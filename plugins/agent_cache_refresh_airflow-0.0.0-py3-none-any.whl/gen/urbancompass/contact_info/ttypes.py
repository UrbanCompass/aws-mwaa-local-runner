
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class AgentProfileType(object):
    INDIVIDUAL = 0
    TEAM = 1

    _VALUES_TO_NAMES = {
        0: "INDIVIDUAL",
        1: "TEAM",
    }

    _NAMES_TO_VALUES = {
        "INDIVIDUAL": 0,
        "TEAM": 1,
    }


class ContactInfoType(object):
    NONE = 0
    CO_BROKER = 1
    MANAGEMENT_FIRM = 2
    LEASING_OFFICE = 3
    SALES_OFFICE = 4
    ACCESS_CONTACT = 5
    UC_AGENT = 6
    CLOSING_CONTACT = 7
    OWNER_OR_LANDLORD = 8
    TENANT = 9
    CO_EXCLUSIVE_BROKER = 10
    MANAGING_AGENT = 11
    ACCOUNT_EXECUTIVE = 12
    TRANSFER_AGENT = 13
    CLOSING_AGENT = 14
    DOORMAN = 15

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "CO_BROKER",
        2: "MANAGEMENT_FIRM",
        3: "LEASING_OFFICE",
        4: "SALES_OFFICE",
        5: "ACCESS_CONTACT",
        6: "UC_AGENT",
        7: "CLOSING_CONTACT",
        8: "OWNER_OR_LANDLORD",
        9: "TENANT",
        10: "CO_EXCLUSIVE_BROKER",
        11: "MANAGING_AGENT",
        12: "ACCOUNT_EXECUTIVE",
        13: "TRANSFER_AGENT",
        14: "CLOSING_AGENT",
        15: "DOORMAN",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "CO_BROKER": 1,
        "MANAGEMENT_FIRM": 2,
        "LEASING_OFFICE": 3,
        "SALES_OFFICE": 4,
        "ACCESS_CONTACT": 5,
        "UC_AGENT": 6,
        "CLOSING_CONTACT": 7,
        "OWNER_OR_LANDLORD": 8,
        "TENANT": 9,
        "CO_EXCLUSIVE_BROKER": 10,
        "MANAGING_AGENT": 11,
        "ACCOUNT_EXECUTIVE": 12,
        "TRANSFER_AGENT": 13,
        "CLOSING_AGENT": 14,
        "DOORMAN": 15,
    }


class EnrichedAgentData(object):
    """
    Attributes:
     - contactName
     - phone
     - mobile
     - email
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'phone', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'mobile', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
    )
    def __init__(self, contactName=None, phone=None, mobile=None, email=None, ):
        self.contactName = contactName
        self.phone = phone
        self.mobile = mobile
        self.email = email

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.mobile = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichedAgentData')
        if self.contactName is not None:
            oprot.writeFieldBegin('contactName', TType.STRING, 1)
            oprot.writeString(self.contactName.encode('utf-8') if sys.version_info[0] == 2 else self.contactName)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 2)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.mobile is not None:
            oprot.writeFieldBegin('mobile', TType.STRING, 3)
            oprot.writeString(self.mobile.encode('utf-8') if sys.version_info[0] == 2 else self.mobile)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactInfo(object):
    """
    Attributes:
     - company
     - officeId
     - email
     - emails
     - contactName
     - phone
     - contactType
     - contactInfoType
     - fax
     - mobile
     - websiteURL
     - profileImageURL
     - title
     - streetAddress
     - city
     - state
     - zipCode
     - notes
     - buildingURL
     - confirmedContact
     - ownerEmailStatus
     - additionalURL
     - userId
     - nonCompassUserId
     - consumerVisible
     - mrisAgentId
     - licenseNum
     - ownerType
     - mlsResoId
     - agentProfileType
     - enrichedAgentData
     - mlsId
     - idxContactInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'company', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'contactName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'phone', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'contactType', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'fax', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'mobile', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'title', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'streetAddress', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'city', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'state', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'zipCode', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'notes', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'userId', 'UTF8', None, ),  # 14
        (15, TType.I32, 'contactInfoType', None, None, ),  # 15
        (16, TType.STRING, 'websiteURL', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'profileImageURL', 'UTF8', None, ),  # 17
        (18, TType.BOOL, 'consumerVisible', None, None, ),  # 18
        (19, TType.STRING, 'mrisAgentId', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'licenseNum', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'ownerType', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'buildingURL', 'UTF8', None, ),  # 22
        (23, TType.STRING, 'confirmedContact', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'ownerEmailStatus', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'additionalURL', 'UTF8', None, ),  # 25
        (26, TType.LIST, 'emails', (TType.STRING, 'UTF8', False), None, ),  # 26
        (27, TType.STRING, 'officeId', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'mlsResoId', 'UTF8', None, ),  # 28
        (29, TType.I32, 'agentProfileType', None, None, ),  # 29
        (30, TType.STRUCT, 'enrichedAgentData', (EnrichedAgentData, EnrichedAgentData.thrift_spec), None, ),  # 30
        (31, TType.STRING, 'nonCompassUserId', 'UTF8', None, ),  # 31
        (32, TType.STRING, 'mlsId', 'UTF8', None, ),  # 32
        (33, TType.STRING, 'idxContactInfo', 'UTF8', None, ),  # 33
    )
    def __init__(self, company=None, email=None, contactName=None, phone=None, contactType=None, fax=None, mobile=None, title=None, streetAddress=None, city=None, state=None, zipCode=None, notes=None, userId=None, contactInfoType=None, websiteURL=None, profileImageURL=None, consumerVisible=None, mrisAgentId=None, licenseNum=None, ownerType=None, buildingURL=None, confirmedContact=None, ownerEmailStatus=None, additionalURL=None, emails=None, officeId=None, mlsResoId=None, agentProfileType=None, enrichedAgentData=None, nonCompassUserId=None, mlsId=None, idxContactInfo=None, ):
        self.company = company
        self.email = email
        self.contactName = contactName
        self.phone = phone
        self.contactType = contactType
        self.fax = fax
        self.mobile = mobile
        self.title = title
        self.streetAddress = streetAddress
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.notes = notes
        self.userId = userId
        self.contactInfoType = contactInfoType
        self.websiteURL = websiteURL
        self.profileImageURL = profileImageURL
        self.consumerVisible = consumerVisible
        self.mrisAgentId = mrisAgentId
        self.licenseNum = licenseNum
        self.ownerType = ownerType
        self.buildingURL = buildingURL
        self.confirmedContact = confirmedContact
        self.ownerEmailStatus = ownerEmailStatus
        self.additionalURL = additionalURL
        self.emails = emails
        self.officeId = officeId
        self.mlsResoId = mlsResoId
        self.agentProfileType = agentProfileType
        self.enrichedAgentData = enrichedAgentData
        self.nonCompassUserId = nonCompassUserId
        self.mlsId = mlsId
        self.idxContactInfo = idxContactInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.contactName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.contactType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.fax = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.mobile = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.streetAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.contactInfoType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.websiteURL = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.profileImageURL = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.consumerVisible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.mrisAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.licenseNum = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.ownerType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.buildingURL = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.confirmedContact = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.ownerEmailStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.additionalURL = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.LIST:
                    self.emails = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emails.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.officeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.mlsResoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.I32:
                    self.agentProfileType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.enrichedAgentData = EnrichedAgentData()
                    self.enrichedAgentData.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.nonCompassUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.STRING:
                    self.idxContactInfo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactInfo')
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 1)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.contactName is not None:
            oprot.writeFieldBegin('contactName', TType.STRING, 3)
            oprot.writeString(self.contactName.encode('utf-8') if sys.version_info[0] == 2 else self.contactName)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 4)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.STRING, 5)
            oprot.writeString(self.contactType.encode('utf-8') if sys.version_info[0] == 2 else self.contactType)
            oprot.writeFieldEnd()
        if self.fax is not None:
            oprot.writeFieldBegin('fax', TType.STRING, 6)
            oprot.writeString(self.fax.encode('utf-8') if sys.version_info[0] == 2 else self.fax)
            oprot.writeFieldEnd()
        if self.mobile is not None:
            oprot.writeFieldBegin('mobile', TType.STRING, 7)
            oprot.writeString(self.mobile.encode('utf-8') if sys.version_info[0] == 2 else self.mobile)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 8)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.streetAddress is not None:
            oprot.writeFieldBegin('streetAddress', TType.STRING, 9)
            oprot.writeString(self.streetAddress.encode('utf-8') if sys.version_info[0] == 2 else self.streetAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 10)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 11)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 12)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 13)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 14)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.contactInfoType is not None:
            oprot.writeFieldBegin('contactInfoType', TType.I32, 15)
            oprot.writeI32(self.contactInfoType)
            oprot.writeFieldEnd()
        if self.websiteURL is not None:
            oprot.writeFieldBegin('websiteURL', TType.STRING, 16)
            oprot.writeString(self.websiteURL.encode('utf-8') if sys.version_info[0] == 2 else self.websiteURL)
            oprot.writeFieldEnd()
        if self.profileImageURL is not None:
            oprot.writeFieldBegin('profileImageURL', TType.STRING, 17)
            oprot.writeString(self.profileImageURL.encode('utf-8') if sys.version_info[0] == 2 else self.profileImageURL)
            oprot.writeFieldEnd()
        if self.consumerVisible is not None:
            oprot.writeFieldBegin('consumerVisible', TType.BOOL, 18)
            oprot.writeBool(self.consumerVisible)
            oprot.writeFieldEnd()
        if self.mrisAgentId is not None:
            oprot.writeFieldBegin('mrisAgentId', TType.STRING, 19)
            oprot.writeString(self.mrisAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.mrisAgentId)
            oprot.writeFieldEnd()
        if self.licenseNum is not None:
            oprot.writeFieldBegin('licenseNum', TType.STRING, 20)
            oprot.writeString(self.licenseNum.encode('utf-8') if sys.version_info[0] == 2 else self.licenseNum)
            oprot.writeFieldEnd()
        if self.ownerType is not None:
            oprot.writeFieldBegin('ownerType', TType.STRING, 21)
            oprot.writeString(self.ownerType.encode('utf-8') if sys.version_info[0] == 2 else self.ownerType)
            oprot.writeFieldEnd()
        if self.buildingURL is not None:
            oprot.writeFieldBegin('buildingURL', TType.STRING, 22)
            oprot.writeString(self.buildingURL.encode('utf-8') if sys.version_info[0] == 2 else self.buildingURL)
            oprot.writeFieldEnd()
        if self.confirmedContact is not None:
            oprot.writeFieldBegin('confirmedContact', TType.STRING, 23)
            oprot.writeString(self.confirmedContact.encode('utf-8') if sys.version_info[0] == 2 else self.confirmedContact)
            oprot.writeFieldEnd()
        if self.ownerEmailStatus is not None:
            oprot.writeFieldBegin('ownerEmailStatus', TType.STRING, 24)
            oprot.writeString(self.ownerEmailStatus.encode('utf-8') if sys.version_info[0] == 2 else self.ownerEmailStatus)
            oprot.writeFieldEnd()
        if self.additionalURL is not None:
            oprot.writeFieldBegin('additionalURL', TType.STRING, 25)
            oprot.writeString(self.additionalURL.encode('utf-8') if sys.version_info[0] == 2 else self.additionalURL)
            oprot.writeFieldEnd()
        if self.emails is not None:
            oprot.writeFieldBegin('emails', TType.LIST, 26)
            oprot.writeListBegin(TType.STRING, len(self.emails))
            for _iter6 in self.emails:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.officeId is not None:
            oprot.writeFieldBegin('officeId', TType.STRING, 27)
            oprot.writeString(self.officeId.encode('utf-8') if sys.version_info[0] == 2 else self.officeId)
            oprot.writeFieldEnd()
        if self.mlsResoId is not None:
            oprot.writeFieldBegin('mlsResoId', TType.STRING, 28)
            oprot.writeString(self.mlsResoId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsResoId)
            oprot.writeFieldEnd()
        if self.agentProfileType is not None:
            oprot.writeFieldBegin('agentProfileType', TType.I32, 29)
            oprot.writeI32(self.agentProfileType)
            oprot.writeFieldEnd()
        if self.enrichedAgentData is not None:
            oprot.writeFieldBegin('enrichedAgentData', TType.STRUCT, 30)
            self.enrichedAgentData.write(oprot)
            oprot.writeFieldEnd()
        if self.nonCompassUserId is not None:
            oprot.writeFieldBegin('nonCompassUserId', TType.STRING, 31)
            oprot.writeString(self.nonCompassUserId.encode('utf-8') if sys.version_info[0] == 2 else self.nonCompassUserId)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 32)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.idxContactInfo is not None:
            oprot.writeFieldBegin('idxContactInfo', TType.STRING, 33)
            oprot.writeString(self.idxContactInfo.encode('utf-8') if sys.version_info[0] == 2 else self.idxContactInfo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactInfoWithTeam(object):
    """
    Attributes:
     - contactInfo
     - teamContactInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'contactInfo', (ContactInfo, ContactInfo.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'teamContactInfo', (ContactInfo, ContactInfo.thrift_spec), None, ),  # 2
    )
    def __init__(self, contactInfo=None, teamContactInfo=None, ):
        self.contactInfo = contactInfo
        self.teamContactInfo = teamContactInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.contactInfo = ContactInfo()
                    self.contactInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.teamContactInfo = ContactInfo()
                    self.teamContactInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactInfoWithTeam')
        if self.contactInfo is not None:
            oprot.writeFieldBegin('contactInfo', TType.STRUCT, 1)
            self.contactInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.teamContactInfo is not None:
            oprot.writeFieldBegin('teamContactInfo', TType.STRUCT, 2)
            self.teamContactInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactInfos(object):
    """
    Attributes:
     - contactInfos
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'contactInfos', (TType.STRUCT, (ContactInfo, ContactInfo.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, contactInfos=None, ):
        self.contactInfos = contactInfos

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.contactInfos = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = ContactInfo()
                        _elem9.read(iprot)
                        self.contactInfos.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactInfos')
        if self.contactInfos is not None:
            oprot.writeFieldBegin('contactInfos', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.contactInfos))
            for _iter11 in self.contactInfos:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
