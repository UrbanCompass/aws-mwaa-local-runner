
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.application.ttypes
import gen.urbancompass.asset_library.asset_library_models.ttypes
import gen.urbancompass.boards.api.ttypes
import gen.urbancompass.cma.cma_models.ttypes
import gen.urbancompass.comments.service.ttypes
import gen.urbancompass.contacts.api.contact.ttypes
import gen.urbancompass.bi.dashboard.data.dashboard.ttypes
import gen.urbancompass.bi.dashboard.data.dataframe.ttypes
import gen.urbancompass.deals.constants.ttypes
import gen.urbancompass.design_studio.models.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.docstore.ttypes
import gen.urbancompass.inventory_apps.folder.folder_service_common.ttypes
import gen.urbancompass.inventory_apps.folder.external.folder_service_ext.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.listing_translation.listing_translation_service.ttypes
import gen.urbancompass.people.api.person.ttypes
import gen.urbancompass.photography_manager.model.ttypes
import gen.urbancompass.pitch.pitch.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes
import gen.urbancompass.search.saved_searches.ttypes
import gen.urbancompass.showsheet.showsheet.ttypes
import gen.urbancompass.tasks.tasks.api.ttypes
import gen.urbancompass.toursheet.toursheet.ttypes
import gen.urbancompass.valuation.valuation.ttypes
import gen.urbancompass.bi.dashboard.data.visualization.ttypes

from thrift.transport import TTransport


class ActivitySection(object):
    FAVORITES = 0
    VIEWS = 1
    INTERESTED = 2
    COMMENTS = 3
    EMAILS = 4
    TOUR_REQUESTS = 5

    _VALUES_TO_NAMES = {
        0: "FAVORITES",
        1: "VIEWS",
        2: "INTERESTED",
        3: "COMMENTS",
        4: "EMAILS",
        5: "TOUR_REQUESTS",
    }

    _NAMES_TO_VALUES = {
        "FAVORITES": 0,
        "VIEWS": 1,
        "INTERESTED": 2,
        "COMMENTS": 3,
        "EMAILS": 4,
        "TOUR_REQUESTS": 5,
    }


class DealCollaboratorRole(object):
    CLIENT = 0
    AGENT = 1
    OWNER = 2
    UNINVITED = 3

    _VALUES_TO_NAMES = {
        0: "CLIENT",
        1: "AGENT",
        2: "OWNER",
        3: "UNINVITED",
    }

    _NAMES_TO_VALUES = {
        "CLIENT": 0,
        "AGENT": 1,
        "OWNER": 2,
        "UNINVITED": 3,
    }


class DealConfidence(object):
    LOW = 0
    MEDIUM = 1
    HIGH = 2

    _VALUES_TO_NAMES = {
        0: "LOW",
        1: "MEDIUM",
        2: "HIGH",
    }

    _NAMES_TO_VALUES = {
        "LOW": 0,
        "MEDIUM": 1,
        "HIGH": 2,
    }


class DealDisposition(object):
    WON = 0
    LOST = 1
    ABANDONED = 2
    OPEN = 3

    _VALUES_TO_NAMES = {
        0: "WON",
        1: "LOST",
        2: "ABANDONED",
        3: "OPEN",
    }

    _NAMES_TO_VALUES = {
        "WON": 0,
        "LOST": 1,
        "ABANDONED": 2,
        "OPEN": 3,
    }


class DealStage(object):
    PRE_LISTING = 0
    PRE_OFFER = 1
    ACTIVE_LISTING = 2
    NEW = 3
    UNDER_CONTRACT = 4
    IN_PROGRESS = 5
    SOLD = 6
    LEASED = 7
    DONE = 8

    _VALUES_TO_NAMES = {
        0: "PRE_LISTING",
        1: "PRE_OFFER",
        2: "ACTIVE_LISTING",
        3: "NEW",
        4: "UNDER_CONTRACT",
        5: "IN_PROGRESS",
        6: "SOLD",
        7: "LEASED",
        8: "DONE",
    }

    _NAMES_TO_VALUES = {
        "PRE_LISTING": 0,
        "PRE_OFFER": 1,
        "ACTIVE_LISTING": 2,
        "NEW": 3,
        "UNDER_CONTRACT": 4,
        "IN_PROGRESS": 5,
        "SOLD": 6,
        "LEASED": 7,
        "DONE": 8,
    }


class DealStatus(object):
    OPEN = 0
    ARCHIVED = 1
    DELETED = 2

    _VALUES_TO_NAMES = {
        0: "OPEN",
        1: "ARCHIVED",
        2: "DELETED",
    }

    _NAMES_TO_VALUES = {
        "OPEN": 0,
        "ARCHIVED": 1,
        "DELETED": 2,
    }


class DealTool(object):
    COLLECTIONS = 0
    SAVED_SEARCHES = 1
    TOURS = 2
    INSIGHTS = 3
    MARKETING_CENTER = 4
    COMPS = 5
    HOT_SHEETS = 6
    OPEN_HOUSE = 7
    LISTING_EDITOR = 8
    NETWORK = 9

    _VALUES_TO_NAMES = {
        0: "COLLECTIONS",
        1: "SAVED_SEARCHES",
        2: "TOURS",
        3: "INSIGHTS",
        4: "MARKETING_CENTER",
        5: "COMPS",
        6: "HOT_SHEETS",
        7: "OPEN_HOUSE",
        8: "LISTING_EDITOR",
        9: "NETWORK",
    }

    _NAMES_TO_VALUES = {
        "COLLECTIONS": 0,
        "SAVED_SEARCHES": 1,
        "TOURS": 2,
        "INSIGHTS": 3,
        "MARKETING_CENTER": 4,
        "COMPS": 5,
        "HOT_SHEETS": 6,
        "OPEN_HOUSE": 7,
        "LISTING_EDITOR": 8,
        "NETWORK": 9,
    }


class DealType(object):
    SELL = 0
    BUY = 1
    LEASE_LISTING = 2
    LEASE_RENTAL = 3
    OTHER = 4
    REFERRED_OUT = 5

    _VALUES_TO_NAMES = {
        0: "SELL",
        1: "BUY",
        2: "LEASE_LISTING",
        3: "LEASE_RENTAL",
        4: "OTHER",
        5: "REFERRED_OUT",
    }

    _NAMES_TO_VALUES = {
        "SELL": 0,
        "BUY": 1,
        "LEASE_LISTING": 2,
        "LEASE_RENTAL": 3,
        "OTHER": 4,
        "REFERRED_OUT": 5,
    }


class OpportunityPhase(object):
    PRE = 0
    ACTIVE = 1
    CLOSE = 2
    INACTIVE = 3

    _VALUES_TO_NAMES = {
        0: "PRE",
        1: "ACTIVE",
        2: "CLOSE",
        3: "INACTIVE",
    }

    _NAMES_TO_VALUES = {
        "PRE": 0,
        "ACTIVE": 1,
        "CLOSE": 2,
        "INACTIVE": 3,
    }


class AgentInfo(object):
    """
    Attributes:
     - internalAgent
     - externalAgent
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'internalAgent', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'externalAgent', (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), None, ),  # 2
    )
    def __init__(self, internalAgent=None, externalAgent=None, ):
        self.internalAgent = internalAgent
        self.externalAgent = externalAgent

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.internalAgent = gen.urbancompass.people.api.person.ttypes.Person()
                    self.internalAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.externalAgent = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                    self.externalAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentInfo')
        if self.internalAgent is not None:
            oprot.writeFieldBegin('internalAgent', TType.STRUCT, 1)
            self.internalAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.externalAgent is not None:
            oprot.writeFieldBegin('externalAgent', TType.STRUCT, 2)
            self.externalAgent.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AttachableDeal(object):
    """
    Attributes:
     - id
     - name
     - updatedAt
     - matchedAddress
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.BOOL, 'matchedAddress', None, None, ),  # 4
    )
    def __init__(self, id=None, name=None, updatedAt=None, matchedAddress=None, ):
        self.id = id
        self.name = name
        self.updatedAt = updatedAt
        self.matchedAddress = matchedAddress

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.matchedAddress = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AttachableDeal')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.matchedAddress is not None:
            oprot.writeFieldBegin('matchedAddress', TType.BOOL, 4)
            oprot.writeBool(self.matchedAddress)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AttachmentKey(object):
    """
    Attributes:
     - id
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
    )
    def __init__(self, id=None, type=None, ):
        self.id = id
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AttachmentKey')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AttachmentRefs(object):
    """
    Attributes:
     - ids
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'ids', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
    )
    def __init__(self, ids=None, type=None, ):
        self.ids = ids
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.ids.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AttachmentRefs')
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.ids))
            for _iter6 in self.ids:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BulkCreateDealRequest(object):
    """
    Attributes:
     - type
     - name
     - opportunityStageId
     - opportunityPhase
     - listingID
     - teamId
     - isAutoCreated
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'opportunityStageId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'opportunityPhase', None, None, ),  # 4
        (5, TType.STRING, 'listingID', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'teamId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'isAutoCreated', None, None, ),  # 7
    )
    def __init__(self, type=None, name=None, opportunityStageId=None, opportunityPhase=None, listingID=None, teamId=None, isAutoCreated=None, ):
        self.type = type
        self.name = name
        self.opportunityStageId = opportunityStageId
        self.opportunityPhase = opportunityPhase
        self.listingID = listingID
        self.teamId = teamId
        self.isAutoCreated = isAutoCreated

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.opportunityStageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.opportunityPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.listingID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isAutoCreated = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkCreateDealRequest')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.opportunityStageId is not None:
            oprot.writeFieldBegin('opportunityStageId', TType.STRING, 3)
            oprot.writeString(self.opportunityStageId.encode('utf-8') if sys.version_info[0] == 2 else self.opportunityStageId)
            oprot.writeFieldEnd()
        if self.opportunityPhase is not None:
            oprot.writeFieldBegin('opportunityPhase', TType.I32, 4)
            oprot.writeI32(self.opportunityPhase)
            oprot.writeFieldEnd()
        if self.listingID is not None:
            oprot.writeFieldBegin('listingID', TType.STRING, 5)
            oprot.writeString(self.listingID.encode('utf-8') if sys.version_info[0] == 2 else self.listingID)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 6)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.isAutoCreated is not None:
            oprot.writeFieldBegin('isAutoCreated', TType.BOOL, 7)
            oprot.writeBool(self.isAutoCreated)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommentFeedItem(object):
    """
    Attributes:
     - timestamp
     - boardListing
     - board
     - comment
     - views
     - person
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'timestamp', None, None, ),  # 1
        (2, TType.STRUCT, 'boardListing', (gen.urbancompass.boards.api.ttypes.BoardListing, gen.urbancompass.boards.api.ttypes.BoardListing.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'board', (gen.urbancompass.boards.api.ttypes.Board, gen.urbancompass.boards.api.ttypes.Board.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'comment', (gen.urbancompass.comments.service.ttypes.Comment, gen.urbancompass.comments.service.ttypes.Comment.thrift_spec), None, ),  # 4
        (5, TType.I32, 'views', None, None, ),  # 5
        (6, TType.STRUCT, 'person', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 6
    )
    def __init__(self, timestamp=None, boardListing=None, board=None, comment=None, views=None, person=None, ):
        self.timestamp = timestamp
        self.boardListing = boardListing
        self.board = board
        self.comment = comment
        self.views = views
        self.person = person

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.boardListing = gen.urbancompass.boards.api.ttypes.BoardListing()
                    self.boardListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.board = gen.urbancompass.boards.api.ttypes.Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.comment = gen.urbancompass.comments.service.ttypes.Comment()
                    self.comment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.views = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.person = gen.urbancompass.people.api.person.ttypes.Person()
                    self.person.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommentFeedItem')
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 1)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.boardListing is not None:
            oprot.writeFieldBegin('boardListing', TType.STRUCT, 2)
            self.boardListing.write(oprot)
            oprot.writeFieldEnd()
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 3)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        if self.comment is not None:
            oprot.writeFieldBegin('comment', TType.STRUCT, 4)
            self.comment.write(oprot)
            oprot.writeFieldEnd()
        if self.views is not None:
            oprot.writeFieldBegin('views', TType.I32, 5)
            oprot.writeI32(self.views)
            oprot.writeFieldEnd()
        if self.person is not None:
            oprot.writeFieldBegin('person', TType.STRUCT, 6)
            self.person.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealActivityError(object):
    """
    Attributes:
     - message
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'message', 'UTF8', None, ),  # 1
    )
    def __init__(self, message=None, ):
        self.message = message

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.message = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealActivityError')
        if self.message is not None:
            oprot.writeFieldBegin('message', TType.STRING, 1)
            oprot.writeString(self.message.encode('utf-8') if sys.version_info[0] == 2 else self.message)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealActivityMetadata(object):
    """
    Attributes:
     - favoriteCount
     - viewCount
     - interestCount
     - commentCount
     - emailCount
     - emailOpenCount
     - tourRequestCount
     - totalCommentCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'favoriteCount', None, None, ),  # 1
        (2, TType.I32, 'viewCount', None, None, ),  # 2
        (3, TType.I32, 'interestCount', None, None, ),  # 3
        (4, TType.I32, 'commentCount', None, None, ),  # 4
        (5, TType.I32, 'emailCount', None, None, ),  # 5
        (6, TType.I32, 'emailOpenCount', None, None, ),  # 6
        (7, TType.I32, 'tourRequestCount', None, None, ),  # 7
        (8, TType.I32, 'totalCommentCount', None, None, ),  # 8
    )
    def __init__(self, favoriteCount=None, viewCount=None, interestCount=None, commentCount=None, emailCount=None, emailOpenCount=None, tourRequestCount=None, totalCommentCount=None, ):
        self.favoriteCount = favoriteCount
        self.viewCount = viewCount
        self.interestCount = interestCount
        self.commentCount = commentCount
        self.emailCount = emailCount
        self.emailOpenCount = emailOpenCount
        self.tourRequestCount = tourRequestCount
        self.totalCommentCount = totalCommentCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.favoriteCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.viewCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.interestCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.commentCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.emailCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.emailOpenCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.tourRequestCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.totalCommentCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealActivityMetadata')
        if self.favoriteCount is not None:
            oprot.writeFieldBegin('favoriteCount', TType.I32, 1)
            oprot.writeI32(self.favoriteCount)
            oprot.writeFieldEnd()
        if self.viewCount is not None:
            oprot.writeFieldBegin('viewCount', TType.I32, 2)
            oprot.writeI32(self.viewCount)
            oprot.writeFieldEnd()
        if self.interestCount is not None:
            oprot.writeFieldBegin('interestCount', TType.I32, 3)
            oprot.writeI32(self.interestCount)
            oprot.writeFieldEnd()
        if self.commentCount is not None:
            oprot.writeFieldBegin('commentCount', TType.I32, 4)
            oprot.writeI32(self.commentCount)
            oprot.writeFieldEnd()
        if self.emailCount is not None:
            oprot.writeFieldBegin('emailCount', TType.I32, 5)
            oprot.writeI32(self.emailCount)
            oprot.writeFieldEnd()
        if self.emailOpenCount is not None:
            oprot.writeFieldBegin('emailOpenCount', TType.I32, 6)
            oprot.writeI32(self.emailOpenCount)
            oprot.writeFieldEnd()
        if self.tourRequestCount is not None:
            oprot.writeFieldBegin('tourRequestCount', TType.I32, 7)
            oprot.writeI32(self.tourRequestCount)
            oprot.writeFieldEnd()
        if self.totalCommentCount is not None:
            oprot.writeFieldBegin('totalCommentCount', TType.I32, 8)
            oprot.writeI32(self.totalCommentCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealActivitySummary(object):
    """
    Attributes:
     - homeViews
     - favorites
     - messages
     - emailOpens
     - savedSearches
     - tourRequests
     - lastActivity
     - unreadMessages
     - newFavorites
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'homeViews', None, None, ),  # 1
        (2, TType.I32, 'favorites', None, None, ),  # 2
        (3, TType.I32, 'messages', None, None, ),  # 3
        (4, TType.I32, 'emailOpens', None, None, ),  # 4
        (5, TType.I32, 'savedSearches', None, None, ),  # 5
        (6, TType.BOOL, 'unreadMessages', None, None, ),  # 6
        (7, TType.I64, 'lastActivity', None, None, ),  # 7
        (8, TType.BOOL, 'newFavorites', None, None, ),  # 8
        (9, TType.I32, 'tourRequests', None, None, ),  # 9
    )
    def __init__(self, homeViews=None, favorites=None, messages=None, emailOpens=None, savedSearches=None, unreadMessages=None, lastActivity=None, newFavorites=None, tourRequests=None, ):
        self.homeViews = homeViews
        self.favorites = favorites
        self.messages = messages
        self.emailOpens = emailOpens
        self.savedSearches = savedSearches
        self.unreadMessages = unreadMessages
        self.lastActivity = lastActivity
        self.newFavorites = newFavorites
        self.tourRequests = tourRequests

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.homeViews = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.favorites = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.messages = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.emailOpens = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.savedSearches = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.unreadMessages = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastActivity = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.newFavorites = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.tourRequests = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealActivitySummary')
        if self.homeViews is not None:
            oprot.writeFieldBegin('homeViews', TType.I32, 1)
            oprot.writeI32(self.homeViews)
            oprot.writeFieldEnd()
        if self.favorites is not None:
            oprot.writeFieldBegin('favorites', TType.I32, 2)
            oprot.writeI32(self.favorites)
            oprot.writeFieldEnd()
        if self.messages is not None:
            oprot.writeFieldBegin('messages', TType.I32, 3)
            oprot.writeI32(self.messages)
            oprot.writeFieldEnd()
        if self.emailOpens is not None:
            oprot.writeFieldBegin('emailOpens', TType.I32, 4)
            oprot.writeI32(self.emailOpens)
            oprot.writeFieldEnd()
        if self.savedSearches is not None:
            oprot.writeFieldBegin('savedSearches', TType.I32, 5)
            oprot.writeI32(self.savedSearches)
            oprot.writeFieldEnd()
        if self.unreadMessages is not None:
            oprot.writeFieldBegin('unreadMessages', TType.BOOL, 6)
            oprot.writeBool(self.unreadMessages)
            oprot.writeFieldEnd()
        if self.lastActivity is not None:
            oprot.writeFieldBegin('lastActivity', TType.I64, 7)
            oprot.writeI64(self.lastActivity)
            oprot.writeFieldEnd()
        if self.newFavorites is not None:
            oprot.writeFieldBegin('newFavorites', TType.BOOL, 8)
            oprot.writeBool(self.newFavorites)
            oprot.writeFieldEnd()
        if self.tourRequests is not None:
            oprot.writeFieldBegin('tourRequests', TType.I32, 9)
            oprot.writeI32(self.tourRequests)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealAggregates(object):
    """
    Attributes:
     - totalResults
     - totalVolume
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'totalResults', None, None, ),  # 1
        (2, TType.I64, 'totalVolume', None, None, ),  # 2
    )
    def __init__(self, totalResults=None, totalVolume=None, ):
        self.totalResults = totalResults
        self.totalVolume = totalVolume

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.totalVolume = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealAggregates')
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 1)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        if self.totalVolume is not None:
            oprot.writeFieldBegin('totalVolume', TType.I64, 2)
            oprot.writeI64(self.totalVolume)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealAssetLibraryCollection(object):
    """
    Attributes:
     - id
     - collection
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'collection', (gen.urbancompass.asset_library.asset_library_models.ttypes.Collection, gen.urbancompass.asset_library.asset_library_models.ttypes.Collection.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, collection=None, ):
        self.id = id
        self.collection = collection

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.collection = gen.urbancompass.asset_library.asset_library_models.ttypes.Collection()
                    self.collection.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealAssetLibraryCollection')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.collection is not None:
            oprot.writeFieldBegin('collection', TType.STRUCT, 2)
            self.collection.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCma(object):
    """
    Attributes:
     - id
     - cma
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'cma', (gen.urbancompass.cma.cma_models.ttypes.Cma, gen.urbancompass.cma.cma_models.ttypes.Cma.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, cma=None, ):
        self.id = id
        self.cma = cma

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.cma = gen.urbancompass.cma.cma_models.ttypes.Cma()
                    self.cma.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCma')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.cma is not None:
            oprot.writeFieldBegin('cma', TType.STRUCT, 2)
            self.cma.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCollaboratorSource(object):
    """
    Attributes:
     - person
     - group
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'person', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'group', 'UTF8', None, ),  # 2
    )
    def __init__(self, person=None, group=None, ):
        self.person = person
        self.group = group

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.person = gen.urbancompass.people.api.person.ttypes.Person()
                    self.person.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.group = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCollaboratorSource')
        if self.person is not None:
            oprot.writeFieldBegin('person', TType.STRUCT, 1)
            self.person.write(oprot)
            oprot.writeFieldEnd()
        if self.group is not None:
            oprot.writeFieldBegin('group', TType.STRING, 2)
            oprot.writeString(self.group.encode('utf-8') if sys.version_info[0] == 2 else self.group)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCollection(object):
    """
    Attributes:
     - id
     - collection
     - content
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'collection', (gen.urbancompass.boards.api.ttypes.Board, gen.urbancompass.boards.api.ttypes.Board.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'content', (gen.urbancompass.boards.api.ttypes.PaginatedBoardContent, gen.urbancompass.boards.api.ttypes.PaginatedBoardContent.thrift_spec), None, ),  # 3
    )
    def __init__(self, id=None, collection=None, content=None, ):
        self.id = id
        self.collection = collection
        self.content = content

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.collection = gen.urbancompass.boards.api.ttypes.Board()
                    self.collection.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.content = gen.urbancompass.boards.api.ttypes.PaginatedBoardContent()
                    self.content.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCollection')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.collection is not None:
            oprot.writeFieldBegin('collection', TType.STRUCT, 2)
            self.collection.write(oprot)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRUCT, 3)
            self.content.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealContact(object):
    """
    Attributes:
     - id
     - contact
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'contact', (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, contact=None, ):
        self.id = id
        self.contact = contact

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.contact = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealContact')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 2)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealDocumentSource(object):
    """
    Attributes:
     - pitch
     - showsheet
     - toursheet
     - valuation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'pitch', (gen.urbancompass.pitch.pitch.ttypes.Pitch, gen.urbancompass.pitch.pitch.ttypes.Pitch.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'showsheet', (gen.urbancompass.showsheet.showsheet.ttypes.Showsheet, gen.urbancompass.showsheet.showsheet.ttypes.Showsheet.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'toursheet', (gen.urbancompass.toursheet.toursheet.ttypes.Toursheet, gen.urbancompass.toursheet.toursheet.ttypes.Toursheet.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'valuation', (gen.urbancompass.valuation.valuation.ttypes.Valuation, gen.urbancompass.valuation.valuation.ttypes.Valuation.thrift_spec), None, ),  # 4
    )
    def __init__(self, pitch=None, showsheet=None, toursheet=None, valuation=None, ):
        self.pitch = pitch
        self.showsheet = showsheet
        self.toursheet = toursheet
        self.valuation = valuation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.pitch = gen.urbancompass.pitch.pitch.ttypes.Pitch()
                    self.pitch.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.showsheet = gen.urbancompass.showsheet.showsheet.ttypes.Showsheet()
                    self.showsheet.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.toursheet = gen.urbancompass.toursheet.toursheet.ttypes.Toursheet()
                    self.toursheet.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.valuation = gen.urbancompass.valuation.valuation.ttypes.Valuation()
                    self.valuation.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealDocumentSource')
        if self.pitch is not None:
            oprot.writeFieldBegin('pitch', TType.STRUCT, 1)
            self.pitch.write(oprot)
            oprot.writeFieldEnd()
        if self.showsheet is not None:
            oprot.writeFieldBegin('showsheet', TType.STRUCT, 2)
            self.showsheet.write(oprot)
            oprot.writeFieldEnd()
        if self.toursheet is not None:
            oprot.writeFieldBegin('toursheet', TType.STRUCT, 3)
            self.toursheet.write(oprot)
            oprot.writeFieldEnd()
        if self.valuation is not None:
            oprot.writeFieldBegin('valuation', TType.STRUCT, 4)
            self.valuation.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealFileStorage(object):
    """
    Attributes:
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
    )
    def __init__(self, id=None, ):
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealFileStorage')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealInsights(object):
    """
    Attributes:
     - dataVisualizations
     - dfIdsToDataframes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dataVisualizations', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.visualization.ttypes.DataVisualization, gen.urbancompass.bi.dashboard.data.visualization.ttypes.DataVisualization.thrift_spec), False), None, ),  # 1
        (2, TType.MAP, 'dfIdsToDataframes', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.bi.dashboard.data.dataframe.ttypes.Dataframe, gen.urbancompass.bi.dashboard.data.dataframe.ttypes.Dataframe.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, dataVisualizations=None, dfIdsToDataframes=None, ):
        self.dataVisualizations = dataVisualizations
        self.dfIdsToDataframes = dfIdsToDataframes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dataVisualizations = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = gen.urbancompass.bi.dashboard.data.visualization.ttypes.DataVisualization()
                        _elem9.read(iprot)
                        self.dataVisualizations.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.dfIdsToDataframes = {}
                    (_ktype12, _vtype13, _size16) = iprot.readMapBegin()
                    for _i11 in range(_size16):
                        _key14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val15 = gen.urbancompass.bi.dashboard.data.dataframe.ttypes.Dataframe()
                        _val15.read(iprot)
                        self.dfIdsToDataframes[_key14] = _val15
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealInsights')
        if self.dataVisualizations is not None:
            oprot.writeFieldBegin('dataVisualizations', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.dataVisualizations))
            for _iter17 in self.dataVisualizations:
                _iter17.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dfIdsToDataframes is not None:
            oprot.writeFieldBegin('dfIdsToDataframes', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.dfIdsToDataframes))
            for _kiter18, _viter19 in self.dfIdsToDataframes.items():
                oprot.writeString(_kiter18.encode('utf-8') if sys.version_info[0] == 2 else _kiter18)
                _viter19.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealLocatorRef(object):
    """
    Attributes:
     - ids
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'ids', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
    )
    def __init__(self, ids=None, type=None, ):
        self.ids = ids
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.ids.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealLocatorRef')
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.ids))
            for _iter24 in self.ids:
                oprot.writeString(_iter24.encode('utf-8') if sys.version_info[0] == 2 else _iter24)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPhotoIngestionProject(object):
    """
    Attributes:
     - id
     - project
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'project', (gen.urbancompass.photography_manager.model.ttypes.Project, gen.urbancompass.photography_manager.model.ttypes.Project.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, project=None, ):
        self.id = id
        self.project = project

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.project = gen.urbancompass.photography_manager.model.ttypes.Project()
                    self.project.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPhotoIngestionProject')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.project is not None:
            oprot.writeFieldBegin('project', TType.STRUCT, 2)
            self.project.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPrice(object):
    """
    Attributes:
     - min
     - max
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'min', None, None, ),  # 1
        (2, TType.DOUBLE, 'max', None, None, ),  # 2
    )
    def __init__(self, min=None, max=None, ):
        self.min = min
        self.max = max

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.min = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.max = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPrice')
        if self.min is not None:
            oprot.writeFieldBegin('min', TType.DOUBLE, 1)
            oprot.writeDouble(self.min)
            oprot.writeFieldEnd()
        if self.max is not None:
            oprot.writeFieldBegin('max', TType.DOUBLE, 2)
            oprot.writeDouble(self.max)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealSavedSearch(object):
    """
    Attributes:
     - id
     - savedSearch
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'savedSearch', (gen.urbancompass.search.saved_searches.ttypes.SavedSearch, gen.urbancompass.search.saved_searches.ttypes.SavedSearch.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, savedSearch=None, ):
        self.id = id
        self.savedSearch = savedSearch

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.savedSearch = gen.urbancompass.search.saved_searches.ttypes.SavedSearch()
                    self.savedSearch.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealSavedSearch')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.savedSearch is not None:
            oprot.writeFieldBegin('savedSearch', TType.STRUCT, 2)
            self.savedSearch.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealStageHistory(object):
    """
    Attributes:
     - timeMillis
     - prevStage
     - currentStage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'timeMillis', None, None, ),  # 1
        (2, TType.I32, 'prevStage', None, None, ),  # 2
        (3, TType.I32, 'currentStage', None, None, ),  # 3
    )
    def __init__(self, timeMillis=None, prevStage=None, currentStage=None, ):
        self.timeMillis = timeMillis
        self.prevStage = prevStage
        self.currentStage = currentStage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.timeMillis = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.prevStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealStageHistory')
        if self.timeMillis is not None:
            oprot.writeFieldBegin('timeMillis', TType.I64, 1)
            oprot.writeI64(self.timeMillis)
            oprot.writeFieldEnd()
        if self.prevStage is not None:
            oprot.writeFieldBegin('prevStage', TType.I32, 2)
            oprot.writeI32(self.prevStage)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 3)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealTask(object):
    """
    Attributes:
     - id
     - task
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'task', (gen.urbancompass.tasks.tasks.api.ttypes.TaskV2, gen.urbancompass.tasks.tasks.api.ttypes.TaskV2.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, task=None, ):
        self.id = id
        self.task = task

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.task = gen.urbancompass.tasks.tasks.api.ttypes.TaskV2()
                    self.task.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealTask')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.task is not None:
            oprot.writeFieldBegin('task', TType.STRUCT, 2)
            self.task.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealToursheet(object):
    """
    Attributes:
     - id
     - toursheet
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'toursheet', (gen.urbancompass.toursheet.toursheet.ttypes.Toursheet, gen.urbancompass.toursheet.toursheet.ttypes.Toursheet.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, toursheet=None, ):
        self.id = id
        self.toursheet = toursheet

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.toursheet = gen.urbancompass.toursheet.toursheet.ttypes.Toursheet()
                    self.toursheet.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealToursheet')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.toursheet is not None:
            oprot.writeFieldBegin('toursheet', TType.STRUCT, 2)
            self.toursheet.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EmailFeedItem(object):
    """
    Attributes:
     - timestamp
     - deliverableId
     - contact
     - openTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'timestamp', None, None, ),  # 1
        (2, TType.STRING, 'deliverableId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'contact', (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), None, ),  # 3
        (4, TType.I64, 'openTimestamp', None, None, ),  # 4
    )
    def __init__(self, timestamp=None, deliverableId=None, contact=None, openTimestamp=None, ):
        self.timestamp = timestamp
        self.deliverableId = deliverableId
        self.contact = contact
        self.openTimestamp = openTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.deliverableId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.contact = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.openTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EmailFeedItem')
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 1)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.deliverableId is not None:
            oprot.writeFieldBegin('deliverableId', TType.STRING, 2)
            oprot.writeString(self.deliverableId.encode('utf-8') if sys.version_info[0] == 2 else self.deliverableId)
            oprot.writeFieldEnd()
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 3)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        if self.openTimestamp is not None:
            oprot.writeFieldBegin('openTimestamp', TType.I64, 4)
            oprot.writeI64(self.openTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingActivitySummary(object):
    """
    Attributes:
     - listingId
     - favorites
     - notInterested
     - views
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'favorites', (TType.STRUCT, (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'notInterested', (TType.STRUCT, (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'views', (TType.STRUCT, (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), False), None, ),  # 4
    )
    def __init__(self, listingId=None, favorites=None, notInterested=None, views=None, ):
        self.listingId = listingId
        self.favorites = favorites
        self.notInterested = notInterested
        self.views = views

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.favorites = []
                    (_etype25, _size28) = iprot.readListBegin()
                    for _i26 in range(_size28):
                        _elem27 = gen.urbancompass.people.api.person.ttypes.Person()
                        _elem27.read(iprot)
                        self.favorites.append(_elem27)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.notInterested = []
                    (_etype29, _size32) = iprot.readListBegin()
                    for _i30 in range(_size32):
                        _elem31 = gen.urbancompass.people.api.person.ttypes.Person()
                        _elem31.read(iprot)
                        self.notInterested.append(_elem31)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.views = []
                    (_etype33, _size36) = iprot.readListBegin()
                    for _i34 in range(_size36):
                        _elem35 = gen.urbancompass.people.api.person.ttypes.Person()
                        _elem35.read(iprot)
                        self.views.append(_elem35)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingActivitySummary')
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 1)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.favorites is not None:
            oprot.writeFieldBegin('favorites', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.favorites))
            for _iter37 in self.favorites:
                _iter37.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notInterested is not None:
            oprot.writeFieldBegin('notInterested', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.notInterested))
            for _iter38 in self.notInterested:
                _iter38.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.views is not None:
            oprot.writeFieldBegin('views', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.views))
            for _iter39 in self.views:
                _iter39.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingFeedItem(object):
    """
    Attributes:
     - timestamp
     - boardListing
     - person
     - views
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'timestamp', None, None, ),  # 1
        (2, TType.STRUCT, 'boardListing', (gen.urbancompass.boards.api.ttypes.BoardListing, gen.urbancompass.boards.api.ttypes.BoardListing.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'person', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 3
        (4, TType.I32, 'views', None, None, ),  # 4
    )
    def __init__(self, timestamp=None, boardListing=None, person=None, views=None, ):
        self.timestamp = timestamp
        self.boardListing = boardListing
        self.person = person
        self.views = views

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.boardListing = gen.urbancompass.boards.api.ttypes.BoardListing()
                    self.boardListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.person = gen.urbancompass.people.api.person.ttypes.Person()
                    self.person.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.views = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingFeedItem')
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 1)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.boardListing is not None:
            oprot.writeFieldBegin('boardListing', TType.STRUCT, 2)
            self.boardListing.write(oprot)
            oprot.writeFieldEnd()
        if self.person is not None:
            oprot.writeFieldBegin('person', TType.STRUCT, 3)
            self.person.write(oprot)
            oprot.writeFieldEnd()
        if self.views is not None:
            oprot.writeFieldBegin('views', TType.I32, 4)
            oprot.writeI32(self.views)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MinimalPersonDetails(object):
    """
    Attributes:
     - firstName
     - lastName
     - email
     - avatarUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'firstName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'lastName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 4
    )
    def __init__(self, firstName=None, lastName=None, email=None, avatarUrl=None, ):
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.avatarUrl = avatarUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MinimalPersonDetails')
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 1)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 2)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 4)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class OpportunityStage(object):
    """
    Attributes:
     - id
     - name
     - phase
     - status
     - transactionPhase
     - description
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I32, 'phase', None, None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.I32, 'transactionPhase', None, None, ),  # 5
        (6, TType.STRING, 'description', 'UTF8', None, ),  # 6
    )
    def __init__(self, id=None, name=None, phase=None, status=None, transactionPhase=None, description=None, ):
        self.id = id
        self.name = name
        self.phase = phase
        self.status = status
        self.transactionPhase = transactionPhase
        self.description = description

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.phase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.transactionPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('OpportunityStage')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.phase is not None:
            oprot.writeFieldBegin('phase', TType.I32, 3)
            oprot.writeI32(self.phase)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.transactionPhase is not None:
            oprot.writeFieldBegin('transactionPhase', TType.I32, 5)
            oprot.writeI32(self.transactionPhase)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 6)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class OpportunityStageMetadata(object):
    """
    Attributes:
     - name
     - phase
     - status
     - stageUpdateTime
     - transactionPhase
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.I32, 'phase', None, None, ),  # 2
        (3, TType.I32, 'status', None, None, ),  # 3
        (4, TType.I64, 'stageUpdateTime', None, None, ),  # 4
        (5, TType.I32, 'transactionPhase', None, None, ),  # 5
    )
    def __init__(self, name=None, phase=None, status=None, stageUpdateTime=None, transactionPhase=None, ):
        self.name = name
        self.phase = phase
        self.status = status
        self.stageUpdateTime = stageUpdateTime
        self.transactionPhase = transactionPhase

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.phase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.stageUpdateTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.transactionPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('OpportunityStageMetadata')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.phase is not None:
            oprot.writeFieldBegin('phase', TType.I32, 2)
            oprot.writeI32(self.phase)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 3)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.stageUpdateTime is not None:
            oprot.writeFieldBegin('stageUpdateTime', TType.I64, 4)
            oprot.writeI64(self.stageUpdateTime)
            oprot.writeFieldEnd()
        if self.transactionPhase is not None:
            oprot.writeFieldBegin('transactionPhase', TType.I32, 5)
            oprot.writeI32(self.transactionPhase)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResourceHydratorConfigOptions(object):
    """
    Attributes:
     - forceResolveContacts
     - listingFoldersFullDetails
     - listingFoldersReferralAgentInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'forceResolveContacts', None, None, ),  # 1
        (2, TType.BOOL, 'listingFoldersFullDetails', None, None, ),  # 2
        (3, TType.BOOL, 'listingFoldersReferralAgentInfo', None, None, ),  # 3
    )
    def __init__(self, forceResolveContacts=None, listingFoldersFullDetails=None, listingFoldersReferralAgentInfo=None, ):
        self.forceResolveContacts = forceResolveContacts
        self.listingFoldersFullDetails = listingFoldersFullDetails
        self.listingFoldersReferralAgentInfo = listingFoldersReferralAgentInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.forceResolveContacts = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.listingFoldersFullDetails = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.listingFoldersReferralAgentInfo = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResourceHydratorConfigOptions')
        if self.forceResolveContacts is not None:
            oprot.writeFieldBegin('forceResolveContacts', TType.BOOL, 1)
            oprot.writeBool(self.forceResolveContacts)
            oprot.writeFieldEnd()
        if self.listingFoldersFullDetails is not None:
            oprot.writeFieldBegin('listingFoldersFullDetails', TType.BOOL, 2)
            oprot.writeBool(self.listingFoldersFullDetails)
            oprot.writeFieldEnd()
        if self.listingFoldersReferralAgentInfo is not None:
            oprot.writeFieldBegin('listingFoldersReferralAgentInfo', TType.BOOL, 3)
            oprot.writeBool(self.listingFoldersReferralAgentInfo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamMember(object):
    """
    Attributes:
     - personId
     - displayName
     - avatarUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'displayName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 3
    )
    def __init__(self, personId=None, displayName=None, avatarUrl=None, ):
        self.personId = personId
        self.displayName = displayName
        self.avatarUrl = avatarUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamMember')
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 1)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 2)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 3)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamMemberStatus(object):
    """
    Attributes:
     - isActive
     - isPrimary
     - canAccessTeamPermissions
     - hasDefaultAccess
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isActive', None, None, ),  # 1
        (2, TType.BOOL, 'isPrimary', None, None, ),  # 2
        (3, TType.BOOL, 'canAccessTeamPermissions', None, None, ),  # 3
        (4, TType.BOOL, 'hasDefaultAccess', None, None, ),  # 4
    )
    def __init__(self, isActive=None, isPrimary=None, canAccessTeamPermissions=None, hasDefaultAccess=None, ):
        self.isActive = isActive
        self.isPrimary = isPrimary
        self.canAccessTeamPermissions = canAccessTeamPermissions
        self.hasDefaultAccess = hasDefaultAccess

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isActive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isPrimary = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.canAccessTeamPermissions = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hasDefaultAccess = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamMemberStatus')
        if self.isActive is not None:
            oprot.writeFieldBegin('isActive', TType.BOOL, 1)
            oprot.writeBool(self.isActive)
            oprot.writeFieldEnd()
        if self.isPrimary is not None:
            oprot.writeFieldBegin('isPrimary', TType.BOOL, 2)
            oprot.writeBool(self.isPrimary)
            oprot.writeFieldEnd()
        if self.canAccessTeamPermissions is not None:
            oprot.writeFieldBegin('canAccessTeamPermissions', TType.BOOL, 3)
            oprot.writeBool(self.canAccessTeamPermissions)
            oprot.writeFieldEnd()
        if self.hasDefaultAccess is not None:
            oprot.writeFieldBegin('hasDefaultAccess', TType.BOOL, 4)
            oprot.writeBool(self.hasDefaultAccess)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealActivity(object):
    """
    Attributes:
     - favoriteFeed
     - viewFeed
     - interestFeed
     - commentFeed
     - emailFeed
     - tourRequestFeed
     - totalResults
     - metadata
     - sectionListingIds
     - errors
    """

    thrift_spec = (
        None,  # 0
        None,  # 1
        (2, TType.LIST, 'favoriteFeed', (TType.STRUCT, (ListingFeedItem, ListingFeedItem.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'viewFeed', (TType.STRUCT, (ListingFeedItem, ListingFeedItem.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'interestFeed', (TType.STRUCT, (ListingFeedItem, ListingFeedItem.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'commentFeed', (TType.STRUCT, (CommentFeedItem, CommentFeedItem.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'emailFeed', (TType.STRUCT, (EmailFeedItem, EmailFeedItem.thrift_spec), False), None, ),  # 6
        (7, TType.MAP, 'totalResults', (TType.I32, None, TType.I32, None, False), None, ),  # 7
        (8, TType.MAP, 'sectionListingIds', (TType.I32, None, TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 8
        (9, TType.LIST, 'tourRequestFeed', (TType.STRUCT, (ListingFeedItem, ListingFeedItem.thrift_spec), False), None, ),  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        (50, TType.STRUCT, 'metadata', (DealActivityMetadata, DealActivityMetadata.thrift_spec), None, ),  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.LIST, 'errors', (TType.STRUCT, (DealActivityError, DealActivityError.thrift_spec), False), None, ),  # 100
    )
    def __init__(self, favoriteFeed=None, viewFeed=None, interestFeed=None, commentFeed=None, emailFeed=None, totalResults=None, sectionListingIds=None, tourRequestFeed=None, metadata=None, errors=None, ):
        self.favoriteFeed = favoriteFeed
        self.viewFeed = viewFeed
        self.interestFeed = interestFeed
        self.commentFeed = commentFeed
        self.emailFeed = emailFeed
        self.totalResults = totalResults
        self.sectionListingIds = sectionListingIds
        self.tourRequestFeed = tourRequestFeed
        self.metadata = metadata
        self.errors = errors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 2:
                if ftype == TType.LIST:
                    self.favoriteFeed = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = ListingFeedItem()
                        _elem42.read(iprot)
                        self.favoriteFeed.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.viewFeed = []
                    (_etype44, _size47) = iprot.readListBegin()
                    for _i45 in range(_size47):
                        _elem46 = ListingFeedItem()
                        _elem46.read(iprot)
                        self.viewFeed.append(_elem46)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.interestFeed = []
                    (_etype48, _size51) = iprot.readListBegin()
                    for _i49 in range(_size51):
                        _elem50 = ListingFeedItem()
                        _elem50.read(iprot)
                        self.interestFeed.append(_elem50)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.commentFeed = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = CommentFeedItem()
                        _elem54.read(iprot)
                        self.commentFeed.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.emailFeed = []
                    (_etype56, _size59) = iprot.readListBegin()
                    for _i57 in range(_size59):
                        _elem58 = EmailFeedItem()
                        _elem58.read(iprot)
                        self.emailFeed.append(_elem58)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.MAP:
                    self.totalResults = {}
                    (_ktype61, _vtype62, _size65) = iprot.readMapBegin()
                    for _i60 in range(_size65):
                        _key63 = iprot.readI32()
                        _val64 = iprot.readI32()
                        self.totalResults[_key63] = _val64
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.sectionListingIds = {}
                    (_ktype67, _vtype68, _size71) = iprot.readMapBegin()
                    for _i66 in range(_size71):
                        _key69 = iprot.readI32()
                        _val70 = []
                        (_etype72, _size75) = iprot.readListBegin()
                        for _i73 in range(_size75):
                            _elem74 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val70.append(_elem74)
                        iprot.readListEnd()
                        self.sectionListingIds[_key69] = _val70
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.tourRequestFeed = []
                    (_etype76, _size79) = iprot.readListBegin()
                    for _i77 in range(_size79):
                        _elem78 = ListingFeedItem()
                        _elem78.read(iprot)
                        self.tourRequestFeed.append(_elem78)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.STRUCT:
                    self.metadata = DealActivityMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.LIST:
                    self.errors = []
                    (_etype80, _size83) = iprot.readListBegin()
                    for _i81 in range(_size83):
                        _elem82 = DealActivityError()
                        _elem82.read(iprot)
                        self.errors.append(_elem82)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealActivity')
        if self.favoriteFeed is not None:
            oprot.writeFieldBegin('favoriteFeed', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.favoriteFeed))
            for _iter84 in self.favoriteFeed:
                _iter84.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.viewFeed is not None:
            oprot.writeFieldBegin('viewFeed', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.viewFeed))
            for _iter85 in self.viewFeed:
                _iter85.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.interestFeed is not None:
            oprot.writeFieldBegin('interestFeed', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.interestFeed))
            for _iter86 in self.interestFeed:
                _iter86.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.commentFeed is not None:
            oprot.writeFieldBegin('commentFeed', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.commentFeed))
            for _iter87 in self.commentFeed:
                _iter87.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.emailFeed is not None:
            oprot.writeFieldBegin('emailFeed', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.emailFeed))
            for _iter88 in self.emailFeed:
                _iter88.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.MAP, 7)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.totalResults))
            for _kiter89, _viter90 in self.totalResults.items():
                oprot.writeI32(_kiter89)
                oprot.writeI32(_viter90)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.sectionListingIds is not None:
            oprot.writeFieldBegin('sectionListingIds', TType.MAP, 8)
            oprot.writeMapBegin(TType.I32, TType.LIST, len(self.sectionListingIds))
            for _kiter91, _viter92 in self.sectionListingIds.items():
                oprot.writeI32(_kiter91)
                oprot.writeListBegin(TType.STRING, len(_viter92))
                for _iter93 in _viter92:
                    oprot.writeString(_iter93.encode('utf-8') if sys.version_info[0] == 2 else _iter93)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.tourRequestFeed is not None:
            oprot.writeFieldBegin('tourRequestFeed', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.tourRequestFeed))
            for _iter94 in self.tourRequestFeed:
                _iter94.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 50)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.LIST, 100)
            oprot.writeListBegin(TType.STRUCT, len(self.errors))
            for _iter95 in self.errors:
                _iter95.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealAssetLibraryCollections(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealAssetLibraryCollection, DealAssetLibraryCollection.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype96, _size99) = iprot.readListBegin()
                    for _i97 in range(_size99):
                        _elem98 = DealAssetLibraryCollection()
                        _elem98.read(iprot)
                        self.data.append(_elem98)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealAssetLibraryCollections')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter100 in self.data:
                _iter100.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCmas(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealCma, DealCma.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype101, _size104) = iprot.readListBegin()
                    for _i102 in range(_size104):
                        _elem103 = DealCma()
                        _elem103.read(iprot)
                        self.data.append(_elem103)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCmas')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter105 in self.data:
                _iter105.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCollaborator(object):
    """
    Attributes:
     - id
     - role
     - source
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'role', None, None, ),  # 2
        (3, TType.STRUCT, 'source', (DealCollaboratorSource, DealCollaboratorSource.thrift_spec), None, ),  # 3
    )
    def __init__(self, id=None, role=None, source=None, ):
        self.id = id
        self.role = role
        self.source = source

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.role = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.source = DealCollaboratorSource()
                    self.source.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCollaborator')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.I32, 2)
            oprot.writeI32(self.role)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRUCT, 3)
            self.source.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCollections(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealCollection, DealCollection.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype106, _size109) = iprot.readListBegin()
                    for _i107 in range(_size109):
                        _elem108 = DealCollection()
                        _elem108.read(iprot)
                        self.data.append(_elem108)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCollections')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter110 in self.data:
                _iter110.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealContacts(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealContact, DealContact.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype111, _size114) = iprot.readListBegin()
                    for _i112 in range(_size114):
                        _elem113 = DealContact()
                        _elem113.read(iprot)
                        self.data.append(_elem113)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealContacts')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter115 in self.data:
                _iter115.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealDocument(object):
    """
    Attributes:
     - id
     - source
     - metadata
     - canvas
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'source', (DealDocumentSource, DealDocumentSource.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'metadata', (gen.urbancompass.docstore.ttypes.DocumentMetadata, gen.urbancompass.docstore.ttypes.DocumentMetadata.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'canvas', (gen.urbancompass.design_studio.models.ttypes.Canvas, gen.urbancompass.design_studio.models.ttypes.Canvas.thrift_spec), None, ),  # 4
    )
    def __init__(self, id=None, source=None, metadata=None, canvas=None, ):
        self.id = id
        self.source = source
        self.metadata = metadata
        self.canvas = canvas

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.source = DealDocumentSource()
                    self.source.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.metadata = gen.urbancompass.docstore.ttypes.DocumentMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.canvas = gen.urbancompass.design_studio.models.ttypes.Canvas()
                    self.canvas.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealDocument')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRUCT, 2)
            self.source.write(oprot)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 3)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.canvas is not None:
            oprot.writeFieldBegin('canvas', TType.STRUCT, 4)
            self.canvas.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealListing(object):
    """
    Attributes:
     - id
     - listing
     - insights
     - hasListing
     - address
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'listing', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'insights', (DealInsights, DealInsights.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'hasListing', None, None, ),  # 4
        (5, TType.STRING, 'address', 'UTF8', None, ),  # 5
    )
    def __init__(self, id=None, listing=None, insights=None, hasListing=None, address=None, ):
        self.id = id
        self.listing = listing
        self.insights = insights
        self.hasListing = hasListing
        self.address = address

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listing = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.insights = DealInsights()
                    self.insights.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hasListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealListing')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 2)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.insights is not None:
            oprot.writeFieldBegin('insights', TType.STRUCT, 3)
            self.insights.write(oprot)
            oprot.writeFieldEnd()
        if self.hasListing is not None:
            oprot.writeFieldBegin('hasListing', TType.BOOL, 4)
            oprot.writeBool(self.hasListing)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 5)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPermittedPerson(object):
    """
    Attributes:
     - personId
     - personDetails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'personDetails', (MinimalPersonDetails, MinimalPersonDetails.thrift_spec), None, ),  # 2
    )
    def __init__(self, personId=None, personDetails=None, ):
        self.personId = personId
        self.personDetails = personDetails

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.personDetails = MinimalPersonDetails()
                    self.personDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPermittedPerson')
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 1)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.personDetails is not None:
            oprot.writeFieldBegin('personDetails', TType.STRUCT, 2)
            self.personDetails.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPhotoIngestionProjects(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealPhotoIngestionProject, DealPhotoIngestionProject.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype116, _size119) = iprot.readListBegin()
                    for _i117 in range(_size119):
                        _elem118 = DealPhotoIngestionProject()
                        _elem118.read(iprot)
                        self.data.append(_elem118)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPhotoIngestionProjects')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter120 in self.data:
                _iter120.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealReferralInfo(object):
    """
    Attributes:
     - referredTo
     - referredBy
     - commission
     - referredDealSubType
     - referralAgentInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'commission', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 3
        (4, TType.I32, 'referredDealSubType', None, None, ),  # 4
        (5, TType.STRUCT, 'referralAgentInfo', (AgentInfo, AgentInfo.thrift_spec), None, ),  # 5
    )
    def __init__(self, referredTo=None, referredBy=None, commission=None, referredDealSubType=None, referralAgentInfo=None, ):
        self.referredTo = referredTo
        self.referredBy = referredBy
        self.commission = commission
        self.referredDealSubType = referredDealSubType
        self.referralAgentInfo = referralAgentInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.commission = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.commission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.referredDealSubType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.referralAgentInfo = AgentInfo()
                    self.referralAgentInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealReferralInfo')
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 1)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 2)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.commission is not None:
            oprot.writeFieldBegin('commission', TType.STRUCT, 3)
            self.commission.write(oprot)
            oprot.writeFieldEnd()
        if self.referredDealSubType is not None:
            oprot.writeFieldBegin('referredDealSubType', TType.I32, 4)
            oprot.writeI32(self.referredDealSubType)
            oprot.writeFieldEnd()
        if self.referralAgentInfo is not None:
            oprot.writeFieldBegin('referralAgentInfo', TType.STRUCT, 5)
            self.referralAgentInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealSavedSearches(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealSavedSearch, DealSavedSearch.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype121, _size124) = iprot.readListBegin()
                    for _i122 in range(_size124):
                        _elem123 = DealSavedSearch()
                        _elem123.read(iprot)
                        self.data.append(_elem123)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealSavedSearches')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter125 in self.data:
                _iter125.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealStats(object):
    """
    Attributes:
     - countsByType
     - statsByTransactionPhase
     - statsByStage
     - statsByDealType
     - totals
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'countsByType', (TType.I32, None, TType.I32, None, False), None, ),  # 1
        (2, TType.MAP, 'statsByTransactionPhase', (TType.I32, None, TType.STRUCT, (DealAggregates, DealAggregates.thrift_spec), False), None, ),  # 2
        (3, TType.MAP, 'statsByStage', (TType.STRING, 'UTF8', TType.STRUCT, (DealAggregates, DealAggregates.thrift_spec), False), None, ),  # 3
        (4, TType.MAP, 'statsByDealType', (TType.I32, None, TType.STRUCT, (DealAggregates, DealAggregates.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'totals', (DealAggregates, DealAggregates.thrift_spec), None, ),  # 5
    )
    def __init__(self, countsByType=None, statsByTransactionPhase=None, statsByStage=None, statsByDealType=None, totals=None, ):
        self.countsByType = countsByType
        self.statsByTransactionPhase = statsByTransactionPhase
        self.statsByStage = statsByStage
        self.statsByDealType = statsByDealType
        self.totals = totals

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.countsByType = {}
                    (_ktype127, _vtype128, _size131) = iprot.readMapBegin()
                    for _i126 in range(_size131):
                        _key129 = iprot.readI32()
                        _val130 = iprot.readI32()
                        self.countsByType[_key129] = _val130
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.statsByTransactionPhase = {}
                    (_ktype133, _vtype134, _size137) = iprot.readMapBegin()
                    for _i132 in range(_size137):
                        _key135 = iprot.readI32()
                        _val136 = DealAggregates()
                        _val136.read(iprot)
                        self.statsByTransactionPhase[_key135] = _val136
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.statsByStage = {}
                    (_ktype139, _vtype140, _size143) = iprot.readMapBegin()
                    for _i138 in range(_size143):
                        _key141 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val142 = DealAggregates()
                        _val142.read(iprot)
                        self.statsByStage[_key141] = _val142
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.statsByDealType = {}
                    (_ktype145, _vtype146, _size149) = iprot.readMapBegin()
                    for _i144 in range(_size149):
                        _key147 = iprot.readI32()
                        _val148 = DealAggregates()
                        _val148.read(iprot)
                        self.statsByDealType[_key147] = _val148
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.totals = DealAggregates()
                    self.totals.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealStats')
        if self.countsByType is not None:
            oprot.writeFieldBegin('countsByType', TType.MAP, 1)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.countsByType))
            for _kiter150, _viter151 in self.countsByType.items():
                oprot.writeI32(_kiter150)
                oprot.writeI32(_viter151)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.statsByTransactionPhase is not None:
            oprot.writeFieldBegin('statsByTransactionPhase', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.statsByTransactionPhase))
            for _kiter152, _viter153 in self.statsByTransactionPhase.items():
                oprot.writeI32(_kiter152)
                _viter153.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.statsByStage is not None:
            oprot.writeFieldBegin('statsByStage', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.statsByStage))
            for _kiter154, _viter155 in self.statsByStage.items():
                oprot.writeString(_kiter154.encode('utf-8') if sys.version_info[0] == 2 else _kiter154)
                _viter155.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.statsByDealType is not None:
            oprot.writeFieldBegin('statsByDealType', TType.MAP, 4)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.statsByDealType))
            for _kiter156, _viter157 in self.statsByDealType.items():
                oprot.writeI32(_kiter156)
                _viter157.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.totals is not None:
            oprot.writeFieldBegin('totals', TType.STRUCT, 5)
            self.totals.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealTasks(object):
    """
    Attributes:
     - data
     - total
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealTask, DealTask.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'total', None, None, ),  # 2
    )
    def __init__(self, data=None, total=None, ):
        self.data = data
        self.total = total

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype158, _size161) = iprot.readListBegin()
                    for _i159 in range(_size161):
                        _elem160 = DealTask()
                        _elem160.read(iprot)
                        self.data.append(_elem160)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.total = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealTasks')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter162 in self.data:
                _iter162.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.I32, 2)
            oprot.writeI32(self.total)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealToursheets(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealToursheet, DealToursheet.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype163, _size166) = iprot.readListBegin()
                    for _i164 in range(_size166):
                        _elem165 = DealToursheet()
                        _elem165.read(iprot)
                        self.data.append(_elem165)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealToursheets')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter167 in self.data:
                _iter167.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class OpportunityWorkflow(object):
    """
    Attributes:
     - dealType
     - stages
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'dealType', None, None, ),  # 1
        (2, TType.LIST, 'stages', (TType.STRUCT, (OpportunityStage, OpportunityStage.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, dealType=None, stages=None, ):
        self.dealType = dealType
        self.stages = stages

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.stages = []
                    (_etype168, _size171) = iprot.readListBegin()
                    for _i169 in range(_size171):
                        _elem170 = OpportunityStage()
                        _elem170.read(iprot)
                        self.stages.append(_elem170)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('OpportunityWorkflow')
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 1)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.stages is not None:
            oprot.writeFieldBegin('stages', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.stages))
            for _iter172 in self.stages:
                _iter172.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Team(object):
    """
    Attributes:
     - id
     - teamName
     - avatarUrl
     - members
     - geography
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'teamName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'members', (TType.STRUCT, (TeamMember, TeamMember.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'geography', 'UTF8', None, ),  # 5
    )
    def __init__(self, id=None, teamName=None, avatarUrl=None, members=None, geography=None, ):
        self.id = id
        self.teamName = teamName
        self.avatarUrl = avatarUrl
        self.members = members
        self.geography = geography

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.teamName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.members = []
                    (_etype173, _size176) = iprot.readListBegin()
                    for _i174 in range(_size176):
                        _elem175 = TeamMember()
                        _elem175.read(iprot)
                        self.members.append(_elem175)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.geography = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Team')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.teamName is not None:
            oprot.writeFieldBegin('teamName', TType.STRING, 2)
            oprot.writeString(self.teamName.encode('utf-8') if sys.version_info[0] == 2 else self.teamName)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 3)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.members is not None:
            oprot.writeFieldBegin('members', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.members))
            for _iter177 in self.members:
                _iter177.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.geography is not None:
            oprot.writeFieldBegin('geography', TType.STRING, 5)
            oprot.writeString(self.geography.encode('utf-8') if sys.version_info[0] == 2 else self.geography)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCollaborators(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealCollaborator, DealCollaborator.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype178, _size181) = iprot.readListBegin()
                    for _i179 in range(_size181):
                        _elem180 = DealCollaborator()
                        _elem180.read(iprot)
                        self.data.append(_elem180)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCollaborators')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter182 in self.data:
                _iter182.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealDocuments(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealDocument, DealDocument.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype183, _size186) = iprot.readListBegin()
                    for _i184 in range(_size186):
                        _elem185 = DealDocument()
                        _elem185.read(iprot)
                        self.data.append(_elem185)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealDocuments')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter187 in self.data:
                _iter187.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealListingFolder(object):
    """
    Attributes:
     - id
     - listingFolder
     - listingId
     - address
     - createEmptyFolder
     - referralInfo
     - listing
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'listingFolder', (gen.urbancompass.inventory_apps.folder.external.folder_service_ext.ttypes.DealListingFolderExt, gen.urbancompass.inventory_apps.folder.external.folder_service_ext.ttypes.DealListingFolderExt.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'listingId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'address', (gen.urbancompass.inventory_apps.folder.folder_service_common.ttypes.FolderAddress, gen.urbancompass.inventory_apps.folder.folder_service_common.ttypes.FolderAddress.thrift_spec), None, ),  # 4
        (5, TType.BOOL, 'createEmptyFolder', None, None, ),  # 5
        (6, TType.STRUCT, 'listing', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'referralInfo', (DealReferralInfo, DealReferralInfo.thrift_spec), None, ),  # 7
    )
    def __init__(self, id=None, listingFolder=None, listingId=None, address=None, createEmptyFolder=None, listing=None, referralInfo=None, ):
        self.id = id
        self.listingFolder = listingFolder
        self.listingId = listingId
        self.address = address
        self.createEmptyFolder = createEmptyFolder
        self.listing = listing
        self.referralInfo = referralInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listingFolder = gen.urbancompass.inventory_apps.folder.external.folder_service_ext.ttypes.DealListingFolderExt()
                    self.listingFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.address = gen.urbancompass.inventory_apps.folder.folder_service_common.ttypes.FolderAddress()
                    self.address.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.createEmptyFolder = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.listing = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.referralInfo = DealReferralInfo()
                    self.referralInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealListingFolder')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.listingFolder is not None:
            oprot.writeFieldBegin('listingFolder', TType.STRUCT, 2)
            self.listingFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 3)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRUCT, 4)
            self.address.write(oprot)
            oprot.writeFieldEnd()
        if self.createEmptyFolder is not None:
            oprot.writeFieldBegin('createEmptyFolder', TType.BOOL, 5)
            oprot.writeBool(self.createEmptyFolder)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 6)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.referralInfo is not None:
            oprot.writeFieldBegin('referralInfo', TType.STRUCT, 7)
            self.referralInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealListings(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealListing, DealListing.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype188, _size191) = iprot.readListBegin()
                    for _i189 in range(_size191):
                        _elem190 = DealListing()
                        _elem190.read(iprot)
                        self.data.append(_elem190)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealListings')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter192 in self.data:
                _iter192.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamMemberData(object):
    """
    Attributes:
     - status
     - team
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (TeamMemberStatus, TeamMemberStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'team', (Team, Team.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, team=None, ):
        self.status = status
        self.team = team

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = TeamMemberStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.team = Team()
                    self.team.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamMemberData')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRUCT, 2)
            self.team.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealAttachment(object):
    """
    Attributes:
     - collaborator
     - collection
     - document
     - insights
     - listing
     - savedSearch
     - toursheet
     - contact
     - cma
     - listingFolder
     - fileStorage
     - assetLibraryCollection
     - photoIngestionProject
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'collaborator', (DealCollaborator, DealCollaborator.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'collection', (DealCollection, DealCollection.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'document', (DealDocument, DealDocument.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'insights', (gen.urbancompass.bi.dashboard.data.dashboard.ttypes.Dashboard, gen.urbancompass.bi.dashboard.data.dashboard.ttypes.Dashboard.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'listing', (DealListing, DealListing.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'savedSearch', (DealSavedSearch, DealSavedSearch.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'toursheet', (DealToursheet, DealToursheet.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'contact', (DealContact, DealContact.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'cma', (DealCma, DealCma.thrift_spec), None, ),  # 9
        (10, TType.STRUCT, 'listingFolder', (DealListingFolder, DealListingFolder.thrift_spec), None, ),  # 10
        (11, TType.STRUCT, 'fileStorage', (DealFileStorage, DealFileStorage.thrift_spec), None, ),  # 11
        (12, TType.STRUCT, 'assetLibraryCollection', (DealAssetLibraryCollection, DealAssetLibraryCollection.thrift_spec), None, ),  # 12
        (13, TType.STRUCT, 'photoIngestionProject', (DealPhotoIngestionProject, DealPhotoIngestionProject.thrift_spec), None, ),  # 13
    )
    def __init__(self, collaborator=None, collection=None, document=None, insights=None, listing=None, savedSearch=None, toursheet=None, contact=None, cma=None, listingFolder=None, fileStorage=None, assetLibraryCollection=None, photoIngestionProject=None, ):
        self.collaborator = collaborator
        self.collection = collection
        self.document = document
        self.insights = insights
        self.listing = listing
        self.savedSearch = savedSearch
        self.toursheet = toursheet
        self.contact = contact
        self.cma = cma
        self.listingFolder = listingFolder
        self.fileStorage = fileStorage
        self.assetLibraryCollection = assetLibraryCollection
        self.photoIngestionProject = photoIngestionProject

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.collaborator = DealCollaborator()
                    self.collaborator.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.collection = DealCollection()
                    self.collection.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.document = DealDocument()
                    self.document.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.insights = gen.urbancompass.bi.dashboard.data.dashboard.ttypes.Dashboard()
                    self.insights.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.listing = DealListing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.savedSearch = DealSavedSearch()
                    self.savedSearch.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.toursheet = DealToursheet()
                    self.toursheet.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.contact = DealContact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.cma = DealCma()
                    self.cma.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.listingFolder = DealListingFolder()
                    self.listingFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.fileStorage = DealFileStorage()
                    self.fileStorage.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.assetLibraryCollection = DealAssetLibraryCollection()
                    self.assetLibraryCollection.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.photoIngestionProject = DealPhotoIngestionProject()
                    self.photoIngestionProject.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealAttachment')
        if self.collaborator is not None:
            oprot.writeFieldBegin('collaborator', TType.STRUCT, 1)
            self.collaborator.write(oprot)
            oprot.writeFieldEnd()
        if self.collection is not None:
            oprot.writeFieldBegin('collection', TType.STRUCT, 2)
            self.collection.write(oprot)
            oprot.writeFieldEnd()
        if self.document is not None:
            oprot.writeFieldBegin('document', TType.STRUCT, 3)
            self.document.write(oprot)
            oprot.writeFieldEnd()
        if self.insights is not None:
            oprot.writeFieldBegin('insights', TType.STRUCT, 4)
            self.insights.write(oprot)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 5)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.savedSearch is not None:
            oprot.writeFieldBegin('savedSearch', TType.STRUCT, 6)
            self.savedSearch.write(oprot)
            oprot.writeFieldEnd()
        if self.toursheet is not None:
            oprot.writeFieldBegin('toursheet', TType.STRUCT, 7)
            self.toursheet.write(oprot)
            oprot.writeFieldEnd()
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 8)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        if self.cma is not None:
            oprot.writeFieldBegin('cma', TType.STRUCT, 9)
            self.cma.write(oprot)
            oprot.writeFieldEnd()
        if self.listingFolder is not None:
            oprot.writeFieldBegin('listingFolder', TType.STRUCT, 10)
            self.listingFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.fileStorage is not None:
            oprot.writeFieldBegin('fileStorage', TType.STRUCT, 11)
            self.fileStorage.write(oprot)
            oprot.writeFieldEnd()
        if self.assetLibraryCollection is not None:
            oprot.writeFieldBegin('assetLibraryCollection', TType.STRUCT, 12)
            self.assetLibraryCollection.write(oprot)
            oprot.writeFieldEnd()
        if self.photoIngestionProject is not None:
            oprot.writeFieldBegin('photoIngestionProject', TType.STRUCT, 13)
            self.photoIngestionProject.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealListingFolders(object):
    """
    Attributes:
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'data', (TType.STRUCT, (DealListingFolder, DealListingFolder.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, data=None, ):
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype193, _size196) = iprot.readListBegin()
                    for _i194 in range(_size196):
                        _elem195 = DealListingFolder()
                        _elem195.read(iprot)
                        self.data.append(_elem195)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealListingFolders')
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter197 in self.data:
                _iter197.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
