
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CITY_CLUSTER_ZOOM = 11
DEFAULT_CENTER_LATITUDE = 33.754406
DEFAULT_CENTER_LONGITUDE = -84.389771
DEFAULT_ZOOM = 12
FULL_DISPLAY_NAME = "Atlanta"
GEO_ID = "atlanta"
MAX_ZOOM = 19
MIN_ZOOM = 10
NEIGHBORHOOD_CLUSTER_ZOOM = 13
# else
SHORT_DISPLAY_NAME = "Atlanta"
# else
