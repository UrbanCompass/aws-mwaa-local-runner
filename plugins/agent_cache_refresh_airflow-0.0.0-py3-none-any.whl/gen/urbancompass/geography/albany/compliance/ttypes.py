
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class COMPLIANCE_TYPES(object):
    BASE = 0
    NO_ADDRESS_FOR_LOGGED_OUT_USER = 1
    VOW = 2

    _VALUES_TO_NAMES = {
        0: "BASE",
        1: "NO_ADDRESS_FOR_LOGGED_OUT_USER",
        2: "VOW",
    }

    _NAMES_TO_VALUES = {
        "BASE": 0,
        "NO_ADDRESS_FOR_LOGGED_OUT_USER": 1,
        "VOW": 2,
    }

