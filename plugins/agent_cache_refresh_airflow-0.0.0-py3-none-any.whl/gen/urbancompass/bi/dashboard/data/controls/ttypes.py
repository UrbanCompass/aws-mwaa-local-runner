
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.series_ref.ttypes

from thrift.transport import TTransport


class Category(object):
    """
    Attributes:
     - categoryNameRef
     - valuesRef
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'categoryNameRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'valuesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
    )
    def __init__(self, categoryNameRef=None, valuesRef=None, ):
        self.categoryNameRef = categoryNameRef
        self.valuesRef = valuesRef

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.categoryNameRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.categoryNameRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.valuesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.valuesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Category')
        if self.categoryNameRef is not None:
            oprot.writeFieldBegin('categoryNameRef', TType.STRUCT, 1)
            self.categoryNameRef.write(oprot)
            oprot.writeFieldEnd()
        if self.valuesRef is not None:
            oprot.writeFieldBegin('valuesRef', TType.STRUCT, 2)
            self.valuesRef.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CategorizedDropdown(object):
    """
    Attributes:
     - categories
     - nameRef
     - config
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'categories', (TType.STRUCT, (Category, Category.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'config', (gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes.CategorizedDropdownConfig, gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes.CategorizedDropdownConfig.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'nameRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 3
    )
    def __init__(self, categories=None, config=None, nameRef=None, ):
        self.categories = categories
        self.config = config
        self.nameRef = nameRef

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.categories = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = Category()
                        _elem4.read(iprot)
                        self.categories.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.config = gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes.CategorizedDropdownConfig()
                    self.config.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.nameRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.nameRef.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CategorizedDropdown')
        if self.categories is not None:
            oprot.writeFieldBegin('categories', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.categories))
            for _iter6 in self.categories:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.config is not None:
            oprot.writeFieldBegin('config', TType.STRUCT, 2)
            self.config.write(oprot)
            oprot.writeFieldEnd()
        if self.nameRef is not None:
            oprot.writeFieldBegin('nameRef', TType.STRUCT, 3)
            self.nameRef.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TwoLevelCategorizedDropdown(object):
    """
    Attributes:
     - categorizedDropdowns
     - config
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'categorizedDropdowns', (TType.STRUCT, (CategorizedDropdown, CategorizedDropdown.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'config', (gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes.TwoLevelCategorizedDropdownConfig, gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes.TwoLevelCategorizedDropdownConfig.thrift_spec), None, ),  # 2
    )
    def __init__(self, categorizedDropdowns=None, config=None, ):
        self.categorizedDropdowns = categorizedDropdowns
        self.config = config

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.categorizedDropdowns = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = CategorizedDropdown()
                        _elem9.read(iprot)
                        self.categorizedDropdowns.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.config = gen.urbancompass.bi.dashboard.data.backend_models.controls_config.ttypes.TwoLevelCategorizedDropdownConfig()
                    self.config.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TwoLevelCategorizedDropdown')
        if self.categorizedDropdowns is not None:
            oprot.writeFieldBegin('categorizedDropdowns', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.categorizedDropdowns))
            for _iter11 in self.categorizedDropdowns:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.config is not None:
            oprot.writeFieldBegin('config', TType.STRUCT, 2)
            self.config.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ControlType(object):
    """
    Attributes:
     - categorizedDropdown
     - twoLevelCategorizedDropdown
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'categorizedDropdown', (CategorizedDropdown, CategorizedDropdown.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'twoLevelCategorizedDropdown', (TwoLevelCategorizedDropdown, TwoLevelCategorizedDropdown.thrift_spec), None, ),  # 2
    )
    def __init__(self, categorizedDropdown=None, twoLevelCategorizedDropdown=None, ):
        self.categorizedDropdown = categorizedDropdown
        self.twoLevelCategorizedDropdown = twoLevelCategorizedDropdown

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.categorizedDropdown = CategorizedDropdown()
                    self.categorizedDropdown.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.twoLevelCategorizedDropdown = TwoLevelCategorizedDropdown()
                    self.twoLevelCategorizedDropdown.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ControlType')
        if self.categorizedDropdown is not None:
            oprot.writeFieldBegin('categorizedDropdown', TType.STRUCT, 1)
            self.categorizedDropdown.write(oprot)
            oprot.writeFieldEnd()
        if self.twoLevelCategorizedDropdown is not None:
            oprot.writeFieldBegin('twoLevelCategorizedDropdown', TType.STRUCT, 2)
            self.twoLevelCategorizedDropdown.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Control(object):
    """
    Attributes:
     - name
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'type', (ControlType, ControlType.thrift_spec), None, ),  # 2
    )
    def __init__(self, name=None, type=None, ):
        self.name = name
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.type = ControlType()
                    self.type.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Control')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRUCT, 2)
            self.type.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
