
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes

from thrift.transport import TTransport


class DealSide(object):
    SELLER = 0
    BUYER = 1
    TENANT = 2
    LANDLORD = 3

    _VALUES_TO_NAMES = {
        0: "SELLER",
        1: "BUYER",
        2: "TENANT",
        3: "LANDLORD",
    }

    _NAMES_TO_VALUES = {
        "SELLER": 0,
        "BUYER": 1,
        "TENANT": 2,
        "LANDLORD": 3,
    }


class DealType(object):
    SALE = 0
    RENTAL = 1
    REFERRAL = 2

    _VALUES_TO_NAMES = {
        0: "SALE",
        1: "RENTAL",
        2: "REFERRAL",
    }

    _NAMES_TO_VALUES = {
        "SALE": 0,
        "RENTAL": 1,
        "REFERRAL": 2,
    }


class DebugDealStatus(object):
    DEAL_NOT_IN_DEAL_TABLE = 0
    DEAL_IS_INVALID = 1
    VENDOR_NOT_IN_VENDOR_TABLE = 2
    VENDOR_IS_INVALID = 3
    DEAL_NOT_IN_MANUAL_PATCHED_VIEW = 4
    DEAL_NOT_IN_DEAL_SUMMARY_VIEW = 5
    NOT_IN_AUTHORIZATION_VIEW = 6
    NO_ISSUE_DETECTED = 7

    _VALUES_TO_NAMES = {
        0: "DEAL_NOT_IN_DEAL_TABLE",
        1: "DEAL_IS_INVALID",
        2: "VENDOR_NOT_IN_VENDOR_TABLE",
        3: "VENDOR_IS_INVALID",
        4: "DEAL_NOT_IN_MANUAL_PATCHED_VIEW",
        5: "DEAL_NOT_IN_DEAL_SUMMARY_VIEW",
        6: "NOT_IN_AUTHORIZATION_VIEW",
        7: "NO_ISSUE_DETECTED",
    }

    _NAMES_TO_VALUES = {
        "DEAL_NOT_IN_DEAL_TABLE": 0,
        "DEAL_IS_INVALID": 1,
        "VENDOR_NOT_IN_VENDOR_TABLE": 2,
        "VENDOR_IS_INVALID": 3,
        "DEAL_NOT_IN_MANUAL_PATCHED_VIEW": 4,
        "DEAL_NOT_IN_DEAL_SUMMARY_VIEW": 5,
        "NOT_IN_AUTHORIZATION_VIEW": 6,
        "NO_ISSUE_DETECTED": 7,
    }


class EntityType(object):
    VENDOR = 0

    _VALUES_TO_NAMES = {
        0: "VENDOR",
    }

    _NAMES_TO_VALUES = {
        "VENDOR": 0,
    }


class FilterField(object):
    YEAR = 0
    TEAM_MEMBERS = 1
    DEAL_TYPE = 2
    QUARTERS = 3
    OVER_YEAR = 4
    TEAM = 5
    CUSTOM_DATE = 6
    LISTING_ADDRESS = 7
    DEAL_STATUS = 8
    DEAL_ID = 9

    _VALUES_TO_NAMES = {
        0: "YEAR",
        1: "TEAM_MEMBERS",
        2: "DEAL_TYPE",
        3: "QUARTERS",
        4: "OVER_YEAR",
        5: "TEAM",
        6: "CUSTOM_DATE",
        7: "LISTING_ADDRESS",
        8: "DEAL_STATUS",
        9: "DEAL_ID",
    }

    _NAMES_TO_VALUES = {
        "YEAR": 0,
        "TEAM_MEMBERS": 1,
        "DEAL_TYPE": 2,
        "QUARTERS": 3,
        "OVER_YEAR": 4,
        "TEAM": 5,
        "CUSTOM_DATE": 6,
        "LISTING_ADDRESS": 7,
        "DEAL_STATUS": 8,
        "DEAL_ID": 9,
    }


class ParityCheckType(object):
    TRANSACTION = 0
    DEAL = 1
    ACCOUNT = 2
    AGENT_ROLE = 3
    CONTACT = 4

    _VALUES_TO_NAMES = {
        0: "TRANSACTION",
        1: "DEAL",
        2: "ACCOUNT",
        3: "AGENT_ROLE",
        4: "CONTACT",
    }

    _NAMES_TO_VALUES = {
        "TRANSACTION": 0,
        "DEAL": 1,
        "ACCOUNT": 2,
        "AGENT_ROLE": 3,
        "CONTACT": 4,
    }


class PropertyType(object):
    REFERRAL = 0
    RENTAL_COMMERICAL = 1
    RENTAL_RESIDENTAL = 2
    SALE_COOP = 3
    SALE_COMMERCIAL = 4
    SALE_CONDO = 5
    SALE_SINGLE_FAMILY = 6
    SALE_MULTI_FAMILY = 7
    SALE_LAND = 8
    SALE_MOBILE_HOME = 9
    SALE_TOWNHOUSE = 10

    _VALUES_TO_NAMES = {
        0: "REFERRAL",
        1: "RENTAL_COMMERICAL",
        2: "RENTAL_RESIDENTAL",
        3: "SALE_COOP",
        4: "SALE_COMMERCIAL",
        5: "SALE_CONDO",
        6: "SALE_SINGLE_FAMILY",
        7: "SALE_MULTI_FAMILY",
        8: "SALE_LAND",
        9: "SALE_MOBILE_HOME",
        10: "SALE_TOWNHOUSE",
    }

    _NAMES_TO_VALUES = {
        "REFERRAL": 0,
        "RENTAL_COMMERICAL": 1,
        "RENTAL_RESIDENTAL": 2,
        "SALE_COOP": 3,
        "SALE_COMMERCIAL": 4,
        "SALE_CONDO": 5,
        "SALE_SINGLE_FAMILY": 6,
        "SALE_MULTI_FAMILY": 7,
        "SALE_LAND": 8,
        "SALE_MOBILE_HOME": 9,
        "SALE_TOWNHOUSE": 10,
    }


class Role(object):
    ADMIN = 0

    _VALUES_TO_NAMES = {
        0: "ADMIN",
    }

    _NAMES_TO_VALUES = {
        "ADMIN": 0,
    }


class SortField(object):
    CLOSE_DATE = 0
    CLOSE_PRICE = 1
    GCI = 2
    COMMISSION_PERCENTAGE = 3
    PROPERTY_TYPE = 4
    DEAL_TYPE = 5
    NUMBER_OF_TRANSACTIONS = 6
    AVERAGE_SALES_VOLUME = 7
    NET_COMMISSION = 8

    _VALUES_TO_NAMES = {
        0: "CLOSE_DATE",
        1: "CLOSE_PRICE",
        2: "GCI",
        3: "COMMISSION_PERCENTAGE",
        4: "PROPERTY_TYPE",
        5: "DEAL_TYPE",
        6: "NUMBER_OF_TRANSACTIONS",
        7: "AVERAGE_SALES_VOLUME",
        8: "NET_COMMISSION",
    }

    _NAMES_TO_VALUES = {
        "CLOSE_DATE": 0,
        "CLOSE_PRICE": 1,
        "GCI": 2,
        "COMMISSION_PERCENTAGE": 3,
        "PROPERTY_TYPE": 4,
        "DEAL_TYPE": 5,
        "NUMBER_OF_TRANSACTIONS": 6,
        "AVERAGE_SALES_VOLUME": 7,
        "NET_COMMISSION": 8,
    }


class SortOrder(object):
    ASCENDING = 0
    DESCENDING = 1

    _VALUES_TO_NAMES = {
        0: "ASCENDING",
        1: "DESCENDING",
    }

    _NAMES_TO_VALUES = {
        "ASCENDING": 0,
        "DESCENDING": 1,
    }


class TeamDataAccessLevel(object):
    ALLOWED = 0
    NOT_ALLOWED = 1

    _VALUES_TO_NAMES = {
        0: "ALLOWED",
        1: "NOT_ALLOWED",
    }

    _NAMES_TO_VALUES = {
        "ALLOWED": 0,
        "NOT_ALLOWED": 1,
    }


class TeamMemberStatus(object):
    AGENT = 0
    SEPARATED = 1

    _VALUES_TO_NAMES = {
        0: "AGENT",
        1: "SEPARATED",
    }

    _NAMES_TO_VALUES = {
        "AGENT": 0,
        "SEPARATED": 1,
    }


class TeamRole(object):
    AGENT = 0
    PRINCIPAL = 1
    UNLICENSED = 2

    _VALUES_TO_NAMES = {
        0: "AGENT",
        1: "PRINCIPAL",
        2: "UNLICENSED",
    }

    _NAMES_TO_VALUES = {
        "AGENT": 0,
        "PRINCIPAL": 1,
        "UNLICENSED": 2,
    }


class TransactionType(object):
    INVOICE = 0
    VENDOR_BILL = 1
    VENDOR_PAYMENT = 2
    VENDOR_CREDIT = 3
    CREDIT_MEMO = 4
    OTHER = 5

    _VALUES_TO_NAMES = {
        0: "INVOICE",
        1: "VENDOR_BILL",
        2: "VENDOR_PAYMENT",
        3: "VENDOR_CREDIT",
        4: "CREDIT_MEMO",
        5: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "INVOICE": 0,
        "VENDOR_BILL": 1,
        "VENDOR_PAYMENT": 2,
        "VENDOR_CREDIT": 3,
        "CREDIT_MEMO": 4,
        "OTHER": 5,
    }


class TruncatableTable(object):
    CONTACT = 0
    AGENT_ROLE = 1
    ACCOUNT = 2

    _VALUES_TO_NAMES = {
        0: "CONTACT",
        1: "AGENT_ROLE",
        2: "ACCOUNT",
    }

    _NAMES_TO_VALUES = {
        "CONTACT": 0,
        "AGENT_ROLE": 1,
        "ACCOUNT": 2,
    }


class DealCommission(object):
    """
    Attributes:
     - afcUserId
     - firstName
     - lastName
     - displayName
     - netCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        None,  # 2
        None,  # 3
        None,  # 4
        (5, TType.STRING, 'firstName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'lastName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'displayName', 'UTF8', None, ),  # 7
        (8, TType.DOUBLE, 'netCommission', None, None, ),  # 8
    )
    def __init__(self, afcUserId=None, firstName=None, lastName=None, displayName=None, netCommission=None, ):
        self.afcUserId = afcUserId
        self.firstName = firstName
        self.lastName = lastName
        self.displayName = displayName
        self.netCommission = netCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.DOUBLE:
                    self.netCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCommission')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 5)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 6)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 7)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.DOUBLE, 8)
            oprot.writeDouble(self.netCommission)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPeriodData(object):
    """
    Attributes:
     - periodData
     - cumulative
     - periodDataPercentChange
     - cumulativePercentChange
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'periodData', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'cumulative', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'periodDataPercentChange', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.STRING, 'cumulativePercentChange', 'UTF8', None, ),  # 4
    )
    def __init__(self, periodData=None, cumulative=None, periodDataPercentChange=None, cumulativePercentChange=None, ):
        self.periodData = periodData
        self.cumulative = cumulative
        self.periodDataPercentChange = periodDataPercentChange
        self.cumulativePercentChange = cumulativePercentChange

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.periodData = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.periodData.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.cumulative = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.periodDataPercentChange = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.periodDataPercentChange.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.cumulativePercentChange = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPeriodData')
        if self.periodData is not None:
            oprot.writeFieldBegin('periodData', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.periodData))
            for _iter10 in self.periodData:
                oprot.writeString(_iter10.encode('utf-8') if sys.version_info[0] == 2 else _iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.cumulative is not None:
            oprot.writeFieldBegin('cumulative', TType.STRING, 2)
            oprot.writeString(self.cumulative.encode('utf-8') if sys.version_info[0] == 2 else self.cumulative)
            oprot.writeFieldEnd()
        if self.periodDataPercentChange is not None:
            oprot.writeFieldBegin('periodDataPercentChange', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.periodDataPercentChange))
            for _iter11 in self.periodDataPercentChange:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.cumulativePercentChange is not None:
            oprot.writeFieldBegin('cumulativePercentChange', TType.STRING, 4)
            oprot.writeString(self.cumulativePercentChange.encode('utf-8') if sys.version_info[0] == 2 else self.cumulativePercentChange)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealsSummaryEntry(object):
    """
    Attributes:
     - summaryStartTime
     - summaryEndTime
     - numberOfDeals
     - volume
     - grossCommission
     - grossCommissionPercent
     - avgGrossCommission
     - avgGrossCommissionPercent
     - netCommission
     - netCommissionPercent
     - avgNetCommission
     - avgNetCommissionPercent
     - currency
     - numberOfPurchases
     - numberOfSales
     - numberOfRentals
     - numberOfReferrals
     - changeInNumberOfDeals
     - changeInNumberOfDealsPercent
     - changeInVolume
     - changeInVolumePercent
     - changeInGrossCommission
     - changeInGrossCommissionPercent
     - changeInNetCommission
     - changeInNetCommissionPercent
     - changeInNumberOfPurchases
     - changeInNumberOfPurchasesPercent
     - changeInNumberOfSales
     - changeInNumberOfSalesPercent
     - changeInNumberOfRentals
     - changeInNumberOfRentalsPercent
     - changeInNumberOfReferrals
     - changeInNumberOfReferralsPercent
     - quarter
     - year
     - changeInAvgGrossCommission
     - changeInAvgGrossCommissionPercent
     - changeInAvgNetCommission
     - changeInAvgNetCommissionPercent
     - purchasesPercent
     - salesPercent
     - rentalsPercent
     - referralsPercent
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'summaryStartTime', None, None, ),  # 1
        (2, TType.I64, 'summaryEndTime', None, None, ),  # 2
        (3, TType.STRING, 'numberOfDeals', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'volume', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'grossCommission', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'grossCommissionPercent', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'avgGrossCommission', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'avgGrossCommissionPercent', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'netCommission', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'netCommissionPercent', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'avgNetCommission', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'avgNetCommissionPercent', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'currency', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'numberOfPurchases', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'numberOfSales', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'numberOfRentals', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'numberOfReferrals', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'changeInNumberOfDeals', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'changeInNumberOfDealsPercent', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'changeInVolume', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'changeInVolumePercent', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'changeInGrossCommission', 'UTF8', None, ),  # 22
        (23, TType.STRING, 'changeInGrossCommissionPercent', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'changeInNetCommission', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'changeInNetCommissionPercent', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'changeInNumberOfPurchases', 'UTF8', None, ),  # 26
        (27, TType.STRING, 'changeInNumberOfPurchasesPercent', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'changeInNumberOfSales', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'changeInNumberOfSalesPercent', 'UTF8', None, ),  # 29
        (30, TType.STRING, 'changeInNumberOfRentals', 'UTF8', None, ),  # 30
        (31, TType.STRING, 'changeInNumberOfRentalsPercent', 'UTF8', None, ),  # 31
        (32, TType.STRING, 'changeInNumberOfReferrals', 'UTF8', None, ),  # 32
        (33, TType.STRING, 'changeInNumberOfReferralsPercent', 'UTF8', None, ),  # 33
        (34, TType.STRING, 'quarter', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'year', 'UTF8', None, ),  # 35
        (36, TType.STRING, 'changeInAvgGrossCommission', 'UTF8', None, ),  # 36
        (37, TType.STRING, 'changeInAvgGrossCommissionPercent', 'UTF8', None, ),  # 37
        (38, TType.STRING, 'changeInAvgNetCommission', 'UTF8', None, ),  # 38
        (39, TType.STRING, 'changeInAvgNetCommissionPercent', 'UTF8', None, ),  # 39
        (40, TType.STRING, 'purchasesPercent', 'UTF8', None, ),  # 40
        (41, TType.STRING, 'salesPercent', 'UTF8', None, ),  # 41
        (42, TType.STRING, 'rentalsPercent', 'UTF8', None, ),  # 42
        (43, TType.STRING, 'referralsPercent', 'UTF8', None, ),  # 43
    )
    def __init__(self, summaryStartTime=None, summaryEndTime=None, numberOfDeals=None, volume=None, grossCommission=None, grossCommissionPercent=None, avgGrossCommission=None, avgGrossCommissionPercent=None, netCommission=None, netCommissionPercent=None, avgNetCommission=None, avgNetCommissionPercent=None, currency=None, numberOfPurchases=None, numberOfSales=None, numberOfRentals=None, numberOfReferrals=None, changeInNumberOfDeals=None, changeInNumberOfDealsPercent=None, changeInVolume=None, changeInVolumePercent=None, changeInGrossCommission=None, changeInGrossCommissionPercent=None, changeInNetCommission=None, changeInNetCommissionPercent=None, changeInNumberOfPurchases=None, changeInNumberOfPurchasesPercent=None, changeInNumberOfSales=None, changeInNumberOfSalesPercent=None, changeInNumberOfRentals=None, changeInNumberOfRentalsPercent=None, changeInNumberOfReferrals=None, changeInNumberOfReferralsPercent=None, quarter=None, year=None, changeInAvgGrossCommission=None, changeInAvgGrossCommissionPercent=None, changeInAvgNetCommission=None, changeInAvgNetCommissionPercent=None, purchasesPercent=None, salesPercent=None, rentalsPercent=None, referralsPercent=None, ):
        self.summaryStartTime = summaryStartTime
        self.summaryEndTime = summaryEndTime
        self.numberOfDeals = numberOfDeals
        self.volume = volume
        self.grossCommission = grossCommission
        self.grossCommissionPercent = grossCommissionPercent
        self.avgGrossCommission = avgGrossCommission
        self.avgGrossCommissionPercent = avgGrossCommissionPercent
        self.netCommission = netCommission
        self.netCommissionPercent = netCommissionPercent
        self.avgNetCommission = avgNetCommission
        self.avgNetCommissionPercent = avgNetCommissionPercent
        self.currency = currency
        self.numberOfPurchases = numberOfPurchases
        self.numberOfSales = numberOfSales
        self.numberOfRentals = numberOfRentals
        self.numberOfReferrals = numberOfReferrals
        self.changeInNumberOfDeals = changeInNumberOfDeals
        self.changeInNumberOfDealsPercent = changeInNumberOfDealsPercent
        self.changeInVolume = changeInVolume
        self.changeInVolumePercent = changeInVolumePercent
        self.changeInGrossCommission = changeInGrossCommission
        self.changeInGrossCommissionPercent = changeInGrossCommissionPercent
        self.changeInNetCommission = changeInNetCommission
        self.changeInNetCommissionPercent = changeInNetCommissionPercent
        self.changeInNumberOfPurchases = changeInNumberOfPurchases
        self.changeInNumberOfPurchasesPercent = changeInNumberOfPurchasesPercent
        self.changeInNumberOfSales = changeInNumberOfSales
        self.changeInNumberOfSalesPercent = changeInNumberOfSalesPercent
        self.changeInNumberOfRentals = changeInNumberOfRentals
        self.changeInNumberOfRentalsPercent = changeInNumberOfRentalsPercent
        self.changeInNumberOfReferrals = changeInNumberOfReferrals
        self.changeInNumberOfReferralsPercent = changeInNumberOfReferralsPercent
        self.quarter = quarter
        self.year = year
        self.changeInAvgGrossCommission = changeInAvgGrossCommission
        self.changeInAvgGrossCommissionPercent = changeInAvgGrossCommissionPercent
        self.changeInAvgNetCommission = changeInAvgNetCommission
        self.changeInAvgNetCommissionPercent = changeInAvgNetCommissionPercent
        self.purchasesPercent = purchasesPercent
        self.salesPercent = salesPercent
        self.rentalsPercent = rentalsPercent
        self.referralsPercent = referralsPercent

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.summaryStartTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.summaryEndTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.numberOfDeals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.volume = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.grossCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.grossCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.avgGrossCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.avgGrossCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.netCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.netCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.avgNetCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.avgNetCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.currency = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.numberOfPurchases = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.numberOfSales = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.numberOfRentals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.numberOfReferrals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.changeInNumberOfDeals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.changeInNumberOfDealsPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.changeInVolume = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.changeInVolumePercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.changeInGrossCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.changeInGrossCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.changeInNetCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.changeInNetCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.changeInNumberOfPurchases = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.changeInNumberOfPurchasesPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.changeInNumberOfSales = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.changeInNumberOfSalesPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.changeInNumberOfRentals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.changeInNumberOfRentalsPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.changeInNumberOfReferrals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.STRING:
                    self.changeInNumberOfReferralsPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.quarter = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.year = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.changeInAvgGrossCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.STRING:
                    self.changeInAvgGrossCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRING:
                    self.changeInAvgNetCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.STRING:
                    self.changeInAvgNetCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.purchasesPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.STRING:
                    self.salesPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.STRING:
                    self.rentalsPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRING:
                    self.referralsPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealsSummaryEntry')
        if self.summaryStartTime is not None:
            oprot.writeFieldBegin('summaryStartTime', TType.I64, 1)
            oprot.writeI64(self.summaryStartTime)
            oprot.writeFieldEnd()
        if self.summaryEndTime is not None:
            oprot.writeFieldBegin('summaryEndTime', TType.I64, 2)
            oprot.writeI64(self.summaryEndTime)
            oprot.writeFieldEnd()
        if self.numberOfDeals is not None:
            oprot.writeFieldBegin('numberOfDeals', TType.STRING, 3)
            oprot.writeString(self.numberOfDeals.encode('utf-8') if sys.version_info[0] == 2 else self.numberOfDeals)
            oprot.writeFieldEnd()
        if self.volume is not None:
            oprot.writeFieldBegin('volume', TType.STRING, 4)
            oprot.writeString(self.volume.encode('utf-8') if sys.version_info[0] == 2 else self.volume)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.STRING, 5)
            oprot.writeString(self.grossCommission.encode('utf-8') if sys.version_info[0] == 2 else self.grossCommission)
            oprot.writeFieldEnd()
        if self.grossCommissionPercent is not None:
            oprot.writeFieldBegin('grossCommissionPercent', TType.STRING, 6)
            oprot.writeString(self.grossCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.grossCommissionPercent)
            oprot.writeFieldEnd()
        if self.avgGrossCommission is not None:
            oprot.writeFieldBegin('avgGrossCommission', TType.STRING, 7)
            oprot.writeString(self.avgGrossCommission.encode('utf-8') if sys.version_info[0] == 2 else self.avgGrossCommission)
            oprot.writeFieldEnd()
        if self.avgGrossCommissionPercent is not None:
            oprot.writeFieldBegin('avgGrossCommissionPercent', TType.STRING, 8)
            oprot.writeString(self.avgGrossCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.avgGrossCommissionPercent)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRING, 9)
            oprot.writeString(self.netCommission.encode('utf-8') if sys.version_info[0] == 2 else self.netCommission)
            oprot.writeFieldEnd()
        if self.netCommissionPercent is not None:
            oprot.writeFieldBegin('netCommissionPercent', TType.STRING, 10)
            oprot.writeString(self.netCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.netCommissionPercent)
            oprot.writeFieldEnd()
        if self.avgNetCommission is not None:
            oprot.writeFieldBegin('avgNetCommission', TType.STRING, 11)
            oprot.writeString(self.avgNetCommission.encode('utf-8') if sys.version_info[0] == 2 else self.avgNetCommission)
            oprot.writeFieldEnd()
        if self.avgNetCommissionPercent is not None:
            oprot.writeFieldBegin('avgNetCommissionPercent', TType.STRING, 12)
            oprot.writeString(self.avgNetCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.avgNetCommissionPercent)
            oprot.writeFieldEnd()
        if self.currency is not None:
            oprot.writeFieldBegin('currency', TType.STRING, 13)
            oprot.writeString(self.currency.encode('utf-8') if sys.version_info[0] == 2 else self.currency)
            oprot.writeFieldEnd()
        if self.numberOfPurchases is not None:
            oprot.writeFieldBegin('numberOfPurchases', TType.STRING, 14)
            oprot.writeString(self.numberOfPurchases.encode('utf-8') if sys.version_info[0] == 2 else self.numberOfPurchases)
            oprot.writeFieldEnd()
        if self.numberOfSales is not None:
            oprot.writeFieldBegin('numberOfSales', TType.STRING, 15)
            oprot.writeString(self.numberOfSales.encode('utf-8') if sys.version_info[0] == 2 else self.numberOfSales)
            oprot.writeFieldEnd()
        if self.numberOfRentals is not None:
            oprot.writeFieldBegin('numberOfRentals', TType.STRING, 16)
            oprot.writeString(self.numberOfRentals.encode('utf-8') if sys.version_info[0] == 2 else self.numberOfRentals)
            oprot.writeFieldEnd()
        if self.numberOfReferrals is not None:
            oprot.writeFieldBegin('numberOfReferrals', TType.STRING, 17)
            oprot.writeString(self.numberOfReferrals.encode('utf-8') if sys.version_info[0] == 2 else self.numberOfReferrals)
            oprot.writeFieldEnd()
        if self.changeInNumberOfDeals is not None:
            oprot.writeFieldBegin('changeInNumberOfDeals', TType.STRING, 18)
            oprot.writeString(self.changeInNumberOfDeals.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfDeals)
            oprot.writeFieldEnd()
        if self.changeInNumberOfDealsPercent is not None:
            oprot.writeFieldBegin('changeInNumberOfDealsPercent', TType.STRING, 19)
            oprot.writeString(self.changeInNumberOfDealsPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfDealsPercent)
            oprot.writeFieldEnd()
        if self.changeInVolume is not None:
            oprot.writeFieldBegin('changeInVolume', TType.STRING, 20)
            oprot.writeString(self.changeInVolume.encode('utf-8') if sys.version_info[0] == 2 else self.changeInVolume)
            oprot.writeFieldEnd()
        if self.changeInVolumePercent is not None:
            oprot.writeFieldBegin('changeInVolumePercent', TType.STRING, 21)
            oprot.writeString(self.changeInVolumePercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInVolumePercent)
            oprot.writeFieldEnd()
        if self.changeInGrossCommission is not None:
            oprot.writeFieldBegin('changeInGrossCommission', TType.STRING, 22)
            oprot.writeString(self.changeInGrossCommission.encode('utf-8') if sys.version_info[0] == 2 else self.changeInGrossCommission)
            oprot.writeFieldEnd()
        if self.changeInGrossCommissionPercent is not None:
            oprot.writeFieldBegin('changeInGrossCommissionPercent', TType.STRING, 23)
            oprot.writeString(self.changeInGrossCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInGrossCommissionPercent)
            oprot.writeFieldEnd()
        if self.changeInNetCommission is not None:
            oprot.writeFieldBegin('changeInNetCommission', TType.STRING, 24)
            oprot.writeString(self.changeInNetCommission.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNetCommission)
            oprot.writeFieldEnd()
        if self.changeInNetCommissionPercent is not None:
            oprot.writeFieldBegin('changeInNetCommissionPercent', TType.STRING, 25)
            oprot.writeString(self.changeInNetCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNetCommissionPercent)
            oprot.writeFieldEnd()
        if self.changeInNumberOfPurchases is not None:
            oprot.writeFieldBegin('changeInNumberOfPurchases', TType.STRING, 26)
            oprot.writeString(self.changeInNumberOfPurchases.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfPurchases)
            oprot.writeFieldEnd()
        if self.changeInNumberOfPurchasesPercent is not None:
            oprot.writeFieldBegin('changeInNumberOfPurchasesPercent', TType.STRING, 27)
            oprot.writeString(self.changeInNumberOfPurchasesPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfPurchasesPercent)
            oprot.writeFieldEnd()
        if self.changeInNumberOfSales is not None:
            oprot.writeFieldBegin('changeInNumberOfSales', TType.STRING, 28)
            oprot.writeString(self.changeInNumberOfSales.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfSales)
            oprot.writeFieldEnd()
        if self.changeInNumberOfSalesPercent is not None:
            oprot.writeFieldBegin('changeInNumberOfSalesPercent', TType.STRING, 29)
            oprot.writeString(self.changeInNumberOfSalesPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfSalesPercent)
            oprot.writeFieldEnd()
        if self.changeInNumberOfRentals is not None:
            oprot.writeFieldBegin('changeInNumberOfRentals', TType.STRING, 30)
            oprot.writeString(self.changeInNumberOfRentals.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfRentals)
            oprot.writeFieldEnd()
        if self.changeInNumberOfRentalsPercent is not None:
            oprot.writeFieldBegin('changeInNumberOfRentalsPercent', TType.STRING, 31)
            oprot.writeString(self.changeInNumberOfRentalsPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfRentalsPercent)
            oprot.writeFieldEnd()
        if self.changeInNumberOfReferrals is not None:
            oprot.writeFieldBegin('changeInNumberOfReferrals', TType.STRING, 32)
            oprot.writeString(self.changeInNumberOfReferrals.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfReferrals)
            oprot.writeFieldEnd()
        if self.changeInNumberOfReferralsPercent is not None:
            oprot.writeFieldBegin('changeInNumberOfReferralsPercent', TType.STRING, 33)
            oprot.writeString(self.changeInNumberOfReferralsPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInNumberOfReferralsPercent)
            oprot.writeFieldEnd()
        if self.quarter is not None:
            oprot.writeFieldBegin('quarter', TType.STRING, 34)
            oprot.writeString(self.quarter.encode('utf-8') if sys.version_info[0] == 2 else self.quarter)
            oprot.writeFieldEnd()
        if self.year is not None:
            oprot.writeFieldBegin('year', TType.STRING, 35)
            oprot.writeString(self.year.encode('utf-8') if sys.version_info[0] == 2 else self.year)
            oprot.writeFieldEnd()
        if self.changeInAvgGrossCommission is not None:
            oprot.writeFieldBegin('changeInAvgGrossCommission', TType.STRING, 36)
            oprot.writeString(self.changeInAvgGrossCommission.encode('utf-8') if sys.version_info[0] == 2 else self.changeInAvgGrossCommission)
            oprot.writeFieldEnd()
        if self.changeInAvgGrossCommissionPercent is not None:
            oprot.writeFieldBegin('changeInAvgGrossCommissionPercent', TType.STRING, 37)
            oprot.writeString(self.changeInAvgGrossCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInAvgGrossCommissionPercent)
            oprot.writeFieldEnd()
        if self.changeInAvgNetCommission is not None:
            oprot.writeFieldBegin('changeInAvgNetCommission', TType.STRING, 38)
            oprot.writeString(self.changeInAvgNetCommission.encode('utf-8') if sys.version_info[0] == 2 else self.changeInAvgNetCommission)
            oprot.writeFieldEnd()
        if self.changeInAvgNetCommissionPercent is not None:
            oprot.writeFieldBegin('changeInAvgNetCommissionPercent', TType.STRING, 39)
            oprot.writeString(self.changeInAvgNetCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.changeInAvgNetCommissionPercent)
            oprot.writeFieldEnd()
        if self.purchasesPercent is not None:
            oprot.writeFieldBegin('purchasesPercent', TType.STRING, 40)
            oprot.writeString(self.purchasesPercent.encode('utf-8') if sys.version_info[0] == 2 else self.purchasesPercent)
            oprot.writeFieldEnd()
        if self.salesPercent is not None:
            oprot.writeFieldBegin('salesPercent', TType.STRING, 41)
            oprot.writeString(self.salesPercent.encode('utf-8') if sys.version_info[0] == 2 else self.salesPercent)
            oprot.writeFieldEnd()
        if self.rentalsPercent is not None:
            oprot.writeFieldBegin('rentalsPercent', TType.STRING, 42)
            oprot.writeString(self.rentalsPercent.encode('utf-8') if sys.version_info[0] == 2 else self.rentalsPercent)
            oprot.writeFieldEnd()
        if self.referralsPercent is not None:
            oprot.writeFieldBegin('referralsPercent', TType.STRING, 43)
            oprot.writeString(self.referralsPercent.encode('utf-8') if sys.version_info[0] == 2 else self.referralsPercent)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntryFilter(object):
    """
    Attributes:
     - values
     - greaterThan
     - lessThan
     - quarters
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'values', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'greaterThan', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'lessThan', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'quarters', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, values=None, greaterThan=None, lessThan=None, quarters=None, ):
        self.values = values
        self.greaterThan = greaterThan
        self.lessThan = lessThan
        self.quarters = quarters

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.values.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.greaterThan = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lessThan = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.quarters = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.quarters.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntryFilter')
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.values))
            for _iter20 in self.values:
                oprot.writeString(_iter20.encode('utf-8') if sys.version_info[0] == 2 else _iter20)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.greaterThan is not None:
            oprot.writeFieldBegin('greaterThan', TType.STRING, 2)
            oprot.writeString(self.greaterThan.encode('utf-8') if sys.version_info[0] == 2 else self.greaterThan)
            oprot.writeFieldEnd()
        if self.lessThan is not None:
            oprot.writeFieldBegin('lessThan', TType.STRING, 3)
            oprot.writeString(self.lessThan.encode('utf-8') if sys.version_info[0] == 2 else self.lessThan)
            oprot.writeFieldEnd()
        if self.quarters is not None:
            oprot.writeFieldBegin('quarters', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.quarters))
            for _iter21 in self.quarters:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LineItem(object):
    """
    Attributes:
     - name
     - amount
     - externalId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
    )
    def __init__(self, name=None, amount=None, externalId=None, ):
        self.name = name
        self.amount = amount
        self.externalId = externalId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LineItem')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetPaymentAgentAllocation(object):
    """
    Attributes:
     - agentName
     - userCompassComId
     - grossCommission
     - allocation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'agentName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userCompassComId', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'grossCommission', None, None, ),  # 3
        (4, TType.DOUBLE, 'allocation', None, None, ),  # 4
    )
    def __init__(self, agentName=None, userCompassComId=None, grossCommission=None, allocation=None, ):
        self.agentName = agentName
        self.userCompassComId = userCompassComId
        self.grossCommission = grossCommission
        self.allocation = allocation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userCompassComId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.grossCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.allocation = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetPaymentAgentAllocation')
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 1)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.userCompassComId is not None:
            oprot.writeFieldBegin('userCompassComId', TType.STRING, 2)
            oprot.writeString(self.userCompassComId.encode('utf-8') if sys.version_info[0] == 2 else self.userCompassComId)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.DOUBLE, 3)
            oprot.writeDouble(self.grossCommission)
            oprot.writeFieldEnd()
        if self.allocation is not None:
            oprot.writeFieldBegin('allocation', TType.DOUBLE, 4)
            oprot.writeDouble(self.allocation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetPaymentItem(object):
    """
    Attributes:
     - deductionName
     - deductionAmount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'deductionName', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'deductionAmount', None, None, ),  # 2
    )
    def __init__(self, deductionName=None, deductionAmount=None, ):
        self.deductionName = deductionName
        self.deductionAmount = deductionAmount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.deductionName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.deductionAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetPaymentItem')
        if self.deductionName is not None:
            oprot.writeFieldBegin('deductionName', TType.STRING, 1)
            oprot.writeString(self.deductionName.encode('utf-8') if sys.version_info[0] == 2 else self.deductionName)
            oprot.writeFieldEnd()
        if self.deductionAmount is not None:
            oprot.writeFieldBegin('deductionAmount', TType.DOUBLE, 2)
            oprot.writeDouble(self.deductionAmount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetPaymentTeamCommission(object):
    """
    Attributes:
     - teamSplitPercent
     - teamGrossCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'teamSplitPercent', None, None, ),  # 1
        (2, TType.DOUBLE, 'teamGrossCommission', None, None, ),  # 2
    )
    def __init__(self, teamSplitPercent=None, teamGrossCommission=None, ):
        self.teamSplitPercent = teamSplitPercent
        self.teamGrossCommission = teamGrossCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.teamSplitPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.teamGrossCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetPaymentTeamCommission')
        if self.teamSplitPercent is not None:
            oprot.writeFieldBegin('teamSplitPercent', TType.DOUBLE, 1)
            oprot.writeDouble(self.teamSplitPercent)
            oprot.writeFieldEnd()
        if self.teamGrossCommission is not None:
            oprot.writeFieldBegin('teamGrossCommission', TType.DOUBLE, 2)
            oprot.writeDouble(self.teamGrossCommission)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NormalizedDealCommission(object):
    """
    Attributes:
     - afcUserId
     - firstName
     - lastName
     - displayName
     - netCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'firstName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'lastName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'displayName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'netCommission', 'UTF8', None, ),  # 5
    )
    def __init__(self, afcUserId=None, firstName=None, lastName=None, displayName=None, netCommission=None, ):
        self.afcUserId = afcUserId
        self.firstName = firstName
        self.lastName = lastName
        self.displayName = displayName
        self.netCommission = netCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.netCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NormalizedDealCommission')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 2)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 3)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 4)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRING, 5)
            oprot.writeString(self.netCommission.encode('utf-8') if sys.version_info[0] == 2 else self.netCommission)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NormalizedLineItem(object):
    """
    Attributes:
     - name
     - amount
     - externalId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'amount', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
    )
    def __init__(self, name=None, amount=None, externalId=None, ):
        self.name = name
        self.amount = amount
        self.externalId = externalId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.amount = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NormalizedLineItem')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.STRING, 2)
            oprot.writeString(self.amount.encode('utf-8') if sys.version_info[0] == 2 else self.amount)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PaginationOptions(object):
    """
    Attributes:
     - offset
     - limit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'offset', None, None, ),  # 1
        (2, TType.I64, 'limit', None, None, ),  # 2
    )
    def __init__(self, offset=None, limit=None, ):
        self.offset = offset
        self.limit = limit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.offset = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.limit = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PaginationOptions')
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I64, 1)
            oprot.writeI64(self.offset)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I64, 2)
            oprot.writeI64(self.limit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Signature(object):
    """
    Attributes:
     - nonce
     - timestamp
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'nonce', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'timestamp', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'signature', 'UTF8', None, ),  # 3
    )
    def __init__(self, nonce=None, timestamp=None, signature=None, ):
        self.nonce = nonce
        self.timestamp = timestamp
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.nonce = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.timestamp = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.signature = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Signature')
        if self.nonce is not None:
            oprot.writeFieldBegin('nonce', TType.STRING, 1)
            oprot.writeString(self.nonce.encode('utf-8') if sys.version_info[0] == 2 else self.nonce)
            oprot.writeFieldEnd()
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.STRING, 2)
            oprot.writeString(self.timestamp.encode('utf-8') if sys.version_info[0] == 2 else self.timestamp)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRING, 3)
            oprot.writeString(self.signature.encode('utf-8') if sys.version_info[0] == 2 else self.signature)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SortOptions(object):
    """
    Attributes:
     - fields
     - orders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'fields', (TType.I32, None, False), None, ),  # 1
        (2, TType.LIST, 'orders', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, fields=None, orders=None, ):
        self.fields = fields
        self.orders = orders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.fields = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readI32()
                        self.fields.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.orders = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = iprot.readI32()
                        self.orders.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SortOptions')
        if self.fields is not None:
            oprot.writeFieldBegin('fields', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.fields))
            for _iter30 in self.fields:
                oprot.writeI32(_iter30)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.orders is not None:
            oprot.writeFieldBegin('orders', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.orders))
            for _iter31 in self.orders:
                oprot.writeI32(_iter31)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamMembership(object):
    """
    Attributes:
     - afcTeamId
     - amaName
     - teamName
     - status
     - role
     - startDate
     - lastUpdatedTime
     - endDate
     - afcUserId
     - teamCompassComId
     - compassTeamId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcTeamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'amaName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'teamName', 'UTF8', None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.I32, 'role', None, None, ),  # 5
        (6, TType.I64, 'startDate', None, None, ),  # 6
        (7, TType.I64, 'lastUpdatedTime', None, None, ),  # 7
        (8, TType.I64, 'endDate', None, None, ),  # 8
        None,  # 9
        (10, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'teamCompassComId', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 12
    )
    def __init__(self, afcTeamId=None, amaName=None, teamName=None, status=None, role=None, startDate=None, lastUpdatedTime=None, endDate=None, afcUserId=None, teamCompassComId=None, compassTeamId=None, ):
        self.afcTeamId = afcTeamId
        self.amaName = amaName
        self.teamName = teamName
        self.status = status
        self.role = role
        self.startDate = startDate
        self.lastUpdatedTime = lastUpdatedTime
        self.endDate = endDate
        self.afcUserId = afcUserId
        self.teamCompassComId = teamCompassComId
        self.compassTeamId = compassTeamId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.amaName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.teamName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.role = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.startDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastUpdatedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.endDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.teamCompassComId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamMembership')
        if self.afcTeamId is not None:
            oprot.writeFieldBegin('afcTeamId', TType.STRING, 1)
            oprot.writeString(self.afcTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.afcTeamId)
            oprot.writeFieldEnd()
        if self.amaName is not None:
            oprot.writeFieldBegin('amaName', TType.STRING, 2)
            oprot.writeString(self.amaName.encode('utf-8') if sys.version_info[0] == 2 else self.amaName)
            oprot.writeFieldEnd()
        if self.teamName is not None:
            oprot.writeFieldBegin('teamName', TType.STRING, 3)
            oprot.writeString(self.teamName.encode('utf-8') if sys.version_info[0] == 2 else self.teamName)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.I32, 5)
            oprot.writeI32(self.role)
            oprot.writeFieldEnd()
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.I64, 6)
            oprot.writeI64(self.startDate)
            oprot.writeFieldEnd()
        if self.lastUpdatedTime is not None:
            oprot.writeFieldBegin('lastUpdatedTime', TType.I64, 7)
            oprot.writeI64(self.lastUpdatedTime)
            oprot.writeFieldEnd()
        if self.endDate is not None:
            oprot.writeFieldBegin('endDate', TType.I64, 8)
            oprot.writeI64(self.endDate)
            oprot.writeFieldEnd()
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 10)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.teamCompassComId is not None:
            oprot.writeFieldBegin('teamCompassComId', TType.STRING, 11)
            oprot.writeString(self.teamCompassComId.encode('utf-8') if sys.version_info[0] == 2 else self.teamCompassComId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 12)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Deal(object):
    """
    Attributes:
     - afcDealId
     - dealType
     - listingId
     - lastUpdatedTime
     - closePrice
     - grossCommission
     - grossCommissionPercent
     - agents
     - closeDate
     - createdDate
     - listingAddress
     - netCommission
     - commissionPaidDate
     - propertyType
     - sideRepresented
     - compassCommissionAmount
     - teamLevelLineItems
     - payoutLineItems
     - payoutAmount
     - externalId
     - dealStatus
     - teamId
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcDealId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dealType', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'listingId', 'UTF8', None, ),  # 3
        None,  # 4
        (5, TType.I64, 'lastUpdatedTime', None, None, ),  # 5
        (6, TType.DOUBLE, 'closePrice', None, None, ),  # 6
        (7, TType.DOUBLE, 'grossCommission', None, None, ),  # 7
        (8, TType.DOUBLE, 'grossCommissionPercent', None, None, ),  # 8
        None,  # 9
        (10, TType.LIST, 'agents', (TType.STRUCT, (DealCommission, DealCommission.thrift_spec), False), None, ),  # 10
        (11, TType.I64, 'closeDate', None, None, ),  # 11
        None,  # 12
        (13, TType.I64, 'createdDate', None, None, ),  # 13
        None,  # 14
        None,  # 15
        (16, TType.STRING, 'listingAddress', 'UTF8', None, ),  # 16
        (17, TType.DOUBLE, 'netCommission', None, None, ),  # 17
        None,  # 18
        (19, TType.I64, 'commissionPaidDate', None, None, ),  # 19
        (20, TType.STRING, 'propertyType', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'sideRepresented', 'UTF8', None, ),  # 21
        (22, TType.DOUBLE, 'compassCommissionAmount', None, None, ),  # 22
        (23, TType.LIST, 'teamLevelLineItems', (TType.STRUCT, (LineItem, LineItem.thrift_spec), False), None, ),  # 23
        (24, TType.LIST, 'payoutLineItems', (TType.STRUCT, (LineItem, LineItem.thrift_spec), False), None, ),  # 24
        (25, TType.DOUBLE, 'payoutAmount', None, None, ),  # 25
        (26, TType.STRING, 'externalId', 'UTF8', None, ),  # 26
        (27, TType.STRING, 'dealStatus', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'teamId', 'UTF8', None, ),  # 28
        (29, TType.BOOL, 'isDeleted', None, None, ),  # 29
    )
    def __init__(self, afcDealId=None, dealType=None, listingId=None, lastUpdatedTime=None, closePrice=None, grossCommission=None, grossCommissionPercent=None, agents=None, closeDate=None, createdDate=None, listingAddress=None, netCommission=None, commissionPaidDate=None, propertyType=None, sideRepresented=None, compassCommissionAmount=None, teamLevelLineItems=None, payoutLineItems=None, payoutAmount=None, externalId=None, dealStatus=None, teamId=None, isDeleted=None, ):
        self.afcDealId = afcDealId
        self.dealType = dealType
        self.listingId = listingId
        self.lastUpdatedTime = lastUpdatedTime
        self.closePrice = closePrice
        self.grossCommission = grossCommission
        self.grossCommissionPercent = grossCommissionPercent
        self.agents = agents
        self.closeDate = closeDate
        self.createdDate = createdDate
        self.listingAddress = listingAddress
        self.netCommission = netCommission
        self.commissionPaidDate = commissionPaidDate
        self.propertyType = propertyType
        self.sideRepresented = sideRepresented
        self.compassCommissionAmount = compassCommissionAmount
        self.teamLevelLineItems = teamLevelLineItems
        self.payoutLineItems = payoutLineItems
        self.payoutAmount = payoutAmount
        self.externalId = externalId
        self.dealStatus = dealStatus
        self.teamId = teamId
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcDealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dealType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.lastUpdatedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.grossCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.DOUBLE:
                    self.grossCommissionPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.agents = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = DealCommission()
                        _elem34.read(iprot)
                        self.agents.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.createdDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.listingAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.DOUBLE:
                    self.netCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I64:
                    self.commissionPaidDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.propertyType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.sideRepresented = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.DOUBLE:
                    self.compassCommissionAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.LIST:
                    self.teamLevelLineItems = []
                    (_etype36, _size39) = iprot.readListBegin()
                    for _i37 in range(_size39):
                        _elem38 = LineItem()
                        _elem38.read(iprot)
                        self.teamLevelLineItems.append(_elem38)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.LIST:
                    self.payoutLineItems = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = LineItem()
                        _elem42.read(iprot)
                        self.payoutLineItems.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.DOUBLE:
                    self.payoutAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.dealStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Deal')
        if self.afcDealId is not None:
            oprot.writeFieldBegin('afcDealId', TType.STRING, 1)
            oprot.writeString(self.afcDealId.encode('utf-8') if sys.version_info[0] == 2 else self.afcDealId)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.STRING, 2)
            oprot.writeString(self.dealType.encode('utf-8') if sys.version_info[0] == 2 else self.dealType)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 3)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.lastUpdatedTime is not None:
            oprot.writeFieldBegin('lastUpdatedTime', TType.I64, 5)
            oprot.writeI64(self.lastUpdatedTime)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 6)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.DOUBLE, 7)
            oprot.writeDouble(self.grossCommission)
            oprot.writeFieldEnd()
        if self.grossCommissionPercent is not None:
            oprot.writeFieldBegin('grossCommissionPercent', TType.DOUBLE, 8)
            oprot.writeDouble(self.grossCommissionPercent)
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.agents))
            for _iter44 in self.agents:
                _iter44.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 11)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.createdDate is not None:
            oprot.writeFieldBegin('createdDate', TType.I64, 13)
            oprot.writeI64(self.createdDate)
            oprot.writeFieldEnd()
        if self.listingAddress is not None:
            oprot.writeFieldBegin('listingAddress', TType.STRING, 16)
            oprot.writeString(self.listingAddress.encode('utf-8') if sys.version_info[0] == 2 else self.listingAddress)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.DOUBLE, 17)
            oprot.writeDouble(self.netCommission)
            oprot.writeFieldEnd()
        if self.commissionPaidDate is not None:
            oprot.writeFieldBegin('commissionPaidDate', TType.I64, 19)
            oprot.writeI64(self.commissionPaidDate)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.STRING, 20)
            oprot.writeString(self.propertyType.encode('utf-8') if sys.version_info[0] == 2 else self.propertyType)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.STRING, 21)
            oprot.writeString(self.sideRepresented.encode('utf-8') if sys.version_info[0] == 2 else self.sideRepresented)
            oprot.writeFieldEnd()
        if self.compassCommissionAmount is not None:
            oprot.writeFieldBegin('compassCommissionAmount', TType.DOUBLE, 22)
            oprot.writeDouble(self.compassCommissionAmount)
            oprot.writeFieldEnd()
        if self.teamLevelLineItems is not None:
            oprot.writeFieldBegin('teamLevelLineItems', TType.LIST, 23)
            oprot.writeListBegin(TType.STRUCT, len(self.teamLevelLineItems))
            for _iter45 in self.teamLevelLineItems:
                _iter45.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.payoutLineItems is not None:
            oprot.writeFieldBegin('payoutLineItems', TType.LIST, 24)
            oprot.writeListBegin(TType.STRUCT, len(self.payoutLineItems))
            for _iter46 in self.payoutLineItems:
                _iter46.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.payoutAmount is not None:
            oprot.writeFieldBegin('payoutAmount', TType.DOUBLE, 25)
            oprot.writeDouble(self.payoutAmount)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 26)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.dealStatus is not None:
            oprot.writeFieldBegin('dealStatus', TType.STRING, 27)
            oprot.writeString(self.dealStatus.encode('utf-8') if sys.version_info[0] == 2 else self.dealStatus)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 28)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 29)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealSideAggregatedEntry(object):
    """
    Attributes:
     - type
     - grossCommission
     - volume
     - numberOfDeals
     - netCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'type', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'grossCommission', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'volume', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'numberOfDeals', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'netCommission', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 5
    )
    def __init__(self, type=None, grossCommission=None, volume=None, numberOfDeals=None, netCommission=None, ):
        self.type = type
        self.grossCommission = grossCommission
        self.volume = volume
        self.numberOfDeals = numberOfDeals
        self.netCommission = netCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.grossCommission = DealPeriodData()
                    self.grossCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.volume = DealPeriodData()
                    self.volume.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.numberOfDeals = DealPeriodData()
                    self.numberOfDeals.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.netCommission = DealPeriodData()
                    self.netCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealSideAggregatedEntry')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 1)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.STRUCT, 2)
            self.grossCommission.write(oprot)
            oprot.writeFieldEnd()
        if self.volume is not None:
            oprot.writeFieldBegin('volume', TType.STRUCT, 3)
            self.volume.write(oprot)
            oprot.writeFieldEnd()
        if self.numberOfDeals is not None:
            oprot.writeFieldBegin('numberOfDeals', TType.STRUCT, 4)
            self.numberOfDeals.write(oprot)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRUCT, 5)
            self.netCommission.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealsSummary(object):
    """
    Attributes:
     - entries
     - cumulative
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'entries', (TType.STRUCT, (DealsSummaryEntry, DealsSummaryEntry.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'cumulative', (DealsSummaryEntry, DealsSummaryEntry.thrift_spec), None, ),  # 2
    )
    def __init__(self, entries=None, cumulative=None, ):
        self.entries = entries
        self.cumulative = cumulative

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.entries = []
                    (_etype47, _size50) = iprot.readListBegin()
                    for _i48 in range(_size50):
                        _elem49 = DealsSummaryEntry()
                        _elem49.read(iprot)
                        self.entries.append(_elem49)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.cumulative = DealsSummaryEntry()
                    self.cumulative.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealsSummary')
        if self.entries is not None:
            oprot.writeFieldBegin('entries', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.entries))
            for _iter51 in self.entries:
                _iter51.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.cumulative is not None:
            oprot.writeFieldBegin('cumulative', TType.STRUCT, 2)
            self.cumulative.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterOptions(object):
    """
    Attributes:
     - entryFilter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'entryFilter', (TType.I32, None, TType.STRUCT, (EntryFilter, EntryFilter.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, entryFilter=None, ):
        self.entryFilter = entryFilter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.entryFilter = {}
                    (_ktype53, _vtype54, _size57) = iprot.readMapBegin()
                    for _i52 in range(_size57):
                        _key55 = iprot.readI32()
                        _val56 = EntryFilter()
                        _val56.read(iprot)
                        self.entryFilter[_key55] = _val56
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterOptions')
        if self.entryFilter is not None:
            oprot.writeFieldBegin('entryFilter', TType.MAP, 1)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.entryFilter))
            for _kiter58, _viter59 in self.entryFilter.items():
                oprot.writeI32(_kiter58)
                _viter59.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetPaymentAgent(object):
    """
    Attributes:
     - allocation
     - netCommission
     - deductions
     - netPayment
     - incomes
     - nonDealDeductions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'allocation', None, None, ),  # 1
        (2, TType.DOUBLE, 'netCommission', None, None, ),  # 2
        (3, TType.LIST, 'deductions', (TType.STRUCT, (NetPaymentItem, NetPaymentItem.thrift_spec), False), None, ),  # 3
        (4, TType.DOUBLE, 'netPayment', None, None, ),  # 4
        (5, TType.LIST, 'incomes', (TType.STRUCT, (NetPaymentItem, NetPaymentItem.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'nonDealDeductions', (TType.STRUCT, (NetPaymentItem, NetPaymentItem.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, allocation=None, netCommission=None, deductions=None, netPayment=None, incomes=None, nonDealDeductions=None, ):
        self.allocation = allocation
        self.netCommission = netCommission
        self.deductions = deductions
        self.netPayment = netPayment
        self.incomes = incomes
        self.nonDealDeductions = nonDealDeductions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.allocation = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.netCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.deductions = []
                    (_etype60, _size63) = iprot.readListBegin()
                    for _i61 in range(_size63):
                        _elem62 = NetPaymentItem()
                        _elem62.read(iprot)
                        self.deductions.append(_elem62)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.netPayment = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.incomes = []
                    (_etype64, _size67) = iprot.readListBegin()
                    for _i65 in range(_size67):
                        _elem66 = NetPaymentItem()
                        _elem66.read(iprot)
                        self.incomes.append(_elem66)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.nonDealDeductions = []
                    (_etype68, _size71) = iprot.readListBegin()
                    for _i69 in range(_size71):
                        _elem70 = NetPaymentItem()
                        _elem70.read(iprot)
                        self.nonDealDeductions.append(_elem70)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetPaymentAgent')
        if self.allocation is not None:
            oprot.writeFieldBegin('allocation', TType.DOUBLE, 1)
            oprot.writeDouble(self.allocation)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.DOUBLE, 2)
            oprot.writeDouble(self.netCommission)
            oprot.writeFieldEnd()
        if self.deductions is not None:
            oprot.writeFieldBegin('deductions', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.deductions))
            for _iter72 in self.deductions:
                _iter72.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.netPayment is not None:
            oprot.writeFieldBegin('netPayment', TType.DOUBLE, 4)
            oprot.writeDouble(self.netPayment)
            oprot.writeFieldEnd()
        if self.incomes is not None:
            oprot.writeFieldBegin('incomes', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.incomes))
            for _iter73 in self.incomes:
                _iter73.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.nonDealDeductions is not None:
            oprot.writeFieldBegin('nonDealDeductions', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.nonDealDeductions))
            for _iter74 in self.nonDealDeductions:
                _iter74.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetPaymentGCI(object):
    """
    Attributes:
     - finalClosePrice
     - brokerageCommission
     - brokerageRevenue
     - offTheTopFees
     - gci
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'finalClosePrice', None, None, ),  # 1
        (2, TType.DOUBLE, 'brokerageCommission', None, None, ),  # 2
        (3, TType.DOUBLE, 'brokerageRevenue', None, None, ),  # 3
        (4, TType.LIST, 'offTheTopFees', (TType.STRUCT, (NetPaymentItem, NetPaymentItem.thrift_spec), False), None, ),  # 4
        (5, TType.DOUBLE, 'gci', None, None, ),  # 5
    )
    def __init__(self, finalClosePrice=None, brokerageCommission=None, brokerageRevenue=None, offTheTopFees=None, gci=None, ):
        self.finalClosePrice = finalClosePrice
        self.brokerageCommission = brokerageCommission
        self.brokerageRevenue = brokerageRevenue
        self.offTheTopFees = offTheTopFees
        self.gci = gci

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.finalClosePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.brokerageCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.brokerageRevenue = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.offTheTopFees = []
                    (_etype75, _size78) = iprot.readListBegin()
                    for _i76 in range(_size78):
                        _elem77 = NetPaymentItem()
                        _elem77.read(iprot)
                        self.offTheTopFees.append(_elem77)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.gci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetPaymentGCI')
        if self.finalClosePrice is not None:
            oprot.writeFieldBegin('finalClosePrice', TType.DOUBLE, 1)
            oprot.writeDouble(self.finalClosePrice)
            oprot.writeFieldEnd()
        if self.brokerageCommission is not None:
            oprot.writeFieldBegin('brokerageCommission', TType.DOUBLE, 2)
            oprot.writeDouble(self.brokerageCommission)
            oprot.writeFieldEnd()
        if self.brokerageRevenue is not None:
            oprot.writeFieldBegin('brokerageRevenue', TType.DOUBLE, 3)
            oprot.writeDouble(self.brokerageRevenue)
            oprot.writeFieldEnd()
        if self.offTheTopFees is not None:
            oprot.writeFieldBegin('offTheTopFees', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.offTheTopFees))
            for _iter79 in self.offTheTopFees:
                _iter79.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.gci is not None:
            oprot.writeFieldBegin('gci', TType.DOUBLE, 5)
            oprot.writeDouble(self.gci)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NormalizedDeal(object):
    """
    Attributes:
     - afcDealId
     - dealType
     - listingId
     - lastUpdatedTime
     - closePrice
     - grossCommission
     - grossCommissionPercent
     - agents
     - closeDate
     - createdDate
     - listingAddress
     - netCommission
     - commissionPaidDate
     - propertyType
     - sideRepresented
     - compassCommissionAmount
     - teamLevelLineItems
     - payoutLineItems
     - payoutAmount
     - externalId
     - dealStatus
     - teamId
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcDealId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dealType', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'listingId', 'UTF8', None, ),  # 3
        None,  # 4
        (5, TType.I64, 'lastUpdatedTime', None, None, ),  # 5
        (6, TType.STRING, 'closePrice', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'grossCommission', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'grossCommissionPercent', 'UTF8', None, ),  # 8
        None,  # 9
        (10, TType.LIST, 'agents', (TType.STRUCT, (NormalizedDealCommission, NormalizedDealCommission.thrift_spec), False), None, ),  # 10
        (11, TType.STRING, 'closeDate', 'UTF8', None, ),  # 11
        None,  # 12
        (13, TType.STRING, 'createdDate', 'UTF8', None, ),  # 13
        None,  # 14
        None,  # 15
        (16, TType.STRING, 'listingAddress', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'netCommission', 'UTF8', None, ),  # 17
        None,  # 18
        (19, TType.STRING, 'commissionPaidDate', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'propertyType', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'sideRepresented', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'compassCommissionAmount', 'UTF8', None, ),  # 22
        (23, TType.LIST, 'teamLevelLineItems', (TType.STRUCT, (NormalizedLineItem, NormalizedLineItem.thrift_spec), False), None, ),  # 23
        (24, TType.LIST, 'payoutLineItems', (TType.STRUCT, (NormalizedLineItem, NormalizedLineItem.thrift_spec), False), None, ),  # 24
        (25, TType.STRING, 'payoutAmount', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'externalId', 'UTF8', None, ),  # 26
        (27, TType.STRING, 'dealStatus', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'teamId', 'UTF8', None, ),  # 28
        (29, TType.BOOL, 'isDeleted', None, None, ),  # 29
    )
    def __init__(self, afcDealId=None, dealType=None, listingId=None, lastUpdatedTime=None, closePrice=None, grossCommission=None, grossCommissionPercent=None, agents=None, closeDate=None, createdDate=None, listingAddress=None, netCommission=None, commissionPaidDate=None, propertyType=None, sideRepresented=None, compassCommissionAmount=None, teamLevelLineItems=None, payoutLineItems=None, payoutAmount=None, externalId=None, dealStatus=None, teamId=None, isDeleted=None, ):
        self.afcDealId = afcDealId
        self.dealType = dealType
        self.listingId = listingId
        self.lastUpdatedTime = lastUpdatedTime
        self.closePrice = closePrice
        self.grossCommission = grossCommission
        self.grossCommissionPercent = grossCommissionPercent
        self.agents = agents
        self.closeDate = closeDate
        self.createdDate = createdDate
        self.listingAddress = listingAddress
        self.netCommission = netCommission
        self.commissionPaidDate = commissionPaidDate
        self.propertyType = propertyType
        self.sideRepresented = sideRepresented
        self.compassCommissionAmount = compassCommissionAmount
        self.teamLevelLineItems = teamLevelLineItems
        self.payoutLineItems = payoutLineItems
        self.payoutAmount = payoutAmount
        self.externalId = externalId
        self.dealStatus = dealStatus
        self.teamId = teamId
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcDealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dealType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.lastUpdatedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.closePrice = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.grossCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.grossCommissionPercent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.agents = []
                    (_etype80, _size83) = iprot.readListBegin()
                    for _i81 in range(_size83):
                        _elem82 = NormalizedDealCommission()
                        _elem82.read(iprot)
                        self.agents.append(_elem82)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.createdDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.listingAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.netCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.commissionPaidDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.propertyType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.sideRepresented = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.compassCommissionAmount = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.LIST:
                    self.teamLevelLineItems = []
                    (_etype84, _size87) = iprot.readListBegin()
                    for _i85 in range(_size87):
                        _elem86 = NormalizedLineItem()
                        _elem86.read(iprot)
                        self.teamLevelLineItems.append(_elem86)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.LIST:
                    self.payoutLineItems = []
                    (_etype88, _size91) = iprot.readListBegin()
                    for _i89 in range(_size91):
                        _elem90 = NormalizedLineItem()
                        _elem90.read(iprot)
                        self.payoutLineItems.append(_elem90)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.payoutAmount = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.dealStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NormalizedDeal')
        if self.afcDealId is not None:
            oprot.writeFieldBegin('afcDealId', TType.STRING, 1)
            oprot.writeString(self.afcDealId.encode('utf-8') if sys.version_info[0] == 2 else self.afcDealId)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.STRING, 2)
            oprot.writeString(self.dealType.encode('utf-8') if sys.version_info[0] == 2 else self.dealType)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 3)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.lastUpdatedTime is not None:
            oprot.writeFieldBegin('lastUpdatedTime', TType.I64, 5)
            oprot.writeI64(self.lastUpdatedTime)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.STRING, 6)
            oprot.writeString(self.closePrice.encode('utf-8') if sys.version_info[0] == 2 else self.closePrice)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.STRING, 7)
            oprot.writeString(self.grossCommission.encode('utf-8') if sys.version_info[0] == 2 else self.grossCommission)
            oprot.writeFieldEnd()
        if self.grossCommissionPercent is not None:
            oprot.writeFieldBegin('grossCommissionPercent', TType.STRING, 8)
            oprot.writeString(self.grossCommissionPercent.encode('utf-8') if sys.version_info[0] == 2 else self.grossCommissionPercent)
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.agents))
            for _iter92 in self.agents:
                _iter92.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 11)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.createdDate is not None:
            oprot.writeFieldBegin('createdDate', TType.STRING, 13)
            oprot.writeString(self.createdDate.encode('utf-8') if sys.version_info[0] == 2 else self.createdDate)
            oprot.writeFieldEnd()
        if self.listingAddress is not None:
            oprot.writeFieldBegin('listingAddress', TType.STRING, 16)
            oprot.writeString(self.listingAddress.encode('utf-8') if sys.version_info[0] == 2 else self.listingAddress)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRING, 17)
            oprot.writeString(self.netCommission.encode('utf-8') if sys.version_info[0] == 2 else self.netCommission)
            oprot.writeFieldEnd()
        if self.commissionPaidDate is not None:
            oprot.writeFieldBegin('commissionPaidDate', TType.STRING, 19)
            oprot.writeString(self.commissionPaidDate.encode('utf-8') if sys.version_info[0] == 2 else self.commissionPaidDate)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.STRING, 20)
            oprot.writeString(self.propertyType.encode('utf-8') if sys.version_info[0] == 2 else self.propertyType)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.STRING, 21)
            oprot.writeString(self.sideRepresented.encode('utf-8') if sys.version_info[0] == 2 else self.sideRepresented)
            oprot.writeFieldEnd()
        if self.compassCommissionAmount is not None:
            oprot.writeFieldBegin('compassCommissionAmount', TType.STRING, 22)
            oprot.writeString(self.compassCommissionAmount.encode('utf-8') if sys.version_info[0] == 2 else self.compassCommissionAmount)
            oprot.writeFieldEnd()
        if self.teamLevelLineItems is not None:
            oprot.writeFieldBegin('teamLevelLineItems', TType.LIST, 23)
            oprot.writeListBegin(TType.STRUCT, len(self.teamLevelLineItems))
            for _iter93 in self.teamLevelLineItems:
                _iter93.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.payoutLineItems is not None:
            oprot.writeFieldBegin('payoutLineItems', TType.LIST, 24)
            oprot.writeListBegin(TType.STRUCT, len(self.payoutLineItems))
            for _iter94 in self.payoutLineItems:
                _iter94.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.payoutAmount is not None:
            oprot.writeFieldBegin('payoutAmount', TType.STRING, 25)
            oprot.writeString(self.payoutAmount.encode('utf-8') if sys.version_info[0] == 2 else self.payoutAmount)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 26)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.dealStatus is not None:
            oprot.writeFieldBegin('dealStatus', TType.STRING, 27)
            oprot.writeString(self.dealStatus.encode('utf-8') if sys.version_info[0] == 2 else self.dealStatus)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 28)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 29)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class User(object):
    """
    Attributes:
     - afcUserId
     - firstName
     - lastName
     - displayName
     - teams
     - historicalTeams
     - lastUpdatedTime
     - userCompassComId
     - compassAgentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'firstName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'lastName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'displayName', 'UTF8', None, ),  # 4
        (5, TType.LIST, 'teams', (TType.STRUCT, (TeamMembership, TeamMembership.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'historicalTeams', (TType.STRUCT, (TeamMembership, TeamMembership.thrift_spec), False), None, ),  # 6
        (7, TType.I64, 'lastUpdatedTime', None, None, ),  # 7
        (8, TType.STRING, 'userCompassComId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'compassAgentId', 'UTF8', None, ),  # 9
    )
    def __init__(self, afcUserId=None, firstName=None, lastName=None, displayName=None, teams=None, historicalTeams=None, lastUpdatedTime=None, userCompassComId=None, compassAgentId=None, ):
        self.afcUserId = afcUserId
        self.firstName = firstName
        self.lastName = lastName
        self.displayName = displayName
        self.teams = teams
        self.historicalTeams = historicalTeams
        self.lastUpdatedTime = lastUpdatedTime
        self.userCompassComId = userCompassComId
        self.compassAgentId = compassAgentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.teams = []
                    (_etype95, _size98) = iprot.readListBegin()
                    for _i96 in range(_size98):
                        _elem97 = TeamMembership()
                        _elem97.read(iprot)
                        self.teams.append(_elem97)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.historicalTeams = []
                    (_etype99, _size102) = iprot.readListBegin()
                    for _i100 in range(_size102):
                        _elem101 = TeamMembership()
                        _elem101.read(iprot)
                        self.historicalTeams.append(_elem101)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastUpdatedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.userCompassComId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.compassAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('User')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 2)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 3)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 4)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.teams is not None:
            oprot.writeFieldBegin('teams', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.teams))
            for _iter103 in self.teams:
                _iter103.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.historicalTeams is not None:
            oprot.writeFieldBegin('historicalTeams', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.historicalTeams))
            for _iter104 in self.historicalTeams:
                _iter104.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastUpdatedTime is not None:
            oprot.writeFieldBegin('lastUpdatedTime', TType.I64, 7)
            oprot.writeI64(self.lastUpdatedTime)
            oprot.writeFieldEnd()
        if self.userCompassComId is not None:
            oprot.writeFieldBegin('userCompassComId', TType.STRING, 8)
            oprot.writeString(self.userCompassComId.encode('utf-8') if sys.version_info[0] == 2 else self.userCompassComId)
            oprot.writeFieldEnd()
        if self.compassAgentId is not None:
            oprot.writeFieldBegin('compassAgentId', TType.STRING, 9)
            oprot.writeString(self.compassAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.compassAgentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CollectionOptions(object):
    """
    Attributes:
     - pagination
     - sort
     - filter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'pagination', (PaginationOptions, PaginationOptions.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'sort', (SortOptions, SortOptions.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'filter', (FilterOptions, FilterOptions.thrift_spec), None, ),  # 3
    )
    def __init__(self, pagination=None, sort=None, filter=None, ):
        self.pagination = pagination
        self.sort = sort
        self.filter = filter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.pagination = PaginationOptions()
                    self.pagination.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.sort = SortOptions()
                    self.sort.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.filter = FilterOptions()
                    self.filter.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CollectionOptions')
        if self.pagination is not None:
            oprot.writeFieldBegin('pagination', TType.STRUCT, 1)
            self.pagination.write(oprot)
            oprot.writeFieldEnd()
        if self.sort is not None:
            oprot.writeFieldBegin('sort', TType.STRUCT, 2)
            self.sort.write(oprot)
            oprot.writeFieldEnd()
        if self.filter is not None:
            oprot.writeFieldBegin('filter', TType.STRUCT, 3)
            self.filter.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealTypeAggregatedEntry(object):
    """
    Attributes:
     - type
     - grossCommission
     - volume
     - numberOfDeals
     - sideEntries
     - netCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'type', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'grossCommission', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'volume', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'numberOfDeals', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 4
        (5, TType.LIST, 'sideEntries', (TType.STRUCT, (DealSideAggregatedEntry, DealSideAggregatedEntry.thrift_spec), False), None, ),  # 5
        (6, TType.STRUCT, 'netCommission', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 6
    )
    def __init__(self, type=None, grossCommission=None, volume=None, numberOfDeals=None, sideEntries=None, netCommission=None, ):
        self.type = type
        self.grossCommission = grossCommission
        self.volume = volume
        self.numberOfDeals = numberOfDeals
        self.sideEntries = sideEntries
        self.netCommission = netCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.grossCommission = DealPeriodData()
                    self.grossCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.volume = DealPeriodData()
                    self.volume.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.numberOfDeals = DealPeriodData()
                    self.numberOfDeals.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.sideEntries = []
                    (_etype105, _size108) = iprot.readListBegin()
                    for _i106 in range(_size108):
                        _elem107 = DealSideAggregatedEntry()
                        _elem107.read(iprot)
                        self.sideEntries.append(_elem107)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.netCommission = DealPeriodData()
                    self.netCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealTypeAggregatedEntry')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 1)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.STRUCT, 2)
            self.grossCommission.write(oprot)
            oprot.writeFieldEnd()
        if self.volume is not None:
            oprot.writeFieldBegin('volume', TType.STRUCT, 3)
            self.volume.write(oprot)
            oprot.writeFieldEnd()
        if self.numberOfDeals is not None:
            oprot.writeFieldBegin('numberOfDeals', TType.STRUCT, 4)
            self.numberOfDeals.write(oprot)
            oprot.writeFieldEnd()
        if self.sideEntries is not None:
            oprot.writeFieldBegin('sideEntries', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.sideEntries))
            for _iter109 in self.sideEntries:
                _iter109.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRUCT, 6)
            self.netCommission.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetPayment(object):
    """
    Attributes:
     - afcDealId
     - grossCommission
     - teamCI
     - agentAllocations
     - agentNetPayment
     - paymentDate
     - paymentDateString
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcDealId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'grossCommission', (NetPaymentGCI, NetPaymentGCI.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'teamCI', (NetPaymentTeamCommission, NetPaymentTeamCommission.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'agentAllocations', (TType.STRUCT, (NetPaymentAgentAllocation, NetPaymentAgentAllocation.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'agentNetPayment', (NetPaymentAgent, NetPaymentAgent.thrift_spec), None, ),  # 5
        (6, TType.I64, 'paymentDate', None, None, ),  # 6
        (7, TType.STRING, 'paymentDateString', 'UTF8', None, ),  # 7
    )
    def __init__(self, afcDealId=None, grossCommission=None, teamCI=None, agentAllocations=None, agentNetPayment=None, paymentDate=None, paymentDateString=None, ):
        self.afcDealId = afcDealId
        self.grossCommission = grossCommission
        self.teamCI = teamCI
        self.agentAllocations = agentAllocations
        self.agentNetPayment = agentNetPayment
        self.paymentDate = paymentDate
        self.paymentDateString = paymentDateString

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcDealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.grossCommission = NetPaymentGCI()
                    self.grossCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.teamCI = NetPaymentTeamCommission()
                    self.teamCI.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.agentAllocations = []
                    (_etype110, _size113) = iprot.readListBegin()
                    for _i111 in range(_size113):
                        _elem112 = NetPaymentAgentAllocation()
                        _elem112.read(iprot)
                        self.agentAllocations.append(_elem112)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.agentNetPayment = NetPaymentAgent()
                    self.agentNetPayment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.paymentDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.paymentDateString = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetPayment')
        if self.afcDealId is not None:
            oprot.writeFieldBegin('afcDealId', TType.STRING, 1)
            oprot.writeString(self.afcDealId.encode('utf-8') if sys.version_info[0] == 2 else self.afcDealId)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.STRUCT, 2)
            self.grossCommission.write(oprot)
            oprot.writeFieldEnd()
        if self.teamCI is not None:
            oprot.writeFieldBegin('teamCI', TType.STRUCT, 3)
            self.teamCI.write(oprot)
            oprot.writeFieldEnd()
        if self.agentAllocations is not None:
            oprot.writeFieldBegin('agentAllocations', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.agentAllocations))
            for _iter114 in self.agentAllocations:
                _iter114.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentNetPayment is not None:
            oprot.writeFieldBegin('agentNetPayment', TType.STRUCT, 5)
            self.agentNetPayment.write(oprot)
            oprot.writeFieldEnd()
        if self.paymentDate is not None:
            oprot.writeFieldBegin('paymentDate', TType.I64, 6)
            oprot.writeI64(self.paymentDate)
            oprot.writeFieldEnd()
        if self.paymentDateString is not None:
            oprot.writeFieldBegin('paymentDateString', TType.STRING, 7)
            oprot.writeString(self.paymentDateString.encode('utf-8') if sys.version_info[0] == 2 else self.paymentDateString)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Team(object):
    """
    Attributes:
     - afcTeamId
     - teamName
     - lastUpdatedTime
     - members
     - historicalMembers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcTeamId', 'UTF8', None, ),  # 1
        None,  # 2
        (3, TType.STRING, 'teamName', 'UTF8', None, ),  # 3
        (4, TType.I64, 'lastUpdatedTime', None, None, ),  # 4
        (5, TType.LIST, 'members', (TType.STRUCT, (User, User.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'historicalMembers', (TType.STRUCT, (User, User.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, afcTeamId=None, teamName=None, lastUpdatedTime=None, members=None, historicalMembers=None, ):
        self.afcTeamId = afcTeamId
        self.teamName = teamName
        self.lastUpdatedTime = lastUpdatedTime
        self.members = members
        self.historicalMembers = historicalMembers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.teamName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.lastUpdatedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.members = []
                    (_etype115, _size118) = iprot.readListBegin()
                    for _i116 in range(_size118):
                        _elem117 = User()
                        _elem117.read(iprot)
                        self.members.append(_elem117)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.historicalMembers = []
                    (_etype119, _size122) = iprot.readListBegin()
                    for _i120 in range(_size122):
                        _elem121 = User()
                        _elem121.read(iprot)
                        self.historicalMembers.append(_elem121)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Team')
        if self.afcTeamId is not None:
            oprot.writeFieldBegin('afcTeamId', TType.STRING, 1)
            oprot.writeString(self.afcTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.afcTeamId)
            oprot.writeFieldEnd()
        if self.teamName is not None:
            oprot.writeFieldBegin('teamName', TType.STRING, 3)
            oprot.writeString(self.teamName.encode('utf-8') if sys.version_info[0] == 2 else self.teamName)
            oprot.writeFieldEnd()
        if self.lastUpdatedTime is not None:
            oprot.writeFieldBegin('lastUpdatedTime', TType.I64, 4)
            oprot.writeI64(self.lastUpdatedTime)
            oprot.writeFieldEnd()
        if self.members is not None:
            oprot.writeFieldBegin('members', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.members))
            for _iter123 in self.members:
                _iter123.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.historicalMembers is not None:
            oprot.writeFieldBegin('historicalMembers', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.historicalMembers))
            for _iter124 in self.historicalMembers:
                _iter124.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamSummaryEntry(object):
    """
    Attributes:
     - user
     - numberOfTransactions
     - averageSalesVolume
     - netCommission
     - agentNetCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'user', (User, User.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'numberOfTransactions', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'averageSalesVolume', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'netCommission', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'agentNetCommission', 'UTF8', None, ),  # 5
    )
    def __init__(self, user=None, numberOfTransactions=None, averageSalesVolume=None, netCommission=None, agentNetCommission=None, ):
        self.user = user
        self.numberOfTransactions = numberOfTransactions
        self.averageSalesVolume = averageSalesVolume
        self.netCommission = netCommission
        self.agentNetCommission = agentNetCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.user = User()
                    self.user.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.numberOfTransactions = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.averageSalesVolume = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.netCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.agentNetCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamSummaryEntry')
        if self.user is not None:
            oprot.writeFieldBegin('user', TType.STRUCT, 1)
            self.user.write(oprot)
            oprot.writeFieldEnd()
        if self.numberOfTransactions is not None:
            oprot.writeFieldBegin('numberOfTransactions', TType.STRING, 2)
            oprot.writeString(self.numberOfTransactions.encode('utf-8') if sys.version_info[0] == 2 else self.numberOfTransactions)
            oprot.writeFieldEnd()
        if self.averageSalesVolume is not None:
            oprot.writeFieldBegin('averageSalesVolume', TType.STRING, 3)
            oprot.writeString(self.averageSalesVolume.encode('utf-8') if sys.version_info[0] == 2 else self.averageSalesVolume)
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRING, 4)
            oprot.writeString(self.netCommission.encode('utf-8') if sys.version_info[0] == 2 else self.netCommission)
            oprot.writeFieldEnd()
        if self.agentNetCommission is not None:
            oprot.writeFieldBegin('agentNetCommission', TType.STRING, 5)
            oprot.writeString(self.agentNetCommission.encode('utf-8') if sys.version_info[0] == 2 else self.agentNetCommission)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealsAggregatedSummary(object):
    """
    Attributes:
     - type
     - grossCommission
     - volume
     - numberOfDeals
     - typeEntries
     - netCommission
     - averageSalesVolume
     - averageSalesVolumePercentChange
     - totalGrossCommission
     - totalGrossCommissionPercentChange
     - totalVolume
     - totalVolumePercentChange
     - totalNetCommission
     - totalNetCommissionPercentChange
     - associatedAgentsAfcIds
     - totalNumberOfDeals
     - totalNumberOfDealsPercentChange
     - agents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'type', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'grossCommission', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'volume', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'numberOfDeals', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 4
        (5, TType.LIST, 'typeEntries', (TType.STRUCT, (DealTypeAggregatedEntry, DealTypeAggregatedEntry.thrift_spec), False), None, ),  # 5
        (6, TType.STRUCT, 'netCommission', (DealPeriodData, DealPeriodData.thrift_spec), None, ),  # 6
        (7, TType.STRING, 'averageSalesVolume', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'averageSalesVolumePercentChange', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'totalGrossCommission', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'totalGrossCommissionPercentChange', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'totalVolume', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'totalVolumePercentChange', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'totalNetCommission', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'totalNetCommissionPercentChange', 'UTF8', None, ),  # 14
        (15, TType.LIST, 'associatedAgentsAfcIds', (TType.STRING, 'UTF8', False), None, ),  # 15
        (16, TType.STRING, 'totalNumberOfDeals', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'totalNumberOfDealsPercentChange', 'UTF8', None, ),  # 17
        (18, TType.LIST, 'agents', (TType.STRUCT, (DealCommission, DealCommission.thrift_spec), False), None, ),  # 18
    )
    def __init__(self, type=None, grossCommission=None, volume=None, numberOfDeals=None, typeEntries=None, netCommission=None, averageSalesVolume=None, averageSalesVolumePercentChange=None, totalGrossCommission=None, totalGrossCommissionPercentChange=None, totalVolume=None, totalVolumePercentChange=None, totalNetCommission=None, totalNetCommissionPercentChange=None, associatedAgentsAfcIds=None, totalNumberOfDeals=None, totalNumberOfDealsPercentChange=None, agents=None, ):
        self.type = type
        self.grossCommission = grossCommission
        self.volume = volume
        self.numberOfDeals = numberOfDeals
        self.typeEntries = typeEntries
        self.netCommission = netCommission
        self.averageSalesVolume = averageSalesVolume
        self.averageSalesVolumePercentChange = averageSalesVolumePercentChange
        self.totalGrossCommission = totalGrossCommission
        self.totalGrossCommissionPercentChange = totalGrossCommissionPercentChange
        self.totalVolume = totalVolume
        self.totalVolumePercentChange = totalVolumePercentChange
        self.totalNetCommission = totalNetCommission
        self.totalNetCommissionPercentChange = totalNetCommissionPercentChange
        self.associatedAgentsAfcIds = associatedAgentsAfcIds
        self.totalNumberOfDeals = totalNumberOfDeals
        self.totalNumberOfDealsPercentChange = totalNumberOfDealsPercentChange
        self.agents = agents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.grossCommission = DealPeriodData()
                    self.grossCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.volume = DealPeriodData()
                    self.volume.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.numberOfDeals = DealPeriodData()
                    self.numberOfDeals.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.typeEntries = []
                    (_etype125, _size128) = iprot.readListBegin()
                    for _i126 in range(_size128):
                        _elem127 = DealTypeAggregatedEntry()
                        _elem127.read(iprot)
                        self.typeEntries.append(_elem127)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.netCommission = DealPeriodData()
                    self.netCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.averageSalesVolume = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.averageSalesVolumePercentChange = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.totalGrossCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.totalGrossCommissionPercentChange = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.totalVolume = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.totalVolumePercentChange = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.totalNetCommission = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.totalNetCommissionPercentChange = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.associatedAgentsAfcIds = []
                    (_etype129, _size132) = iprot.readListBegin()
                    for _i130 in range(_size132):
                        _elem131 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.associatedAgentsAfcIds.append(_elem131)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.totalNumberOfDeals = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.totalNumberOfDealsPercentChange = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.LIST:
                    self.agents = []
                    (_etype133, _size136) = iprot.readListBegin()
                    for _i134 in range(_size136):
                        _elem135 = DealCommission()
                        _elem135.read(iprot)
                        self.agents.append(_elem135)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealsAggregatedSummary')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 1)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.STRUCT, 2)
            self.grossCommission.write(oprot)
            oprot.writeFieldEnd()
        if self.volume is not None:
            oprot.writeFieldBegin('volume', TType.STRUCT, 3)
            self.volume.write(oprot)
            oprot.writeFieldEnd()
        if self.numberOfDeals is not None:
            oprot.writeFieldBegin('numberOfDeals', TType.STRUCT, 4)
            self.numberOfDeals.write(oprot)
            oprot.writeFieldEnd()
        if self.typeEntries is not None:
            oprot.writeFieldBegin('typeEntries', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.typeEntries))
            for _iter137 in self.typeEntries:
                _iter137.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.netCommission is not None:
            oprot.writeFieldBegin('netCommission', TType.STRUCT, 6)
            self.netCommission.write(oprot)
            oprot.writeFieldEnd()
        if self.averageSalesVolume is not None:
            oprot.writeFieldBegin('averageSalesVolume', TType.STRING, 7)
            oprot.writeString(self.averageSalesVolume.encode('utf-8') if sys.version_info[0] == 2 else self.averageSalesVolume)
            oprot.writeFieldEnd()
        if self.averageSalesVolumePercentChange is not None:
            oprot.writeFieldBegin('averageSalesVolumePercentChange', TType.STRING, 8)
            oprot.writeString(self.averageSalesVolumePercentChange.encode('utf-8') if sys.version_info[0] == 2 else self.averageSalesVolumePercentChange)
            oprot.writeFieldEnd()
        if self.totalGrossCommission is not None:
            oprot.writeFieldBegin('totalGrossCommission', TType.STRING, 9)
            oprot.writeString(self.totalGrossCommission.encode('utf-8') if sys.version_info[0] == 2 else self.totalGrossCommission)
            oprot.writeFieldEnd()
        if self.totalGrossCommissionPercentChange is not None:
            oprot.writeFieldBegin('totalGrossCommissionPercentChange', TType.STRING, 10)
            oprot.writeString(self.totalGrossCommissionPercentChange.encode('utf-8') if sys.version_info[0] == 2 else self.totalGrossCommissionPercentChange)
            oprot.writeFieldEnd()
        if self.totalVolume is not None:
            oprot.writeFieldBegin('totalVolume', TType.STRING, 11)
            oprot.writeString(self.totalVolume.encode('utf-8') if sys.version_info[0] == 2 else self.totalVolume)
            oprot.writeFieldEnd()
        if self.totalVolumePercentChange is not None:
            oprot.writeFieldBegin('totalVolumePercentChange', TType.STRING, 12)
            oprot.writeString(self.totalVolumePercentChange.encode('utf-8') if sys.version_info[0] == 2 else self.totalVolumePercentChange)
            oprot.writeFieldEnd()
        if self.totalNetCommission is not None:
            oprot.writeFieldBegin('totalNetCommission', TType.STRING, 13)
            oprot.writeString(self.totalNetCommission.encode('utf-8') if sys.version_info[0] == 2 else self.totalNetCommission)
            oprot.writeFieldEnd()
        if self.totalNetCommissionPercentChange is not None:
            oprot.writeFieldBegin('totalNetCommissionPercentChange', TType.STRING, 14)
            oprot.writeString(self.totalNetCommissionPercentChange.encode('utf-8') if sys.version_info[0] == 2 else self.totalNetCommissionPercentChange)
            oprot.writeFieldEnd()
        if self.associatedAgentsAfcIds is not None:
            oprot.writeFieldBegin('associatedAgentsAfcIds', TType.LIST, 15)
            oprot.writeListBegin(TType.STRING, len(self.associatedAgentsAfcIds))
            for _iter138 in self.associatedAgentsAfcIds:
                oprot.writeString(_iter138.encode('utf-8') if sys.version_info[0] == 2 else _iter138)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalNumberOfDeals is not None:
            oprot.writeFieldBegin('totalNumberOfDeals', TType.STRING, 16)
            oprot.writeString(self.totalNumberOfDeals.encode('utf-8') if sys.version_info[0] == 2 else self.totalNumberOfDeals)
            oprot.writeFieldEnd()
        if self.totalNumberOfDealsPercentChange is not None:
            oprot.writeFieldBegin('totalNumberOfDealsPercentChange', TType.STRING, 17)
            oprot.writeString(self.totalNumberOfDealsPercentChange.encode('utf-8') if sys.version_info[0] == 2 else self.totalNumberOfDealsPercentChange)
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.LIST, 18)
            oprot.writeListBegin(TType.STRUCT, len(self.agents))
            for _iter139 in self.agents:
                _iter139.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Query(object):
    """
    Attributes:
     - collectionOptions
     - startTime
     - endTime
     - resolution
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'collectionOptions', (TType.STRING, 'UTF8', TType.STRUCT, (CollectionOptions, CollectionOptions.thrift_spec), False), None, ),  # 1
        (2, TType.I64, 'startTime', None, None, ),  # 2
        (3, TType.I64, 'endTime', None, None, ),  # 3
        (4, TType.STRING, 'resolution', 'UTF8', None, ),  # 4
    )
    def __init__(self, collectionOptions=None, startTime=None, endTime=None, resolution=None, ):
        self.collectionOptions = collectionOptions
        self.startTime = startTime
        self.endTime = endTime
        self.resolution = resolution

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.collectionOptions = {}
                    (_ktype141, _vtype142, _size145) = iprot.readMapBegin()
                    for _i140 in range(_size145):
                        _key143 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val144 = CollectionOptions()
                        _val144.read(iprot)
                        self.collectionOptions[_key143] = _val144
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.startTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.endTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.resolution = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Query')
        if self.collectionOptions is not None:
            oprot.writeFieldBegin('collectionOptions', TType.MAP, 1)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.collectionOptions))
            for _kiter146, _viter147 in self.collectionOptions.items():
                oprot.writeString(_kiter146.encode('utf-8') if sys.version_info[0] == 2 else _kiter146)
                _viter147.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.startTime is not None:
            oprot.writeFieldBegin('startTime', TType.I64, 2)
            oprot.writeI64(self.startTime)
            oprot.writeFieldEnd()
        if self.endTime is not None:
            oprot.writeFieldBegin('endTime', TType.I64, 3)
            oprot.writeI64(self.endTime)
            oprot.writeFieldEnd()
        if self.resolution is not None:
            oprot.writeFieldBegin('resolution', TType.STRING, 4)
            oprot.writeString(self.resolution.encode('utf-8') if sys.version_info[0] == 2 else self.resolution)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamSummary(object):
    """
    Attributes:
     - entries
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'entries', (TType.STRUCT, (TeamSummaryEntry, TeamSummaryEntry.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, entries=None, ):
        self.entries = entries

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.entries = []
                    (_etype148, _size151) = iprot.readListBegin()
                    for _i149 in range(_size151):
                        _elem150 = TeamSummaryEntry()
                        _elem150.read(iprot)
                        self.entries.append(_elem150)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamSummary')
        if self.entries is not None:
            oprot.writeFieldBegin('entries', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.entries))
            for _iter152 in self.entries:
                _iter152.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
