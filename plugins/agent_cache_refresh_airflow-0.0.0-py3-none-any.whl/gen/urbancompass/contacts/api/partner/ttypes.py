
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class UserRole(object):
    ADMIN = 0
    MEMBER = 1

    _VALUES_TO_NAMES = {
        0: "ADMIN",
        1: "MEMBER",
    }

    _NAMES_TO_VALUES = {
        "ADMIN": 0,
        "MEMBER": 1,
    }


class UserStatus(object):
    ACTIVE = 0
    INACTIVE = 1

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "INACTIVE",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "INACTIVE": 1,
    }


class PartnerCustomFieldIds(object):
    """
    Attributes:
     - geography
     - source
     - invitedBy
     - updatedAt
     - sourceDetail
     - sellerScore
     - sellerScoreDate
     - inviteSentAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'geography', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'source', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'invitedBy', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'updatedAt', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'sourceDetail', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'sellerScore', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'sellerScoreDate', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'inviteSentAt', 'UTF8', None, ),  # 8
    )
    def __init__(self, geography=None, source=None, invitedBy=None, updatedAt=None, sourceDetail=None, sellerScore=None, sellerScoreDate=None, inviteSentAt=None, ):
        self.geography = geography
        self.source = source
        self.invitedBy = invitedBy
        self.updatedAt = updatedAt
        self.sourceDetail = sourceDetail
        self.sellerScore = sellerScore
        self.sellerScoreDate = sellerScoreDate
        self.inviteSentAt = inviteSentAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.geography = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.invitedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.updatedAt = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.sourceDetail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.sellerScore = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.sellerScoreDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.inviteSentAt = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PartnerCustomFieldIds')
        if self.geography is not None:
            oprot.writeFieldBegin('geography', TType.STRING, 1)
            oprot.writeString(self.geography.encode('utf-8') if sys.version_info[0] == 2 else self.geography)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 2)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        if self.invitedBy is not None:
            oprot.writeFieldBegin('invitedBy', TType.STRING, 3)
            oprot.writeString(self.invitedBy.encode('utf-8') if sys.version_info[0] == 2 else self.invitedBy)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.STRING, 4)
            oprot.writeString(self.updatedAt.encode('utf-8') if sys.version_info[0] == 2 else self.updatedAt)
            oprot.writeFieldEnd()
        if self.sourceDetail is not None:
            oprot.writeFieldBegin('sourceDetail', TType.STRING, 5)
            oprot.writeString(self.sourceDetail.encode('utf-8') if sys.version_info[0] == 2 else self.sourceDetail)
            oprot.writeFieldEnd()
        if self.sellerScore is not None:
            oprot.writeFieldBegin('sellerScore', TType.STRING, 6)
            oprot.writeString(self.sellerScore.encode('utf-8') if sys.version_info[0] == 2 else self.sellerScore)
            oprot.writeFieldEnd()
        if self.sellerScoreDate is not None:
            oprot.writeFieldBegin('sellerScoreDate', TType.STRING, 7)
            oprot.writeString(self.sellerScoreDate.encode('utf-8') if sys.version_info[0] == 2 else self.sellerScoreDate)
            oprot.writeFieldEnd()
        if self.inviteSentAt is not None:
            oprot.writeFieldBegin('inviteSentAt', TType.STRING, 8)
            oprot.writeString(self.inviteSentAt.encode('utf-8') if sys.version_info[0] == 2 else self.inviteSentAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class User(object):
    """
    Attributes:
     - id
     - externalID
     - firstName
     - lastName
     - email
     - teamID
     - status
     - role
     - avatarUrl
     - phoneNumber
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'externalID', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'firstName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'lastName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'email', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'teamID', 'UTF8', None, ),  # 6
        (7, TType.I32, 'status', None, None, ),  # 7
        (8, TType.I32, 'role', None, None, ),  # 8
        (9, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'phoneNumber', 'UTF8', None, ),  # 10
    )
    def __init__(self, id=None, externalID=None, firstName=None, lastName=None, email=None, teamID=None, status=None, role=None, avatarUrl=None, phoneNumber=None, ):
        self.id = id
        self.externalID = externalID
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.teamID = teamID
        self.status = status
        self.role = role
        self.avatarUrl = avatarUrl
        self.phoneNumber = phoneNumber

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.externalID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.teamID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.role = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.phoneNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('User')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.externalID is not None:
            oprot.writeFieldBegin('externalID', TType.STRING, 2)
            oprot.writeString(self.externalID.encode('utf-8') if sys.version_info[0] == 2 else self.externalID)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 3)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 4)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 5)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.teamID is not None:
            oprot.writeFieldBegin('teamID', TType.STRING, 6)
            oprot.writeString(self.teamID.encode('utf-8') if sys.version_info[0] == 2 else self.teamID)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 7)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.I32, 8)
            oprot.writeI32(self.role)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 9)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.phoneNumber is not None:
            oprot.writeFieldBegin('phoneNumber', TType.STRING, 10)
            oprot.writeString(self.phoneNumber.encode('utf-8') if sys.version_info[0] == 2 else self.phoneNumber)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
