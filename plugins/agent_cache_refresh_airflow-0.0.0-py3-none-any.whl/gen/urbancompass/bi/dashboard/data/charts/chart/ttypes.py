
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.charts.key_insights_chart.ttypes
import gen.urbancompass.bi.dashboard.data.charts.list_chart.ttypes
import gen.urbancompass.bi.dashboard.data.charts.map_chart.ttypes
import gen.urbancompass.bi.dashboard.data.charts.pie_chart.ttypes
import gen.urbancompass.bi.dashboard.data.charts.single_metric_button.ttypes
import gen.urbancompass.bi.dashboard.data.charts.single_metric_chart.ttypes
import gen.urbancompass.bi.dashboard.data.charts.table_chart.ttypes
import gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes

from thrift.transport import TTransport


class Chart(object):
    """
    Attributes:
     - pieChart
     - keyInsightsChart
     - mapChart
     - singleMetricChart
     - tableChart
     - xyChart
     - singleMetricButton
     - listChart
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'pieChart', (gen.urbancompass.bi.dashboard.data.charts.pie_chart.ttypes.PieChart, gen.urbancompass.bi.dashboard.data.charts.pie_chart.ttypes.PieChart.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'keyInsightsChart', (gen.urbancompass.bi.dashboard.data.charts.key_insights_chart.ttypes.KeyInsightsChart, gen.urbancompass.bi.dashboard.data.charts.key_insights_chart.ttypes.KeyInsightsChart.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'mapChart', (gen.urbancompass.bi.dashboard.data.charts.map_chart.ttypes.MapChart, gen.urbancompass.bi.dashboard.data.charts.map_chart.ttypes.MapChart.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'singleMetricChart', (gen.urbancompass.bi.dashboard.data.charts.single_metric_chart.ttypes.SingleMetricChart, gen.urbancompass.bi.dashboard.data.charts.single_metric_chart.ttypes.SingleMetricChart.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'tableChart', (gen.urbancompass.bi.dashboard.data.charts.table_chart.ttypes.TableChart, gen.urbancompass.bi.dashboard.data.charts.table_chart.ttypes.TableChart.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'xyChart', (gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes.XYChart, gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes.XYChart.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'singleMetricButton', (gen.urbancompass.bi.dashboard.data.charts.single_metric_button.ttypes.SingleMetricButton, gen.urbancompass.bi.dashboard.data.charts.single_metric_button.ttypes.SingleMetricButton.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'listChart', (gen.urbancompass.bi.dashboard.data.charts.list_chart.ttypes.ListChart, gen.urbancompass.bi.dashboard.data.charts.list_chart.ttypes.ListChart.thrift_spec), None, ),  # 8
    )
    def __init__(self, pieChart=None, keyInsightsChart=None, mapChart=None, singleMetricChart=None, tableChart=None, xyChart=None, singleMetricButton=None, listChart=None, ):
        self.pieChart = pieChart
        self.keyInsightsChart = keyInsightsChart
        self.mapChart = mapChart
        self.singleMetricChart = singleMetricChart
        self.tableChart = tableChart
        self.xyChart = xyChart
        self.singleMetricButton = singleMetricButton
        self.listChart = listChart

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.pieChart = gen.urbancompass.bi.dashboard.data.charts.pie_chart.ttypes.PieChart()
                    self.pieChart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.keyInsightsChart = gen.urbancompass.bi.dashboard.data.charts.key_insights_chart.ttypes.KeyInsightsChart()
                    self.keyInsightsChart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.mapChart = gen.urbancompass.bi.dashboard.data.charts.map_chart.ttypes.MapChart()
                    self.mapChart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.singleMetricChart = gen.urbancompass.bi.dashboard.data.charts.single_metric_chart.ttypes.SingleMetricChart()
                    self.singleMetricChart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.tableChart = gen.urbancompass.bi.dashboard.data.charts.table_chart.ttypes.TableChart()
                    self.tableChart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.xyChart = gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes.XYChart()
                    self.xyChart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.singleMetricButton = gen.urbancompass.bi.dashboard.data.charts.single_metric_button.ttypes.SingleMetricButton()
                    self.singleMetricButton.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.listChart = gen.urbancompass.bi.dashboard.data.charts.list_chart.ttypes.ListChart()
                    self.listChart.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Chart')
        if self.pieChart is not None:
            oprot.writeFieldBegin('pieChart', TType.STRUCT, 1)
            self.pieChart.write(oprot)
            oprot.writeFieldEnd()
        if self.keyInsightsChart is not None:
            oprot.writeFieldBegin('keyInsightsChart', TType.STRUCT, 2)
            self.keyInsightsChart.write(oprot)
            oprot.writeFieldEnd()
        if self.mapChart is not None:
            oprot.writeFieldBegin('mapChart', TType.STRUCT, 3)
            self.mapChart.write(oprot)
            oprot.writeFieldEnd()
        if self.singleMetricChart is not None:
            oprot.writeFieldBegin('singleMetricChart', TType.STRUCT, 4)
            self.singleMetricChart.write(oprot)
            oprot.writeFieldEnd()
        if self.tableChart is not None:
            oprot.writeFieldBegin('tableChart', TType.STRUCT, 5)
            self.tableChart.write(oprot)
            oprot.writeFieldEnd()
        if self.xyChart is not None:
            oprot.writeFieldBegin('xyChart', TType.STRUCT, 6)
            self.xyChart.write(oprot)
            oprot.writeFieldEnd()
        if self.singleMetricButton is not None:
            oprot.writeFieldBegin('singleMetricButton', TType.STRUCT, 7)
            self.singleMetricButton.write(oprot)
            oprot.writeFieldEnd()
        if self.listChart is not None:
            oprot.writeFieldBegin('listChart', TType.STRUCT, 8)
            self.listChart.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
