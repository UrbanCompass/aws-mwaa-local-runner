
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes
import gen.urbancompass.bi.dashboard.data.visibility.ttypes

from thrift.transport import TTransport


class SingleXMultipleYChartItemStyle(object):
    XY = 0
    SINGLE_STACKED_BAR = 1
    MULTI_STACKED_BAR = 2

    _VALUES_TO_NAMES = {
        0: "XY",
        1: "SINGLE_STACKED_BAR",
        2: "MULTI_STACKED_BAR",
    }

    _NAMES_TO_VALUES = {
        "XY": 0,
        "SINGLE_STACKED_BAR": 1,
        "MULTI_STACKED_BAR": 2,
    }


class SingleXSingleYChartItemStyle(object):
    BAR = 0
    LINE = 1
    SPLINE = 2
    SCATTER = 3

    _VALUES_TO_NAMES = {
        0: "BAR",
        1: "LINE",
        2: "SPLINE",
        3: "SCATTER",
    }

    _NAMES_TO_VALUES = {
        "BAR": 0,
        "LINE": 1,
        "SPLINE": 2,
        "SCATTER": 3,
    }


class XYAxialOrientation(object):
    PRIMARY_Y = 0
    SECONDARY_Y = 1
    PRIMARY_Y_ROTATED = 2

    _VALUES_TO_NAMES = {
        0: "PRIMARY_Y",
        1: "SECONDARY_Y",
        2: "PRIMARY_Y_ROTATED",
    }

    _NAMES_TO_VALUES = {
        "PRIMARY_Y": 0,
        "SECONDARY_Y": 1,
        "PRIMARY_Y_ROTATED": 2,
    }


class XyChartType(object):
    BAR = 0
    LINE = 1
    STACKED_BAR = 2
    COLUMN = 3

    _VALUES_TO_NAMES = {
        0: "BAR",
        1: "LINE",
        2: "STACKED_BAR",
        3: "COLUMN",
    }

    _NAMES_TO_VALUES = {
        "BAR": 0,
        "LINE": 1,
        "STACKED_BAR": 2,
        "COLUMN": 3,
    }


class AnnotatedSeriesRef(object):
    """
    Attributes:
     - seriesRef
     - color
     - visibility
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'seriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'color', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'visibility', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings.thrift_spec), None, ),  # 3
    )
    def __init__(self, seriesRef=None, color=None, visibility=None, ):
        self.seriesRef = seriesRef
        self.color = color
        self.visibility = visibility

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.seriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.seriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.color = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.visibility = gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings()
                    self.visibility.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AnnotatedSeriesRef')
        if self.seriesRef is not None:
            oprot.writeFieldBegin('seriesRef', TType.STRUCT, 1)
            self.seriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.color is not None:
            oprot.writeFieldBegin('color', TType.STRING, 2)
            oprot.writeString(self.color.encode('utf-8') if sys.version_info[0] == 2 else self.color)
            oprot.writeFieldEnd()
        if self.visibility is not None:
            oprot.writeFieldBegin('visibility', TType.STRUCT, 3)
            self.visibility.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class XYChartSettings(object):
    """
    Attributes:
     - xAxisSettings
     - yAxisSettings
     - y2AxisSettings
     - includeLegend
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'xAxisSettings', (gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings, gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'yAxisSettings', (gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings, gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'y2AxisSettings', (gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings, gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'includeLegend', None, None, ),  # 4
    )
    def __init__(self, xAxisSettings=None, yAxisSettings=None, y2AxisSettings=None, includeLegend=None, ):
        self.xAxisSettings = xAxisSettings
        self.yAxisSettings = yAxisSettings
        self.y2AxisSettings = y2AxisSettings
        self.includeLegend = includeLegend

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.xAxisSettings = gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings()
                    self.xAxisSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.yAxisSettings = gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings()
                    self.yAxisSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.y2AxisSettings = gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes.AxisSettings()
                    self.y2AxisSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.includeLegend = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('XYChartSettings')
        if self.xAxisSettings is not None:
            oprot.writeFieldBegin('xAxisSettings', TType.STRUCT, 1)
            self.xAxisSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.yAxisSettings is not None:
            oprot.writeFieldBegin('yAxisSettings', TType.STRUCT, 2)
            self.yAxisSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.y2AxisSettings is not None:
            oprot.writeFieldBegin('y2AxisSettings', TType.STRUCT, 3)
            self.y2AxisSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.includeLegend is not None:
            oprot.writeFieldBegin('includeLegend', TType.BOOL, 4)
            oprot.writeBool(self.includeLegend)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class XYLegendItem(object):
    """
    Attributes:
     - valueSeriesRef
     - comparisonValueSeriesRef
     - descriptionSeriesRef
     - text
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'valueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'comparisonValueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'descriptionSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'text', 'UTF8', None, ),  # 4
    )
    def __init__(self, valueSeriesRef=None, comparisonValueSeriesRef=None, descriptionSeriesRef=None, text=None, ):
        self.valueSeriesRef = valueSeriesRef
        self.comparisonValueSeriesRef = comparisonValueSeriesRef
        self.descriptionSeriesRef = descriptionSeriesRef
        self.text = text

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.valueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.valueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.comparisonValueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.comparisonValueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.descriptionSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.descriptionSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.text = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('XYLegendItem')
        if self.valueSeriesRef is not None:
            oprot.writeFieldBegin('valueSeriesRef', TType.STRUCT, 1)
            self.valueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.comparisonValueSeriesRef is not None:
            oprot.writeFieldBegin('comparisonValueSeriesRef', TType.STRUCT, 2)
            self.comparisonValueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.descriptionSeriesRef is not None:
            oprot.writeFieldBegin('descriptionSeriesRef', TType.STRUCT, 3)
            self.descriptionSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.text is not None:
            oprot.writeFieldBegin('text', TType.STRING, 4)
            oprot.writeString(self.text.encode('utf-8') if sys.version_info[0] == 2 else self.text)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SingleXMultipleYChartItem(object):
    """
    Attributes:
     - style
     - axialOrientation
     - xSeriesRef
     - ySeriesRefs
     - colors
     - summarySeriesRef
     - totalYSeriesRef
     - legendItem
     - visibility
     - annotatedYSeriesRefs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'style', None, None, ),  # 1
        (2, TType.I32, 'axialOrientation', None, None, ),  # 2
        (3, TType.STRUCT, 'xSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'ySeriesRefs', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'summarySeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'totalYSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'legendItem', (XYLegendItem, XYLegendItem.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'visibility', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings.thrift_spec), None, ),  # 8
        (9, TType.LIST, 'colors', (TType.STRING, 'UTF8', False), None, ),  # 9
        (10, TType.LIST, 'annotatedYSeriesRefs', (TType.STRUCT, (AnnotatedSeriesRef, AnnotatedSeriesRef.thrift_spec), False), None, ),  # 10
    )
    def __init__(self, style=None, axialOrientation=None, xSeriesRef=None, ySeriesRefs=None, summarySeriesRef=None, totalYSeriesRef=None, legendItem=None, visibility=None, colors=None, annotatedYSeriesRefs=None, ):
        self.style = style
        self.axialOrientation = axialOrientation
        self.xSeriesRef = xSeriesRef
        self.ySeriesRefs = ySeriesRefs
        self.summarySeriesRef = summarySeriesRef
        self.totalYSeriesRef = totalYSeriesRef
        self.legendItem = legendItem
        self.visibility = visibility
        self.colors = colors
        self.annotatedYSeriesRefs = annotatedYSeriesRefs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.style = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.axialOrientation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.xSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.xSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.ySeriesRefs = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                        _elem4.read(iprot)
                        self.ySeriesRefs.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.summarySeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.summarySeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.totalYSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.totalYSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.legendItem = XYLegendItem()
                    self.legendItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.visibility = gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings()
                    self.visibility.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.colors = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.colors.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.annotatedYSeriesRefs = []
                    (_etype10, _size13) = iprot.readListBegin()
                    for _i11 in range(_size13):
                        _elem12 = AnnotatedSeriesRef()
                        _elem12.read(iprot)
                        self.annotatedYSeriesRefs.append(_elem12)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SingleXMultipleYChartItem')
        if self.style is not None:
            oprot.writeFieldBegin('style', TType.I32, 1)
            oprot.writeI32(self.style)
            oprot.writeFieldEnd()
        if self.axialOrientation is not None:
            oprot.writeFieldBegin('axialOrientation', TType.I32, 2)
            oprot.writeI32(self.axialOrientation)
            oprot.writeFieldEnd()
        if self.xSeriesRef is not None:
            oprot.writeFieldBegin('xSeriesRef', TType.STRUCT, 3)
            self.xSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.ySeriesRefs is not None:
            oprot.writeFieldBegin('ySeriesRefs', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.ySeriesRefs))
            for _iter14 in self.ySeriesRefs:
                _iter14.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.summarySeriesRef is not None:
            oprot.writeFieldBegin('summarySeriesRef', TType.STRUCT, 5)
            self.summarySeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.totalYSeriesRef is not None:
            oprot.writeFieldBegin('totalYSeriesRef', TType.STRUCT, 6)
            self.totalYSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.legendItem is not None:
            oprot.writeFieldBegin('legendItem', TType.STRUCT, 7)
            self.legendItem.write(oprot)
            oprot.writeFieldEnd()
        if self.visibility is not None:
            oprot.writeFieldBegin('visibility', TType.STRUCT, 8)
            self.visibility.write(oprot)
            oprot.writeFieldEnd()
        if self.colors is not None:
            oprot.writeFieldBegin('colors', TType.LIST, 9)
            oprot.writeListBegin(TType.STRING, len(self.colors))
            for _iter15 in self.colors:
                oprot.writeString(_iter15.encode('utf-8') if sys.version_info[0] == 2 else _iter15)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.annotatedYSeriesRefs is not None:
            oprot.writeFieldBegin('annotatedYSeriesRefs', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.annotatedYSeriesRefs))
            for _iter16 in self.annotatedYSeriesRefs:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SingleXSingleYChartItem(object):
    """
    Attributes:
     - style
     - axialOrientation
     - xSeriesRef
     - ySeriesRef
     - legendItem
     - visibility
     - color
     - dropTrailingEmptyYPoints
     - dropLeadingEmptyYPoints
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'style', None, None, ),  # 1
        (2, TType.I32, 'axialOrientation', None, None, ),  # 2
        (3, TType.STRUCT, 'xSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'ySeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'legendItem', (XYLegendItem, XYLegendItem.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'visibility', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings.thrift_spec), None, ),  # 6
        (7, TType.STRING, 'color', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'dropTrailingEmptyYPoints', None, None, ),  # 8
        (9, TType.BOOL, 'dropLeadingEmptyYPoints', None, None, ),  # 9
    )
    def __init__(self, style=None, axialOrientation=None, xSeriesRef=None, ySeriesRef=None, legendItem=None, visibility=None, color=None, dropTrailingEmptyYPoints=None, dropLeadingEmptyYPoints=None, ):
        self.style = style
        self.axialOrientation = axialOrientation
        self.xSeriesRef = xSeriesRef
        self.ySeriesRef = ySeriesRef
        self.legendItem = legendItem
        self.visibility = visibility
        self.color = color
        self.dropTrailingEmptyYPoints = dropTrailingEmptyYPoints
        self.dropLeadingEmptyYPoints = dropLeadingEmptyYPoints

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.style = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.axialOrientation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.xSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.xSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.ySeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.ySeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.legendItem = XYLegendItem()
                    self.legendItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.visibility = gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings()
                    self.visibility.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.color = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.dropTrailingEmptyYPoints = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.dropLeadingEmptyYPoints = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SingleXSingleYChartItem')
        if self.style is not None:
            oprot.writeFieldBegin('style', TType.I32, 1)
            oprot.writeI32(self.style)
            oprot.writeFieldEnd()
        if self.axialOrientation is not None:
            oprot.writeFieldBegin('axialOrientation', TType.I32, 2)
            oprot.writeI32(self.axialOrientation)
            oprot.writeFieldEnd()
        if self.xSeriesRef is not None:
            oprot.writeFieldBegin('xSeriesRef', TType.STRUCT, 3)
            self.xSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.ySeriesRef is not None:
            oprot.writeFieldBegin('ySeriesRef', TType.STRUCT, 4)
            self.ySeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.legendItem is not None:
            oprot.writeFieldBegin('legendItem', TType.STRUCT, 5)
            self.legendItem.write(oprot)
            oprot.writeFieldEnd()
        if self.visibility is not None:
            oprot.writeFieldBegin('visibility', TType.STRUCT, 6)
            self.visibility.write(oprot)
            oprot.writeFieldEnd()
        if self.color is not None:
            oprot.writeFieldBegin('color', TType.STRING, 7)
            oprot.writeString(self.color.encode('utf-8') if sys.version_info[0] == 2 else self.color)
            oprot.writeFieldEnd()
        if self.dropTrailingEmptyYPoints is not None:
            oprot.writeFieldBegin('dropTrailingEmptyYPoints', TType.BOOL, 8)
            oprot.writeBool(self.dropTrailingEmptyYPoints)
            oprot.writeFieldEnd()
        if self.dropLeadingEmptyYPoints is not None:
            oprot.writeFieldBegin('dropLeadingEmptyYPoints', TType.BOOL, 9)
            oprot.writeBool(self.dropLeadingEmptyYPoints)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class XYChartItem(object):
    """
    Attributes:
     - singleXSingleYChartItem
     - singleXMultipleYChartItem
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'singleXSingleYChartItem', (SingleXSingleYChartItem, SingleXSingleYChartItem.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'singleXMultipleYChartItem', (SingleXMultipleYChartItem, SingleXMultipleYChartItem.thrift_spec), None, ),  # 2
    )
    def __init__(self, singleXSingleYChartItem=None, singleXMultipleYChartItem=None, ):
        self.singleXSingleYChartItem = singleXSingleYChartItem
        self.singleXMultipleYChartItem = singleXMultipleYChartItem

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.singleXSingleYChartItem = SingleXSingleYChartItem()
                    self.singleXSingleYChartItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.singleXMultipleYChartItem = SingleXMultipleYChartItem()
                    self.singleXMultipleYChartItem.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('XYChartItem')
        if self.singleXSingleYChartItem is not None:
            oprot.writeFieldBegin('singleXSingleYChartItem', TType.STRUCT, 1)
            self.singleXSingleYChartItem.write(oprot)
            oprot.writeFieldEnd()
        if self.singleXMultipleYChartItem is not None:
            oprot.writeFieldBegin('singleXMultipleYChartItem', TType.STRUCT, 2)
            self.singleXMultipleYChartItem.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class XYChart(object):
    """
    Attributes:
     - title
     - items
     - settings
     - description
     - icon
     - titleForReport
     - emptyView
     - subType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'items', (TType.STRUCT, (XYChartItem, XYChartItem.thrift_spec), False), None, ),  # 2
        (3, TType.STRUCT, 'settings', (XYChartSettings, XYChartSettings.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'description', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'icon', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'titleForReport', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'emptyView', (gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView, gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView.thrift_spec), None, ),  # 7
        (8, TType.I32, 'subType', None, None, ),  # 8
    )
    def __init__(self, title=None, items=None, settings=None, description=None, icon=None, titleForReport=None, emptyView=None, subType=None, ):
        self.title = title
        self.items = items
        self.settings = settings
        self.description = description
        self.icon = icon
        self.titleForReport = titleForReport
        self.emptyView = emptyView
        self.subType = subType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.items = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = XYChartItem()
                        _elem19.read(iprot)
                        self.items.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.settings = XYChartSettings()
                    self.settings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.icon = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.titleForReport = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.emptyView = gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView()
                    self.emptyView.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.subType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('XYChart')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.items is not None:
            oprot.writeFieldBegin('items', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.items))
            for _iter21 in self.items:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.settings is not None:
            oprot.writeFieldBegin('settings', TType.STRUCT, 3)
            self.settings.write(oprot)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 4)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.icon is not None:
            oprot.writeFieldBegin('icon', TType.STRING, 5)
            oprot.writeString(self.icon.encode('utf-8') if sys.version_info[0] == 2 else self.icon)
            oprot.writeFieldEnd()
        if self.titleForReport is not None:
            oprot.writeFieldBegin('titleForReport', TType.STRING, 6)
            oprot.writeString(self.titleForReport.encode('utf-8') if sys.version_info[0] == 2 else self.titleForReport)
            oprot.writeFieldEnd()
        if self.emptyView is not None:
            oprot.writeFieldBegin('emptyView', TType.STRUCT, 7)
            self.emptyView.write(oprot)
            oprot.writeFieldEnd()
        if self.subType is not None:
            oprot.writeFieldBegin('subType', TType.I32, 8)
            oprot.writeI32(self.subType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
