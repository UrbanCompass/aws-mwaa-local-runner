
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class DataProvider(object):
    DEALS = 0
    QUALIFIED_LEADS = 1
    TASKS = 2

    _VALUES_TO_NAMES = {
        0: "DEALS",
        1: "QUALIFIED_LEADS",
        2: "TASKS",
    }

    _NAMES_TO_VALUES = {
        "DEALS": 0,
        "QUALIFIED_LEADS": 1,
        "TASKS": 2,
    }


class EnrichError(object):
    """
    Attributes:
     - dataProvider
     - message
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'dataProvider', None, None, ),  # 1
        (2, TType.STRING, 'message', 'UTF8', None, ),  # 2
    )
    def __init__(self, dataProvider=None, message=None, ):
        self.dataProvider = dataProvider
        self.message = message

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.dataProvider = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.message = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichError')
        if self.dataProvider is not None:
            oprot.writeFieldBegin('dataProvider', TType.I32, 1)
            oprot.writeI32(self.dataProvider)
            oprot.writeFieldEnd()
        if self.message is not None:
            oprot.writeFieldBegin('message', TType.STRING, 2)
            oprot.writeString(self.message.encode('utf-8') if sys.version_info[0] == 2 else self.message)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
