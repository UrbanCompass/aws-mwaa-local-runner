
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class DataType(object):
    DATE = 0
    DATE_RANGE = 1
    VARCHAR = 2
    DECIMAL = 3
    LONG = 4
    INTEGER = 5
    BOOLEAN = 6
    USER_ID = 7
    SCALAR = 8

    _VALUES_TO_NAMES = {
        0: "DATE",
        1: "DATE_RANGE",
        2: "VARCHAR",
        3: "DECIMAL",
        4: "LONG",
        5: "INTEGER",
        6: "BOOLEAN",
        7: "USER_ID",
        8: "SCALAR",
    }

    _NAMES_TO_VALUES = {
        "DATE": 0,
        "DATE_RANGE": 1,
        "VARCHAR": 2,
        "DECIMAL": 3,
        "LONG": 4,
        "INTEGER": 5,
        "BOOLEAN": 6,
        "USER_ID": 7,
        "SCALAR": 8,
    }


class Date(object):
    """
    Attributes:
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'value', 'UTF8', None, ),  # 1
    )
    def __init__(self, value=None, ):
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Date')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 1)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DateRange(object):
    """
    Attributes:
     - startDate
     - endDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'startDate', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'endDate', 'UTF8', None, ),  # 2
    )
    def __init__(self, startDate=None, endDate=None, ):
        self.startDate = startDate
        self.endDate = endDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.startDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.endDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DateRange')
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.STRING, 1)
            oprot.writeString(self.startDate.encode('utf-8') if sys.version_info[0] == 2 else self.startDate)
            oprot.writeFieldEnd()
        if self.endDate is not None:
            oprot.writeFieldBegin('endDate', TType.STRING, 2)
            oprot.writeString(self.endDate.encode('utf-8') if sys.version_info[0] == 2 else self.endDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Primitive(object):
    """
    Attributes:
     - varchar
     - decimal
     - long
     - integer
     - boolean
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'varchar', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'decimal', None, None, ),  # 2
        (3, TType.I64, 'long', None, None, ),  # 3
        (4, TType.I32, 'integer', None, None, ),  # 4
        (5, TType.BOOL, 'boolean', None, None, ),  # 5
    )
    def __init__(self, varchar=None, decimal=None, long=None, integer=None, boolean=None, ):
        self.varchar = varchar
        self.decimal = decimal
        self.long = long
        self.integer = integer
        self.boolean = boolean

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.varchar = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.decimal = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.long = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.integer = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.boolean = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Primitive')
        if self.varchar is not None:
            oprot.writeFieldBegin('varchar', TType.STRING, 1)
            oprot.writeString(self.varchar.encode('utf-8') if sys.version_info[0] == 2 else self.varchar)
            oprot.writeFieldEnd()
        if self.decimal is not None:
            oprot.writeFieldBegin('decimal', TType.DOUBLE, 2)
            oprot.writeDouble(self.decimal)
            oprot.writeFieldEnd()
        if self.long is not None:
            oprot.writeFieldBegin('long', TType.I64, 3)
            oprot.writeI64(self.long)
            oprot.writeFieldEnd()
        if self.integer is not None:
            oprot.writeFieldBegin('integer', TType.I32, 4)
            oprot.writeI32(self.integer)
            oprot.writeFieldEnd()
        if self.boolean is not None:
            oprot.writeFieldBegin('boolean', TType.BOOL, 5)
            oprot.writeBool(self.boolean)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Scalar(object):
    """
    Attributes:
     - date
     - dateRange
     - primitive
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'date', (Date, Date.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dateRange', (DateRange, DateRange.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'primitive', (Primitive, Primitive.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
    )
    def __init__(self, date=None, dateRange=None, primitive=None, userId=None, ):
        self.date = date
        self.dateRange = dateRange
        self.primitive = primitive
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.date = Date()
                    self.date.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dateRange = DateRange()
                    self.dateRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.primitive = Primitive()
                    self.primitive.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Scalar')
        if self.date is not None:
            oprot.writeFieldBegin('date', TType.STRUCT, 1)
            self.date.write(oprot)
            oprot.writeFieldEnd()
        if self.dateRange is not None:
            oprot.writeFieldBegin('dateRange', TType.STRUCT, 2)
            self.dateRange.write(oprot)
            oprot.writeFieldEnd()
        if self.primitive is not None:
            oprot.writeFieldBegin('primitive', TType.STRUCT, 3)
            self.primitive.write(oprot)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Vector(object):
    """
    Attributes:
     - dates
     - dateRanges
     - varchars
     - decimals
     - longs
     - integers
     - booleans
     - userIds
     - scalars
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dates', (TType.STRUCT, (Date, Date.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'dateRanges', (TType.STRUCT, (DateRange, DateRange.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'varchars', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'decimals', (TType.DOUBLE, None, False), None, ),  # 4
        (5, TType.LIST, 'longs', (TType.I64, None, False), None, ),  # 5
        (6, TType.LIST, 'integers', (TType.I32, None, False), None, ),  # 6
        (7, TType.LIST, 'booleans', (TType.BOOL, None, False), None, ),  # 7
        (8, TType.LIST, 'userIds', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.LIST, 'scalars', (TType.STRUCT, (Scalar, Scalar.thrift_spec), False), None, ),  # 9
    )
    def __init__(self, dates=None, dateRanges=None, varchars=None, decimals=None, longs=None, integers=None, booleans=None, userIds=None, scalars=None, ):
        self.dates = dates
        self.dateRanges = dateRanges
        self.varchars = varchars
        self.decimals = decimals
        self.longs = longs
        self.integers = integers
        self.booleans = booleans
        self.userIds = userIds
        self.scalars = scalars

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dates = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = Date()
                        _elem4.read(iprot)
                        self.dates.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dateRanges = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = DateRange()
                        _elem8.read(iprot)
                        self.dateRanges.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.varchars = []
                    (_etype10, _size13) = iprot.readListBegin()
                    for _i11 in range(_size13):
                        _elem12 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.varchars.append(_elem12)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.decimals = []
                    (_etype14, _size17) = iprot.readListBegin()
                    for _i15 in range(_size17):
                        _elem16 = iprot.readDouble()
                        self.decimals.append(_elem16)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.longs = []
                    (_etype18, _size21) = iprot.readListBegin()
                    for _i19 in range(_size21):
                        _elem20 = iprot.readI64()
                        self.longs.append(_elem20)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.integers = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readI32()
                        self.integers.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.booleans = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = iprot.readBool()
                        self.booleans.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.userIds = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userIds.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.scalars = []
                    (_etype34, _size37) = iprot.readListBegin()
                    for _i35 in range(_size37):
                        _elem36 = Scalar()
                        _elem36.read(iprot)
                        self.scalars.append(_elem36)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Vector')
        if self.dates is not None:
            oprot.writeFieldBegin('dates', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.dates))
            for _iter38 in self.dates:
                _iter38.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dateRanges is not None:
            oprot.writeFieldBegin('dateRanges', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dateRanges))
            for _iter39 in self.dateRanges:
                _iter39.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.varchars is not None:
            oprot.writeFieldBegin('varchars', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.varchars))
            for _iter40 in self.varchars:
                oprot.writeString(_iter40.encode('utf-8') if sys.version_info[0] == 2 else _iter40)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.decimals is not None:
            oprot.writeFieldBegin('decimals', TType.LIST, 4)
            oprot.writeListBegin(TType.DOUBLE, len(self.decimals))
            for _iter41 in self.decimals:
                oprot.writeDouble(_iter41)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.longs is not None:
            oprot.writeFieldBegin('longs', TType.LIST, 5)
            oprot.writeListBegin(TType.I64, len(self.longs))
            for _iter42 in self.longs:
                oprot.writeI64(_iter42)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.integers is not None:
            oprot.writeFieldBegin('integers', TType.LIST, 6)
            oprot.writeListBegin(TType.I32, len(self.integers))
            for _iter43 in self.integers:
                oprot.writeI32(_iter43)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.booleans is not None:
            oprot.writeFieldBegin('booleans', TType.LIST, 7)
            oprot.writeListBegin(TType.BOOL, len(self.booleans))
            for _iter44 in self.booleans:
                oprot.writeBool(_iter44)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userIds is not None:
            oprot.writeFieldBegin('userIds', TType.LIST, 8)
            oprot.writeListBegin(TType.STRING, len(self.userIds))
            for _iter45 in self.userIds:
                oprot.writeString(_iter45.encode('utf-8') if sys.version_info[0] == 2 else _iter45)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.scalars is not None:
            oprot.writeFieldBegin('scalars', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.scalars))
            for _iter46 in self.scalars:
                _iter46.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
