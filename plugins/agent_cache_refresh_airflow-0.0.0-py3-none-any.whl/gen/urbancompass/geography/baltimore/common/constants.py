
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CITY_CLUSTER_ZOOM = 12
DEFAULT_CENTER_LATITUDE = 39.287791
DEFAULT_CENTER_LONGITUDE = -76.612124
DEFAULT_ZOOM = 11
FULL_DISPLAY_NAME = "Baltimore"
GEO_ID = "baltimore"
MAX_ZOOM = 19
MIN_ZOOM = 10
NEIGHBORHOOD_CLUSTER_ZOOM = 13
# else
SHORT_DISPLAY_NAME = "Baltimore"
# else
