
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CONTACTINFO_TYPE_TO_FIELD_NAME_MAP = {
    0: "",
    1: "cobrokerContacts",
    2: "managementCompaniesContacts",
    3: "leasingOfficeContacts",
    4: "salesOfficeContacts",
    5: "accessContactContacts",
    6: "agentContacts",
    7: "closingContactContacts",
    8: "landlordContacts",
    9: "tenantContacts",
    10: "coexclusiveBrokerContacts",
    11: "managingAgentContacts",
    12: "accountExecutiveContacts",
    13: "transferAgentContacts",
    14: "closingAgentContacts",
    15: "doormanContacts",
}
LICENSE_PREFIX_DEFAULT = "License #"
STATE_TO_LICENSE_PREFIX = {
    "CA": "DRE #",
    "TX": "TREC #",
}
