
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.user.user.ttypes

from thrift.transport import TTransport


class SocialProfileType(object):
    FACEBOOK = 0
    INSTAGRAM = 1
    LINKEDIN = 2
    PINTEREST = 3
    TWITTER = 4

    _VALUES_TO_NAMES = {
        0: "FACEBOOK",
        1: "INSTAGRAM",
        2: "LINKEDIN",
        3: "PINTEREST",
        4: "TWITTER",
    }

    _NAMES_TO_VALUES = {
        "FACEBOOK": 0,
        "INSTAGRAM": 1,
        "LINKEDIN": 2,
        "PINTEREST": 3,
        "TWITTER": 4,
    }


class InvalidateRequest(object):
    """
    Attributes:
     - roles
     - emailAddresses
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'emailAddresses', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, roles=None, emailAddresses=None, ):
        self.roles = roles
        self.emailAddresses = emailAddresses

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.user.user.ttypes.Role()
                        _elem4.read(iprot)
                        self.roles.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.emailAddresses = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emailAddresses.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('InvalidateRequest')
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter10 in self.roles:
                _iter10.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.emailAddresses is not None:
            oprot.writeFieldBegin('emailAddresses', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.emailAddresses))
            for _iter11 in self.emailAddresses:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class InvalidateResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('InvalidateResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryRequest(object):
    """
    Attributes:
     - emailAddresses
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'emailAddresses', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, emailAddresses=None, ):
        self.emailAddresses = emailAddresses

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.emailAddresses = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emailAddresses.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryRequest')
        if self.emailAddresses is not None:
            oprot.writeFieldBegin('emailAddresses', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.emailAddresses))
            for _iter16 in self.emailAddresses:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SocialProfile(object):
    """
    Attributes:
     - typeId
     - typeName
     - url
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'typeId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'typeName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'url', 'UTF8', None, ),  # 3
        (4, TType.I32, 'type', None, None, ),  # 4
    )
    def __init__(self, typeId=None, typeName=None, url=None, type=None, ):
        self.typeId = typeId
        self.typeName = typeName
        self.url = url
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.typeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.typeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SocialProfile')
        if self.typeId is not None:
            oprot.writeFieldBegin('typeId', TType.STRING, 1)
            oprot.writeString(self.typeId.encode('utf-8') if sys.version_info[0] == 2 else self.typeId)
            oprot.writeFieldEnd()
        if self.typeName is not None:
            oprot.writeFieldBegin('typeName', TType.STRING, 2)
            oprot.writeString(self.typeName.encode('utf-8') if sys.version_info[0] == 2 else self.typeName)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 3)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 4)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FullContactInformation(object):
    """
    Attributes:
     - name
     - location
     - jobTitle
     - employer
     - photo
     - socialProfiles
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'location', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'jobTitle', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'employer', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'photo', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'socialProfiles', (TType.STRUCT, (SocialProfile, SocialProfile.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, name=None, location=None, jobTitle=None, employer=None, photo=None, socialProfiles=None, ):
        self.name = name
        self.location = location
        self.jobTitle = jobTitle
        self.employer = employer
        self.photo = photo
        self.socialProfiles = socialProfiles

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.location = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.jobTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.employer = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.photo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.socialProfiles = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = SocialProfile()
                        _elem19.read(iprot)
                        self.socialProfiles.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FullContactInformation')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.STRING, 2)
            oprot.writeString(self.location.encode('utf-8') if sys.version_info[0] == 2 else self.location)
            oprot.writeFieldEnd()
        if self.jobTitle is not None:
            oprot.writeFieldBegin('jobTitle', TType.STRING, 3)
            oprot.writeString(self.jobTitle.encode('utf-8') if sys.version_info[0] == 2 else self.jobTitle)
            oprot.writeFieldEnd()
        if self.employer is not None:
            oprot.writeFieldBegin('employer', TType.STRING, 4)
            oprot.writeString(self.employer.encode('utf-8') if sys.version_info[0] == 2 else self.employer)
            oprot.writeFieldEnd()
        if self.photo is not None:
            oprot.writeFieldBegin('photo', TType.STRING, 5)
            oprot.writeString(self.photo.encode('utf-8') if sys.version_info[0] == 2 else self.photo)
            oprot.writeFieldEnd()
        if self.socialProfiles is not None:
            oprot.writeFieldBegin('socialProfiles', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.socialProfiles))
            for _iter21 in self.socialProfiles:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FullContactCacheEntry(object):
    """
    Attributes:
     - _id
     - emailAddress
     - profile
     - retryAfter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'emailAddress', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'profile', (FullContactInformation, FullContactInformation.thrift_spec), None, ),  # 3
        (4, TType.I64, 'retryAfter', None, None, ),  # 4
    )
    def __init__(self, _id=None, emailAddress=None, profile=None, retryAfter=None, ):
        self._id = _id
        self.emailAddress = emailAddress
        self.profile = profile
        self.retryAfter = retryAfter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.emailAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.profile = FullContactInformation()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.retryAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FullContactCacheEntry')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.emailAddress is not None:
            oprot.writeFieldBegin('emailAddress', TType.STRING, 2)
            oprot.writeString(self.emailAddress.encode('utf-8') if sys.version_info[0] == 2 else self.emailAddress)
            oprot.writeFieldEnd()
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 3)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        if self.retryAfter is not None:
            oprot.writeFieldBegin('retryAfter', TType.I64, 4)
            oprot.writeI64(self.retryAfter)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryResult(object):
    """
    Attributes:
     - emailAddress
     - result
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'emailAddress', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'result', (FullContactInformation, FullContactInformation.thrift_spec), None, ),  # 2
    )
    def __init__(self, emailAddress=None, result=None, ):
        self.emailAddress = emailAddress
        self.result = result

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.emailAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.result = FullContactInformation()
                    self.result.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryResult')
        if self.emailAddress is not None:
            oprot.writeFieldBegin('emailAddress', TType.STRING, 1)
            oprot.writeString(self.emailAddress.encode('utf-8') if sys.version_info[0] == 2 else self.emailAddress)
            oprot.writeFieldEnd()
        if self.result is not None:
            oprot.writeFieldBegin('result', TType.STRUCT, 2)
            self.result.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryResponse(object):
    """
    Attributes:
     - status
     - results
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'results', (TType.STRUCT, (QueryResult, QueryResult.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, results=None, ):
        self.status = status
        self.results = results

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.results = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = QueryResult()
                        _elem24.read(iprot)
                        self.results.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.results is not None:
            oprot.writeFieldBegin('results', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.results))
            for _iter26 in self.results:
                _iter26.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
