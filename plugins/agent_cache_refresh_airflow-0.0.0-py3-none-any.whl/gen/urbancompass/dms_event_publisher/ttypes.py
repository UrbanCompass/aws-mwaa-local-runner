
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.application.ttypes
import gen.urbancompass.dms_common.dms_glide.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes

from thrift.transport import TTransport


class DmsAgentId(object):
    """
    Attributes:
     - id
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
    )
    def __init__(self, id=None, type=None, ):
        self.id = id
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsAgentId')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsChecklistItem(object):
    """
    Attributes:
     - id
     - glideFormId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'glideFormId', 'UTF8', None, ),  # 2
    )
    def __init__(self, id=None, glideFormId=None, ):
        self.id = id
        self.glideFormId = glideFormId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.glideFormId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsChecklistItem')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.glideFormId is not None:
            oprot.writeFieldBegin('glideFormId', TType.STRING, 2)
            oprot.writeString(self.glideFormId.encode('utf-8') if sys.version_info[0] == 2 else self.glideFormId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsUpdates(object):
    """
    Attributes:
     - propertyAddress
     - propertyAddressTs
     - closePrice
     - closePriceTs
     - yearBuilt
     - yearBuiltTs
     - listDate
     - listDateTs
     - expirationDate
     - expirationDateTs
     - listPrice
     - listPriceTs
     - propertyType
     - propertyTypeTs
     - acceptanceDate
     - acceptanceDateTs
     - closeDate
     - closeDateTs
     - commissionRateAmount
     - commissionRateAmountTs
     - commissionRate
     - commissionRateTs
     - otherSideCommissionRateAmount
     - otherSideCommissionRateAmountTs
     - otherSideCommissionRate
     - otherSideCommissionRateTs
     - unit
     - unitTs
     - city
     - cityTs
     - state
     - stateTs
     - zipcode
     - zipcodeTs
     - otherSideClientIds
     - otherSideClientIdsTs
     - otherSideAgentIds
     - otherSideAgentIdsTs
     - mlsId
     - mlsIdTs
     - deletedFields
     - deletedFieldsTs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 1
        (2, TType.I64, 'propertyAddressTs', None, None, ),  # 2
        (3, TType.DOUBLE, 'closePrice', None, None, ),  # 3
        (4, TType.I64, 'closePriceTs', None, None, ),  # 4
        (5, TType.I32, 'yearBuilt', None, None, ),  # 5
        (6, TType.I64, 'yearBuiltTs', None, None, ),  # 6
        (7, TType.I64, 'listDate', None, None, ),  # 7
        (8, TType.I64, 'listDateTs', None, None, ),  # 8
        (9, TType.I64, 'expirationDate', None, None, ),  # 9
        (10, TType.I64, 'expirationDateTs', None, None, ),  # 10
        (11, TType.DOUBLE, 'listPrice', None, None, ),  # 11
        (12, TType.I64, 'listPriceTs', None, None, ),  # 12
        (13, TType.I32, 'propertyType', None, None, ),  # 13
        (14, TType.I64, 'propertyTypeTs', None, None, ),  # 14
        (15, TType.I64, 'acceptanceDate', None, None, ),  # 15
        (16, TType.I64, 'acceptanceDateTs', None, None, ),  # 16
        (17, TType.I64, 'closeDate', None, None, ),  # 17
        (18, TType.I64, 'closeDateTs', None, None, ),  # 18
        (19, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 19
        (20, TType.I64, 'commissionRateAmountTs', None, None, ),  # 20
        (21, TType.DOUBLE, 'commissionRate', None, None, ),  # 21
        (22, TType.I64, 'commissionRateTs', None, None, ),  # 22
        (23, TType.DOUBLE, 'otherSideCommissionRateAmount', None, None, ),  # 23
        (24, TType.I64, 'otherSideCommissionRateAmountTs', None, None, ),  # 24
        (25, TType.DOUBLE, 'otherSideCommissionRate', None, None, ),  # 25
        (26, TType.I64, 'otherSideCommissionRateTs', None, None, ),  # 26
        (27, TType.STRING, 'unit', 'UTF8', None, ),  # 27
        (28, TType.I64, 'unitTs', None, None, ),  # 28
        (29, TType.STRING, 'city', 'UTF8', None, ),  # 29
        (30, TType.I64, 'cityTs', None, None, ),  # 30
        (31, TType.STRING, 'state', 'UTF8', None, ),  # 31
        (32, TType.I64, 'stateTs', None, None, ),  # 32
        (33, TType.STRING, 'zipcode', 'UTF8', None, ),  # 33
        (34, TType.I64, 'zipcodeTs', None, None, ),  # 34
        (35, TType.LIST, 'otherSideClientIds', (TType.STRING, 'UTF8', False), None, ),  # 35
        (36, TType.I64, 'otherSideClientIdsTs', None, None, ),  # 36
        (37, TType.LIST, 'otherSideAgentIds', (TType.STRUCT, (DmsAgentId, DmsAgentId.thrift_spec), False), None, ),  # 37
        None,  # 38
        (39, TType.I64, 'otherSideAgentIdsTs', None, None, ),  # 39
        (40, TType.STRING, 'mlsId', 'UTF8', None, ),  # 40
        (41, TType.I64, 'mlsIdTs', None, None, ),  # 41
        (42, TType.LIST, 'deletedFields', (TType.STRING, 'UTF8', False), None, ),  # 42
        (43, TType.I64, 'deletedFieldsTs', None, None, ),  # 43
    )
    def __init__(self, propertyAddress=None, propertyAddressTs=None, closePrice=None, closePriceTs=None, yearBuilt=None, yearBuiltTs=None, listDate=None, listDateTs=None, expirationDate=None, expirationDateTs=None, listPrice=None, listPriceTs=None, propertyType=None, propertyTypeTs=None, acceptanceDate=None, acceptanceDateTs=None, closeDate=None, closeDateTs=None, commissionRateAmount=None, commissionRateAmountTs=None, commissionRate=None, commissionRateTs=None, otherSideCommissionRateAmount=None, otherSideCommissionRateAmountTs=None, otherSideCommissionRate=None, otherSideCommissionRateTs=None, unit=None, unitTs=None, city=None, cityTs=None, state=None, stateTs=None, zipcode=None, zipcodeTs=None, otherSideClientIds=None, otherSideClientIdsTs=None, otherSideAgentIds=None, otherSideAgentIdsTs=None, mlsId=None, mlsIdTs=None, deletedFields=None, deletedFieldsTs=None, ):
        self.propertyAddress = propertyAddress
        self.propertyAddressTs = propertyAddressTs
        self.closePrice = closePrice
        self.closePriceTs = closePriceTs
        self.yearBuilt = yearBuilt
        self.yearBuiltTs = yearBuiltTs
        self.listDate = listDate
        self.listDateTs = listDateTs
        self.expirationDate = expirationDate
        self.expirationDateTs = expirationDateTs
        self.listPrice = listPrice
        self.listPriceTs = listPriceTs
        self.propertyType = propertyType
        self.propertyTypeTs = propertyTypeTs
        self.acceptanceDate = acceptanceDate
        self.acceptanceDateTs = acceptanceDateTs
        self.closeDate = closeDate
        self.closeDateTs = closeDateTs
        self.commissionRateAmount = commissionRateAmount
        self.commissionRateAmountTs = commissionRateAmountTs
        self.commissionRate = commissionRate
        self.commissionRateTs = commissionRateTs
        self.otherSideCommissionRateAmount = otherSideCommissionRateAmount
        self.otherSideCommissionRateAmountTs = otherSideCommissionRateAmountTs
        self.otherSideCommissionRate = otherSideCommissionRate
        self.otherSideCommissionRateTs = otherSideCommissionRateTs
        self.unit = unit
        self.unitTs = unitTs
        self.city = city
        self.cityTs = cityTs
        self.state = state
        self.stateTs = stateTs
        self.zipcode = zipcode
        self.zipcodeTs = zipcodeTs
        self.otherSideClientIds = otherSideClientIds
        self.otherSideClientIdsTs = otherSideClientIdsTs
        self.otherSideAgentIds = otherSideAgentIds
        self.otherSideAgentIdsTs = otherSideAgentIdsTs
        self.mlsId = mlsId
        self.mlsIdTs = mlsIdTs
        self.deletedFields = deletedFields
        self.deletedFieldsTs = deletedFieldsTs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.propertyAddressTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.closePriceTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.yearBuiltTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.listDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.expirationDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.expirationDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.listPriceTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.propertyTypeTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I64:
                    self.acceptanceDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I64:
                    self.acceptanceDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I64:
                    self.closeDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I64:
                    self.commissionRateAmountTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.commissionRateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.I64:
                    self.otherSideCommissionRateAmountTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I64:
                    self.otherSideCommissionRateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.I64:
                    self.unitTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.I64:
                    self.cityTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.I64:
                    self.stateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.I64:
                    self.zipcodeTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.LIST:
                    self.otherSideClientIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.otherSideClientIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.I64:
                    self.otherSideClientIdsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.LIST:
                    self.otherSideAgentIds = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = DmsAgentId()
                        _elem8.read(iprot)
                        self.otherSideAgentIds.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.I64:
                    self.otherSideAgentIdsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.I64:
                    self.mlsIdTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.LIST:
                    self.deletedFields = []
                    (_etype10, _size13) = iprot.readListBegin()
                    for _i11 in range(_size13):
                        _elem12 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.deletedFields.append(_elem12)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.I64:
                    self.deletedFieldsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsUpdates')
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 1)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.propertyAddressTs is not None:
            oprot.writeFieldBegin('propertyAddressTs', TType.I64, 2)
            oprot.writeI64(self.propertyAddressTs)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 3)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.closePriceTs is not None:
            oprot.writeFieldBegin('closePriceTs', TType.I64, 4)
            oprot.writeI64(self.closePriceTs)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 5)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.yearBuiltTs is not None:
            oprot.writeFieldBegin('yearBuiltTs', TType.I64, 6)
            oprot.writeI64(self.yearBuiltTs)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 7)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.listDateTs is not None:
            oprot.writeFieldBegin('listDateTs', TType.I64, 8)
            oprot.writeI64(self.listDateTs)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.I64, 9)
            oprot.writeI64(self.expirationDate)
            oprot.writeFieldEnd()
        if self.expirationDateTs is not None:
            oprot.writeFieldBegin('expirationDateTs', TType.I64, 10)
            oprot.writeI64(self.expirationDateTs)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 11)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.listPriceTs is not None:
            oprot.writeFieldBegin('listPriceTs', TType.I64, 12)
            oprot.writeI64(self.listPriceTs)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 13)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.propertyTypeTs is not None:
            oprot.writeFieldBegin('propertyTypeTs', TType.I64, 14)
            oprot.writeI64(self.propertyTypeTs)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.I64, 15)
            oprot.writeI64(self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.acceptanceDateTs is not None:
            oprot.writeFieldBegin('acceptanceDateTs', TType.I64, 16)
            oprot.writeI64(self.acceptanceDateTs)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 17)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.closeDateTs is not None:
            oprot.writeFieldBegin('closeDateTs', TType.I64, 18)
            oprot.writeI64(self.closeDateTs)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 19)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.commissionRateAmountTs is not None:
            oprot.writeFieldBegin('commissionRateAmountTs', TType.I64, 20)
            oprot.writeI64(self.commissionRateAmountTs)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 21)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.commissionRateTs is not None:
            oprot.writeFieldBegin('commissionRateTs', TType.I64, 22)
            oprot.writeI64(self.commissionRateTs)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmount is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmount', TType.DOUBLE, 23)
            oprot.writeDouble(self.otherSideCommissionRateAmount)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmountTs is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmountTs', TType.I64, 24)
            oprot.writeI64(self.otherSideCommissionRateAmountTs)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.DOUBLE, 25)
            oprot.writeDouble(self.otherSideCommissionRate)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateTs is not None:
            oprot.writeFieldBegin('otherSideCommissionRateTs', TType.I64, 26)
            oprot.writeI64(self.otherSideCommissionRateTs)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 27)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.unitTs is not None:
            oprot.writeFieldBegin('unitTs', TType.I64, 28)
            oprot.writeI64(self.unitTs)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 29)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.cityTs is not None:
            oprot.writeFieldBegin('cityTs', TType.I64, 30)
            oprot.writeI64(self.cityTs)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 31)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.stateTs is not None:
            oprot.writeFieldBegin('stateTs', TType.I64, 32)
            oprot.writeI64(self.stateTs)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 33)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.zipcodeTs is not None:
            oprot.writeFieldBegin('zipcodeTs', TType.I64, 34)
            oprot.writeI64(self.zipcodeTs)
            oprot.writeFieldEnd()
        if self.otherSideClientIds is not None:
            oprot.writeFieldBegin('otherSideClientIds', TType.LIST, 35)
            oprot.writeListBegin(TType.STRING, len(self.otherSideClientIds))
            for _iter14 in self.otherSideClientIds:
                oprot.writeString(_iter14.encode('utf-8') if sys.version_info[0] == 2 else _iter14)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideClientIdsTs is not None:
            oprot.writeFieldBegin('otherSideClientIdsTs', TType.I64, 36)
            oprot.writeI64(self.otherSideClientIdsTs)
            oprot.writeFieldEnd()
        if self.otherSideAgentIds is not None:
            oprot.writeFieldBegin('otherSideAgentIds', TType.LIST, 37)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideAgentIds))
            for _iter15 in self.otherSideAgentIds:
                _iter15.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideAgentIdsTs is not None:
            oprot.writeFieldBegin('otherSideAgentIdsTs', TType.I64, 39)
            oprot.writeI64(self.otherSideAgentIdsTs)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 40)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.mlsIdTs is not None:
            oprot.writeFieldBegin('mlsIdTs', TType.I64, 41)
            oprot.writeI64(self.mlsIdTs)
            oprot.writeFieldEnd()
        if self.deletedFields is not None:
            oprot.writeFieldBegin('deletedFields', TType.LIST, 42)
            oprot.writeListBegin(TType.STRING, len(self.deletedFields))
            for _iter16 in self.deletedFields:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.deletedFieldsTs is not None:
            oprot.writeFieldBegin('deletedFieldsTs', TType.I64, 43)
            oprot.writeI64(self.deletedFieldsTs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsUpdateEvent(object):
    """
    Attributes:
     - dmsFolderId
     - origin
     - updateTs
     - updatedBy
     - updates
     - addedChecklistItems
     - isReferral
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'origin', None, None, ),  # 2
        (3, TType.I64, 'updateTs', None, None, ),  # 3
        (4, TType.STRUCT, 'updates', (DmsUpdates, DmsUpdates.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'addedChecklistItems', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 6
        (7, TType.BOOL, 'isReferral', None, None, ),  # 7
    )
    def __init__(self, dmsFolderId=None, origin=None, updateTs=None, updates=None, updatedBy=None, addedChecklistItems=None, isReferral=None, ):
        self.dmsFolderId = dmsFolderId
        self.origin = origin
        self.updateTs = updateTs
        self.updates = updates
        self.updatedBy = updatedBy
        self.addedChecklistItems = addedChecklistItems
        self.isReferral = isReferral

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.updates = DmsUpdates()
                    self.updates.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.addedChecklistItems = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = DmsChecklistItem()
                        _elem19.read(iprot)
                        self.addedChecklistItems.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isReferral = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsUpdateEvent')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 2)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.updateTs is not None:
            oprot.writeFieldBegin('updateTs', TType.I64, 3)
            oprot.writeI64(self.updateTs)
            oprot.writeFieldEnd()
        if self.updates is not None:
            oprot.writeFieldBegin('updates', TType.STRUCT, 4)
            self.updates.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 5)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        if self.addedChecklistItems is not None:
            oprot.writeFieldBegin('addedChecklistItems', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.addedChecklistItems))
            for _iter21 in self.addedChecklistItems:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isReferral is not None:
            oprot.writeFieldBegin('isReferral', TType.BOOL, 7)
            oprot.writeBool(self.isReferral)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
