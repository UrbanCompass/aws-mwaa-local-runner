
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
ACWORTH = "Acworth"
ADAIRSVILLE = "Adairsville"
ALPHARETTA = "Alpharetta"
ALTO = "Alto"
ARAGON = "Aragon"
ARMUCHEE = "Armuchee"
ATLANTA = "Atlanta"
AUBURN = "Auburn"
AUSTELL = "Austell"
AVONDALE_ESTATES = "Avondale Estates"
BALL_GROUND = "Ball Ground"
BARNESVILLE = "Barnesville"
BERKELEY_LAKE = "Berkeley Lake"
BETHLEHEM = "Bethlehem"
BIG_CANOE = "Big Canoe"
BLAIRSVILLE = "Blairsville"
BLUE_RIDGE = "Blue Ridge"
BOSTWICK = "Bostwick"
BOWDON = "Bowdon"
BRASELTON = "Braselton"
BREMEN = "Bremen"
BROOKHAVEN = "Brookhaven"
BROOKS = "Brooks"
BUCHANAN = "Buchanan"
BUCKHEAD = "Buckhead"
BUFORD = "Buford"
CALHOUN = "Calhoun"
CANTON = "Canton"
CARROLLTON = "Carrollton"
CARTERSVILLE = "Cartersville"
CAVE_SPRING = "Cave Spring"
CEDARTOWN = "Cedartown"
CHAMBLEE = "Chamblee"
CHATTAHOOCHEE_HILLS = "Chattahoochee Hills"
CHERRY_LOG = "Cherry Log"
CITIES = [
    "Acworth",
    "Adairsville",
    "Alpharetta",
    "Alto",
    "Aragon",
    "Armuchee",
    "Atlanta",
    "Auburn",
    "Austell",
    "Avondale Estates",
    "Ball Ground",
    "Barnesville",
    "Berkeley Lake",
    "Bethlehem",
    "Big Canoe",
    "Blairsville",
    "Blue Ridge",
    "Bostwick",
    "Bowdon",
    "Braselton",
    "Bremen",
    "Brookhaven",
    "Brooks",
    "Buchanan",
    "Buckhead",
    "Buford",
    "Calhoun",
    "Canton",
    "Carrollton",
    "Cartersville",
    "Cave Spring",
    "Cedartown",
    "Chamblee",
    "Chattahoochee Hills",
    "Cherry Log",
    "Clarkesville",
    "Clarkston",
    "Clayton",
    "Clermont",
    "Cleveland",
    "College Park",
    "Commerce",
    "Concord",
    "Conley",
    "Conyers",
    "Cornelia",
    "Covington",
    "Cumming",
    "Dacula",
    "Dahlonega",
    "Dallas",
    "Dawsonville",
    "Decatur",
    "Demorest",
    "Dillard",
    "Doraville",
    "Douglasville",
    "Duluth",
    "Dunwoody",
    "East Point",
    "Ellenwood",
    "Ellijay",
    "Emerson",
    "Epworth",
    "Euharlee",
    "Fairburn",
    "Fairmount",
    "Fayetteville",
    "Flovilla",
    "Flowery Branch",
    "Forest Park",
    "Franklin",
    "Gainesville",
    "Gay",
    "Gillsville",
    "Good Hope",
    "Grantville",
    "Grayson",
    "Greenville",
    "Griffin",
    "Hampton",
    "Hapeville",
    "Helen",
    "Hillsboro",
    "Hiram",
    "Hogansville",
    "Holly Springs",
    "Hoschton",
    "Jackson",
    "Jasper",
    "Jefferson",
    "Jenkinsburg",
    "Johns Creek",
    "Jonesboro",
    "Kennesaw",
    "Kingston",
    "LaGrange",
    "Lakemont",
    "Lake City",
    "Lake Spivey",
    "Lawrenceville",
    "Lebanon",
    "Lilburn",
    "Lindale",
    "Lithia Springs",
    "Lithonia",
    "Locust Grove",
    "Loganville",
    "Lula",
    "Luthersville",
    "Lyerly",
    "Mableton",
    "Madison",
    "Manchester",
    "Mansfield",
    "Marble Hill",
    "Marietta",
    "McCaysville",
    "McDonough",
    "Meansville",
    "Menlo",
    "Milner",
    "Milton",
    "Mineral Bluff",
    "Molena",
    "Monroe",
    "Monticello",
    "Moreland",
    "Morganton",
    "Morrow",
    "Mount Airy",
    "Murrayville",
    "Newborn",
    "Newnan",
    "Nicholson",
    "Norcross",
    "Oakwood",
    "Oxford",
    "Palmetto",
    "Peachtree City",
    "Peachtree Corners",
    "Pendergrass",
    "Pine Lake",
    "Plainville",
    "Porterdale",
    "Powder Springs",
    "Rabun Gap",
    "Ranger",
    "Red Oak",
    "Resaca",
    "Rex",
    "Riverdale",
    "Rockmart",
    "Rome",
    "Roopville",
    "Roswell",
    "Rutledge",
    "Rydal",
    "Sandy Springs",
    "Sautee Nacoochee",
    "Scottdale",
    "Senoia",
    "Shady Dale",
    "Sharpsburg",
    "Silver Creek",
    "Smoke Rise",
    "Smyrna",
    "Snellville",
    "Social Circle",
    "Statham",
    "Stockbridge",
    "Stone Mountain",
    "Suches",
    "Sugar Hill",
    "Sugar Valley",
    "Summerville",
    "Suwanee",
    "Talking Rock",
    "Tallapoosa",
    "Tallulah Falls",
    "Talmo",
    "Tate",
    "Taylorsville",
    "Temple",
    "Tiger",
    "Trion",
    "Tucker",
    "Tyrone",
    "Union City",
    "Villa Rica",
    "Vinings",
    "Waco",
    "Waleska",
    "Warm Springs",
    "West Point",
    "White",
    "Whitesburg",
    "Williamson",
    "Winder",
    "Winston",
    "Woodbury",
    "Woodstock",
    "Zebulon",
]
CLARKESVILLE = "Clarkesville"
CLARKSTON = "Clarkston"
CLAYTON = "Clayton"
CLERMONT = "Clermont"
CLEVELAND = "Cleveland"
COLLEGE_PARK = "College Park"
COMMERCE = "Commerce"
CONCORD = "Concord"
CONLEY = "Conley"
CONYERS = "Conyers"
CORNELIA = "Cornelia"
COVINGTON = "Covington"
CUMMING = "Cumming"
DACULA = "Dacula"
DAHLONEGA = "Dahlonega"
DALLAS = "Dallas"
DAWSONVILLE = "Dawsonville"
DECATUR = "Decatur"
DEMOREST = "Demorest"
DILLARD = "Dillard"
DORAVILLE = "Doraville"
DOUGLASVILLE = "Douglasville"
DULUTH = "Duluth"
DUNWOODY = "Dunwoody"
EAST_POINT = "East Point"
ELLENWOOD = "Ellenwood"
ELLIJAY = "Ellijay"
EMERSON = "Emerson"
EPWORTH = "Epworth"
EUHARLEE = "Euharlee"
FAIRBURN = "Fairburn"
FAIRMOUNT = "Fairmount"
FAYETTEVILLE = "Fayetteville"
FLOVILLA = "Flovilla"
FLOWERY_BRANCH = "Flowery Branch"
FOREST_PARK = "Forest Park"
FRANKLIN = "Franklin"
GAINESVILLE = "Gainesville"
GAY = "Gay"
GILLSVILLE = "Gillsville"
GOOD_HOPE = "Good Hope"
GRANTVILLE = "Grantville"
GRAYSON = "Grayson"
GREENVILLE = "Greenville"
GRIFFIN = "Griffin"
HAMPTON = "Hampton"
HAPEVILLE = "Hapeville"
HELEN = "Helen"
HILLSBORO = "Hillsboro"
HIRAM = "Hiram"
HOGANSVILLE = "Hogansville"
HOLLY_SPRINGS = "Holly Springs"
HOSCHTON = "Hoschton"
JACKSON = "Jackson"
JASPER = "Jasper"
JEFFERSON = "Jefferson"
JENKINSBURG = "Jenkinsburg"
JOHNS_CREEK = "Johns Creek"
JONESBORO = "Jonesboro"
KENNESAW = "Kennesaw"
KINGSTON = "Kingston"
LAGRANGE = "LaGrange"
LAKEMONT = "Lakemont"
LAKE_CITY = "Lake City"
LAKE_SPIVEY = "Lake Spivey"
LAWRENCEVILLE = "Lawrenceville"
LEBANON = "Lebanon"
LILBURN = "Lilburn"
LINDALE = "Lindale"
LITHIA_SPRINGS = "Lithia Springs"
LITHONIA = "Lithonia"
LOCUST_GROVE = "Locust Grove"
LOGANVILLE = "Loganville"
LULA = "Lula"
LUTHERSVILLE = "Luthersville"
LYERLY = "Lyerly"
MABLETON = "Mableton"
MADISON = "Madison"
MANCHESTER = "Manchester"
MANSFIELD = "Mansfield"
MARBLE_HILL = "Marble Hill"
MARIETTA = "Marietta"
MCCAYSVILLE = "McCaysville"
MCDONOUGH = "McDonough"
MEANSVILLE = "Meansville"
MENLO = "Menlo"
MILNER = "Milner"
MILTON = "Milton"
MINERAL_BLUFF = "Mineral Bluff"
MOLENA = "Molena"
MONROE = "Monroe"
MONTICELLO = "Monticello"
MORELAND = "Moreland"
MORGANTON = "Morganton"
MORROW = "Morrow"
MOUNT_AIRY = "Mount Airy"
MURRAYVILLE = "Murrayville"
NEWBORN = "Newborn"
NEWNAN = "Newnan"
NICHOLSON = "Nicholson"
NORCROSS = "Norcross"
OAKWOOD = "Oakwood"
OXFORD = "Oxford"
PALMETTO = "Palmetto"
PEACHTREE_CITY = "Peachtree City"
PEACHTREE_CORNERS = "Peachtree Corners"
PENDERGRASS = "Pendergrass"
PINE_LAKE = "Pine Lake"
PLAINVILLE = "Plainville"
PORTERDALE = "Porterdale"
POWDER_SPRINGS = "Powder Springs"
RABUN_GAP = "Rabun Gap"
RANGER = "Ranger"
RED_OAK = "Red Oak"
RESACA = "Resaca"
REX = "Rex"
RIVERDALE = "Riverdale"
ROCKMART = "Rockmart"
ROME = "Rome"
ROOPVILLE = "Roopville"
ROSWELL = "Roswell"
RUTLEDGE = "Rutledge"
RYDAL = "Rydal"
SANDY_SPRINGS = "Sandy Springs"
SAUTEE_NACOOCHEE = "Sautee Nacoochee"
SCOTTDALE = "Scottdale"
SENOIA = "Senoia"
SHADY_DALE = "Shady Dale"
SHARPSBURG = "Sharpsburg"
SILVER_CREEK = "Silver Creek"
SMOKE_RISE = "Smoke Rise"
SMYRNA = "Smyrna"
SNELLVILLE = "Snellville"
SOCIAL_CIRCLE = "Social Circle"
STATHAM = "Statham"
STOCKBRIDGE = "Stockbridge"
STONE_MOUNTAIN = "Stone Mountain"
SUCHES = "Suches"
SUGAR_HILL = "Sugar Hill"
SUGAR_VALLEY = "Sugar Valley"
SUMMERVILLE = "Summerville"
SUWANEE = "Suwanee"
TALKING_ROCK = "Talking Rock"
TALLAPOOSA = "Tallapoosa"
TALLULAH_FALLS = "Tallulah Falls"
TALMO = "Talmo"
TATE = "Tate"
TAYLORSVILLE = "Taylorsville"
TEMPLE = "Temple"
TIGER = "Tiger"
TRION = "Trion"
TUCKER = "Tucker"
TYRONE = "Tyrone"
UNION_CITY = "Union City"
VILLA_RICA = "Villa Rica"
VININGS = "Vinings"
WACO = "Waco"
WALESKA = "Waleska"
WARM_SPRINGS = "Warm Springs"
WEST_POINT = "West Point"
WHITE = "White"
WHITESBURG = "Whitesburg"
WILLIAMSON = "Williamson"
WINDER = "Winder"
WINSTON = "Winston"
WOODBURY = "Woodbury"
WOODSTOCK = "Woodstock"
ZEBULON = "Zebulon"
