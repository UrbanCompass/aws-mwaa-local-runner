
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class AttachmentType(object):
    CONTACTS = 0
    LISTINGS = 1
    COLLECTIONS = 2
    TOURSHEETS = 3
    DOCUMENTS = 4
    COMPARATIVE_MARKET_ANALYSIS = 5
    LISTING_FOLDERS = 6
    SAVED_SEARCHES = 7
    MARKETING_PLAN = 8
    DIGITAL_AD = 9
    VIDEO_STUDIO_ASSET = 10

    _VALUES_TO_NAMES = {
        0: "CONTACTS",
        1: "LISTINGS",
        2: "COLLECTIONS",
        3: "TOURSHEETS",
        4: "DOCUMENTS",
        5: "COMPARATIVE_MARKET_ANALYSIS",
        6: "LISTING_FOLDERS",
        7: "SAVED_SEARCHES",
        8: "MARKETING_PLAN",
        9: "DIGITAL_AD",
        10: "VIDEO_STUDIO_ASSET",
    }

    _NAMES_TO_VALUES = {
        "CONTACTS": 0,
        "LISTINGS": 1,
        "COLLECTIONS": 2,
        "TOURSHEETS": 3,
        "DOCUMENTS": 4,
        "COMPARATIVE_MARKET_ANALYSIS": 5,
        "LISTING_FOLDERS": 6,
        "SAVED_SEARCHES": 7,
        "MARKETING_PLAN": 8,
        "DIGITAL_AD": 9,
        "VIDEO_STUDIO_ASSET": 10,
    }


class AutoAttachAction(object):
    NONE = 0
    DEAL_CREATED = 1
    DEAL_UPDATED = 2

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "DEAL_CREATED",
        2: "DEAL_UPDATED",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "DEAL_CREATED": 1,
        "DEAL_UPDATED": 2,
    }


class DealAvailableFeatures(object):
    COLLECTIONS = 0
    DOCUMENTS = 1
    LISTINGS = 2
    OPEN_HOUSE = 3
    SAVED_SEARCHES = 4
    TOURSHEETS = 5
    CONTACTS = 6
    CMAS = 7
    TASKS = 8
    ACTIVITY = 9
    NOTES = 10
    INSIGHTS = 11
    FILE_STORAGE = 12

    _VALUES_TO_NAMES = {
        0: "COLLECTIONS",
        1: "DOCUMENTS",
        2: "LISTINGS",
        3: "OPEN_HOUSE",
        4: "SAVED_SEARCHES",
        5: "TOURSHEETS",
        6: "CONTACTS",
        7: "CMAS",
        8: "TASKS",
        9: "ACTIVITY",
        10: "NOTES",
        11: "INSIGHTS",
        12: "FILE_STORAGE",
    }

    _NAMES_TO_VALUES = {
        "COLLECTIONS": 0,
        "DOCUMENTS": 1,
        "LISTINGS": 2,
        "OPEN_HOUSE": 3,
        "SAVED_SEARCHES": 4,
        "TOURSHEETS": 5,
        "CONTACTS": 6,
        "CMAS": 7,
        "TASKS": 8,
        "ACTIVITY": 9,
        "NOTES": 10,
        "INSIGHTS": 11,
        "FILE_STORAGE": 12,
    }


class DealDisposition(object):
    WON = 0
    LOST = 1
    ABANDONED = 2
    OPEN = 3

    _VALUES_TO_NAMES = {
        0: "WON",
        1: "LOST",
        2: "ABANDONED",
        3: "OPEN",
    }

    _NAMES_TO_VALUES = {
        "WON": 0,
        "LOST": 1,
        "ABANDONED": 2,
        "OPEN": 3,
    }


class DealPermittedActions(object):
    EDIT = 0
    DELETE = 1

    _VALUES_TO_NAMES = {
        0: "EDIT",
        1: "DELETE",
    }

    _NAMES_TO_VALUES = {
        "EDIT": 0,
        "DELETE": 1,
    }


class DealStatus(object):
    OPEN = 0
    ARCHIVED = 1
    DELETED = 2

    _VALUES_TO_NAMES = {
        0: "OPEN",
        1: "ARCHIVED",
        2: "DELETED",
    }

    _NAMES_TO_VALUES = {
        "OPEN": 0,
        "ARCHIVED": 1,
        "DELETED": 2,
    }


class DealType(object):
    SELL = 0
    BUY = 1
    LEASE_LISTING = 2
    LEASE_RENTAL = 3
    OTHER = 4
    REFERRED_OUT = 5

    _VALUES_TO_NAMES = {
        0: "SELL",
        1: "BUY",
        2: "LEASE_LISTING",
        3: "LEASE_RENTAL",
        4: "OTHER",
        5: "REFERRED_OUT",
    }

    _NAMES_TO_VALUES = {
        "SELL": 0,
        "BUY": 1,
        "LEASE_LISTING": 2,
        "LEASE_RENTAL": 3,
        "OTHER": 4,
        "REFERRED_OUT": 5,
    }


class InactiveReason(object):
    UNRESPONSIVE = 0
    ANOTHER_AGENT = 1
    FINANCING = 2
    OTHER = 3

    _VALUES_TO_NAMES = {
        0: "UNRESPONSIVE",
        1: "ANOTHER_AGENT",
        2: "FINANCING",
        3: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "UNRESPONSIVE": 0,
        "ANOTHER_AGENT": 1,
        "FINANCING": 2,
        "OTHER": 3,
    }


class OpportunityStatus(object):
    ACTIVE = 0
    INACTIVE = 1
    CLOSED = 2

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "INACTIVE",
        2: "CLOSED",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "INACTIVE": 1,
        "CLOSED": 2,
    }


class TransactionPhase(object):
    POTENTIAL = 0
    ACTIVE = 1
    COMPLETE = 2
    INACTIVE = 3

    _VALUES_TO_NAMES = {
        0: "POTENTIAL",
        1: "ACTIVE",
        2: "COMPLETE",
        3: "INACTIVE",
    }

    _NAMES_TO_VALUES = {
        "POTENTIAL": 0,
        "ACTIVE": 1,
        "COMPLETE": 2,
        "INACTIVE": 3,
    }


class TransactionStateByAgent(object):
    INVITE_CLIENT = 0
    ACTIVATE_CLIENT_BYPASS_INVITE = 1

    _VALUES_TO_NAMES = {
        0: "INVITE_CLIENT",
        1: "ACTIVATE_CLIENT_BYPASS_INVITE",
    }

    _NAMES_TO_VALUES = {
        "INVITE_CLIENT": 0,
        "ACTIVATE_CLIENT_BYPASS_INVITE": 1,
    }


class TransactionStateByClient(object):
    INVITE_CLIENT = 0
    ACCEPT_INVITE_SELF = 1

    _VALUES_TO_NAMES = {
        0: "INVITE_CLIENT",
        1: "ACCEPT_INVITE_SELF",
    }

    _NAMES_TO_VALUES = {
        "INVITE_CLIENT": 0,
        "ACCEPT_INVITE_SELF": 1,
    }

