# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes as deals_workflow_model
import gen.urbancompass.dms_common.dms_deal.ttypes as dms_deal
import gen.urbancompass.dms_common.dms_listing.ttypes as dms_listing
import gen.urbancompass.listing.listing.ttypes as listing
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes as region_compliance_checklist_db_helper
import gen.urbancompass.region_compliance_checklist_model.ttypes as region_compliance_checklist_model
import gen.urbancompass.dms_region_config_service.regions.ttypes as regions
import uc.grpc.codec as _grpc_codec



class DmsRegionConfigServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.batchGetComplianceDocumentChecklistCriteria = channel.unary_unary(
        '/DmsRegionConfigService/batchGetComplianceDocumentChecklistCriteria',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistCriteriaResponse),
        )
    self.batchGetComplianceDocumentChecklistCriteriaRelations = channel.unary_unary(
        '/DmsRegionConfigService/batchGetComplianceDocumentChecklistCriteriaRelations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistCriteriaRelationResponse),
        )
    self.batchGetComplianceDocumentChecklists = channel.unary_unary(
        '/DmsRegionConfigService/batchGetComplianceDocumentChecklists',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistResponse),
        )
    self.batchGetComplianceDocuments = channel.unary_unary(
        '/DmsRegionConfigService/batchGetComplianceDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentResponse),
        )
    self.batchUpsertComplianceDocumentChecklistCriteria = channel.unary_unary(
        '/DmsRegionConfigService/batchUpsertComplianceDocumentChecklistCriteria',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistCriteriaResponse),
        )
    self.batchUpsertComplianceDocumentChecklistCriteriaRelations = channel.unary_unary(
        '/DmsRegionConfigService/batchUpsertComplianceDocumentChecklistCriteriaRelations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistCriteriaRelationResponse),
        )
    self.batchUpsertComplianceDocumentChecklists = channel.unary_unary(
        '/DmsRegionConfigService/batchUpsertComplianceDocumentChecklists',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistResponse),
        )
    self.batchUpsertComplianceDocuments = channel.unary_unary(
        '/DmsRegionConfigService/batchUpsertComplianceDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentResponse),
        )
    self.getChecklistAdminSettings = channel.unary_unary(
        '/DmsRegionConfigService/getChecklistAdminSettings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistAdminSettingsInternalResponse),
        )
    self.getComplianceChecklistDocuments = channel.unary_unary(
        '/DmsRegionConfigService/getComplianceChecklistDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetComplianceChecklistDocumentsResponse),
        )
    self.getComplianceChecklistRegionMarkets = channel.unary_unary(
        '/DmsRegionConfigService/getComplianceChecklistRegionMarkets',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetComplianceChecklistRegionMarketsResponse),
        )
    self.getComplianceEmailSupport = channel.unary_unary(
        '/DmsRegionConfigService/getComplianceEmailSupport',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetComplianceEmailSupportResponse),
        )
    self.getRegionSpecificPropertyTypes = channel.unary_unary(
        '/DmsRegionConfigService/getRegionSpecificPropertyTypes',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetRegionSpecificPropertyTypesResponse),
        )
    self.getRegionSpecificSettings = channel.unary_unary(
        '/DmsRegionConfigService/getRegionSpecificSettings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetRegionSpecificSettingsResponse),
        )
    self.triggerUploadComplianceChecklist = channel.unary_unary(
        '/DmsRegionConfigService/triggerUploadComplianceChecklist',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(TriggerUploadComplianceChecklistResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class DmsRegionConfigServiceServicer(BaseServiceServicer):
  """
    The DmsRegionConfigService Service definition
  """

  def batchGetComplianceDocumentChecklistCriteria(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetComplianceDocumentChecklistCriteriaRelations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetComplianceDocumentChecklists(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetComplianceDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertComplianceDocumentChecklistCriteria(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertComplianceDocumentChecklistCriteriaRelations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertComplianceDocumentChecklists(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertComplianceDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklistAdminSettings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getComplianceChecklistDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getComplianceChecklistRegionMarkets(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getComplianceEmailSupport(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getRegionSpecificPropertyTypes(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getRegionSpecificSettings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def triggerUploadComplianceChecklist(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_DmsRegionConfigServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'batchGetComplianceDocumentChecklistCriteria': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetComplianceDocumentChecklistCriteria(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistCriteriaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetComplianceDocumentChecklistCriteriaRelations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetComplianceDocumentChecklistCriteriaRelations(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistCriteriaRelationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetComplianceDocumentChecklists': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetComplianceDocumentChecklists(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetComplianceDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetComplianceDocuments(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocumentChecklistCriteria': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertComplianceDocumentChecklistCriteria(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistCriteriaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocumentChecklistCriteriaRelations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertComplianceDocumentChecklistCriteriaRelations(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistCriteriaRelationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocumentChecklists': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertComplianceDocumentChecklists(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertComplianceDocuments(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistAdminSettings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklistAdminSettings(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistAdminSettingsInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getComplianceChecklistDocuments(req),
          request_deserializer=_grpc_codec.deserializer(GetComplianceChecklistDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceChecklistRegionMarkets': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getComplianceChecklistRegionMarkets(req),
          request_deserializer=_grpc_codec.deserializer(GetComplianceChecklistRegionMarketsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceEmailSupport': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getComplianceEmailSupport(req),
          request_deserializer=_grpc_codec.deserializer(GetComplianceEmailSupportRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getRegionSpecificPropertyTypes': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getRegionSpecificPropertyTypes(req),
          request_deserializer=_grpc_codec.deserializer(GetRegionSpecificPropertyTypesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getRegionSpecificSettings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getRegionSpecificSettings(req),
          request_deserializer=_grpc_codec.deserializer(GetRegionSpecificSettingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'triggerUploadComplianceChecklist': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.triggerUploadComplianceChecklist(req),
          request_deserializer=_grpc_codec.deserializer(TriggerUploadComplianceChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsRegionConfigService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_DmsRegionConfigServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'batchGetComplianceDocumentChecklistCriteria': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetComplianceDocumentChecklistCriteria,
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistCriteriaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetComplianceDocumentChecklistCriteriaRelations': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetComplianceDocumentChecklistCriteriaRelations,
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistCriteriaRelationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetComplianceDocumentChecklists': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetComplianceDocumentChecklists,
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetComplianceDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetComplianceDocuments,
          request_deserializer=_grpc_codec.deserializer(BatchGetComplianceDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocumentChecklistCriteria': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertComplianceDocumentChecklistCriteria,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistCriteriaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocumentChecklistCriteriaRelations': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertComplianceDocumentChecklistCriteriaRelations,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistCriteriaRelationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocumentChecklists': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertComplianceDocumentChecklists,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertComplianceDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertComplianceDocuments,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertComplianceDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistAdminSettings': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklistAdminSettings,
          request_deserializer=_grpc_codec.deserializer(GetChecklistAdminSettingsInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.getComplianceChecklistDocuments,
          request_deserializer=_grpc_codec.deserializer(GetComplianceChecklistDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceChecklistRegionMarkets': grpc.unary_unary_rpc_method_handler(
          servicer.getComplianceChecklistRegionMarkets,
          request_deserializer=_grpc_codec.deserializer(GetComplianceChecklistRegionMarketsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceEmailSupport': grpc.unary_unary_rpc_method_handler(
          servicer.getComplianceEmailSupport,
          request_deserializer=_grpc_codec.deserializer(GetComplianceEmailSupportRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getRegionSpecificPropertyTypes': grpc.unary_unary_rpc_method_handler(
          servicer.getRegionSpecificPropertyTypes,
          request_deserializer=_grpc_codec.deserializer(GetRegionSpecificPropertyTypesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getRegionSpecificSettings': grpc.unary_unary_rpc_method_handler(
          servicer.getRegionSpecificSettings,
          request_deserializer=_grpc_codec.deserializer(GetRegionSpecificSettingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'triggerUploadComplianceChecklist': grpc.unary_unary_rpc_method_handler(
          servicer.triggerUploadComplianceChecklist,
          request_deserializer=_grpc_codec.deserializer(TriggerUploadComplianceChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsRegionConfigService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

