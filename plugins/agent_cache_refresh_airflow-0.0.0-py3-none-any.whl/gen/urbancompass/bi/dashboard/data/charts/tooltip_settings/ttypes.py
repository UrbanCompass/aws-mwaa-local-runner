
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.value_formats.ttypes

from thrift.transport import TTransport


class TooltipItemSettings(object):
    """
    Attributes:
     - isVisible
     - displayFormat
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isVisible', None, None, ),  # 1
        (2, TType.STRUCT, 'displayFormat', (gen.urbancompass.bi.dashboard.data.value_formats.ttypes.ValueFormat, gen.urbancompass.bi.dashboard.data.value_formats.ttypes.ValueFormat.thrift_spec), None, ),  # 2
    )
    def __init__(self, isVisible=None, displayFormat=None, ):
        self.isVisible = isVisible
        self.displayFormat = displayFormat

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isVisible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.displayFormat = gen.urbancompass.bi.dashboard.data.value_formats.ttypes.ValueFormat()
                    self.displayFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TooltipItemSettings')
        if self.isVisible is not None:
            oprot.writeFieldBegin('isVisible', TType.BOOL, 1)
            oprot.writeBool(self.isVisible)
            oprot.writeFieldEnd()
        if self.displayFormat is not None:
            oprot.writeFieldBegin('displayFormat', TType.STRUCT, 2)
            self.displayFormat.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TooltipSettings(object):
    """
    Attributes:
     - header
     - title
     - text
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'header', (TooltipItemSettings, TooltipItemSettings.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'title', (TooltipItemSettings, TooltipItemSettings.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'text', (TooltipItemSettings, TooltipItemSettings.thrift_spec), None, ),  # 3
    )
    def __init__(self, header=None, title=None, text=None, ):
        self.header = header
        self.title = title
        self.text = text

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.header = TooltipItemSettings()
                    self.header.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.title = TooltipItemSettings()
                    self.title.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.text = TooltipItemSettings()
                    self.text.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TooltipSettings')
        if self.header is not None:
            oprot.writeFieldBegin('header', TType.STRUCT, 1)
            self.header.write(oprot)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRUCT, 2)
            self.title.write(oprot)
            oprot.writeFieldEnd()
        if self.text is not None:
            oprot.writeFieldBegin('text', TType.STRUCT, 3)
            self.text.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
