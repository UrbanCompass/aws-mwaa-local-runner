
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.ad_campaign.models.ttypes
import gen.urbancompass.translation_common.media.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes
import gen.urbancompass.profile.ttypes

from thrift.transport import TTransport


class BriefSource(object):
    LISTING = 0
    INSIGHTS = 1
    CMA = 2

    _VALUES_TO_NAMES = {
        0: "LISTING",
        1: "INSIGHTS",
        2: "CMA",
    }

    _NAMES_TO_VALUES = {
        "LISTING": 0,
        "INSIGHTS": 1,
        "CMA": 2,
    }


class BriefType(object):
    OBJECT = 0
    APP = 1
    MOCK = 2

    _VALUES_TO_NAMES = {
        0: "OBJECT",
        1: "APP",
        2: "MOCK",
    }

    _NAMES_TO_VALUES = {
        "OBJECT": 0,
        "APP": 1,
        "MOCK": 2,
    }


class CmaBrief(object):
    """
    Attributes:
     - subjectProperty
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'subjectProperty', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, subjectProperty=None, listings=None, ):
        self.subjectProperty = subjectProperty
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.subjectProperty = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.subjectProperty.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem4.read(iprot)
                        self.listings.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CmaBrief')
        if self.subjectProperty is not None:
            oprot.writeFieldBegin('subjectProperty', TType.STRUCT, 1)
            self.subjectProperty.write(oprot)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter6 in self.listings:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class InsightsBrief(object):
    """
    Attributes:
     - listings
     - insightsData
     - adCampaign
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'insightsData', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'adCampaign', (gen.urbancompass.ad_campaign.models.ttypes.AdCampaign, gen.urbancompass.ad_campaign.models.ttypes.AdCampaign.thrift_spec), None, ),  # 3
    )
    def __init__(self, listings=None, insightsData=None, adCampaign=None, ):
        self.listings = listings
        self.insightsData = insightsData
        self.adCampaign = adCampaign

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem9.read(iprot)
                        self.listings.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.insightsData = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.adCampaign = gen.urbancompass.ad_campaign.models.ttypes.AdCampaign()
                    self.adCampaign.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('InsightsBrief')
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter11 in self.listings:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.insightsData is not None:
            oprot.writeFieldBegin('insightsData', TType.STRING, 2)
            oprot.writeString(self.insightsData.encode('utf-8') if sys.version_info[0] == 2 else self.insightsData)
            oprot.writeFieldEnd()
        if self.adCampaign is not None:
            oprot.writeFieldBegin('adCampaign', TType.STRUCT, 3)
            self.adCampaign.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingBrief(object):
    """
    Attributes:
     - address
     - neighborhood
     - baths
     - beds
     - price
     - size
     - description
     - media
     - stats
     - subStats
     - agents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'address', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'neighborhood', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'baths', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'beds', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'price', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'size', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'description', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'media', (TType.STRUCT, (gen.urbancompass.translation_common.media.ttypes.Media, gen.urbancompass.translation_common.media.ttypes.Media.thrift_spec), False), None, ),  # 8
        (9, TType.LIST, 'stats', (TType.STRING, 'UTF8', False), None, ),  # 9
        (10, TType.LIST, 'subStats', (TType.STRING, 'UTF8', False), None, ),  # 10
        (11, TType.LIST, 'agents', (TType.STRUCT, (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), False), None, ),  # 11
    )
    def __init__(self, address=None, neighborhood=None, baths=None, beds=None, price=None, size=None, description=None, media=None, stats=None, subStats=None, agents=None, ):
        self.address = address
        self.neighborhood = neighborhood
        self.baths = baths
        self.beds = beds
        self.price = price
        self.size = size
        self.description = description
        self.media = media
        self.stats = stats
        self.subStats = subStats
        self.agents = agents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.neighborhood = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.baths = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.beds = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.price = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.size = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.media = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = gen.urbancompass.translation_common.media.ttypes.Media()
                        _elem14.read(iprot)
                        self.media.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.stats = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.stats.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.subStats = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.subStats.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.agents = []
                    (_etype24, _size27) = iprot.readListBegin()
                    for _i25 in range(_size27):
                        _elem26 = gen.urbancompass.profile.ttypes.Entity()
                        _elem26.read(iprot)
                        self.agents.append(_elem26)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingBrief')
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 1)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.neighborhood is not None:
            oprot.writeFieldBegin('neighborhood', TType.STRING, 2)
            oprot.writeString(self.neighborhood.encode('utf-8') if sys.version_info[0] == 2 else self.neighborhood)
            oprot.writeFieldEnd()
        if self.baths is not None:
            oprot.writeFieldBegin('baths', TType.STRING, 3)
            oprot.writeString(self.baths.encode('utf-8') if sys.version_info[0] == 2 else self.baths)
            oprot.writeFieldEnd()
        if self.beds is not None:
            oprot.writeFieldBegin('beds', TType.STRING, 4)
            oprot.writeString(self.beds.encode('utf-8') if sys.version_info[0] == 2 else self.beds)
            oprot.writeFieldEnd()
        if self.price is not None:
            oprot.writeFieldBegin('price', TType.STRING, 5)
            oprot.writeString(self.price.encode('utf-8') if sys.version_info[0] == 2 else self.price)
            oprot.writeFieldEnd()
        if self.size is not None:
            oprot.writeFieldBegin('size', TType.STRING, 6)
            oprot.writeString(self.size.encode('utf-8') if sys.version_info[0] == 2 else self.size)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 7)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.media is not None:
            oprot.writeFieldBegin('media', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.media))
            for _iter28 in self.media:
                _iter28.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stats is not None:
            oprot.writeFieldBegin('stats', TType.LIST, 9)
            oprot.writeListBegin(TType.STRING, len(self.stats))
            for _iter29 in self.stats:
                oprot.writeString(_iter29.encode('utf-8') if sys.version_info[0] == 2 else _iter29)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.subStats is not None:
            oprot.writeFieldBegin('subStats', TType.LIST, 10)
            oprot.writeListBegin(TType.STRING, len(self.subStats))
            for _iter30 in self.subStats:
                oprot.writeString(_iter30.encode('utf-8') if sys.version_info[0] == 2 else _iter30)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.agents))
            for _iter31 in self.agents:
                _iter31.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BriefData(object):
    """
    Attributes:
     - listings
     - listingBriefs
     - insightsBriefs
     - cmaBriefs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'listingBriefs', (TType.STRUCT, (ListingBrief, ListingBrief.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'insightsBriefs', (TType.STRUCT, (InsightsBrief, InsightsBrief.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'cmaBriefs', (TType.STRUCT, (CmaBrief, CmaBrief.thrift_spec), False), None, ),  # 4
    )
    def __init__(self, listings=None, listingBriefs=None, insightsBriefs=None, cmaBriefs=None, ):
        self.listings = listings
        self.listingBriefs = listingBriefs
        self.insightsBriefs = insightsBriefs
        self.cmaBriefs = cmaBriefs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem34.read(iprot)
                        self.listings.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listingBriefs = []
                    (_etype36, _size39) = iprot.readListBegin()
                    for _i37 in range(_size39):
                        _elem38 = ListingBrief()
                        _elem38.read(iprot)
                        self.listingBriefs.append(_elem38)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.insightsBriefs = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = InsightsBrief()
                        _elem42.read(iprot)
                        self.insightsBriefs.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.cmaBriefs = []
                    (_etype44, _size47) = iprot.readListBegin()
                    for _i45 in range(_size47):
                        _elem46 = CmaBrief()
                        _elem46.read(iprot)
                        self.cmaBriefs.append(_elem46)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BriefData')
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter48 in self.listings:
                _iter48.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingBriefs is not None:
            oprot.writeFieldBegin('listingBriefs', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listingBriefs))
            for _iter49 in self.listingBriefs:
                _iter49.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.insightsBriefs is not None:
            oprot.writeFieldBegin('insightsBriefs', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.insightsBriefs))
            for _iter50 in self.insightsBriefs:
                _iter50.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.cmaBriefs is not None:
            oprot.writeFieldBegin('cmaBriefs', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.cmaBriefs))
            for _iter51 in self.cmaBriefs:
                _iter51.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Brief(object):
    """
    Attributes:
     - _id
     - name
     - description
     - type
     - source
     - data
     - workspaceIds
     - version
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'description', 'UTF8', None, ),  # 3
        (4, TType.I32, 'type', None, None, ),  # 4
        (5, TType.I32, 'source', None, None, ),  # 5
        (6, TType.STRUCT, 'data', (BriefData, BriefData.thrift_spec), None, ),  # 6
        (7, TType.LIST, 'workspaceIds', (TType.STRING, 'UTF8', False), None, ),  # 7
        (8, TType.I32, 'version', None, None, ),  # 8
    )
    def __init__(self, _id=None, name=None, description=None, type=None, source=None, data=None, workspaceIds=None, version=None, ):
        self._id = _id
        self.name = name
        self.description = description
        self.type = type
        self.source = source
        self.data = data
        self.workspaceIds = workspaceIds
        self.version = version

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.source = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.data = BriefData()
                    self.data.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.workspaceIds = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.workspaceIds.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Brief')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 3)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 4)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.I32, 5)
            oprot.writeI32(self.source)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRUCT, 6)
            self.data.write(oprot)
            oprot.writeFieldEnd()
        if self.workspaceIds is not None:
            oprot.writeFieldBegin('workspaceIds', TType.LIST, 7)
            oprot.writeListBegin(TType.STRING, len(self.workspaceIds))
            for _iter56 in self.workspaceIds:
                oprot.writeString(_iter56.encode('utf-8') if sys.version_info[0] == 2 else _iter56)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 8)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
