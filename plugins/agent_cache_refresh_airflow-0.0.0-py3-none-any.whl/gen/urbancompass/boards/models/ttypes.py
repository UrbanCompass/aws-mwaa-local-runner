
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.permissions.acl.ttypes
import gen.urbancompass.notification.delivery.ttypes
import gen.urbancompass.email.ttypes
import gen.urbancompass.folders.ttypes
import gen.urbancompass.notification.notifications.ttypes
import gen.urbancompass.notification.preference.ttypes
import gen.urbancompass.profile.ttypes

from thrift.transport import TTransport


class BoardListingReviewStage(object):
    REVIEW = 0
    REVIEW_REJECTED = 1
    COLLECTION_INTERESTED = 2
    COLLECTION_ARCHIVED = 3

    _VALUES_TO_NAMES = {
        0: "REVIEW",
        1: "REVIEW_REJECTED",
        2: "COLLECTION_INTERESTED",
        3: "COLLECTION_ARCHIVED",
    }

    _NAMES_TO_VALUES = {
        "REVIEW": 0,
        "REVIEW_REJECTED": 1,
        "COLLECTION_INTERESTED": 2,
        "COLLECTION_ARCHIVED": 3,
    }


class BoardListingTourStatus(object):
    REQUESTED = 0
    REQUEST_CANCELLED = 1
    SCHEDULED = 2
    SEEN = 3
    PENDING_CONFIRMATION = 4

    _VALUES_TO_NAMES = {
        0: "REQUESTED",
        1: "REQUEST_CANCELLED",
        2: "SCHEDULED",
        3: "SEEN",
        4: "PENDING_CONFIRMATION",
    }

    _NAMES_TO_VALUES = {
        "REQUESTED": 0,
        "REQUEST_CANCELLED": 1,
        "SCHEDULED": 2,
        "SEEN": 3,
        "PENDING_CONFIRMATION": 4,
    }


class MigrationStatus(object):
    IN_PROCESS = 0
    COMPLETE = 1
    FAILED = 2

    _VALUES_TO_NAMES = {
        0: "IN_PROCESS",
        1: "COMPLETE",
        2: "FAILED",
    }

    _NAMES_TO_VALUES = {
        "IN_PROCESS": 0,
        "COMPLETE": 1,
        "FAILED": 2,
    }


class BoardDraftListingModel(object):
    """
    Attributes:
     - listingIdSHA
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'notes', 'UTF8', None, ),  # 2
    )
    def __init__(self, listingIdSHA=None, notes=None, ):
        self.listingIdSHA = listingIdSHA
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardDraftListingModel')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 2)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardInvitation(object):
    """
    Attributes:
     - emailAddress
     - firstName
     - lastName
     - contactId
     - personId
     - boardId
     - inviterId
     - origin
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'emailAddress', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'boardId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'inviterId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'origin', None, None, ),  # 4
        (5, TType.STRING, 'contactId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'personId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'firstName', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'lastName', 'UTF8', None, ),  # 8
    )
    def __init__(self, emailAddress=None, boardId=None, inviterId=None, origin=None, contactId=None, personId=None, firstName=None, lastName=None, ):
        self.emailAddress = emailAddress
        self.boardId = boardId
        self.inviterId = inviterId
        self.origin = origin
        self.contactId = contactId
        self.personId = personId
        self.firstName = firstName
        self.lastName = lastName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.emailAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.boardId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.inviterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardInvitation')
        if self.emailAddress is not None:
            oprot.writeFieldBegin('emailAddress', TType.STRING, 1)
            oprot.writeString(self.emailAddress.encode('utf-8') if sys.version_info[0] == 2 else self.emailAddress)
            oprot.writeFieldEnd()
        if self.boardId is not None:
            oprot.writeFieldBegin('boardId', TType.STRING, 2)
            oprot.writeString(self.boardId.encode('utf-8') if sys.version_info[0] == 2 else self.boardId)
            oprot.writeFieldEnd()
        if self.inviterId is not None:
            oprot.writeFieldBegin('inviterId', TType.STRING, 3)
            oprot.writeString(self.inviterId.encode('utf-8') if sys.version_info[0] == 2 else self.inviterId)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 4)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 5)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 6)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 7)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 8)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardListingMigrationResult(object):
    """
    Attributes:
     - transactionId
     - code
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'transactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'code', None, None, ),  # 2
        (3, TType.STRING, 'error', 'UTF8', None, ),  # 3
    )
    def __init__(self, transactionId=None, code=None, error=None, ):
        self.transactionId = transactionId
        self.code = code
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.transactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardListingMigrationResult')
        if self.transactionId is not None:
            oprot.writeFieldBegin('transactionId', TType.STRING, 1)
            oprot.writeString(self.transactionId.encode('utf-8') if sys.version_info[0] == 2 else self.transactionId)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 2)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 3)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardNotificationPreference(object):
    """
    Attributes:
     - channel
     - frequency
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'channel', None, None, ),  # 1
        (2, TType.I32, 'frequency', None, None, ),  # 2
    )
    def __init__(self, channel=None, frequency=None, ):
        self.channel = channel
        self.frequency = frequency

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.channel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.frequency = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardNotificationPreference')
        if self.channel is not None:
            oprot.writeFieldBegin('channel', TType.I32, 1)
            oprot.writeI32(self.channel)
            oprot.writeFieldEnd()
        if self.frequency is not None:
            oprot.writeFieldBegin('frequency', TType.I32, 2)
            oprot.writeI32(self.frequency)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class IdSHAFormat(object):
    """
    Attributes:
     - transactionId
     - valid
     - legacyId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'transactionId', None, None, ),  # 1
        (2, TType.BOOL, 'valid', None, None, ),  # 2
        (3, TType.STRING, 'legacyId', 'UTF8', None, ),  # 3
    )
    def __init__(self, transactionId=None, valid=None, legacyId=None, ):
        self.transactionId = transactionId
        self.valid = valid
        self.legacyId = legacyId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.transactionId = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.valid = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.legacyId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('IdSHAFormat')
        if self.transactionId is not None:
            oprot.writeFieldBegin('transactionId', TType.BOOL, 1)
            oprot.writeBool(self.transactionId)
            oprot.writeFieldEnd()
        if self.valid is not None:
            oprot.writeFieldBegin('valid', TType.BOOL, 2)
            oprot.writeBool(self.valid)
            oprot.writeFieldEnd()
        if self.legacyId is not None:
            oprot.writeFieldBegin('legacyId', TType.STRING, 3)
            oprot.writeString(self.legacyId.encode('utf-8') if sys.version_info[0] == 2 else self.legacyId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SavedHomesSource(object):
    """
    Attributes:
     - userId
     - agentUserId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'agentUserId', 'UTF8', None, ),  # 2
    )
    def __init__(self, userId=None, agentUserId=None, ):
        self.userId = userId
        self.agentUserId = agentUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SavedHomesSource')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.agentUserId is not None:
            oprot.writeFieldBegin('agentUserId', TType.STRING, 2)
            oprot.writeString(self.agentUserId.encode('utf-8') if sys.version_info[0] == 2 else self.agentUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UserMigrationLog(object):
    """
    Attributes:
     - _id
     - userId
     - status
     - statusMessage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'status', None, None, ),  # 3
        (4, TType.STRING, 'statusMessage', 'UTF8', None, ),  # 4
    )
    def __init__(self, _id=None, userId=None, status=None, statusMessage=None, ):
        self._id = _id
        self.userId = userId
        self.status = status
        self.statusMessage = statusMessage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.statusMessage = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UserMigrationLog')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 3)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.statusMessage is not None:
            oprot.writeFieldBegin('statusMessage', TType.STRING, 4)
            oprot.writeString(self.statusMessage.encode('utf-8') if sys.version_info[0] == 2 else self.statusMessage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardDraftModel(object):
    """
    Attributes:
     - _id
     - notes
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'notes', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'listings', (TType.STRUCT, (BoardDraftListingModel, BoardDraftListingModel.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, _id=None, notes=None, listings=None, ):
        self._id = _id
        self.notes = notes
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = BoardDraftListingModel()
                        _elem4.read(iprot)
                        self.listings.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardDraftModel')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 2)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter6 in self.listings:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardListingModel(object):
    """
    Attributes:
     - listingIdSHA
     - isInvalidId
     - legacyIdSHA
     - format
     - globallyArchived
     - createdAt
     - createdBy
     - updatedAt
     - updatedBy
     - reviewStage
     - savedSearchIds
     - likelyToSell
     - wantToSee
     - tourStatus
     - tourDate
     - feedListingId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'globallyArchived', None, None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.STRUCT, 'createdBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 4
        (5, TType.I64, 'updatedAt', None, None, ),  # 5
        (6, TType.STRUCT, 'updatedBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 6
        (7, TType.I32, 'reviewStage', None, None, ),  # 7
        (8, TType.SET, 'savedSearchIds', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.STRING, 'feedListingId', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'wantToSee', None, None, ),  # 10
        (11, TType.STRUCT, 'format', (IdSHAFormat, IdSHAFormat.thrift_spec), None, ),  # 11
        (12, TType.BOOL, 'isInvalidId', None, None, ),  # 12
        (13, TType.STRING, 'legacyIdSHA', 'UTF8', None, ),  # 13
        (14, TType.I32, 'tourStatus', None, None, ),  # 14
        (15, TType.I64, 'tourDate', None, None, ),  # 15
        (16, TType.BOOL, 'likelyToSell', None, None, ),  # 16
    )
    def __init__(self, listingIdSHA=None, globallyArchived=None, createdAt=None, createdBy=None, updatedAt=None, updatedBy=None, reviewStage=None, savedSearchIds=None, feedListingId=None, wantToSee=None, format=None, isInvalidId=None, legacyIdSHA=None, tourStatus=None, tourDate=None, likelyToSell=None, ):
        self.listingIdSHA = listingIdSHA
        self.globallyArchived = globallyArchived
        self.createdAt = createdAt
        self.createdBy = createdBy
        self.updatedAt = updatedAt
        self.updatedBy = updatedBy
        self.reviewStage = reviewStage
        self.savedSearchIds = savedSearchIds
        self.feedListingId = feedListingId
        self.wantToSee = wantToSee
        self.format = format
        self.isInvalidId = isInvalidId
        self.legacyIdSHA = legacyIdSHA
        self.tourStatus = tourStatus
        self.tourDate = tourDate
        self.likelyToSell = likelyToSell

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.globallyArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.createdBy = gen.urbancompass.profile.ttypes.Entity()
                    self.createdBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.updatedBy = gen.urbancompass.profile.ttypes.Entity()
                    self.updatedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.reviewStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.SET:
                    self.savedSearchIds = set()
                    (_etype8, _size10) = iprot.readSetBegin()
                    for _i7 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.savedSearchIds.add(_elem9)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.feedListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.wantToSee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.format = IdSHAFormat()
                    self.format.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isInvalidId = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.legacyIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.tourStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I64:
                    self.tourDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.likelyToSell = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardListingModel')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.globallyArchived is not None:
            oprot.writeFieldBegin('globallyArchived', TType.BOOL, 2)
            oprot.writeBool(self.globallyArchived)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRUCT, 4)
            self.createdBy.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 5)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRUCT, 6)
            self.updatedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.reviewStage is not None:
            oprot.writeFieldBegin('reviewStage', TType.I32, 7)
            oprot.writeI32(self.reviewStage)
            oprot.writeFieldEnd()
        if self.savedSearchIds is not None:
            oprot.writeFieldBegin('savedSearchIds', TType.SET, 8)
            oprot.writeSetBegin(TType.STRING, len(self.savedSearchIds))
            for _iter11 in self.savedSearchIds:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.feedListingId is not None:
            oprot.writeFieldBegin('feedListingId', TType.STRING, 9)
            oprot.writeString(self.feedListingId.encode('utf-8') if sys.version_info[0] == 2 else self.feedListingId)
            oprot.writeFieldEnd()
        if self.wantToSee is not None:
            oprot.writeFieldBegin('wantToSee', TType.BOOL, 10)
            oprot.writeBool(self.wantToSee)
            oprot.writeFieldEnd()
        if self.format is not None:
            oprot.writeFieldBegin('format', TType.STRUCT, 11)
            self.format.write(oprot)
            oprot.writeFieldEnd()
        if self.isInvalidId is not None:
            oprot.writeFieldBegin('isInvalidId', TType.BOOL, 12)
            oprot.writeBool(self.isInvalidId)
            oprot.writeFieldEnd()
        if self.legacyIdSHA is not None:
            oprot.writeFieldBegin('legacyIdSHA', TType.STRING, 13)
            oprot.writeString(self.legacyIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.legacyIdSHA)
            oprot.writeFieldEnd()
        if self.tourStatus is not None:
            oprot.writeFieldBegin('tourStatus', TType.I32, 14)
            oprot.writeI32(self.tourStatus)
            oprot.writeFieldEnd()
        if self.tourDate is not None:
            oprot.writeFieldBegin('tourDate', TType.I64, 15)
            oprot.writeI64(self.tourDate)
            oprot.writeFieldEnd()
        if self.likelyToSell is not None:
            oprot.writeFieldBegin('likelyToSell', TType.BOOL, 16)
            oprot.writeBool(self.likelyToSell)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Source(object):
    """
    Attributes:
     - folder
     - savedHomes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'folder', (gen.urbancompass.folders.ttypes.Folder, gen.urbancompass.folders.ttypes.Folder.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'savedHomes', (SavedHomesSource, SavedHomesSource.thrift_spec), None, ),  # 2
    )
    def __init__(self, folder=None, savedHomes=None, ):
        self.folder = folder
        self.savedHomes = savedHomes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.folder = gen.urbancompass.folders.ttypes.Folder()
                    self.folder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.savedHomes = SavedHomesSource()
                    self.savedHomes.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Source')
        if self.folder is not None:
            oprot.writeFieldBegin('folder', TType.STRUCT, 1)
            self.folder.write(oprot)
            oprot.writeFieldEnd()
        if self.savedHomes is not None:
            oprot.writeFieldBegin('savedHomes', TType.STRUCT, 2)
            self.savedHomes.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardModel(object):
    """
    Attributes:
     - _id
     - name
     - createdAt
     - createdBy
     - updatedAt
     - updatedBy
     - deletedAt
     - deletedBy
     - listingAddedAt
     - owner
     - acl
     - listings
     - migratedListingIdSHAsToTransactionIds
     - archivedBy
     - activeCollaborators
     - activeCollaboratorStateTransition
     - source
     - rejectedSuggestedInvitees
     - isPublic
     - description
     - prettyUrls
     - shareableImageUrl
     - collaboratorNotificationPreferences
     - numComments
     - lastCommentedAt
     - numListingsPerReviewStage
     - addSavedSearchResults
     - hideLikelyToSell
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.STRUCT, 'createdBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 4
        (5, TType.I64, 'updatedAt', None, None, ),  # 5
        (6, TType.STRUCT, 'updatedBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 6
        (7, TType.I64, 'listingAddedAt', None, None, ),  # 7
        (8, TType.STRUCT, 'owner', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 8
        (9, TType.LIST, 'acl', (TType.STRUCT, (gen.urbancompass.permissions.acl.ttypes.ACLEntry, gen.urbancompass.permissions.acl.ttypes.ACLEntry.thrift_spec), False), None, ),  # 9
        (10, TType.LIST, 'listings', (TType.STRUCT, (BoardListingModel, BoardListingModel.thrift_spec), False), None, ),  # 10
        (11, TType.LIST, 'archivedBy', (TType.STRUCT, (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), False), None, ),  # 11
        (12, TType.LIST, 'activeCollaborators', (TType.STRUCT, (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), False), None, ),  # 12
        (13, TType.STRUCT, 'source', (Source, Source.thrift_spec), None, ),  # 13
        (14, TType.LIST, 'rejectedSuggestedInvitees', (TType.STRUCT, (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), False), None, ),  # 14
        (15, TType.BOOL, 'isPublic', None, None, ),  # 15
        (16, TType.STRING, 'description', 'UTF8', None, ),  # 16
        (17, TType.LIST, 'prettyUrls', (TType.STRING, 'UTF8', False), None, ),  # 17
        (18, TType.STRING, 'shareableImageUrl', 'UTF8', None, ),  # 18
        (19, TType.MAP, 'collaboratorNotificationPreferences', (TType.I32, None, TType.MAP, (TType.I32, None, TType.I32, None, False), False), None, ),  # 19
        (20, TType.I32, 'numComments', None, None, ),  # 20
        (21, TType.I64, 'lastCommentedAt', None, None, ),  # 21
        (22, TType.MAP, 'numListingsPerReviewStage', (TType.I32, None, TType.I32, None, False), None, ),  # 22
        (23, TType.BOOL, 'activeCollaboratorStateTransition', None, None, ),  # 23
        (24, TType.I64, 'deletedAt', None, None, ),  # 24
        (25, TType.STRUCT, 'deletedBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 25
        (26, TType.BOOL, 'migratedListingIdSHAsToTransactionIds', None, None, ),  # 26
        (27, TType.BOOL, 'addSavedSearchResults', None, None, ),  # 27
        (28, TType.BOOL, 'hideLikelyToSell', None, None, ),  # 28
    )
    def __init__(self, _id=None, name=None, createdAt=None, createdBy=None, updatedAt=None, updatedBy=None, listingAddedAt=None, owner=None, acl=None, listings=None, archivedBy=None, activeCollaborators=None, source=None, rejectedSuggestedInvitees=None, isPublic=None, description=None, prettyUrls=None, shareableImageUrl=None, collaboratorNotificationPreferences=None, numComments=None, lastCommentedAt=None, numListingsPerReviewStage=None, activeCollaboratorStateTransition=None, deletedAt=None, deletedBy=None, migratedListingIdSHAsToTransactionIds=None, addSavedSearchResults=None, hideLikelyToSell=None, ):
        self._id = _id
        self.name = name
        self.createdAt = createdAt
        self.createdBy = createdBy
        self.updatedAt = updatedAt
        self.updatedBy = updatedBy
        self.listingAddedAt = listingAddedAt
        self.owner = owner
        self.acl = acl
        self.listings = listings
        self.archivedBy = archivedBy
        self.activeCollaborators = activeCollaborators
        self.source = source
        self.rejectedSuggestedInvitees = rejectedSuggestedInvitees
        self.isPublic = isPublic
        self.description = description
        self.prettyUrls = prettyUrls
        self.shareableImageUrl = shareableImageUrl
        self.collaboratorNotificationPreferences = collaboratorNotificationPreferences
        self.numComments = numComments
        self.lastCommentedAt = lastCommentedAt
        self.numListingsPerReviewStage = numListingsPerReviewStage
        self.activeCollaboratorStateTransition = activeCollaboratorStateTransition
        self.deletedAt = deletedAt
        self.deletedBy = deletedBy
        self.migratedListingIdSHAsToTransactionIds = migratedListingIdSHAsToTransactionIds
        self.addSavedSearchResults = addSavedSearchResults
        self.hideLikelyToSell = hideLikelyToSell

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.createdBy = gen.urbancompass.profile.ttypes.Entity()
                    self.createdBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.updatedBy = gen.urbancompass.profile.ttypes.Entity()
                    self.updatedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.listingAddedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.owner = gen.urbancompass.profile.ttypes.Entity()
                    self.owner.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.acl = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = gen.urbancompass.permissions.acl.ttypes.ACLEntry()
                        _elem14.read(iprot)
                        self.acl.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = BoardListingModel()
                        _elem18.read(iprot)
                        self.listings.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.archivedBy = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = gen.urbancompass.profile.ttypes.Entity()
                        _elem22.read(iprot)
                        self.archivedBy.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.activeCollaborators = []
                    (_etype24, _size27) = iprot.readListBegin()
                    for _i25 in range(_size27):
                        _elem26 = gen.urbancompass.profile.ttypes.Entity()
                        _elem26.read(iprot)
                        self.activeCollaborators.append(_elem26)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.source = Source()
                    self.source.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.rejectedSuggestedInvitees = []
                    (_etype28, _size31) = iprot.readListBegin()
                    for _i29 in range(_size31):
                        _elem30 = gen.urbancompass.profile.ttypes.Entity()
                        _elem30.read(iprot)
                        self.rejectedSuggestedInvitees.append(_elem30)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.isPublic = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.prettyUrls = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.prettyUrls.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.shareableImageUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.MAP:
                    self.collaboratorNotificationPreferences = {}
                    (_ktype37, _vtype38, _size41) = iprot.readMapBegin()
                    for _i36 in range(_size41):
                        _key39 = iprot.readI32()
                        _val40 = {}
                        (_ktype43, _vtype44, _size47) = iprot.readMapBegin()
                        for _i42 in range(_size47):
                            _key45 = iprot.readI32()
                            _val46 = iprot.readI32()
                            _val40[_key45] = _val46
                        iprot.readMapEnd()
                        self.collaboratorNotificationPreferences[_key39] = _val40
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.numComments = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I64:
                    self.lastCommentedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.MAP:
                    self.numListingsPerReviewStage = {}
                    (_ktype49, _vtype50, _size53) = iprot.readMapBegin()
                    for _i48 in range(_size53):
                        _key51 = iprot.readI32()
                        _val52 = iprot.readI32()
                        self.numListingsPerReviewStage[_key51] = _val52
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.activeCollaboratorStateTransition = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRUCT:
                    self.deletedBy = gen.urbancompass.profile.ttypes.Entity()
                    self.deletedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.BOOL:
                    self.migratedListingIdSHAsToTransactionIds = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.BOOL:
                    self.addSavedSearchResults = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.BOOL:
                    self.hideLikelyToSell = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardModel')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRUCT, 4)
            self.createdBy.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 5)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRUCT, 6)
            self.updatedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.listingAddedAt is not None:
            oprot.writeFieldBegin('listingAddedAt', TType.I64, 7)
            oprot.writeI64(self.listingAddedAt)
            oprot.writeFieldEnd()
        if self.owner is not None:
            oprot.writeFieldBegin('owner', TType.STRUCT, 8)
            self.owner.write(oprot)
            oprot.writeFieldEnd()
        if self.acl is not None:
            oprot.writeFieldBegin('acl', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.acl))
            for _iter54 in self.acl:
                _iter54.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter55 in self.listings:
                _iter55.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.archivedBy is not None:
            oprot.writeFieldBegin('archivedBy', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.archivedBy))
            for _iter56 in self.archivedBy:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.activeCollaborators is not None:
            oprot.writeFieldBegin('activeCollaborators', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.activeCollaborators))
            for _iter57 in self.activeCollaborators:
                _iter57.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRUCT, 13)
            self.source.write(oprot)
            oprot.writeFieldEnd()
        if self.rejectedSuggestedInvitees is not None:
            oprot.writeFieldBegin('rejectedSuggestedInvitees', TType.LIST, 14)
            oprot.writeListBegin(TType.STRUCT, len(self.rejectedSuggestedInvitees))
            for _iter58 in self.rejectedSuggestedInvitees:
                _iter58.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isPublic is not None:
            oprot.writeFieldBegin('isPublic', TType.BOOL, 15)
            oprot.writeBool(self.isPublic)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 16)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.prettyUrls is not None:
            oprot.writeFieldBegin('prettyUrls', TType.LIST, 17)
            oprot.writeListBegin(TType.STRING, len(self.prettyUrls))
            for _iter59 in self.prettyUrls:
                oprot.writeString(_iter59.encode('utf-8') if sys.version_info[0] == 2 else _iter59)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.shareableImageUrl is not None:
            oprot.writeFieldBegin('shareableImageUrl', TType.STRING, 18)
            oprot.writeString(self.shareableImageUrl.encode('utf-8') if sys.version_info[0] == 2 else self.shareableImageUrl)
            oprot.writeFieldEnd()
        if self.collaboratorNotificationPreferences is not None:
            oprot.writeFieldBegin('collaboratorNotificationPreferences', TType.MAP, 19)
            oprot.writeMapBegin(TType.I32, TType.MAP, len(self.collaboratorNotificationPreferences))
            for _kiter60, _viter61 in self.collaboratorNotificationPreferences.items():
                oprot.writeI32(_kiter60)
                oprot.writeMapBegin(TType.I32, TType.I32, len(_viter61))
                for _kiter62, _viter63 in _viter61.items():
                    oprot.writeI32(_kiter62)
                    oprot.writeI32(_viter63)
                oprot.writeMapEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.numComments is not None:
            oprot.writeFieldBegin('numComments', TType.I32, 20)
            oprot.writeI32(self.numComments)
            oprot.writeFieldEnd()
        if self.lastCommentedAt is not None:
            oprot.writeFieldBegin('lastCommentedAt', TType.I64, 21)
            oprot.writeI64(self.lastCommentedAt)
            oprot.writeFieldEnd()
        if self.numListingsPerReviewStage is not None:
            oprot.writeFieldBegin('numListingsPerReviewStage', TType.MAP, 22)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.numListingsPerReviewStage))
            for _kiter64, _viter65 in self.numListingsPerReviewStage.items():
                oprot.writeI32(_kiter64)
                oprot.writeI32(_viter65)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.activeCollaboratorStateTransition is not None:
            oprot.writeFieldBegin('activeCollaboratorStateTransition', TType.BOOL, 23)
            oprot.writeBool(self.activeCollaboratorStateTransition)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 24)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        if self.deletedBy is not None:
            oprot.writeFieldBegin('deletedBy', TType.STRUCT, 25)
            self.deletedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.migratedListingIdSHAsToTransactionIds is not None:
            oprot.writeFieldBegin('migratedListingIdSHAsToTransactionIds', TType.BOOL, 26)
            oprot.writeBool(self.migratedListingIdSHAsToTransactionIds)
            oprot.writeFieldEnd()
        if self.addSavedSearchResults is not None:
            oprot.writeFieldBegin('addSavedSearchResults', TType.BOOL, 27)
            oprot.writeBool(self.addSavedSearchResults)
            oprot.writeFieldEnd()
        if self.hideLikelyToSell is not None:
            oprot.writeFieldBegin('hideLikelyToSell', TType.BOOL, 28)
            oprot.writeBool(self.hideLikelyToSell)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
