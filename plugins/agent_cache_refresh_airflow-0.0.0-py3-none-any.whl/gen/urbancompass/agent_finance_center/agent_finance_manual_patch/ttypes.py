
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class AccountOverrides(object):
    """
    Attributes:
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isDeleted', None, None, ),  # 1
    )
    def __init__(self, isDeleted=None, ):
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountOverrides')
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 1)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AccountPatched(object):
    """
    Attributes:
     - externalId
     - afcId
     - isDeleted
     - afcLastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'externalId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'afcId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isDeleted', None, None, ),  # 3
        (4, TType.I64, 'afcLastModifiedTime', None, None, ),  # 4
    )
    def __init__(self, externalId=None, afcId=None, isDeleted=None, afcLastModifiedTime=None, ):
        self.externalId = externalId
        self.afcId = afcId
        self.isDeleted = isDeleted
        self.afcLastModifiedTime = afcLastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.afcLastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountPatched')
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 1)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 2)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 3)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.afcLastModifiedTime is not None:
            oprot.writeFieldBegin('afcLastModifiedTime', TType.I64, 4)
            oprot.writeI64(self.afcLastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentRoleOverrides(object):
    """
    Attributes:
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isDeleted', None, None, ),  # 1
    )
    def __init__(self, isDeleted=None, ):
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentRoleOverrides')
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 1)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentRolePatched(object):
    """
    Attributes:
     - externalId
     - isDeleted
     - afcLastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'externalId', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'isDeleted', None, None, ),  # 2
        (3, TType.I64, 'afcLastModifiedTime', None, None, ),  # 3
    )
    def __init__(self, externalId=None, isDeleted=None, afcLastModifiedTime=None, ):
        self.externalId = externalId
        self.isDeleted = isDeleted
        self.afcLastModifiedTime = afcLastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.afcLastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentRolePatched')
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 1)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 2)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.afcLastModifiedTime is not None:
            oprot.writeFieldBegin('afcLastModifiedTime', TType.I64, 3)
            oprot.writeI64(self.afcLastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactOverrides(object):
    """
    Attributes:
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isDeleted', None, None, ),  # 1
    )
    def __init__(self, isDeleted=None, ):
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactOverrides')
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 1)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactPatched(object):
    """
    Attributes:
     - externalId
     - afcId
     - isDeleted
     - afcLastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'externalId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'afcId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isDeleted', None, None, ),  # 3
        (4, TType.I64, 'afcLastModifiedTime', None, None, ),  # 4
    )
    def __init__(self, externalId=None, afcId=None, isDeleted=None, afcLastModifiedTime=None, ):
        self.externalId = externalId
        self.afcId = afcId
        self.isDeleted = isDeleted
        self.afcLastModifiedTime = afcLastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.afcLastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactPatched')
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 1)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 2)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 3)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.afcLastModifiedTime is not None:
            oprot.writeFieldBegin('afcLastModifiedTime', TType.I64, 4)
            oprot.writeI64(self.afcLastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealOverrides(object):
    """
    Attributes:
     - afcIsDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'afcIsDeleted', None, None, ),  # 1
    )
    def __init__(self, afcIsDeleted=None, ):
        self.afcIsDeleted = afcIsDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.afcIsDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealOverrides')
        if self.afcIsDeleted is not None:
            oprot.writeFieldBegin('afcIsDeleted', TType.BOOL, 1)
            oprot.writeBool(self.afcIsDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPatched(object):
    """
    Attributes:
     - internalId
     - afcId
     - isDeleted
     - afcLastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'internalId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'afcId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isDeleted', None, None, ),  # 3
        (4, TType.I64, 'afcLastModifiedTime', None, None, ),  # 4
    )
    def __init__(self, internalId=None, afcId=None, isDeleted=None, afcLastModifiedTime=None, ):
        self.internalId = internalId
        self.afcId = afcId
        self.isDeleted = isDeleted
        self.afcLastModifiedTime = afcLastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.internalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.afcLastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPatched')
        if self.internalId is not None:
            oprot.writeFieldBegin('internalId', TType.STRING, 1)
            oprot.writeString(self.internalId.encode('utf-8') if sys.version_info[0] == 2 else self.internalId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 2)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 3)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.afcLastModifiedTime is not None:
            oprot.writeFieldBegin('afcLastModifiedTime', TType.I64, 4)
            oprot.writeI64(self.afcLastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntityDebugInfo(object):
    """
    Attributes:
     - internalId
     - isDeleted
     - externalId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'internalId', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'isDeleted', None, None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
    )
    def __init__(self, internalId=None, isDeleted=None, externalId=None, ):
        self.internalId = internalId
        self.isDeleted = isDeleted
        self.externalId = externalId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.internalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntityDebugInfo')
        if self.internalId is not None:
            oprot.writeFieldBegin('internalId', TType.STRING, 1)
            oprot.writeString(self.internalId.encode('utf-8') if sys.version_info[0] == 2 else self.internalId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 2)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntityOverrides(object):
    """
    Attributes:
     - afcIsDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'afcIsDeleted', None, None, ),  # 1
    )
    def __init__(self, afcIsDeleted=None, ):
        self.afcIsDeleted = afcIsDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.afcIsDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntityOverrides')
        if self.afcIsDeleted is not None:
            oprot.writeFieldBegin('afcIsDeleted', TType.BOOL, 1)
            oprot.writeBool(self.afcIsDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntityPatched(object):
    """
    Attributes:
     - externalId
     - afcId
     - isDeleted
     - afcLastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'externalId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'afcId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isDeleted', None, None, ),  # 3
        (4, TType.I64, 'afcLastModifiedTime', None, None, ),  # 4
    )
    def __init__(self, externalId=None, afcId=None, isDeleted=None, afcLastModifiedTime=None, ):
        self.externalId = externalId
        self.afcId = afcId
        self.isDeleted = isDeleted
        self.afcLastModifiedTime = afcLastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.afcLastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntityPatched')
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 1)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 2)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 3)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.afcLastModifiedTime is not None:
            oprot.writeFieldBegin('afcLastModifiedTime', TType.I64, 4)
            oprot.writeI64(self.afcLastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionOverrides(object):
    """
    Attributes:
     - afcIsDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'afcIsDeleted', None, None, ),  # 1
    )
    def __init__(self, afcIsDeleted=None, ):
        self.afcIsDeleted = afcIsDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.afcIsDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionOverrides')
        if self.afcIsDeleted is not None:
            oprot.writeFieldBegin('afcIsDeleted', TType.BOOL, 1)
            oprot.writeBool(self.afcIsDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionPatched(object):
    """
    Attributes:
     - internalId
     - afcId
     - isDeleted
     - afcLastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'internalId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'afcId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isDeleted', None, None, ),  # 3
        (4, TType.I64, 'afcLastModifiedTime', None, None, ),  # 4
    )
    def __init__(self, internalId=None, afcId=None, isDeleted=None, afcLastModifiedTime=None, ):
        self.internalId = internalId
        self.afcId = afcId
        self.isDeleted = isDeleted
        self.afcLastModifiedTime = afcLastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.internalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.afcLastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionPatched')
        if self.internalId is not None:
            oprot.writeFieldBegin('internalId', TType.STRING, 1)
            oprot.writeString(self.internalId.encode('utf-8') if sys.version_info[0] == 2 else self.internalId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 2)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 3)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.afcLastModifiedTime is not None:
            oprot.writeFieldBegin('afcLastModifiedTime', TType.I64, 4)
            oprot.writeI64(self.afcLastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
