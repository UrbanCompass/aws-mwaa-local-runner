# -*- coding: utf-8 -*-
"""
Tools for validating that a thrift object is not subtly misconstructed.

:copyright: (c) 2016 by UrbanCompass, Inc.
"""

from numbers import Number
from thrift.Thrift import TType


def validate_thrift_object(thrift_object, thrift_class=None):
    """Validate that a thrift_object is a valid thrift.

    :param thrift_object:  the object to be validated.
    :param thrift_class:  the expected class of thrift_object, if known.
    :return:  a list of (path, error). If the list is empty we believe that the object was valid.

    Typical usage is:
      try:
        res = thrift_to_dict(o)
      except Exception:
        for path, error in validate_thrift_object(o):
          logging.error('ERROR  %s: %s', path, error)
        raise

    The errors produced this way are typically way more detailed than the errors produced by thrift
    protocol encoding.
    """
    return _validate_thrift_object(thrift_object, thrift_class, errors=[], path="_")


def _validate_thrift_object(thrift_object, thrift_class, errors, path):
    try:
        if thrift_class is not None and not isinstance(thrift_object, thrift_class):
            errors.append((path, "is not an instance of %r" % thrift_class))
            return errors
        for field_spec in thrift_object.thrift_spec:
            if field_spec is None:
                continue
            field_id, ttype, name, spec_args, default = field_spec
            value = getattr(thrift_object, name)
            if value is None:
                continue
            _validate_thrift_value(value, ttype, spec_args, errors=errors, path=path + "." + name)
    except Exception as e:
        errors.append((path, "ERROR: %r" % e))
    return errors


def _validate_thrift_value(value, ttype, spec_args, errors, path):
    if value is None:
        return None
    if ttype in (TType.STRING, TType.UTF7, TType.UTF16):
        if not isinstance(value, str):
            errors.append((path, "is not an instance of basestring but a %s" % type(value)))
            return
    if ttype in (TType.I08, TType.I16, TType.I32, TType.I64, TType.DOUBLE, TType.BYTE):
        if not isinstance(value, Number):
            errors.append((path, "is not an instance of Number but a %s" % type(value)))
            return
    elif ttype == TType.STRUCT:
        return _validate_thrift_object(value, spec_args[0], errors, path)
    elif ttype in (TType.LIST, TType.SET):
        if not isinstance(value, (list, set)):
            errors.append((path, "is not an instance of list but a %s" % type(value)))
            return
        for i in value:
            _validate_thrift_value(i, spec_args[0], spec_args[1], errors, path + "*")
    elif ttype == TType.MAP:
        if not isinstance(value, dict):
            errors.append((path, "is not an instance of list but a %s" % type(value)))
            return
        for (k, v) in value.items():
            _validate_thrift_value(k, spec_args[0], spec_args[1], errors, path + "(key)")
            _validate_thrift_value(v, spec_args[2], spec_args[3], errors, path + "(value)")
