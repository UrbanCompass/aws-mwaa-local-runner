# Copyright 2013 Urban Compass Inc. All rights reserved

__author__ = "jiqing"

"""
Tools for interacting with s3 in a Urban Compass structured way.
"""
import boto3
import logging

from uc.base import app
from uc.base.app.secret_arguments import add_secret_argument

# TODO: migrate credentials
# from credentials import credential
from uc.aws import s3_tools


def get_defaults_args():
    res = {
        # TODO: migrate credentials
        # "access_key": credential("development", "aws_access_key_id"),
        # "secret_key": credential("development", "aws_secret_access_key"),
        "access_key": "",
        "secret_key": "",
        "bucket": "urbancompass-development",
    }
    return res


def add_args(
    parser=None, default_key=None, default_secret=None, default_bucket=None, role_based=False
):
    if parser is None:
        parser = app.parser
    if role_based:
        # The role based s3 access should provide None credentials. In this case the SDK will
        # automatically generate temporary credentials
        defaults = {"bucket": get_defaults_args()["bucket"]}
    else:
        defaults = get_defaults_args()
    if default_key is None:
        default_key = defaults.get("access_key")
    if default_secret is None:
        default_secret = defaults.get("secret_key")
    if default_bucket is None:
        default_bucket = defaults.get("bucket")
    s3_args = parser.add_argument_group("S3 options")
    add_secret_argument(
        s3_args,
        "--aws_access_key_id",
        default=default_key,
        help="AWS access key for s3. (default: %(default)r)",
    )
    add_secret_argument(
        s3_args,
        "--aws_secret_access_key",
        default=default_secret,
        help="AWS secret key for s3. (default: %(default)r)",
    )
    s3_args.add_argument(
        "--destination_bucket",
        default=default_bucket,
        help="Bucket to save mongo backup. (default: %(default)r)",
    )
    return s3_args


def get_temporary_sts_token():
    sts = boto3.client("sts")
    # Get aws temporary token, default expiration is 12 hours, we will use 24 hours for now
    # Note we could keep the credential as None, the S3 connection would still work but we also
    # might use these credentials to load/unload to redshift, postgres, ... . So we want to get
    # explicitly the credentials and have more control over them (for example in the future,
    # we might need to increase the expiration time of the credentials)
    return sts.get_session_token(DurationSeconds=3600 * 24)


def get_s3_client(
    access_key=None,
    secret_key=None,
    assume_role=None,
    session_assume_role=None,
    sts_token=None,
    bucket=None,
):
    if session_assume_role:
        logging.info("get_s3_client with session_assume_role: {}".format(session_assume_role))
        pass
    elif sts_token:
        pass
    elif assume_role:
        from uc.aws.assume_role import assume_role_session

        logging.info("Use assume role for s3_tools client: {}".format(assume_role))
        session_assume_role = assume_role_session(assume_role, session_name="s3-tools-sessions")
    elif access_key is None or secret_key is None:
        sts_token = get_temporary_sts_token()

    if sts_token:
        access_key = sts_token["Credentials"]["AccessKeyId"]
        secret_key = sts_token["Credentials"]["SecretAccessKey"]

    if bucket:
        if session_assume_role:
            return new_boto_s3_connector(bucket=bucket, assume_role_session=session_assume_role)
        elif access_key and secret_key:
            return new_boto_s3_connector(
                access_key=access_key, secret_key=secret_key, bucket=bucket
            )
        else:
            return new_boto_s3_connector(bucket=bucket, use_iam=True)

    if session_assume_role:
        return s3_tools.Boto3S3Connector(assume_role_session=session_assume_role)
    elif access_key and secret_key:
        return s3_tools.Boto3S3Connector(access_key=access_key, secret_key=secret_key)
    else:
        return s3_tools.Boto3S3Connector()


def new_s3_connector(access_key=None, secret_key=None, bucket=None, use_iam=False, *args, **dargs):
    if (access_key is None or secret_key is None) and not use_iam:
        access_key = app.OPTIONS.aws_access_key_id
        secret_key = app.OPTIONS.aws_secret_access_key
    if bucket is None and hasattr(app.OPTIONS, "destination_bucket"):
        bucket = app.OPTIONS.destination_bucket
    return _S3ConnectorWithDefaultBucket(bucket, access_key, secret_key, *args, **dargs)


class _S3ConnectorWithDefaultBucket(s3_tools.S3Connector):
    def __init__(self, bucket, *args, **dargs):
        self.default_bucket = bucket
        super(_S3ConnectorWithDefaultBucket, self).__init__(*args, **dargs)

    def split(self, s3name):
        if s3name.startswith("s3://"):
            return super(_S3ConnectorWithDefaultBucket, self).split(s3name)
        else:
            return self.default_bucket, s3name

    def get_s3_bucket(self, bucket=None):
        if bucket is None:
            bucket = self.default_bucket
        return super(_S3ConnectorWithDefaultBucket, self).get_s3_bucket(bucket)

    def multipart_upload(self, source, key, bucket_name=None, *args, **dargs):
        if bucket_name is None:
            bucket_name = self.default_bucket
        return super(_S3ConnectorWithDefaultBucket, self).multipart_upload(
            source, key, bucket_name, *args, **dargs
        )


def new_boto_s3_connector(
    access_key=None,
    secret_key=None,
    bucket=None,
    use_iam=False,
    assume_role_session=None,
    *args,
    **dargs
):
    """To aid migration from S3Connector to Boto3S3Connector"""
    if assume_role_session is None and (access_key is None or secret_key is None) and not use_iam:
        access_key = app.OPTIONS.aws_access_key_id
        secret_key = app.OPTIONS.aws_secret_access_key
    if bucket is None and hasattr(app.OPTIONS, "destination_bucket"):
        bucket = app.OPTIONS.destination_bucket
    enrypt = False
    return _BotoS3ConnectorWithDefaultBucket(
        bucket, access_key, secret_key, enrypt, assume_role_session, *args, **dargs
    )


class _BotoS3ConnectorWithDefaultBucket(s3_tools.Boto3S3Connector):
    def __init__(self, bucket, *args, **dargs):
        self.default_bucket = bucket
        super(_BotoS3ConnectorWithDefaultBucket, self).__init__(*args, **dargs)

    def split(self, s3name):
        if s3name.startswith("s3://"):
            return super(_BotoS3ConnectorWithDefaultBucket, self).split(s3name)
        else:
            return self.default_bucket, s3name

    def get_s3_bucket(self, bucket=None):
        if bucket is None:
            bucket = self.default_bucket
        return super(_BotoS3ConnectorWithDefaultBucket, self).get_s3_bucket(bucket)

    def multipart_upload(self, source, key, bucket_name=None, *args, **dargs):
        if bucket_name is None:
            bucket_name = self.default_bucket
        return super(_BotoS3ConnectorWithDefaultBucket, self).multipart_upload(
            source, key, bucket_name, *args, **dargs
        )
