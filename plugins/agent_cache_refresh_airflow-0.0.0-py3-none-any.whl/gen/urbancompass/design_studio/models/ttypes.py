
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.asset.models.ttypes
import gen.urbancompass.brief.models.ttypes
import gen.urbancompass.docstore.ttypes
import gen.urbancompass.listing.listing_status.ttypes
import gen.urbancompass.profile.ttypes

from thrift.transport import TTransport


class CanvasType(object):
    CANVAS = 0
    MARKETING_DOCUMENT = 1
    MARKETING_TEMPLATE = 2
    MARKETING_VIDEO = 3

    _VALUES_TO_NAMES = {
        0: "CANVAS",
        1: "MARKETING_DOCUMENT",
        2: "MARKETING_TEMPLATE",
        3: "MARKETING_VIDEO",
    }

    _NAMES_TO_VALUES = {
        "CANVAS": 0,
        "MARKETING_DOCUMENT": 1,
        "MARKETING_TEMPLATE": 2,
        "MARKETING_VIDEO": 3,
    }


class DesignType(object):
    BROCHURE = 0
    SHOWSHEET = 1
    DEVELOPMENT = 2
    POSTCARD = 3
    INSTAGRAM = 4
    CARD = 5
    INSIGHTS = 6
    WINDOW = 7
    EMAIL = 8
    QUARTERLY = 9
    BOOKLET = 10
    VIDEO = 11
    MARKETING_PLAN = 12

    _VALUES_TO_NAMES = {
        0: "BROCHURE",
        1: "SHOWSHEET",
        2: "DEVELOPMENT",
        3: "POSTCARD",
        4: "INSTAGRAM",
        5: "CARD",
        6: "INSIGHTS",
        7: "WINDOW",
        8: "EMAIL",
        9: "QUARTERLY",
        10: "BOOKLET",
        11: "VIDEO",
        12: "MARKETING_PLAN",
    }

    _NAMES_TO_VALUES = {
        "BROCHURE": 0,
        "SHOWSHEET": 1,
        "DEVELOPMENT": 2,
        "POSTCARD": 3,
        "INSTAGRAM": 4,
        "CARD": 5,
        "INSIGHTS": 6,
        "WINDOW": 7,
        "EMAIL": 8,
        "QUARTERLY": 9,
        "BOOKLET": 10,
        "VIDEO": 11,
        "MARKETING_PLAN": 12,
    }


class FoldType(object):
    NONE = 0
    BIFOLD = 1
    BOOKLET = 2
    TRIFOLD = 3
    GATEFOLD = 4

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "BIFOLD",
        2: "BOOKLET",
        3: "TRIFOLD",
        4: "GATEFOLD",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "BIFOLD": 1,
        "BOOKLET": 2,
        "TRIFOLD": 3,
        "GATEFOLD": 4,
    }


class FulfillmentType(object):
    DOWNLOAD_PDF = 0
    CHECKOUT_XPD = 1
    DOWNLOAD_XPD = 2
    DOWNLOAD_PNG = 3
    PRINT_IN_HOUSE = 4
    SHARE_INSTAGRAM = 5
    SEND_MAILCHIMP = 6
    CHECKOUT_KIRKWOOD = 7
    TEST_EMAILONACID = 8
    GET_HTML_OUTPUT = 9
    SEND_SENDGRID = 10
    DOWNLOAD_PDF_NO_TRANSFORM = 11
    SEND_MC_EMAIL = 12
    AD_CAMPAIGN = 13

    _VALUES_TO_NAMES = {
        0: "DOWNLOAD_PDF",
        1: "CHECKOUT_XPD",
        2: "DOWNLOAD_XPD",
        3: "DOWNLOAD_PNG",
        4: "PRINT_IN_HOUSE",
        5: "SHARE_INSTAGRAM",
        6: "SEND_MAILCHIMP",
        7: "CHECKOUT_KIRKWOOD",
        8: "TEST_EMAILONACID",
        9: "GET_HTML_OUTPUT",
        10: "SEND_SENDGRID",
        11: "DOWNLOAD_PDF_NO_TRANSFORM",
        12: "SEND_MC_EMAIL",
        13: "AD_CAMPAIGN",
    }

    _NAMES_TO_VALUES = {
        "DOWNLOAD_PDF": 0,
        "CHECKOUT_XPD": 1,
        "DOWNLOAD_XPD": 2,
        "DOWNLOAD_PNG": 3,
        "PRINT_IN_HOUSE": 4,
        "SHARE_INSTAGRAM": 5,
        "SEND_MAILCHIMP": 6,
        "CHECKOUT_KIRKWOOD": 7,
        "TEST_EMAILONACID": 8,
        "GET_HTML_OUTPUT": 9,
        "SEND_SENDGRID": 10,
        "DOWNLOAD_PDF_NO_TRANSFORM": 11,
        "SEND_MC_EMAIL": 12,
        "AD_CAMPAIGN": 13,
    }


class OrderStatus(object):
    INITIATED = 0
    IN_PROCESS = 1
    COMPLETED = 2
    CANCELED = 3

    _VALUES_TO_NAMES = {
        0: "INITIATED",
        1: "IN_PROCESS",
        2: "COMPLETED",
        3: "CANCELED",
    }

    _NAMES_TO_VALUES = {
        "INITIATED": 0,
        "IN_PROCESS": 1,
        "COMPLETED": 2,
        "CANCELED": 3,
    }


class SearchType(object):
    LEGACY_PUBLIC_CANVAS = 0
    LEGACY_NON_PUBLIC_CANVAS = 1
    MARKETING_DOCUMENT = 2
    MARKETING_TEMPLATE = 3

    _VALUES_TO_NAMES = {
        0: "LEGACY_PUBLIC_CANVAS",
        1: "LEGACY_NON_PUBLIC_CANVAS",
        2: "MARKETING_DOCUMENT",
        3: "MARKETING_TEMPLATE",
    }

    _NAMES_TO_VALUES = {
        "LEGACY_PUBLIC_CANVAS": 0,
        "LEGACY_NON_PUBLIC_CANVAS": 1,
        "MARKETING_DOCUMENT": 2,
        "MARKETING_TEMPLATE": 3,
    }


class TemplateCategory(object):
    READY_MADE = 0
    LISTING_TEMPLATE = 1

    _VALUES_TO_NAMES = {
        0: "READY_MADE",
        1: "LISTING_TEMPLATE",
    }

    _NAMES_TO_VALUES = {
        "READY_MADE": 0,
        "LISTING_TEMPLATE": 1,
    }


class Vendor(object):
    XPRESSDOCS = 0
    KIRKWOOD = 1

    _VALUES_TO_NAMES = {
        0: "XPRESSDOCS",
        1: "KIRKWOOD",
    }

    _NAMES_TO_VALUES = {
        "XPRESSDOCS": 0,
        "KIRKWOOD": 1,
    }


class Layout(object):
    """
    Attributes:
     - layoutId
     - body
     - pageId
     - collateralId
     - listOrder
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'layoutId', None, None, ),  # 1
        (2, TType.STRING, 'body', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'pageId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'collateralId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'listOrder', None, None, ),  # 5
    )
    def __init__(self, layoutId=None, body=None, pageId=None, collateralId=None, listOrder=None, ):
        self.layoutId = layoutId
        self.body = body
        self.pageId = pageId
        self.collateralId = collateralId
        self.listOrder = listOrder

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.layoutId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.pageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.collateralId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.listOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Layout')
        if self.layoutId is not None:
            oprot.writeFieldBegin('layoutId', TType.I64, 1)
            oprot.writeI64(self.layoutId)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 2)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        if self.pageId is not None:
            oprot.writeFieldBegin('pageId', TType.STRING, 3)
            oprot.writeString(self.pageId.encode('utf-8') if sys.version_info[0] == 2 else self.pageId)
            oprot.writeFieldEnd()
        if self.collateralId is not None:
            oprot.writeFieldBegin('collateralId', TType.STRING, 4)
            oprot.writeString(self.collateralId.encode('utf-8') if sys.version_info[0] == 2 else self.collateralId)
            oprot.writeFieldEnd()
        if self.listOrder is not None:
            oprot.writeFieldBegin('listOrder', TType.I32, 5)
            oprot.writeI32(self.listOrder)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class OrderItem(object):
    """
    Attributes:
     - name
     - externalToken
     - unitPrice
     - quantity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'externalToken', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'unitPrice', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'quantity', 'UTF8', None, ),  # 4
    )
    def __init__(self, name=None, externalToken=None, unitPrice=None, quantity=None, ):
        self.name = name
        self.externalToken = externalToken
        self.unitPrice = unitPrice
        self.quantity = quantity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.externalToken = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.unitPrice = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.quantity = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('OrderItem')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.externalToken is not None:
            oprot.writeFieldBegin('externalToken', TType.STRING, 2)
            oprot.writeString(self.externalToken.encode('utf-8') if sys.version_info[0] == 2 else self.externalToken)
            oprot.writeFieldEnd()
        if self.unitPrice is not None:
            oprot.writeFieldBegin('unitPrice', TType.STRING, 3)
            oprot.writeString(self.unitPrice.encode('utf-8') if sys.version_info[0] == 2 else self.unitPrice)
            oprot.writeFieldEnd()
        if self.quantity is not None:
            oprot.writeFieldBegin('quantity', TType.STRING, 4)
            oprot.writeString(self.quantity.encode('utf-8') if sys.version_info[0] == 2 else self.quantity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class OrderListing(object):
    """
    Attributes:
     - listingIdSHA
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.I32, 'status', None, None, ),  # 2
    )
    def __init__(self, listingIdSHA=None, status=None, ):
        self.listingIdSHA = listingIdSHA
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('OrderListing')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 2)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PageContainer(object):
    """
    Attributes:
     - selectedPageId
     - data
     - pageSetId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'selectedPageId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'data', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'pageSetId', 'UTF8', None, ),  # 3
    )
    def __init__(self, selectedPageId=None, data=None, pageSetId=None, ):
        self.selectedPageId = selectedPageId
        self.data = data
        self.pageSetId = pageSetId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.selectedPageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.data = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.pageSetId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PageContainer')
        if self.selectedPageId is not None:
            oprot.writeFieldBegin('selectedPageId', TType.STRING, 1)
            oprot.writeString(self.selectedPageId.encode('utf-8') if sys.version_info[0] == 2 else self.selectedPageId)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 2)
            oprot.writeString(self.data.encode('utf-8') if sys.version_info[0] == 2 else self.data)
            oprot.writeFieldEnd()
        if self.pageSetId is not None:
            oprot.writeFieldBegin('pageSetId', TType.STRING, 3)
            oprot.writeString(self.pageSetId.encode('utf-8') if sys.version_info[0] == 2 else self.pageSetId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchCanvasResult(object):
    """
    Attributes:
     - _id
     - title
     - designType
     - canvasType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'title', 'UTF8', None, ),  # 2
        (3, TType.I32, 'designType', None, None, ),  # 3
        (4, TType.I32, 'canvasType', None, None, ),  # 4
    )
    def __init__(self, _id=None, title=None, designType=None, canvasType=None, ):
        self._id = _id
        self.title = title
        self.designType = designType
        self.canvasType = canvasType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.designType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.canvasType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchCanvasResult')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 2)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.designType is not None:
            oprot.writeFieldBegin('designType', TType.I32, 3)
            oprot.writeI32(self.designType)
            oprot.writeFieldEnd()
        if self.canvasType is not None:
            oprot.writeFieldBegin('canvasType', TType.I32, 4)
            oprot.writeI32(self.canvasType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShippingAddress(object):
    """
    Attributes:
     - shippingEmail
     - name
     - company
     - address1
     - address2
     - city
     - state
     - country
     - postalCode
     - phone
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'shippingEmail', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'company', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'address1', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'address2', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'city', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'state', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'country', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'postalCode', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'phone', 'UTF8', None, ),  # 10
    )
    def __init__(self, shippingEmail=None, name=None, company=None, address1=None, address2=None, city=None, state=None, country=None, postalCode=None, phone=None, ):
        self.shippingEmail = shippingEmail
        self.name = name
        self.company = company
        self.address1 = address1
        self.address2 = address2
        self.city = city
        self.state = state
        self.country = country
        self.postalCode = postalCode
        self.phone = phone

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.shippingEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.address1 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.address2 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.country = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.postalCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShippingAddress')
        if self.shippingEmail is not None:
            oprot.writeFieldBegin('shippingEmail', TType.STRING, 1)
            oprot.writeString(self.shippingEmail.encode('utf-8') if sys.version_info[0] == 2 else self.shippingEmail)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 3)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.address1 is not None:
            oprot.writeFieldBegin('address1', TType.STRING, 4)
            oprot.writeString(self.address1.encode('utf-8') if sys.version_info[0] == 2 else self.address1)
            oprot.writeFieldEnd()
        if self.address2 is not None:
            oprot.writeFieldBegin('address2', TType.STRING, 5)
            oprot.writeString(self.address2.encode('utf-8') if sys.version_info[0] == 2 else self.address2)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 6)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 7)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.country is not None:
            oprot.writeFieldBegin('country', TType.STRING, 8)
            oprot.writeString(self.country.encode('utf-8') if sys.version_info[0] == 2 else self.country)
            oprot.writeFieldEnd()
        if self.postalCode is not None:
            oprot.writeFieldBegin('postalCode', TType.STRING, 9)
            oprot.writeString(self.postalCode.encode('utf-8') if sys.version_info[0] == 2 else self.postalCode)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 10)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CanvasBody(object):
    """
    Attributes:
     - briefs
     - data
     - pageContainers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'briefs', (TType.STRUCT, (gen.urbancompass.brief.models.ttypes.Brief, gen.urbancompass.brief.models.ttypes.Brief.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'data', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'pageContainers', (TType.STRUCT, (PageContainer, PageContainer.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, briefs=None, data=None, pageContainers=None, ):
        self.briefs = briefs
        self.data = data
        self.pageContainers = pageContainers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.briefs = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.brief.models.ttypes.Brief()
                        _elem4.read(iprot)
                        self.briefs.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.data = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.pageContainers = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = PageContainer()
                        _elem8.read(iprot)
                        self.pageContainers.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CanvasBody')
        if self.briefs is not None:
            oprot.writeFieldBegin('briefs', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.briefs))
            for _iter10 in self.briefs:
                _iter10.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 2)
            oprot.writeString(self.data.encode('utf-8') if sys.version_info[0] == 2 else self.data)
            oprot.writeFieldEnd()
        if self.pageContainers is not None:
            oprot.writeFieldBegin('pageContainers', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.pageContainers))
            for _iter11 in self.pageContainers:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Order(object):
    """
    Attributes:
     - _id
     - createdAt
     - createdByUserId
     - updatedAt
     - updatedByUserId
     - orderId
     - orderDate
     - status
     - userId
     - workspaceId
     - canvasId
     - fulfillmentType
     - vendor
     - sourceUrl
     - templateKey
     - externalOrderId
     - externalUrl
     - items
     - subTotal
     - total
     - shippingAddress
     - designId
     - quantity
     - assetId
     - asset
     - title
     - sharedDate
     - archived
     - publishedTitle
     - categoryId
     - source
     - published
     - designType
     - listingIdSHA
     - emailId
     - designTitle
     - designTypeTitle
     - fulfillmentTypeTitle
     - mediaTypeTitle
     - sourceName
     - publishedTypeName
     - templateName
     - categoryName
     - geoId
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'orderId', 'UTF8', None, ),  # 2
        (3, TType.I64, 'orderDate', None, None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.STRING, 'userId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'workspaceId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'canvasId', 'UTF8', None, ),  # 7
        (8, TType.I32, 'fulfillmentType', None, None, ),  # 8
        (9, TType.I32, 'vendor', None, None, ),  # 9
        (10, TType.STRING, 'sourceUrl', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'templateKey', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'externalOrderId', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'externalUrl', 'UTF8', None, ),  # 13
        (14, TType.LIST, 'items', (TType.STRUCT, (OrderItem, OrderItem.thrift_spec), False), None, ),  # 14
        (15, TType.DOUBLE, 'subTotal', None, None, ),  # 15
        (16, TType.DOUBLE, 'total', None, None, ),  # 16
        (17, TType.STRUCT, 'shippingAddress', (ShippingAddress, ShippingAddress.thrift_spec), None, ),  # 17
        (18, TType.STRING, 'designId', 'UTF8', None, ),  # 18
        (19, TType.I32, 'quantity', None, None, ),  # 19
        (20, TType.STRING, 'assetId', 'UTF8', None, ),  # 20
        (21, TType.STRUCT, 'asset', (gen.urbancompass.asset.models.ttypes.Asset, gen.urbancompass.asset.models.ttypes.Asset.thrift_spec), None, ),  # 21
        (22, TType.STRING, 'title', 'UTF8', None, ),  # 22
        (23, TType.I64, 'sharedDate', None, None, ),  # 23
        (24, TType.BOOL, 'archived', None, None, ),  # 24
        (25, TType.STRING, 'publishedTitle', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'categoryId', 'UTF8', None, ),  # 26
        (27, TType.I32, 'source', None, None, ),  # 27
        (28, TType.BOOL, 'published', None, None, ),  # 28
        (29, TType.I32, 'designType', None, None, ),  # 29
        (30, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 30
        (31, TType.STRING, 'emailId', 'UTF8', None, ),  # 31
        (32, TType.STRING, 'designTitle', 'UTF8', None, ),  # 32
        (33, TType.STRING, 'designTypeTitle', 'UTF8', None, ),  # 33
        (34, TType.STRING, 'fulfillmentTypeTitle', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'mediaTypeTitle', 'UTF8', None, ),  # 35
        (36, TType.STRING, 'sourceName', 'UTF8', None, ),  # 36
        (37, TType.STRING, 'publishedTypeName', 'UTF8', None, ),  # 37
        (38, TType.STRING, 'templateName', 'UTF8', None, ),  # 38
        (39, TType.STRING, 'categoryName', 'UTF8', None, ),  # 39
        (40, TType.STRING, 'geoId', 'UTF8', None, ),  # 40
        (41, TType.LIST, 'listings', (TType.STRUCT, (OrderListing, OrderListing.thrift_spec), False), None, ),  # 41
        (42, TType.I64, 'createdAt', None, None, ),  # 42
        (43, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 43
        (44, TType.I64, 'updatedAt', None, None, ),  # 44
        (45, TType.STRING, 'updatedByUserId', 'UTF8', None, ),  # 45
    )
    def __init__(self, _id=None, orderId=None, orderDate=None, status=None, userId=None, workspaceId=None, canvasId=None, fulfillmentType=None, vendor=None, sourceUrl=None, templateKey=None, externalOrderId=None, externalUrl=None, items=None, subTotal=None, total=None, shippingAddress=None, designId=None, quantity=None, assetId=None, asset=None, title=None, sharedDate=None, archived=None, publishedTitle=None, categoryId=None, source=None, published=None, designType=None, listingIdSHA=None, emailId=None, designTitle=None, designTypeTitle=None, fulfillmentTypeTitle=None, mediaTypeTitle=None, sourceName=None, publishedTypeName=None, templateName=None, categoryName=None, geoId=None, listings=None, createdAt=None, createdByUserId=None, updatedAt=None, updatedByUserId=None, ):
        self._id = _id
        self.orderId = orderId
        self.orderDate = orderDate
        self.status = status
        self.userId = userId
        self.workspaceId = workspaceId
        self.canvasId = canvasId
        self.fulfillmentType = fulfillmentType
        self.vendor = vendor
        self.sourceUrl = sourceUrl
        self.templateKey = templateKey
        self.externalOrderId = externalOrderId
        self.externalUrl = externalUrl
        self.items = items
        self.subTotal = subTotal
        self.total = total
        self.shippingAddress = shippingAddress
        self.designId = designId
        self.quantity = quantity
        self.assetId = assetId
        self.asset = asset
        self.title = title
        self.sharedDate = sharedDate
        self.archived = archived
        self.publishedTitle = publishedTitle
        self.categoryId = categoryId
        self.source = source
        self.published = published
        self.designType = designType
        self.listingIdSHA = listingIdSHA
        self.emailId = emailId
        self.designTitle = designTitle
        self.designTypeTitle = designTypeTitle
        self.fulfillmentTypeTitle = fulfillmentTypeTitle
        self.mediaTypeTitle = mediaTypeTitle
        self.sourceName = sourceName
        self.publishedTypeName = publishedTypeName
        self.templateName = templateName
        self.categoryName = categoryName
        self.geoId = geoId
        self.listings = listings
        self.createdAt = createdAt
        self.createdByUserId = createdByUserId
        self.updatedAt = updatedAt
        self.updatedByUserId = updatedByUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.orderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.orderDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.workspaceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.canvasId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.fulfillmentType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.vendor = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.sourceUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.templateKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.externalOrderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.externalUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.items = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = OrderItem()
                        _elem14.read(iprot)
                        self.items.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.DOUBLE:
                    self.subTotal = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.total = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRUCT:
                    self.shippingAddress = ShippingAddress()
                    self.shippingAddress.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.designId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.quantity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.assetId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRUCT:
                    self.asset = gen.urbancompass.asset.models.ttypes.Asset()
                    self.asset.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I64:
                    self.sharedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.archived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.publishedTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.categoryId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I32:
                    self.source = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.BOOL:
                    self.published = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.I32:
                    self.designType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.emailId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.designTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.STRING:
                    self.designTypeTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.fulfillmentTypeTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.mediaTypeTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.sourceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.STRING:
                    self.publishedTypeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRING:
                    self.templateName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.STRING:
                    self.categoryName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = OrderListing()
                        _elem18.read(iprot)
                        self.listings.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.STRING:
                    self.updatedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Order')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.orderId is not None:
            oprot.writeFieldBegin('orderId', TType.STRING, 2)
            oprot.writeString(self.orderId.encode('utf-8') if sys.version_info[0] == 2 else self.orderId)
            oprot.writeFieldEnd()
        if self.orderDate is not None:
            oprot.writeFieldBegin('orderDate', TType.I64, 3)
            oprot.writeI64(self.orderDate)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 5)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.workspaceId is not None:
            oprot.writeFieldBegin('workspaceId', TType.STRING, 6)
            oprot.writeString(self.workspaceId.encode('utf-8') if sys.version_info[0] == 2 else self.workspaceId)
            oprot.writeFieldEnd()
        if self.canvasId is not None:
            oprot.writeFieldBegin('canvasId', TType.STRING, 7)
            oprot.writeString(self.canvasId.encode('utf-8') if sys.version_info[0] == 2 else self.canvasId)
            oprot.writeFieldEnd()
        if self.fulfillmentType is not None:
            oprot.writeFieldBegin('fulfillmentType', TType.I32, 8)
            oprot.writeI32(self.fulfillmentType)
            oprot.writeFieldEnd()
        if self.vendor is not None:
            oprot.writeFieldBegin('vendor', TType.I32, 9)
            oprot.writeI32(self.vendor)
            oprot.writeFieldEnd()
        if self.sourceUrl is not None:
            oprot.writeFieldBegin('sourceUrl', TType.STRING, 10)
            oprot.writeString(self.sourceUrl.encode('utf-8') if sys.version_info[0] == 2 else self.sourceUrl)
            oprot.writeFieldEnd()
        if self.templateKey is not None:
            oprot.writeFieldBegin('templateKey', TType.STRING, 11)
            oprot.writeString(self.templateKey.encode('utf-8') if sys.version_info[0] == 2 else self.templateKey)
            oprot.writeFieldEnd()
        if self.externalOrderId is not None:
            oprot.writeFieldBegin('externalOrderId', TType.STRING, 12)
            oprot.writeString(self.externalOrderId.encode('utf-8') if sys.version_info[0] == 2 else self.externalOrderId)
            oprot.writeFieldEnd()
        if self.externalUrl is not None:
            oprot.writeFieldBegin('externalUrl', TType.STRING, 13)
            oprot.writeString(self.externalUrl.encode('utf-8') if sys.version_info[0] == 2 else self.externalUrl)
            oprot.writeFieldEnd()
        if self.items is not None:
            oprot.writeFieldBegin('items', TType.LIST, 14)
            oprot.writeListBegin(TType.STRUCT, len(self.items))
            for _iter20 in self.items:
                _iter20.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.subTotal is not None:
            oprot.writeFieldBegin('subTotal', TType.DOUBLE, 15)
            oprot.writeDouble(self.subTotal)
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.DOUBLE, 16)
            oprot.writeDouble(self.total)
            oprot.writeFieldEnd()
        if self.shippingAddress is not None:
            oprot.writeFieldBegin('shippingAddress', TType.STRUCT, 17)
            self.shippingAddress.write(oprot)
            oprot.writeFieldEnd()
        if self.designId is not None:
            oprot.writeFieldBegin('designId', TType.STRING, 18)
            oprot.writeString(self.designId.encode('utf-8') if sys.version_info[0] == 2 else self.designId)
            oprot.writeFieldEnd()
        if self.quantity is not None:
            oprot.writeFieldBegin('quantity', TType.I32, 19)
            oprot.writeI32(self.quantity)
            oprot.writeFieldEnd()
        if self.assetId is not None:
            oprot.writeFieldBegin('assetId', TType.STRING, 20)
            oprot.writeString(self.assetId.encode('utf-8') if sys.version_info[0] == 2 else self.assetId)
            oprot.writeFieldEnd()
        if self.asset is not None:
            oprot.writeFieldBegin('asset', TType.STRUCT, 21)
            self.asset.write(oprot)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 22)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.sharedDate is not None:
            oprot.writeFieldBegin('sharedDate', TType.I64, 23)
            oprot.writeI64(self.sharedDate)
            oprot.writeFieldEnd()
        if self.archived is not None:
            oprot.writeFieldBegin('archived', TType.BOOL, 24)
            oprot.writeBool(self.archived)
            oprot.writeFieldEnd()
        if self.publishedTitle is not None:
            oprot.writeFieldBegin('publishedTitle', TType.STRING, 25)
            oprot.writeString(self.publishedTitle.encode('utf-8') if sys.version_info[0] == 2 else self.publishedTitle)
            oprot.writeFieldEnd()
        if self.categoryId is not None:
            oprot.writeFieldBegin('categoryId', TType.STRING, 26)
            oprot.writeString(self.categoryId.encode('utf-8') if sys.version_info[0] == 2 else self.categoryId)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.I32, 27)
            oprot.writeI32(self.source)
            oprot.writeFieldEnd()
        if self.published is not None:
            oprot.writeFieldBegin('published', TType.BOOL, 28)
            oprot.writeBool(self.published)
            oprot.writeFieldEnd()
        if self.designType is not None:
            oprot.writeFieldBegin('designType', TType.I32, 29)
            oprot.writeI32(self.designType)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 30)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.emailId is not None:
            oprot.writeFieldBegin('emailId', TType.STRING, 31)
            oprot.writeString(self.emailId.encode('utf-8') if sys.version_info[0] == 2 else self.emailId)
            oprot.writeFieldEnd()
        if self.designTitle is not None:
            oprot.writeFieldBegin('designTitle', TType.STRING, 32)
            oprot.writeString(self.designTitle.encode('utf-8') if sys.version_info[0] == 2 else self.designTitle)
            oprot.writeFieldEnd()
        if self.designTypeTitle is not None:
            oprot.writeFieldBegin('designTypeTitle', TType.STRING, 33)
            oprot.writeString(self.designTypeTitle.encode('utf-8') if sys.version_info[0] == 2 else self.designTypeTitle)
            oprot.writeFieldEnd()
        if self.fulfillmentTypeTitle is not None:
            oprot.writeFieldBegin('fulfillmentTypeTitle', TType.STRING, 34)
            oprot.writeString(self.fulfillmentTypeTitle.encode('utf-8') if sys.version_info[0] == 2 else self.fulfillmentTypeTitle)
            oprot.writeFieldEnd()
        if self.mediaTypeTitle is not None:
            oprot.writeFieldBegin('mediaTypeTitle', TType.STRING, 35)
            oprot.writeString(self.mediaTypeTitle.encode('utf-8') if sys.version_info[0] == 2 else self.mediaTypeTitle)
            oprot.writeFieldEnd()
        if self.sourceName is not None:
            oprot.writeFieldBegin('sourceName', TType.STRING, 36)
            oprot.writeString(self.sourceName.encode('utf-8') if sys.version_info[0] == 2 else self.sourceName)
            oprot.writeFieldEnd()
        if self.publishedTypeName is not None:
            oprot.writeFieldBegin('publishedTypeName', TType.STRING, 37)
            oprot.writeString(self.publishedTypeName.encode('utf-8') if sys.version_info[0] == 2 else self.publishedTypeName)
            oprot.writeFieldEnd()
        if self.templateName is not None:
            oprot.writeFieldBegin('templateName', TType.STRING, 38)
            oprot.writeString(self.templateName.encode('utf-8') if sys.version_info[0] == 2 else self.templateName)
            oprot.writeFieldEnd()
        if self.categoryName is not None:
            oprot.writeFieldBegin('categoryName', TType.STRING, 39)
            oprot.writeString(self.categoryName.encode('utf-8') if sys.version_info[0] == 2 else self.categoryName)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 40)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 41)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter21 in self.listings:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 42)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 43)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 44)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.updatedByUserId is not None:
            oprot.writeFieldBegin('updatedByUserId', TType.STRING, 45)
            oprot.writeString(self.updatedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.updatedByUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Canvas(object):
    """
    Attributes:
     - _id
     - workspaceIds
     - designId
     - title
     - detail
     - body
     - version
     - createdAt
     - updatedAt
     - createdByUserId
     - updatedByUserId
     - tags
     - proPrint
     - isPublic
     - publishedAt
     - publishedForGeos
     - categoryId
     - designType
     - imageHandle
     - suggestedImagesRefId
     - publishedTitle
     - emailId
     - uuid
     - showInHomepage
     - canvasType
     - publishedForTeams
     - publishedForAgents
     - templateId
     - parentId
     - subcategoryId
     - collateralUUID
     - activeLayoutsMap
     - foldType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'workspaceIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'designId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'title', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'detail', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'body', (CanvasBody, CanvasBody.thrift_spec), None, ),  # 6
        (7, TType.I32, 'version', None, None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'updatedByUserId', 'UTF8', None, ),  # 11
        (12, TType.SET, 'tags', (TType.STRUCT, (gen.urbancompass.docstore.ttypes.Tag, gen.urbancompass.docstore.ttypes.Tag.thrift_spec), False), None, ),  # 12
        (13, TType.BOOL, 'proPrint', None, None, ),  # 13
        (14, TType.BOOL, 'isPublic', None, None, ),  # 14
        (15, TType.I64, 'publishedAt', None, None, ),  # 15
        (16, TType.SET, 'publishedForGeos', (TType.STRING, 'UTF8', False), None, ),  # 16
        (17, TType.STRING, 'categoryId', 'UTF8', None, ),  # 17
        (18, TType.I32, 'designType', None, None, ),  # 18
        (19, TType.STRING, 'imageHandle', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'suggestedImagesRefId', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'publishedTitle', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'emailId', 'UTF8', None, ),  # 22
        (23, TType.STRING, 'uuid', 'UTF8', None, ),  # 23
        (24, TType.BOOL, 'showInHomepage', None, None, ),  # 24
        (25, TType.I32, 'canvasType', None, None, ),  # 25
        (26, TType.SET, 'publishedForTeams', (TType.STRING, 'UTF8', False), None, ),  # 26
        (27, TType.SET, 'publishedForAgents', (TType.STRING, 'UTF8', False), None, ),  # 27
        (28, TType.STRING, 'templateId', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'parentId', 'UTF8', None, ),  # 29
        (30, TType.STRING, 'subcategoryId', 'UTF8', None, ),  # 30
        (31, TType.STRING, 'collateralUUID', 'UTF8', None, ),  # 31
        (32, TType.MAP, 'activeLayoutsMap', (TType.STRING, 'UTF8', TType.STRUCT, (Layout, Layout.thrift_spec), False), None, ),  # 32
        (33, TType.I32, 'foldType', None, None, ),  # 33
    )
    def __init__(self, _id=None, workspaceIds=None, designId=None, title=None, detail=None, body=None, version=None, createdAt=None, updatedAt=None, createdByUserId=None, updatedByUserId=None, tags=None, proPrint=None, isPublic=None, publishedAt=None, publishedForGeos=None, categoryId=None, designType=None, imageHandle=None, suggestedImagesRefId=None, publishedTitle=None, emailId=None, uuid=None, showInHomepage=None, canvasType=None, publishedForTeams=None, publishedForAgents=None, templateId=None, parentId=None, subcategoryId=None, collateralUUID=None, activeLayoutsMap=None, foldType=None, ):
        self._id = _id
        self.workspaceIds = workspaceIds
        self.designId = designId
        self.title = title
        self.detail = detail
        self.body = body
        self.version = version
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.createdByUserId = createdByUserId
        self.updatedByUserId = updatedByUserId
        self.tags = tags
        self.proPrint = proPrint
        self.isPublic = isPublic
        self.publishedAt = publishedAt
        self.publishedForGeos = publishedForGeos
        self.categoryId = categoryId
        self.designType = designType
        self.imageHandle = imageHandle
        self.suggestedImagesRefId = suggestedImagesRefId
        self.publishedTitle = publishedTitle
        self.emailId = emailId
        self.uuid = uuid
        self.showInHomepage = showInHomepage
        self.canvasType = canvasType
        self.publishedForTeams = publishedForTeams
        self.publishedForAgents = publishedForAgents
        self.templateId = templateId
        self.parentId = parentId
        self.subcategoryId = subcategoryId
        self.collateralUUID = collateralUUID
        self.activeLayoutsMap = activeLayoutsMap
        self.foldType = foldType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.workspaceIds = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.workspaceIds.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.designId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.detail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.body = CanvasBody()
                    self.body.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.updatedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.SET:
                    self.tags = set()
                    (_etype27, _size29) = iprot.readSetBegin()
                    for _i26 in range(_size29):
                        _elem28 = gen.urbancompass.docstore.ttypes.Tag()
                        _elem28.read(iprot)
                        self.tags.add(_elem28)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.proPrint = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.isPublic = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I64:
                    self.publishedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.SET:
                    self.publishedForGeos = set()
                    (_etype31, _size33) = iprot.readSetBegin()
                    for _i30 in range(_size33):
                        _elem32 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.publishedForGeos.add(_elem32)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.categoryId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.designType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.imageHandle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.suggestedImagesRefId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.publishedTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.emailId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.showInHomepage = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.canvasType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.SET:
                    self.publishedForTeams = set()
                    (_etype35, _size37) = iprot.readSetBegin()
                    for _i34 in range(_size37):
                        _elem36 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.publishedForTeams.add(_elem36)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.SET:
                    self.publishedForAgents = set()
                    (_etype39, _size41) = iprot.readSetBegin()
                    for _i38 in range(_size41):
                        _elem40 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.publishedForAgents.add(_elem40)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.templateId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.parentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.subcategoryId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.collateralUUID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.MAP:
                    self.activeLayoutsMap = {}
                    (_ktype43, _vtype44, _size47) = iprot.readMapBegin()
                    for _i42 in range(_size47):
                        _key45 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val46 = Layout()
                        _val46.read(iprot)
                        self.activeLayoutsMap[_key45] = _val46
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I32:
                    self.foldType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Canvas')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.workspaceIds is not None:
            oprot.writeFieldBegin('workspaceIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.workspaceIds))
            for _iter48 in self.workspaceIds:
                oprot.writeString(_iter48.encode('utf-8') if sys.version_info[0] == 2 else _iter48)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.designId is not None:
            oprot.writeFieldBegin('designId', TType.STRING, 3)
            oprot.writeString(self.designId.encode('utf-8') if sys.version_info[0] == 2 else self.designId)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 4)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.detail is not None:
            oprot.writeFieldBegin('detail', TType.STRING, 5)
            oprot.writeString(self.detail.encode('utf-8') if sys.version_info[0] == 2 else self.detail)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRUCT, 6)
            self.body.write(oprot)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 7)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 10)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        if self.updatedByUserId is not None:
            oprot.writeFieldBegin('updatedByUserId', TType.STRING, 11)
            oprot.writeString(self.updatedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.updatedByUserId)
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.SET, 12)
            oprot.writeSetBegin(TType.STRUCT, len(self.tags))
            for _iter49 in self.tags:
                _iter49.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.proPrint is not None:
            oprot.writeFieldBegin('proPrint', TType.BOOL, 13)
            oprot.writeBool(self.proPrint)
            oprot.writeFieldEnd()
        if self.isPublic is not None:
            oprot.writeFieldBegin('isPublic', TType.BOOL, 14)
            oprot.writeBool(self.isPublic)
            oprot.writeFieldEnd()
        if self.publishedAt is not None:
            oprot.writeFieldBegin('publishedAt', TType.I64, 15)
            oprot.writeI64(self.publishedAt)
            oprot.writeFieldEnd()
        if self.publishedForGeos is not None:
            oprot.writeFieldBegin('publishedForGeos', TType.SET, 16)
            oprot.writeSetBegin(TType.STRING, len(self.publishedForGeos))
            for _iter50 in self.publishedForGeos:
                oprot.writeString(_iter50.encode('utf-8') if sys.version_info[0] == 2 else _iter50)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.categoryId is not None:
            oprot.writeFieldBegin('categoryId', TType.STRING, 17)
            oprot.writeString(self.categoryId.encode('utf-8') if sys.version_info[0] == 2 else self.categoryId)
            oprot.writeFieldEnd()
        if self.designType is not None:
            oprot.writeFieldBegin('designType', TType.I32, 18)
            oprot.writeI32(self.designType)
            oprot.writeFieldEnd()
        if self.imageHandle is not None:
            oprot.writeFieldBegin('imageHandle', TType.STRING, 19)
            oprot.writeString(self.imageHandle.encode('utf-8') if sys.version_info[0] == 2 else self.imageHandle)
            oprot.writeFieldEnd()
        if self.suggestedImagesRefId is not None:
            oprot.writeFieldBegin('suggestedImagesRefId', TType.STRING, 20)
            oprot.writeString(self.suggestedImagesRefId.encode('utf-8') if sys.version_info[0] == 2 else self.suggestedImagesRefId)
            oprot.writeFieldEnd()
        if self.publishedTitle is not None:
            oprot.writeFieldBegin('publishedTitle', TType.STRING, 21)
            oprot.writeString(self.publishedTitle.encode('utf-8') if sys.version_info[0] == 2 else self.publishedTitle)
            oprot.writeFieldEnd()
        if self.emailId is not None:
            oprot.writeFieldBegin('emailId', TType.STRING, 22)
            oprot.writeString(self.emailId.encode('utf-8') if sys.version_info[0] == 2 else self.emailId)
            oprot.writeFieldEnd()
        if self.uuid is not None:
            oprot.writeFieldBegin('uuid', TType.STRING, 23)
            oprot.writeString(self.uuid.encode('utf-8') if sys.version_info[0] == 2 else self.uuid)
            oprot.writeFieldEnd()
        if self.showInHomepage is not None:
            oprot.writeFieldBegin('showInHomepage', TType.BOOL, 24)
            oprot.writeBool(self.showInHomepage)
            oprot.writeFieldEnd()
        if self.canvasType is not None:
            oprot.writeFieldBegin('canvasType', TType.I32, 25)
            oprot.writeI32(self.canvasType)
            oprot.writeFieldEnd()
        if self.publishedForTeams is not None:
            oprot.writeFieldBegin('publishedForTeams', TType.SET, 26)
            oprot.writeSetBegin(TType.STRING, len(self.publishedForTeams))
            for _iter51 in self.publishedForTeams:
                oprot.writeString(_iter51.encode('utf-8') if sys.version_info[0] == 2 else _iter51)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.publishedForAgents is not None:
            oprot.writeFieldBegin('publishedForAgents', TType.SET, 27)
            oprot.writeSetBegin(TType.STRING, len(self.publishedForAgents))
            for _iter52 in self.publishedForAgents:
                oprot.writeString(_iter52.encode('utf-8') if sys.version_info[0] == 2 else _iter52)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.templateId is not None:
            oprot.writeFieldBegin('templateId', TType.STRING, 28)
            oprot.writeString(self.templateId.encode('utf-8') if sys.version_info[0] == 2 else self.templateId)
            oprot.writeFieldEnd()
        if self.parentId is not None:
            oprot.writeFieldBegin('parentId', TType.STRING, 29)
            oprot.writeString(self.parentId.encode('utf-8') if sys.version_info[0] == 2 else self.parentId)
            oprot.writeFieldEnd()
        if self.subcategoryId is not None:
            oprot.writeFieldBegin('subcategoryId', TType.STRING, 30)
            oprot.writeString(self.subcategoryId.encode('utf-8') if sys.version_info[0] == 2 else self.subcategoryId)
            oprot.writeFieldEnd()
        if self.collateralUUID is not None:
            oprot.writeFieldBegin('collateralUUID', TType.STRING, 31)
            oprot.writeString(self.collateralUUID.encode('utf-8') if sys.version_info[0] == 2 else self.collateralUUID)
            oprot.writeFieldEnd()
        if self.activeLayoutsMap is not None:
            oprot.writeFieldBegin('activeLayoutsMap', TType.MAP, 32)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.activeLayoutsMap))
            for _kiter53, _viter54 in self.activeLayoutsMap.items():
                oprot.writeString(_kiter53.encode('utf-8') if sys.version_info[0] == 2 else _kiter53)
                _viter54.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.foldType is not None:
            oprot.writeFieldBegin('foldType', TType.I32, 33)
            oprot.writeI32(self.foldType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
