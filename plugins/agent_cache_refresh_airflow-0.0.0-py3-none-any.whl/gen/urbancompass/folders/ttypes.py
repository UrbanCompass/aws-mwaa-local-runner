
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes

from thrift.transport import TTransport


class ListingType(object):
    IN_CONSIDERATION = 0
    ARCHIVE = 1

    _VALUES_TO_NAMES = {
        0: "IN_CONSIDERATION",
        1: "ARCHIVE",
    }

    _NAMES_TO_VALUES = {
        "IN_CONSIDERATION": 0,
        "ARCHIVE": 1,
    }


class RequestOrigin(object):
    SEARCH = 0
    INBOX = 1
    SUBMISSION = 2
    BUCKET = 3
    DESKTOP_FOLDER = 4

    _VALUES_TO_NAMES = {
        0: "SEARCH",
        1: "INBOX",
        2: "SUBMISSION",
        3: "BUCKET",
        4: "DESKTOP_FOLDER",
    }

    _NAMES_TO_VALUES = {
        "SEARCH": 0,
        "INBOX": 1,
        "SUBMISSION": 2,
        "BUCKET": 3,
        "DESKTOP_FOLDER": 4,
    }


class ListingNote(object):
    """
    Attributes:
     - _id
     - note
     - createdAt
     - createdByUserId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'note', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 4
    )
    def __init__(self, _id=None, note=None, createdAt=None, createdByUserId=None, ):
        self._id = _id
        self.note = note
        self.createdAt = createdAt
        self.createdByUserId = createdByUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingNote')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 2)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 4)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchAlert(object):
    """
    Attributes:
     - searchAlertId
     - createdAt
     - createdByUserId
     - updatedAt
     - updatedByUserId
     - name
     - listingIdSHAs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'searchAlertId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.STRING, 'updatedByUserId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'name', 'UTF8', None, ),  # 6
        (7, TType.LIST, 'listingIdSHAs', (TType.STRING, 'UTF8', False), None, ),  # 7
    )
    def __init__(self, searchAlertId=None, createdAt=None, createdByUserId=None, updatedAt=None, updatedByUserId=None, name=None, listingIdSHAs=None, ):
        self.searchAlertId = searchAlertId
        self.createdAt = createdAt
        self.createdByUserId = createdByUserId
        self.updatedAt = updatedAt
        self.updatedByUserId = updatedByUserId
        self.name = name
        self.listingIdSHAs = listingIdSHAs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.searchAlertId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.updatedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.listingIdSHAs = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAs.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchAlert')
        if self.searchAlertId is not None:
            oprot.writeFieldBegin('searchAlertId', TType.STRING, 1)
            oprot.writeString(self.searchAlertId.encode('utf-8') if sys.version_info[0] == 2 else self.searchAlertId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 3)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.updatedByUserId is not None:
            oprot.writeFieldBegin('updatedByUserId', TType.STRING, 5)
            oprot.writeString(self.updatedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.updatedByUserId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 6)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.listingIdSHAs is not None:
            oprot.writeFieldBegin('listingIdSHAs', TType.LIST, 7)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAs))
            for _iter6 in self.listingIdSHAs:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UserInformation(object):
    """
    Attributes:
     - _id
     - firstName
     - lastName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'firstName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'lastName', 'UTF8', None, ),  # 3
    )
    def __init__(self, _id=None, firstName=None, lastName=None, ):
        self._id = _id
        self.firstName = firstName
        self.lastName = lastName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UserInformation')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 2)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 3)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Agent(object):
    """
    Attributes:
     - agent
     - createdAt
     - createdByUserId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'agent', (UserInformation, UserInformation.thrift_spec), None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 3
    )
    def __init__(self, agent=None, createdAt=None, createdByUserId=None, ):
        self.agent = agent
        self.createdAt = createdAt
        self.createdByUserId = createdByUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.agent = UserInformation()
                    self.agent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Agent')
        if self.agent is not None:
            oprot.writeFieldBegin('agent', TType.STRUCT, 1)
            self.agent.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 3)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Customer(object):
    """
    Attributes:
     - customer
     - createdAt
     - createdByUserId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'customer', (UserInformation, UserInformation.thrift_spec), None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 3
    )
    def __init__(self, customer=None, createdAt=None, createdByUserId=None, ):
        self.customer = customer
        self.createdAt = createdAt
        self.createdByUserId = createdByUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.customer = UserInformation()
                    self.customer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Customer')
        if self.customer is not None:
            oprot.writeFieldBegin('customer', TType.STRUCT, 1)
            self.customer.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 3)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Listing(object):
    """
    Attributes:
     - listingIdSHA
     - type
     - createdAt
     - updatedAt
     - createdByUserId
     - updatedByUserId
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, 0, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'updatedByUserId', 'UTF8', None, ),  # 6
        (7, TType.LIST, 'notes', (TType.STRUCT, (ListingNote, ListingNote.thrift_spec), False), None, ),  # 7
    )
    def __init__(self, listingIdSHA=None, type=thrift_spec[2][4], createdAt=None, updatedAt=None, createdByUserId=None, updatedByUserId=None, notes=None, ):
        self.listingIdSHA = listingIdSHA
        self.type = type
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.createdByUserId = createdByUserId
        self.updatedByUserId = updatedByUserId
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.updatedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.notes = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = ListingNote()
                        _elem9.read(iprot)
                        self.notes.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Listing')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 5)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        if self.updatedByUserId is not None:
            oprot.writeFieldBegin('updatedByUserId', TType.STRING, 6)
            oprot.writeString(self.updatedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.updatedByUserId)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.notes))
            for _iter11 in self.notes:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Folder(object):
    """
    Attributes:
     - _id
     - folderName
     - searchAlerts
     - listings
     - customers
     - agents
     - searchTerms
     - createdAt
     - updatedAt
     - createdByUserId
     - updatedByUserId
     - version
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'folderName', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'searchAlerts', (TType.STRUCT, (SearchAlert, SearchAlert.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'listings', (TType.STRUCT, (Listing, Listing.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'customers', (TType.STRUCT, (Customer, Customer.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'agents', (TType.STRUCT, (Agent, Agent.thrift_spec), False), None, ),  # 6
        (7, TType.LIST, 'searchTerms', (TType.STRING, 'UTF8', False), None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'updatedByUserId', 'UTF8', None, ),  # 11
        (12, TType.I32, 'version', None, None, ),  # 12
    )
    def __init__(self, _id=None, folderName=None, searchAlerts=None, listings=None, customers=None, agents=None, searchTerms=None, createdAt=None, updatedAt=None, createdByUserId=None, updatedByUserId=None, version=None, ):
        self._id = _id
        self.folderName = folderName
        self.searchAlerts = searchAlerts
        self.listings = listings
        self.customers = customers
        self.agents = agents
        self.searchTerms = searchTerms
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.createdByUserId = createdByUserId
        self.updatedByUserId = updatedByUserId
        self.version = version

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.folderName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.searchAlerts = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = SearchAlert()
                        _elem14.read(iprot)
                        self.searchAlerts.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = Listing()
                        _elem18.read(iprot)
                        self.listings.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.customers = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = Customer()
                        _elem22.read(iprot)
                        self.customers.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.agents = []
                    (_etype24, _size27) = iprot.readListBegin()
                    for _i25 in range(_size27):
                        _elem26 = Agent()
                        _elem26.read(iprot)
                        self.agents.append(_elem26)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.searchTerms = []
                    (_etype28, _size31) = iprot.readListBegin()
                    for _i29 in range(_size31):
                        _elem30 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.searchTerms.append(_elem30)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.updatedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Folder')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.folderName is not None:
            oprot.writeFieldBegin('folderName', TType.STRING, 2)
            oprot.writeString(self.folderName.encode('utf-8') if sys.version_info[0] == 2 else self.folderName)
            oprot.writeFieldEnd()
        if self.searchAlerts is not None:
            oprot.writeFieldBegin('searchAlerts', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.searchAlerts))
            for _iter32 in self.searchAlerts:
                _iter32.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter33 in self.listings:
                _iter33.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.customers is not None:
            oprot.writeFieldBegin('customers', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.customers))
            for _iter34 in self.customers:
                _iter34.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.agents))
            for _iter35 in self.agents:
                _iter35.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.searchTerms is not None:
            oprot.writeFieldBegin('searchTerms', TType.LIST, 7)
            oprot.writeListBegin(TType.STRING, len(self.searchTerms))
            for _iter36 in self.searchTerms:
                oprot.writeString(_iter36.encode('utf-8') if sys.version_info[0] == 2 else _iter36)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 10)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        if self.updatedByUserId is not None:
            oprot.writeFieldBegin('updatedByUserId', TType.STRING, 11)
            oprot.writeString(self.updatedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.updatedByUserId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 12)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
