# -*- coding: utf-8 -*-
"""
Client Profile interceptor. Stores the information about last calling client in
request context.

:copyright: (c) 2018 by UrbanCompass, Inc.
"""
import grpc
import logging

from grpc._interceptor import _ClientCallDetails

from uc.base.app import get_app_name, get_host
from gen.urbancompass.common.base.constants import CLIENT_PROFILE_METADATA_KEY
from gen.urbancompass.common.base.ttypes import ClientProfile

from thrift.TSerialization import serialize
from thrift.protocol.TBinaryProtocol import TBinaryProtocolFactory


class ClientProfileInterceptor(grpc.UnaryUnaryClientInterceptor):
    def intercept_unary_unary(self, continuation, client_call_details, request):
        """An interceptor that adds a thrift-serialized ClientProfile to
         the grpc Context metadata. This can be in turn used by the servers to identify their clients
         This is the implementation of
         https://grpc.github.io/grpc/python/_modules/grpc.html#UnaryUnaryClientInterceptor.intercept_unary_unary
        :param continuation: A function that proceeds with the invocation by
                executing the next interceptor in chain or invoking the
                actual RPC on the underlying Channel. It is the interceptor's
                responsibility to call it if it decides to move the RPC forward.
                The interceptor can use
                `response_iterator = continuation(client_call_details, request)`
                to continue with the RPC. `continuation` returns an object that is
                both a Call for the RPC and an iterator for response values.
                Drawing response values from the returned Call-iterator may
                raise RpcError indicating termination of the RPC with non-OK
                status.
        :param client_call_details: A ClientCallDetails object describing the
                outgoing RPC.
        :param request: The request value for the RPC.
        :return: An object that is both a Call for the RPC and an iterator of
                response values. Drawing response values from the returned
                Call-iterator may raise RpcError indicating termination of
                the RPC with non-OK status.
        """
        metadata = {}
        if client_call_details.metadata is not None:
            metadata = dict(client_call_details.metadata)
        serialized_client_profile = None
        try:
            app_name = get_app_name()
            if app_name:
                logging.debug("app_name=%s" % app_name)
                client_profile = ClientProfile(appName=app_name, source=get_host())
                serialized_client_profile = serialize(
                    client_profile, protocol_factory=TBinaryProtocolFactory()
                )
        except Exception as e:
            logging.warning(
                "{} Serialization failed with error: {}".format(self.__class__.__name__, e)
            )
        else:
            if serialized_client_profile:
                metadata[CLIENT_PROFILE_METADATA_KEY] = serialized_client_profile

        client_call_details = _ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=list(metadata.items()),
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
            compression=client_call_details.compression,
        )

        response = continuation(client_call_details, request)
        return response
