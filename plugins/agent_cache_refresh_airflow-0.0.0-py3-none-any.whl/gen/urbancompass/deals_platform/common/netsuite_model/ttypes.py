
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals_platform.common.gci_model.ttypes

from thrift.transport import TTransport


class ApprovalStatus(object):
    UNKNOWN = 0
    PENDING_APPROVAL = 1
    APPROVAL_REJECTED = 2
    APPROVED = 3
    PAYMENT_HOLD = 4
    PENDING_W9 = 5
    PENDING_AGENT_ID = 6

    _VALUES_TO_NAMES = {
        0: "UNKNOWN",
        1: "PENDING_APPROVAL",
        2: "APPROVAL_REJECTED",
        3: "APPROVED",
        4: "PAYMENT_HOLD",
        5: "PENDING_W9",
        6: "PENDING_AGENT_ID",
    }

    _NAMES_TO_VALUES = {
        "UNKNOWN": 0,
        "PENDING_APPROVAL": 1,
        "APPROVAL_REJECTED": 2,
        "APPROVED": 3,
        "PAYMENT_HOLD": 4,
        "PENDING_W9": 5,
        "PENDING_AGENT_ID": 6,
    }


class InvoiceStatus(object):
    OPEN = 0
    PAID_IN_FULL = 1
    VOIDED = 2

    _VALUES_TO_NAMES = {
        0: "OPEN",
        1: "PAID_IN_FULL",
        2: "VOIDED",
    }

    _NAMES_TO_VALUES = {
        "OPEN": 0,
        "PAID_IN_FULL": 1,
        "VOIDED": 2,
    }


class NetSuiteEntityType(object):
    CUSTOMER = 0
    VENDOR = 1

    _VALUES_TO_NAMES = {
        0: "CUSTOMER",
        1: "VENDOR",
    }

    _NAMES_TO_VALUES = {
        "CUSTOMER": 0,
        "VENDOR": 1,
    }


class NetsuiteCurrency(object):
    USD = 0

    _VALUES_TO_NAMES = {
        0: "USD",
    }

    _NAMES_TO_VALUES = {
        "USD": 0,
    }


class NetsuiteMarketingPaymentType(object):
    CUSTOMER_PAYMENT = 0

    _VALUES_TO_NAMES = {
        0: "CUSTOMER_PAYMENT",
    }

    _NAMES_TO_VALUES = {
        "CUSTOMER_PAYMENT": 0,
    }


class NetsuiteShippingMethod(object):
    FREIGHT = 0
    UPS_TWO_DAY_AIR = 1
    UPS_ONE_DAY_AIR_SAVER = 2
    UPS_ONE_DAY_AIR_EARLY = 3

    _VALUES_TO_NAMES = {
        0: "FREIGHT",
        1: "UPS_TWO_DAY_AIR",
        2: "UPS_ONE_DAY_AIR_SAVER",
        3: "UPS_ONE_DAY_AIR_EARLY",
    }

    _NAMES_TO_VALUES = {
        "FREIGHT": 0,
        "UPS_TWO_DAY_AIR": 1,
        "UPS_ONE_DAY_AIR_SAVER": 2,
        "UPS_ONE_DAY_AIR_EARLY": 3,
    }


class PaymentStatus(object):
    SUCCESS = 0
    FAIL = 1

    _VALUES_TO_NAMES = {
        0: "SUCCESS",
        1: "FAIL",
    }

    _NAMES_TO_VALUES = {
        "SUCCESS": 0,
        "FAIL": 1,
    }


class NetSuiteEntityName(object):
    """
    Attributes:
     - uniqueName
     - companyName
     - checkName
     - fullName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'uniqueName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'companyName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'checkName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'fullName', 'UTF8', None, ),  # 4
    )
    def __init__(self, uniqueName=None, companyName=None, checkName=None, fullName=None, ):
        self.uniqueName = uniqueName
        self.companyName = companyName
        self.checkName = checkName
        self.fullName = fullName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.uniqueName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.companyName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.checkName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.fullName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetSuiteEntityName')
        if self.uniqueName is not None:
            oprot.writeFieldBegin('uniqueName', TType.STRING, 1)
            oprot.writeString(self.uniqueName.encode('utf-8') if sys.version_info[0] == 2 else self.uniqueName)
            oprot.writeFieldEnd()
        if self.companyName is not None:
            oprot.writeFieldBegin('companyName', TType.STRING, 2)
            oprot.writeString(self.companyName.encode('utf-8') if sys.version_info[0] == 2 else self.companyName)
            oprot.writeFieldEnd()
        if self.checkName is not None:
            oprot.writeFieldBegin('checkName', TType.STRING, 3)
            oprot.writeString(self.checkName.encode('utf-8') if sys.version_info[0] == 2 else self.checkName)
            oprot.writeFieldEnd()
        if self.fullName is not None:
            oprot.writeFieldBegin('fullName', TType.STRING, 4)
            oprot.writeString(self.fullName.encode('utf-8') if sys.version_info[0] == 2 else self.fullName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetSuiteEntityRole(object):
    """
    Attributes:
     - type
     - subsidiaries
     - vendorApprovalStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.LIST, 'subsidiaries', (TType.I32, None, False), None, ),  # 2
        (3, TType.I32, 'vendorApprovalStatus', None, None, ),  # 3
    )
    def __init__(self, type=None, subsidiaries=None, vendorApprovalStatus=None, ):
        self.type = type
        self.subsidiaries = subsidiaries
        self.vendorApprovalStatus = vendorApprovalStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.subsidiaries = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readI32()
                        self.subsidiaries.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.vendorApprovalStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetSuiteEntityRole')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.subsidiaries is not None:
            oprot.writeFieldBegin('subsidiaries', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.subsidiaries))
            for _iter6 in self.subsidiaries:
                oprot.writeI32(_iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.vendorApprovalStatus is not None:
            oprot.writeFieldBegin('vendorApprovalStatus', TType.I32, 3)
            oprot.writeI32(self.vendorApprovalStatus)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteAdditionalTerm(object):
    """
    Attributes:
     - balance
     - id
     - type
     - percent
     - cap
     - startDate
     - endDate
     - lastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'balance', None, None, ),  # 1
        (2, TType.I32, 'id', None, None, ),  # 2
        (3, TType.STRING, 'type', 'UTF8', None, ),  # 3
        (4, TType.DOUBLE, 'percent', None, None, ),  # 4
        (5, TType.DOUBLE, 'cap', None, None, ),  # 5
        (6, TType.STRING, 'startDate', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'endDate', 'UTF8', None, ),  # 7
        (8, TType.I64, 'lastModifiedTime', None, None, ),  # 8
    )
    def __init__(self, balance=None, id=None, type=None, percent=None, cap=None, startDate=None, endDate=None, lastModifiedTime=None, ):
        self.balance = balance
        self.id = id
        self.type = type
        self.percent = percent
        self.cap = cap
        self.startDate = startDate
        self.endDate = endDate
        self.lastModifiedTime = lastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.balance = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.cap = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.startDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.endDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteAdditionalTerm')
        if self.balance is not None:
            oprot.writeFieldBegin('balance', TType.DOUBLE, 1)
            oprot.writeDouble(self.balance)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 2)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 3)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 4)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.cap is not None:
            oprot.writeFieldBegin('cap', TType.DOUBLE, 5)
            oprot.writeDouble(self.cap)
            oprot.writeFieldEnd()
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.STRING, 6)
            oprot.writeString(self.startDate.encode('utf-8') if sys.version_info[0] == 2 else self.startDate)
            oprot.writeFieldEnd()
        if self.endDate is not None:
            oprot.writeFieldBegin('endDate', TType.STRING, 7)
            oprot.writeString(self.endDate.encode('utf-8') if sys.version_info[0] == 2 else self.endDate)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 8)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteAddress(object):
    """
    Attributes:
     - address1
     - address2
     - city
     - state
     - zipCode
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'address1', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'address2', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'city', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'state', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'zipCode', 'UTF8', None, ),  # 5
    )
    def __init__(self, address1=None, address2=None, city=None, state=None, zipCode=None, ):
        self.address1 = address1
        self.address2 = address2
        self.city = city
        self.state = state
        self.zipCode = zipCode

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.address1 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.address2 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteAddress')
        if self.address1 is not None:
            oprot.writeFieldBegin('address1', TType.STRING, 1)
            oprot.writeString(self.address1.encode('utf-8') if sys.version_info[0] == 2 else self.address1)
            oprot.writeFieldEnd()
        if self.address2 is not None:
            oprot.writeFieldBegin('address2', TType.STRING, 2)
            oprot.writeString(self.address2.encode('utf-8') if sys.version_info[0] == 2 else self.address2)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 3)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 4)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 5)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteAgent(object):
    """
    Attributes:
     - amaCompassTeamId
     - amaId
     - amaCompassId
     - agentName
     - teamId
     - teamName
     - officeName
     - market
     - submarket
     - officeLocationId
     - submarketSubsidiaryId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'amaCompassTeamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'amaId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'amaCompassId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'agentName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'teamId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'teamName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'officeName', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'market', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'submarket', 'UTF8', None, ),  # 9
        (10, TType.I32, 'officeLocationId', None, None, ),  # 10
        (11, TType.I32, 'submarketSubsidiaryId', None, None, ),  # 11
    )
    def __init__(self, amaCompassTeamId=None, amaId=None, amaCompassId=None, agentName=None, teamId=None, teamName=None, officeName=None, market=None, submarket=None, officeLocationId=None, submarketSubsidiaryId=None, ):
        self.amaCompassTeamId = amaCompassTeamId
        self.amaId = amaId
        self.amaCompassId = amaCompassId
        self.agentName = agentName
        self.teamId = teamId
        self.teamName = teamName
        self.officeName = officeName
        self.market = market
        self.submarket = submarket
        self.officeLocationId = officeLocationId
        self.submarketSubsidiaryId = submarketSubsidiaryId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.amaCompassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.amaCompassId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.teamName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.officeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.submarket = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.officeLocationId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.submarketSubsidiaryId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteAgent')
        if self.amaCompassTeamId is not None:
            oprot.writeFieldBegin('amaCompassTeamId', TType.STRING, 1)
            oprot.writeString(self.amaCompassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.amaCompassTeamId)
            oprot.writeFieldEnd()
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 2)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.amaCompassId is not None:
            oprot.writeFieldBegin('amaCompassId', TType.STRING, 3)
            oprot.writeString(self.amaCompassId.encode('utf-8') if sys.version_info[0] == 2 else self.amaCompassId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 4)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 5)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.teamName is not None:
            oprot.writeFieldBegin('teamName', TType.STRING, 6)
            oprot.writeString(self.teamName.encode('utf-8') if sys.version_info[0] == 2 else self.teamName)
            oprot.writeFieldEnd()
        if self.officeName is not None:
            oprot.writeFieldBegin('officeName', TType.STRING, 7)
            oprot.writeString(self.officeName.encode('utf-8') if sys.version_info[0] == 2 else self.officeName)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 8)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.submarket is not None:
            oprot.writeFieldBegin('submarket', TType.STRING, 9)
            oprot.writeString(self.submarket.encode('utf-8') if sys.version_info[0] == 2 else self.submarket)
            oprot.writeFieldEnd()
        if self.officeLocationId is not None:
            oprot.writeFieldBegin('officeLocationId', TType.I32, 10)
            oprot.writeI32(self.officeLocationId)
            oprot.writeFieldEnd()
        if self.submarketSubsidiaryId is not None:
            oprot.writeFieldBegin('submarketSubsidiaryId', TType.I32, 11)
            oprot.writeI32(self.submarketSubsidiaryId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteCreateEntityRequest(object):
    """
    Attributes:
     - name
     - email
     - type
     - subsidiary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
        (3, TType.I32, 'type', None, None, ),  # 3
        (4, TType.I32, 'subsidiary', None, None, ),  # 4
    )
    def __init__(self, name=None, email=None, type=None, subsidiary=None, ):
        self.name = name
        self.email = email
        self.type = type
        self.subsidiary = subsidiary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.subsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteCreateEntityRequest')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 3)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.I32, 4)
            oprot.writeI32(self.subsidiary)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteError(object):
    """
    Attributes:
     - code
     - message
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'code', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'message', 'UTF8', None, ),  # 2
    )
    def __init__(self, code=None, message=None, ):
        self.code = code
        self.message = message

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.code = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.message = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteError')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.STRING, 1)
            oprot.writeString(self.code.encode('utf-8') if sys.version_info[0] == 2 else self.code)
            oprot.writeFieldEnd()
        if self.message is not None:
            oprot.writeFieldBegin('message', TType.STRING, 2)
            oprot.writeString(self.message.encode('utf-8') if sys.version_info[0] == 2 else self.message)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteGciRecord(object):
    """
    Attributes:
     - teamId
     - ltmGci
     - ytdGci
     - asOfDate
     - ttdGci
     - startDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'ltmGci', None, None, ),  # 2
        (3, TType.DOUBLE, 'ytdGci', None, None, ),  # 3
        (4, TType.STRING, 'asOfDate', 'UTF8', None, ),  # 4
        (5, TType.DOUBLE, 'ttdGci', None, None, ),  # 5
        (6, TType.STRING, 'startDate', 'UTF8', None, ),  # 6
    )
    def __init__(self, teamId=None, ltmGci=None, ytdGci=None, asOfDate=None, ttdGci=None, startDate=None, ):
        self.teamId = teamId
        self.ltmGci = ltmGci
        self.ytdGci = ytdGci
        self.asOfDate = asOfDate
        self.ttdGci = ttdGci
        self.startDate = startDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.ltmGci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.ytdGci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.asOfDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.ttdGci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.startDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteGciRecord')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.ltmGci is not None:
            oprot.writeFieldBegin('ltmGci', TType.DOUBLE, 2)
            oprot.writeDouble(self.ltmGci)
            oprot.writeFieldEnd()
        if self.ytdGci is not None:
            oprot.writeFieldBegin('ytdGci', TType.DOUBLE, 3)
            oprot.writeDouble(self.ytdGci)
            oprot.writeFieldEnd()
        if self.asOfDate is not None:
            oprot.writeFieldBegin('asOfDate', TType.STRING, 4)
            oprot.writeString(self.asOfDate.encode('utf-8') if sys.version_info[0] == 2 else self.asOfDate)
            oprot.writeFieldEnd()
        if self.ttdGci is not None:
            oprot.writeFieldBegin('ttdGci', TType.DOUBLE, 5)
            oprot.writeDouble(self.ttdGci)
            oprot.writeFieldEnd()
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.STRING, 6)
            oprot.writeString(self.startDate.encode('utf-8') if sys.version_info[0] == 2 else self.startDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteGetAggregatedGciRequest(object):
    """
    Attributes:
     - teams
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'teams', (TType.STRUCT, (gen.urbancompass.deals_platform.common.gci_model.ttypes.GciCriteria, gen.urbancompass.deals_platform.common.gci_model.ttypes.GciCriteria.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, teams=None, ):
        self.teams = teams

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.teams = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = gen.urbancompass.deals_platform.common.gci_model.ttypes.GciCriteria()
                        _elem9.read(iprot)
                        self.teams.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteGetAggregatedGciRequest')
        if self.teams is not None:
            oprot.writeFieldBegin('teams', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.teams))
            for _iter11 in self.teams:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteGetEntitiesRequest(object):
    """
    Attributes:
     - entityIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'entityIds', (TType.I32, None, False), None, ),  # 1
    )
    def __init__(self, entityIds=None, ):
        self.entityIds = entityIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.entityIds = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readI32()
                        self.entityIds.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteGetEntitiesRequest')
        if self.entityIds is not None:
            oprot.writeFieldBegin('entityIds', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.entityIds))
            for _iter16 in self.entityIds:
                oprot.writeI32(_iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteGetItemsRequest(object):
    """
    Attributes:
     - itemIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'itemIds', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, itemIds=None, ):
        self.itemIds = itemIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.itemIds = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.itemIds.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteGetItemsRequest')
        if self.itemIds is not None:
            oprot.writeFieldBegin('itemIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.itemIds))
            for _iter21 in self.itemIds:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteGetParticipantRequest(object):
    """
    Attributes:
     - amaIds
     - closeDate
     - submittedAt
     - subsidiary
     - excludeDmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'amaIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'closeDate', 'UTF8', None, ),  # 2
        (3, TType.I64, 'submittedAt', None, None, ),  # 3
        (4, TType.I32, 'subsidiary', None, None, ),  # 4
        (5, TType.STRING, 'excludeDmsTransactionId', 'UTF8', None, ),  # 5
    )
    def __init__(self, amaIds=None, closeDate=None, submittedAt=None, subsidiary=None, excludeDmsTransactionId=None, ):
        self.amaIds = amaIds
        self.closeDate = closeDate
        self.submittedAt = submittedAt
        self.subsidiary = subsidiary
        self.excludeDmsTransactionId = excludeDmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.amaIds = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.amaIds.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.submittedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.subsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.excludeDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteGetParticipantRequest')
        if self.amaIds is not None:
            oprot.writeFieldBegin('amaIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.amaIds))
            for _iter26 in self.amaIds:
                oprot.writeString(_iter26.encode('utf-8') if sys.version_info[0] == 2 else _iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 2)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.submittedAt is not None:
            oprot.writeFieldBegin('submittedAt', TType.I64, 3)
            oprot.writeI64(self.submittedAt)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.I32, 4)
            oprot.writeI32(self.subsidiary)
            oprot.writeFieldEnd()
        if self.excludeDmsTransactionId is not None:
            oprot.writeFieldBegin('excludeDmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.excludeDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.excludeDmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteGetTciRequest(object):
    """
    Attributes:
     - amaId
     - startDate
     - endDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'amaId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'startDate', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'endDate', 'UTF8', None, ),  # 3
    )
    def __init__(self, amaId=None, startDate=None, endDate=None, ):
        self.amaId = amaId
        self.startDate = startDate
        self.endDate = endDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.startDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.endDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteGetTciRequest')
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 1)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.STRING, 2)
            oprot.writeString(self.startDate.encode('utf-8') if sys.version_info[0] == 2 else self.startDate)
            oprot.writeFieldEnd()
        if self.endDate is not None:
            oprot.writeFieldBegin('endDate', TType.STRING, 3)
            oprot.writeString(self.endDate.encode('utf-8') if sys.version_info[0] == 2 else self.endDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteInvoicePayment(object):
    """
    Attributes:
     - id
     - documentNumber
     - type
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'documentNumber', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'type', 'UTF8', None, ),  # 3
        (4, TType.DOUBLE, 'amount', None, None, ),  # 4
    )
    def __init__(self, id=None, documentNumber=None, type=None, amount=None, ):
        self.id = id
        self.documentNumber = documentNumber
        self.type = type
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteInvoicePayment')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.documentNumber is not None:
            oprot.writeFieldBegin('documentNumber', TType.STRING, 2)
            oprot.writeString(self.documentNumber.encode('utf-8') if sys.version_info[0] == 2 else self.documentNumber)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 3)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 4)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteInvoicePaymentReponse(object):
    """
    Attributes:
     - submissionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'submissionId', None, None, ),  # 1
    )
    def __init__(self, submissionId=None, ):
        self.submissionId = submissionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.submissionId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteInvoicePaymentReponse')
        if self.submissionId is not None:
            oprot.writeFieldBegin('submissionId', TType.I32, 1)
            oprot.writeI32(self.submissionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteItem(object):
    """
    Attributes:
     - itemId
     - isGciImpacting
     - itemName
     - isInactive
     - lastModifiedTime
     - typeName
     - receivablePayableType
     - payableItemId
     - receivableItemId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'itemId', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'isGciImpacting', None, None, ),  # 2
        (3, TType.STRING, 'itemName', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'isInactive', None, None, ),  # 4
        (5, TType.I64, 'lastModifiedTime', None, None, ),  # 5
        (6, TType.STRING, 'typeName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'receivablePayableType', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'payableItemId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'receivableItemId', 'UTF8', None, ),  # 9
    )
    def __init__(self, itemId=None, isGciImpacting=None, itemName=None, isInactive=None, lastModifiedTime=None, typeName=None, receivablePayableType=None, payableItemId=None, receivableItemId=None, ):
        self.itemId = itemId
        self.isGciImpacting = isGciImpacting
        self.itemName = itemName
        self.isInactive = isInactive
        self.lastModifiedTime = lastModifiedTime
        self.typeName = typeName
        self.receivablePayableType = receivablePayableType
        self.payableItemId = payableItemId
        self.receivableItemId = receivableItemId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.itemId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isGciImpacting = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.itemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isInactive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.typeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.receivablePayableType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.payableItemId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.receivableItemId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteItem')
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.STRING, 1)
            oprot.writeString(self.itemId.encode('utf-8') if sys.version_info[0] == 2 else self.itemId)
            oprot.writeFieldEnd()
        if self.isGciImpacting is not None:
            oprot.writeFieldBegin('isGciImpacting', TType.BOOL, 2)
            oprot.writeBool(self.isGciImpacting)
            oprot.writeFieldEnd()
        if self.itemName is not None:
            oprot.writeFieldBegin('itemName', TType.STRING, 3)
            oprot.writeString(self.itemName.encode('utf-8') if sys.version_info[0] == 2 else self.itemName)
            oprot.writeFieldEnd()
        if self.isInactive is not None:
            oprot.writeFieldBegin('isInactive', TType.BOOL, 4)
            oprot.writeBool(self.isInactive)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 5)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.typeName is not None:
            oprot.writeFieldBegin('typeName', TType.STRING, 6)
            oprot.writeString(self.typeName.encode('utf-8') if sys.version_info[0] == 2 else self.typeName)
            oprot.writeFieldEnd()
        if self.receivablePayableType is not None:
            oprot.writeFieldBegin('receivablePayableType', TType.STRING, 7)
            oprot.writeString(self.receivablePayableType.encode('utf-8') if sys.version_info[0] == 2 else self.receivablePayableType)
            oprot.writeFieldEnd()
        if self.payableItemId is not None:
            oprot.writeFieldBegin('payableItemId', TType.STRING, 8)
            oprot.writeString(self.payableItemId.encode('utf-8') if sys.version_info[0] == 2 else self.payableItemId)
            oprot.writeFieldEnd()
        if self.receivableItemId is not None:
            oprot.writeFieldBegin('receivableItemId', TType.STRING, 9)
            oprot.writeString(self.receivableItemId.encode('utf-8') if sys.version_info[0] == 2 else self.receivableItemId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteLocation(object):
    """
    Attributes:
     - id
     - name
     - associatedSubsidiaries
     - isInactive
     - lastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'associatedSubsidiaries', (TType.I32, None, False), None, ),  # 3
        (4, TType.BOOL, 'isInactive', None, None, ),  # 4
        (5, TType.I64, 'lastModifiedTime', None, None, ),  # 5
    )
    def __init__(self, id=None, name=None, associatedSubsidiaries=None, isInactive=None, lastModifiedTime=None, ):
        self.id = id
        self.name = name
        self.associatedSubsidiaries = associatedSubsidiaries
        self.isInactive = isInactive
        self.lastModifiedTime = lastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.associatedSubsidiaries = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = iprot.readI32()
                        self.associatedSubsidiaries.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isInactive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteLocation')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.associatedSubsidiaries is not None:
            oprot.writeFieldBegin('associatedSubsidiaries', TType.LIST, 3)
            oprot.writeListBegin(TType.I32, len(self.associatedSubsidiaries))
            for _iter31 in self.associatedSubsidiaries:
                oprot.writeI32(_iter31)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isInactive is not None:
            oprot.writeFieldBegin('isInactive', TType.BOOL, 4)
            oprot.writeBool(self.isInactive)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 5)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteMarketingPayment(object):
    """
    Attributes:
     - type
     - paymentAmount
     - stripePaymentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.DOUBLE, 'paymentAmount', None, None, ),  # 2
        (3, TType.STRING, 'stripePaymentId', 'UTF8', None, ),  # 3
    )
    def __init__(self, type=None, paymentAmount=None, stripePaymentId=None, ):
        self.type = type
        self.paymentAmount = paymentAmount
        self.stripePaymentId = stripePaymentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.paymentAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.stripePaymentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteMarketingPayment')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.paymentAmount is not None:
            oprot.writeFieldBegin('paymentAmount', TType.DOUBLE, 2)
            oprot.writeDouble(self.paymentAmount)
            oprot.writeFieldEnd()
        if self.stripePaymentId is not None:
            oprot.writeFieldBegin('stripePaymentId', TType.STRING, 3)
            oprot.writeString(self.stripePaymentId.encode('utf-8') if sys.version_info[0] == 2 else self.stripePaymentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuitePaymentSummary(object):
    """
    Attributes:
     - dmsTransactionId
     - entityId
     - totalInvoiced
     - totalCredited
     - totalPaid
     - status
     - updateTimeStamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'entityId', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'totalInvoiced', None, None, ),  # 3
        (4, TType.DOUBLE, 'totalCredited', None, None, ),  # 4
        (5, TType.DOUBLE, 'totalPaid', None, None, ),  # 5
        (6, TType.STRING, 'status', 'UTF8', None, ),  # 6
        (7, TType.I64, 'updateTimeStamp', None, None, ),  # 7
    )
    def __init__(self, dmsTransactionId=None, entityId=None, totalInvoiced=None, totalCredited=None, totalPaid=None, status=None, updateTimeStamp=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.entityId = entityId
        self.totalInvoiced = totalInvoiced
        self.totalCredited = totalCredited
        self.totalPaid = totalPaid
        self.status = status
        self.updateTimeStamp = updateTimeStamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.entityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.totalInvoiced = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.totalCredited = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.totalPaid = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.status = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updateTimeStamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuitePaymentSummary')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.entityId is not None:
            oprot.writeFieldBegin('entityId', TType.STRING, 2)
            oprot.writeString(self.entityId.encode('utf-8') if sys.version_info[0] == 2 else self.entityId)
            oprot.writeFieldEnd()
        if self.totalInvoiced is not None:
            oprot.writeFieldBegin('totalInvoiced', TType.DOUBLE, 3)
            oprot.writeDouble(self.totalInvoiced)
            oprot.writeFieldEnd()
        if self.totalCredited is not None:
            oprot.writeFieldBegin('totalCredited', TType.DOUBLE, 4)
            oprot.writeDouble(self.totalCredited)
            oprot.writeFieldEnd()
        if self.totalPaid is not None:
            oprot.writeFieldBegin('totalPaid', TType.DOUBLE, 5)
            oprot.writeDouble(self.totalPaid)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRING, 6)
            oprot.writeString(self.status.encode('utf-8') if sys.version_info[0] == 2 else self.status)
            oprot.writeFieldEnd()
        if self.updateTimeStamp is not None:
            oprot.writeFieldBegin('updateTimeStamp', TType.I64, 7)
            oprot.writeI64(self.updateTimeStamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteSearchEntityRequest(object):
    """
    Attributes:
     - name
     - type
     - subsidiary
     - page
     - pageSize
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
        (3, TType.I32, 'subsidiary', None, None, ),  # 3
        (4, TType.I32, 'page', None, None, ),  # 4
        (5, TType.I32, 'pageSize', None, None, ),  # 5
    )
    def __init__(self, name=None, type=None, subsidiary=None, page=None, pageSize=None, ):
        self.name = name
        self.type = type
        self.subsidiary = subsidiary
        self.page = page
        self.pageSize = pageSize

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.subsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.page = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.pageSize = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteSearchEntityRequest')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.I32, 3)
            oprot.writeI32(self.subsidiary)
            oprot.writeFieldEnd()
        if self.page is not None:
            oprot.writeFieldBegin('page', TType.I32, 4)
            oprot.writeI32(self.page)
            oprot.writeFieldEnd()
        if self.pageSize is not None:
            oprot.writeFieldBegin('pageSize', TType.I32, 5)
            oprot.writeI32(self.pageSize)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteSubsidiary(object):
    """
    Attributes:
     - id
     - legalEntityDisplayName
     - taxId
     - legalAddressStreet
     - legalAddressCity
     - legalAddressState
     - legalAddressPostalCode
     - country
     - noticesEmail
     - stateCoverage
     - presignIcaEligible
     - active
     - lastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'legalEntityDisplayName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'taxId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'legalAddressStreet', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'legalAddressCity', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'legalAddressState', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'legalAddressPostalCode', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'country', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'noticesEmail', 'UTF8', None, ),  # 9
        (10, TType.LIST, 'stateCoverage', (TType.STRING, 'UTF8', False), None, ),  # 10
        (11, TType.BOOL, 'presignIcaEligible', None, None, ),  # 11
        (12, TType.BOOL, 'active', None, None, ),  # 12
        (13, TType.I64, 'lastModifiedTime', None, None, ),  # 13
    )
    def __init__(self, id=None, legalEntityDisplayName=None, taxId=None, legalAddressStreet=None, legalAddressCity=None, legalAddressState=None, legalAddressPostalCode=None, country=None, noticesEmail=None, stateCoverage=None, presignIcaEligible=None, active=None, lastModifiedTime=None, ):
        self.id = id
        self.legalEntityDisplayName = legalEntityDisplayName
        self.taxId = taxId
        self.legalAddressStreet = legalAddressStreet
        self.legalAddressCity = legalAddressCity
        self.legalAddressState = legalAddressState
        self.legalAddressPostalCode = legalAddressPostalCode
        self.country = country
        self.noticesEmail = noticesEmail
        self.stateCoverage = stateCoverage
        self.presignIcaEligible = presignIcaEligible
        self.active = active
        self.lastModifiedTime = lastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.legalEntityDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.taxId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.legalAddressStreet = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.legalAddressCity = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.legalAddressState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.legalAddressPostalCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.country = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.noticesEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.stateCoverage = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.stateCoverage.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.presignIcaEligible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.active = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteSubsidiary')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.legalEntityDisplayName is not None:
            oprot.writeFieldBegin('legalEntityDisplayName', TType.STRING, 2)
            oprot.writeString(self.legalEntityDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.legalEntityDisplayName)
            oprot.writeFieldEnd()
        if self.taxId is not None:
            oprot.writeFieldBegin('taxId', TType.STRING, 3)
            oprot.writeString(self.taxId.encode('utf-8') if sys.version_info[0] == 2 else self.taxId)
            oprot.writeFieldEnd()
        if self.legalAddressStreet is not None:
            oprot.writeFieldBegin('legalAddressStreet', TType.STRING, 4)
            oprot.writeString(self.legalAddressStreet.encode('utf-8') if sys.version_info[0] == 2 else self.legalAddressStreet)
            oprot.writeFieldEnd()
        if self.legalAddressCity is not None:
            oprot.writeFieldBegin('legalAddressCity', TType.STRING, 5)
            oprot.writeString(self.legalAddressCity.encode('utf-8') if sys.version_info[0] == 2 else self.legalAddressCity)
            oprot.writeFieldEnd()
        if self.legalAddressState is not None:
            oprot.writeFieldBegin('legalAddressState', TType.STRING, 6)
            oprot.writeString(self.legalAddressState.encode('utf-8') if sys.version_info[0] == 2 else self.legalAddressState)
            oprot.writeFieldEnd()
        if self.legalAddressPostalCode is not None:
            oprot.writeFieldBegin('legalAddressPostalCode', TType.STRING, 7)
            oprot.writeString(self.legalAddressPostalCode.encode('utf-8') if sys.version_info[0] == 2 else self.legalAddressPostalCode)
            oprot.writeFieldEnd()
        if self.country is not None:
            oprot.writeFieldBegin('country', TType.STRING, 8)
            oprot.writeString(self.country.encode('utf-8') if sys.version_info[0] == 2 else self.country)
            oprot.writeFieldEnd()
        if self.noticesEmail is not None:
            oprot.writeFieldBegin('noticesEmail', TType.STRING, 9)
            oprot.writeString(self.noticesEmail.encode('utf-8') if sys.version_info[0] == 2 else self.noticesEmail)
            oprot.writeFieldEnd()
        if self.stateCoverage is not None:
            oprot.writeFieldBegin('stateCoverage', TType.LIST, 10)
            oprot.writeListBegin(TType.STRING, len(self.stateCoverage))
            for _iter36 in self.stateCoverage:
                oprot.writeString(_iter36.encode('utf-8') if sys.version_info[0] == 2 else _iter36)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.presignIcaEligible is not None:
            oprot.writeFieldBegin('presignIcaEligible', TType.BOOL, 11)
            oprot.writeBool(self.presignIcaEligible)
            oprot.writeFieldEnd()
        if self.active is not None:
            oprot.writeFieldBegin('active', TType.BOOL, 12)
            oprot.writeBool(self.active)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 13)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteTaxDetails(object):
    """
    Attributes:
     - taxable
     - taxAmount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'taxable', None, None, ),  # 1
        (2, TType.DOUBLE, 'taxAmount', None, None, ),  # 2
    )
    def __init__(self, taxable=None, taxAmount=None, ):
        self.taxable = taxable
        self.taxAmount = taxAmount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.taxable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.taxAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteTaxDetails')
        if self.taxable is not None:
            oprot.writeFieldBegin('taxable', TType.BOOL, 1)
            oprot.writeBool(self.taxable)
            oprot.writeFieldEnd()
        if self.taxAmount is not None:
            oprot.writeFieldBegin('taxAmount', TType.DOUBLE, 2)
            oprot.writeDouble(self.taxAmount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteTransaction(object):
    """
    Attributes:
     - id
     - documentNumber
     - totalAmount
     - remainingAmount
     - applyingAmount
     - lastModifiedTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'documentNumber', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'totalAmount', None, None, ),  # 3
        (4, TType.DOUBLE, 'remainingAmount', None, None, ),  # 4
        (5, TType.DOUBLE, 'applyingAmount', None, None, ),  # 5
        (6, TType.I64, 'lastModifiedTime', None, None, ),  # 6
    )
    def __init__(self, id=None, documentNumber=None, totalAmount=None, remainingAmount=None, applyingAmount=None, lastModifiedTime=None, ):
        self.id = id
        self.documentNumber = documentNumber
        self.totalAmount = totalAmount
        self.remainingAmount = remainingAmount
        self.applyingAmount = applyingAmount
        self.lastModifiedTime = lastModifiedTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.totalAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.remainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.applyingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteTransaction')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.documentNumber is not None:
            oprot.writeFieldBegin('documentNumber', TType.STRING, 2)
            oprot.writeString(self.documentNumber.encode('utf-8') if sys.version_info[0] == 2 else self.documentNumber)
            oprot.writeFieldEnd()
        if self.totalAmount is not None:
            oprot.writeFieldBegin('totalAmount', TType.DOUBLE, 3)
            oprot.writeDouble(self.totalAmount)
            oprot.writeFieldEnd()
        if self.remainingAmount is not None:
            oprot.writeFieldBegin('remainingAmount', TType.DOUBLE, 4)
            oprot.writeDouble(self.remainingAmount)
            oprot.writeFieldEnd()
        if self.applyingAmount is not None:
            oprot.writeFieldBegin('applyingAmount', TType.DOUBLE, 5)
            oprot.writeDouble(self.applyingAmount)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 6)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteTransactionLine(object):
    """
    Attributes:
     - dmsTransactionId
     - transactionType
     - transactionTimestamp
     - entityId
     - subsidiaryId
     - locationId
     - departmentId
     - itemId
     - amount
     - listingTypeId
     - transactionId
     - transactionLineId
     - isReferral
     - itemUnitPrice
     - itemCount
     - memo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'transactionType', 'UTF8', None, ),  # 2
        (3, TType.I64, 'transactionTimestamp', None, None, ),  # 3
        (4, TType.STRING, 'entityId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'subsidiaryId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'locationId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'departmentId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'itemId', 'UTF8', None, ),  # 8
        (9, TType.DOUBLE, 'amount', None, None, ),  # 9
        (10, TType.STRING, 'listingTypeId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'transactionId', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'transactionLineId', 'UTF8', None, ),  # 12
        (13, TType.BOOL, 'isReferral', None, None, ),  # 13
        (14, TType.DOUBLE, 'itemUnitPrice', None, None, ),  # 14
        (15, TType.I32, 'itemCount', None, None, ),  # 15
        (16, TType.STRING, 'memo', 'UTF8', None, ),  # 16
    )
    def __init__(self, dmsTransactionId=None, transactionType=None, transactionTimestamp=None, entityId=None, subsidiaryId=None, locationId=None, departmentId=None, itemId=None, amount=None, listingTypeId=None, transactionId=None, transactionLineId=None, isReferral=None, itemUnitPrice=None, itemCount=None, memo=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.transactionType = transactionType
        self.transactionTimestamp = transactionTimestamp
        self.entityId = entityId
        self.subsidiaryId = subsidiaryId
        self.locationId = locationId
        self.departmentId = departmentId
        self.itemId = itemId
        self.amount = amount
        self.listingTypeId = listingTypeId
        self.transactionId = transactionId
        self.transactionLineId = transactionLineId
        self.isReferral = isReferral
        self.itemUnitPrice = itemUnitPrice
        self.itemCount = itemCount
        self.memo = memo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.transactionType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.transactionTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.entityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.subsidiaryId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.locationId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.departmentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.itemId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.listingTypeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.transactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.transactionLineId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isReferral = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.itemUnitPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.itemCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.memo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteTransactionLine')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.transactionType is not None:
            oprot.writeFieldBegin('transactionType', TType.STRING, 2)
            oprot.writeString(self.transactionType.encode('utf-8') if sys.version_info[0] == 2 else self.transactionType)
            oprot.writeFieldEnd()
        if self.transactionTimestamp is not None:
            oprot.writeFieldBegin('transactionTimestamp', TType.I64, 3)
            oprot.writeI64(self.transactionTimestamp)
            oprot.writeFieldEnd()
        if self.entityId is not None:
            oprot.writeFieldBegin('entityId', TType.STRING, 4)
            oprot.writeString(self.entityId.encode('utf-8') if sys.version_info[0] == 2 else self.entityId)
            oprot.writeFieldEnd()
        if self.subsidiaryId is not None:
            oprot.writeFieldBegin('subsidiaryId', TType.STRING, 5)
            oprot.writeString(self.subsidiaryId.encode('utf-8') if sys.version_info[0] == 2 else self.subsidiaryId)
            oprot.writeFieldEnd()
        if self.locationId is not None:
            oprot.writeFieldBegin('locationId', TType.STRING, 6)
            oprot.writeString(self.locationId.encode('utf-8') if sys.version_info[0] == 2 else self.locationId)
            oprot.writeFieldEnd()
        if self.departmentId is not None:
            oprot.writeFieldBegin('departmentId', TType.STRING, 7)
            oprot.writeString(self.departmentId.encode('utf-8') if sys.version_info[0] == 2 else self.departmentId)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.STRING, 8)
            oprot.writeString(self.itemId.encode('utf-8') if sys.version_info[0] == 2 else self.itemId)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 9)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.listingTypeId is not None:
            oprot.writeFieldBegin('listingTypeId', TType.STRING, 10)
            oprot.writeString(self.listingTypeId.encode('utf-8') if sys.version_info[0] == 2 else self.listingTypeId)
            oprot.writeFieldEnd()
        if self.transactionId is not None:
            oprot.writeFieldBegin('transactionId', TType.STRING, 11)
            oprot.writeString(self.transactionId.encode('utf-8') if sys.version_info[0] == 2 else self.transactionId)
            oprot.writeFieldEnd()
        if self.transactionLineId is not None:
            oprot.writeFieldBegin('transactionLineId', TType.STRING, 12)
            oprot.writeString(self.transactionLineId.encode('utf-8') if sys.version_info[0] == 2 else self.transactionLineId)
            oprot.writeFieldEnd()
        if self.isReferral is not None:
            oprot.writeFieldBegin('isReferral', TType.BOOL, 13)
            oprot.writeBool(self.isReferral)
            oprot.writeFieldEnd()
        if self.itemUnitPrice is not None:
            oprot.writeFieldBegin('itemUnitPrice', TType.DOUBLE, 14)
            oprot.writeDouble(self.itemUnitPrice)
            oprot.writeFieldEnd()
        if self.itemCount is not None:
            oprot.writeFieldBegin('itemCount', TType.I32, 15)
            oprot.writeI32(self.itemCount)
            oprot.writeFieldEnd()
        if self.memo is not None:
            oprot.writeFieldBegin('memo', TType.STRING, 16)
            oprot.writeString(self.memo.encode('utf-8') if sys.version_info[0] == 2 else self.memo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Payment(object):
    """
    Attributes:
     - invoiceId
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'invoiceId', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, invoiceId=None, amount=None, ):
        self.invoiceId = invoiceId
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.invoiceId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Payment')
        if self.invoiceId is not None:
            oprot.writeFieldBegin('invoiceId', TType.I32, 1)
            oprot.writeI32(self.invoiceId)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ApplyingTransaction(object):
    """
    Attributes:
     - amaId
     - transactions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'amaId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'transactions', (TType.STRUCT, (NetsuiteTransaction, NetsuiteTransaction.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, amaId=None, transactions=None, ):
        self.amaId = amaId
        self.transactions = transactions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.transactions = []
                    (_etype37, _size40) = iprot.readListBegin()
                    for _i38 in range(_size40):
                        _elem39 = NetsuiteTransaction()
                        _elem39.read(iprot)
                        self.transactions.append(_elem39)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ApplyingTransaction')
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 1)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.transactions is not None:
            oprot.writeFieldBegin('transactions', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.transactions))
            for _iter41 in self.transactions:
                _iter41.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetSuiteEntity(object):
    """
    Attributes:
     - netsuiteId
     - name
     - email
     - isInactive
     - roles
     - lastModifiedTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'netsuiteId', None, None, ),  # 1
        (2, TType.STRUCT, 'name', (NetSuiteEntityName, NetSuiteEntityName.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'isInactive', None, None, ),  # 4
        (5, TType.LIST, 'roles', (TType.STRUCT, (NetSuiteEntityRole, NetSuiteEntityRole.thrift_spec), False), None, ),  # 5
        (6, TType.I64, 'lastModifiedTimestamp', None, None, ),  # 6
    )
    def __init__(self, netsuiteId=None, name=None, email=None, isInactive=None, roles=None, lastModifiedTimestamp=None, ):
        self.netsuiteId = netsuiteId
        self.name = name
        self.email = email
        self.isInactive = isInactive
        self.roles = roles
        self.lastModifiedTimestamp = lastModifiedTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.netsuiteId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.name = NetSuiteEntityName()
                    self.name.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isInactive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype42, _size45) = iprot.readListBegin()
                    for _i43 in range(_size45):
                        _elem44 = NetSuiteEntityRole()
                        _elem44.read(iprot)
                        self.roles.append(_elem44)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModifiedTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetSuiteEntity')
        if self.netsuiteId is not None:
            oprot.writeFieldBegin('netsuiteId', TType.I32, 1)
            oprot.writeI32(self.netsuiteId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRUCT, 2)
            self.name.write(oprot)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.isInactive is not None:
            oprot.writeFieldBegin('isInactive', TType.BOOL, 4)
            oprot.writeBool(self.isInactive)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter46 in self.roles:
                _iter46.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastModifiedTimestamp is not None:
            oprot.writeFieldBegin('lastModifiedTimestamp', TType.I64, 6)
            oprot.writeI64(self.lastModifiedTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteDeal(object):
    """
    Attributes:
     - netsuiteDealId
     - agent
     - closeDate
     - gci
     - isTci
     - lastModifiedTime
     - closePrice
     - brokerFeePercent
     - brokerFeeAmount
     - isCompassLead
     - sideRepresentedId
     - address
     - city
     - state
     - zipcode
     - listingType
     - listingTypeId
     - submittedOn
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'netsuiteDealId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'agent', (NetsuiteAgent, NetsuiteAgent.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'closeDate', 'UTF8', None, ),  # 3
        (4, TType.DOUBLE, 'gci', None, None, ),  # 4
        (5, TType.BOOL, 'isTci', None, None, ),  # 5
        (6, TType.I64, 'lastModifiedTime', None, None, ),  # 6
        (7, TType.DOUBLE, 'closePrice', None, None, ),  # 7
        (8, TType.DOUBLE, 'brokerFeePercent', None, None, ),  # 8
        (9, TType.DOUBLE, 'brokerFeeAmount', None, None, ),  # 9
        (10, TType.BOOL, 'isCompassLead', None, None, ),  # 10
        (11, TType.I32, 'sideRepresentedId', None, None, ),  # 11
        (12, TType.STRING, 'address', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'city', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'state', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'zipcode', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'listingType', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'listingTypeId', 'UTF8', None, ),  # 17
        (18, TType.I64, 'submittedOn', None, None, ),  # 18
        (19, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 19
    )
    def __init__(self, netsuiteDealId=None, agent=None, closeDate=None, gci=None, isTci=None, lastModifiedTime=None, closePrice=None, brokerFeePercent=None, brokerFeeAmount=None, isCompassLead=None, sideRepresentedId=None, address=None, city=None, state=None, zipcode=None, listingType=None, listingTypeId=None, submittedOn=None, dmsTransactionId=None, ):
        self.netsuiteDealId = netsuiteDealId
        self.agent = agent
        self.closeDate = closeDate
        self.gci = gci
        self.isTci = isTci
        self.lastModifiedTime = lastModifiedTime
        self.closePrice = closePrice
        self.brokerFeePercent = brokerFeePercent
        self.brokerFeeAmount = brokerFeeAmount
        self.isCompassLead = isCompassLead
        self.sideRepresentedId = sideRepresentedId
        self.address = address
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listingType = listingType
        self.listingTypeId = listingTypeId
        self.submittedOn = submittedOn
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.netsuiteDealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.agent = NetsuiteAgent()
                    self.agent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.gci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isTci = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.DOUBLE:
                    self.brokerFeePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.brokerFeeAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.sideRepresentedId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.listingType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.listingTypeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I64:
                    self.submittedOn = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteDeal')
        if self.netsuiteDealId is not None:
            oprot.writeFieldBegin('netsuiteDealId', TType.STRING, 1)
            oprot.writeString(self.netsuiteDealId.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteDealId)
            oprot.writeFieldEnd()
        if self.agent is not None:
            oprot.writeFieldBegin('agent', TType.STRUCT, 2)
            self.agent.write(oprot)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 3)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.gci is not None:
            oprot.writeFieldBegin('gci', TType.DOUBLE, 4)
            oprot.writeDouble(self.gci)
            oprot.writeFieldEnd()
        if self.isTci is not None:
            oprot.writeFieldBegin('isTci', TType.BOOL, 5)
            oprot.writeBool(self.isTci)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 6)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 7)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.brokerFeePercent is not None:
            oprot.writeFieldBegin('brokerFeePercent', TType.DOUBLE, 8)
            oprot.writeDouble(self.brokerFeePercent)
            oprot.writeFieldEnd()
        if self.brokerFeeAmount is not None:
            oprot.writeFieldBegin('brokerFeeAmount', TType.DOUBLE, 9)
            oprot.writeDouble(self.brokerFeeAmount)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 10)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.sideRepresentedId is not None:
            oprot.writeFieldBegin('sideRepresentedId', TType.I32, 11)
            oprot.writeI32(self.sideRepresentedId)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 12)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 13)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 14)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 15)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.STRING, 16)
            oprot.writeString(self.listingType.encode('utf-8') if sys.version_info[0] == 2 else self.listingType)
            oprot.writeFieldEnd()
        if self.listingTypeId is not None:
            oprot.writeFieldBegin('listingTypeId', TType.STRING, 17)
            oprot.writeString(self.listingTypeId.encode('utf-8') if sys.version_info[0] == 2 else self.listingTypeId)
            oprot.writeFieldEnd()
        if self.submittedOn is not None:
            oprot.writeFieldBegin('submittedOn', TType.I64, 18)
            oprot.writeI64(self.submittedOn)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 19)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteDealAllocation(object):
    """
    Attributes:
     - netsuiteDealId
     - agent
     - commissionPercent
     - lastModifiedTime
     - dealAgentAllocationId
     - dmsTransactionId
     - agentGci
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'netsuiteDealId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'agent', (NetsuiteAgent, NetsuiteAgent.thrift_spec), None, ),  # 2
        (3, TType.DOUBLE, 'commissionPercent', None, None, ),  # 3
        (4, TType.I64, 'lastModifiedTime', None, None, ),  # 4
        (5, TType.STRING, 'dealAgentAllocationId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.DOUBLE, 'agentGci', None, None, ),  # 7
    )
    def __init__(self, netsuiteDealId=None, agent=None, commissionPercent=None, lastModifiedTime=None, dealAgentAllocationId=None, dmsTransactionId=None, agentGci=None, ):
        self.netsuiteDealId = netsuiteDealId
        self.agent = agent
        self.commissionPercent = commissionPercent
        self.lastModifiedTime = lastModifiedTime
        self.dealAgentAllocationId = dealAgentAllocationId
        self.dmsTransactionId = dmsTransactionId
        self.agentGci = agentGci

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.netsuiteDealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.agent = NetsuiteAgent()
                    self.agent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.commissionPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dealAgentAllocationId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.agentGci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteDealAllocation')
        if self.netsuiteDealId is not None:
            oprot.writeFieldBegin('netsuiteDealId', TType.STRING, 1)
            oprot.writeString(self.netsuiteDealId.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteDealId)
            oprot.writeFieldEnd()
        if self.agent is not None:
            oprot.writeFieldBegin('agent', TType.STRUCT, 2)
            self.agent.write(oprot)
            oprot.writeFieldEnd()
        if self.commissionPercent is not None:
            oprot.writeFieldBegin('commissionPercent', TType.DOUBLE, 3)
            oprot.writeDouble(self.commissionPercent)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 4)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.dealAgentAllocationId is not None:
            oprot.writeFieldBegin('dealAgentAllocationId', TType.STRING, 5)
            oprot.writeString(self.dealAgentAllocationId.encode('utf-8') if sys.version_info[0] == 2 else self.dealAgentAllocationId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.agentGci is not None:
            oprot.writeFieldBegin('agentGci', TType.DOUBLE, 7)
            oprot.writeDouble(self.agentGci)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteFeeType(object):
    """
    Attributes:
     - feeTypeItem
     - feeCalculationType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'feeTypeItem', (NetsuiteItem, NetsuiteItem.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'feeCalculationType', 'UTF8', None, ),  # 2
    )
    def __init__(self, feeTypeItem=None, feeCalculationType=None, ):
        self.feeTypeItem = feeTypeItem
        self.feeCalculationType = feeCalculationType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.feeTypeItem = NetsuiteItem()
                    self.feeTypeItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.feeCalculationType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteFeeType')
        if self.feeTypeItem is not None:
            oprot.writeFieldBegin('feeTypeItem', TType.STRUCT, 1)
            self.feeTypeItem.write(oprot)
            oprot.writeFieldEnd()
        if self.feeCalculationType is not None:
            oprot.writeFieldBegin('feeCalculationType', TType.STRING, 2)
            oprot.writeString(self.feeCalculationType.encode('utf-8') if sys.version_info[0] == 2 else self.feeCalculationType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteInvoiceItem(object):
    """
    Attributes:
     - transactionLine
     - item
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'transactionLine', (NetsuiteTransactionLine, NetsuiteTransactionLine.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'item', (NetsuiteItem, NetsuiteItem.thrift_spec), None, ),  # 2
    )
    def __init__(self, transactionLine=None, item=None, ):
        self.transactionLine = transactionLine
        self.item = item

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.transactionLine = NetsuiteTransactionLine()
                    self.transactionLine.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.item = NetsuiteItem()
                    self.item.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteInvoiceItem')
        if self.transactionLine is not None:
            oprot.writeFieldBegin('transactionLine', TType.STRUCT, 1)
            self.transactionLine.write(oprot)
            oprot.writeFieldEnd()
        if self.item is not None:
            oprot.writeFieldBegin('item', TType.STRUCT, 2)
            self.item.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteInvoicePaymentRequest(object):
    """
    Attributes:
     - payments
     - stripePaymentIntentId
     - amount
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'payments', (TType.STRUCT, (Payment, Payment.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'stripePaymentIntentId', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'amount', None, None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
    )
    def __init__(self, payments=None, stripePaymentIntentId=None, amount=None, status=None, ):
        self.payments = payments
        self.stripePaymentIntentId = stripePaymentIntentId
        self.amount = amount
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.payments = []
                    (_etype47, _size50) = iprot.readListBegin()
                    for _i48 in range(_size50):
                        _elem49 = Payment()
                        _elem49.read(iprot)
                        self.payments.append(_elem49)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.stripePaymentIntentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteInvoicePaymentRequest')
        if self.payments is not None:
            oprot.writeFieldBegin('payments', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.payments))
            for _iter51 in self.payments:
                _iter51.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stripePaymentIntentId is not None:
            oprot.writeFieldBegin('stripePaymentIntentId', TType.STRING, 2)
            oprot.writeString(self.stripePaymentIntentId.encode('utf-8') if sys.version_info[0] == 2 else self.stripePaymentIntentId)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 3)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteParticipant(object):
    """
    Attributes:
     - amaId
     - additionalTerms
     - transactions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'amaId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'additionalTerms', (TType.STRUCT, (NetsuiteAdditionalTerm, NetsuiteAdditionalTerm.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'transactions', (TType.STRUCT, (NetsuiteTransaction, NetsuiteTransaction.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, amaId=None, additionalTerms=None, transactions=None, ):
        self.amaId = amaId
        self.additionalTerms = additionalTerms
        self.transactions = transactions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.additionalTerms = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = NetsuiteAdditionalTerm()
                        _elem54.read(iprot)
                        self.additionalTerms.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.transactions = []
                    (_etype56, _size59) = iprot.readListBegin()
                    for _i57 in range(_size59):
                        _elem58 = NetsuiteTransaction()
                        _elem58.read(iprot)
                        self.transactions.append(_elem58)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteParticipant')
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 1)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.additionalTerms is not None:
            oprot.writeFieldBegin('additionalTerms', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.additionalTerms))
            for _iter60 in self.additionalTerms:
                _iter60.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.transactions is not None:
            oprot.writeFieldBegin('transactions', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.transactions))
            for _iter61 in self.transactions:
                _iter61.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteShippingDetails(object):
    """
    Attributes:
     - shippingAddress
     - method
     - shippingCost
     - taxAmount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'shippingAddress', (NetsuiteAddress, NetsuiteAddress.thrift_spec), None, ),  # 1
        (2, TType.I32, 'method', None, None, ),  # 2
        (3, TType.DOUBLE, 'shippingCost', None, None, ),  # 3
        (4, TType.DOUBLE, 'taxAmount', None, None, ),  # 4
    )
    def __init__(self, shippingAddress=None, method=None, shippingCost=None, taxAmount=None, ):
        self.shippingAddress = shippingAddress
        self.method = method
        self.shippingCost = shippingCost
        self.taxAmount = taxAmount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.shippingAddress = NetsuiteAddress()
                    self.shippingAddress.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.method = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.shippingCost = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.taxAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteShippingDetails')
        if self.shippingAddress is not None:
            oprot.writeFieldBegin('shippingAddress', TType.STRUCT, 1)
            self.shippingAddress.write(oprot)
            oprot.writeFieldEnd()
        if self.method is not None:
            oprot.writeFieldBegin('method', TType.I32, 2)
            oprot.writeI32(self.method)
            oprot.writeFieldEnd()
        if self.shippingCost is not None:
            oprot.writeFieldBegin('shippingCost', TType.DOUBLE, 3)
            oprot.writeDouble(self.shippingCost)
            oprot.writeFieldEnd()
        if self.taxAmount is not None:
            oprot.writeFieldBegin('taxAmount', TType.DOUBLE, 4)
            oprot.writeDouble(self.taxAmount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetsuiteInvoice(object):
    """
    Attributes:
     - id
     - transactionDate
     - entity
     - dueDate
     - subsidiary
     - documentNumber
     - status
     - dmsTransactionId
     - total
     - memo
     - remainingAmount
     - items
     - taxAmount
     - shippingAmount
     - payments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'transactionDate', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'entity', (NetSuiteEntity, NetSuiteEntity.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dueDate', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'subsidiary', (NetsuiteSubsidiary, NetsuiteSubsidiary.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'documentNumber', 'UTF8', None, ),  # 6
        (7, TType.I32, 'status', None, None, ),  # 7
        (8, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 8
        (9, TType.DOUBLE, 'total', None, None, ),  # 9
        (10, TType.STRING, 'memo', 'UTF8', None, ),  # 10
        (11, TType.DOUBLE, 'remainingAmount', None, None, ),  # 11
        (12, TType.LIST, 'items', (TType.STRUCT, (NetsuiteInvoiceItem, NetsuiteInvoiceItem.thrift_spec), False), None, ),  # 12
        (13, TType.DOUBLE, 'taxAmount', None, None, ),  # 13
        (14, TType.DOUBLE, 'shippingAmount', None, None, ),  # 14
        (15, TType.LIST, 'payments', (TType.STRUCT, (NetsuiteInvoicePayment, NetsuiteInvoicePayment.thrift_spec), False), None, ),  # 15
    )
    def __init__(self, id=None, transactionDate=None, entity=None, dueDate=None, subsidiary=None, documentNumber=None, status=None, dmsTransactionId=None, total=None, memo=None, remainingAmount=None, items=None, taxAmount=None, shippingAmount=None, payments=None, ):
        self.id = id
        self.transactionDate = transactionDate
        self.entity = entity
        self.dueDate = dueDate
        self.subsidiary = subsidiary
        self.documentNumber = documentNumber
        self.status = status
        self.dmsTransactionId = dmsTransactionId
        self.total = total
        self.memo = memo
        self.remainingAmount = remainingAmount
        self.items = items
        self.taxAmount = taxAmount
        self.shippingAmount = shippingAmount
        self.payments = payments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.transactionDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.entity = NetSuiteEntity()
                    self.entity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dueDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.subsidiary = NetsuiteSubsidiary()
                    self.subsidiary.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.documentNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.total = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.memo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.remainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.items = []
                    (_etype62, _size65) = iprot.readListBegin()
                    for _i63 in range(_size65):
                        _elem64 = NetsuiteInvoiceItem()
                        _elem64.read(iprot)
                        self.items.append(_elem64)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.DOUBLE:
                    self.taxAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.shippingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.payments = []
                    (_etype66, _size69) = iprot.readListBegin()
                    for _i67 in range(_size69):
                        _elem68 = NetsuiteInvoicePayment()
                        _elem68.read(iprot)
                        self.payments.append(_elem68)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetsuiteInvoice')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.transactionDate is not None:
            oprot.writeFieldBegin('transactionDate', TType.STRING, 2)
            oprot.writeString(self.transactionDate.encode('utf-8') if sys.version_info[0] == 2 else self.transactionDate)
            oprot.writeFieldEnd()
        if self.entity is not None:
            oprot.writeFieldBegin('entity', TType.STRUCT, 3)
            self.entity.write(oprot)
            oprot.writeFieldEnd()
        if self.dueDate is not None:
            oprot.writeFieldBegin('dueDate', TType.STRING, 4)
            oprot.writeString(self.dueDate.encode('utf-8') if sys.version_info[0] == 2 else self.dueDate)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.STRUCT, 5)
            self.subsidiary.write(oprot)
            oprot.writeFieldEnd()
        if self.documentNumber is not None:
            oprot.writeFieldBegin('documentNumber', TType.STRING, 6)
            oprot.writeString(self.documentNumber.encode('utf-8') if sys.version_info[0] == 2 else self.documentNumber)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 7)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 8)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.DOUBLE, 9)
            oprot.writeDouble(self.total)
            oprot.writeFieldEnd()
        if self.memo is not None:
            oprot.writeFieldBegin('memo', TType.STRING, 10)
            oprot.writeString(self.memo.encode('utf-8') if sys.version_info[0] == 2 else self.memo)
            oprot.writeFieldEnd()
        if self.remainingAmount is not None:
            oprot.writeFieldBegin('remainingAmount', TType.DOUBLE, 11)
            oprot.writeDouble(self.remainingAmount)
            oprot.writeFieldEnd()
        if self.items is not None:
            oprot.writeFieldBegin('items', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.items))
            for _iter70 in self.items:
                _iter70.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.taxAmount is not None:
            oprot.writeFieldBegin('taxAmount', TType.DOUBLE, 13)
            oprot.writeDouble(self.taxAmount)
            oprot.writeFieldEnd()
        if self.shippingAmount is not None:
            oprot.writeFieldBegin('shippingAmount', TType.DOUBLE, 14)
            oprot.writeDouble(self.shippingAmount)
            oprot.writeFieldEnd()
        if self.payments is not None:
            oprot.writeFieldBegin('payments', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.payments))
            for _iter71 in self.payments:
                _iter71.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
