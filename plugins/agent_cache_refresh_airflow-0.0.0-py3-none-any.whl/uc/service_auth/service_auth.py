# -*- coding: utf-8 -*-
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""
from enum import Enum
import logging

DN_QUALIFIER = "DNQ"
ORGANIZATION = "O"
COMPASS_DOMAIN = "compass.com"
ORGANIZATIONAL_UNIT = "OU"
COMMON_NAME = "CN"
SERIAL_NUMBER = "SERIALNUMBER"


class DistinguishedNameQualifier(Enum):
    UCv0 = "UCv0"
    UCv1 = "UCv1"


class DistinguishedNameMetadata(object):
    def __init__(self, common_name):
        self.distinguished_name_qualifier = DistinguishedNameQualifier.UCv0.value
        self.common_name = common_name
        self.organization_name = COMPASS_DOMAIN
        self.serial_number = "1"
        self.organizational_unit = ["Self"]

    def __str__(self):
        organizational_unit_str = ""
        for i in self.organizational_unit:
            organizational_unit_str += "/OU=" + i
        return (
            "DNQ="
            + self.distinguished_name_qualifier
            + "/O="
            + self.organization_name
            + organizational_unit_str
            + "/CN="
            + self.common_name
            + "/SERIALNUMBER="
            + self.serial_number
        )


# redeem_dn_metadata checks for the existence and validity of a DN metadata object held
# in the gRPC metadata. if validate then return its DistinguishedNameMetadata otherwise return None
# return: DistinguishedNameMetadata
def redeem_dn_metadata(raw_dn_metadata):
    try:
        dn_metadata = get_dn_metadata(raw_dn_metadata)
    except Exception as e:
        logging.debug("redeem_dn_metadata: Failed to get DN from gRPC metadata: {}".format(e))
    return dn_metadata


def get_dn_metadata(dn_metadata):
    if not dn_metadata:
        logging.debug("distinguished name metadata is empty")
        return None
    parsed = dn_metadata.split("/")
    new_dn_metadata = DistinguishedNameMetadata("None")
    organizational_unit_list = []
    for pairs in parsed:
        pair = pairs.split("=")
        if pair[0] == DN_QUALIFIER:
            if pair[1] != "UCv0" and pair[1] != "UCv1":
                logging.error("invalid distinguished name qualifier.")
                return None
            new_dn_metadata.distinguished_name_qualifier = pair[1]
        elif pair[0] == ORGANIZATION:
            if pair[1] != COMPASS_DOMAIN:
                logging.error("invalid organization on distinguished name metadata.")
                return None
        elif pair[0] == ORGANIZATIONAL_UNIT:
            organizational_unit_list.append(pair[1])
        elif pair[0] == COMMON_NAME:
            new_dn_metadata.common_name = pair[1]
        elif pair[0] == SERIAL_NUMBER:
            new_dn_metadata.serial_number = pair[1]
        else:
            logging.error("invalid distinguished name metadata.")
            return None
    new_dn_metadata.organizational_unit = organizational_unit_list
    return new_dn_metadata
