
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.value_formats.ttypes

from thrift.transport import TTransport


class DateAxisSettings(object):
    """
    Attributes:
     - displayFormat
     - isVisible
     - label
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'displayFormat', (gen.urbancompass.bi.dashboard.data.value_formats.ttypes.DateFormat, gen.urbancompass.bi.dashboard.data.value_formats.ttypes.DateFormat.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'isVisible', None, None, ),  # 2
        (3, TType.STRING, 'label', 'UTF8', None, ),  # 3
    )
    def __init__(self, displayFormat=None, isVisible=None, label=None, ):
        self.displayFormat = displayFormat
        self.isVisible = isVisible
        self.label = label

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.displayFormat = gen.urbancompass.bi.dashboard.data.value_formats.ttypes.DateFormat()
                    self.displayFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isVisible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DateAxisSettings')
        if self.displayFormat is not None:
            oprot.writeFieldBegin('displayFormat', TType.STRUCT, 1)
            self.displayFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.isVisible is not None:
            oprot.writeFieldBegin('isVisible', TType.BOOL, 2)
            oprot.writeBool(self.isVisible)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 3)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NumberAxisSettings(object):
    """
    Attributes:
     - displayFormat
     - isVisible
     - label
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'displayFormat', (gen.urbancompass.bi.dashboard.data.value_formats.ttypes.NumberFormat, gen.urbancompass.bi.dashboard.data.value_formats.ttypes.NumberFormat.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'isVisible', None, None, ),  # 2
        (3, TType.STRING, 'label', 'UTF8', None, ),  # 3
    )
    def __init__(self, displayFormat=None, isVisible=None, label=None, ):
        self.displayFormat = displayFormat
        self.isVisible = isVisible
        self.label = label

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.displayFormat = gen.urbancompass.bi.dashboard.data.value_formats.ttypes.NumberFormat()
                    self.displayFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isVisible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NumberAxisSettings')
        if self.displayFormat is not None:
            oprot.writeFieldBegin('displayFormat', TType.STRUCT, 1)
            self.displayFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.isVisible is not None:
            oprot.writeFieldBegin('isVisible', TType.BOOL, 2)
            oprot.writeBool(self.isVisible)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 3)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StringAxisSettings(object):
    """
    Attributes:
     - displayFormat
     - isVisible
     - label
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'displayFormat', (gen.urbancompass.bi.dashboard.data.value_formats.ttypes.StringFormat, gen.urbancompass.bi.dashboard.data.value_formats.ttypes.StringFormat.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'isVisible', None, None, ),  # 2
        (3, TType.STRING, 'label', 'UTF8', None, ),  # 3
    )
    def __init__(self, displayFormat=None, isVisible=None, label=None, ):
        self.displayFormat = displayFormat
        self.isVisible = isVisible
        self.label = label

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.displayFormat = gen.urbancompass.bi.dashboard.data.value_formats.ttypes.StringFormat()
                    self.displayFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isVisible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StringAxisSettings')
        if self.displayFormat is not None:
            oprot.writeFieldBegin('displayFormat', TType.STRUCT, 1)
            self.displayFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.isVisible is not None:
            oprot.writeFieldBegin('isVisible', TType.BOOL, 2)
            oprot.writeBool(self.isVisible)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 3)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AxisSettings(object):
    """
    Attributes:
     - dateAxisSettings
     - numberAxisSettings
     - stringAxisSettings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dateAxisSettings', (DateAxisSettings, DateAxisSettings.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'numberAxisSettings', (NumberAxisSettings, NumberAxisSettings.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'stringAxisSettings', (StringAxisSettings, StringAxisSettings.thrift_spec), None, ),  # 3
    )
    def __init__(self, dateAxisSettings=None, numberAxisSettings=None, stringAxisSettings=None, ):
        self.dateAxisSettings = dateAxisSettings
        self.numberAxisSettings = numberAxisSettings
        self.stringAxisSettings = stringAxisSettings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dateAxisSettings = DateAxisSettings()
                    self.dateAxisSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.numberAxisSettings = NumberAxisSettings()
                    self.numberAxisSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.stringAxisSettings = StringAxisSettings()
                    self.stringAxisSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AxisSettings')
        if self.dateAxisSettings is not None:
            oprot.writeFieldBegin('dateAxisSettings', TType.STRUCT, 1)
            self.dateAxisSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.numberAxisSettings is not None:
            oprot.writeFieldBegin('numberAxisSettings', TType.STRUCT, 2)
            self.numberAxisSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.stringAxisSettings is not None:
            oprot.writeFieldBegin('stringAxisSettings', TType.STRUCT, 3)
            self.stringAxisSettings.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
