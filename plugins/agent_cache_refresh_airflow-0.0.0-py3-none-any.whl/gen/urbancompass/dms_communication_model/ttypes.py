
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.dms_common.dms_communication.ttypes
import gen.urbancompass.dms_document.ttypes
import gen.urbancompass.dms_common.dms_folder.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.dms_state_model.ttypes

from thrift.transport import TTransport


class ClientType(object):
    DOCUMENT_SERVICE = 0
    STATE_SERVICE = 1
    TRANSLATION_SERVICE = 2
    NOTIFICATION_SERVICE = 3

    _VALUES_TO_NAMES = {
        0: "DOCUMENT_SERVICE",
        1: "STATE_SERVICE",
        2: "TRANSLATION_SERVICE",
        3: "NOTIFICATION_SERVICE",
    }

    _NAMES_TO_VALUES = {
        "DOCUMENT_SERVICE": 0,
        "STATE_SERVICE": 1,
        "TRANSLATION_SERVICE": 2,
        "NOTIFICATION_SERVICE": 3,
    }


class DeliverableState(object):
    SENT = 0
    FAILED = 1

    _VALUES_TO_NAMES = {
        0: "SENT",
        1: "FAILED",
    }

    _NAMES_TO_VALUES = {
        "SENT": 0,
        "FAILED": 1,
    }


class EnrichFolderFields(object):
    STAFF_GROUP = 0

    _VALUES_TO_NAMES = {
        0: "STAFF_GROUP",
    }

    _NAMES_TO_VALUES = {
        "STAFF_GROUP": 0,
    }


class EventState(object):
    SCHEDULED = 0
    STORED = 1
    SENT_NOW = 2

    _VALUES_TO_NAMES = {
        0: "SCHEDULED",
        1: "STORED",
        2: "SENT_NOW",
    }

    _NAMES_TO_VALUES = {
        "SCHEDULED": 0,
        "STORED": 1,
        "SENT_NOW": 2,
    }


class EventType(object):
    COMPLIANCE_STATUS_CHANGE = 0
    COMMISSION_STATUS_CHANGE = 1
    EMAIL_FROM_TC = 2
    REMINDER = 3
    PERMISSION_CHANGE = 4
    MANUAL_ENTRY = 5
    EMAIL_NOTIFICATION = 6

    _VALUES_TO_NAMES = {
        0: "COMPLIANCE_STATUS_CHANGE",
        1: "COMMISSION_STATUS_CHANGE",
        2: "EMAIL_FROM_TC",
        3: "REMINDER",
        4: "PERMISSION_CHANGE",
        5: "MANUAL_ENTRY",
        6: "EMAIL_NOTIFICATION",
    }

    _NAMES_TO_VALUES = {
        "COMPLIANCE_STATUS_CHANGE": 0,
        "COMMISSION_STATUS_CHANGE": 1,
        "EMAIL_FROM_TC": 2,
        "REMINDER": 3,
        "PERMISSION_CHANGE": 4,
        "MANUAL_ENTRY": 5,
        "EMAIL_NOTIFICATION": 6,
    }


class CommunicationEventPayload(object):
    """
    Attributes:
     - id
     - dmsFolderId
     - resourceType
     - resourceId
     - payload
     - md5
     - createdAt
     - stage
     - operatorId
     - impersonatorId
     - recipientId
     - dmsListingId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'resourceType', None, None, ),  # 3
        (4, TType.STRING, 'resourceId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'payload', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'md5', 'UTF8', None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I32, 'stage', None, None, ),  # 8
        (9, TType.STRING, 'operatorId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'recipientId', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 13
    )
    def __init__(self, id=None, dmsFolderId=None, resourceType=None, resourceId=None, payload=None, md5=None, createdAt=None, stage=None, operatorId=None, impersonatorId=None, recipientId=None, dmsListingId=None, dmsTransactionId=None, ):
        self.id = id
        self.dmsFolderId = dmsFolderId
        self.resourceType = resourceType
        self.resourceId = resourceId
        self.payload = payload
        self.md5 = md5
        self.createdAt = createdAt
        self.stage = stage
        self.operatorId = operatorId
        self.impersonatorId = impersonatorId
        self.recipientId = recipientId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.resourceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.resourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.payload = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.md5 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.operatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommunicationEventPayload')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.resourceType is not None:
            oprot.writeFieldBegin('resourceType', TType.I32, 3)
            oprot.writeI32(self.resourceType)
            oprot.writeFieldEnd()
        if self.resourceId is not None:
            oprot.writeFieldBegin('resourceId', TType.STRING, 4)
            oprot.writeString(self.resourceId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceId)
            oprot.writeFieldEnd()
        if self.payload is not None:
            oprot.writeFieldBegin('payload', TType.STRING, 5)
            oprot.writeString(self.payload.encode('utf-8') if sys.version_info[0] == 2 else self.payload)
            oprot.writeFieldEnd()
        if self.md5 is not None:
            oprot.writeFieldBegin('md5', TType.STRING, 6)
            oprot.writeString(self.md5.encode('utf-8') if sys.version_info[0] == 2 else self.md5)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 8)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.operatorId is not None:
            oprot.writeFieldBegin('operatorId', TType.STRING, 9)
            oprot.writeString(self.operatorId.encode('utf-8') if sys.version_info[0] == 2 else self.operatorId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 10)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 11)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 12)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 13)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsAgentCommunicationInfo(object):
    """
    Attributes:
     - removedDmsAgentIdList
     - addedDmsAgentIdList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'removedDmsAgentIdList', (TType.I64, None, False), None, ),  # 1
        (2, TType.LIST, 'addedDmsAgentIdList', (TType.I64, None, False), None, ),  # 2
    )
    def __init__(self, removedDmsAgentIdList=None, addedDmsAgentIdList=None, ):
        self.removedDmsAgentIdList = removedDmsAgentIdList
        self.addedDmsAgentIdList = addedDmsAgentIdList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.removedDmsAgentIdList = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readI64()
                        self.removedDmsAgentIdList.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.addedDmsAgentIdList = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readI64()
                        self.addedDmsAgentIdList.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsAgentCommunicationInfo')
        if self.removedDmsAgentIdList is not None:
            oprot.writeFieldBegin('removedDmsAgentIdList', TType.LIST, 1)
            oprot.writeListBegin(TType.I64, len(self.removedDmsAgentIdList))
            for _iter10 in self.removedDmsAgentIdList:
                oprot.writeI64(_iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.addedDmsAgentIdList is not None:
            oprot.writeFieldBegin('addedDmsAgentIdList', TType.LIST, 2)
            oprot.writeListBegin(TType.I64, len(self.addedDmsAgentIdList))
            for _iter11 in self.addedDmsAgentIdList:
                oprot.writeI64(_iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsClientCommunicationInfo(object):
    """
    Attributes:
     - removedDmsClientIdList
     - addedDmsClientIdList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'removedDmsClientIdList', (TType.I64, None, False), None, ),  # 1
        (2, TType.LIST, 'addedDmsClientIdList', (TType.I64, None, False), None, ),  # 2
    )
    def __init__(self, removedDmsClientIdList=None, addedDmsClientIdList=None, ):
        self.removedDmsClientIdList = removedDmsClientIdList
        self.addedDmsClientIdList = addedDmsClientIdList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.removedDmsClientIdList = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readI64()
                        self.removedDmsClientIdList.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.addedDmsClientIdList = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = iprot.readI64()
                        self.addedDmsClientIdList.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsClientCommunicationInfo')
        if self.removedDmsClientIdList is not None:
            oprot.writeFieldBegin('removedDmsClientIdList', TType.LIST, 1)
            oprot.writeListBegin(TType.I64, len(self.removedDmsClientIdList))
            for _iter20 in self.removedDmsClientIdList:
                oprot.writeI64(_iter20)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.addedDmsClientIdList is not None:
            oprot.writeFieldBegin('addedDmsClientIdList', TType.LIST, 2)
            oprot.writeListBegin(TType.I64, len(self.addedDmsClientIdList))
            for _iter21 in self.addedDmsClientIdList:
                oprot.writeI64(_iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsCommunicationDeliverable(object):
    """
    Attributes:
     - id
     - recipientId
     - recipientEmail
     - eventIds
     - state
     - deliveredData
     - deliveryErrMsg
     - createdAt
     - updatedAt
     - md5
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'recipientId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'recipientEmail', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'eventIds', (TType.I64, None, False), None, ),  # 4
        (5, TType.I32, 'state', None, None, ),  # 5
        (6, TType.STRING, 'deliveredData', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'deliveryErrMsg', 'UTF8', None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.STRING, 'md5', 'UTF8', None, ),  # 10
    )
    def __init__(self, id=None, recipientId=None, recipientEmail=None, eventIds=None, state=None, deliveredData=None, deliveryErrMsg=None, createdAt=None, updatedAt=None, md5=None, ):
        self.id = id
        self.recipientId = recipientId
        self.recipientEmail = recipientEmail
        self.eventIds = eventIds
        self.state = state
        self.deliveredData = deliveredData
        self.deliveryErrMsg = deliveryErrMsg
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.md5 = md5

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.recipientEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.eventIds = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readI64()
                        self.eventIds.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.state = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.deliveredData = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.deliveryErrMsg = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.md5 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsCommunicationDeliverable')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 2)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.recipientEmail is not None:
            oprot.writeFieldBegin('recipientEmail', TType.STRING, 3)
            oprot.writeString(self.recipientEmail.encode('utf-8') if sys.version_info[0] == 2 else self.recipientEmail)
            oprot.writeFieldEnd()
        if self.eventIds is not None:
            oprot.writeFieldBegin('eventIds', TType.LIST, 4)
            oprot.writeListBegin(TType.I64, len(self.eventIds))
            for _iter26 in self.eventIds:
                oprot.writeI64(_iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.I32, 5)
            oprot.writeI32(self.state)
            oprot.writeFieldEnd()
        if self.deliveredData is not None:
            oprot.writeFieldBegin('deliveredData', TType.STRING, 6)
            oprot.writeString(self.deliveredData.encode('utf-8') if sys.version_info[0] == 2 else self.deliveredData)
            oprot.writeFieldEnd()
        if self.deliveryErrMsg is not None:
            oprot.writeFieldBegin('deliveryErrMsg', TType.STRING, 7)
            oprot.writeString(self.deliveryErrMsg.encode('utf-8') if sys.version_info[0] == 2 else self.deliveryErrMsg)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.md5 is not None:
            oprot.writeFieldBegin('md5', TType.STRING, 10)
            oprot.writeString(self.md5.encode('utf-8') if sys.version_info[0] == 2 else self.md5)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsCommunicationEvent(object):
    """
    Attributes:
     - id
     - recipientId
     - eventType
     - eventState
     - stateCode
     - payloadId
     - createdAt
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'recipientId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'eventType', None, None, ),  # 3
        (4, TType.I32, 'eventState', None, None, ),  # 4
        (5, TType.I32, 'stateCode', None, None, ),  # 5
        (6, TType.I64, 'payloadId', None, None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'updatedAt', None, None, ),  # 8
    )
    def __init__(self, id=None, recipientId=None, eventType=None, eventState=None, stateCode=None, payloadId=None, createdAt=None, updatedAt=None, ):
        self.id = id
        self.recipientId = recipientId
        self.eventType = eventType
        self.eventState = eventState
        self.stateCode = stateCode
        self.payloadId = payloadId
        self.createdAt = createdAt
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.eventType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.eventState = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.stateCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.payloadId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsCommunicationEvent')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 2)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.eventType is not None:
            oprot.writeFieldBegin('eventType', TType.I32, 3)
            oprot.writeI32(self.eventType)
            oprot.writeFieldEnd()
        if self.eventState is not None:
            oprot.writeFieldBegin('eventState', TType.I32, 4)
            oprot.writeI32(self.eventState)
            oprot.writeFieldEnd()
        if self.stateCode is not None:
            oprot.writeFieldBegin('stateCode', TType.I32, 5)
            oprot.writeI32(self.stateCode)
            oprot.writeFieldEnd()
        if self.payloadId is not None:
            oprot.writeFieldBegin('payloadId', TType.I64, 6)
            oprot.writeI64(self.payloadId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 8)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDailyReminderEvent(object):
    """
    Attributes:
     - recipientIds
     - dmsFolderId
     - dmsFolderName
     - resourceType
     - resourceId
     - resourceName
     - dueTime
     - stateCode
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'recipientIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderName', 'UTF8', None, ),  # 3
        (4, TType.I32, 'resourceType', None, None, ),  # 4
        (5, TType.STRING, 'resourceId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'resourceName', 'UTF8', None, ),  # 6
        (7, TType.I32, 'dueTime', None, None, ),  # 7
        (8, TType.I32, 'stateCode', None, None, ),  # 8
    )
    def __init__(self, recipientIds=None, dmsFolderId=None, dmsFolderName=None, resourceType=None, resourceId=None, resourceName=None, dueTime=None, stateCode=None, ):
        self.recipientIds = recipientIds
        self.dmsFolderId = dmsFolderId
        self.dmsFolderName = dmsFolderName
        self.resourceType = resourceType
        self.resourceId = resourceId
        self.resourceName = resourceName
        self.dueTime = dueTime
        self.stateCode = stateCode

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.recipientIds = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.recipientIds.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.resourceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.resourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.resourceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.dueTime = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.stateCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDailyReminderEvent')
        if self.recipientIds is not None:
            oprot.writeFieldBegin('recipientIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.recipientIds))
            for _iter31 in self.recipientIds:
                oprot.writeString(_iter31.encode('utf-8') if sys.version_info[0] == 2 else _iter31)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsFolderName is not None:
            oprot.writeFieldBegin('dmsFolderName', TType.STRING, 3)
            oprot.writeString(self.dmsFolderName.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderName)
            oprot.writeFieldEnd()
        if self.resourceType is not None:
            oprot.writeFieldBegin('resourceType', TType.I32, 4)
            oprot.writeI32(self.resourceType)
            oprot.writeFieldEnd()
        if self.resourceId is not None:
            oprot.writeFieldBegin('resourceId', TType.STRING, 5)
            oprot.writeString(self.resourceId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceId)
            oprot.writeFieldEnd()
        if self.resourceName is not None:
            oprot.writeFieldBegin('resourceName', TType.STRING, 6)
            oprot.writeString(self.resourceName.encode('utf-8') if sys.version_info[0] == 2 else self.resourceName)
            oprot.writeFieldEnd()
        if self.dueTime is not None:
            oprot.writeFieldBegin('dueTime', TType.I32, 7)
            oprot.writeI32(self.dueTime)
            oprot.writeFieldEnd()
        if self.stateCode is not None:
            oprot.writeFieldBegin('stateCode', TType.I32, 8)
            oprot.writeI32(self.stateCode)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PayloadInfo(object):
    """
    Attributes:
     - dmsFolderName
     - resourceName
     - resourceStatus
     - operatorId
     - operatorDisplayName
     - operatedAt
     - note
     - daysToDueDate
     - operatorFirstName
     - operatorLastName
     - shortLog
     - changes
     - recipientId
     - recipientDisplayName
     - recipientFirstName
     - recipientLastName
     - checklistItemNameToPages
     - listDate
     - dmsTransaction
     - impersonatorId
     - impersonatorDisplayName
     - impersonatorFirstName
     - impersonatorLastName
     - dmsListing
     - checklistItemName
     - notificationType
     - dmsAgentCommunicationInfo
     - dmsClientCommunicationInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'resourceName', 'UTF8', None, ),  # 2
        (3, TType.I32, 'resourceStatus', None, None, ),  # 3
        (4, TType.STRING, 'operatorId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'operatorDisplayName', 'UTF8', None, ),  # 5
        (6, TType.I64, 'operatedAt', None, None, ),  # 6
        (7, TType.STRING, 'note', 'UTF8', None, ),  # 7
        (8, TType.I32, 'daysToDueDate', None, None, ),  # 8
        (9, TType.STRING, 'operatorFirstName', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'operatorLastName', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'shortLog', 'UTF8', None, ),  # 11
        (12, TType.LIST, 'changes', (TType.STRUCT, (gen.urbancompass.dms_common.dms_communication.ttypes.DiffElement, gen.urbancompass.dms_common.dms_communication.ttypes.DiffElement.thrift_spec), False), None, ),  # 12
        (13, TType.STRING, 'recipientId', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'recipientDisplayName', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'recipientFirstName', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'recipientLastName', 'UTF8', None, ),  # 16
        (17, TType.MAP, 'checklistItemNameToPages', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.dms_document.ttypes.PageInterval, gen.urbancompass.dms_document.ttypes.PageInterval.thrift_spec), False), None, ),  # 17
        (18, TType.I64, 'listDate', None, None, ),  # 18
        (19, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 19
        (20, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'impersonatorDisplayName', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'impersonatorFirstName', 'UTF8', None, ),  # 22
        (23, TType.STRING, 'impersonatorLastName', 'UTF8', None, ),  # 23
        (24, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 24
        (25, TType.STRING, 'checklistItemName', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'notificationType', 'UTF8', None, ),  # 26
        (27, TType.STRUCT, 'dmsAgentCommunicationInfo', (DmsAgentCommunicationInfo, DmsAgentCommunicationInfo.thrift_spec), None, ),  # 27
        (28, TType.STRUCT, 'dmsClientCommunicationInfo', (DmsClientCommunicationInfo, DmsClientCommunicationInfo.thrift_spec), None, ),  # 28
    )
    def __init__(self, dmsFolderName=None, resourceName=None, resourceStatus=None, operatorId=None, operatorDisplayName=None, operatedAt=None, note=None, daysToDueDate=None, operatorFirstName=None, operatorLastName=None, shortLog=None, changes=None, recipientId=None, recipientDisplayName=None, recipientFirstName=None, recipientLastName=None, checklistItemNameToPages=None, listDate=None, dmsTransaction=None, impersonatorId=None, impersonatorDisplayName=None, impersonatorFirstName=None, impersonatorLastName=None, dmsListing=None, checklistItemName=None, notificationType=None, dmsAgentCommunicationInfo=None, dmsClientCommunicationInfo=None, ):
        self.dmsFolderName = dmsFolderName
        self.resourceName = resourceName
        self.resourceStatus = resourceStatus
        self.operatorId = operatorId
        self.operatorDisplayName = operatorDisplayName
        self.operatedAt = operatedAt
        self.note = note
        self.daysToDueDate = daysToDueDate
        self.operatorFirstName = operatorFirstName
        self.operatorLastName = operatorLastName
        self.shortLog = shortLog
        self.changes = changes
        self.recipientId = recipientId
        self.recipientDisplayName = recipientDisplayName
        self.recipientFirstName = recipientFirstName
        self.recipientLastName = recipientLastName
        self.checklistItemNameToPages = checklistItemNameToPages
        self.listDate = listDate
        self.dmsTransaction = dmsTransaction
        self.impersonatorId = impersonatorId
        self.impersonatorDisplayName = impersonatorDisplayName
        self.impersonatorFirstName = impersonatorFirstName
        self.impersonatorLastName = impersonatorLastName
        self.dmsListing = dmsListing
        self.checklistItemName = checklistItemName
        self.notificationType = notificationType
        self.dmsAgentCommunicationInfo = dmsAgentCommunicationInfo
        self.dmsClientCommunicationInfo = dmsClientCommunicationInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.resourceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.resourceStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.operatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.operatorDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.operatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.daysToDueDate = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.operatorFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.operatorLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.shortLog = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.changes = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = gen.urbancompass.dms_common.dms_communication.ttypes.DiffElement()
                        _elem34.read(iprot)
                        self.changes.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.recipientDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.recipientFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.recipientLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.MAP:
                    self.checklistItemNameToPages = {}
                    (_ktype37, _vtype38, _size41) = iprot.readMapBegin()
                    for _i36 in range(_size41):
                        _key39 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val40 = gen.urbancompass.dms_document.ttypes.PageInterval()
                        _val40.read(iprot)
                        self.checklistItemNameToPages[_key39] = _val40
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.impersonatorDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.impersonatorFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.impersonatorLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.checklistItemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.notificationType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRUCT:
                    self.dmsAgentCommunicationInfo = DmsAgentCommunicationInfo()
                    self.dmsAgentCommunicationInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRUCT:
                    self.dmsClientCommunicationInfo = DmsClientCommunicationInfo()
                    self.dmsClientCommunicationInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PayloadInfo')
        if self.dmsFolderName is not None:
            oprot.writeFieldBegin('dmsFolderName', TType.STRING, 1)
            oprot.writeString(self.dmsFolderName.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderName)
            oprot.writeFieldEnd()
        if self.resourceName is not None:
            oprot.writeFieldBegin('resourceName', TType.STRING, 2)
            oprot.writeString(self.resourceName.encode('utf-8') if sys.version_info[0] == 2 else self.resourceName)
            oprot.writeFieldEnd()
        if self.resourceStatus is not None:
            oprot.writeFieldBegin('resourceStatus', TType.I32, 3)
            oprot.writeI32(self.resourceStatus)
            oprot.writeFieldEnd()
        if self.operatorId is not None:
            oprot.writeFieldBegin('operatorId', TType.STRING, 4)
            oprot.writeString(self.operatorId.encode('utf-8') if sys.version_info[0] == 2 else self.operatorId)
            oprot.writeFieldEnd()
        if self.operatorDisplayName is not None:
            oprot.writeFieldBegin('operatorDisplayName', TType.STRING, 5)
            oprot.writeString(self.operatorDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.operatorDisplayName)
            oprot.writeFieldEnd()
        if self.operatedAt is not None:
            oprot.writeFieldBegin('operatedAt', TType.I64, 6)
            oprot.writeI64(self.operatedAt)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 7)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.daysToDueDate is not None:
            oprot.writeFieldBegin('daysToDueDate', TType.I32, 8)
            oprot.writeI32(self.daysToDueDate)
            oprot.writeFieldEnd()
        if self.operatorFirstName is not None:
            oprot.writeFieldBegin('operatorFirstName', TType.STRING, 9)
            oprot.writeString(self.operatorFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.operatorFirstName)
            oprot.writeFieldEnd()
        if self.operatorLastName is not None:
            oprot.writeFieldBegin('operatorLastName', TType.STRING, 10)
            oprot.writeString(self.operatorLastName.encode('utf-8') if sys.version_info[0] == 2 else self.operatorLastName)
            oprot.writeFieldEnd()
        if self.shortLog is not None:
            oprot.writeFieldBegin('shortLog', TType.STRING, 11)
            oprot.writeString(self.shortLog.encode('utf-8') if sys.version_info[0] == 2 else self.shortLog)
            oprot.writeFieldEnd()
        if self.changes is not None:
            oprot.writeFieldBegin('changes', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.changes))
            for _iter42 in self.changes:
                _iter42.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 13)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.recipientDisplayName is not None:
            oprot.writeFieldBegin('recipientDisplayName', TType.STRING, 14)
            oprot.writeString(self.recipientDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.recipientDisplayName)
            oprot.writeFieldEnd()
        if self.recipientFirstName is not None:
            oprot.writeFieldBegin('recipientFirstName', TType.STRING, 15)
            oprot.writeString(self.recipientFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.recipientFirstName)
            oprot.writeFieldEnd()
        if self.recipientLastName is not None:
            oprot.writeFieldBegin('recipientLastName', TType.STRING, 16)
            oprot.writeString(self.recipientLastName.encode('utf-8') if sys.version_info[0] == 2 else self.recipientLastName)
            oprot.writeFieldEnd()
        if self.checklistItemNameToPages is not None:
            oprot.writeFieldBegin('checklistItemNameToPages', TType.MAP, 17)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.checklistItemNameToPages))
            for _kiter43, _viter44 in self.checklistItemNameToPages.items():
                oprot.writeString(_kiter43.encode('utf-8') if sys.version_info[0] == 2 else _kiter43)
                _viter44.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 18)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 19)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 20)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.impersonatorDisplayName is not None:
            oprot.writeFieldBegin('impersonatorDisplayName', TType.STRING, 21)
            oprot.writeString(self.impersonatorDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorDisplayName)
            oprot.writeFieldEnd()
        if self.impersonatorFirstName is not None:
            oprot.writeFieldBegin('impersonatorFirstName', TType.STRING, 22)
            oprot.writeString(self.impersonatorFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorFirstName)
            oprot.writeFieldEnd()
        if self.impersonatorLastName is not None:
            oprot.writeFieldBegin('impersonatorLastName', TType.STRING, 23)
            oprot.writeString(self.impersonatorLastName.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorLastName)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 24)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItemName is not None:
            oprot.writeFieldBegin('checklistItemName', TType.STRING, 25)
            oprot.writeString(self.checklistItemName.encode('utf-8') if sys.version_info[0] == 2 else self.checklistItemName)
            oprot.writeFieldEnd()
        if self.notificationType is not None:
            oprot.writeFieldBegin('notificationType', TType.STRING, 26)
            oprot.writeString(self.notificationType.encode('utf-8') if sys.version_info[0] == 2 else self.notificationType)
            oprot.writeFieldEnd()
        if self.dmsAgentCommunicationInfo is not None:
            oprot.writeFieldBegin('dmsAgentCommunicationInfo', TType.STRUCT, 27)
            self.dmsAgentCommunicationInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsClientCommunicationInfo is not None:
            oprot.writeFieldBegin('dmsClientCommunicationInfo', TType.STRUCT, 28)
            self.dmsClientCommunicationInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
