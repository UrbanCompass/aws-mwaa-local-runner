# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.dms_common.dms_communication.ttypes as dms_communication
import gen.urbancompass.dms_communication_model.ttypes as dms_communication_model
import gen.urbancompass.dms_document.ttypes as dms_document
import gen.urbancompass.dms_common.dms_folder.ttypes as dms_folder
import gen.urbancompass.dms_common.dms_listing.ttypes as dms_listing
import gen.urbancompass.dms_state_model.ttypes as dms_state_model
import uc.grpc.codec as _grpc_codec



class DmsCommunicationServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.getEventPayloadsForFolder = channel.unary_unary(
        '/DmsCommunicationService/getEventPayloadsForFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetEventPayloadsForFolderResponse),
        )
    self.triggerCommunicationService = channel.unary_unary(
        '/DmsCommunicationService/triggerCommunicationService',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(TriggerCommunicationServiceResponse),
        )
    self.triggerDailyDigest = channel.unary_unary(
        '/DmsCommunicationService/triggerDailyDigest',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(TriggerDailyDigestResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class DmsCommunicationServiceServicer(BaseServiceServicer):
  """
    The DmsCommunicationService Service definition
  """

  def getEventPayloadsForFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def triggerCommunicationService(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def triggerDailyDigest(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_DmsCommunicationServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'getEventPayloadsForFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getEventPayloadsForFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetEventPayloadsForFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'triggerCommunicationService': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.triggerCommunicationService(req),
          request_deserializer=_grpc_codec.deserializer(TriggerCommunicationServiceRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'triggerDailyDigest': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.triggerDailyDigest(req),
          request_deserializer=_grpc_codec.deserializer(TriggerDailyDigestRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsCommunicationService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_DmsCommunicationServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'getEventPayloadsForFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getEventPayloadsForFolder,
          request_deserializer=_grpc_codec.deserializer(GetEventPayloadsForFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'triggerCommunicationService': grpc.unary_unary_rpc_method_handler(
          servicer.triggerCommunicationService,
          request_deserializer=_grpc_codec.deserializer(TriggerCommunicationServiceRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'triggerDailyDigest': grpc.unary_unary_rpc_method_handler(
          servicer.triggerDailyDigest,
          request_deserializer=_grpc_codec.deserializer(TriggerDailyDigestRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsCommunicationService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

