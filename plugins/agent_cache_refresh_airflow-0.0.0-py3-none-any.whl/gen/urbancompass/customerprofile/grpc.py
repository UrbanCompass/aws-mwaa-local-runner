# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.user.user.ttypes as user
import gen.urbancompass.common.utils.ttypes as utils
import uc.grpc.codec as _grpc_codec



class CustomerProfileServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.create = channel.unary_unary(
        '/CustomerProfileService/create',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateCustomerProfileResponse),
        )
    self.find = channel.unary_unary(
        '/CustomerProfileService/find',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FindCustomerProfileResponse),
        )
    self.get = channel.unary_unary(
        '/CustomerProfileService/get',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetCustomerProfileResponse),
        )
    self.getCustomerEmails = channel.unary_unary(
        '/CustomerProfileService/getCustomerEmails',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetCustomerEmailsResponse),
        )
    self.loadCustomers = channel.unary_unary(
        '/CustomerProfileService/loadCustomers',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(LoadCustomerProfilesResponse),
        )
    self.save = channel.unary_unary(
        '/CustomerProfileService/save',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateCustomerProfileResponse),
        )
    self.update = channel.unary_unary(
        '/CustomerProfileService/update',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateCustomerProfileResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class CustomerProfileServiceServicer(BaseServiceServicer):
  """
    The CustomerProfileService Service definition
  """

  def create(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def find(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def get(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getCustomerEmails(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def loadCustomers(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def save(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def update(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_CustomerProfileServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'create': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.create(req),
          request_deserializer=_grpc_codec.deserializer(CustomerProfile),
          response_serializer=_grpc_codec.serialize,
      ),
      'find': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.find(req),
          request_deserializer=_grpc_codec.deserializer(FindCustomerProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'get': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.get(req),
          request_deserializer=_grpc_codec.deserializer(GetCustomerProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCustomerEmails': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getCustomerEmails(req),
          request_deserializer=_grpc_codec.deserializer(GetCustomerEmailsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadCustomers': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.loadCustomers(req),
          request_deserializer=_grpc_codec.deserializer(LoadCustomerProfilesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'save': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.save(req),
          request_deserializer=_grpc_codec.deserializer(CustomerProfile),
          response_serializer=_grpc_codec.serialize,
      ),
      'update': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.update(req),
          request_deserializer=_grpc_codec.deserializer(CustomerProfile),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'CustomerProfileService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_CustomerProfileServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'create': grpc.unary_unary_rpc_method_handler(
          servicer.create,
          request_deserializer=_grpc_codec.deserializer(CustomerProfile),
          response_serializer=_grpc_codec.serialize,
      ),
      'find': grpc.unary_unary_rpc_method_handler(
          servicer.find,
          request_deserializer=_grpc_codec.deserializer(FindCustomerProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'get': grpc.unary_unary_rpc_method_handler(
          servicer.get,
          request_deserializer=_grpc_codec.deserializer(GetCustomerProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCustomerEmails': grpc.unary_unary_rpc_method_handler(
          servicer.getCustomerEmails,
          request_deserializer=_grpc_codec.deserializer(GetCustomerEmailsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadCustomers': grpc.unary_unary_rpc_method_handler(
          servicer.loadCustomers,
          request_deserializer=_grpc_codec.deserializer(LoadCustomerProfilesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'save': grpc.unary_unary_rpc_method_handler(
          servicer.save,
          request_deserializer=_grpc_codec.deserializer(CustomerProfile),
          response_serializer=_grpc_codec.serialize,
      ),
      'update': grpc.unary_unary_rpc_method_handler(
          servicer.update,
          request_deserializer=_grpc_codec.deserializer(CustomerProfile),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'CustomerProfileService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

