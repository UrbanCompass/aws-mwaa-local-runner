# -*- coding: utf-8 -*-
"""
:copyright: (c) 2017 by Urban Compass, Inc.
"""
GRPC_PORT_OFFSET = 500


def grpc_port_from_thrift_port(thrift_port):
    return GRPC_PORT_OFFSET + thrift_port
