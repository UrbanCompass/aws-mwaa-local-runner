
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class FolderSortingOption(object):
    LISTING_TYPE = 0
    CREATED_AT = 1
    CLOSE_DATE = 2
    LAST_DOCUMENT_UPDATED_DATE = 3
    NUM_DOCUMENTS_PENDING = 4
    DMS_LISTING_TRANSACTION_STAGE = 5
    NUM_DOCUMENTS_NEEDED = 6
    EXPIRATION_DATE = 7
    INITIAL_COMPLETED_AT = 8
    LAST_DOCUMENT_REVIEWED_DATE = 9
    NUM_UNRESOLVED_CHECKLIST_NOTES = 10

    _VALUES_TO_NAMES = {
        0: "LISTING_TYPE",
        1: "CREATED_AT",
        2: "CLOSE_DATE",
        3: "LAST_DOCUMENT_UPDATED_DATE",
        4: "NUM_DOCUMENTS_PENDING",
        5: "DMS_LISTING_TRANSACTION_STAGE",
        6: "NUM_DOCUMENTS_NEEDED",
        7: "EXPIRATION_DATE",
        8: "INITIAL_COMPLETED_AT",
        9: "LAST_DOCUMENT_REVIEWED_DATE",
        10: "NUM_UNRESOLVED_CHECKLIST_NOTES",
    }

    _NAMES_TO_VALUES = {
        "LISTING_TYPE": 0,
        "CREATED_AT": 1,
        "CLOSE_DATE": 2,
        "LAST_DOCUMENT_UPDATED_DATE": 3,
        "NUM_DOCUMENTS_PENDING": 4,
        "DMS_LISTING_TRANSACTION_STAGE": 5,
        "NUM_DOCUMENTS_NEEDED": 6,
        "EXPIRATION_DATE": 7,
        "INITIAL_COMPLETED_AT": 8,
        "LAST_DOCUMENT_REVIEWED_DATE": 9,
        "NUM_UNRESOLVED_CHECKLIST_NOTES": 10,
    }


class OriginatedFrom(object):
    BT = 0
    DMS = 1
    UNKNOWN = 2

    _VALUES_TO_NAMES = {
        0: "BT",
        1: "DMS",
        2: "UNKNOWN",
    }

    _NAMES_TO_VALUES = {
        "BT": 0,
        "DMS": 1,
        "UNKNOWN": 2,
    }


class ReferralType(object):
    NONE = 0
    OUTGOING_INTERNAL = 1
    OUTGOING_EXTERNAL = 2
    INCOMING_INTERNAL = 3
    INCOMING_EXTERNAL = 4

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "OUTGOING_INTERNAL",
        2: "OUTGOING_EXTERNAL",
        3: "INCOMING_INTERNAL",
        4: "INCOMING_EXTERNAL",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "OUTGOING_INTERNAL": 1,
        "OUTGOING_EXTERNAL": 2,
        "INCOMING_INTERNAL": 3,
        "INCOMING_EXTERNAL": 4,
    }


class SourceService(object):
    BT = 0
    CS = 1

    _VALUES_TO_NAMES = {
        0: "BT",
        1: "CS",
    }

    _NAMES_TO_VALUES = {
        "BT": 0,
        "CS": 1,
    }


class StateCode(object):
    AL = 0
    AK = 1
    AZ = 2
    AR = 3
    CA = 4
    CO = 5
    CT = 6
    DE = 7
    DC = 8
    FL = 9
    GA = 10
    HI = 11
    ID = 12
    IL = 13
    IN = 14
    IA = 15
    KS = 16
    KY = 17
    LA = 18
    ME = 19
    MD = 20
    MA = 21
    MI = 22
    MN = 23
    MS = 24
    MO = 25
    MT = 26
    NE = 27
    NV = 28
    NH = 29
    NJ = 30
    NM = 31
    NY = 32
    NC = 33
    ND = 34
    OH = 35
    OK = 36
    OR = 37
    PA = 38
    RI = 39
    SC = 40
    SD = 41
    TN = 42
    TX = 43
    UT = 44
    VT = 45
    VA = 46
    WA = 47
    WV = 48
    WI = 49
    WY = 50

    _VALUES_TO_NAMES = {
        0: "AL",
        1: "AK",
        2: "AZ",
        3: "AR",
        4: "CA",
        5: "CO",
        6: "CT",
        7: "DE",
        8: "DC",
        9: "FL",
        10: "GA",
        11: "HI",
        12: "ID",
        13: "IL",
        14: "IN",
        15: "IA",
        16: "KS",
        17: "KY",
        18: "LA",
        19: "ME",
        20: "MD",
        21: "MA",
        22: "MI",
        23: "MN",
        24: "MS",
        25: "MO",
        26: "MT",
        27: "NE",
        28: "NV",
        29: "NH",
        30: "NJ",
        31: "NM",
        32: "NY",
        33: "NC",
        34: "ND",
        35: "OH",
        36: "OK",
        37: "OR",
        38: "PA",
        39: "RI",
        40: "SC",
        41: "SD",
        42: "TN",
        43: "TX",
        44: "UT",
        45: "VT",
        46: "VA",
        47: "WA",
        48: "WV",
        49: "WI",
        50: "WY",
    }

    _NAMES_TO_VALUES = {
        "AL": 0,
        "AK": 1,
        "AZ": 2,
        "AR": 3,
        "CA": 4,
        "CO": 5,
        "CT": 6,
        "DE": 7,
        "DC": 8,
        "FL": 9,
        "GA": 10,
        "HI": 11,
        "ID": 12,
        "IL": 13,
        "IN": 14,
        "IA": 15,
        "KS": 16,
        "KY": 17,
        "LA": 18,
        "ME": 19,
        "MD": 20,
        "MA": 21,
        "MI": 22,
        "MN": 23,
        "MS": 24,
        "MO": 25,
        "MT": 26,
        "NE": 27,
        "NV": 28,
        "NH": 29,
        "NJ": 30,
        "NM": 31,
        "NY": 32,
        "NC": 33,
        "ND": 34,
        "OH": 35,
        "OK": 36,
        "OR": 37,
        "PA": 38,
        "RI": 39,
        "SC": 40,
        "SD": 41,
        "TN": 42,
        "TX": 43,
        "UT": 44,
        "VT": 45,
        "VA": 46,
        "WA": 47,
        "WV": 48,
        "WI": 49,
        "WY": 50,
    }


class FolderSortingRequest(object):
    """
    Attributes:
     - folderSortingOption
     - folderSortingDescending
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'folderSortingOption', None, None, ),  # 1
        (2, TType.BOOL, 'folderSortingDescending', None, None, ),  # 2
    )
    def __init__(self, folderSortingOption=None, folderSortingDescending=None, ):
        self.folderSortingOption = folderSortingOption
        self.folderSortingDescending = folderSortingDescending

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.folderSortingOption = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.folderSortingDescending = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FolderSortingRequest')
        if self.folderSortingOption is not None:
            oprot.writeFieldBegin('folderSortingOption', TType.I32, 1)
            oprot.writeI32(self.folderSortingOption)
            oprot.writeFieldEnd()
        if self.folderSortingDescending is not None:
            oprot.writeFieldBegin('folderSortingDescending', TType.BOOL, 2)
            oprot.writeBool(self.folderSortingDescending)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamDmsFolderMatchingLocation(object):
    """
    Attributes:
     - mlsId
     - dmsFolderId
     - dealListingId
     - folderCreatedBy
     - listingCreatedBy
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'mlsId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'folderCreatedBy', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'listingCreatedBy', 'UTF8', None, ),  # 5
    )
    def __init__(self, mlsId=None, dmsFolderId=None, dealListingId=None, folderCreatedBy=None, listingCreatedBy=None, ):
        self.mlsId = mlsId
        self.dmsFolderId = dmsFolderId
        self.dealListingId = dealListingId
        self.folderCreatedBy = folderCreatedBy
        self.listingCreatedBy = listingCreatedBy

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.folderCreatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.listingCreatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamDmsFolderMatchingLocation')
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 1)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 3)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.folderCreatedBy is not None:
            oprot.writeFieldBegin('folderCreatedBy', TType.STRING, 4)
            oprot.writeString(self.folderCreatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.folderCreatedBy)
            oprot.writeFieldEnd()
        if self.listingCreatedBy is not None:
            oprot.writeFieldBegin('listingCreatedBy', TType.STRING, 5)
            oprot.writeString(self.listingCreatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.listingCreatedBy)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
