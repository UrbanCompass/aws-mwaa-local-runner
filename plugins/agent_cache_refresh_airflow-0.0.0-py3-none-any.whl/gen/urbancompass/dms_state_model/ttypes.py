
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_communication.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_document.ttypes
import gen.urbancompass.dms_common.dms_folder.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.permissions.permissions_acl_api.ttypes
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes

from thrift.transport import TTransport


class ChecklistItemStatus(object):
    NOT_DONE = 0
    DONE = 1

    _VALUES_TO_NAMES = {
        0: "NOT_DONE",
        1: "DONE",
    }

    _NAMES_TO_VALUES = {
        "NOT_DONE": 0,
        "DONE": 1,
    }


class ConditionToCheck(object):
    IS_COMPLIANCE_COMPLETE = 0
    ALL_DOCUMENTS_UPLOADED_APPROVED = 1
    COMMISSION_NOT_SUBMITTED = 2
    ALL_REQUIRED_DOCUMENTS_UPLOADED = 3
    NOT_ALL_REQUIRED_DOCUMENTS_UPLOADED = 4
    LISTING_CHECKLIST_ITEM_NOTE_VALID = 5
    TRANSACTION_CHECKLIST_ITEM_NOTE_VALID = 6

    _VALUES_TO_NAMES = {
        0: "IS_COMPLIANCE_COMPLETE",
        1: "ALL_DOCUMENTS_UPLOADED_APPROVED",
        2: "COMMISSION_NOT_SUBMITTED",
        3: "ALL_REQUIRED_DOCUMENTS_UPLOADED",
        4: "NOT_ALL_REQUIRED_DOCUMENTS_UPLOADED",
        5: "LISTING_CHECKLIST_ITEM_NOTE_VALID",
        6: "TRANSACTION_CHECKLIST_ITEM_NOTE_VALID",
    }

    _NAMES_TO_VALUES = {
        "IS_COMPLIANCE_COMPLETE": 0,
        "ALL_DOCUMENTS_UPLOADED_APPROVED": 1,
        "COMMISSION_NOT_SUBMITTED": 2,
        "ALL_REQUIRED_DOCUMENTS_UPLOADED": 3,
        "NOT_ALL_REQUIRED_DOCUMENTS_UPLOADED": 4,
        "LISTING_CHECKLIST_ITEM_NOTE_VALID": 5,
        "TRANSACTION_CHECKLIST_ITEM_NOTE_VALID": 6,
    }


class DmsAgentIdType(object):
    LISTING = 0
    OFFER = 1

    _VALUES_TO_NAMES = {
        0: "LISTING",
        1: "OFFER",
    }

    _NAMES_TO_VALUES = {
        "LISTING": 0,
        "OFFER": 1,
    }


class DmsFolderChecklistItemType(object):
    LISTING = 0
    LISTING_CHECKLIST = 1
    TRANSACTION_CHECKLIST = 2
    CLOSED_CHECKLIST = 3
    OFFER = 4
    COMMISSIONS_REQUESTED = 5
    WITHDRAWN_CANCELED_CHECKLIST = 6

    _VALUES_TO_NAMES = {
        0: "LISTING",
        1: "LISTING_CHECKLIST",
        2: "TRANSACTION_CHECKLIST",
        3: "CLOSED_CHECKLIST",
        4: "OFFER",
        5: "COMMISSIONS_REQUESTED",
        6: "WITHDRAWN_CANCELED_CHECKLIST",
    }

    _NAMES_TO_VALUES = {
        "LISTING": 0,
        "LISTING_CHECKLIST": 1,
        "TRANSACTION_CHECKLIST": 2,
        "CLOSED_CHECKLIST": 3,
        "OFFER": 4,
        "COMMISSIONS_REQUESTED": 5,
        "WITHDRAWN_CANCELED_CHECKLIST": 6,
    }


class DmsFolderChecklistState(object):
    COMPLETE = 0
    NOT_STARTED = 1
    UNDER_REVIEW = 2
    ERRORS = 3
    IN_PROGRESS = 4

    _VALUES_TO_NAMES = {
        0: "COMPLETE",
        1: "NOT_STARTED",
        2: "UNDER_REVIEW",
        3: "ERRORS",
        4: "IN_PROGRESS",
    }

    _NAMES_TO_VALUES = {
        "COMPLETE": 0,
        "NOT_STARTED": 1,
        "UNDER_REVIEW": 2,
        "ERRORS": 3,
        "IN_PROGRESS": 4,
    }


class InternalFolderTransactionType(object):
    TRANSACTION = 0
    REFERRAL = 1
    LISTING = 2
    CLOSED = 3
    WITHDRAWN = 4
    EMPTY = 5
    UNKNOWN = 6

    _VALUES_TO_NAMES = {
        0: "TRANSACTION",
        1: "REFERRAL",
        2: "LISTING",
        3: "CLOSED",
        4: "WITHDRAWN",
        5: "EMPTY",
        6: "UNKNOWN",
    }

    _NAMES_TO_VALUES = {
        "TRANSACTION": 0,
        "REFERRAL": 1,
        "LISTING": 2,
        "CLOSED": 3,
        "WITHDRAWN": 4,
        "EMPTY": 5,
        "UNKNOWN": 6,
    }


class ReviewStatus(object):
    CLAIMED = 0
    UNCLAIMED = 1

    _VALUES_TO_NAMES = {
        0: "CLAIMED",
        1: "UNCLAIMED",
    }

    _NAMES_TO_VALUES = {
        "CLAIMED": 0,
        "UNCLAIMED": 1,
    }


class SyntheticEntity(object):
    NONE = 0
    PRE_OFFER = 1
    REFERRAL = 2

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "PRE_OFFER",
        2: "REFERRAL",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "PRE_OFFER": 1,
        "REFERRAL": 2,
    }


class ClosingDmsChecklistDocument(object):
    """
    Attributes:
     - feeId
     - checklistItemId
     - documentId
     - documentStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'feeId', None, None, ),  # 1
        (2, TType.I32, 'checklistItemId', None, None, ),  # 2
        (3, TType.STRING, 'documentId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'documentStatus', None, None, ),  # 4
    )
    def __init__(self, feeId=None, checklistItemId=None, documentId=None, documentStatus=None, ):
        self.feeId = feeId
        self.checklistItemId = checklistItemId
        self.documentId = documentId
        self.documentStatus = documentStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.feeId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.documentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosingDmsChecklistDocument')
        if self.feeId is not None:
            oprot.writeFieldBegin('feeId', TType.I64, 1)
            oprot.writeI64(self.feeId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 2)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 3)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.documentStatus is not None:
            oprot.writeFieldBegin('documentStatus', TType.I32, 4)
            oprot.writeI32(self.documentStatus)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsAgent(object):
    """
    Attributes:
     - id
     - dmsListingId
     - dmsTransactionId
     - agentUserId
     - displayName
     - email
     - phone
     - avatarUrl
     - isPrimary
     - isDeleted
     - createdBy
     - createdAt
     - isDualRep
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'agentUserId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'displayName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'email', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'phone', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'isPrimary', None, None, ),  # 9
        (10, TType.BOOL, 'isDeleted', None, None, ),  # 10
        (11, TType.STRING, 'createdBy', 'UTF8', None, ),  # 11
        (12, TType.I64, 'createdAt', None, None, ),  # 12
        (13, TType.BOOL, 'isDualRep', None, None, ),  # 13
    )
    def __init__(self, id=None, dmsListingId=None, dmsTransactionId=None, agentUserId=None, displayName=None, email=None, phone=None, avatarUrl=None, isPrimary=None, isDeleted=None, createdBy=None, createdAt=None, isDualRep=None, ):
        self.id = id
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.agentUserId = agentUserId
        self.displayName = displayName
        self.email = email
        self.phone = phone
        self.avatarUrl = avatarUrl
        self.isPrimary = isPrimary
        self.isDeleted = isDeleted
        self.createdBy = createdBy
        self.createdAt = createdAt
        self.isDualRep = isDualRep

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.agentUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isPrimary = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isDualRep = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsAgent')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.agentUserId is not None:
            oprot.writeFieldBegin('agentUserId', TType.STRING, 4)
            oprot.writeString(self.agentUserId.encode('utf-8') if sys.version_info[0] == 2 else self.agentUserId)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 5)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 6)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 7)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 8)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.isPrimary is not None:
            oprot.writeFieldBegin('isPrimary', TType.BOOL, 9)
            oprot.writeBool(self.isPrimary)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 10)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 11)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 12)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.isDualRep is not None:
            oprot.writeFieldBegin('isDualRep', TType.BOOL, 13)
            oprot.writeBool(self.isDualRep)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsContact(object):
    """
    Attributes:
     - id
     - dmsFolderId
     - dmsTransactionId
     - isDeleted
     - sideRepresented
     - firstName
     - lastName
     - contactType
     - emailAddress
     - isCompany
     - companyName
     - crmContactId
     - isRecommended
     - createdAt
     - updatedAt
     - phoneNumber
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'isDeleted', None, None, ),  # 4
        (5, TType.I32, 'sideRepresented', None, None, ),  # 5
        (6, TType.STRING, 'firstName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'lastName', 'UTF8', None, ),  # 7
        (8, TType.I32, 'contactType', None, None, ),  # 8
        (9, TType.STRING, 'emailAddress', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'isCompany', None, None, ),  # 10
        (11, TType.STRING, 'companyName', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'crmContactId', 'UTF8', None, ),  # 12
        (13, TType.BOOL, 'isRecommended', None, None, ),  # 13
        (14, TType.I64, 'createdAt', None, None, ),  # 14
        (15, TType.I64, 'updatedAt', None, None, ),  # 15
        (16, TType.STRING, 'phoneNumber', 'UTF8', None, ),  # 16
    )
    def __init__(self, id=None, dmsFolderId=None, dmsTransactionId=None, isDeleted=None, sideRepresented=None, firstName=None, lastName=None, contactType=None, emailAddress=None, isCompany=None, companyName=None, crmContactId=None, isRecommended=None, createdAt=None, updatedAt=None, phoneNumber=None, ):
        self.id = id
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId
        self.isDeleted = isDeleted
        self.sideRepresented = sideRepresented
        self.firstName = firstName
        self.lastName = lastName
        self.contactType = contactType
        self.emailAddress = emailAddress
        self.isCompany = isCompany
        self.companyName = companyName
        self.crmContactId = crmContactId
        self.isRecommended = isRecommended
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.phoneNumber = phoneNumber

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.contactType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.emailAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isCompany = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.companyName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.crmContactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isRecommended = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.phoneNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsContact')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 4)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 5)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 6)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 7)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.I32, 8)
            oprot.writeI32(self.contactType)
            oprot.writeFieldEnd()
        if self.emailAddress is not None:
            oprot.writeFieldBegin('emailAddress', TType.STRING, 9)
            oprot.writeString(self.emailAddress.encode('utf-8') if sys.version_info[0] == 2 else self.emailAddress)
            oprot.writeFieldEnd()
        if self.isCompany is not None:
            oprot.writeFieldBegin('isCompany', TType.BOOL, 10)
            oprot.writeBool(self.isCompany)
            oprot.writeFieldEnd()
        if self.companyName is not None:
            oprot.writeFieldBegin('companyName', TType.STRING, 11)
            oprot.writeString(self.companyName.encode('utf-8') if sys.version_info[0] == 2 else self.companyName)
            oprot.writeFieldEnd()
        if self.crmContactId is not None:
            oprot.writeFieldBegin('crmContactId', TType.STRING, 12)
            oprot.writeString(self.crmContactId.encode('utf-8') if sys.version_info[0] == 2 else self.crmContactId)
            oprot.writeFieldEnd()
        if self.isRecommended is not None:
            oprot.writeFieldBegin('isRecommended', TType.BOOL, 13)
            oprot.writeBool(self.isRecommended)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 14)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 15)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.phoneNumber is not None:
            oprot.writeFieldBegin('phoneNumber', TType.STRING, 16)
            oprot.writeString(self.phoneNumber.encode('utf-8') if sys.version_info[0] == 2 else self.phoneNumber)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolder(object):
    """
    Attributes:
     - id
     - name
     - sideRepresented
     - createdBy
     - team
     - createdAt
     - updatedAt
     - isDeleted
     - partitionState
     - ama
     - groupId
     - sfTeamId
     - staffGroupId
     - submarketId
     - officeId
     - marketId
     - referralType
     - sourceService
     - isReferralDeal
     - folderType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.STRING, 'createdBy', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'team', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.I32, 'partitionState', None, None, ),  # 9
        (10, TType.STRING, 'ama', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'groupId', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'sfTeamId', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'staffGroupId', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'submarketId', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'officeId', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'marketId', 'UTF8', None, ),  # 16
        (17, TType.I32, 'referralType', None, None, ),  # 17
        (18, TType.I32, 'sourceService', None, None, ),  # 18
        (19, TType.BOOL, 'isReferralDeal', None, None, ),  # 19
        (20, TType.I32, 'folderType', None, None, ),  # 20
    )
    def __init__(self, id=None, name=None, sideRepresented=None, createdBy=None, team=None, createdAt=None, updatedAt=None, isDeleted=None, partitionState=None, ama=None, groupId=None, sfTeamId=None, staffGroupId=None, submarketId=None, officeId=None, marketId=None, referralType=None, sourceService=None, isReferralDeal=None, folderType=None, ):
        self.id = id
        self.name = name
        self.sideRepresented = sideRepresented
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.isDeleted = isDeleted
        self.partitionState = partitionState
        self.ama = ama
        self.groupId = groupId
        self.sfTeamId = sfTeamId
        self.staffGroupId = staffGroupId
        self.submarketId = submarketId
        self.officeId = officeId
        self.marketId = marketId
        self.referralType = referralType
        self.sourceService = sourceService
        self.isReferralDeal = isReferralDeal
        self.folderType = folderType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.partitionState = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.ama = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.groupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.sfTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.staffGroupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.submarketId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.officeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.marketId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.sourceService = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.isReferralDeal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.folderType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolder')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 4)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 5)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.partitionState is not None:
            oprot.writeFieldBegin('partitionState', TType.I32, 9)
            oprot.writeI32(self.partitionState)
            oprot.writeFieldEnd()
        if self.ama is not None:
            oprot.writeFieldBegin('ama', TType.STRING, 10)
            oprot.writeString(self.ama.encode('utf-8') if sys.version_info[0] == 2 else self.ama)
            oprot.writeFieldEnd()
        if self.groupId is not None:
            oprot.writeFieldBegin('groupId', TType.STRING, 11)
            oprot.writeString(self.groupId.encode('utf-8') if sys.version_info[0] == 2 else self.groupId)
            oprot.writeFieldEnd()
        if self.sfTeamId is not None:
            oprot.writeFieldBegin('sfTeamId', TType.STRING, 12)
            oprot.writeString(self.sfTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.sfTeamId)
            oprot.writeFieldEnd()
        if self.staffGroupId is not None:
            oprot.writeFieldBegin('staffGroupId', TType.STRING, 13)
            oprot.writeString(self.staffGroupId.encode('utf-8') if sys.version_info[0] == 2 else self.staffGroupId)
            oprot.writeFieldEnd()
        if self.submarketId is not None:
            oprot.writeFieldBegin('submarketId', TType.STRING, 14)
            oprot.writeString(self.submarketId.encode('utf-8') if sys.version_info[0] == 2 else self.submarketId)
            oprot.writeFieldEnd()
        if self.officeId is not None:
            oprot.writeFieldBegin('officeId', TType.STRING, 15)
            oprot.writeString(self.officeId.encode('utf-8') if sys.version_info[0] == 2 else self.officeId)
            oprot.writeFieldEnd()
        if self.marketId is not None:
            oprot.writeFieldBegin('marketId', TType.STRING, 16)
            oprot.writeString(self.marketId.encode('utf-8') if sys.version_info[0] == 2 else self.marketId)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 17)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        if self.sourceService is not None:
            oprot.writeFieldBegin('sourceService', TType.I32, 18)
            oprot.writeI32(self.sourceService)
            oprot.writeFieldEnd()
        if self.isReferralDeal is not None:
            oprot.writeFieldBegin('isReferralDeal', TType.BOOL, 19)
            oprot.writeBool(self.isReferralDeal)
            oprot.writeFieldEnd()
        if self.folderType is not None:
            oprot.writeFieldBegin('folderType', TType.I32, 20)
            oprot.writeI32(self.folderType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderReminder(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderReminder')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingChecklistItemNote(object):
    """
    Attributes:
     - noteId
     - note
     - checklistItemId
     - checklistItemNoteRole
     - checklistItemNoteType
     - dmsListingId
     - listingStage
     - isDeleted
     - createdAt
     - createdBy
     - noteCreatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'noteId', None, None, ),  # 1
        (2, TType.STRING, 'note', 'UTF8', None, ),  # 2
        (3, TType.I32, 'checklistItemId', None, None, ),  # 3
        (4, TType.I32, 'checklistItemNoteRole', None, None, ),  # 4
        (5, TType.I32, 'checklistItemNoteType', None, None, ),  # 5
        (6, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'listingStage', None, None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.I64, 'createdAt', None, None, ),  # 9
        (10, TType.STRING, 'createdBy', 'UTF8', None, ),  # 10
        (11, TType.I64, 'noteCreatedAt', None, None, ),  # 11
    )
    def __init__(self, noteId=None, note=None, checklistItemId=None, checklistItemNoteRole=None, checklistItemNoteType=None, dmsListingId=None, listingStage=None, isDeleted=None, createdAt=None, createdBy=None, noteCreatedAt=None, ):
        self.noteId = noteId
        self.note = note
        self.checklistItemId = checklistItemId
        self.checklistItemNoteRole = checklistItemNoteRole
        self.checklistItemNoteType = checklistItemNoteType
        self.dmsListingId = dmsListingId
        self.listingStage = listingStage
        self.isDeleted = isDeleted
        self.createdAt = createdAt
        self.createdBy = createdBy
        self.noteCreatedAt = noteCreatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.noteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemNoteRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.checklistItemNoteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.listingStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.noteCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingChecklistItemNote')
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.I64, 1)
            oprot.writeI64(self.noteId)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 2)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 3)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.checklistItemNoteRole is not None:
            oprot.writeFieldBegin('checklistItemNoteRole', TType.I32, 4)
            oprot.writeI32(self.checklistItemNoteRole)
            oprot.writeFieldEnd()
        if self.checklistItemNoteType is not None:
            oprot.writeFieldBegin('checklistItemNoteType', TType.I32, 5)
            oprot.writeI32(self.checklistItemNoteType)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 6)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.listingStage is not None:
            oprot.writeFieldBegin('listingStage', TType.I32, 7)
            oprot.writeI32(self.listingStage)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 9)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 10)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.noteCreatedAt is not None:
            oprot.writeFieldBegin('noteCreatedAt', TType.I64, 11)
            oprot.writeI64(self.noteCreatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingDocument(object):
    """
    Attributes:
     - dmsListingId
     - checklistItemId
     - documentId
     - createdAt
     - isDeleted
     - deletedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistItemId', None, None, ),  # 2
        (3, TType.STRING, 'documentId', 'UTF8', None, ),  # 3
        (4, TType.I64, 'createdAt', None, None, ),  # 4
        (5, TType.BOOL, 'isDeleted', None, None, ),  # 5
        (6, TType.I64, 'deletedAt', None, None, ),  # 6
    )
    def __init__(self, dmsListingId=None, checklistItemId=None, documentId=None, createdAt=None, isDeleted=None, deletedAt=None, ):
        self.dmsListingId = dmsListingId
        self.checklistItemId = checklistItemId
        self.documentId = documentId
        self.createdAt = createdAt
        self.isDeleted = isDeleted
        self.deletedAt = deletedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingDocument')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 2)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 3)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 4)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 5)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 6)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingFieldsUpdatedAt(object):
    """
    Attributes:
     - dmsListingId
     - propertyAddress
     - yearBuilt
     - listDate
     - expirationDate
     - listPrice
     - propertyType
     - unit
     - city
     - state
     - zipcode
     - mlsId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'propertyAddress', None, None, ),  # 2
        (3, TType.I64, 'yearBuilt', None, None, ),  # 3
        (4, TType.I64, 'listDate', None, None, ),  # 4
        (5, TType.I64, 'expirationDate', None, None, ),  # 5
        (6, TType.I64, 'listPrice', None, None, ),  # 6
        (7, TType.I64, 'propertyType', None, None, ),  # 7
        (8, TType.I64, 'unit', None, None, ),  # 8
        (9, TType.I64, 'city', None, None, ),  # 9
        (10, TType.I64, 'state', None, None, ),  # 10
        (11, TType.I64, 'zipcode', None, None, ),  # 11
        (12, TType.I64, 'mlsId', None, None, ),  # 12
    )
    def __init__(self, dmsListingId=None, propertyAddress=None, yearBuilt=None, listDate=None, expirationDate=None, listPrice=None, propertyType=None, unit=None, city=None, state=None, zipcode=None, mlsId=None, ):
        self.dmsListingId = dmsListingId
        self.propertyAddress = propertyAddress
        self.yearBuilt = yearBuilt
        self.listDate = listDate
        self.expirationDate = expirationDate
        self.listPrice = listPrice
        self.propertyType = propertyType
        self.unit = unit
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.mlsId = mlsId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.propertyAddress = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.yearBuilt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.expirationDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.listPrice = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.propertyType = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.unit = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.city = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.state = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.zipcode = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.mlsId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingFieldsUpdatedAt')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.I64, 2)
            oprot.writeI64(self.propertyAddress)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I64, 3)
            oprot.writeI64(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 4)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.I64, 5)
            oprot.writeI64(self.expirationDate)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.I64, 6)
            oprot.writeI64(self.listPrice)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I64, 7)
            oprot.writeI64(self.propertyType)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.I64, 8)
            oprot.writeI64(self.unit)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.I64, 9)
            oprot.writeI64(self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.I64, 10)
            oprot.writeI64(self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.I64, 11)
            oprot.writeI64(self.zipcode)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.I64, 12)
            oprot.writeI64(self.mlsId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingPatch(object):
    """
    Attributes:
     - dmsListingId
     - dealListingId
     - propertyAddress
     - city
     - state
     - zipcode
     - listPrice
     - isDeleted
     - yearBuilt
     - propertyType
     - listingType
     - createdAt
     - updatedAt
     - usedConcierge
     - mediaUrl
     - unit
     - expirationDate
     - yearlyRent
     - market
     - isNewConstruction
     - listDate
     - mlsId
     - isFullServiceRental
     - isHousingVoucher
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'city', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'state', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'zipcode', 'UTF8', None, ),  # 6
        (7, TType.DOUBLE, 'listPrice', None, None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.I32, 'yearBuilt', None, None, ),  # 9
        (10, TType.I32, 'propertyType', None, None, ),  # 10
        (11, TType.I32, 'listingType', None, None, ),  # 11
        (12, TType.I64, 'createdAt', None, None, ),  # 12
        (13, TType.I64, 'updatedAt', None, None, ),  # 13
        (14, TType.BOOL, 'usedConcierge', None, None, ),  # 14
        (15, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'unit', 'UTF8', None, ),  # 16
        (17, TType.I64, 'expirationDate', None, None, ),  # 17
        (18, TType.DOUBLE, 'yearlyRent', None, None, ),  # 18
        (19, TType.STRING, 'market', 'UTF8', None, ),  # 19
        (20, TType.BOOL, 'isNewConstruction', None, None, ),  # 20
        (21, TType.I64, 'listDate', None, None, ),  # 21
        (22, TType.STRING, 'mlsId', 'UTF8', None, ),  # 22
        (23, TType.BOOL, 'isFullServiceRental', None, None, ),  # 23
        (24, TType.BOOL, 'isHousingVoucher', None, None, ),  # 24
    )
    def __init__(self, dmsListingId=None, dealListingId=None, propertyAddress=None, city=None, state=None, zipcode=None, listPrice=None, isDeleted=None, yearBuilt=None, propertyType=None, listingType=None, createdAt=None, updatedAt=None, usedConcierge=None, mediaUrl=None, unit=None, expirationDate=None, yearlyRent=None, market=None, isNewConstruction=None, listDate=None, mlsId=None, isFullServiceRental=None, isHousingVoucher=None, ):
        self.dmsListingId = dmsListingId
        self.dealListingId = dealListingId
        self.propertyAddress = propertyAddress
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.isDeleted = isDeleted
        self.yearBuilt = yearBuilt
        self.propertyType = propertyType
        self.listingType = listingType
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.unit = unit
        self.expirationDate = expirationDate
        self.yearlyRent = yearlyRent
        self.market = market
        self.isNewConstruction = isNewConstruction
        self.listDate = listDate
        self.mlsId = mlsId
        self.isFullServiceRental = isFullServiceRental
        self.isHousingVoucher = isHousingVoucher

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I64:
                    self.expirationDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.DOUBLE:
                    self.yearlyRent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.isFullServiceRental = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.isHousingVoucher = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingPatch')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 2)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 3)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 4)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 5)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 6)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 7)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 9)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 10)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 11)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 12)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 13)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 14)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 15)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 16)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.I64, 17)
            oprot.writeI64(self.expirationDate)
            oprot.writeFieldEnd()
        if self.yearlyRent is not None:
            oprot.writeFieldBegin('yearlyRent', TType.DOUBLE, 18)
            oprot.writeDouble(self.yearlyRent)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 19)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 20)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 21)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 22)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.isFullServiceRental is not None:
            oprot.writeFieldBegin('isFullServiceRental', TType.BOOL, 23)
            oprot.writeBool(self.isFullServiceRental)
            oprot.writeFieldEnd()
        if self.isHousingVoucher is not None:
            oprot.writeFieldBegin('isHousingVoucher', TType.BOOL, 24)
            oprot.writeBool(self.isHousingVoucher)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingValidationContext(object):
    """
    Attributes:
     - isReferral
     - isDraft
     - isSellSideRep
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isReferral', None, None, ),  # 1
        (2, TType.BOOL, 'isDraft', None, None, ),  # 2
        (3, TType.BOOL, 'isSellSideRep', None, None, ),  # 3
    )
    def __init__(self, isReferral=None, isDraft=None, isSellSideRep=None, ):
        self.isReferral = isReferral
        self.isDraft = isDraft
        self.isSellSideRep = isSellSideRep

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isReferral = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isDraft = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isSellSideRep = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingValidationContext')
        if self.isReferral is not None:
            oprot.writeFieldBegin('isReferral', TType.BOOL, 1)
            oprot.writeBool(self.isReferral)
            oprot.writeFieldEnd()
        if self.isDraft is not None:
            oprot.writeFieldBegin('isDraft', TType.BOOL, 2)
            oprot.writeBool(self.isDraft)
            oprot.writeFieldEnd()
        if self.isSellSideRep is not None:
            oprot.writeFieldBegin('isSellSideRep', TType.BOOL, 3)
            oprot.writeBool(self.isSellSideRep)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsNeededSFInfo(object):
    """
    Attributes:
     - status
     - amaId
     - sfTeamId
     - isSubmarketActive
     - groupId
     - teamExist
     - staffGroupId
     - allowableListingStates
     - submarketId
     - officeId
     - marketId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'amaId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'sfTeamId', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'isSubmarketActive', None, None, ),  # 4
        (5, TType.STRING, 'groupId', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'teamExist', None, None, ),  # 6
        (7, TType.STRING, 'staffGroupId', 'UTF8', None, ),  # 7
        (8, TType.SET, 'allowableListingStates', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.STRING, 'submarketId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'officeId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'marketId', 'UTF8', None, ),  # 11
    )
    def __init__(self, status=None, amaId=None, sfTeamId=None, isSubmarketActive=None, groupId=None, teamExist=None, staffGroupId=None, allowableListingStates=None, submarketId=None, officeId=None, marketId=None, ):
        self.status = status
        self.amaId = amaId
        self.sfTeamId = sfTeamId
        self.isSubmarketActive = isSubmarketActive
        self.groupId = groupId
        self.teamExist = teamExist
        self.staffGroupId = staffGroupId
        self.allowableListingStates = allowableListingStates
        self.submarketId = submarketId
        self.officeId = officeId
        self.marketId = marketId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.sfTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isSubmarketActive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.groupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.teamExist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.staffGroupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.SET:
                    self.allowableListingStates = set()
                    (_etype3, _size5) = iprot.readSetBegin()
                    for _i2 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.allowableListingStates.add(_elem4)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.submarketId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.officeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.marketId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsNeededSFInfo')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 2)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.sfTeamId is not None:
            oprot.writeFieldBegin('sfTeamId', TType.STRING, 3)
            oprot.writeString(self.sfTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.sfTeamId)
            oprot.writeFieldEnd()
        if self.isSubmarketActive is not None:
            oprot.writeFieldBegin('isSubmarketActive', TType.BOOL, 4)
            oprot.writeBool(self.isSubmarketActive)
            oprot.writeFieldEnd()
        if self.groupId is not None:
            oprot.writeFieldBegin('groupId', TType.STRING, 5)
            oprot.writeString(self.groupId.encode('utf-8') if sys.version_info[0] == 2 else self.groupId)
            oprot.writeFieldEnd()
        if self.teamExist is not None:
            oprot.writeFieldBegin('teamExist', TType.BOOL, 6)
            oprot.writeBool(self.teamExist)
            oprot.writeFieldEnd()
        if self.staffGroupId is not None:
            oprot.writeFieldBegin('staffGroupId', TType.STRING, 7)
            oprot.writeString(self.staffGroupId.encode('utf-8') if sys.version_info[0] == 2 else self.staffGroupId)
            oprot.writeFieldEnd()
        if self.allowableListingStates is not None:
            oprot.writeFieldBegin('allowableListingStates', TType.SET, 8)
            oprot.writeSetBegin(TType.STRING, len(self.allowableListingStates))
            for _iter6 in self.allowableListingStates:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.submarketId is not None:
            oprot.writeFieldBegin('submarketId', TType.STRING, 9)
            oprot.writeString(self.submarketId.encode('utf-8') if sys.version_info[0] == 2 else self.submarketId)
            oprot.writeFieldEnd()
        if self.officeId is not None:
            oprot.writeFieldBegin('officeId', TType.STRING, 10)
            oprot.writeString(self.officeId.encode('utf-8') if sys.version_info[0] == 2 else self.officeId)
            oprot.writeFieldEnd()
        if self.marketId is not None:
            oprot.writeFieldBegin('marketId', TType.STRING, 11)
            oprot.writeString(self.marketId.encode('utf-8') if sys.version_info[0] == 2 else self.marketId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsQueryWithChecklistItemIdsObj(object):
    """
    Attributes:
     - id
     - itemIds
     - stage
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'itemIds', (TType.I32, None, False), None, ),  # 2
        (3, TType.I32, 'stage', None, None, ),  # 3
        (4, TType.LIST, 'ids', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, id=None, itemIds=None, stage=None, ids=None, ):
        self.id = id
        self.itemIds = itemIds
        self.stage = stage
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.itemIds = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readI32()
                        self.itemIds.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.ids.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsQueryWithChecklistItemIdsObj')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.itemIds is not None:
            oprot.writeFieldBegin('itemIds', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.itemIds))
            for _iter15 in self.itemIds:
                oprot.writeI32(_iter15)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 3)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.ids))
            for _iter16 in self.ids:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsQueryWithDocumentIdsObj(object):
    """
    Attributes:
     - documentIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'documentIds', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, documentIds=None, ):
        self.documentIds = documentIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.documentIds = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.documentIds.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsQueryWithDocumentIdsObj')
        if self.documentIds is not None:
            oprot.writeFieldBegin('documentIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.documentIds))
            for _iter21 in self.documentIds:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsReview(object):
    """
    Attributes:
     - reviewer
     - dmsFolderId
     - status
     - requestedAt
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'reviewer', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'status', None, None, ),  # 3
        (4, TType.I64, 'requestedAt', None, None, ),  # 4
        (5, TType.I64, 'updatedAt', None, None, ),  # 5
    )
    def __init__(self, reviewer=None, dmsFolderId=None, status=None, requestedAt=None, updatedAt=None, ):
        self.reviewer = reviewer
        self.dmsFolderId = dmsFolderId
        self.status = status
        self.requestedAt = requestedAt
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.reviewer = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.requestedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsReview')
        if self.reviewer is not None:
            oprot.writeFieldBegin('reviewer', TType.STRING, 1)
            oprot.writeString(self.reviewer.encode('utf-8') if sys.version_info[0] == 2 else self.reviewer)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 3)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.requestedAt is not None:
            oprot.writeFieldBegin('requestedAt', TType.I64, 4)
            oprot.writeI64(self.requestedAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 5)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionChecklistItemNote(object):
    """
    Attributes:
     - noteId
     - note
     - checklistItemId
     - checklistItemNoteRole
     - checklistItemNoteType
     - dmsTransactionId
     - transactionStage
     - isDeleted
     - createdAt
     - createdBy
     - noteCreatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'noteId', None, None, ),  # 1
        (2, TType.STRING, 'note', 'UTF8', None, ),  # 2
        (3, TType.I32, 'checklistItemId', None, None, ),  # 3
        (4, TType.I32, 'checklistItemNoteRole', None, None, ),  # 4
        (5, TType.I32, 'checklistItemNoteType', None, None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'transactionStage', None, None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.I64, 'createdAt', None, None, ),  # 9
        (10, TType.STRING, 'createdBy', 'UTF8', None, ),  # 10
        (11, TType.I64, 'noteCreatedAt', None, None, ),  # 11
    )
    def __init__(self, noteId=None, note=None, checklistItemId=None, checklistItemNoteRole=None, checklistItemNoteType=None, dmsTransactionId=None, transactionStage=None, isDeleted=None, createdAt=None, createdBy=None, noteCreatedAt=None, ):
        self.noteId = noteId
        self.note = note
        self.checklistItemId = checklistItemId
        self.checklistItemNoteRole = checklistItemNoteRole
        self.checklistItemNoteType = checklistItemNoteType
        self.dmsTransactionId = dmsTransactionId
        self.transactionStage = transactionStage
        self.isDeleted = isDeleted
        self.createdAt = createdAt
        self.createdBy = createdBy
        self.noteCreatedAt = noteCreatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.noteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemNoteRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.checklistItemNoteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.transactionStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.noteCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionChecklistItemNote')
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.I64, 1)
            oprot.writeI64(self.noteId)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 2)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 3)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.checklistItemNoteRole is not None:
            oprot.writeFieldBegin('checklistItemNoteRole', TType.I32, 4)
            oprot.writeI32(self.checklistItemNoteRole)
            oprot.writeFieldEnd()
        if self.checklistItemNoteType is not None:
            oprot.writeFieldBegin('checklistItemNoteType', TType.I32, 5)
            oprot.writeI32(self.checklistItemNoteType)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.transactionStage is not None:
            oprot.writeFieldBegin('transactionStage', TType.I32, 7)
            oprot.writeI32(self.transactionStage)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 9)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 10)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.noteCreatedAt is not None:
            oprot.writeFieldBegin('noteCreatedAt', TType.I64, 11)
            oprot.writeI64(self.noteCreatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionDocument(object):
    """
    Attributes:
     - dmsTransactionId
     - checklistItemId
     - documentId
     - createdAt
     - isDeleted
     - deletedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistItemId', None, None, ),  # 2
        (3, TType.STRING, 'documentId', 'UTF8', None, ),  # 3
        (4, TType.I64, 'createdAt', None, None, ),  # 4
        (5, TType.BOOL, 'isDeleted', None, None, ),  # 5
        (6, TType.I64, 'deletedAt', None, None, ),  # 6
    )
    def __init__(self, dmsTransactionId=None, checklistItemId=None, documentId=None, createdAt=None, isDeleted=None, deletedAt=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.checklistItemId = checklistItemId
        self.documentId = documentId
        self.createdAt = createdAt
        self.isDeleted = isDeleted
        self.deletedAt = deletedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionDocument')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 2)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 3)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 4)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 5)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 6)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionFieldsUpdatedAt(object):
    """
    Attributes:
     - dmsTransactionId
     - closePrice
     - acceptanceDate
     - closeDate
     - commissionRateAmount
     - commissionRate
     - otherSideCommissionRateAmount
     - otherSideCommissionRate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'closePrice', None, None, ),  # 2
        (3, TType.I64, 'acceptanceDate', None, None, ),  # 3
        (4, TType.I64, 'closeDate', None, None, ),  # 4
        (5, TType.I64, 'commissionRateAmount', None, None, ),  # 5
        (6, TType.I64, 'commissionRate', None, None, ),  # 6
        (7, TType.I64, 'otherSideCommissionRateAmount', None, None, ),  # 7
        (8, TType.I64, 'otherSideCommissionRate', None, None, ),  # 8
    )
    def __init__(self, dmsTransactionId=None, closePrice=None, acceptanceDate=None, closeDate=None, commissionRateAmount=None, commissionRate=None, otherSideCommissionRateAmount=None, otherSideCommissionRate=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.closePrice = closePrice
        self.acceptanceDate = acceptanceDate
        self.closeDate = closeDate
        self.commissionRateAmount = commissionRateAmount
        self.commissionRate = commissionRate
        self.otherSideCommissionRateAmount = otherSideCommissionRateAmount
        self.otherSideCommissionRate = otherSideCommissionRate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.closePrice = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.acceptanceDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.commissionRateAmount = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.commissionRate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.otherSideCommissionRateAmount = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.otherSideCommissionRate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionFieldsUpdatedAt')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.I64, 2)
            oprot.writeI64(self.closePrice)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.I64, 3)
            oprot.writeI64(self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 4)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.I64, 5)
            oprot.writeI64(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.I64, 6)
            oprot.writeI64(self.commissionRate)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmount is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmount', TType.I64, 7)
            oprot.writeI64(self.otherSideCommissionRateAmount)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.I64, 8)
            oprot.writeI64(self.otherSideCommissionRate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsWithdrawnCanceledChecklistItem(object):
    """
    Attributes:
     - checklistType
     - itemId
     - itemName
     - itemType
     - isCustom
     - stage
     - status
     - createdAt
     - updatedAt
     - isDeleted
     - description
     - isRequired
     - priorityOrder
     - documentId
     - documentStatus
     - documentIsPacket
     - documentComment
     - purposeType
     - originalItemId
     - dmsListingId
     - dmsTransactionId
     - notesCount
     - notesResolved
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'checklistType', None, None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
        (3, TType.STRING, 'itemName', 'UTF8', None, ),  # 3
        (4, TType.I32, 'itemType', None, None, ),  # 4
        (5, TType.BOOL, 'isCustom', None, None, ),  # 5
        (6, TType.I32, 'stage', None, None, ),  # 6
        (7, TType.I32, 'status', None, None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.BOOL, 'isDeleted', None, None, ),  # 10
        (11, TType.STRING, 'description', 'UTF8', None, ),  # 11
        (12, TType.BOOL, 'isRequired', None, None, ),  # 12
        (13, TType.I32, 'priorityOrder', None, None, ),  # 13
        (14, TType.STRING, 'documentId', 'UTF8', None, ),  # 14
        (15, TType.I32, 'documentStatus', None, None, ),  # 15
        (16, TType.BOOL, 'documentIsPacket', None, None, ),  # 16
        (17, TType.STRING, 'documentComment', 'UTF8', None, ),  # 17
        (18, TType.I32, 'purposeType', None, None, ),  # 18
        (19, TType.I32, 'originalItemId', None, None, ),  # 19
        (20, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 21
        (22, TType.I32, 'notesCount', None, None, ),  # 22
        (23, TType.BOOL, 'notesResolved', None, None, ),  # 23
    )
    def __init__(self, checklistType=None, itemId=None, itemName=None, itemType=None, isCustom=None, stage=None, status=None, createdAt=None, updatedAt=None, isDeleted=None, description=None, isRequired=None, priorityOrder=None, documentId=None, documentStatus=None, documentIsPacket=None, documentComment=None, purposeType=None, originalItemId=None, dmsListingId=None, dmsTransactionId=None, notesCount=None, notesResolved=None, ):
        self.checklistType = checklistType
        self.itemId = itemId
        self.itemName = itemName
        self.itemType = itemType
        self.isCustom = isCustom
        self.stage = stage
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.isDeleted = isDeleted
        self.description = description
        self.isRequired = isRequired
        self.priorityOrder = priorityOrder
        self.documentId = documentId
        self.documentStatus = documentStatus
        self.documentIsPacket = documentIsPacket
        self.documentComment = documentComment
        self.purposeType = purposeType
        self.originalItemId = originalItemId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.notesCount = notesCount
        self.notesResolved = notesResolved

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.itemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.itemType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isCustom = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.priorityOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.documentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.documentIsPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.documentComment = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.originalItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I32:
                    self.notesCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.notesResolved = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsWithdrawnCanceledChecklistItem')
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 1)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.itemName is not None:
            oprot.writeFieldBegin('itemName', TType.STRING, 3)
            oprot.writeString(self.itemName.encode('utf-8') if sys.version_info[0] == 2 else self.itemName)
            oprot.writeFieldEnd()
        if self.itemType is not None:
            oprot.writeFieldBegin('itemType', TType.I32, 4)
            oprot.writeI32(self.itemType)
            oprot.writeFieldEnd()
        if self.isCustom is not None:
            oprot.writeFieldBegin('isCustom', TType.BOOL, 5)
            oprot.writeBool(self.isCustom)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 6)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 7)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 10)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 11)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 12)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.priorityOrder is not None:
            oprot.writeFieldBegin('priorityOrder', TType.I32, 13)
            oprot.writeI32(self.priorityOrder)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 14)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.documentStatus is not None:
            oprot.writeFieldBegin('documentStatus', TType.I32, 15)
            oprot.writeI32(self.documentStatus)
            oprot.writeFieldEnd()
        if self.documentIsPacket is not None:
            oprot.writeFieldBegin('documentIsPacket', TType.BOOL, 16)
            oprot.writeBool(self.documentIsPacket)
            oprot.writeFieldEnd()
        if self.documentComment is not None:
            oprot.writeFieldBegin('documentComment', TType.STRING, 17)
            oprot.writeString(self.documentComment.encode('utf-8') if sys.version_info[0] == 2 else self.documentComment)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 18)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.originalItemId is not None:
            oprot.writeFieldBegin('originalItemId', TType.I32, 19)
            oprot.writeI32(self.originalItemId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 20)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 21)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.notesCount is not None:
            oprot.writeFieldBegin('notesCount', TType.I32, 22)
            oprot.writeI32(self.notesCount)
            oprot.writeFieldEnd()
        if self.notesResolved is not None:
            oprot.writeFieldBegin('notesResolved', TType.BOOL, 23)
            oprot.writeBool(self.notesResolved)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindTeamDmsFoldersMatchingLocationParams(object):
    """
    Attributes:
     - teamId
     - sideRepresentation
     - zipCode
     - address
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'sideRepresentation', None, None, ),  # 2
        (3, TType.STRING, 'zipCode', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'address', 'UTF8', None, ),  # 4
    )
    def __init__(self, teamId=None, sideRepresentation=None, zipCode=None, address=None, ):
        self.teamId = teamId
        self.sideRepresentation = sideRepresentation
        self.zipCode = zipCode
        self.address = address

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.sideRepresentation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindTeamDmsFoldersMatchingLocationParams')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.sideRepresentation is not None:
            oprot.writeFieldBegin('sideRepresentation', TType.I32, 2)
            oprot.writeI32(self.sideRepresentation)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 3)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 4)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SubmittedCount(object):
    """
    Attributes:
     - numSubmitted
     - numRequired
     - numCompleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'numSubmitted', None, None, ),  # 1
        (2, TType.I32, 'numRequired', None, None, ),  # 2
        (3, TType.I32, 'numCompleted', None, None, ),  # 3
    )
    def __init__(self, numSubmitted=None, numRequired=None, numCompleted=None, ):
        self.numSubmitted = numSubmitted
        self.numRequired = numRequired
        self.numCompleted = numCompleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.numSubmitted = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.numRequired = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.numCompleted = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SubmittedCount')
        if self.numSubmitted is not None:
            oprot.writeFieldBegin('numSubmitted', TType.I32, 1)
            oprot.writeI32(self.numSubmitted)
            oprot.writeFieldEnd()
        if self.numRequired is not None:
            oprot.writeFieldBegin('numRequired', TType.I32, 2)
            oprot.writeI32(self.numRequired)
            oprot.writeFieldEnd()
        if self.numCompleted is not None:
            oprot.writeFieldBegin('numCompleted', TType.I32, 3)
            oprot.writeI32(self.numCompleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UserCapabilities(object):
    """
    Attributes:
     - userId
     - capabilities
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.SET, 'capabilities', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, userId=None, capabilities=None, ):
        self.userId = userId
        self.capabilities = capabilities

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.SET:
                    self.capabilities = set()
                    (_etype23, _size25) = iprot.readSetBegin()
                    for _i22 in range(_size25):
                        _elem24 = iprot.readI32()
                        self.capabilities.add(_elem24)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UserCapabilities')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.capabilities is not None:
            oprot.writeFieldBegin('capabilities', TType.SET, 2)
            oprot.writeSetBegin(TType.I32, len(self.capabilities))
            for _iter26 in self.capabilities:
                oprot.writeI32(_iter26)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsAgentLogInfo(object):
    """
    Attributes:
     - removedDmsAgentList
     - addedDmsAgentList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'removedDmsAgentList', (TType.STRUCT, (DmsAgent, DmsAgent.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'addedDmsAgentList', (TType.STRUCT, (DmsAgent, DmsAgent.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, removedDmsAgentList=None, addedDmsAgentList=None, ):
        self.removedDmsAgentList = removedDmsAgentList
        self.addedDmsAgentList = addedDmsAgentList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.removedDmsAgentList = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = DmsAgent()
                        _elem29.read(iprot)
                        self.removedDmsAgentList.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.addedDmsAgentList = []
                    (_etype31, _size34) = iprot.readListBegin()
                    for _i32 in range(_size34):
                        _elem33 = DmsAgent()
                        _elem33.read(iprot)
                        self.addedDmsAgentList.append(_elem33)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsAgentLogInfo')
        if self.removedDmsAgentList is not None:
            oprot.writeFieldBegin('removedDmsAgentList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.removedDmsAgentList))
            for _iter35 in self.removedDmsAgentList:
                _iter35.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.addedDmsAgentList is not None:
            oprot.writeFieldBegin('addedDmsAgentList', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.addedDmsAgentList))
            for _iter36 in self.addedDmsAgentList:
                _iter36.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsClientLogInfo(object):
    """
    Attributes:
     - removedDmsClientList
     - addedDmsClientList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'removedDmsClientList', (TType.STRUCT, (DmsContact, DmsContact.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'addedDmsClientList', (TType.STRUCT, (DmsContact, DmsContact.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, removedDmsClientList=None, addedDmsClientList=None, ):
        self.removedDmsClientList = removedDmsClientList
        self.addedDmsClientList = addedDmsClientList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.removedDmsClientList = []
                    (_etype37, _size40) = iprot.readListBegin()
                    for _i38 in range(_size40):
                        _elem39 = DmsContact()
                        _elem39.read(iprot)
                        self.removedDmsClientList.append(_elem39)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.addedDmsClientList = []
                    (_etype41, _size44) = iprot.readListBegin()
                    for _i42 in range(_size44):
                        _elem43 = DmsContact()
                        _elem43.read(iprot)
                        self.addedDmsClientList.append(_elem43)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsClientLogInfo')
        if self.removedDmsClientList is not None:
            oprot.writeFieldBegin('removedDmsClientList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.removedDmsClientList))
            for _iter45 in self.removedDmsClientList:
                _iter45.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.addedDmsClientList is not None:
            oprot.writeFieldBegin('addedDmsClientList', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.addedDmsClientList))
            for _iter46 in self.addedDmsClientList:
                _iter46.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderChecklistItem(object):
    """
    Attributes:
     - name
     - state
     - itemType
     - submittedCount
     - stage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.I32, 'state', None, None, ),  # 2
        (3, TType.I32, 'itemType', None, None, ),  # 3
        (4, TType.STRUCT, 'submittedCount', (SubmittedCount, SubmittedCount.thrift_spec), None, ),  # 4
        (5, TType.I32, 'stage', None, None, ),  # 5
    )
    def __init__(self, name=None, state=None, itemType=None, submittedCount=None, stage=None, ):
        self.name = name
        self.state = state
        self.itemType = itemType
        self.submittedCount = submittedCount
        self.stage = stage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.state = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.itemType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.submittedCount = SubmittedCount()
                    self.submittedCount.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderChecklistItem')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.I32, 2)
            oprot.writeI32(self.state)
            oprot.writeFieldEnd()
        if self.itemType is not None:
            oprot.writeFieldBegin('itemType', TType.I32, 3)
            oprot.writeI32(self.itemType)
            oprot.writeFieldEnd()
        if self.submittedCount is not None:
            oprot.writeFieldBegin('submittedCount', TType.STRUCT, 4)
            self.submittedCount.write(oprot)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 5)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingChecklistItem(object):
    """
    Attributes:
     - dmsListingId
     - checklistType
     - itemId
     - itemName
     - itemType
     - isCustom
     - listingStage
     - status
     - createdAt
     - updatedAt
     - description
     - isRequired
     - priorityOrder
     - documentId
     - documentStatus
     - originalItemId
     - documentIsPacket
     - documentComment
     - purposeType
     - isDeleted
     - notes
     - notesCount
     - notesResolved
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistType', None, None, ),  # 2
        (3, TType.I32, 'itemId', None, None, ),  # 3
        (4, TType.STRING, 'itemName', 'UTF8', None, ),  # 4
        (5, TType.I32, 'itemType', None, None, ),  # 5
        (6, TType.BOOL, 'isCustom', None, None, ),  # 6
        (7, TType.I32, 'listingStage', None, None, ),  # 7
        (8, TType.I32, 'status', None, None, ),  # 8
        (9, TType.I64, 'createdAt', None, None, ),  # 9
        (10, TType.I64, 'updatedAt', None, None, ),  # 10
        (11, TType.STRING, 'description', 'UTF8', None, ),  # 11
        (12, TType.BOOL, 'isRequired', None, None, ),  # 12
        (13, TType.I32, 'priorityOrder', None, None, ),  # 13
        (14, TType.STRING, 'documentId', 'UTF8', None, ),  # 14
        (15, TType.I32, 'documentStatus', None, None, ),  # 15
        (16, TType.I32, 'originalItemId', None, None, ),  # 16
        (17, TType.BOOL, 'documentIsPacket', None, None, ),  # 17
        (18, TType.STRING, 'documentComment', 'UTF8', None, ),  # 18
        (19, TType.I32, 'purposeType', None, None, ),  # 19
        (20, TType.BOOL, 'isDeleted', None, None, ),  # 20
        (21, TType.LIST, 'notes', (TType.STRUCT, (DmsListingChecklistItemNote, DmsListingChecklistItemNote.thrift_spec), False), None, ),  # 21
        (22, TType.I32, 'notesCount', None, None, ),  # 22
        (23, TType.BOOL, 'notesResolved', None, None, ),  # 23
    )
    def __init__(self, dmsListingId=None, checklistType=None, itemId=None, itemName=None, itemType=None, isCustom=None, listingStage=None, status=None, createdAt=None, updatedAt=None, description=None, isRequired=None, priorityOrder=None, documentId=None, documentStatus=None, originalItemId=None, documentIsPacket=None, documentComment=None, purposeType=None, isDeleted=None, notes=None, notesCount=None, notesResolved=None, ):
        self.dmsListingId = dmsListingId
        self.checklistType = checklistType
        self.itemId = itemId
        self.itemName = itemName
        self.itemType = itemType
        self.isCustom = isCustom
        self.listingStage = listingStage
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.description = description
        self.isRequired = isRequired
        self.priorityOrder = priorityOrder
        self.documentId = documentId
        self.documentStatus = documentStatus
        self.originalItemId = originalItemId
        self.documentIsPacket = documentIsPacket
        self.documentComment = documentComment
        self.purposeType = purposeType
        self.isDeleted = isDeleted
        self.notes = notes
        self.notesCount = notesCount
        self.notesResolved = notesResolved

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.itemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.itemType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isCustom = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.listingStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.priorityOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.documentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.originalItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.documentIsPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.documentComment = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.notes = []
                    (_etype47, _size50) = iprot.readListBegin()
                    for _i48 in range(_size50):
                        _elem49 = DmsListingChecklistItemNote()
                        _elem49.read(iprot)
                        self.notes.append(_elem49)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I32:
                    self.notesCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.notesResolved = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingChecklistItem')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 2)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 3)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.itemName is not None:
            oprot.writeFieldBegin('itemName', TType.STRING, 4)
            oprot.writeString(self.itemName.encode('utf-8') if sys.version_info[0] == 2 else self.itemName)
            oprot.writeFieldEnd()
        if self.itemType is not None:
            oprot.writeFieldBegin('itemType', TType.I32, 5)
            oprot.writeI32(self.itemType)
            oprot.writeFieldEnd()
        if self.isCustom is not None:
            oprot.writeFieldBegin('isCustom', TType.BOOL, 6)
            oprot.writeBool(self.isCustom)
            oprot.writeFieldEnd()
        if self.listingStage is not None:
            oprot.writeFieldBegin('listingStage', TType.I32, 7)
            oprot.writeI32(self.listingStage)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 8)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 9)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 10)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 11)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 12)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.priorityOrder is not None:
            oprot.writeFieldBegin('priorityOrder', TType.I32, 13)
            oprot.writeI32(self.priorityOrder)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 14)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.documentStatus is not None:
            oprot.writeFieldBegin('documentStatus', TType.I32, 15)
            oprot.writeI32(self.documentStatus)
            oprot.writeFieldEnd()
        if self.originalItemId is not None:
            oprot.writeFieldBegin('originalItemId', TType.I32, 16)
            oprot.writeI32(self.originalItemId)
            oprot.writeFieldEnd()
        if self.documentIsPacket is not None:
            oprot.writeFieldBegin('documentIsPacket', TType.BOOL, 17)
            oprot.writeBool(self.documentIsPacket)
            oprot.writeFieldEnd()
        if self.documentComment is not None:
            oprot.writeFieldBegin('documentComment', TType.STRING, 18)
            oprot.writeString(self.documentComment.encode('utf-8') if sys.version_info[0] == 2 else self.documentComment)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 19)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 20)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.LIST, 21)
            oprot.writeListBegin(TType.STRUCT, len(self.notes))
            for _iter51 in self.notes:
                _iter51.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notesCount is not None:
            oprot.writeFieldBegin('notesCount', TType.I32, 22)
            oprot.writeI32(self.notesCount)
            oprot.writeFieldEnd()
        if self.notesResolved is not None:
            oprot.writeFieldBegin('notesResolved', TType.BOOL, 23)
            oprot.writeBool(self.notesResolved)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionChecklistItem(object):
    """
    Attributes:
     - dmsTransactionId
     - checklistType
     - itemId
     - itemName
     - itemType
     - isCustom
     - transactionStage
     - status
     - createdAt
     - updatedAt
     - description
     - isRequired
     - priorityOrder
     - documentId
     - documentStatus
     - originalItemId
     - documentIsPacket
     - documentComment
     - purposeType
     - isDeleted
     - notes
     - notesCount
     - notesResolved
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistType', None, None, ),  # 2
        (3, TType.I32, 'itemId', None, None, ),  # 3
        (4, TType.STRING, 'itemName', 'UTF8', None, ),  # 4
        (5, TType.I32, 'itemType', None, None, ),  # 5
        (6, TType.BOOL, 'isCustom', None, None, ),  # 6
        (7, TType.I32, 'transactionStage', None, None, ),  # 7
        (8, TType.I32, 'status', None, None, ),  # 8
        (9, TType.I64, 'createdAt', None, None, ),  # 9
        (10, TType.I64, 'updatedAt', None, None, ),  # 10
        (11, TType.STRING, 'description', 'UTF8', None, ),  # 11
        (12, TType.BOOL, 'isRequired', None, None, ),  # 12
        (13, TType.I32, 'priorityOrder', None, None, ),  # 13
        (14, TType.STRING, 'documentId', 'UTF8', None, ),  # 14
        (15, TType.I32, 'documentStatus', None, None, ),  # 15
        (16, TType.I32, 'originalItemId', None, None, ),  # 16
        (17, TType.BOOL, 'documentIsPacket', None, None, ),  # 17
        (18, TType.STRING, 'documentComment', 'UTF8', None, ),  # 18
        (19, TType.I32, 'purposeType', None, None, ),  # 19
        (20, TType.BOOL, 'isDeleted', None, None, ),  # 20
        (21, TType.LIST, 'notes', (TType.STRUCT, (DmsTransactionChecklistItemNote, DmsTransactionChecklistItemNote.thrift_spec), False), None, ),  # 21
        (22, TType.I32, 'notesCount', None, None, ),  # 22
        (23, TType.BOOL, 'notesResolved', None, None, ),  # 23
    )
    def __init__(self, dmsTransactionId=None, checklistType=None, itemId=None, itemName=None, itemType=None, isCustom=None, transactionStage=None, status=None, createdAt=None, updatedAt=None, description=None, isRequired=None, priorityOrder=None, documentId=None, documentStatus=None, originalItemId=None, documentIsPacket=None, documentComment=None, purposeType=None, isDeleted=None, notes=None, notesCount=None, notesResolved=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.checklistType = checklistType
        self.itemId = itemId
        self.itemName = itemName
        self.itemType = itemType
        self.isCustom = isCustom
        self.transactionStage = transactionStage
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.description = description
        self.isRequired = isRequired
        self.priorityOrder = priorityOrder
        self.documentId = documentId
        self.documentStatus = documentStatus
        self.originalItemId = originalItemId
        self.documentIsPacket = documentIsPacket
        self.documentComment = documentComment
        self.purposeType = purposeType
        self.isDeleted = isDeleted
        self.notes = notes
        self.notesCount = notesCount
        self.notesResolved = notesResolved

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.itemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.itemType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isCustom = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.transactionStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.priorityOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.documentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.originalItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.documentIsPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.documentComment = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.notes = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = DmsTransactionChecklistItemNote()
                        _elem54.read(iprot)
                        self.notes.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I32:
                    self.notesCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.notesResolved = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionChecklistItem')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 2)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 3)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.itemName is not None:
            oprot.writeFieldBegin('itemName', TType.STRING, 4)
            oprot.writeString(self.itemName.encode('utf-8') if sys.version_info[0] == 2 else self.itemName)
            oprot.writeFieldEnd()
        if self.itemType is not None:
            oprot.writeFieldBegin('itemType', TType.I32, 5)
            oprot.writeI32(self.itemType)
            oprot.writeFieldEnd()
        if self.isCustom is not None:
            oprot.writeFieldBegin('isCustom', TType.BOOL, 6)
            oprot.writeBool(self.isCustom)
            oprot.writeFieldEnd()
        if self.transactionStage is not None:
            oprot.writeFieldBegin('transactionStage', TType.I32, 7)
            oprot.writeI32(self.transactionStage)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 8)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 9)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 10)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 11)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 12)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.priorityOrder is not None:
            oprot.writeFieldBegin('priorityOrder', TType.I32, 13)
            oprot.writeI32(self.priorityOrder)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 14)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.documentStatus is not None:
            oprot.writeFieldBegin('documentStatus', TType.I32, 15)
            oprot.writeI32(self.documentStatus)
            oprot.writeFieldEnd()
        if self.originalItemId is not None:
            oprot.writeFieldBegin('originalItemId', TType.I32, 16)
            oprot.writeI32(self.originalItemId)
            oprot.writeFieldEnd()
        if self.documentIsPacket is not None:
            oprot.writeFieldBegin('documentIsPacket', TType.BOOL, 17)
            oprot.writeBool(self.documentIsPacket)
            oprot.writeFieldEnd()
        if self.documentComment is not None:
            oprot.writeFieldBegin('documentComment', TType.STRING, 18)
            oprot.writeString(self.documentComment.encode('utf-8') if sys.version_info[0] == 2 else self.documentComment)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 19)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 20)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.LIST, 21)
            oprot.writeListBegin(TType.STRUCT, len(self.notes))
            for _iter56 in self.notes:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notesCount is not None:
            oprot.writeFieldBegin('notesCount', TType.I32, 22)
            oprot.writeI32(self.notesCount)
            oprot.writeFieldEnd()
        if self.notesResolved is not None:
            oprot.writeFieldBegin('notesResolved', TType.BOOL, 23)
            oprot.writeBool(self.notesResolved)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsChecklists(object):
    """
    Attributes:
     - checklistType
     - dmsListingChecklist
     - dmsTransactionChecklist
     - dmsClosedChecklist
     - dmsWithdrawnCanceledChecklist
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'checklistType', None, None, ),  # 1
        (2, TType.LIST, 'dmsListingChecklist', (TType.STRUCT, (DmsListingChecklistItem, DmsListingChecklistItem.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'dmsTransactionChecklist', (TType.STRUCT, (DmsTransactionChecklistItem, DmsTransactionChecklistItem.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'dmsClosedChecklist', (TType.STRUCT, (DmsTransactionChecklistItem, DmsTransactionChecklistItem.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'dmsWithdrawnCanceledChecklist', (TType.STRUCT, (DmsWithdrawnCanceledChecklistItem, DmsWithdrawnCanceledChecklistItem.thrift_spec), False), None, ),  # 5
    )
    def __init__(self, checklistType=None, dmsListingChecklist=None, dmsTransactionChecklist=None, dmsClosedChecklist=None, dmsWithdrawnCanceledChecklist=None, ):
        self.checklistType = checklistType
        self.dmsListingChecklist = dmsListingChecklist
        self.dmsTransactionChecklist = dmsTransactionChecklist
        self.dmsClosedChecklist = dmsClosedChecklist
        self.dmsWithdrawnCanceledChecklist = dmsWithdrawnCanceledChecklist

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsListingChecklist = []
                    (_etype57, _size60) = iprot.readListBegin()
                    for _i58 in range(_size60):
                        _elem59 = DmsListingChecklistItem()
                        _elem59.read(iprot)
                        self.dmsListingChecklist.append(_elem59)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.dmsTransactionChecklist = []
                    (_etype61, _size64) = iprot.readListBegin()
                    for _i62 in range(_size64):
                        _elem63 = DmsTransactionChecklistItem()
                        _elem63.read(iprot)
                        self.dmsTransactionChecklist.append(_elem63)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsClosedChecklist = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = DmsTransactionChecklistItem()
                        _elem67.read(iprot)
                        self.dmsClosedChecklist.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dmsWithdrawnCanceledChecklist = []
                    (_etype69, _size72) = iprot.readListBegin()
                    for _i70 in range(_size72):
                        _elem71 = DmsWithdrawnCanceledChecklistItem()
                        _elem71.read(iprot)
                        self.dmsWithdrawnCanceledChecklist.append(_elem71)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsChecklists')
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 1)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.dmsListingChecklist is not None:
            oprot.writeFieldBegin('dmsListingChecklist', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsListingChecklist))
            for _iter73 in self.dmsListingChecklist:
                _iter73.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsTransactionChecklist is not None:
            oprot.writeFieldBegin('dmsTransactionChecklist', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsTransactionChecklist))
            for _iter74 in self.dmsTransactionChecklist:
                _iter74.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsClosedChecklist is not None:
            oprot.writeFieldBegin('dmsClosedChecklist', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsClosedChecklist))
            for _iter75 in self.dmsClosedChecklist:
                _iter75.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsWithdrawnCanceledChecklist is not None:
            oprot.writeFieldBegin('dmsWithdrawnCanceledChecklist', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsWithdrawnCanceledChecklist))
            for _iter76 in self.dmsWithdrawnCanceledChecklist:
                _iter76.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListing(object):
    """
    Attributes:
     - id
     - dmsFolderId
     - dealListingId
     - createdBy
     - team
     - createdAt
     - updatedAt
     - currentStage
     - currentSubStage
     - checklist
     - isDeleted
     - listDate
     - commissionRate
     - otherSideCommissionRate
     - commissionRateAmount
     - otherSideCommissionRateAmount
     - submitStatus
     - isHousingVoucher
     - market
     - isNewConstruction
     - propertyType
     - listingType
     - yearBuilt
     - propertyAddress
     - city
     - state
     - zipcode
     - listPrice
     - usedConcierge
     - mediaUrl
     - unit
     - expirationDate
     - yearlyRent
     - hasListingId
     - salesTransactionType
     - rentalTransactionType
     - expiresIn
     - reasonForWithdrawal
     - initialCompletedAt
     - mlsId
     - primaryDualRepDmsListingId
     - isFullServiceRental
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'createdBy', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'team', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
        (8, TType.I32, 'propertyType', None, None, ),  # 8
        (9, TType.I32, 'listingType', None, None, ),  # 9
        (10, TType.I32, 'currentStage', None, None, ),  # 10
        (11, TType.I32, 'currentSubStage', None, None, ),  # 11
        (12, TType.LIST, 'checklist', (TType.STRUCT, (DmsListingChecklistItem, DmsListingChecklistItem.thrift_spec), False), None, ),  # 12
        (13, TType.BOOL, 'isDeleted', None, None, ),  # 13
        (14, TType.I32, 'yearBuilt', None, None, ),  # 14
        (15, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'city', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'state', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'zipcode', 'UTF8', None, ),  # 18
        (19, TType.DOUBLE, 'listPrice', None, None, ),  # 19
        (20, TType.I32, 'salesTransactionType', None, None, ),  # 20
        (21, TType.I32, 'rentalTransactionType', None, None, ),  # 21
        (22, TType.BOOL, 'usedConcierge', None, None, ),  # 22
        (23, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'unit', 'UTF8', None, ),  # 24
        (25, TType.I64, 'expirationDate', None, None, ),  # 25
        (26, TType.DOUBLE, 'yearlyRent', None, None, ),  # 26
        (27, TType.BOOL, 'hasListingId', None, None, ),  # 27
        (28, TType.STRING, 'market', 'UTF8', None, ),  # 28
        (29, TType.BOOL, 'isNewConstruction', None, None, ),  # 29
        (30, TType.I64, 'listDate', None, None, ),  # 30
        (31, TType.I32, 'expiresIn', None, None, ),  # 31
        (32, TType.STRING, 'reasonForWithdrawal', 'UTF8', None, ),  # 32
        (33, TType.I64, 'initialCompletedAt', None, None, ),  # 33
        (34, TType.STRING, 'mlsId', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'primaryDualRepDmsListingId', 'UTF8', None, ),  # 35
        (36, TType.DOUBLE, 'commissionRate', None, None, ),  # 36
        (37, TType.DOUBLE, 'otherSideCommissionRate', None, None, ),  # 37
        (38, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 38
        (39, TType.DOUBLE, 'otherSideCommissionRateAmount', None, None, ),  # 39
        (40, TType.I32, 'submitStatus', None, None, ),  # 40
        (41, TType.BOOL, 'isFullServiceRental', None, None, ),  # 41
        (42, TType.BOOL, 'isHousingVoucher', None, None, ),  # 42
    )
    def __init__(self, id=None, dmsFolderId=None, dealListingId=None, createdBy=None, team=None, createdAt=None, updatedAt=None, propertyType=None, listingType=None, currentStage=None, currentSubStage=None, checklist=None, isDeleted=None, yearBuilt=None, propertyAddress=None, city=None, state=None, zipcode=None, listPrice=None, salesTransactionType=None, rentalTransactionType=None, usedConcierge=None, mediaUrl=None, unit=None, expirationDate=None, yearlyRent=None, hasListingId=None, market=None, isNewConstruction=None, listDate=None, expiresIn=None, reasonForWithdrawal=None, initialCompletedAt=None, mlsId=None, primaryDualRepDmsListingId=None, commissionRate=None, otherSideCommissionRate=None, commissionRateAmount=None, otherSideCommissionRateAmount=None, submitStatus=None, isFullServiceRental=None, isHousingVoucher=None, ):
        self.id = id
        self.dmsFolderId = dmsFolderId
        self.dealListingId = dealListingId
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.propertyType = propertyType
        self.listingType = listingType
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.checklist = checklist
        self.isDeleted = isDeleted
        self.yearBuilt = yearBuilt
        self.propertyAddress = propertyAddress
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.salesTransactionType = salesTransactionType
        self.rentalTransactionType = rentalTransactionType
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.unit = unit
        self.expirationDate = expirationDate
        self.yearlyRent = yearlyRent
        self.hasListingId = hasListingId
        self.market = market
        self.isNewConstruction = isNewConstruction
        self.listDate = listDate
        self.expiresIn = expiresIn
        self.reasonForWithdrawal = reasonForWithdrawal
        self.initialCompletedAt = initialCompletedAt
        self.mlsId = mlsId
        self.primaryDualRepDmsListingId = primaryDualRepDmsListingId
        self.commissionRate = commissionRate
        self.otherSideCommissionRate = otherSideCommissionRate
        self.commissionRateAmount = commissionRateAmount
        self.otherSideCommissionRateAmount = otherSideCommissionRateAmount
        self.submitStatus = submitStatus
        self.isFullServiceRental = isFullServiceRental
        self.isHousingVoucher = isHousingVoucher

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype77, _size80) = iprot.readListBegin()
                    for _i78 in range(_size80):
                        _elem79 = DmsListingChecklistItem()
                        _elem79.read(iprot)
                        self.checklist.append(_elem79)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.salesTransactionType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I32:
                    self.rentalTransactionType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I64:
                    self.expirationDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.DOUBLE:
                    self.yearlyRent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.BOOL:
                    self.hasListingId = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.reasonForWithdrawal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I64:
                    self.initialCompletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.primaryDualRepDmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.BOOL:
                    self.isFullServiceRental = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.BOOL:
                    self.isHousingVoucher = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListing')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 3)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 4)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 5)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 8)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 9)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 10)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 11)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter81 in self.checklist:
                _iter81.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 13)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 14)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 15)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 16)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 17)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 18)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 19)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.salesTransactionType is not None:
            oprot.writeFieldBegin('salesTransactionType', TType.I32, 20)
            oprot.writeI32(self.salesTransactionType)
            oprot.writeFieldEnd()
        if self.rentalTransactionType is not None:
            oprot.writeFieldBegin('rentalTransactionType', TType.I32, 21)
            oprot.writeI32(self.rentalTransactionType)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 22)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 23)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 24)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.I64, 25)
            oprot.writeI64(self.expirationDate)
            oprot.writeFieldEnd()
        if self.yearlyRent is not None:
            oprot.writeFieldBegin('yearlyRent', TType.DOUBLE, 26)
            oprot.writeDouble(self.yearlyRent)
            oprot.writeFieldEnd()
        if self.hasListingId is not None:
            oprot.writeFieldBegin('hasListingId', TType.BOOL, 27)
            oprot.writeBool(self.hasListingId)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 28)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 29)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 30)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 31)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.reasonForWithdrawal is not None:
            oprot.writeFieldBegin('reasonForWithdrawal', TType.STRING, 32)
            oprot.writeString(self.reasonForWithdrawal.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForWithdrawal)
            oprot.writeFieldEnd()
        if self.initialCompletedAt is not None:
            oprot.writeFieldBegin('initialCompletedAt', TType.I64, 33)
            oprot.writeI64(self.initialCompletedAt)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 34)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.primaryDualRepDmsListingId is not None:
            oprot.writeFieldBegin('primaryDualRepDmsListingId', TType.STRING, 35)
            oprot.writeString(self.primaryDualRepDmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDualRepDmsListingId)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 36)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.DOUBLE, 37)
            oprot.writeDouble(self.otherSideCommissionRate)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 38)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmount is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmount', TType.DOUBLE, 39)
            oprot.writeDouble(self.otherSideCommissionRateAmount)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 40)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        if self.isFullServiceRental is not None:
            oprot.writeFieldBegin('isFullServiceRental', TType.BOOL, 41)
            oprot.writeBool(self.isFullServiceRental)
            oprot.writeFieldEnd()
        if self.isHousingVoucher is not None:
            oprot.writeFieldBegin('isHousingVoucher', TType.BOOL, 42)
            oprot.writeBool(self.isHousingVoucher)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransaction(object):
    """
    Attributes:
     - id
     - dmsListingId
     - createdBy
     - team
     - createdAt
     - updatedAt
     - currentStage
     - currentSubStage
     - isDeleted
     - closingId
     - checklist
     - closeDate
     - acceptanceDate
     - commissionRate
     - closePrice
     - commissionRateAmount
     - dealType
     - primaryTransactionId
     - otherSideCommissionRate
     - otherSideCommissionRateAmount
     - reasonForCancellation
     - initialCompletedAt
     - ctcServiceType
     - primaryDualRepDmsTransactionId
     - paymentStatus
     - submitStatus
     - syntheticEntity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'createdBy', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'team', 'UTF8', None, ),  # 4
        (5, TType.I64, 'createdAt', None, None, ),  # 5
        (6, TType.I64, 'updatedAt', None, None, ),  # 6
        (7, TType.I32, 'currentStage', None, None, ),  # 7
        (8, TType.I32, 'currentSubStage', None, None, ),  # 8
        (9, TType.BOOL, 'isDeleted', None, None, ),  # 9
        (10, TType.I64, 'closingId', None, None, ),  # 10
        (11, TType.LIST, 'checklist', (TType.STRUCT, (DmsTransactionChecklistItem, DmsTransactionChecklistItem.thrift_spec), False), None, ),  # 11
        (12, TType.I64, 'closeDate', None, None, ),  # 12
        (13, TType.I64, 'acceptanceDate', None, None, ),  # 13
        (14, TType.DOUBLE, 'commissionRate', None, None, ),  # 14
        (15, TType.DOUBLE, 'closePrice', None, None, ),  # 15
        (16, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 16
        (17, TType.I32, 'dealType', None, None, ),  # 17
        (18, TType.STRING, 'primaryTransactionId', 'UTF8', None, ),  # 18
        (19, TType.DOUBLE, 'otherSideCommissionRate', None, None, ),  # 19
        (20, TType.DOUBLE, 'otherSideCommissionRateAmount', None, None, ),  # 20
        (21, TType.STRING, 'reasonForCancellation', 'UTF8', None, ),  # 21
        (22, TType.I64, 'initialCompletedAt', None, None, ),  # 22
        (23, TType.I32, 'ctcServiceType', None, None, ),  # 23
        (24, TType.STRING, 'primaryDualRepDmsTransactionId', 'UTF8', None, ),  # 24
        (25, TType.I32, 'paymentStatus', None, None, ),  # 25
        (26, TType.I32, 'submitStatus', None, None, ),  # 26
        (27, TType.I32, 'syntheticEntity', None, None, ),  # 27
    )
    def __init__(self, id=None, dmsListingId=None, createdBy=None, team=None, createdAt=None, updatedAt=None, currentStage=None, currentSubStage=None, isDeleted=None, closingId=None, checklist=None, closeDate=None, acceptanceDate=None, commissionRate=None, closePrice=None, commissionRateAmount=None, dealType=None, primaryTransactionId=None, otherSideCommissionRate=None, otherSideCommissionRateAmount=None, reasonForCancellation=None, initialCompletedAt=None, ctcServiceType=None, primaryDualRepDmsTransactionId=None, paymentStatus=None, submitStatus=None, syntheticEntity=None, ):
        self.id = id
        self.dmsListingId = dmsListingId
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.isDeleted = isDeleted
        self.closingId = closingId
        self.checklist = checklist
        self.closeDate = closeDate
        self.acceptanceDate = acceptanceDate
        self.commissionRate = commissionRate
        self.closePrice = closePrice
        self.commissionRateAmount = commissionRateAmount
        self.dealType = dealType
        self.primaryTransactionId = primaryTransactionId
        self.otherSideCommissionRate = otherSideCommissionRate
        self.otherSideCommissionRateAmount = otherSideCommissionRateAmount
        self.reasonForCancellation = reasonForCancellation
        self.initialCompletedAt = initialCompletedAt
        self.ctcServiceType = ctcServiceType
        self.primaryDualRepDmsTransactionId = primaryDualRepDmsTransactionId
        self.paymentStatus = paymentStatus
        self.submitStatus = submitStatus
        self.syntheticEntity = syntheticEntity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.closingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype82, _size85) = iprot.readListBegin()
                    for _i83 in range(_size85):
                        _elem84 = DmsTransactionChecklistItem()
                        _elem84.read(iprot)
                        self.checklist.append(_elem84)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.acceptanceDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.primaryTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.reasonForCancellation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.initialCompletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.primaryDualRepDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.paymentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I32:
                    self.syntheticEntity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransaction')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 3)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 4)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 5)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 6)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 7)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 8)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 9)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.I64, 10)
            oprot.writeI64(self.closingId)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter86 in self.checklist:
                _iter86.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 12)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.I64, 13)
            oprot.writeI64(self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 14)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 15)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 16)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 17)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.primaryTransactionId is not None:
            oprot.writeFieldBegin('primaryTransactionId', TType.STRING, 18)
            oprot.writeString(self.primaryTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryTransactionId)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.DOUBLE, 19)
            oprot.writeDouble(self.otherSideCommissionRate)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmount is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmount', TType.DOUBLE, 20)
            oprot.writeDouble(self.otherSideCommissionRateAmount)
            oprot.writeFieldEnd()
        if self.reasonForCancellation is not None:
            oprot.writeFieldBegin('reasonForCancellation', TType.STRING, 21)
            oprot.writeString(self.reasonForCancellation.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForCancellation)
            oprot.writeFieldEnd()
        if self.initialCompletedAt is not None:
            oprot.writeFieldBegin('initialCompletedAt', TType.I64, 22)
            oprot.writeI64(self.initialCompletedAt)
            oprot.writeFieldEnd()
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 23)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        if self.primaryDualRepDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDualRepDmsTransactionId', TType.STRING, 24)
            oprot.writeString(self.primaryDualRepDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDualRepDmsTransactionId)
            oprot.writeFieldEnd()
        if self.paymentStatus is not None:
            oprot.writeFieldBegin('paymentStatus', TType.I32, 25)
            oprot.writeI32(self.paymentStatus)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 26)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        if self.syntheticEntity is not None:
            oprot.writeFieldBegin('syntheticEntity', TType.I32, 27)
            oprot.writeI32(self.syntheticEntity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AggregateDmsFolderData(object):
    """
    Attributes:
     - dmsFolder
     - dmsListing
     - dmsTransaction
     - lastUpdatedDate
     - lastReviewedDate
     - numDocumentsPending
     - documentSplitNeeded
     - numDocumentsNeeded
     - noteCount
     - unresolvedNotesCount
     - hasUnresolvedNotes
     - initialCompletedAt
     - dmsAgents
     - dmsListingUpdatedAt
     - dmsTransactionUpdatedAt
     - dmsWithdrawnCanceledChecklist
     - referredBy
     - referredTo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dmsFolder', (DmsFolder, DmsFolder.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsListing', (DmsListing, DmsListing.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'dmsTransaction', (DmsTransaction, DmsTransaction.thrift_spec), None, ),  # 3
        (4, TType.I64, 'lastUpdatedDate', None, None, ),  # 4
        (5, TType.I32, 'numDocumentsPending', None, None, ),  # 5
        (6, TType.BOOL, 'documentSplitNeeded', None, None, ),  # 6
        (7, TType.I32, 'numDocumentsNeeded', None, None, ),  # 7
        (8, TType.I64, 'initialCompletedAt', None, None, ),  # 8
        (9, TType.LIST, 'dmsAgents', (TType.STRUCT, (DmsAgent, DmsAgent.thrift_spec), False), None, ),  # 9
        (10, TType.STRUCT, 'dmsListingUpdatedAt', (DmsListingFieldsUpdatedAt, DmsListingFieldsUpdatedAt.thrift_spec), None, ),  # 10
        (11, TType.STRUCT, 'dmsTransactionUpdatedAt', (DmsTransactionFieldsUpdatedAt, DmsTransactionFieldsUpdatedAt.thrift_spec), None, ),  # 11
        (12, TType.LIST, 'dmsWithdrawnCanceledChecklist', (TType.STRUCT, (DmsWithdrawnCanceledChecklistItem, DmsWithdrawnCanceledChecklistItem.thrift_spec), False), None, ),  # 12
        (13, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 13
        (14, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 14
        (15, TType.I64, 'lastReviewedDate', None, None, ),  # 15
        (16, TType.I32, 'noteCount', None, None, ),  # 16
        (17, TType.BOOL, 'hasUnresolvedNotes', None, None, ),  # 17
        (18, TType.I32, 'unresolvedNotesCount', None, None, ),  # 18
    )
    def __init__(self, dmsFolder=None, dmsListing=None, dmsTransaction=None, lastUpdatedDate=None, numDocumentsPending=None, documentSplitNeeded=None, numDocumentsNeeded=None, initialCompletedAt=None, dmsAgents=None, dmsListingUpdatedAt=None, dmsTransactionUpdatedAt=None, dmsWithdrawnCanceledChecklist=None, referredBy=None, referredTo=None, lastReviewedDate=None, noteCount=None, hasUnresolvedNotes=None, unresolvedNotesCount=None, ):
        self.dmsFolder = dmsFolder
        self.dmsListing = dmsListing
        self.dmsTransaction = dmsTransaction
        self.lastUpdatedDate = lastUpdatedDate
        self.numDocumentsPending = numDocumentsPending
        self.documentSplitNeeded = documentSplitNeeded
        self.numDocumentsNeeded = numDocumentsNeeded
        self.initialCompletedAt = initialCompletedAt
        self.dmsAgents = dmsAgents
        self.dmsListingUpdatedAt = dmsListingUpdatedAt
        self.dmsTransactionUpdatedAt = dmsTransactionUpdatedAt
        self.dmsWithdrawnCanceledChecklist = dmsWithdrawnCanceledChecklist
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.lastReviewedDate = lastReviewedDate
        self.noteCount = noteCount
        self.hasUnresolvedNotes = hasUnresolvedNotes
        self.unresolvedNotesCount = unresolvedNotesCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dmsFolder = DmsFolder()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsListing = DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.lastUpdatedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.numDocumentsPending = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.documentSplitNeeded = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.numDocumentsNeeded = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.initialCompletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype87, _size90) = iprot.readListBegin()
                    for _i88 in range(_size90):
                        _elem89 = DmsAgent()
                        _elem89.read(iprot)
                        self.dmsAgents.append(_elem89)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.dmsListingUpdatedAt = DmsListingFieldsUpdatedAt()
                    self.dmsListingUpdatedAt.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.dmsTransactionUpdatedAt = DmsTransactionFieldsUpdatedAt()
                    self.dmsTransactionUpdatedAt.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.dmsWithdrawnCanceledChecklist = []
                    (_etype91, _size94) = iprot.readListBegin()
                    for _i92 in range(_size94):
                        _elem93 = DmsWithdrawnCanceledChecklistItem()
                        _elem93.read(iprot)
                        self.dmsWithdrawnCanceledChecklist.append(_elem93)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I64:
                    self.lastReviewedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.noteCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.hasUnresolvedNotes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.unresolvedNotesCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AggregateDmsFolderData')
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 1)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 2)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 3)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.lastUpdatedDate is not None:
            oprot.writeFieldBegin('lastUpdatedDate', TType.I64, 4)
            oprot.writeI64(self.lastUpdatedDate)
            oprot.writeFieldEnd()
        if self.numDocumentsPending is not None:
            oprot.writeFieldBegin('numDocumentsPending', TType.I32, 5)
            oprot.writeI32(self.numDocumentsPending)
            oprot.writeFieldEnd()
        if self.documentSplitNeeded is not None:
            oprot.writeFieldBegin('documentSplitNeeded', TType.BOOL, 6)
            oprot.writeBool(self.documentSplitNeeded)
            oprot.writeFieldEnd()
        if self.numDocumentsNeeded is not None:
            oprot.writeFieldBegin('numDocumentsNeeded', TType.I32, 7)
            oprot.writeI32(self.numDocumentsNeeded)
            oprot.writeFieldEnd()
        if self.initialCompletedAt is not None:
            oprot.writeFieldBegin('initialCompletedAt', TType.I64, 8)
            oprot.writeI64(self.initialCompletedAt)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter95 in self.dmsAgents:
                _iter95.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsListingUpdatedAt is not None:
            oprot.writeFieldBegin('dmsListingUpdatedAt', TType.STRUCT, 10)
            self.dmsListingUpdatedAt.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionUpdatedAt is not None:
            oprot.writeFieldBegin('dmsTransactionUpdatedAt', TType.STRUCT, 11)
            self.dmsTransactionUpdatedAt.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsWithdrawnCanceledChecklist is not None:
            oprot.writeFieldBegin('dmsWithdrawnCanceledChecklist', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsWithdrawnCanceledChecklist))
            for _iter96 in self.dmsWithdrawnCanceledChecklist:
                _iter96.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 13)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 14)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.lastReviewedDate is not None:
            oprot.writeFieldBegin('lastReviewedDate', TType.I64, 15)
            oprot.writeI64(self.lastReviewedDate)
            oprot.writeFieldEnd()
        if self.noteCount is not None:
            oprot.writeFieldBegin('noteCount', TType.I32, 16)
            oprot.writeI32(self.noteCount)
            oprot.writeFieldEnd()
        if self.hasUnresolvedNotes is not None:
            oprot.writeFieldBegin('hasUnresolvedNotes', TType.BOOL, 17)
            oprot.writeBool(self.hasUnresolvedNotes)
            oprot.writeFieldEnd()
        if self.unresolvedNotesCount is not None:
            oprot.writeFieldBegin('unresolvedNotesCount', TType.I32, 18)
            oprot.writeI32(self.unresolvedNotesCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CancelledDMSTransaction(object):
    """
    Attributes:
     - dmsListing
     - dmsTransaction
     - checklist
     - dmsContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dmsListing', (DmsListing, DmsListing.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsTransaction', (DmsTransaction, DmsTransaction.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'checklist', (TType.STRUCT, (DmsWithdrawnCanceledChecklistItem, DmsWithdrawnCanceledChecklistItem.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'dmsContacts', (TType.STRUCT, (DmsContact, DmsContact.thrift_spec), False), None, ),  # 4
    )
    def __init__(self, dmsListing=None, dmsTransaction=None, checklist=None, dmsContacts=None, ):
        self.dmsListing = dmsListing
        self.dmsTransaction = dmsTransaction
        self.checklist = checklist
        self.dmsContacts = dmsContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dmsListing = DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype97, _size100) = iprot.readListBegin()
                    for _i98 in range(_size100):
                        _elem99 = DmsWithdrawnCanceledChecklistItem()
                        _elem99.read(iprot)
                        self.checklist.append(_elem99)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype101, _size104) = iprot.readListBegin()
                    for _i102 in range(_size104):
                        _elem103 = DmsContact()
                        _elem103.read(iprot)
                        self.dmsContacts.append(_elem103)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CancelledDMSTransaction')
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 1)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 2)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter105 in self.checklist:
                _iter105.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter106 in self.dmsContacts:
                _iter106.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderActivityLog(object):
    """
    Attributes:
     - resourceType
     - resourceId
     - resourceName
     - resourceStatus
     - operatorId
     - operatorDisplayName
     - operatedAt
     - address
     - city
     - state
     - zipcode
     - operatorFirstName
     - operatorLastName
     - shortLog
     - changes
     - recipientId
     - recipientDisplayName
     - recipientFirstName
     - recipientLastName
     - note
     - checklistItemNameToPages
     - listDate
     - dmsTransaction
     - impersonatorId
     - impersonatorDisplayName
     - impersonatorFirstName
     - impersonatorLastName
     - dmsListing
     - checklistItemName
     - notificationType
     - dmsAgentLogInfo
     - dmsClientLogInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'resourceType', None, None, ),  # 1
        (2, TType.STRING, 'resourceId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'resourceName', 'UTF8', None, ),  # 3
        (4, TType.I32, 'resourceStatus', None, None, ),  # 4
        (5, TType.STRING, 'operatorId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'operatorDisplayName', 'UTF8', None, ),  # 6
        (7, TType.I64, 'operatedAt', None, None, ),  # 7
        (8, TType.STRING, 'address', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'city', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'state', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'zipcode', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'operatorFirstName', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'operatorLastName', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'shortLog', 'UTF8', None, ),  # 14
        (15, TType.LIST, 'changes', (TType.STRUCT, (gen.urbancompass.dms_common.dms_communication.ttypes.DiffElement, gen.urbancompass.dms_common.dms_communication.ttypes.DiffElement.thrift_spec), False), None, ),  # 15
        (16, TType.STRING, 'recipientId', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'recipientDisplayName', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'recipientFirstName', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'recipientLastName', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'note', 'UTF8', None, ),  # 20
        (21, TType.MAP, 'checklistItemNameToPages', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.dms_document.ttypes.PageInterval, gen.urbancompass.dms_document.ttypes.PageInterval.thrift_spec), False), None, ),  # 21
        (22, TType.I64, 'listDate', None, None, ),  # 22
        (23, TType.STRUCT, 'dmsTransaction', (DmsTransaction, DmsTransaction.thrift_spec), None, ),  # 23
        (24, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'impersonatorDisplayName', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'impersonatorFirstName', 'UTF8', None, ),  # 26
        (27, TType.STRING, 'impersonatorLastName', 'UTF8', None, ),  # 27
        (28, TType.STRUCT, 'dmsListing', (DmsListing, DmsListing.thrift_spec), None, ),  # 28
        (29, TType.STRING, 'checklistItemName', 'UTF8', None, ),  # 29
        (30, TType.STRING, 'notificationType', 'UTF8', None, ),  # 30
        (31, TType.STRUCT, 'dmsAgentLogInfo', (DmsAgentLogInfo, DmsAgentLogInfo.thrift_spec), None, ),  # 31
        (32, TType.STRUCT, 'dmsClientLogInfo', (DmsClientLogInfo, DmsClientLogInfo.thrift_spec), None, ),  # 32
    )
    def __init__(self, resourceType=None, resourceId=None, resourceName=None, resourceStatus=None, operatorId=None, operatorDisplayName=None, operatedAt=None, address=None, city=None, state=None, zipcode=None, operatorFirstName=None, operatorLastName=None, shortLog=None, changes=None, recipientId=None, recipientDisplayName=None, recipientFirstName=None, recipientLastName=None, note=None, checklistItemNameToPages=None, listDate=None, dmsTransaction=None, impersonatorId=None, impersonatorDisplayName=None, impersonatorFirstName=None, impersonatorLastName=None, dmsListing=None, checklistItemName=None, notificationType=None, dmsAgentLogInfo=None, dmsClientLogInfo=None, ):
        self.resourceType = resourceType
        self.resourceId = resourceId
        self.resourceName = resourceName
        self.resourceStatus = resourceStatus
        self.operatorId = operatorId
        self.operatorDisplayName = operatorDisplayName
        self.operatedAt = operatedAt
        self.address = address
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.operatorFirstName = operatorFirstName
        self.operatorLastName = operatorLastName
        self.shortLog = shortLog
        self.changes = changes
        self.recipientId = recipientId
        self.recipientDisplayName = recipientDisplayName
        self.recipientFirstName = recipientFirstName
        self.recipientLastName = recipientLastName
        self.note = note
        self.checklistItemNameToPages = checklistItemNameToPages
        self.listDate = listDate
        self.dmsTransaction = dmsTransaction
        self.impersonatorId = impersonatorId
        self.impersonatorDisplayName = impersonatorDisplayName
        self.impersonatorFirstName = impersonatorFirstName
        self.impersonatorLastName = impersonatorLastName
        self.dmsListing = dmsListing
        self.checklistItemName = checklistItemName
        self.notificationType = notificationType
        self.dmsAgentLogInfo = dmsAgentLogInfo
        self.dmsClientLogInfo = dmsClientLogInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.resourceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.resourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.resourceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.resourceStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.operatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.operatorDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.operatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.operatorFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.operatorLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.shortLog = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.changes = []
                    (_etype107, _size110) = iprot.readListBegin()
                    for _i108 in range(_size110):
                        _elem109 = gen.urbancompass.dms_common.dms_communication.ttypes.DiffElement()
                        _elem109.read(iprot)
                        self.changes.append(_elem109)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.recipientDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.recipientFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.recipientLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.MAP:
                    self.checklistItemNameToPages = {}
                    (_ktype112, _vtype113, _size116) = iprot.readMapBegin()
                    for _i111 in range(_size116):
                        _key114 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val115 = gen.urbancompass.dms_document.ttypes.PageInterval()
                        _val115.read(iprot)
                        self.checklistItemNameToPages[_key114] = _val115
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.impersonatorDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.impersonatorFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.impersonatorLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRUCT:
                    self.dmsListing = DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.checklistItemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.notificationType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRUCT:
                    self.dmsAgentLogInfo = DmsAgentLogInfo()
                    self.dmsAgentLogInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRUCT:
                    self.dmsClientLogInfo = DmsClientLogInfo()
                    self.dmsClientLogInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderActivityLog')
        if self.resourceType is not None:
            oprot.writeFieldBegin('resourceType', TType.I32, 1)
            oprot.writeI32(self.resourceType)
            oprot.writeFieldEnd()
        if self.resourceId is not None:
            oprot.writeFieldBegin('resourceId', TType.STRING, 2)
            oprot.writeString(self.resourceId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceId)
            oprot.writeFieldEnd()
        if self.resourceName is not None:
            oprot.writeFieldBegin('resourceName', TType.STRING, 3)
            oprot.writeString(self.resourceName.encode('utf-8') if sys.version_info[0] == 2 else self.resourceName)
            oprot.writeFieldEnd()
        if self.resourceStatus is not None:
            oprot.writeFieldBegin('resourceStatus', TType.I32, 4)
            oprot.writeI32(self.resourceStatus)
            oprot.writeFieldEnd()
        if self.operatorId is not None:
            oprot.writeFieldBegin('operatorId', TType.STRING, 5)
            oprot.writeString(self.operatorId.encode('utf-8') if sys.version_info[0] == 2 else self.operatorId)
            oprot.writeFieldEnd()
        if self.operatorDisplayName is not None:
            oprot.writeFieldBegin('operatorDisplayName', TType.STRING, 6)
            oprot.writeString(self.operatorDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.operatorDisplayName)
            oprot.writeFieldEnd()
        if self.operatedAt is not None:
            oprot.writeFieldBegin('operatedAt', TType.I64, 7)
            oprot.writeI64(self.operatedAt)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 8)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 9)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 10)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 11)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.operatorFirstName is not None:
            oprot.writeFieldBegin('operatorFirstName', TType.STRING, 12)
            oprot.writeString(self.operatorFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.operatorFirstName)
            oprot.writeFieldEnd()
        if self.operatorLastName is not None:
            oprot.writeFieldBegin('operatorLastName', TType.STRING, 13)
            oprot.writeString(self.operatorLastName.encode('utf-8') if sys.version_info[0] == 2 else self.operatorLastName)
            oprot.writeFieldEnd()
        if self.shortLog is not None:
            oprot.writeFieldBegin('shortLog', TType.STRING, 14)
            oprot.writeString(self.shortLog.encode('utf-8') if sys.version_info[0] == 2 else self.shortLog)
            oprot.writeFieldEnd()
        if self.changes is not None:
            oprot.writeFieldBegin('changes', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.changes))
            for _iter117 in self.changes:
                _iter117.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 16)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.recipientDisplayName is not None:
            oprot.writeFieldBegin('recipientDisplayName', TType.STRING, 17)
            oprot.writeString(self.recipientDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.recipientDisplayName)
            oprot.writeFieldEnd()
        if self.recipientFirstName is not None:
            oprot.writeFieldBegin('recipientFirstName', TType.STRING, 18)
            oprot.writeString(self.recipientFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.recipientFirstName)
            oprot.writeFieldEnd()
        if self.recipientLastName is not None:
            oprot.writeFieldBegin('recipientLastName', TType.STRING, 19)
            oprot.writeString(self.recipientLastName.encode('utf-8') if sys.version_info[0] == 2 else self.recipientLastName)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 20)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.checklistItemNameToPages is not None:
            oprot.writeFieldBegin('checklistItemNameToPages', TType.MAP, 21)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.checklistItemNameToPages))
            for _kiter118, _viter119 in self.checklistItemNameToPages.items():
                oprot.writeString(_kiter118.encode('utf-8') if sys.version_info[0] == 2 else _kiter118)
                _viter119.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 22)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 23)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 24)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.impersonatorDisplayName is not None:
            oprot.writeFieldBegin('impersonatorDisplayName', TType.STRING, 25)
            oprot.writeString(self.impersonatorDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorDisplayName)
            oprot.writeFieldEnd()
        if self.impersonatorFirstName is not None:
            oprot.writeFieldBegin('impersonatorFirstName', TType.STRING, 26)
            oprot.writeString(self.impersonatorFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorFirstName)
            oprot.writeFieldEnd()
        if self.impersonatorLastName is not None:
            oprot.writeFieldBegin('impersonatorLastName', TType.STRING, 27)
            oprot.writeString(self.impersonatorLastName.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorLastName)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 28)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItemName is not None:
            oprot.writeFieldBegin('checklistItemName', TType.STRING, 29)
            oprot.writeString(self.checklistItemName.encode('utf-8') if sys.version_info[0] == 2 else self.checklistItemName)
            oprot.writeFieldEnd()
        if self.notificationType is not None:
            oprot.writeFieldBegin('notificationType', TType.STRING, 30)
            oprot.writeString(self.notificationType.encode('utf-8') if sys.version_info[0] == 2 else self.notificationType)
            oprot.writeFieldEnd()
        if self.dmsAgentLogInfo is not None:
            oprot.writeFieldBegin('dmsAgentLogInfo', TType.STRUCT, 31)
            self.dmsAgentLogInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsClientLogInfo is not None:
            oprot.writeFieldBegin('dmsClientLogInfo', TType.STRUCT, 32)
            self.dmsClientLogInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingSyncPayload(object):
    """
    Attributes:
     - dmsListingId
     - dmsListing
     - fieldUpdateTimestamps
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'dmsListing', (DmsListing, DmsListing.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'fieldUpdateTimestamps', (DmsListingFieldsUpdatedAt, DmsListingFieldsUpdatedAt.thrift_spec), None, ),  # 3
    )
    def __init__(self, dmsListingId=None, dmsListing=None, fieldUpdateTimestamps=None, ):
        self.dmsListingId = dmsListingId
        self.dmsListing = dmsListing
        self.fieldUpdateTimestamps = fieldUpdateTimestamps

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsListing = DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.fieldUpdateTimestamps = DmsListingFieldsUpdatedAt()
                    self.fieldUpdateTimestamps.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingSyncPayload')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 2)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.fieldUpdateTimestamps is not None:
            oprot.writeFieldBegin('fieldUpdateTimestamps', TType.STRUCT, 3)
            self.fieldUpdateTimestamps.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingWithDetailedPatchInfo(object):
    """
    Attributes:
     - dmsListingWithoutPatch
     - dmsListingWithPatch
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dmsListingWithoutPatch', (DmsListing, DmsListing.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsListingWithPatch', (DmsListing, DmsListing.thrift_spec), None, ),  # 2
    )
    def __init__(self, dmsListingWithoutPatch=None, dmsListingWithPatch=None, ):
        self.dmsListingWithoutPatch = dmsListingWithoutPatch
        self.dmsListingWithPatch = dmsListingWithPatch

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dmsListingWithoutPatch = DmsListing()
                    self.dmsListingWithoutPatch.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsListingWithPatch = DmsListing()
                    self.dmsListingWithPatch.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingWithDetailedPatchInfo')
        if self.dmsListingWithoutPatch is not None:
            oprot.writeFieldBegin('dmsListingWithoutPatch', TType.STRUCT, 1)
            self.dmsListingWithoutPatch.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingWithPatch is not None:
            oprot.writeFieldBegin('dmsListingWithPatch', TType.STRUCT, 2)
            self.dmsListingWithPatch.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionSyncPayload(object):
    """
    Attributes:
     - dmsTransactionId
     - dmsTransaction
     - fieldUpdateTimestamps
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'dmsTransaction', (DmsTransaction, DmsTransaction.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'fieldUpdateTimestamps', (DmsTransactionFieldsUpdatedAt, DmsTransactionFieldsUpdatedAt.thrift_spec), None, ),  # 3
    )
    def __init__(self, dmsTransactionId=None, dmsTransaction=None, fieldUpdateTimestamps=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.dmsTransaction = dmsTransaction
        self.fieldUpdateTimestamps = fieldUpdateTimestamps

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.fieldUpdateTimestamps = DmsTransactionFieldsUpdatedAt()
                    self.fieldUpdateTimestamps.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionSyncPayload')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 2)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.fieldUpdateTimestamps is not None:
            oprot.writeFieldBegin('fieldUpdateTimestamps', TType.STRUCT, 3)
            self.fieldUpdateTimestamps.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class WithdrawnDMSListing(object):
    """
    Attributes:
     - dmsListing
     - checklist
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dmsListing', (DmsListing, DmsListing.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklist', (TType.STRUCT, (DmsListingChecklistItem, DmsListingChecklistItem.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, dmsListing=None, checklist=None, ):
        self.dmsListing = dmsListing
        self.checklist = checklist

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dmsListing = DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype120, _size123) = iprot.readListBegin()
                    for _i121 in range(_size123):
                        _elem122 = DmsListingChecklistItem()
                        _elem122.read(iprot)
                        self.checklist.append(_elem122)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('WithdrawnDMSListing')
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 1)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter124 in self.checklist:
                _iter124.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
