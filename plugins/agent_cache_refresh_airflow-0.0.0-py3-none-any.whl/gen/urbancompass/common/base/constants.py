
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
BINARY_CONTENT_TYPE_VALUES = {
    0: "application/vnd.mapbox-vector-tile",
    2: "application/pdf",
    1: "image/gif",
    3: "image/jpeg",
    4: "image/webp",
    5: "image/png",
    6: "text/csv",
    7: "application/xml",
    8: "text/tab-separated-values",
    9: "text/html",
}
CLIENT_PROFILE_METADATA_KEY = "uc-client-profile-bin"
INTERNAL_TOKEN_KEY = "x-compass-internal-token"
SERVICE_AUTH_KEY = "x-compass-auth-id"
TRACE_ID_METADATA_KEY = "uc-trace-id"
