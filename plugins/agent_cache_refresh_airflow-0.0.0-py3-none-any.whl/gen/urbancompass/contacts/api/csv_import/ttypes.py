
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class ContactsToImport(object):
    NEW_AND_EXISTING = 0
    ONLY_EXISTING = 1
    ONLY_NEW = 2

    _VALUES_TO_NAMES = {
        0: "NEW_AND_EXISTING",
        1: "ONLY_EXISTING",
        2: "ONLY_NEW",
    }

    _NAMES_TO_VALUES = {
        "NEW_AND_EXISTING": 0,
        "ONLY_EXISTING": 1,
        "ONLY_NEW": 2,
    }


class ImportStatus(object):
    ERROR_OCCURRED = 0
    NEEDS_PROCESSING = 1
    NEEDS_VALIDATING = 2
    PROCESSED = 3
    UPLOADED = 4
    VALIDATED = 5

    _VALUES_TO_NAMES = {
        0: "ERROR_OCCURRED",
        1: "NEEDS_PROCESSING",
        2: "NEEDS_VALIDATING",
        3: "PROCESSED",
        4: "UPLOADED",
        5: "VALIDATED",
    }

    _NAMES_TO_VALUES = {
        "ERROR_OCCURRED": 0,
        "NEEDS_PROCESSING": 1,
        "NEEDS_VALIDATING": 2,
        "PROCESSED": 3,
        "UPLOADED": 4,
        "VALIDATED": 5,
    }


class MappedHeader(object):
    ADDRESS_CITY = 0
    ADDRESS_COUNTRY = 1
    ADDRESS_LABEL = 2
    ADDRESS_LINE1 = 3
    ADDRESS_LINE2 = 4
    ADDRESS_STATE = 5
    ADDRESS_ZIP = 6
    ANNIVERSARY = 7
    BIRTH_DATE = 8
    BUCKETS = 9
    COMPANY = 10
    CUSTOM_FIELD = 11
    EMAIL = 12
    EMPTY = 13
    FIRST_NAME = 14
    FULL_NAME = 15
    LAST_NAME = 16
    NOTE = 17
    PHONE = 18
    SOCIAL_PROFILE = 19
    TAGS = 20
    TITLE = 21
    WEBSITE = 22
    HOME_ANNIVERSARY = 23
    WEDDING_ANNIVERSARY = 24
    LEASE_ANNIVERSARY = 25

    _VALUES_TO_NAMES = {
        0: "ADDRESS_CITY",
        1: "ADDRESS_COUNTRY",
        2: "ADDRESS_LABEL",
        3: "ADDRESS_LINE1",
        4: "ADDRESS_LINE2",
        5: "ADDRESS_STATE",
        6: "ADDRESS_ZIP",
        7: "ANNIVERSARY",
        8: "BIRTH_DATE",
        9: "BUCKETS",
        10: "COMPANY",
        11: "CUSTOM_FIELD",
        12: "EMAIL",
        13: "EMPTY",
        14: "FIRST_NAME",
        15: "FULL_NAME",
        16: "LAST_NAME",
        17: "NOTE",
        18: "PHONE",
        19: "SOCIAL_PROFILE",
        20: "TAGS",
        21: "TITLE",
        22: "WEBSITE",
        23: "HOME_ANNIVERSARY",
        24: "WEDDING_ANNIVERSARY",
        25: "LEASE_ANNIVERSARY",
    }

    _NAMES_TO_VALUES = {
        "ADDRESS_CITY": 0,
        "ADDRESS_COUNTRY": 1,
        "ADDRESS_LABEL": 2,
        "ADDRESS_LINE1": 3,
        "ADDRESS_LINE2": 4,
        "ADDRESS_STATE": 5,
        "ADDRESS_ZIP": 6,
        "ANNIVERSARY": 7,
        "BIRTH_DATE": 8,
        "BUCKETS": 9,
        "COMPANY": 10,
        "CUSTOM_FIELD": 11,
        "EMAIL": 12,
        "EMPTY": 13,
        "FIRST_NAME": 14,
        "FULL_NAME": 15,
        "LAST_NAME": 16,
        "NOTE": 17,
        "PHONE": 18,
        "SOCIAL_PROFILE": 19,
        "TAGS": 20,
        "TITLE": 21,
        "WEBSITE": 22,
        "HOME_ANNIVERSARY": 23,
        "WEDDING_ANNIVERSARY": 24,
        "LEASE_ANNIVERSARY": 25,
    }


class ImportColumnMap(object):
    """
    Attributes:
     - dateFormat
     - exampleData
     - mappedHeader
     - skip
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dateFormat', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'exampleData', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.I32, 'mappedHeader', None, None, ),  # 3
        (4, TType.BOOL, 'skip', None, None, ),  # 4
        (5, TType.STRING, 'type', 'UTF8', None, ),  # 5
    )
    def __init__(self, dateFormat=None, exampleData=None, mappedHeader=None, skip=None, type=None, ):
        self.dateFormat = dateFormat
        self.exampleData = exampleData
        self.mappedHeader = mappedHeader
        self.skip = skip
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dateFormat = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.exampleData = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.exampleData.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.mappedHeader = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.skip = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ImportColumnMap')
        if self.dateFormat is not None:
            oprot.writeFieldBegin('dateFormat', TType.STRING, 1)
            oprot.writeString(self.dateFormat.encode('utf-8') if sys.version_info[0] == 2 else self.dateFormat)
            oprot.writeFieldEnd()
        if self.exampleData is not None:
            oprot.writeFieldBegin('exampleData', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.exampleData))
            for _iter26 in self.exampleData:
                oprot.writeString(_iter26.encode('utf-8') if sys.version_info[0] == 2 else _iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.mappedHeader is not None:
            oprot.writeFieldBegin('mappedHeader', TType.I32, 3)
            oprot.writeI32(self.mappedHeader)
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.BOOL, 4)
            oprot.writeBool(self.skip)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 5)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ImportRowOverride(object):
    """
    Attributes:
     - contactExists
     - errors
     - skip
     - values
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'contactExists', None, None, ),  # 1
        (2, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 2
        (3, TType.BOOL, 'skip', None, None, ),  # 3
        (4, TType.MAP, 'values', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, contactExists=None, errors=None, skip=None, values=None, ):
        self.contactExists = contactExists
        self.errors = errors
        self.skip = skip
        self.values = values

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.contactExists = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype51, _vtype52, _size55) = iprot.readMapBegin()
                    for _i50 in range(_size55):
                        _key53 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val54 = []
                        (_etype56, _size59) = iprot.readListBegin()
                        for _i57 in range(_size59):
                            _elem58 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val54.append(_elem58)
                        iprot.readListEnd()
                        self.errors[_key53] = _val54
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.skip = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.values = {}
                    (_ktype61, _vtype62, _size65) = iprot.readMapBegin()
                    for _i60 in range(_size65):
                        _key63 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val64 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.values[_key63] = _val64
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ImportRowOverride')
        if self.contactExists is not None:
            oprot.writeFieldBegin('contactExists', TType.BOOL, 1)
            oprot.writeBool(self.contactExists)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.errors))
            for _kiter70, _viter71 in self.errors.items():
                oprot.writeString(_kiter70.encode('utf-8') if sys.version_info[0] == 2 else _kiter70)
                oprot.writeListBegin(TType.STRING, len(_viter71))
                for _iter72 in _viter71:
                    oprot.writeString(_iter72.encode('utf-8') if sys.version_info[0] == 2 else _iter72)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.BOOL, 3)
            oprot.writeBool(self.skip)
            oprot.writeFieldEnd()
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.values))
            for _kiter73, _viter74 in self.values.items():
                oprot.writeString(_kiter73.encode('utf-8') if sys.version_info[0] == 2 else _kiter73)
                oprot.writeString(_viter74.encode('utf-8') if sys.version_info[0] == 2 else _viter74)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PreviewResults(object):
    """
    Attributes:
     - existingContacts
     - newContacts
     - skipped
     - total
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'existingContacts', None, None, ),  # 1
        (2, TType.I32, 'newContacts', None, None, ),  # 2
        (3, TType.I32, 'skipped', None, None, ),  # 3
        (4, TType.I32, 'total', None, None, ),  # 4
    )
    def __init__(self, existingContacts=None, newContacts=None, skipped=None, total=None, ):
        self.existingContacts = existingContacts
        self.newContacts = newContacts
        self.skipped = skipped
        self.total = total

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.existingContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.newContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.skipped = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.total = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PreviewResults')
        if self.existingContacts is not None:
            oprot.writeFieldBegin('existingContacts', TType.I32, 1)
            oprot.writeI32(self.existingContacts)
            oprot.writeFieldEnd()
        if self.newContacts is not None:
            oprot.writeFieldBegin('newContacts', TType.I32, 2)
            oprot.writeI32(self.newContacts)
            oprot.writeFieldEnd()
        if self.skipped is not None:
            oprot.writeFieldBegin('skipped', TType.I32, 3)
            oprot.writeI32(self.skipped)
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.I32, 4)
            oprot.writeI32(self.total)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class VerTwoMeta(object):
    """
    Attributes:
     - existingArchivedContacts
     - existingContacts
     - newContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'existingArchivedContacts', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'existingContacts', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'newContacts', (TType.STRING, 'UTF8', False), None, ),  # 3
    )
    def __init__(self, existingArchivedContacts=None, existingContacts=None, newContacts=None, ):
        self.existingArchivedContacts = existingArchivedContacts
        self.existingContacts = existingContacts
        self.newContacts = newContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.existingArchivedContacts = []
                    (_etype96, _size99) = iprot.readListBegin()
                    for _i97 in range(_size99):
                        _elem98 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.existingArchivedContacts.append(_elem98)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.existingContacts = []
                    (_etype104, _size107) = iprot.readListBegin()
                    for _i105 in range(_size107):
                        _elem106 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.existingContacts.append(_elem106)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.newContacts = []
                    (_etype112, _size115) = iprot.readListBegin()
                    for _i113 in range(_size115):
                        _elem114 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.newContacts.append(_elem114)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('VerTwoMeta')
        if self.existingArchivedContacts is not None:
            oprot.writeFieldBegin('existingArchivedContacts', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.existingArchivedContacts))
            for _iter120 in self.existingArchivedContacts:
                oprot.writeString(_iter120.encode('utf-8') if sys.version_info[0] == 2 else _iter120)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.existingContacts is not None:
            oprot.writeFieldBegin('existingContacts', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.existingContacts))
            for _iter123 in self.existingContacts:
                oprot.writeString(_iter123.encode('utf-8') if sys.version_info[0] == 2 else _iter123)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.newContacts is not None:
            oprot.writeFieldBegin('newContacts', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.newContacts))
            for _iter124 in self.newContacts:
                oprot.writeString(_iter124.encode('utf-8') if sys.version_info[0] == 2 else _iter124)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ImportOptions(object):
    """
    Attributes:
     - addGroupingId
     - contactsToImport
     - react
     - columnMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'addGroupingId', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'contactsToImport', None, None, ),  # 2
        (3, TType.BOOL, 'react', None, None, ),  # 3
        (4, TType.MAP, 'columnMap', (TType.STRING, 'UTF8', TType.STRUCT, (ImportColumnMap, ImportColumnMap.thrift_spec), False), None, ),  # 4
    )
    def __init__(self, addGroupingId=None, contactsToImport=None, react=None, columnMap=None, ):
        self.addGroupingId = addGroupingId
        self.contactsToImport = contactsToImport
        self.react = react
        self.columnMap = columnMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.addGroupingId = []
                    (_etype133, _size136) = iprot.readListBegin()
                    for _i134 in range(_size136):
                        _elem135 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.addGroupingId.append(_elem135)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.contactsToImport = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.react = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.columnMap = {}
                    (_ktype138, _vtype139, _size142) = iprot.readMapBegin()
                    for _i137 in range(_size142):
                        _key140 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val141 = ImportColumnMap()
                        _val141.read(iprot)
                        self.columnMap[_key140] = _val141
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ImportOptions')
        if self.addGroupingId is not None:
            oprot.writeFieldBegin('addGroupingId', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.addGroupingId))
            for _iter143 in self.addGroupingId:
                oprot.writeString(_iter143.encode('utf-8') if sys.version_info[0] == 2 else _iter143)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.contactsToImport is not None:
            oprot.writeFieldBegin('contactsToImport', TType.I32, 2)
            oprot.writeI32(self.contactsToImport)
            oprot.writeFieldEnd()
        if self.react is not None:
            oprot.writeFieldBegin('react', TType.BOOL, 3)
            oprot.writeBool(self.react)
            oprot.writeFieldEnd()
        if self.columnMap is not None:
            oprot.writeFieldBegin('columnMap', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.columnMap))
            for _kiter145, _viter146 in self.columnMap.items():
                oprot.writeString(_kiter145.encode('utf-8') if sys.version_info[0] == 2 else _kiter145)
                _viter146.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ImportResults(object):
    """
    Attributes:
     - existingArchivedContacts
     - existingContacts
     - failed
     - skipped
     - successful
     - total
     - v2meta
     - errors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'existingArchivedContacts', None, None, ),  # 1
        (2, TType.I32, 'existingContacts', None, None, ),  # 2
        (3, TType.I32, 'failed', None, None, ),  # 3
        (4, TType.I32, 'skipped', None, None, ),  # 4
        (5, TType.I32, 'successful', None, None, ),  # 5
        (6, TType.I32, 'total', None, None, ),  # 6
        (7, TType.STRUCT, 'v2meta', (VerTwoMeta, VerTwoMeta.thrift_spec), None, ),  # 7
        (8, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 8
    )
    def __init__(self, existingArchivedContacts=None, existingContacts=None, failed=None, skipped=None, successful=None, total=None, v2meta=None, errors=None, ):
        self.existingArchivedContacts = existingArchivedContacts
        self.existingContacts = existingContacts
        self.failed = failed
        self.skipped = skipped
        self.successful = successful
        self.total = total
        self.v2meta = v2meta
        self.errors = errors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.existingArchivedContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.existingContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.failed = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.skipped = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.successful = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.total = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.v2meta = VerTwoMeta()
                    self.v2meta.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype156, _vtype157, _size160) = iprot.readMapBegin()
                    for _i155 in range(_size160):
                        _key158 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val159 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key158] = _val159
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ImportResults')
        if self.existingArchivedContacts is not None:
            oprot.writeFieldBegin('existingArchivedContacts', TType.I32, 1)
            oprot.writeI32(self.existingArchivedContacts)
            oprot.writeFieldEnd()
        if self.existingContacts is not None:
            oprot.writeFieldBegin('existingContacts', TType.I32, 2)
            oprot.writeI32(self.existingContacts)
            oprot.writeFieldEnd()
        if self.failed is not None:
            oprot.writeFieldBegin('failed', TType.I32, 3)
            oprot.writeI32(self.failed)
            oprot.writeFieldEnd()
        if self.skipped is not None:
            oprot.writeFieldBegin('skipped', TType.I32, 4)
            oprot.writeI32(self.skipped)
            oprot.writeFieldEnd()
        if self.successful is not None:
            oprot.writeFieldBegin('successful', TType.I32, 5)
            oprot.writeI32(self.successful)
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.I32, 6)
            oprot.writeI32(self.total)
            oprot.writeFieldEnd()
        if self.v2meta is not None:
            oprot.writeFieldBegin('v2meta', TType.STRUCT, 7)
            self.v2meta.write(oprot)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 8)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter162, _viter163 in self.errors.items():
                oprot.writeString(_kiter162.encode('utf-8') if sys.version_info[0] == 2 else _kiter162)
                oprot.writeString(_viter163.encode('utf-8') if sys.version_info[0] == 2 else _viter163)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
