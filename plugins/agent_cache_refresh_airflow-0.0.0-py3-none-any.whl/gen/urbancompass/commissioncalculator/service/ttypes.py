
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.agent_data_platform.commissionable_terms.model.comm_terms.ttypes
import gen.urbancompass.deals_platform.common.netsuite_model.ttypes

from thrift.transport import TTransport


class AccountingSummary(object):
    """
    Attributes:
     - netInvoice
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'netInvoice', None, None, ),  # 1
    )
    def __init__(self, netInvoice=None, ):
        self.netInvoice = netInvoice

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.netInvoice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountingSummary')
        if self.netInvoice is not None:
            oprot.writeFieldBegin('netInvoice', TType.DOUBLE, 1)
            oprot.writeDouble(self.netInvoice)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AdditionalTerm(object):
    """
    Attributes:
     - percent
     - cap
     - balance
     - id
     - type
     - start_date
     - end_date
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percent', None, None, ),  # 1
        (2, TType.DOUBLE, 'cap', None, None, ),  # 2
        (3, TType.DOUBLE, 'balance', None, None, ),  # 3
        (4, TType.I32, 'id', None, None, ),  # 4
        (5, TType.STRING, 'type', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'start_date', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'end_date', 'UTF8', None, ),  # 7
    )
    def __init__(self, percent=None, cap=None, balance=None, id=None, type=None, start_date=None, end_date=None, ):
        self.percent = percent
        self.cap = cap
        self.balance = balance
        self.id = id
        self.type = type
        self.start_date = start_date
        self.end_date = end_date

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.cap = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.balance = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.start_date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.end_date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AdditionalTerm')
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 1)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.cap is not None:
            oprot.writeFieldBegin('cap', TType.DOUBLE, 2)
            oprot.writeDouble(self.cap)
            oprot.writeFieldEnd()
        if self.balance is not None:
            oprot.writeFieldBegin('balance', TType.DOUBLE, 3)
            oprot.writeDouble(self.balance)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 4)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 5)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.start_date is not None:
            oprot.writeFieldBegin('start_date', TType.STRING, 6)
            oprot.writeString(self.start_date.encode('utf-8') if sys.version_info[0] == 2 else self.start_date)
            oprot.writeFieldEnd()
        if self.end_date is not None:
            oprot.writeFieldBegin('end_date', TType.STRING, 7)
            oprot.writeString(self.end_date.encode('utf-8') if sys.version_info[0] == 2 else self.end_date)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentCommission(object):
    """
    Attributes:
     - uuid
     - amount
     - commission_percent
     - entity_id
     - deal_split
     - deal_commission_type
     - deal_commission_type_id
     - agent_revenue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'uuid', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.DOUBLE, 'commission_percent', None, None, ),  # 3
        (4, TType.STRING, 'entity_id', 'UTF8', None, ),  # 4
        (5, TType.DOUBLE, 'deal_split', None, None, ),  # 5
        (6, TType.STRING, 'deal_commission_type', 'UTF8', None, ),  # 6
        (7, TType.I32, 'deal_commission_type_id', None, None, ),  # 7
        (8, TType.DOUBLE, 'agent_revenue', None, None, ),  # 8
    )
    def __init__(self, uuid=None, amount=None, commission_percent=None, entity_id=None, deal_split=None, deal_commission_type=None, deal_commission_type_id=None, agent_revenue=None, ):
        self.uuid = uuid
        self.amount = amount
        self.commission_percent = commission_percent
        self.entity_id = entity_id
        self.deal_split = deal_split
        self.deal_commission_type = deal_commission_type
        self.deal_commission_type_id = deal_commission_type_id
        self.agent_revenue = agent_revenue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.commission_percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.entity_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.deal_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.deal_commission_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.deal_commission_type_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.DOUBLE:
                    self.agent_revenue = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentCommission')
        if self.uuid is not None:
            oprot.writeFieldBegin('uuid', TType.STRING, 1)
            oprot.writeString(self.uuid.encode('utf-8') if sys.version_info[0] == 2 else self.uuid)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.commission_percent is not None:
            oprot.writeFieldBegin('commission_percent', TType.DOUBLE, 3)
            oprot.writeDouble(self.commission_percent)
            oprot.writeFieldEnd()
        if self.entity_id is not None:
            oprot.writeFieldBegin('entity_id', TType.STRING, 4)
            oprot.writeString(self.entity_id.encode('utf-8') if sys.version_info[0] == 2 else self.entity_id)
            oprot.writeFieldEnd()
        if self.deal_split is not None:
            oprot.writeFieldBegin('deal_split', TType.DOUBLE, 5)
            oprot.writeDouble(self.deal_split)
            oprot.writeFieldEnd()
        if self.deal_commission_type is not None:
            oprot.writeFieldBegin('deal_commission_type', TType.STRING, 6)
            oprot.writeString(self.deal_commission_type.encode('utf-8') if sys.version_info[0] == 2 else self.deal_commission_type)
            oprot.writeFieldEnd()
        if self.deal_commission_type_id is not None:
            oprot.writeFieldBegin('deal_commission_type_id', TType.I32, 7)
            oprot.writeI32(self.deal_commission_type_id)
            oprot.writeFieldEnd()
        if self.agent_revenue is not None:
            oprot.writeFieldBegin('agent_revenue', TType.DOUBLE, 8)
            oprot.writeDouble(self.agent_revenue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentFee(object):
    """
    Attributes:
     - uuid
     - amount
     - payer_id
     - payee_id
     - fee_type_id
     - fee_calculation_type
     - percent
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'uuid', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.STRING, 'payer_id', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'payee_id', 'UTF8', None, ),  # 4
        (5, TType.I32, 'fee_type_id', None, None, ),  # 5
        (6, TType.STRING, 'fee_calculation_type', 'UTF8', None, ),  # 6
        (7, TType.DOUBLE, 'percent', None, None, ),  # 7
    )
    def __init__(self, uuid=None, amount=None, payer_id=None, payee_id=None, fee_type_id=None, fee_calculation_type=None, percent=None, ):
        self.uuid = uuid
        self.amount = amount
        self.payer_id = payer_id
        self.payee_id = payee_id
        self.fee_type_id = fee_type_id
        self.fee_calculation_type = fee_calculation_type
        self.percent = percent

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.payer_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.payee_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.fee_type_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.fee_calculation_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentFee')
        if self.uuid is not None:
            oprot.writeFieldBegin('uuid', TType.STRING, 1)
            oprot.writeString(self.uuid.encode('utf-8') if sys.version_info[0] == 2 else self.uuid)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.payer_id is not None:
            oprot.writeFieldBegin('payer_id', TType.STRING, 3)
            oprot.writeString(self.payer_id.encode('utf-8') if sys.version_info[0] == 2 else self.payer_id)
            oprot.writeFieldEnd()
        if self.payee_id is not None:
            oprot.writeFieldBegin('payee_id', TType.STRING, 4)
            oprot.writeString(self.payee_id.encode('utf-8') if sys.version_info[0] == 2 else self.payee_id)
            oprot.writeFieldEnd()
        if self.fee_type_id is not None:
            oprot.writeFieldBegin('fee_type_id', TType.I32, 5)
            oprot.writeI32(self.fee_type_id)
            oprot.writeFieldEnd()
        if self.fee_calculation_type is not None:
            oprot.writeFieldBegin('fee_calculation_type', TType.STRING, 6)
            oprot.writeString(self.fee_calculation_type.encode('utf-8') if sys.version_info[0] == 2 else self.fee_calculation_type)
            oprot.writeFieldEnd()
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 7)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BaseSplitModel(object):
    """
    Attributes:
     - base_split
     - incentive_split
     - split_policy_applies
     - base_agent_split_type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'base_split', None, None, ),  # 1
        (2, TType.DOUBLE, 'incentive_split', None, None, ),  # 2
        (3, TType.BOOL, 'split_policy_applies', None, None, ),  # 3
        (4, TType.STRING, 'base_agent_split_type', 'UTF8', None, ),  # 4
    )
    def __init__(self, base_split=None, incentive_split=None, split_policy_applies=None, base_agent_split_type=None, ):
        self.base_split = base_split
        self.incentive_split = incentive_split
        self.split_policy_applies = split_policy_applies
        self.base_agent_split_type = base_agent_split_type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.base_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.incentive_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.split_policy_applies = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.base_agent_split_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BaseSplitModel')
        if self.base_split is not None:
            oprot.writeFieldBegin('base_split', TType.DOUBLE, 1)
            oprot.writeDouble(self.base_split)
            oprot.writeFieldEnd()
        if self.incentive_split is not None:
            oprot.writeFieldBegin('incentive_split', TType.DOUBLE, 2)
            oprot.writeDouble(self.incentive_split)
            oprot.writeFieldEnd()
        if self.split_policy_applies is not None:
            oprot.writeFieldBegin('split_policy_applies', TType.BOOL, 3)
            oprot.writeBool(self.split_policy_applies)
            oprot.writeFieldEnd()
        if self.base_agent_split_type is not None:
            oprot.writeFieldBegin('base_agent_split_type', TType.STRING, 4)
            oprot.writeString(self.base_agent_split_type.encode('utf-8') if sys.version_info[0] == 2 else self.base_agent_split_type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BrokerFee(object):
    """
    Attributes:
     - percent
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percent', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, percent=None, amount=None, ):
        self.percent = percent
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BrokerFee')
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 1)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommissionCapSplitModel(object):
    """
    Attributes:
     - pre_cap_split
     - post_cap_split
     - cap_amount
     - incentive_split
     - cap_split_term_option_code
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'pre_cap_split', None, None, ),  # 1
        (2, TType.DOUBLE, 'post_cap_split', None, None, ),  # 2
        (3, TType.DOUBLE, 'cap_amount', None, None, ),  # 3
        (4, TType.DOUBLE, 'incentive_split', None, None, ),  # 4
        (5, TType.STRING, 'cap_split_term_option_code', 'UTF8', None, ),  # 5
    )
    def __init__(self, pre_cap_split=None, post_cap_split=None, cap_amount=None, incentive_split=None, cap_split_term_option_code=None, ):
        self.pre_cap_split = pre_cap_split
        self.post_cap_split = post_cap_split
        self.cap_amount = cap_amount
        self.incentive_split = incentive_split
        self.cap_split_term_option_code = cap_split_term_option_code

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.pre_cap_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.post_cap_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.cap_amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.incentive_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.cap_split_term_option_code = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionCapSplitModel')
        if self.pre_cap_split is not None:
            oprot.writeFieldBegin('pre_cap_split', TType.DOUBLE, 1)
            oprot.writeDouble(self.pre_cap_split)
            oprot.writeFieldEnd()
        if self.post_cap_split is not None:
            oprot.writeFieldBegin('post_cap_split', TType.DOUBLE, 2)
            oprot.writeDouble(self.post_cap_split)
            oprot.writeFieldEnd()
        if self.cap_amount is not None:
            oprot.writeFieldBegin('cap_amount', TType.DOUBLE, 3)
            oprot.writeDouble(self.cap_amount)
            oprot.writeFieldEnd()
        if self.incentive_split is not None:
            oprot.writeFieldBegin('incentive_split', TType.DOUBLE, 4)
            oprot.writeDouble(self.incentive_split)
            oprot.writeFieldEnd()
        if self.cap_split_term_option_code is not None:
            oprot.writeFieldBegin('cap_split_term_option_code', TType.STRING, 5)
            oprot.writeString(self.cap_split_term_option_code.encode('utf-8') if sys.version_info[0] == 2 else self.cap_split_term_option_code)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntityGroupsWrapper(object):
    """
    Attributes:
     - brokerage_id
     - client_id
     - agent_ids
     - third_party_ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'brokerage_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'client_id', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'agent_ids', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'third_party_ids', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, brokerage_id=None, client_id=None, agent_ids=None, third_party_ids=None, ):
        self.brokerage_id = brokerage_id
        self.client_id = client_id
        self.agent_ids = agent_ids
        self.third_party_ids = third_party_ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.brokerage_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.client_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.agent_ids = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.agent_ids.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.third_party_ids = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.third_party_ids.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntityGroupsWrapper')
        if self.brokerage_id is not None:
            oprot.writeFieldBegin('brokerage_id', TType.STRING, 1)
            oprot.writeString(self.brokerage_id.encode('utf-8') if sys.version_info[0] == 2 else self.brokerage_id)
            oprot.writeFieldEnd()
        if self.client_id is not None:
            oprot.writeFieldBegin('client_id', TType.STRING, 2)
            oprot.writeString(self.client_id.encode('utf-8') if sys.version_info[0] == 2 else self.client_id)
            oprot.writeFieldEnd()
        if self.agent_ids is not None:
            oprot.writeFieldBegin('agent_ids', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.agent_ids))
            for _iter10 in self.agent_ids:
                oprot.writeString(_iter10.encode('utf-8') if sys.version_info[0] == 2 else _iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.third_party_ids is not None:
            oprot.writeFieldBegin('third_party_ids', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.third_party_ids))
            for _iter11 in self.third_party_ids:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Gci(object):
    """
    Attributes:
     - year_to_date
     - team_gci
     - agent_gci
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'year_to_date', None, None, ),  # 1
        (2, TType.DOUBLE, 'team_gci', None, None, ),  # 2
        (3, TType.MAP, 'agent_gci', (TType.STRING, 'UTF8', TType.DOUBLE, None, False), None, ),  # 3
    )
    def __init__(self, year_to_date=None, team_gci=None, agent_gci=None, ):
        self.year_to_date = year_to_date
        self.team_gci = team_gci
        self.agent_gci = agent_gci

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.year_to_date = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.team_gci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.agent_gci = {}
                    (_ktype13, _vtype14, _size17) = iprot.readMapBegin()
                    for _i12 in range(_size17):
                        _key15 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val16 = iprot.readDouble()
                        self.agent_gci[_key15] = _val16
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Gci')
        if self.year_to_date is not None:
            oprot.writeFieldBegin('year_to_date', TType.DOUBLE, 1)
            oprot.writeDouble(self.year_to_date)
            oprot.writeFieldEnd()
        if self.team_gci is not None:
            oprot.writeFieldBegin('team_gci', TType.DOUBLE, 2)
            oprot.writeDouble(self.team_gci)
            oprot.writeFieldEnd()
        if self.agent_gci is not None:
            oprot.writeFieldBegin('agent_gci', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.DOUBLE, len(self.agent_gci))
            for _kiter18, _viter19 in self.agent_gci.items():
                oprot.writeString(_kiter18.encode('utf-8') if sys.version_info[0] == 2 else _kiter18)
                oprot.writeDouble(_viter19)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class HealthCheckRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('HealthCheckRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class HealthCheckResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('HealthCheckResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ItemAmount(object):
    """
    Attributes:
     - netsuiteItem
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'netsuiteItem', (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteItem, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteItem.thrift_spec), None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, netsuiteItem=None, amount=None, ):
        self.netsuiteItem = netsuiteItem
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.netsuiteItem = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteItem()
                    self.netsuiteItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ItemAmount')
        if self.netsuiteItem is not None:
            oprot.writeFieldBegin('netsuiteItem', TType.STRUCT, 1)
            self.netsuiteItem.write(oprot)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Line(object):
    """
    Attributes:
     - item_id
     - amount
     - exact_amount
     - listing_type
     - listing_type_id
     - disbursement_id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'item_id', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.DOUBLE, 'exact_amount', None, None, ),  # 3
        (4, TType.STRING, 'listing_type', 'UTF8', None, ),  # 4
        (5, TType.I32, 'listing_type_id', None, None, ),  # 5
        (6, TType.I32, 'disbursement_id', None, None, ),  # 6
    )
    def __init__(self, item_id=None, amount=None, exact_amount=None, listing_type=None, listing_type_id=None, disbursement_id=None, ):
        self.item_id = item_id
        self.amount = amount
        self.exact_amount = exact_amount
        self.listing_type = listing_type
        self.listing_type_id = listing_type_id
        self.disbursement_id = disbursement_id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.exact_amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.listing_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.listing_type_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.disbursement_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Line')
        if self.item_id is not None:
            oprot.writeFieldBegin('item_id', TType.I32, 1)
            oprot.writeI32(self.item_id)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.exact_amount is not None:
            oprot.writeFieldBegin('exact_amount', TType.DOUBLE, 3)
            oprot.writeDouble(self.exact_amount)
            oprot.writeFieldEnd()
        if self.listing_type is not None:
            oprot.writeFieldBegin('listing_type', TType.STRING, 4)
            oprot.writeString(self.listing_type.encode('utf-8') if sys.version_info[0] == 2 else self.listing_type)
            oprot.writeFieldEnd()
        if self.listing_type_id is not None:
            oprot.writeFieldBegin('listing_type_id', TType.I32, 5)
            oprot.writeI32(self.listing_type_id)
            oprot.writeFieldEnd()
        if self.disbursement_id is not None:
            oprot.writeFieldBegin('disbursement_id', TType.I32, 6)
            oprot.writeI32(self.disbursement_id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PeriodFeeFee(object):
    """
    Attributes:
     - percent
     - calculation_type
     - cap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percent', None, None, ),  # 1
        (2, TType.STRING, 'calculation_type', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'cap', None, None, ),  # 3
    )
    def __init__(self, percent=None, calculation_type=None, cap=None, ):
        self.percent = percent
        self.calculation_type = calculation_type
        self.cap = cap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.calculation_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.cap = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PeriodFeeFee')
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 1)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.calculation_type is not None:
            oprot.writeFieldBegin('calculation_type', TType.STRING, 2)
            oprot.writeString(self.calculation_type.encode('utf-8') if sys.version_info[0] == 2 else self.calculation_type)
            oprot.writeFieldEnd()
        if self.cap is not None:
            oprot.writeFieldBegin('cap', TType.DOUBLE, 3)
            oprot.writeDouble(self.cap)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralBroker(object):
    """
    Attributes:
     - ama_id
     - external_broker_id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'ama_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'external_broker_id', 'UTF8', None, ),  # 2
    )
    def __init__(self, ama_id=None, external_broker_id=None, ):
        self.ama_id = ama_id
        self.external_broker_id = external_broker_id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.ama_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.external_broker_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralBroker')
        if self.ama_id is not None:
            oprot.writeFieldBegin('ama_id', TType.STRING, 1)
            oprot.writeString(self.ama_id.encode('utf-8') if sys.version_info[0] == 2 else self.ama_id)
            oprot.writeFieldEnd()
        if self.external_broker_id is not None:
            oprot.writeFieldBegin('external_broker_id', TType.STRING, 2)
            oprot.writeString(self.external_broker_id.encode('utf-8') if sys.version_info[0] == 2 else self.external_broker_id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralFee(object):
    """
    Attributes:
     - percentage
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percentage', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, percentage=None, amount=None, ):
        self.percentage = percentage
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percentage = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralFee')
        if self.percentage is not None:
            oprot.writeFieldBegin('percentage', TType.DOUBLE, 1)
            oprot.writeDouble(self.percentage)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveToNetsuiteRequest(object):
    """
    Attributes:
     - commissionResponse
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'commissionResponse', 'UTF8', None, ),  # 1
    )
    def __init__(self, commissionResponse=None, ):
        self.commissionResponse = commissionResponse

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.commissionResponse = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveToNetsuiteRequest')
        if self.commissionResponse is not None:
            oprot.writeFieldBegin('commissionResponse', TType.STRING, 1)
            oprot.writeString(self.commissionResponse.encode('utf-8') if sys.version_info[0] == 2 else self.commissionResponse)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveToNetsuiteResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveToNetsuiteResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Split(object):
    """
    Attributes:
     - incentive_split
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'incentive_split', None, None, ),  # 1
    )
    def __init__(self, incentive_split=None, ):
        self.incentive_split = incentive_split

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.incentive_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Split')
        if self.incentive_split is not None:
            oprot.writeFieldBegin('incentive_split', TType.DOUBLE, 1)
            oprot.writeDouble(self.incentive_split)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SplitOverride(object):
    """
    Attributes:
     - base_split
     - incentive_split
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'base_split', None, None, ),  # 1
        (2, TType.DOUBLE, 'incentive_split', None, None, ),  # 2
    )
    def __init__(self, base_split=None, incentive_split=None, ):
        self.base_split = base_split
        self.incentive_split = incentive_split

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.base_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.incentive_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SplitOverride')
        if self.base_split is not None:
            oprot.writeFieldBegin('base_split', TType.DOUBLE, 1)
            oprot.writeDouble(self.base_split)
            oprot.writeFieldEnd()
        if self.incentive_split is not None:
            oprot.writeFieldBegin('incentive_split', TType.DOUBLE, 2)
            oprot.writeDouble(self.incentive_split)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ThresholdSplit(object):
    """
    Attributes:
     - minimum_threshold
     - maximum_threshold
     - default_base_agent_split
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'minimum_threshold', None, None, ),  # 1
        (2, TType.DOUBLE, 'maximum_threshold', None, None, ),  # 2
        (3, TType.DOUBLE, 'default_base_agent_split', None, None, ),  # 3
    )
    def __init__(self, minimum_threshold=None, maximum_threshold=None, default_base_agent_split=None, ):
        self.minimum_threshold = minimum_threshold
        self.maximum_threshold = maximum_threshold
        self.default_base_agent_split = default_base_agent_split

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.minimum_threshold = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.maximum_threshold = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.default_base_agent_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ThresholdSplit')
        if self.minimum_threshold is not None:
            oprot.writeFieldBegin('minimum_threshold', TType.DOUBLE, 1)
            oprot.writeDouble(self.minimum_threshold)
            oprot.writeFieldEnd()
        if self.maximum_threshold is not None:
            oprot.writeFieldBegin('maximum_threshold', TType.DOUBLE, 2)
            oprot.writeDouble(self.maximum_threshold)
            oprot.writeFieldEnd()
        if self.default_base_agent_split is not None:
            oprot.writeFieldBegin('default_base_agent_split', TType.DOUBLE, 3)
            oprot.writeDouble(self.default_base_agent_split)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentPayoutSummary(object):
    """
    Attributes:
     - entityId
     - grossCommission
     - grossIncentiveCommission
     - resourceFee
     - abp
     - aep
     - remainingApplicableFees
     - amountByItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'entityId', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'grossCommission', None, None, ),  # 2
        (3, TType.DOUBLE, 'grossIncentiveCommission', None, None, ),  # 3
        (4, TType.DOUBLE, 'resourceFee', None, None, ),  # 4
        (5, TType.DOUBLE, 'abp', None, None, ),  # 5
        (6, TType.DOUBLE, 'aep', None, None, ),  # 6
        (7, TType.DOUBLE, 'remainingApplicableFees', None, None, ),  # 7
        (8, TType.LIST, 'amountByItems', (TType.STRUCT, (ItemAmount, ItemAmount.thrift_spec), False), None, ),  # 8
    )
    def __init__(self, entityId=None, grossCommission=None, grossIncentiveCommission=None, resourceFee=None, abp=None, aep=None, remainingApplicableFees=None, amountByItems=None, ):
        self.entityId = entityId
        self.grossCommission = grossCommission
        self.grossIncentiveCommission = grossIncentiveCommission
        self.resourceFee = resourceFee
        self.abp = abp
        self.aep = aep
        self.remainingApplicableFees = remainingApplicableFees
        self.amountByItems = amountByItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.entityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.grossCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.grossIncentiveCommission = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.resourceFee = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.abp = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.aep = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.remainingApplicableFees = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.amountByItems = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = ItemAmount()
                        _elem22.read(iprot)
                        self.amountByItems.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentPayoutSummary')
        if self.entityId is not None:
            oprot.writeFieldBegin('entityId', TType.STRING, 1)
            oprot.writeString(self.entityId.encode('utf-8') if sys.version_info[0] == 2 else self.entityId)
            oprot.writeFieldEnd()
        if self.grossCommission is not None:
            oprot.writeFieldBegin('grossCommission', TType.DOUBLE, 2)
            oprot.writeDouble(self.grossCommission)
            oprot.writeFieldEnd()
        if self.grossIncentiveCommission is not None:
            oprot.writeFieldBegin('grossIncentiveCommission', TType.DOUBLE, 3)
            oprot.writeDouble(self.grossIncentiveCommission)
            oprot.writeFieldEnd()
        if self.resourceFee is not None:
            oprot.writeFieldBegin('resourceFee', TType.DOUBLE, 4)
            oprot.writeDouble(self.resourceFee)
            oprot.writeFieldEnd()
        if self.abp is not None:
            oprot.writeFieldBegin('abp', TType.DOUBLE, 5)
            oprot.writeDouble(self.abp)
            oprot.writeFieldEnd()
        if self.aep is not None:
            oprot.writeFieldBegin('aep', TType.DOUBLE, 6)
            oprot.writeDouble(self.aep)
            oprot.writeFieldEnd()
        if self.remainingApplicableFees is not None:
            oprot.writeFieldBegin('remainingApplicableFees', TType.DOUBLE, 7)
            oprot.writeDouble(self.remainingApplicableFees)
            oprot.writeFieldEnd()
        if self.amountByItems is not None:
            oprot.writeFieldBegin('amountByItems', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.amountByItems))
            for _iter24 in self.amountByItems:
                _iter24.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Allocation(object):
    """
    Attributes:
     - agent_id
     - commission_percent
     - fee_percent
     - amount
     - splitOverride
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'agent_id', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'commission_percent', None, None, ),  # 2
        (3, TType.DOUBLE, 'fee_percent', None, None, ),  # 3
        (4, TType.DOUBLE, 'amount', None, None, ),  # 4
        (5, TType.STRUCT, 'splitOverride', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 5
    )
    def __init__(self, agent_id=None, commission_percent=None, fee_percent=None, amount=None, splitOverride=None, ):
        self.agent_id = agent_id
        self.commission_percent = commission_percent
        self.fee_percent = fee_percent
        self.amount = amount
        self.splitOverride = splitOverride

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.agent_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.commission_percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.fee_percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.splitOverride = SplitOverride()
                    self.splitOverride.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Allocation')
        if self.agent_id is not None:
            oprot.writeFieldBegin('agent_id', TType.STRING, 1)
            oprot.writeString(self.agent_id.encode('utf-8') if sys.version_info[0] == 2 else self.agent_id)
            oprot.writeFieldEnd()
        if self.commission_percent is not None:
            oprot.writeFieldBegin('commission_percent', TType.DOUBLE, 2)
            oprot.writeDouble(self.commission_percent)
            oprot.writeFieldEnd()
        if self.fee_percent is not None:
            oprot.writeFieldBegin('fee_percent', TType.DOUBLE, 3)
            oprot.writeDouble(self.fee_percent)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 4)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.splitOverride is not None:
            oprot.writeFieldBegin('splitOverride', TType.STRUCT, 5)
            self.splitOverride.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Invoice(object):
    """
    Attributes:
     - date
     - entity_id
     - ar_account
     - subsidiary
     - location
     - department
     - line_of_business
     - lines
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'date', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'entity_id', 'UTF8', None, ),  # 2
        (3, TType.I32, 'ar_account', None, None, ),  # 3
        (4, TType.I32, 'subsidiary', None, None, ),  # 4
        (5, TType.I32, 'location', None, None, ),  # 5
        (6, TType.I32, 'department', None, None, ),  # 6
        (7, TType.I32, 'line_of_business', None, None, ),  # 7
        (8, TType.LIST, 'lines', (TType.STRUCT, (Line, Line.thrift_spec), False), None, ),  # 8
    )
    def __init__(self, date=None, entity_id=None, ar_account=None, subsidiary=None, location=None, department=None, line_of_business=None, lines=None, ):
        self.date = date
        self.entity_id = entity_id
        self.ar_account = ar_account
        self.subsidiary = subsidiary
        self.location = location
        self.department = department
        self.line_of_business = line_of_business
        self.lines = lines

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.entity_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.ar_account = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.subsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.location = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.department = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.line_of_business = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.lines = []
                    (_etype25, _size28) = iprot.readListBegin()
                    for _i26 in range(_size28):
                        _elem27 = Line()
                        _elem27.read(iprot)
                        self.lines.append(_elem27)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Invoice')
        if self.date is not None:
            oprot.writeFieldBegin('date', TType.STRING, 1)
            oprot.writeString(self.date.encode('utf-8') if sys.version_info[0] == 2 else self.date)
            oprot.writeFieldEnd()
        if self.entity_id is not None:
            oprot.writeFieldBegin('entity_id', TType.STRING, 2)
            oprot.writeString(self.entity_id.encode('utf-8') if sys.version_info[0] == 2 else self.entity_id)
            oprot.writeFieldEnd()
        if self.ar_account is not None:
            oprot.writeFieldBegin('ar_account', TType.I32, 3)
            oprot.writeI32(self.ar_account)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.I32, 4)
            oprot.writeI32(self.subsidiary)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.I32, 5)
            oprot.writeI32(self.location)
            oprot.writeFieldEnd()
        if self.department is not None:
            oprot.writeFieldBegin('department', TType.I32, 6)
            oprot.writeI32(self.department)
            oprot.writeFieldEnd()
        if self.line_of_business is not None:
            oprot.writeFieldBegin('line_of_business', TType.I32, 7)
            oprot.writeI32(self.line_of_business)
            oprot.writeFieldEnd()
        if self.lines is not None:
            oprot.writeFieldBegin('lines', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.lines))
            for _iter29 in self.lines:
                _iter29.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Participant(object):
    """
    Attributes:
     - entity_id
     - additional_terms
     - netsuiteTransactions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'entity_id', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'additional_terms', (TType.STRUCT, (AdditionalTerm, AdditionalTerm.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'netsuiteTransactions', (TType.STRUCT, (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteTransaction, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteTransaction.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, entity_id=None, additional_terms=None, netsuiteTransactions=None, ):
        self.entity_id = entity_id
        self.additional_terms = additional_terms
        self.netsuiteTransactions = netsuiteTransactions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.entity_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.additional_terms = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = AdditionalTerm()
                        _elem32.read(iprot)
                        self.additional_terms.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.netsuiteTransactions = []
                    (_etype34, _size37) = iprot.readListBegin()
                    for _i35 in range(_size37):
                        _elem36 = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteTransaction()
                        _elem36.read(iprot)
                        self.netsuiteTransactions.append(_elem36)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Participant')
        if self.entity_id is not None:
            oprot.writeFieldBegin('entity_id', TType.STRING, 1)
            oprot.writeString(self.entity_id.encode('utf-8') if sys.version_info[0] == 2 else self.entity_id)
            oprot.writeFieldEnd()
        if self.additional_terms is not None:
            oprot.writeFieldBegin('additional_terms', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.additional_terms))
            for _iter38 in self.additional_terms:
                _iter38.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.netsuiteTransactions is not None:
            oprot.writeFieldBegin('netsuiteTransactions', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.netsuiteTransactions))
            for _iter39 in self.netsuiteTransactions:
                _iter39.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PeriodFee(object):
    """
    Attributes:
     - frequency
     - fee
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'frequency', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'fee', (PeriodFeeFee, PeriodFeeFee.thrift_spec), None, ),  # 2
    )
    def __init__(self, frequency=None, fee=None, ):
        self.frequency = frequency
        self.fee = fee

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.frequency = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.fee = PeriodFeeFee()
                    self.fee.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PeriodFee')
        if self.frequency is not None:
            oprot.writeFieldBegin('frequency', TType.STRING, 1)
            oprot.writeString(self.frequency.encode('utf-8') if sys.version_info[0] == 2 else self.frequency)
            oprot.writeFieldEnd()
        if self.fee is not None:
            oprot.writeFieldBegin('fee', TType.STRUCT, 2)
            self.fee.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionCountIncentiveSplit(object):
    """
    Attributes:
     - split
     - incentive_count
     - incentive_type
     - applied_incentive_count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'split', (Split, Split.thrift_spec), None, ),  # 1
        (2, TType.I32, 'incentive_count', None, None, ),  # 2
        (3, TType.STRING, 'incentive_type', 'UTF8', None, ),  # 3
        (4, TType.I32, 'applied_incentive_count', None, None, ),  # 4
    )
    def __init__(self, split=None, incentive_count=None, incentive_type=None, applied_incentive_count=None, ):
        self.split = split
        self.incentive_count = incentive_count
        self.incentive_type = incentive_type
        self.applied_incentive_count = applied_incentive_count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.split = Split()
                    self.split.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.incentive_count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.incentive_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.applied_incentive_count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionCountIncentiveSplit')
        if self.split is not None:
            oprot.writeFieldBegin('split', TType.STRUCT, 1)
            self.split.write(oprot)
            oprot.writeFieldEnd()
        if self.incentive_count is not None:
            oprot.writeFieldBegin('incentive_count', TType.I32, 2)
            oprot.writeI32(self.incentive_count)
            oprot.writeFieldEnd()
        if self.incentive_type is not None:
            oprot.writeFieldBegin('incentive_type', TType.STRING, 3)
            oprot.writeString(self.incentive_type.encode('utf-8') if sys.version_info[0] == 2 else self.incentive_type)
            oprot.writeFieldEnd()
        if self.applied_incentive_count is not None:
            oprot.writeFieldBegin('applied_incentive_count', TType.I32, 4)
            oprot.writeI32(self.applied_incentive_count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class VendorBill(object):
    """
    Attributes:
     - date
     - entity_id
     - subsidiary
     - location
     - department
     - line_of_business
     - lines
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'date', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'entity_id', 'UTF8', None, ),  # 2
        (3, TType.I32, 'subsidiary', None, None, ),  # 3
        (4, TType.I32, 'location', None, None, ),  # 4
        (5, TType.I32, 'department', None, None, ),  # 5
        (6, TType.I32, 'line_of_business', None, None, ),  # 6
        (7, TType.LIST, 'lines', (TType.STRUCT, (Line, Line.thrift_spec), False), None, ),  # 7
    )
    def __init__(self, date=None, entity_id=None, subsidiary=None, location=None, department=None, line_of_business=None, lines=None, ):
        self.date = date
        self.entity_id = entity_id
        self.subsidiary = subsidiary
        self.location = location
        self.department = department
        self.line_of_business = line_of_business
        self.lines = lines

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.entity_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.subsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.location = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.department = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.line_of_business = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.lines = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = Line()
                        _elem42.read(iprot)
                        self.lines.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('VendorBill')
        if self.date is not None:
            oprot.writeFieldBegin('date', TType.STRING, 1)
            oprot.writeString(self.date.encode('utf-8') if sys.version_info[0] == 2 else self.date)
            oprot.writeFieldEnd()
        if self.entity_id is not None:
            oprot.writeFieldBegin('entity_id', TType.STRING, 2)
            oprot.writeString(self.entity_id.encode('utf-8') if sys.version_info[0] == 2 else self.entity_id)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.I32, 3)
            oprot.writeI32(self.subsidiary)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.I32, 4)
            oprot.writeI32(self.location)
            oprot.writeFieldEnd()
        if self.department is not None:
            oprot.writeFieldBegin('department', TType.I32, 5)
            oprot.writeI32(self.department)
            oprot.writeFieldEnd()
        if self.line_of_business is not None:
            oprot.writeFieldBegin('line_of_business', TType.I32, 6)
            oprot.writeI32(self.line_of_business)
            oprot.writeFieldEnd()
        if self.lines is not None:
            oprot.writeFieldBegin('lines', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.lines))
            for _iter44 in self.lines:
                _iter44.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AccountingResponse(object):
    """
    Attributes:
     - deal_address
     - deal_id
     - request_uuid
     - invoices
     - vendor_bills
     - parent_deal
     - effective_split
     - source_topic
     - ama_id
     - calculated_at
     - agentPayoutSummaries
     - dmsTransactionId
     - accountingSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'deal_address', 'UTF8', None, ),  # 1
        (2, TType.I32, 'deal_id', None, None, ),  # 2
        (3, TType.STRING, 'request_uuid', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'invoices', (TType.STRUCT, (Invoice, Invoice.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'vendor_bills', (TType.STRUCT, (VendorBill, VendorBill.thrift_spec), False), None, ),  # 5
        (6, TType.I32, 'parent_deal', None, None, ),  # 6
        (7, TType.DOUBLE, 'effective_split', None, None, ),  # 7
        (8, TType.STRING, 'source_topic', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'ama_id', 'UTF8', None, ),  # 9
        (10, TType.I64, 'calculated_at', None, None, ),  # 10
        (11, TType.LIST, 'agentPayoutSummaries', (TType.STRUCT, (AgentPayoutSummary, AgentPayoutSummary.thrift_spec), False), None, ),  # 11
        (12, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 12
        (13, TType.STRUCT, 'accountingSummary', (AccountingSummary, AccountingSummary.thrift_spec), None, ),  # 13
    )
    def __init__(self, deal_address=None, deal_id=None, request_uuid=None, invoices=None, vendor_bills=None, parent_deal=None, effective_split=None, source_topic=None, ama_id=None, calculated_at=None, agentPayoutSummaries=None, dmsTransactionId=None, accountingSummary=None, ):
        self.deal_address = deal_address
        self.deal_id = deal_id
        self.request_uuid = request_uuid
        self.invoices = invoices
        self.vendor_bills = vendor_bills
        self.parent_deal = parent_deal
        self.effective_split = effective_split
        self.source_topic = source_topic
        self.ama_id = ama_id
        self.calculated_at = calculated_at
        self.agentPayoutSummaries = agentPayoutSummaries
        self.dmsTransactionId = dmsTransactionId
        self.accountingSummary = accountingSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.deal_address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.deal_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.request_uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.invoices = []
                    (_etype45, _size48) = iprot.readListBegin()
                    for _i46 in range(_size48):
                        _elem47 = Invoice()
                        _elem47.read(iprot)
                        self.invoices.append(_elem47)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.vendor_bills = []
                    (_etype49, _size52) = iprot.readListBegin()
                    for _i50 in range(_size52):
                        _elem51 = VendorBill()
                        _elem51.read(iprot)
                        self.vendor_bills.append(_elem51)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.parent_deal = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.effective_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.source_topic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.ama_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.calculated_at = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.agentPayoutSummaries = []
                    (_etype53, _size56) = iprot.readListBegin()
                    for _i54 in range(_size56):
                        _elem55 = AgentPayoutSummary()
                        _elem55.read(iprot)
                        self.agentPayoutSummaries.append(_elem55)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.accountingSummary = AccountingSummary()
                    self.accountingSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountingResponse')
        if self.deal_address is not None:
            oprot.writeFieldBegin('deal_address', TType.STRING, 1)
            oprot.writeString(self.deal_address.encode('utf-8') if sys.version_info[0] == 2 else self.deal_address)
            oprot.writeFieldEnd()
        if self.deal_id is not None:
            oprot.writeFieldBegin('deal_id', TType.I32, 2)
            oprot.writeI32(self.deal_id)
            oprot.writeFieldEnd()
        if self.request_uuid is not None:
            oprot.writeFieldBegin('request_uuid', TType.STRING, 3)
            oprot.writeString(self.request_uuid.encode('utf-8') if sys.version_info[0] == 2 else self.request_uuid)
            oprot.writeFieldEnd()
        if self.invoices is not None:
            oprot.writeFieldBegin('invoices', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.invoices))
            for _iter57 in self.invoices:
                _iter57.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.vendor_bills is not None:
            oprot.writeFieldBegin('vendor_bills', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.vendor_bills))
            for _iter58 in self.vendor_bills:
                _iter58.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.parent_deal is not None:
            oprot.writeFieldBegin('parent_deal', TType.I32, 6)
            oprot.writeI32(self.parent_deal)
            oprot.writeFieldEnd()
        if self.effective_split is not None:
            oprot.writeFieldBegin('effective_split', TType.DOUBLE, 7)
            oprot.writeDouble(self.effective_split)
            oprot.writeFieldEnd()
        if self.source_topic is not None:
            oprot.writeFieldBegin('source_topic', TType.STRING, 8)
            oprot.writeString(self.source_topic.encode('utf-8') if sys.version_info[0] == 2 else self.source_topic)
            oprot.writeFieldEnd()
        if self.ama_id is not None:
            oprot.writeFieldBegin('ama_id', TType.STRING, 9)
            oprot.writeString(self.ama_id.encode('utf-8') if sys.version_info[0] == 2 else self.ama_id)
            oprot.writeFieldEnd()
        if self.calculated_at is not None:
            oprot.writeFieldBegin('calculated_at', TType.I64, 10)
            oprot.writeI64(self.calculated_at)
            oprot.writeFieldEnd()
        if self.agentPayoutSummaries is not None:
            oprot.writeFieldBegin('agentPayoutSummaries', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.agentPayoutSummaries))
            for _iter59 in self.agentPayoutSummaries:
                _iter59.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 12)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.accountingSummary is not None:
            oprot.writeFieldBegin('accountingSummary', TType.STRUCT, 13)
            self.accountingSummary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AreInfo(object):
    """
    Attributes:
     - deal_address
     - close_date
     - brokerage_ar_entity
     - brokerage_ar_account
     - subsidiary
     - location
     - department
     - line_of_business
     - listing_type
     - listing_type_id
     - revenue_item_id
     - commission_item_id
     - incentive_commission_item_id
     - aep_item_id
     - abp_item_id
     - cabig_item_id
     - participants
     - resource_fee_item_id
     - compass_lead_revenue_item_id
     - referral_deduction_item_id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'deal_address', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'close_date', 'UTF8', None, ),  # 2
        (3, TType.I32, 'brokerage_ar_entity', None, None, ),  # 3
        (4, TType.I32, 'brokerage_ar_account', None, None, ),  # 4
        (5, TType.I32, 'subsidiary', None, None, ),  # 5
        (6, TType.I32, 'location', None, None, ),  # 6
        (7, TType.I32, 'department', None, None, ),  # 7
        (8, TType.I32, 'line_of_business', None, None, ),  # 8
        (9, TType.STRING, 'listing_type', 'UTF8', None, ),  # 9
        (10, TType.I32, 'listing_type_id', None, None, ),  # 10
        (11, TType.I32, 'revenue_item_id', None, None, ),  # 11
        (12, TType.I32, 'commission_item_id', None, None, ),  # 12
        (13, TType.I32, 'incentive_commission_item_id', None, None, ),  # 13
        (14, TType.I32, 'aep_item_id', None, None, ),  # 14
        (15, TType.I32, 'abp_item_id', None, None, ),  # 15
        (16, TType.I32, 'cabig_item_id', None, None, ),  # 16
        (17, TType.LIST, 'participants', (TType.STRUCT, (Participant, Participant.thrift_spec), False), None, ),  # 17
        (18, TType.I32, 'resource_fee_item_id', None, None, ),  # 18
        (19, TType.I32, 'compass_lead_revenue_item_id', None, None, ),  # 19
        (20, TType.I32, 'referral_deduction_item_id', None, None, ),  # 20
    )
    def __init__(self, deal_address=None, close_date=None, brokerage_ar_entity=None, brokerage_ar_account=None, subsidiary=None, location=None, department=None, line_of_business=None, listing_type=None, listing_type_id=None, revenue_item_id=None, commission_item_id=None, incentive_commission_item_id=None, aep_item_id=None, abp_item_id=None, cabig_item_id=None, participants=None, resource_fee_item_id=None, compass_lead_revenue_item_id=None, referral_deduction_item_id=None, ):
        self.deal_address = deal_address
        self.close_date = close_date
        self.brokerage_ar_entity = brokerage_ar_entity
        self.brokerage_ar_account = brokerage_ar_account
        self.subsidiary = subsidiary
        self.location = location
        self.department = department
        self.line_of_business = line_of_business
        self.listing_type = listing_type
        self.listing_type_id = listing_type_id
        self.revenue_item_id = revenue_item_id
        self.commission_item_id = commission_item_id
        self.incentive_commission_item_id = incentive_commission_item_id
        self.aep_item_id = aep_item_id
        self.abp_item_id = abp_item_id
        self.cabig_item_id = cabig_item_id
        self.participants = participants
        self.resource_fee_item_id = resource_fee_item_id
        self.compass_lead_revenue_item_id = compass_lead_revenue_item_id
        self.referral_deduction_item_id = referral_deduction_item_id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.deal_address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.close_date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.brokerage_ar_entity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.brokerage_ar_account = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.subsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.location = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.department = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.line_of_business = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.listing_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.listing_type_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.revenue_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.commission_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.incentive_commission_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.aep_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.abp_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.cabig_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.participants = []
                    (_etype60, _size63) = iprot.readListBegin()
                    for _i61 in range(_size63):
                        _elem62 = Participant()
                        _elem62.read(iprot)
                        self.participants.append(_elem62)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.resource_fee_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.compass_lead_revenue_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.referral_deduction_item_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AreInfo')
        if self.deal_address is not None:
            oprot.writeFieldBegin('deal_address', TType.STRING, 1)
            oprot.writeString(self.deal_address.encode('utf-8') if sys.version_info[0] == 2 else self.deal_address)
            oprot.writeFieldEnd()
        if self.close_date is not None:
            oprot.writeFieldBegin('close_date', TType.STRING, 2)
            oprot.writeString(self.close_date.encode('utf-8') if sys.version_info[0] == 2 else self.close_date)
            oprot.writeFieldEnd()
        if self.brokerage_ar_entity is not None:
            oprot.writeFieldBegin('brokerage_ar_entity', TType.I32, 3)
            oprot.writeI32(self.brokerage_ar_entity)
            oprot.writeFieldEnd()
        if self.brokerage_ar_account is not None:
            oprot.writeFieldBegin('brokerage_ar_account', TType.I32, 4)
            oprot.writeI32(self.brokerage_ar_account)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.I32, 5)
            oprot.writeI32(self.subsidiary)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.I32, 6)
            oprot.writeI32(self.location)
            oprot.writeFieldEnd()
        if self.department is not None:
            oprot.writeFieldBegin('department', TType.I32, 7)
            oprot.writeI32(self.department)
            oprot.writeFieldEnd()
        if self.line_of_business is not None:
            oprot.writeFieldBegin('line_of_business', TType.I32, 8)
            oprot.writeI32(self.line_of_business)
            oprot.writeFieldEnd()
        if self.listing_type is not None:
            oprot.writeFieldBegin('listing_type', TType.STRING, 9)
            oprot.writeString(self.listing_type.encode('utf-8') if sys.version_info[0] == 2 else self.listing_type)
            oprot.writeFieldEnd()
        if self.listing_type_id is not None:
            oprot.writeFieldBegin('listing_type_id', TType.I32, 10)
            oprot.writeI32(self.listing_type_id)
            oprot.writeFieldEnd()
        if self.revenue_item_id is not None:
            oprot.writeFieldBegin('revenue_item_id', TType.I32, 11)
            oprot.writeI32(self.revenue_item_id)
            oprot.writeFieldEnd()
        if self.commission_item_id is not None:
            oprot.writeFieldBegin('commission_item_id', TType.I32, 12)
            oprot.writeI32(self.commission_item_id)
            oprot.writeFieldEnd()
        if self.incentive_commission_item_id is not None:
            oprot.writeFieldBegin('incentive_commission_item_id', TType.I32, 13)
            oprot.writeI32(self.incentive_commission_item_id)
            oprot.writeFieldEnd()
        if self.aep_item_id is not None:
            oprot.writeFieldBegin('aep_item_id', TType.I32, 14)
            oprot.writeI32(self.aep_item_id)
            oprot.writeFieldEnd()
        if self.abp_item_id is not None:
            oprot.writeFieldBegin('abp_item_id', TType.I32, 15)
            oprot.writeI32(self.abp_item_id)
            oprot.writeFieldEnd()
        if self.cabig_item_id is not None:
            oprot.writeFieldBegin('cabig_item_id', TType.I32, 16)
            oprot.writeI32(self.cabig_item_id)
            oprot.writeFieldEnd()
        if self.participants is not None:
            oprot.writeFieldBegin('participants', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.participants))
            for _iter64 in self.participants:
                _iter64.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.resource_fee_item_id is not None:
            oprot.writeFieldBegin('resource_fee_item_id', TType.I32, 18)
            oprot.writeI32(self.resource_fee_item_id)
            oprot.writeFieldEnd()
        if self.compass_lead_revenue_item_id is not None:
            oprot.writeFieldBegin('compass_lead_revenue_item_id', TType.I32, 19)
            oprot.writeI32(self.compass_lead_revenue_item_id)
            oprot.writeFieldEnd()
        if self.referral_deduction_item_id is not None:
            oprot.writeFieldBegin('referral_deduction_item_id', TType.I32, 20)
            oprot.writeI32(self.referral_deduction_item_id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Fee(object):
    """
    Attributes:
     - pay_to_entity_id
     - fee_type_id
     - fee_calculation_type
     - amount
     - percent
     - commission_impacting
     - allocations
     - waived
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'pay_to_entity_id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'fee_type_id', None, None, ),  # 2
        (3, TType.STRING, 'fee_calculation_type', 'UTF8', None, ),  # 3
        (4, TType.DOUBLE, 'amount', None, None, ),  # 4
        (5, TType.DOUBLE, 'percent', None, None, ),  # 5
        (6, TType.BOOL, 'commission_impacting', None, None, ),  # 6
        (7, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 7
        (8, TType.BOOL, 'waived', None, None, ),  # 8
    )
    def __init__(self, pay_to_entity_id=None, fee_type_id=None, fee_calculation_type=None, amount=None, percent=None, commission_impacting=None, allocations=None, waived=None, ):
        self.pay_to_entity_id = pay_to_entity_id
        self.fee_type_id = fee_type_id
        self.fee_calculation_type = fee_calculation_type
        self.amount = amount
        self.percent = percent
        self.commission_impacting = commission_impacting
        self.allocations = allocations
        self.waived = waived

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.pay_to_entity_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.fee_type_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.fee_calculation_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.commission_impacting = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = Allocation()
                        _elem67.read(iprot)
                        self.allocations.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.waived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Fee')
        if self.pay_to_entity_id is not None:
            oprot.writeFieldBegin('pay_to_entity_id', TType.STRING, 1)
            oprot.writeString(self.pay_to_entity_id.encode('utf-8') if sys.version_info[0] == 2 else self.pay_to_entity_id)
            oprot.writeFieldEnd()
        if self.fee_type_id is not None:
            oprot.writeFieldBegin('fee_type_id', TType.I32, 2)
            oprot.writeI32(self.fee_type_id)
            oprot.writeFieldEnd()
        if self.fee_calculation_type is not None:
            oprot.writeFieldBegin('fee_calculation_type', TType.STRING, 3)
            oprot.writeString(self.fee_calculation_type.encode('utf-8') if sys.version_info[0] == 2 else self.fee_calculation_type)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 4)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 5)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.commission_impacting is not None:
            oprot.writeFieldBegin('commission_impacting', TType.BOOL, 6)
            oprot.writeBool(self.commission_impacting)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter69 in self.allocations:
                _iter69.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.waived is not None:
            oprot.writeFieldBegin('waived', TType.BOOL, 8)
            oprot.writeBool(self.waived)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResourceFee(object):
    """
    Attributes:
     - type
     - period_fee
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'type', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'period_fee', (PeriodFee, PeriodFee.thrift_spec), None, ),  # 2
    )
    def __init__(self, type=None, period_fee=None, ):
        self.type = type
        self.period_fee = period_fee

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.period_fee = PeriodFee()
                    self.period_fee.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResourceFee')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 1)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.period_fee is not None:
            oprot.writeFieldBegin('period_fee', TType.STRUCT, 2)
            self.period_fee.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveCommissionResponseToNetsuiteResponse(object):
    """
    Attributes:
     - deal_address
     - deal_id
     - request_uuid
     - invoices
     - vendor_bills
     - source_topic
     - status
     - parent_deal
     - effective_split
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'deal_address', 'UTF8', None, ),  # 1
        (2, TType.I32, 'deal_id', None, None, ),  # 2
        (3, TType.STRING, 'request_uuid', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'invoices', (TType.STRUCT, (Invoice, Invoice.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'vendor_bills', (TType.STRUCT, (VendorBill, VendorBill.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'source_topic', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 7
        (8, TType.I32, 'parent_deal', None, None, ),  # 8
        (9, TType.DOUBLE, 'effective_split', None, None, ),  # 9
    )
    def __init__(self, deal_address=None, deal_id=None, request_uuid=None, invoices=None, vendor_bills=None, source_topic=None, status=None, parent_deal=None, effective_split=None, ):
        self.deal_address = deal_address
        self.deal_id = deal_id
        self.request_uuid = request_uuid
        self.invoices = invoices
        self.vendor_bills = vendor_bills
        self.source_topic = source_topic
        self.status = status
        self.parent_deal = parent_deal
        self.effective_split = effective_split

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.deal_address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.deal_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.request_uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.invoices = []
                    (_etype70, _size73) = iprot.readListBegin()
                    for _i71 in range(_size73):
                        _elem72 = Invoice()
                        _elem72.read(iprot)
                        self.invoices.append(_elem72)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.vendor_bills = []
                    (_etype74, _size77) = iprot.readListBegin()
                    for _i75 in range(_size77):
                        _elem76 = VendorBill()
                        _elem76.read(iprot)
                        self.vendor_bills.append(_elem76)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.source_topic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.parent_deal = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.effective_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveCommissionResponseToNetsuiteResponse')
        if self.deal_address is not None:
            oprot.writeFieldBegin('deal_address', TType.STRING, 1)
            oprot.writeString(self.deal_address.encode('utf-8') if sys.version_info[0] == 2 else self.deal_address)
            oprot.writeFieldEnd()
        if self.deal_id is not None:
            oprot.writeFieldBegin('deal_id', TType.I32, 2)
            oprot.writeI32(self.deal_id)
            oprot.writeFieldEnd()
        if self.request_uuid is not None:
            oprot.writeFieldBegin('request_uuid', TType.STRING, 3)
            oprot.writeString(self.request_uuid.encode('utf-8') if sys.version_info[0] == 2 else self.request_uuid)
            oprot.writeFieldEnd()
        if self.invoices is not None:
            oprot.writeFieldBegin('invoices', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.invoices))
            for _iter78 in self.invoices:
                _iter78.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.vendor_bills is not None:
            oprot.writeFieldBegin('vendor_bills', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.vendor_bills))
            for _iter79 in self.vendor_bills:
                _iter79.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.source_topic is not None:
            oprot.writeFieldBegin('source_topic', TType.STRING, 6)
            oprot.writeString(self.source_topic.encode('utf-8') if sys.version_info[0] == 2 else self.source_topic)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 7)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.parent_deal is not None:
            oprot.writeFieldBegin('parent_deal', TType.I32, 8)
            oprot.writeI32(self.parent_deal)
            oprot.writeFieldEnd()
        if self.effective_split is not None:
            oprot.writeFieldBegin('effective_split', TType.DOUBLE, 9)
            oprot.writeDouble(self.effective_split)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Ama(object):
    """
    Attributes:
     - id
     - is_valid_for_automated_commissions
     - base_split_model
     - broker_account_split
     - resource_fee
     - transaction_count_incentive_split
     - threshold_split
     - split_model_type
     - commission_cap_split_model
     - agent_role
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'is_valid_for_automated_commissions', None, None, ),  # 2
        (3, TType.STRUCT, 'base_split_model', (BaseSplitModel, BaseSplitModel.thrift_spec), None, ),  # 3
        (4, TType.DOUBLE, 'broker_account_split', None, None, ),  # 4
        (5, TType.STRUCT, 'resource_fee', (ResourceFee, ResourceFee.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'transaction_count_incentive_split', (TransactionCountIncentiveSplit, TransactionCountIncentiveSplit.thrift_spec), None, ),  # 6
        (7, TType.LIST, 'threshold_split', (TType.STRUCT, (ThresholdSplit, ThresholdSplit.thrift_spec), False), None, ),  # 7
        (8, TType.STRING, 'split_model_type', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'commission_cap_split_model', (CommissionCapSplitModel, CommissionCapSplitModel.thrift_spec), None, ),  # 9
        (10, TType.STRING, 'agent_role', 'UTF8', None, ),  # 10
    )
    def __init__(self, id=None, is_valid_for_automated_commissions=None, base_split_model=None, broker_account_split=None, resource_fee=None, transaction_count_incentive_split=None, threshold_split=None, split_model_type=None, commission_cap_split_model=None, agent_role=None, ):
        self.id = id
        self.is_valid_for_automated_commissions = is_valid_for_automated_commissions
        self.base_split_model = base_split_model
        self.broker_account_split = broker_account_split
        self.resource_fee = resource_fee
        self.transaction_count_incentive_split = transaction_count_incentive_split
        self.threshold_split = threshold_split
        self.split_model_type = split_model_type
        self.commission_cap_split_model = commission_cap_split_model
        self.agent_role = agent_role

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.is_valid_for_automated_commissions = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.base_split_model = BaseSplitModel()
                    self.base_split_model.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.broker_account_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.resource_fee = ResourceFee()
                    self.resource_fee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.transaction_count_incentive_split = TransactionCountIncentiveSplit()
                    self.transaction_count_incentive_split.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.threshold_split = []
                    (_etype80, _size83) = iprot.readListBegin()
                    for _i81 in range(_size83):
                        _elem82 = ThresholdSplit()
                        _elem82.read(iprot)
                        self.threshold_split.append(_elem82)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.split_model_type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.commission_cap_split_model = CommissionCapSplitModel()
                    self.commission_cap_split_model.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.agent_role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Ama')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.is_valid_for_automated_commissions is not None:
            oprot.writeFieldBegin('is_valid_for_automated_commissions', TType.BOOL, 2)
            oprot.writeBool(self.is_valid_for_automated_commissions)
            oprot.writeFieldEnd()
        if self.base_split_model is not None:
            oprot.writeFieldBegin('base_split_model', TType.STRUCT, 3)
            self.base_split_model.write(oprot)
            oprot.writeFieldEnd()
        if self.broker_account_split is not None:
            oprot.writeFieldBegin('broker_account_split', TType.DOUBLE, 4)
            oprot.writeDouble(self.broker_account_split)
            oprot.writeFieldEnd()
        if self.resource_fee is not None:
            oprot.writeFieldBegin('resource_fee', TType.STRUCT, 5)
            self.resource_fee.write(oprot)
            oprot.writeFieldEnd()
        if self.transaction_count_incentive_split is not None:
            oprot.writeFieldBegin('transaction_count_incentive_split', TType.STRUCT, 6)
            self.transaction_count_incentive_split.write(oprot)
            oprot.writeFieldEnd()
        if self.threshold_split is not None:
            oprot.writeFieldBegin('threshold_split', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.threshold_split))
            for _iter84 in self.threshold_split:
                _iter84.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.split_model_type is not None:
            oprot.writeFieldBegin('split_model_type', TType.STRING, 8)
            oprot.writeString(self.split_model_type.encode('utf-8') if sys.version_info[0] == 2 else self.split_model_type)
            oprot.writeFieldEnd()
        if self.commission_cap_split_model is not None:
            oprot.writeFieldBegin('commission_cap_split_model', TType.STRUCT, 9)
            self.commission_cap_split_model.write(oprot)
            oprot.writeFieldEnd()
        if self.agent_role is not None:
            oprot.writeFieldBegin('agent_role', TType.STRING, 10)
            oprot.writeString(self.agent_role.encode('utf-8') if sys.version_info[0] == 2 else self.agent_role)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculationResponse(object):
    """
    Attributes:
     - request_uuid
     - deal_id
     - version
     - calculated_at
     - revenue
     - agent_commissions
     - agent_fees
     - entities
     - are_info
     - source_topic
     - parent_deal
     - effective_split
     - ama_id
     - grossCommissionIncome
     - netCommissionIncome
     - dmsTransactionId
     - effectiveSplitsByAmaId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'request_uuid', 'UTF8', None, ),  # 1
        (2, TType.I32, 'deal_id', None, None, ),  # 2
        (3, TType.STRING, 'version', 'UTF8', None, ),  # 3
        (4, TType.I64, 'calculated_at', None, None, ),  # 4
        (5, TType.DOUBLE, 'revenue', None, None, ),  # 5
        (6, TType.LIST, 'agent_commissions', (TType.STRUCT, (AgentCommission, AgentCommission.thrift_spec), False), None, ),  # 6
        (7, TType.LIST, 'agent_fees', (TType.STRUCT, (AgentFee, AgentFee.thrift_spec), False), None, ),  # 7
        (8, TType.STRUCT, 'entities', (EntityGroupsWrapper, EntityGroupsWrapper.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'are_info', (AreInfo, AreInfo.thrift_spec), None, ),  # 9
        (10, TType.STRING, 'source_topic', 'UTF8', None, ),  # 10
        (11, TType.I32, 'parent_deal', None, None, ),  # 11
        (12, TType.DOUBLE, 'effective_split', None, None, ),  # 12
        (13, TType.STRING, 'ama_id', 'UTF8', None, ),  # 13
        (14, TType.DOUBLE, 'grossCommissionIncome', None, None, ),  # 14
        (15, TType.DOUBLE, 'netCommissionIncome', None, None, ),  # 15
        (16, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 16
        (17, TType.MAP, 'effectiveSplitsByAmaId', (TType.STRING, 'UTF8', TType.DOUBLE, None, False), None, ),  # 17
    )
    def __init__(self, request_uuid=None, deal_id=None, version=None, calculated_at=None, revenue=None, agent_commissions=None, agent_fees=None, entities=None, are_info=None, source_topic=None, parent_deal=None, effective_split=None, ama_id=None, grossCommissionIncome=None, netCommissionIncome=None, dmsTransactionId=None, effectiveSplitsByAmaId=None, ):
        self.request_uuid = request_uuid
        self.deal_id = deal_id
        self.version = version
        self.calculated_at = calculated_at
        self.revenue = revenue
        self.agent_commissions = agent_commissions
        self.agent_fees = agent_fees
        self.entities = entities
        self.are_info = are_info
        self.source_topic = source_topic
        self.parent_deal = parent_deal
        self.effective_split = effective_split
        self.ama_id = ama_id
        self.grossCommissionIncome = grossCommissionIncome
        self.netCommissionIncome = netCommissionIncome
        self.dmsTransactionId = dmsTransactionId
        self.effectiveSplitsByAmaId = effectiveSplitsByAmaId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.request_uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.deal_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.version = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.calculated_at = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.revenue = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.agent_commissions = []
                    (_etype85, _size88) = iprot.readListBegin()
                    for _i86 in range(_size88):
                        _elem87 = AgentCommission()
                        _elem87.read(iprot)
                        self.agent_commissions.append(_elem87)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.agent_fees = []
                    (_etype89, _size92) = iprot.readListBegin()
                    for _i90 in range(_size92):
                        _elem91 = AgentFee()
                        _elem91.read(iprot)
                        self.agent_fees.append(_elem91)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.entities = EntityGroupsWrapper()
                    self.entities.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.are_info = AreInfo()
                    self.are_info.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.source_topic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.parent_deal = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.DOUBLE:
                    self.effective_split = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.ama_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.grossCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.DOUBLE:
                    self.netCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.MAP:
                    self.effectiveSplitsByAmaId = {}
                    (_ktype94, _vtype95, _size98) = iprot.readMapBegin()
                    for _i93 in range(_size98):
                        _key96 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val97 = iprot.readDouble()
                        self.effectiveSplitsByAmaId[_key96] = _val97
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculationResponse')
        if self.request_uuid is not None:
            oprot.writeFieldBegin('request_uuid', TType.STRING, 1)
            oprot.writeString(self.request_uuid.encode('utf-8') if sys.version_info[0] == 2 else self.request_uuid)
            oprot.writeFieldEnd()
        if self.deal_id is not None:
            oprot.writeFieldBegin('deal_id', TType.I32, 2)
            oprot.writeI32(self.deal_id)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.STRING, 3)
            oprot.writeString(self.version.encode('utf-8') if sys.version_info[0] == 2 else self.version)
            oprot.writeFieldEnd()
        if self.calculated_at is not None:
            oprot.writeFieldBegin('calculated_at', TType.I64, 4)
            oprot.writeI64(self.calculated_at)
            oprot.writeFieldEnd()
        if self.revenue is not None:
            oprot.writeFieldBegin('revenue', TType.DOUBLE, 5)
            oprot.writeDouble(self.revenue)
            oprot.writeFieldEnd()
        if self.agent_commissions is not None:
            oprot.writeFieldBegin('agent_commissions', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.agent_commissions))
            for _iter99 in self.agent_commissions:
                _iter99.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agent_fees is not None:
            oprot.writeFieldBegin('agent_fees', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.agent_fees))
            for _iter100 in self.agent_fees:
                _iter100.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.entities is not None:
            oprot.writeFieldBegin('entities', TType.STRUCT, 8)
            self.entities.write(oprot)
            oprot.writeFieldEnd()
        if self.are_info is not None:
            oprot.writeFieldBegin('are_info', TType.STRUCT, 9)
            self.are_info.write(oprot)
            oprot.writeFieldEnd()
        if self.source_topic is not None:
            oprot.writeFieldBegin('source_topic', TType.STRING, 10)
            oprot.writeString(self.source_topic.encode('utf-8') if sys.version_info[0] == 2 else self.source_topic)
            oprot.writeFieldEnd()
        if self.parent_deal is not None:
            oprot.writeFieldBegin('parent_deal', TType.I32, 11)
            oprot.writeI32(self.parent_deal)
            oprot.writeFieldEnd()
        if self.effective_split is not None:
            oprot.writeFieldBegin('effective_split', TType.DOUBLE, 12)
            oprot.writeDouble(self.effective_split)
            oprot.writeFieldEnd()
        if self.ama_id is not None:
            oprot.writeFieldBegin('ama_id', TType.STRING, 13)
            oprot.writeString(self.ama_id.encode('utf-8') if sys.version_info[0] == 2 else self.ama_id)
            oprot.writeFieldEnd()
        if self.grossCommissionIncome is not None:
            oprot.writeFieldBegin('grossCommissionIncome', TType.DOUBLE, 14)
            oprot.writeDouble(self.grossCommissionIncome)
            oprot.writeFieldEnd()
        if self.netCommissionIncome is not None:
            oprot.writeFieldBegin('netCommissionIncome', TType.DOUBLE, 15)
            oprot.writeDouble(self.netCommissionIncome)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 16)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.effectiveSplitsByAmaId is not None:
            oprot.writeFieldBegin('effectiveSplitsByAmaId', TType.MAP, 17)
            oprot.writeMapBegin(TType.STRING, TType.DOUBLE, len(self.effectiveSplitsByAmaId))
            for _kiter101, _viter102 in self.effectiveSplitsByAmaId.items():
                oprot.writeString(_kiter101.encode('utf-8') if sys.version_info[0] == 2 else _kiter101)
                oprot.writeDouble(_viter102)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralInfo(object):
    """
    Attributes:
     - referral_broker
     - gci
     - referral_fee
     - are_info
     - allocations
     - fees
     - dmsTransactionId
     - is_paid_at_table
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'referral_broker', (ReferralBroker, ReferralBroker.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'gci', (Gci, Gci.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'referral_fee', (ReferralFee, ReferralFee.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'are_info', (AreInfo, AreInfo.thrift_spec), None, ),  # 4
        (5, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 6
        (7, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'is_paid_at_table', None, None, ),  # 8
    )
    def __init__(self, referral_broker=None, gci=None, referral_fee=None, are_info=None, allocations=None, fees=None, dmsTransactionId=None, is_paid_at_table=None, ):
        self.referral_broker = referral_broker
        self.gci = gci
        self.referral_fee = referral_fee
        self.are_info = are_info
        self.allocations = allocations
        self.fees = fees
        self.dmsTransactionId = dmsTransactionId
        self.is_paid_at_table = is_paid_at_table

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.referral_broker = ReferralBroker()
                    self.referral_broker.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.gci = Gci()
                    self.gci.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.referral_fee = ReferralFee()
                    self.referral_fee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.are_info = AreInfo()
                    self.are_info.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype103, _size106) = iprot.readListBegin()
                    for _i104 in range(_size106):
                        _elem105 = Allocation()
                        _elem105.read(iprot)
                        self.allocations.append(_elem105)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype107, _size110) = iprot.readListBegin()
                    for _i108 in range(_size110):
                        _elem109 = Fee()
                        _elem109.read(iprot)
                        self.fees.append(_elem109)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.is_paid_at_table = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralInfo')
        if self.referral_broker is not None:
            oprot.writeFieldBegin('referral_broker', TType.STRUCT, 1)
            self.referral_broker.write(oprot)
            oprot.writeFieldEnd()
        if self.gci is not None:
            oprot.writeFieldBegin('gci', TType.STRUCT, 2)
            self.gci.write(oprot)
            oprot.writeFieldEnd()
        if self.referral_fee is not None:
            oprot.writeFieldBegin('referral_fee', TType.STRUCT, 3)
            self.referral_fee.write(oprot)
            oprot.writeFieldEnd()
        if self.are_info is not None:
            oprot.writeFieldBegin('are_info', TType.STRUCT, 4)
            self.are_info.write(oprot)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter111 in self.allocations:
                _iter111.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter112 in self.fees:
                _iter112.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 7)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.is_paid_at_table is not None:
            oprot.writeFieldBegin('is_paid_at_table', TType.BOOL, 8)
            oprot.writeBool(self.is_paid_at_table)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveCommissionResponseToNetsuiteRequest(object):
    """
    Attributes:
     - accountingResponse
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'accountingResponse', (AccountingResponse, AccountingResponse.thrift_spec), None, ),  # 1
    )
    def __init__(self, accountingResponse=None, ):
        self.accountingResponse = accountingResponse

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.accountingResponse = AccountingResponse()
                    self.accountingResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveCommissionResponseToNetsuiteRequest')
        if self.accountingResponse is not None:
            oprot.writeFieldBegin('accountingResponse', TType.STRUCT, 1)
            self.accountingResponse.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AreError(object):
    """
    Attributes:
     - errors
     - input
     - source_topic
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'errors', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRUCT, 'input', (CalculationResponse, CalculationResponse.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'source_topic', 'UTF8', None, ),  # 3
    )
    def __init__(self, errors=None, input=None, source_topic=None, ):
        self.errors = errors
        self.input = input
        self.source_topic = source_topic

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.errors = []
                    (_etype113, _size116) = iprot.readListBegin()
                    for _i114 in range(_size116):
                        _elem115 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors.append(_elem115)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.input = CalculationResponse()
                    self.input.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.source_topic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AreError')
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.errors))
            for _iter117 in self.errors:
                oprot.writeString(_iter117.encode('utf-8') if sys.version_info[0] == 2 else _iter117)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.input is not None:
            oprot.writeFieldBegin('input', TType.STRUCT, 2)
            self.input.write(oprot)
            oprot.writeFieldEnd()
        if self.source_topic is not None:
            oprot.writeFieldBegin('source_topic', TType.STRING, 3)
            oprot.writeString(self.source_topic.encode('utf-8') if sys.version_info[0] == 2 else self.source_topic)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculateCommissionInput(object):
    """
    Attributes:
     - request_uuid
     - deal_id
     - client_id
     - brokerage_id
     - close_price
     - broker_fee
     - ama
     - contract_id
     - is_tci
     - is_broker_account_split_applicable
     - gci
     - split_override
     - allocations
     - fees
     - are_info
     - parent_deal
     - contract_external_id
     - contract_start_date
     - contract_end_date
     - dmsTransactionId
     - deal_amas
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'request_uuid', 'UTF8', None, ),  # 1
        (2, TType.I32, 'deal_id', None, None, ),  # 2
        (3, TType.STRING, 'client_id', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'brokerage_id', 'UTF8', None, ),  # 4
        (5, TType.DOUBLE, 'close_price', None, None, ),  # 5
        (6, TType.STRUCT, 'broker_fee', (BrokerFee, BrokerFee.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'ama', (Ama, Ama.thrift_spec), None, ),  # 7
        (8, TType.STRING, 'contract_id', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'is_tci', None, None, ),  # 9
        (10, TType.BOOL, 'is_broker_account_split_applicable', None, None, ),  # 10
        (11, TType.STRUCT, 'gci', (Gci, Gci.thrift_spec), None, ),  # 11
        (12, TType.STRUCT, 'split_override', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 12
        (13, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 13
        (14, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 14
        (15, TType.STRUCT, 'are_info', (AreInfo, AreInfo.thrift_spec), None, ),  # 15
        (16, TType.I32, 'parent_deal', None, None, ),  # 16
        (17, TType.STRING, 'contract_external_id', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'contract_start_date', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'contract_end_date', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 20
        (21, TType.MAP, 'deal_amas', (TType.STRING, 'UTF8', TType.STRUCT, (Ama, Ama.thrift_spec), False), None, ),  # 21
    )
    def __init__(self, request_uuid=None, deal_id=None, client_id=None, brokerage_id=None, close_price=None, broker_fee=None, ama=None, contract_id=None, is_tci=None, is_broker_account_split_applicable=None, gci=None, split_override=None, allocations=None, fees=None, are_info=None, parent_deal=None, contract_external_id=None, contract_start_date=None, contract_end_date=None, dmsTransactionId=None, deal_amas=None, ):
        self.request_uuid = request_uuid
        self.deal_id = deal_id
        self.client_id = client_id
        self.brokerage_id = brokerage_id
        self.close_price = close_price
        self.broker_fee = broker_fee
        self.ama = ama
        self.contract_id = contract_id
        self.is_tci = is_tci
        self.is_broker_account_split_applicable = is_broker_account_split_applicable
        self.gci = gci
        self.split_override = split_override
        self.allocations = allocations
        self.fees = fees
        self.are_info = are_info
        self.parent_deal = parent_deal
        self.contract_external_id = contract_external_id
        self.contract_start_date = contract_start_date
        self.contract_end_date = contract_end_date
        self.dmsTransactionId = dmsTransactionId
        self.deal_amas = deal_amas

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.request_uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.deal_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.client_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.brokerage_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.close_price = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.broker_fee = BrokerFee()
                    self.broker_fee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.ama = Ama()
                    self.ama.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.contract_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.is_tci = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.is_broker_account_split_applicable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.gci = Gci()
                    self.gci.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.split_override = SplitOverride()
                    self.split_override.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype118, _size121) = iprot.readListBegin()
                    for _i119 in range(_size121):
                        _elem120 = Allocation()
                        _elem120.read(iprot)
                        self.allocations.append(_elem120)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype122, _size125) = iprot.readListBegin()
                    for _i123 in range(_size125):
                        _elem124 = Fee()
                        _elem124.read(iprot)
                        self.fees.append(_elem124)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.are_info = AreInfo()
                    self.are_info.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.parent_deal = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.contract_external_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.contract_start_date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.contract_end_date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.MAP:
                    self.deal_amas = {}
                    (_ktype127, _vtype128, _size131) = iprot.readMapBegin()
                    for _i126 in range(_size131):
                        _key129 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val130 = Ama()
                        _val130.read(iprot)
                        self.deal_amas[_key129] = _val130
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculateCommissionInput')
        if self.request_uuid is not None:
            oprot.writeFieldBegin('request_uuid', TType.STRING, 1)
            oprot.writeString(self.request_uuid.encode('utf-8') if sys.version_info[0] == 2 else self.request_uuid)
            oprot.writeFieldEnd()
        if self.deal_id is not None:
            oprot.writeFieldBegin('deal_id', TType.I32, 2)
            oprot.writeI32(self.deal_id)
            oprot.writeFieldEnd()
        if self.client_id is not None:
            oprot.writeFieldBegin('client_id', TType.STRING, 3)
            oprot.writeString(self.client_id.encode('utf-8') if sys.version_info[0] == 2 else self.client_id)
            oprot.writeFieldEnd()
        if self.brokerage_id is not None:
            oprot.writeFieldBegin('brokerage_id', TType.STRING, 4)
            oprot.writeString(self.brokerage_id.encode('utf-8') if sys.version_info[0] == 2 else self.brokerage_id)
            oprot.writeFieldEnd()
        if self.close_price is not None:
            oprot.writeFieldBegin('close_price', TType.DOUBLE, 5)
            oprot.writeDouble(self.close_price)
            oprot.writeFieldEnd()
        if self.broker_fee is not None:
            oprot.writeFieldBegin('broker_fee', TType.STRUCT, 6)
            self.broker_fee.write(oprot)
            oprot.writeFieldEnd()
        if self.ama is not None:
            oprot.writeFieldBegin('ama', TType.STRUCT, 7)
            self.ama.write(oprot)
            oprot.writeFieldEnd()
        if self.contract_id is not None:
            oprot.writeFieldBegin('contract_id', TType.STRING, 8)
            oprot.writeString(self.contract_id.encode('utf-8') if sys.version_info[0] == 2 else self.contract_id)
            oprot.writeFieldEnd()
        if self.is_tci is not None:
            oprot.writeFieldBegin('is_tci', TType.BOOL, 9)
            oprot.writeBool(self.is_tci)
            oprot.writeFieldEnd()
        if self.is_broker_account_split_applicable is not None:
            oprot.writeFieldBegin('is_broker_account_split_applicable', TType.BOOL, 10)
            oprot.writeBool(self.is_broker_account_split_applicable)
            oprot.writeFieldEnd()
        if self.gci is not None:
            oprot.writeFieldBegin('gci', TType.STRUCT, 11)
            self.gci.write(oprot)
            oprot.writeFieldEnd()
        if self.split_override is not None:
            oprot.writeFieldBegin('split_override', TType.STRUCT, 12)
            self.split_override.write(oprot)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 13)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter132 in self.allocations:
                _iter132.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 14)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter133 in self.fees:
                _iter133.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.are_info is not None:
            oprot.writeFieldBegin('are_info', TType.STRUCT, 15)
            self.are_info.write(oprot)
            oprot.writeFieldEnd()
        if self.parent_deal is not None:
            oprot.writeFieldBegin('parent_deal', TType.I32, 16)
            oprot.writeI32(self.parent_deal)
            oprot.writeFieldEnd()
        if self.contract_external_id is not None:
            oprot.writeFieldBegin('contract_external_id', TType.STRING, 17)
            oprot.writeString(self.contract_external_id.encode('utf-8') if sys.version_info[0] == 2 else self.contract_external_id)
            oprot.writeFieldEnd()
        if self.contract_start_date is not None:
            oprot.writeFieldBegin('contract_start_date', TType.STRING, 18)
            oprot.writeString(self.contract_start_date.encode('utf-8') if sys.version_info[0] == 2 else self.contract_start_date)
            oprot.writeFieldEnd()
        if self.contract_end_date is not None:
            oprot.writeFieldBegin('contract_end_date', TType.STRING, 19)
            oprot.writeString(self.contract_end_date.encode('utf-8') if sys.version_info[0] == 2 else self.contract_end_date)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 20)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.deal_amas is not None:
            oprot.writeFieldBegin('deal_amas', TType.MAP, 21)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.deal_amas))
            for _kiter134, _viter135 in self.deal_amas.items():
                oprot.writeString(_kiter134.encode('utf-8') if sys.version_info[0] == 2 else _kiter134)
                _viter135.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculateCommissionPreviewRequest(object):
    """
    Attributes:
     - dealId
     - brokerageId
     - closeDate
     - closePrice
     - brokerFeePercent
     - brokerFeeAmount
     - amaId
     - isBrokerAccountSplitApplicable
     - splitOverride
     - allocations
     - fees
     - uuid
     - ama
     - teamId
     - gci
     - commissionableTerms
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'dealId', None, None, ),  # 1
        (2, TType.STRING, 'brokerageId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'closeDate', 'UTF8', None, ),  # 3
        (4, TType.DOUBLE, 'closePrice', None, None, ),  # 4
        (5, TType.DOUBLE, 'brokerFeePercent', None, None, ),  # 5
        (6, TType.DOUBLE, 'brokerFeeAmount', None, None, ),  # 6
        (7, TType.STRING, 'amaId', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isBrokerAccountSplitApplicable', None, None, ),  # 8
        (9, TType.STRUCT, 'splitOverride', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 9
        (10, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 10
        (11, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 11
        (12, TType.STRING, 'uuid', 'UTF8', None, ),  # 12
        (13, TType.STRUCT, 'ama', (Ama, Ama.thrift_spec), None, ),  # 13
        (14, TType.STRING, 'teamId', 'UTF8', None, ),  # 14
        (15, TType.STRUCT, 'gci', (Gci, Gci.thrift_spec), None, ),  # 15
        (16, TType.STRUCT, 'commissionableTerms', (gen.urbancompass.agent_data_platform.commissionable_terms.model.comm_terms.ttypes.CommissionableTerms, gen.urbancompass.agent_data_platform.commissionable_terms.model.comm_terms.ttypes.CommissionableTerms.thrift_spec), None, ),  # 16
    )
    def __init__(self, dealId=None, brokerageId=None, closeDate=None, closePrice=None, brokerFeePercent=None, brokerFeeAmount=None, amaId=None, isBrokerAccountSplitApplicable=None, splitOverride=None, allocations=None, fees=None, uuid=None, ama=None, teamId=None, gci=None, commissionableTerms=None, ):
        self.dealId = dealId
        self.brokerageId = brokerageId
        self.closeDate = closeDate
        self.closePrice = closePrice
        self.brokerFeePercent = brokerFeePercent
        self.brokerFeeAmount = brokerFeeAmount
        self.amaId = amaId
        self.isBrokerAccountSplitApplicable = isBrokerAccountSplitApplicable
        self.splitOverride = splitOverride
        self.allocations = allocations
        self.fees = fees
        self.uuid = uuid
        self.ama = ama
        self.teamId = teamId
        self.gci = gci
        self.commissionableTerms = commissionableTerms

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.dealId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.brokerageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.brokerFeePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.brokerFeeAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isBrokerAccountSplitApplicable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.splitOverride = SplitOverride()
                    self.splitOverride.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype136, _size139) = iprot.readListBegin()
                    for _i137 in range(_size139):
                        _elem138 = Allocation()
                        _elem138.read(iprot)
                        self.allocations.append(_elem138)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype140, _size143) = iprot.readListBegin()
                    for _i141 in range(_size143):
                        _elem142 = Fee()
                        _elem142.read(iprot)
                        self.fees.append(_elem142)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.ama = Ama()
                    self.ama.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.gci = Gci()
                    self.gci.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.commissionableTerms = gen.urbancompass.agent_data_platform.commissionable_terms.model.comm_terms.ttypes.CommissionableTerms()
                    self.commissionableTerms.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculateCommissionPreviewRequest')
        if self.dealId is not None:
            oprot.writeFieldBegin('dealId', TType.I32, 1)
            oprot.writeI32(self.dealId)
            oprot.writeFieldEnd()
        if self.brokerageId is not None:
            oprot.writeFieldBegin('brokerageId', TType.STRING, 2)
            oprot.writeString(self.brokerageId.encode('utf-8') if sys.version_info[0] == 2 else self.brokerageId)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 3)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 4)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.brokerFeePercent is not None:
            oprot.writeFieldBegin('brokerFeePercent', TType.DOUBLE, 5)
            oprot.writeDouble(self.brokerFeePercent)
            oprot.writeFieldEnd()
        if self.brokerFeeAmount is not None:
            oprot.writeFieldBegin('brokerFeeAmount', TType.DOUBLE, 6)
            oprot.writeDouble(self.brokerFeeAmount)
            oprot.writeFieldEnd()
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 7)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.isBrokerAccountSplitApplicable is not None:
            oprot.writeFieldBegin('isBrokerAccountSplitApplicable', TType.BOOL, 8)
            oprot.writeBool(self.isBrokerAccountSplitApplicable)
            oprot.writeFieldEnd()
        if self.splitOverride is not None:
            oprot.writeFieldBegin('splitOverride', TType.STRUCT, 9)
            self.splitOverride.write(oprot)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter144 in self.allocations:
                _iter144.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter145 in self.fees:
                _iter145.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.uuid is not None:
            oprot.writeFieldBegin('uuid', TType.STRING, 12)
            oprot.writeString(self.uuid.encode('utf-8') if sys.version_info[0] == 2 else self.uuid)
            oprot.writeFieldEnd()
        if self.ama is not None:
            oprot.writeFieldBegin('ama', TType.STRUCT, 13)
            self.ama.write(oprot)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 14)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.gci is not None:
            oprot.writeFieldBegin('gci', TType.STRUCT, 15)
            self.gci.write(oprot)
            oprot.writeFieldEnd()
        if self.commissionableTerms is not None:
            oprot.writeFieldBegin('commissionableTerms', TType.STRUCT, 16)
            self.commissionableTerms.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculateCommissionRequest(object):
    """
    Attributes:
     - request_uuid
     - deal_id
     - brokerage_id
     - client_id
     - close_date
     - close_price
     - broker_fee_percent
     - broker_fee_amount
     - ama_id
     - is_tci
     - is_broker_account_split_applicable
     - gci
     - split_override
     - allocations
     - fees
     - are_info
     - parent_deal
     - onlyPreview
     - referral_infos
     - hamptons_listing_infos
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'request_uuid', 'UTF8', None, ),  # 1
        (2, TType.I32, 'deal_id', None, None, ),  # 2
        (3, TType.STRING, 'brokerage_id', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'client_id', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'close_date', 'UTF8', None, ),  # 5
        (6, TType.DOUBLE, 'close_price', None, None, ),  # 6
        (7, TType.DOUBLE, 'broker_fee_percent', None, None, ),  # 7
        (8, TType.DOUBLE, 'broker_fee_amount', None, None, ),  # 8
        (9, TType.STRING, 'ama_id', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'is_tci', None, None, ),  # 10
        (11, TType.BOOL, 'is_broker_account_split_applicable', None, None, ),  # 11
        (12, TType.STRUCT, 'gci', (Gci, Gci.thrift_spec), None, ),  # 12
        (13, TType.STRUCT, 'split_override', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 13
        (14, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 14
        (15, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 15
        (16, TType.STRUCT, 'are_info', (AreInfo, AreInfo.thrift_spec), None, ),  # 16
        (17, TType.I32, 'parent_deal', None, None, ),  # 17
        (18, TType.BOOL, 'onlyPreview', None, None, ),  # 18
        (19, TType.LIST, 'referral_infos', (TType.STRUCT, (ReferralInfo, ReferralInfo.thrift_spec), False), None, ),  # 19
        (20, TType.LIST, 'hamptons_listing_infos', (TType.STRUCT, (ReferralInfo, ReferralInfo.thrift_spec), False), None, ),  # 20
        (21, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 21
    )
    def __init__(self, request_uuid=None, deal_id=None, brokerage_id=None, client_id=None, close_date=None, close_price=None, broker_fee_percent=None, broker_fee_amount=None, ama_id=None, is_tci=None, is_broker_account_split_applicable=None, gci=None, split_override=None, allocations=None, fees=None, are_info=None, parent_deal=None, onlyPreview=None, referral_infos=None, hamptons_listing_infos=None, dmsTransactionId=None, ):
        self.request_uuid = request_uuid
        self.deal_id = deal_id
        self.brokerage_id = brokerage_id
        self.client_id = client_id
        self.close_date = close_date
        self.close_price = close_price
        self.broker_fee_percent = broker_fee_percent
        self.broker_fee_amount = broker_fee_amount
        self.ama_id = ama_id
        self.is_tci = is_tci
        self.is_broker_account_split_applicable = is_broker_account_split_applicable
        self.gci = gci
        self.split_override = split_override
        self.allocations = allocations
        self.fees = fees
        self.are_info = are_info
        self.parent_deal = parent_deal
        self.onlyPreview = onlyPreview
        self.referral_infos = referral_infos
        self.hamptons_listing_infos = hamptons_listing_infos
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.request_uuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.deal_id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.brokerage_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.client_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.close_date = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.close_price = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.broker_fee_percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.DOUBLE:
                    self.broker_fee_amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.ama_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.is_tci = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.is_broker_account_split_applicable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.gci = Gci()
                    self.gci.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.split_override = SplitOverride()
                    self.split_override.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype146, _size149) = iprot.readListBegin()
                    for _i147 in range(_size149):
                        _elem148 = Allocation()
                        _elem148.read(iprot)
                        self.allocations.append(_elem148)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype150, _size153) = iprot.readListBegin()
                    for _i151 in range(_size153):
                        _elem152 = Fee()
                        _elem152.read(iprot)
                        self.fees.append(_elem152)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.are_info = AreInfo()
                    self.are_info.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.parent_deal = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.onlyPreview = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.LIST:
                    self.referral_infos = []
                    (_etype154, _size157) = iprot.readListBegin()
                    for _i155 in range(_size157):
                        _elem156 = ReferralInfo()
                        _elem156.read(iprot)
                        self.referral_infos.append(_elem156)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.hamptons_listing_infos = []
                    (_etype158, _size161) = iprot.readListBegin()
                    for _i159 in range(_size161):
                        _elem160 = ReferralInfo()
                        _elem160.read(iprot)
                        self.hamptons_listing_infos.append(_elem160)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculateCommissionRequest')
        if self.request_uuid is not None:
            oprot.writeFieldBegin('request_uuid', TType.STRING, 1)
            oprot.writeString(self.request_uuid.encode('utf-8') if sys.version_info[0] == 2 else self.request_uuid)
            oprot.writeFieldEnd()
        if self.deal_id is not None:
            oprot.writeFieldBegin('deal_id', TType.I32, 2)
            oprot.writeI32(self.deal_id)
            oprot.writeFieldEnd()
        if self.brokerage_id is not None:
            oprot.writeFieldBegin('brokerage_id', TType.STRING, 3)
            oprot.writeString(self.brokerage_id.encode('utf-8') if sys.version_info[0] == 2 else self.brokerage_id)
            oprot.writeFieldEnd()
        if self.client_id is not None:
            oprot.writeFieldBegin('client_id', TType.STRING, 4)
            oprot.writeString(self.client_id.encode('utf-8') if sys.version_info[0] == 2 else self.client_id)
            oprot.writeFieldEnd()
        if self.close_date is not None:
            oprot.writeFieldBegin('close_date', TType.STRING, 5)
            oprot.writeString(self.close_date.encode('utf-8') if sys.version_info[0] == 2 else self.close_date)
            oprot.writeFieldEnd()
        if self.close_price is not None:
            oprot.writeFieldBegin('close_price', TType.DOUBLE, 6)
            oprot.writeDouble(self.close_price)
            oprot.writeFieldEnd()
        if self.broker_fee_percent is not None:
            oprot.writeFieldBegin('broker_fee_percent', TType.DOUBLE, 7)
            oprot.writeDouble(self.broker_fee_percent)
            oprot.writeFieldEnd()
        if self.broker_fee_amount is not None:
            oprot.writeFieldBegin('broker_fee_amount', TType.DOUBLE, 8)
            oprot.writeDouble(self.broker_fee_amount)
            oprot.writeFieldEnd()
        if self.ama_id is not None:
            oprot.writeFieldBegin('ama_id', TType.STRING, 9)
            oprot.writeString(self.ama_id.encode('utf-8') if sys.version_info[0] == 2 else self.ama_id)
            oprot.writeFieldEnd()
        if self.is_tci is not None:
            oprot.writeFieldBegin('is_tci', TType.BOOL, 10)
            oprot.writeBool(self.is_tci)
            oprot.writeFieldEnd()
        if self.is_broker_account_split_applicable is not None:
            oprot.writeFieldBegin('is_broker_account_split_applicable', TType.BOOL, 11)
            oprot.writeBool(self.is_broker_account_split_applicable)
            oprot.writeFieldEnd()
        if self.gci is not None:
            oprot.writeFieldBegin('gci', TType.STRUCT, 12)
            self.gci.write(oprot)
            oprot.writeFieldEnd()
        if self.split_override is not None:
            oprot.writeFieldBegin('split_override', TType.STRUCT, 13)
            self.split_override.write(oprot)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 14)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter162 in self.allocations:
                _iter162.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter163 in self.fees:
                _iter163.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.are_info is not None:
            oprot.writeFieldBegin('are_info', TType.STRUCT, 16)
            self.are_info.write(oprot)
            oprot.writeFieldEnd()
        if self.parent_deal is not None:
            oprot.writeFieldBegin('parent_deal', TType.I32, 17)
            oprot.writeI32(self.parent_deal)
            oprot.writeFieldEnd()
        if self.onlyPreview is not None:
            oprot.writeFieldBegin('onlyPreview', TType.BOOL, 18)
            oprot.writeBool(self.onlyPreview)
            oprot.writeFieldEnd()
        if self.referral_infos is not None:
            oprot.writeFieldBegin('referral_infos', TType.LIST, 19)
            oprot.writeListBegin(TType.STRUCT, len(self.referral_infos))
            for _iter164 in self.referral_infos:
                _iter164.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hamptons_listing_infos is not None:
            oprot.writeFieldBegin('hamptons_listing_infos', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.hamptons_listing_infos))
            for _iter165 in self.hamptons_listing_infos:
                _iter165.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 21)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AccountingFullResponse(object):
    """
    Attributes:
     - accountingSuccessfulResponse
     - areError
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'accountingSuccessfulResponse', (AccountingResponse, AccountingResponse.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'areError', (AreError, AreError.thrift_spec), None, ),  # 2
    )
    def __init__(self, accountingSuccessfulResponse=None, areError=None, ):
        self.accountingSuccessfulResponse = accountingSuccessfulResponse
        self.areError = areError

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.accountingSuccessfulResponse = AccountingResponse()
                    self.accountingSuccessfulResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.areError = AreError()
                    self.areError.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountingFullResponse')
        if self.accountingSuccessfulResponse is not None:
            oprot.writeFieldBegin('accountingSuccessfulResponse', TType.STRUCT, 1)
            self.accountingSuccessfulResponse.write(oprot)
            oprot.writeFieldEnd()
        if self.areError is not None:
            oprot.writeFieldBegin('areError', TType.STRUCT, 2)
            self.areError.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CceError(object):
    """
    Attributes:
     - errors
     - input
     - source_topic
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'errors', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRUCT, 'input', (CalculateCommissionInput, CalculateCommissionInput.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'source_topic', 'UTF8', None, ),  # 3
    )
    def __init__(self, errors=None, input=None, source_topic=None, ):
        self.errors = errors
        self.input = input
        self.source_topic = source_topic

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.errors = []
                    (_etype166, _size169) = iprot.readListBegin()
                    for _i167 in range(_size169):
                        _elem168 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors.append(_elem168)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.input = CalculateCommissionInput()
                    self.input.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.source_topic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CceError')
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.errors))
            for _iter170 in self.errors:
                oprot.writeString(_iter170.encode('utf-8') if sys.version_info[0] == 2 else _iter170)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.input is not None:
            oprot.writeFieldBegin('input', TType.STRUCT, 2)
            self.input.write(oprot)
            oprot.writeFieldEnd()
        if self.source_topic is not None:
            oprot.writeFieldBegin('source_topic', TType.STRING, 3)
            oprot.writeString(self.source_topic.encode('utf-8') if sys.version_info[0] == 2 else self.source_topic)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculateCommissionPreviewResponse(object):
    """
    Attributes:
     - status
     - brokerFeePercent
     - brokerFeeAmount
     - grossCommissionIncome
     - agentSplitAmount
     - netCommissionIncome
     - fees
     - effectiveSplit
     - isBlended
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.DOUBLE, 'brokerFeePercent', None, None, ),  # 2
        (3, TType.DOUBLE, 'brokerFeeAmount', None, None, ),  # 3
        (4, TType.DOUBLE, 'grossCommissionIncome', None, None, ),  # 4
        (5, TType.DOUBLE, 'agentSplitAmount', None, None, ),  # 5
        (6, TType.DOUBLE, 'netCommissionIncome', None, None, ),  # 6
        (7, TType.LIST, 'fees', (TType.STRUCT, (AgentFee, AgentFee.thrift_spec), False), None, ),  # 7
        (8, TType.STRUCT, 'error', (CceError, CceError.thrift_spec), None, ),  # 8
        (9, TType.DOUBLE, 'effectiveSplit', None, None, ),  # 9
        (10, TType.BOOL, 'isBlended', None, None, ),  # 10
    )
    def __init__(self, status=None, brokerFeePercent=None, brokerFeeAmount=None, grossCommissionIncome=None, agentSplitAmount=None, netCommissionIncome=None, fees=None, error=None, effectiveSplit=None, isBlended=None, ):
        self.status = status
        self.brokerFeePercent = brokerFeePercent
        self.brokerFeeAmount = brokerFeeAmount
        self.grossCommissionIncome = grossCommissionIncome
        self.agentSplitAmount = agentSplitAmount
        self.netCommissionIncome = netCommissionIncome
        self.fees = fees
        self.error = error
        self.effectiveSplit = effectiveSplit
        self.isBlended = isBlended

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.brokerFeePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.brokerFeeAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.grossCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.agentSplitAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.netCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype171, _size174) = iprot.readListBegin()
                    for _i172 in range(_size174):
                        _elem173 = AgentFee()
                        _elem173.read(iprot)
                        self.fees.append(_elem173)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.error = CceError()
                    self.error.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.effectiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isBlended = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculateCommissionPreviewResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.brokerFeePercent is not None:
            oprot.writeFieldBegin('brokerFeePercent', TType.DOUBLE, 2)
            oprot.writeDouble(self.brokerFeePercent)
            oprot.writeFieldEnd()
        if self.brokerFeeAmount is not None:
            oprot.writeFieldBegin('brokerFeeAmount', TType.DOUBLE, 3)
            oprot.writeDouble(self.brokerFeeAmount)
            oprot.writeFieldEnd()
        if self.grossCommissionIncome is not None:
            oprot.writeFieldBegin('grossCommissionIncome', TType.DOUBLE, 4)
            oprot.writeDouble(self.grossCommissionIncome)
            oprot.writeFieldEnd()
        if self.agentSplitAmount is not None:
            oprot.writeFieldBegin('agentSplitAmount', TType.DOUBLE, 5)
            oprot.writeDouble(self.agentSplitAmount)
            oprot.writeFieldEnd()
        if self.netCommissionIncome is not None:
            oprot.writeFieldBegin('netCommissionIncome', TType.DOUBLE, 6)
            oprot.writeDouble(self.netCommissionIncome)
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter175 in self.fees:
                _iter175.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRUCT, 8)
            self.error.write(oprot)
            oprot.writeFieldEnd()
        if self.effectiveSplit is not None:
            oprot.writeFieldBegin('effectiveSplit', TType.DOUBLE, 9)
            oprot.writeDouble(self.effectiveSplit)
            oprot.writeFieldEnd()
        if self.isBlended is not None:
            oprot.writeFieldBegin('isBlended', TType.BOOL, 10)
            oprot.writeBool(self.isBlended)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculationFullResponse(object):
    """
    Attributes:
     - calculationSuccessfulResponse
     - calculationError
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'calculationSuccessfulResponse', (CalculationResponse, CalculationResponse.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'calculationError', (CceError, CceError.thrift_spec), None, ),  # 2
    )
    def __init__(self, calculationSuccessfulResponse=None, calculationError=None, ):
        self.calculationSuccessfulResponse = calculationSuccessfulResponse
        self.calculationError = calculationError

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.calculationSuccessfulResponse = CalculationResponse()
                    self.calculationSuccessfulResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.calculationError = CceError()
                    self.calculationError.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculationFullResponse')
        if self.calculationSuccessfulResponse is not None:
            oprot.writeFieldBegin('calculationSuccessfulResponse', TType.STRUCT, 1)
            self.calculationSuccessfulResponse.write(oprot)
            oprot.writeFieldEnd()
        if self.calculationError is not None:
            oprot.writeFieldBegin('calculationError', TType.STRUCT, 2)
            self.calculationError.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CalculateCommissionResponse(object):
    """
    Attributes:
     - calculateCommissionInput
     - status
     - calculationResponse
     - accountingResponse
     - referralCalculationResponses
     - referralAccountingResponses
     - compassLeadCalculationResponse
     - compassLeadAccountingResponse
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'calculateCommissionInput', (CalculateCommissionInput, CalculateCommissionInput.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'calculationResponse', (CalculationFullResponse, CalculationFullResponse.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'accountingResponse', (AccountingFullResponse, AccountingFullResponse.thrift_spec), None, ),  # 4
        (5, TType.LIST, 'referralCalculationResponses', (TType.STRUCT, (CalculationFullResponse, CalculationFullResponse.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'referralAccountingResponses', (TType.STRUCT, (AccountingFullResponse, AccountingFullResponse.thrift_spec), False), None, ),  # 6
        (7, TType.STRUCT, 'compassLeadCalculationResponse', (CalculationFullResponse, CalculationFullResponse.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'compassLeadAccountingResponse', (AccountingFullResponse, AccountingFullResponse.thrift_spec), None, ),  # 8
    )
    def __init__(self, calculateCommissionInput=None, status=None, calculationResponse=None, accountingResponse=None, referralCalculationResponses=None, referralAccountingResponses=None, compassLeadCalculationResponse=None, compassLeadAccountingResponse=None, ):
        self.calculateCommissionInput = calculateCommissionInput
        self.status = status
        self.calculationResponse = calculationResponse
        self.accountingResponse = accountingResponse
        self.referralCalculationResponses = referralCalculationResponses
        self.referralAccountingResponses = referralAccountingResponses
        self.compassLeadCalculationResponse = compassLeadCalculationResponse
        self.compassLeadAccountingResponse = compassLeadAccountingResponse

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.calculateCommissionInput = CalculateCommissionInput()
                    self.calculateCommissionInput.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.calculationResponse = CalculationFullResponse()
                    self.calculationResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.accountingResponse = AccountingFullResponse()
                    self.accountingResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.referralCalculationResponses = []
                    (_etype176, _size179) = iprot.readListBegin()
                    for _i177 in range(_size179):
                        _elem178 = CalculationFullResponse()
                        _elem178.read(iprot)
                        self.referralCalculationResponses.append(_elem178)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.referralAccountingResponses = []
                    (_etype180, _size183) = iprot.readListBegin()
                    for _i181 in range(_size183):
                        _elem182 = AccountingFullResponse()
                        _elem182.read(iprot)
                        self.referralAccountingResponses.append(_elem182)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.compassLeadCalculationResponse = CalculationFullResponse()
                    self.compassLeadCalculationResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.compassLeadAccountingResponse = AccountingFullResponse()
                    self.compassLeadAccountingResponse.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CalculateCommissionResponse')
        if self.calculateCommissionInput is not None:
            oprot.writeFieldBegin('calculateCommissionInput', TType.STRUCT, 1)
            self.calculateCommissionInput.write(oprot)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 2)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.calculationResponse is not None:
            oprot.writeFieldBegin('calculationResponse', TType.STRUCT, 3)
            self.calculationResponse.write(oprot)
            oprot.writeFieldEnd()
        if self.accountingResponse is not None:
            oprot.writeFieldBegin('accountingResponse', TType.STRUCT, 4)
            self.accountingResponse.write(oprot)
            oprot.writeFieldEnd()
        if self.referralCalculationResponses is not None:
            oprot.writeFieldBegin('referralCalculationResponses', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.referralCalculationResponses))
            for _iter184 in self.referralCalculationResponses:
                _iter184.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.referralAccountingResponses is not None:
            oprot.writeFieldBegin('referralAccountingResponses', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.referralAccountingResponses))
            for _iter185 in self.referralAccountingResponses:
                _iter185.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.compassLeadCalculationResponse is not None:
            oprot.writeFieldBegin('compassLeadCalculationResponse', TType.STRUCT, 7)
            self.compassLeadCalculationResponse.write(oprot)
            oprot.writeFieldEnd()
        if self.compassLeadAccountingResponse is not None:
            oprot.writeFieldBegin('compassLeadAccountingResponse', TType.STRUCT, 8)
            self.compassLeadAccountingResponse.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
