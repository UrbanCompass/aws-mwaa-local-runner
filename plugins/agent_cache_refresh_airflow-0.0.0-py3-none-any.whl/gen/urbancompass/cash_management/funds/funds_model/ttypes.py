
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals_platform.common.netsuite_model.ttypes

from thrift.transport import TTransport


class FundSyncStatusCode(object):
    SUCCESS = 0
    FAILURE_GENERIC = 1

    _VALUES_TO_NAMES = {
        0: "SUCCESS",
        1: "FAILURE_GENERIC",
    }

    _NAMES_TO_VALUES = {
        "SUCCESS": 0,
        "FAILURE_GENERIC": 1,
    }


class FundType(object):
    CHECK = 0
    ACH = 1
    WIRE = 2

    _VALUES_TO_NAMES = {
        0: "CHECK",
        1: "ACH",
        2: "WIRE",
    }

    _NAMES_TO_VALUES = {
        "CHECK": 0,
        "ACH": 1,
        "WIRE": 2,
    }


class BankAccount(object):
    """
    Attributes:
     - routingNumber
     - accountNumber
     - subsidiary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'routingNumber', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'accountNumber', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'subsidiary', (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteSubsidiary, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteSubsidiary.thrift_spec), None, ),  # 3
    )
    def __init__(self, routingNumber=None, accountNumber=None, subsidiary=None, ):
        self.routingNumber = routingNumber
        self.accountNumber = accountNumber
        self.subsidiary = subsidiary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.routingNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.accountNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.subsidiary = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetsuiteSubsidiary()
                    self.subsidiary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BankAccount')
        if self.routingNumber is not None:
            oprot.writeFieldBegin('routingNumber', TType.STRING, 1)
            oprot.writeString(self.routingNumber.encode('utf-8') if sys.version_info[0] == 2 else self.routingNumber)
            oprot.writeFieldEnd()
        if self.accountNumber is not None:
            oprot.writeFieldBegin('accountNumber', TType.STRING, 2)
            oprot.writeString(self.accountNumber.encode('utf-8') if sys.version_info[0] == 2 else self.accountNumber)
            oprot.writeFieldEnd()
        if self.subsidiary is not None:
            oprot.writeFieldBegin('subsidiary', TType.STRUCT, 3)
            self.subsidiary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FundAllocation(object):
    """
    Attributes:
     - dmsTransactionId
     - amount
     - fundId
     - updatedBy
     - updatedTimestamp
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.STRING, 'fundId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 4
        (5, TType.I64, 'updatedTimestamp', None, None, ),  # 5
        (6, TType.BOOL, 'isDeleted', None, None, ),  # 6
    )
    def __init__(self, dmsTransactionId=None, amount=None, fundId=None, updatedBy=None, updatedTimestamp=None, isDeleted=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.amount = amount
        self.fundId = fundId
        self.updatedBy = updatedBy
        self.updatedTimestamp = updatedTimestamp
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.fundId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.updatedTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FundAllocation')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.fundId is not None:
            oprot.writeFieldBegin('fundId', TType.STRING, 3)
            oprot.writeString(self.fundId.encode('utf-8') if sys.version_info[0] == 2 else self.fundId)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 4)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        if self.updatedTimestamp is not None:
            oprot.writeFieldBegin('updatedTimestamp', TType.I64, 5)
            oprot.writeI64(self.updatedTimestamp)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 6)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FundNotes(object):
    """
    Attributes:
     - address
     - agentName
     - misc
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'address', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'agentName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'misc', 'UTF8', None, ),  # 3
    )
    def __init__(self, address=None, agentName=None, misc=None, ):
        self.address = address
        self.agentName = agentName
        self.misc = misc

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.misc = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FundNotes')
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 1)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 2)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.misc is not None:
            oprot.writeFieldBegin('misc', TType.STRING, 3)
            oprot.writeString(self.misc.encode('utf-8') if sys.version_info[0] == 2 else self.misc)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FundSyncState(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'status', None, None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FundSyncState')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 1)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EnrichedFundInfo(object):
    """
    Attributes:
     - notes
     - updatedBy
     - updatedTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'notes', (FundNotes, FundNotes.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 2
        (3, TType.I64, 'updatedTimestamp', None, None, ),  # 3
    )
    def __init__(self, notes=None, updatedBy=None, updatedTimestamp=None, ):
        self.notes = notes
        self.updatedBy = updatedBy
        self.updatedTimestamp = updatedTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.notes = FundNotes()
                    self.notes.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichedFundInfo')
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRUCT, 1)
            self.notes.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 2)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        if self.updatedTimestamp is not None:
            oprot.writeFieldBegin('updatedTimestamp', TType.I64, 3)
            oprot.writeI64(self.updatedTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FundAllocations(object):
    """
    Attributes:
     - allocations
     - fundVersion
     - remainingAmount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'allocations', (TType.STRUCT, (FundAllocation, FundAllocation.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'fundVersion', None, None, ),  # 2
        (3, TType.DOUBLE, 'remainingAmount', None, None, ),  # 3
    )
    def __init__(self, allocations=None, fundVersion=None, remainingAmount=None, ):
        self.allocations = allocations
        self.fundVersion = fundVersion
        self.remainingAmount = remainingAmount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = FundAllocation()
                        _elem4.read(iprot)
                        self.allocations.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.fundVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.remainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FundAllocations')
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter6 in self.allocations:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fundVersion is not None:
            oprot.writeFieldBegin('fundVersion', TType.I32, 2)
            oprot.writeI32(self.fundVersion)
            oprot.writeFieldEnd()
        if self.remainingAmount is not None:
            oprot.writeFieldBegin('remainingAmount', TType.DOUBLE, 3)
            oprot.writeDouble(self.remainingAmount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FundDetails(object):
    """
    Attributes:
     - type
     - amount
     - memo
     - externalReferenceNumber
     - externalFundId
     - remitter
     - depositAccount
     - depositDate
     - fullAddress
     - isBounced
     - lockboxNumber
     - batchNumber
     - remitterName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.STRING, 'memo', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'externalReferenceNumber', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'externalFundId', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'remitter', (BankAccount, BankAccount.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'depositAccount', (BankAccount, BankAccount.thrift_spec), None, ),  # 7
        (8, TType.STRING, 'depositDate', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'fullAddress', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'isBounced', None, None, ),  # 10
        (11, TType.STRING, 'lockboxNumber', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'batchNumber', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'remitterName', 'UTF8', None, ),  # 13
    )
    def __init__(self, type=None, amount=None, memo=None, externalReferenceNumber=None, externalFundId=None, remitter=None, depositAccount=None, depositDate=None, fullAddress=None, isBounced=None, lockboxNumber=None, batchNumber=None, remitterName=None, ):
        self.type = type
        self.amount = amount
        self.memo = memo
        self.externalReferenceNumber = externalReferenceNumber
        self.externalFundId = externalFundId
        self.remitter = remitter
        self.depositAccount = depositAccount
        self.depositDate = depositDate
        self.fullAddress = fullAddress
        self.isBounced = isBounced
        self.lockboxNumber = lockboxNumber
        self.batchNumber = batchNumber
        self.remitterName = remitterName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.memo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.externalReferenceNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.externalFundId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.remitter = BankAccount()
                    self.remitter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.depositAccount = BankAccount()
                    self.depositAccount.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.depositDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.fullAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isBounced = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.lockboxNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.batchNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.remitterName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FundDetails')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.memo is not None:
            oprot.writeFieldBegin('memo', TType.STRING, 3)
            oprot.writeString(self.memo.encode('utf-8') if sys.version_info[0] == 2 else self.memo)
            oprot.writeFieldEnd()
        if self.externalReferenceNumber is not None:
            oprot.writeFieldBegin('externalReferenceNumber', TType.STRING, 4)
            oprot.writeString(self.externalReferenceNumber.encode('utf-8') if sys.version_info[0] == 2 else self.externalReferenceNumber)
            oprot.writeFieldEnd()
        if self.externalFundId is not None:
            oprot.writeFieldBegin('externalFundId', TType.STRING, 5)
            oprot.writeString(self.externalFundId.encode('utf-8') if sys.version_info[0] == 2 else self.externalFundId)
            oprot.writeFieldEnd()
        if self.remitter is not None:
            oprot.writeFieldBegin('remitter', TType.STRUCT, 6)
            self.remitter.write(oprot)
            oprot.writeFieldEnd()
        if self.depositAccount is not None:
            oprot.writeFieldBegin('depositAccount', TType.STRUCT, 7)
            self.depositAccount.write(oprot)
            oprot.writeFieldEnd()
        if self.depositDate is not None:
            oprot.writeFieldBegin('depositDate', TType.STRING, 8)
            oprot.writeString(self.depositDate.encode('utf-8') if sys.version_info[0] == 2 else self.depositDate)
            oprot.writeFieldEnd()
        if self.fullAddress is not None:
            oprot.writeFieldBegin('fullAddress', TType.STRING, 9)
            oprot.writeString(self.fullAddress.encode('utf-8') if sys.version_info[0] == 2 else self.fullAddress)
            oprot.writeFieldEnd()
        if self.isBounced is not None:
            oprot.writeFieldBegin('isBounced', TType.BOOL, 10)
            oprot.writeBool(self.isBounced)
            oprot.writeFieldEnd()
        if self.lockboxNumber is not None:
            oprot.writeFieldBegin('lockboxNumber', TType.STRING, 11)
            oprot.writeString(self.lockboxNumber.encode('utf-8') if sys.version_info[0] == 2 else self.lockboxNumber)
            oprot.writeFieldEnd()
        if self.batchNumber is not None:
            oprot.writeFieldBegin('batchNumber', TType.STRING, 12)
            oprot.writeString(self.batchNumber.encode('utf-8') if sys.version_info[0] == 2 else self.batchNumber)
            oprot.writeFieldEnd()
        if self.remitterName is not None:
            oprot.writeFieldBegin('remitterName', TType.STRING, 13)
            oprot.writeString(self.remitterName.encode('utf-8') if sys.version_info[0] == 2 else self.remitterName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Fund(object):
    """
    Attributes:
     - fundId
     - fundDetails
     - fundAllocations
     - fundInfo
     - syncState
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'fundId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'fundDetails', (FundDetails, FundDetails.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'fundAllocations', (FundAllocations, FundAllocations.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'fundInfo', (EnrichedFundInfo, EnrichedFundInfo.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'syncState', (FundSyncState, FundSyncState.thrift_spec), None, ),  # 5
    )
    def __init__(self, fundId=None, fundDetails=None, fundAllocations=None, fundInfo=None, syncState=None, ):
        self.fundId = fundId
        self.fundDetails = fundDetails
        self.fundAllocations = fundAllocations
        self.fundInfo = fundInfo
        self.syncState = syncState

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.fundId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.fundDetails = FundDetails()
                    self.fundDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.fundAllocations = FundAllocations()
                    self.fundAllocations.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.fundInfo = EnrichedFundInfo()
                    self.fundInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.syncState = FundSyncState()
                    self.syncState.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Fund')
        if self.fundId is not None:
            oprot.writeFieldBegin('fundId', TType.STRING, 1)
            oprot.writeString(self.fundId.encode('utf-8') if sys.version_info[0] == 2 else self.fundId)
            oprot.writeFieldEnd()
        if self.fundDetails is not None:
            oprot.writeFieldBegin('fundDetails', TType.STRUCT, 2)
            self.fundDetails.write(oprot)
            oprot.writeFieldEnd()
        if self.fundAllocations is not None:
            oprot.writeFieldBegin('fundAllocations', TType.STRUCT, 3)
            self.fundAllocations.write(oprot)
            oprot.writeFieldEnd()
        if self.fundInfo is not None:
            oprot.writeFieldBegin('fundInfo', TType.STRUCT, 4)
            self.fundInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.syncState is not None:
            oprot.writeFieldBegin('syncState', TType.STRUCT, 5)
            self.syncState.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
