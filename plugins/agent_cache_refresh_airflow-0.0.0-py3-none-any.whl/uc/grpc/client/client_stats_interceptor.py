# -*- coding: utf-8 -*-
"""
Client call stats interceptor which post result to datadog

:copyright: (c) 2018 by UrbanCompass, Inc.
"""
import grpc

from uc.base.monitoring.monitoring import counter


class ClientStatsInterceptor(grpc.UnaryUnaryClientInterceptor):
    def intercept_unary_unary(self, continuation, client_call_details, request):
        response = continuation(client_call_details, request)
        method_name_with_prefix = "{}{}".format(
            "grpc.client", client_call_details.method.replace("/", ".")
        )
        if response.exception():
            counter("{}.errors.count".format(method_name_with_prefix)).increment()
        else:
            counter("{}.successes.count".format(method_name_with_prefix)).increment()
        return response
