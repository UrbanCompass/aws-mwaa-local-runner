# -*- coding: utf-8 -*-
"""
Client TraceId interceptor

:copyright: (c) 2018 by UrbanCompass, Inc.
"""
import grpc
from grpc._interceptor import _ClientCallDetails


from uc.base.uc_logging import get_trace_id
from uc.base.uc_logging import new_trace_id
from uc.base.uc_logging import set_trace_id
from gen.urbancompass.common.base.constants import TRACE_ID_METADATA_KEY


class ClientTraceIdInterceptor(grpc.UnaryUnaryClientInterceptor):
    def intercept_unary_unary(self, continuation, client_call_details, request):
        metadata = {}
        if client_call_details.metadata is not None:
            metadata = dict(client_call_details.metadata)
        if TRACE_ID_METADATA_KEY in metadata:
            set_trace_id(metadata[TRACE_ID_METADATA_KEY])
        else:
            new_trace_id()
        tid = get_trace_id()
        if not metadata:
            metadata[TRACE_ID_METADATA_KEY] = tid
        client_call_details = _ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            list(metadata.items()),
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            client_call_details.compression,
        )
        response = continuation(client_call_details, request)
        return response
