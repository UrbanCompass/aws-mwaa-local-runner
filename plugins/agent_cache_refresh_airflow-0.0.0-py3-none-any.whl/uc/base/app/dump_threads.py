# -*- coding: utf-8 -*-
"""Tools for dumping all the current threads stack traces.

Inspired by zope's source code -
https://raw.githubusercontent.com/zopefoundation/Zope/966f7dfaeba33af07878dd7f2dad01aa5db49a08/src/Signals/threads.py  # noqa

:copyright: (c) 2016 by UrbanCompass, Inc.
"""

import sys
import threading
import traceback
import time


def dump_threads(output=None):
    """Dump stack traces for all running threads.

    :param output: A file object to write the thread dump to. sys.stderr by default.
    """
    if output is None:
        output = sys.stderr

    def thread_info(t):
        return "%s%s" % (t.name, " (daemon)" if t.daemon else "")

    id_to_info = {t.ident: thread_info(t) for t in threading.enumerate()}

    frames = sys._current_frames()
    output.write("Threads traceback dump at ")
    output.write(time.strftime("%Y-%m-%d %H:%M:%S"))
    output.write("\n")
    for thread_id, frame in list(frames.items()):
        output.write("\nThread %x %s:\n" % (thread_id, id_to_info.get(thread_id, "")))
        traceback.print_stack(frame, file=output)

    frames = None
    output.write("\nEnd of dump\n")
