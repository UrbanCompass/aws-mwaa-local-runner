# -*- coding: utf-8 -*-
"""
Please do not use classes in this file directly, rather instantiate them using
base.monitoring.timer

:copyright: (c) 2014 by Urban Compass, Inc.
"""

import collections
from contextlib import contextmanager
import logging
import time


class Error(Exception):
    pass


class TimerReporter(object):
    """
    Base class for reporting Timer's results.
    """

    def _send(self, subname, delta_ms, t):
        """
        Send a measurement.

        :param subname: the name of this subtimer.
        :param delta_ms: the amount of time passed for this subtimer in ms.
        :param t: the time of the measurement in seconds from the epoch.
        """
        pass

    def _finish_report(self):
        """
        Finish reporting metrics for this timer.
        """
        pass

    def report_times(self, name_delta_and_t_list):
        """
        Send the times recorded by a Timer to this reporter.
        """
        for name, delta, t in name_delta_and_t_list:
            self._send(name, delta * 1000, t)
        self._finish_report()


class LoggingTimerReporter(TimerReporter):
    """
    Log timer's times to logging.info.
    """

    def __init__(self, name, log_level="INFO", threshold_ms=0):
        self._name = name
        self._data = []
        self._log_level = logging.getLevelName(log_level)
        self._threshold_ms = threshold_ms

    def _send(self, subname, delta_ms, t):
        if delta_ms > self._threshold_ms:
            self._data.append((subname, delta_ms))

    def _finish_report(self):
        if self._data:
            logging.log(
                self._log_level,
                "{} : {}".format(self._name, ", ".join(["%s: %6.2f" % kv for kv in self._data])),
            )
        self._data = []


class DatadogTimerReporter(TimerReporter):
    def __init__(self, name, client, tags=None):
        """
        :param name: gauge name
        :type name: str

        :param client: properly initialized StatsD client
        :type client: base.dd_statsd.StatsD

        :param tags: tags to apply to the metric. Tag keys and values can't have spaces
        :type tags: dict[str,str]
        """
        self.metric_name = name
        self.statsd = client
        self.tags = tags

    def _send(self, subname, delta_ms, t):
        """
        Send a measurement.

        :param subname: the name of this subtimer.
        :param delta_ms: the amount of time passed for this subtimer.
        :param t: (not used) the time of the measurement in seconds from the epoch.
        """
        name = "{}.{}".format(self.metric_name, subname)
        self.statsd.time(name, delta_ms / 1000.0, tags=self.tags)


class Timer(object):
    """
    A timer provides start(), intermediate(), and stop().

    Upon stopping, it reports its times to its reporters.
    Notice that, unless you actually call stop, no time will be reported, so (depending on your use
    case) you may want to ensure that stop is called also in case of errors.

    Typically some of the reporters will create exported variables named after the timer's
    intermediate steps, so for example:

      timer = Timer('test', reporters)
      timer.start()
      ... do stuff
      timer.intermediate('first_step')
      ... do stuff
      timer.intermediate('second_step')
      ... even more
      timer.stop()

    will result in reporting 3 time deltas:
      'name.total'       the time delta between start() and stop().
      'name.first_step'  the time delta between start() and intermediate('first_step')
      'name.second_step' the time delta between intermediate('first_step') and
                         intermediate('second_step')

    Notice that we do not report the time delta between the last intermediate and stop.
    That delta can be derived from the total - the sum of the other partials.

    This class is not thread-safe.
    """

    def __init__(self, name, reporters):
        self._stop = None
        self._times = []
        self._reporters = reporters

    def start(self):
        """
        Start the timer and store the start time, this can only be executed once per instance.
        """
        if self._times:
            raise Error("Unable to start, the timer is already running.")
        self._times.append(("start", time.time()))

    def intermediate(self, subname):
        """
        Send the time that has passed (in milliseconds) since our last measurement

        :param subname: The subname to report the data to.
        :return: elapsed time from the last intermediate or start, in msec
        """
        times = self._times
        if not times:
            raise Error("Unable to take intermediate timer, the timer was never started")
        if self._stop is not None:
            raise Error("Unable to take intermediate timer, the timer is already stopped.")
        t = time.time()
        _, t0 = times[-1]
        times.append((subname, t))
        return (t - t0) * 1000

    def stop(self):
        """
        Stop the timer and report all times.

        :param subname: The subname to report the data to.
        :return: elapsed time from the start, in msec
        """
        times = self._times
        if not times:
            raise Error("Unable to stop, the timer was never started")
        if self._stop is not None:
            raise Error("Unable to stop, the timer is already stopped.")
        self._stop = True
        t = time.time()
        times.append(("stop", t))

        name_delta_and_t_list = []
        t0 = times[0][1]
        t = times[-1][1]
        delta = t - t0
        name_delta_and_t_list.append(("total", delta, t))
        for name, t in times[1:-1]:
            name_delta_and_t_list.append((name, t - t0, t))
            t0 = t
        # Note(ugo): See that we do not export the last point, as specified in the class doc.
        for d in self._reporters:
            try:
                d.report_times(name_delta_and_t_list)
            except Exception:
                logging.exception("Error in report_times:")
        return delta * 1000


class TimerWithSubtimers(Timer):
    """
    A timer that also can collect a number of nested subtimers.

    Use as:
      timer = TimerWithSubtimers('name')

      timer.start()
      with timer.subtimer('A'):
        ... do stuff

      with timer.subtimer('B'):
        ... do more stuff

      with timer.subtimer('A'):
        ... even more

      timer.stop()

    This will export three more counters than an ordinary Timer:
      'name.A' the cumulative time spent in subtimer 'A'
      'name.B' the cumulative time spent in subtimer 'B'
      'name.no_subtimer' the cumulative time spent with no subtimer.
    """

    def __init__(self, *args, **kwargs):
        super(TimerWithSubtimers, self).__init__(*args, **kwargs)
        self._subtimers = collections.defaultdict(float)
        self._active_subtimers = 0
        self._no_subtimer_start = None

    @contextmanager
    def subtimer(self, subname):
        """Create a self-closing subtimer named subname."""
        if not self._times:
            raise Error("Unable to create subtimer, the timer was never started")
        if self._stop is not None:
            raise Error("Unable to create subtimer, the timer is already stopped.")
        self._active_subtimers += 1
        start = time.time()
        if self._active_subtimers == 1:
            if self._no_subtimer_start is None:
                self._subtimers["no_subtimer"] += start - self._times[0][1]
            else:
                self._subtimers["no_subtimer"] += start - self._no_subtimer_start
        yield
        end = time.time()
        self._active_subtimers -= 1
        if self._active_subtimers == 0:
            self._no_subtimer_start = end
        self._subtimers[subname] += end - start

    def stop(self, *args, **kwargs):
        total_delta_ms = super(TimerWithSubtimers, self).stop(*args, **kwargs)
        start, end = self._times[0][1], self._times[-1][1]
        if self._active_subtimers == 0:
            if self._no_subtimer_start is None:
                self._subtimers["no_subtimer"] += end - start
            else:
                self._subtimers["no_subtimer"] += end - self._no_subtimer_start
        name_delta_and_t = [(s, delta, end) for (s, delta) in list(self._subtimers.items())]
        for d in self._reporters:
            try:
                d.report_times(name_delta_and_t)
            except Exception:
                logging.exception("Error in report_times:")
        return total_delta_ms
