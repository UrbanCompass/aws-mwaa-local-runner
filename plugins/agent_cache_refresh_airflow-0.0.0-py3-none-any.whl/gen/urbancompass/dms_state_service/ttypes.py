
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.closings.closings_service.ttypes
import gen.urbancompass.contacts.api.contact.ttypes
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_communication.ttypes
import gen.urbancompass.dms_communication_model.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_document.ttypes
import gen.urbancompass.dms_event_publisher.ttypes
import gen.urbancompass.dms_common.dms_folder.ttypes
import gen.urbancompass.dms_common.dms_glide.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.dms_common.dms_notification.ttypes
import gen.urbancompass.dms_state_model.ttypes
import gen.urbancompass.dms_translation_model.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.listing.listing_compliance.ttypes
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes

from thrift.transport import TTransport


class AddChecklistItemNoteRequest(object):
    """
    Attributes:
     - userId
     - itemId
     - note
     - checklistItemNoteRole
     - checklistItemNoteType
     - stage
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - impersonatorId
     - noteCreatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        None,  # 2
        (3, TType.I32, 'itemId', None, None, ),  # 3
        (4, TType.STRING, 'note', 'UTF8', None, ),  # 4
        (5, TType.I32, 'checklistItemNoteRole', None, None, ),  # 5
        (6, TType.I32, 'checklistItemNoteType', None, None, ),  # 6
        (7, TType.I32, 'stage', None, None, ),  # 7
        (8, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 11
        (12, TType.I64, 'noteCreatedAt', None, None, ),  # 12
    )
    def __init__(self, userId=None, itemId=None, note=None, checklistItemNoteRole=None, checklistItemNoteType=None, stage=None, dmsListingId=None, dmsTransactionId=None, impersonatorId=None, dmsFolderId=None, noteCreatedAt=None, ):
        self.userId = userId
        self.itemId = itemId
        self.note = note
        self.checklistItemNoteRole = checklistItemNoteRole
        self.checklistItemNoteType = checklistItemNoteType
        self.stage = stage
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId
        self.dmsFolderId = dmsFolderId
        self.noteCreatedAt = noteCreatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.checklistItemNoteRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.checklistItemNoteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.noteCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddChecklistItemNoteRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 3)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 4)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.checklistItemNoteRole is not None:
            oprot.writeFieldBegin('checklistItemNoteRole', TType.I32, 5)
            oprot.writeI32(self.checklistItemNoteRole)
            oprot.writeFieldEnd()
        if self.checklistItemNoteType is not None:
            oprot.writeFieldBegin('checklistItemNoteType', TType.I32, 6)
            oprot.writeI32(self.checklistItemNoteType)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 7)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 8)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 9)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 10)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 11)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.noteCreatedAt is not None:
            oprot.writeFieldBegin('noteCreatedAt', TType.I64, 12)
            oprot.writeI64(self.noteCreatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddChecklistItemNoteResponse(object):
    """
    Attributes:
     - status
     - noteId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I64, 'noteId', None, None, ),  # 2
    )
    def __init__(self, status=None, noteId=None, ):
        self.status = status
        self.noteId = noteId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.noteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddChecklistItemNoteResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.I64, 2)
            oprot.writeI64(self.noteId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddCustomChecklistItemRequest(object):
    """
    Attributes:
     - userId
     - checklistType
     - itemName
     - description
     - isRequired
     - stage
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistType', None, None, ),  # 2
        (3, TType.STRING, 'itemName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'description', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'isRequired', None, None, ),  # 5
        (6, TType.I32, 'stage', None, None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 10
    )
    def __init__(self, userId=None, checklistType=None, itemName=None, description=None, isRequired=None, stage=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, impersonatorId=None, ):
        self.userId = userId
        self.checklistType = checklistType
        self.itemName = itemName
        self.description = description
        self.isRequired = isRequired
        self.stage = stage
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.itemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddCustomChecklistItemRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 2)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.itemName is not None:
            oprot.writeFieldBegin('itemName', TType.STRING, 3)
            oprot.writeString(self.itemName.encode('utf-8') if sys.version_info[0] == 2 else self.itemName)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 4)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 5)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 6)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 8)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 9)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 10)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddCustomChecklistItemResponse(object):
    """
    Attributes:
     - status
     - itemId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
    )
    def __init__(self, status=None, itemId=None, ):
        self.status = status
        self.itemId = itemId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddCustomChecklistItemResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSContactsRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsTransactionId
     - dmsContacts
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsTransactionId=None, dmsContacts=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId
        self.dmsContacts = dmsContacts
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                        _elem4.read(iprot)
                        self.dmsContacts.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSContactsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter6 in self.dmsContacts:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSContactsResponse(object):
    """
    Attributes:
     - status
     - dmsContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsContacts=None, ):
        self.status = status
        self.dmsContacts = dmsContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                        _elem9.read(iprot)
                        self.dmsContacts.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSContactsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter11 in self.dmsContacts:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSListingDocumentRequest(object):
    """
    Attributes:
     - userId
     - documentId
     - dmsFolderId
     - checklistItemId
     - dmsListingId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'checklistItemId', None, None, ),  # 4
        (5, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, documentId=None, dmsFolderId=None, checklistItemId=None, dmsListingId=None, impersonatorId=None, ):
        self.userId = userId
        self.documentId = documentId
        self.dmsFolderId = dmsFolderId
        self.checklistItemId = checklistItemId
        self.dmsListingId = dmsListingId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSListingDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 4)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 5)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSListingDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSListingDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSListingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - team
     - dealListingId
     - dmsListing
     - listingId
     - impersonatorId
     - dmsAgents
     - doNotCallLDFS
     - origin
     - notTryDeleteFromDLSIfFailed
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'team', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'listingId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 8
        (9, TType.BOOL, 'doNotCallLDFS', None, None, ),  # 9
        (10, TType.I32, 'origin', None, None, ),  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.BOOL, 'notTryDeleteFromDLSIfFailed', None, None, ),  # 100
    )
    def __init__(self, dmsFolderId=None, userId=None, team=None, dealListingId=None, dmsListing=None, listingId=None, impersonatorId=None, dmsAgents=None, doNotCallLDFS=None, origin=None, notTryDeleteFromDLSIfFailed=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.team = team
        self.dealListingId = dealListingId
        self.dmsListing = dmsListing
        self.listingId = listingId
        self.impersonatorId = impersonatorId
        self.dmsAgents = dmsAgents
        self.doNotCallLDFS = doNotCallLDFS
        self.origin = origin
        self.notTryDeleteFromDLSIfFailed = notTryDeleteFromDLSIfFailed

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem14.read(iprot)
                        self.dmsAgents.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.doNotCallLDFS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.BOOL:
                    self.notTryDeleteFromDLSIfFailed = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSListingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 3)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 4)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 5)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 6)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 7)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter16 in self.dmsAgents:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.doNotCallLDFS is not None:
            oprot.writeFieldBegin('doNotCallLDFS', TType.BOOL, 9)
            oprot.writeBool(self.doNotCallLDFS)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 10)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.notTryDeleteFromDLSIfFailed is not None:
            oprot.writeFieldBegin('notTryDeleteFromDLSIfFailed', TType.BOOL, 100)
            oprot.writeBool(self.notTryDeleteFromDLSIfFailed)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSListingResponse(object):
    """
    Attributes:
     - status
     - dmsListingId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsListingId=None, ):
        self.status = status
        self.dmsListingId = dmsListingId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSOfferRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - dmsFolderId
     - dmsOffer
     - team
     - contactsToAdd
     - dmsAgents
     - shouldCreateDualRepDmsFolder
     - dualRepAgent
     - userType
     - userTypeOverrides
     - syntheticEntity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'dmsOffer', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'team', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'contactsToAdd', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 6
        (7, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 7
        (8, TType.BOOL, 'shouldCreateDualRepDmsFolder', None, None, ),  # 8
        (9, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), None, ),  # 9
        (10, TType.I32, 'userType', None, None, ),  # 10
        (11, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 11
        (12, TType.I32, 'syntheticEntity', None, None, ),  # 12
    )
    def __init__(self, userId=None, impersonatorId=None, dmsFolderId=None, dmsOffer=None, team=None, contactsToAdd=None, dmsAgents=None, shouldCreateDualRepDmsFolder=None, dualRepAgent=None, userType=None, userTypeOverrides=None, syntheticEntity=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.dmsFolderId = dmsFolderId
        self.dmsOffer = dmsOffer
        self.team = team
        self.contactsToAdd = contactsToAdd
        self.dmsAgents = dmsAgents
        self.shouldCreateDualRepDmsFolder = shouldCreateDualRepDmsFolder
        self.dualRepAgent = dualRepAgent
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.syntheticEntity = syntheticEntity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.dmsOffer = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.dmsOffer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.contactsToAdd = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem19.read(iprot)
                        self.contactsToAdd.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype21, _size24) = iprot.readListBegin()
                    for _i22 in range(_size24):
                        _elem23 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem23.read(iprot)
                        self.dmsAgents.append(_elem23)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.shouldCreateDualRepDmsFolder = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype26, _vtype27, _size30) = iprot.readMapBegin()
                    for _i25 in range(_size30):
                        _key28 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val29 = iprot.readI32()
                        self.userTypeOverrides[_key28] = _val29
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.syntheticEntity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSOfferRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsOffer is not None:
            oprot.writeFieldBegin('dmsOffer', TType.STRUCT, 4)
            self.dmsOffer.write(oprot)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 5)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.contactsToAdd is not None:
            oprot.writeFieldBegin('contactsToAdd', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.contactsToAdd))
            for _iter31 in self.contactsToAdd:
                _iter31.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter32 in self.dmsAgents:
                _iter32.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.shouldCreateDualRepDmsFolder is not None:
            oprot.writeFieldBegin('shouldCreateDualRepDmsFolder', TType.BOOL, 8)
            oprot.writeBool(self.shouldCreateDualRepDmsFolder)
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 9)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 10)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 11)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter33, _viter34 in self.userTypeOverrides.items():
                oprot.writeString(_kiter33.encode('utf-8') if sys.version_info[0] == 2 else _kiter33)
                oprot.writeI32(_viter34)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.syntheticEntity is not None:
            oprot.writeFieldBegin('syntheticEntity', TType.I32, 12)
            oprot.writeI32(self.syntheticEntity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSOfferResponse(object):
    """
    Attributes:
     - status
     - dmsOffer
     - isDmsOfferComplete
     - isDmsOfferSubmitted
     - expiresIn
     - dmsContacts
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
     - dmsAgents
     - otherSideDualRepAgents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsOffer', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 3
        (4, TType.I32, 'expiresIn', None, None, ),  # 4
        (5, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isDmsOfferSubmitted', None, None, ),  # 8
        (9, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 9
        (10, TType.LIST, 'otherSideDualRepAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 10
    )
    def __init__(self, status=None, dmsOffer=None, isDmsOfferComplete=None, expiresIn=None, dmsContacts=None, otherSideDualRepFolderBtId=None, otherSideDualRepDmsFolderId=None, isDmsOfferSubmitted=None, dmsAgents=None, otherSideDualRepAgents=None, ):
        self.status = status
        self.dmsOffer = dmsOffer
        self.isDmsOfferComplete = isDmsOfferComplete
        self.expiresIn = expiresIn
        self.dmsContacts = dmsContacts
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.isDmsOfferSubmitted = isDmsOfferSubmitted
        self.dmsAgents = dmsAgents
        self.otherSideDualRepAgents = otherSideDualRepAgents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsOffer = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.dmsOffer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype35, _size38) = iprot.readListBegin()
                    for _i36 in range(_size38):
                        _elem37 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem37.read(iprot)
                        self.dmsContacts.append(_elem37)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDmsOfferSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype39, _size42) = iprot.readListBegin()
                    for _i40 in range(_size42):
                        _elem41 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem41.read(iprot)
                        self.dmsAgents.append(_elem41)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.otherSideDualRepAgents = []
                    (_etype43, _size46) = iprot.readListBegin()
                    for _i44 in range(_size46):
                        _elem45 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem45.read(iprot)
                        self.otherSideDualRepAgents.append(_elem45)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSOfferResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsOffer is not None:
            oprot.writeFieldBegin('dmsOffer', TType.STRUCT, 2)
            self.dmsOffer.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 3)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 4)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter47 in self.dmsContacts:
                _iter47.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 6)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 7)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.isDmsOfferSubmitted is not None:
            oprot.writeFieldBegin('isDmsOfferSubmitted', TType.BOOL, 8)
            oprot.writeBool(self.isDmsOfferSubmitted)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter48 in self.dmsAgents:
                _iter48.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideDualRepAgents is not None:
            oprot.writeFieldBegin('otherSideDualRepAgents', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideDualRepAgents))
            for _iter49 in self.otherSideDualRepAgents:
                _iter49.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSTransactionDocumentRequest(object):
    """
    Attributes:
     - userId
     - documentId
     - dmsFolderId
     - checklistItemId
     - dmsTransactionId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'checklistItemId', None, None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, documentId=None, dmsFolderId=None, checklistItemId=None, dmsTransactionId=None, impersonatorId=None, ):
        self.userId = userId
        self.documentId = documentId
        self.dmsFolderId = dmsFolderId
        self.checklistItemId = checklistItemId
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSTransactionDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 4)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSTransactionDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSTransactionDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSTransactionRequest(object):
    """
    Attributes:
     - dmsListingId
     - userId
     - team
     - dmsFolderId
     - dmsTransaction
     - impersonatorId
     - origin
     - syntheticEntity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'team', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'origin', None, None, ),  # 7
        (8, TType.I32, 'syntheticEntity', None, None, ),  # 8
    )
    def __init__(self, dmsListingId=None, userId=None, team=None, dmsFolderId=None, dmsTransaction=None, impersonatorId=None, origin=None, syntheticEntity=None, ):
        self.dmsListingId = dmsListingId
        self.userId = userId
        self.team = team
        self.dmsFolderId = dmsFolderId
        self.dmsTransaction = dmsTransaction
        self.impersonatorId = impersonatorId
        self.origin = origin
        self.syntheticEntity = syntheticEntity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.syntheticEntity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSTransactionRequest')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 3)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 4)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 5)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 7)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.syntheticEntity is not None:
            oprot.writeFieldBegin('syntheticEntity', TType.I32, 8)
            oprot.writeI32(self.syntheticEntity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsTransactionId=None, ):
        self.status = status
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BackfillDmsFolderWithMarketAndOfficeRequest(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BackfillDmsFolderWithMarketAndOfficeRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BackfillDmsFolderWithMarketAndOfficeResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BackfillDmsFolderWithMarketAndOfficeResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetChecklistItemNoteInfoRequest(object):
    """
    Attributes:
     - listingChecklistItemNoteIds
     - transactionChecklistItemNoteIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listingChecklistItemNoteIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'transactionChecklistItemNoteIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, listingChecklistItemNoteIds=None, transactionChecklistItemNoteIds=None, ):
        self.listingChecklistItemNoteIds = listingChecklistItemNoteIds
        self.transactionChecklistItemNoteIds = transactionChecklistItemNoteIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listingChecklistItemNoteIds = []
                    (_etype50, _size53) = iprot.readListBegin()
                    for _i51 in range(_size53):
                        _elem52 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingChecklistItemNoteIds.append(_elem52)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.transactionChecklistItemNoteIds = []
                    (_etype54, _size57) = iprot.readListBegin()
                    for _i55 in range(_size57):
                        _elem56 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.transactionChecklistItemNoteIds.append(_elem56)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetChecklistItemNoteInfoRequest')
        if self.listingChecklistItemNoteIds is not None:
            oprot.writeFieldBegin('listingChecklistItemNoteIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.listingChecklistItemNoteIds))
            for _iter58 in self.listingChecklistItemNoteIds:
                oprot.writeString(_iter58.encode('utf-8') if sys.version_info[0] == 2 else _iter58)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.transactionChecklistItemNoteIds is not None:
            oprot.writeFieldBegin('transactionChecklistItemNoteIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.transactionChecklistItemNoteIds))
            for _iter59 in self.transactionChecklistItemNoteIds:
                oprot.writeString(_iter59.encode('utf-8') if sys.version_info[0] == 2 else _iter59)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetChecklistItemNoteInfoResponse(object):
    """
    Attributes:
     - status
     - checklistItemNotes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklistItemNotes', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItemNote, gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItemNote.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, checklistItemNotes=None, ):
        self.status = status
        self.checklistItemNotes = checklistItemNotes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistItemNotes = []
                    (_etype60, _size63) = iprot.readListBegin()
                    for _i61 in range(_size63):
                        _elem62 = gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItemNote()
                        _elem62.read(iprot)
                        self.checklistItemNotes.append(_elem62)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetChecklistItemNoteInfoResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItemNotes is not None:
            oprot.writeFieldBegin('checklistItemNotes', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklistItemNotes))
            for _iter64 in self.checklistItemNotes:
                _iter64.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetDMSFoldersOverviewRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderIds
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderIds=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderIds = dmsFolderIds
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetDMSFoldersOverviewRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter69 in self.dmsFolderIds:
                oprot.writeString(_iter69.encode('utf-8') if sys.version_info[0] == 2 else _iter69)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckChecklistItemNoteConditionRequest(object):
    """
    Attributes:
     - dmsFolderId
     - checklistItemNoteId
     - conditionsToCheck
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'checklistItemNoteId', None, None, ),  # 2
        (3, TType.LIST, 'conditionsToCheck', (TType.I32, None, False), None, ),  # 3
    )
    def __init__(self, dmsFolderId=None, checklistItemNoteId=None, conditionsToCheck=None, ):
        self.dmsFolderId = dmsFolderId
        self.checklistItemNoteId = checklistItemNoteId
        self.conditionsToCheck = conditionsToCheck

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.checklistItemNoteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.conditionsToCheck = []
                    (_etype70, _size73) = iprot.readListBegin()
                    for _i71 in range(_size73):
                        _elem72 = iprot.readI32()
                        self.conditionsToCheck.append(_elem72)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckChecklistItemNoteConditionRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistItemNoteId is not None:
            oprot.writeFieldBegin('checklistItemNoteId', TType.I64, 2)
            oprot.writeI64(self.checklistItemNoteId)
            oprot.writeFieldEnd()
        if self.conditionsToCheck is not None:
            oprot.writeFieldBegin('conditionsToCheck', TType.LIST, 3)
            oprot.writeListBegin(TType.I32, len(self.conditionsToCheck))
            for _iter74 in self.conditionsToCheck:
                oprot.writeI32(_iter74)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckChecklistItemNoteConditionResponse(object):
    """
    Attributes:
     - status
     - results
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'results', (TType.I32, None, TType.BOOL, None, False), None, ),  # 2
    )
    def __init__(self, status=None, results=None, ):
        self.status = status
        self.results = results

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.results = {}
                    (_ktype76, _vtype77, _size80) = iprot.readMapBegin()
                    for _i75 in range(_size80):
                        _key78 = iprot.readI32()
                        _val79 = iprot.readBool()
                        self.results[_key78] = _val79
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckChecklistItemNoteConditionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.results is not None:
            oprot.writeFieldBegin('results', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.BOOL, len(self.results))
            for _kiter81, _viter82 in self.results.items():
                oprot.writeI32(_kiter81)
                oprot.writeBool(_viter82)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckDmsFolderConditionRequest(object):
    """
    Attributes:
     - dmsFolderId
     - conditionsToCheck
     - checklistItemNoteId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'conditionsToCheck', (TType.I32, None, False), None, ),  # 2
        (3, TType.I64, 'checklistItemNoteId', None, None, ),  # 3
    )
    def __init__(self, dmsFolderId=None, conditionsToCheck=None, checklistItemNoteId=None, ):
        self.dmsFolderId = dmsFolderId
        self.conditionsToCheck = conditionsToCheck
        self.checklistItemNoteId = checklistItemNoteId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.conditionsToCheck = []
                    (_etype83, _size86) = iprot.readListBegin()
                    for _i84 in range(_size86):
                        _elem85 = iprot.readI32()
                        self.conditionsToCheck.append(_elem85)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.checklistItemNoteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckDmsFolderConditionRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.conditionsToCheck is not None:
            oprot.writeFieldBegin('conditionsToCheck', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.conditionsToCheck))
            for _iter87 in self.conditionsToCheck:
                oprot.writeI32(_iter87)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.checklistItemNoteId is not None:
            oprot.writeFieldBegin('checklistItemNoteId', TType.I64, 3)
            oprot.writeI64(self.checklistItemNoteId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckDmsFolderConditionResponse(object):
    """
    Attributes:
     - status
     - results
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'results', (TType.I32, None, TType.BOOL, None, False), None, ),  # 2
    )
    def __init__(self, status=None, results=None, ):
        self.status = status
        self.results = results

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.results = {}
                    (_ktype89, _vtype90, _size93) = iprot.readMapBegin()
                    for _i88 in range(_size93):
                        _key91 = iprot.readI32()
                        _val92 = iprot.readBool()
                        self.results[_key91] = _val92
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckDmsFolderConditionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.results is not None:
            oprot.writeFieldBegin('results', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.BOOL, len(self.results))
            for _kiter94, _viter95 in self.results.items():
                oprot.writeI32(_kiter94)
                oprot.writeBool(_viter95)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClaimDealRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
    )
    def __init__(self, userId=None, dmsFolderId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClaimDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClaimDealResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClaimDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommissionsAndAllocationsCalculationRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - closingRequest
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'closingRequest', (gen.urbancompass.closings.closings_service.ttypes.ClosingRequest, gen.urbancompass.closings.closings_service.ttypes.ClosingRequest.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, userId=None, closingRequest=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.closingRequest = closingRequest
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.closingRequest = gen.urbancompass.closings.closings_service.ttypes.ClosingRequest()
                    self.closingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionsAndAllocationsCalculationRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.closingRequest is not None:
            oprot.writeFieldBegin('closingRequest', TType.STRUCT, 3)
            self.closingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateClosingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - closingRequest
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'closingRequest', (gen.urbancompass.closings.closings_service.ttypes.ClosingRequest, gen.urbancompass.closings.closings_service.ttypes.ClosingRequest.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, userId=None, closingRequest=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.closingRequest = closingRequest
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.closingRequest = gen.urbancompass.closings.closings_service.ttypes.ClosingRequest()
                    self.closingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateClosingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.closingRequest is not None:
            oprot.writeFieldBegin('closingRequest', TType.STRUCT, 3)
            self.closingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDMSFolderForDualRepRequest(object):
    """
    Attributes:
     - userId
     - team
     - sideRepresented
     - primaryDmsFolderId
     - dualRepAgent
     - clientFromDmsContact
     - userType
     - userTypeOverrides
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'team', 'UTF8', None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.STRING, 'primaryDmsFolderId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'clientFromDmsContact', (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), None, ),  # 6
        (7, TType.I32, 'userType', None, None, ),  # 7
        (8, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 8
        (9, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 9
    )
    def __init__(self, userId=None, team=None, sideRepresented=None, primaryDmsFolderId=None, dualRepAgent=None, clientFromDmsContact=None, userType=None, userTypeOverrides=None, impersonatorId=None, ):
        self.userId = userId
        self.team = team
        self.sideRepresented = sideRepresented
        self.primaryDmsFolderId = primaryDmsFolderId
        self.dualRepAgent = dualRepAgent
        self.clientFromDmsContact = clientFromDmsContact
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.primaryDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.clientFromDmsContact = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                    self.clientFromDmsContact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype97, _vtype98, _size101) = iprot.readMapBegin()
                    for _i96 in range(_size101):
                        _key99 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val100 = iprot.readI32()
                        self.userTypeOverrides[_key99] = _val100
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDMSFolderForDualRepRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 2)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.primaryDmsFolderId is not None:
            oprot.writeFieldBegin('primaryDmsFolderId', TType.STRING, 4)
            oprot.writeString(self.primaryDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsFolderId)
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 5)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.clientFromDmsContact is not None:
            oprot.writeFieldBegin('clientFromDmsContact', TType.STRUCT, 6)
            self.clientFromDmsContact.write(oprot)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 7)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 8)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter102, _viter103 in self.userTypeOverrides.items():
                oprot.writeString(_kiter102.encode('utf-8') if sys.version_info[0] == 2 else _kiter102)
                oprot.writeI32(_viter103)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 9)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDMSFolderForDualRepResponse(object):
    """
    Attributes:
     - status
     - dmsFolderId
     - btId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'btId', 'UTF8', None, ),  # 3
    )
    def __init__(self, status=None, dmsFolderId=None, btId=None, ):
        self.status = status
        self.dmsFolderId = dmsFolderId
        self.btId = btId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDMSFolderForDualRepResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 3)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDMSFolderRequest(object):
    """
    Attributes:
     - name
     - sideRepresented
     - userId
     - team
     - dealListingId
     - listingId
     - ownerUserId
     - fromIntermediatePage
     - isForReferralDeal
     - impersonatorId
     - dealType
     - referredBy
     - referredTo
     - referralDetail
     - originatedFrom
     - sourceService
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.I32, 'sideRepresented', None, None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'team', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'listingId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'ownerUserId', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'fromIntermediatePage', None, None, ),  # 8
        (9, TType.BOOL, 'isForReferralDeal', None, None, ),  # 9
        (10, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 10
        (11, TType.I32, 'dealType', None, None, ),  # 11
        (12, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 12
        (13, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 13
        (14, TType.STRUCT, 'referralDetail', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail.thrift_spec), None, ),  # 14
        (15, TType.I32, 'originatedFrom', None, None, ),  # 15
        (16, TType.I32, 'sourceService', None, None, ),  # 16
    )
    def __init__(self, name=None, sideRepresented=None, userId=None, team=None, dealListingId=None, listingId=None, ownerUserId=None, fromIntermediatePage=None, isForReferralDeal=None, impersonatorId=None, dealType=None, referredBy=None, referredTo=None, referralDetail=None, originatedFrom=None, sourceService=None, ):
        self.name = name
        self.sideRepresented = sideRepresented
        self.userId = userId
        self.team = team
        self.dealListingId = dealListingId
        self.listingId = listingId
        self.ownerUserId = ownerUserId
        self.fromIntermediatePage = fromIntermediatePage
        self.isForReferralDeal = isForReferralDeal
        self.impersonatorId = impersonatorId
        self.dealType = dealType
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.referralDetail = referralDetail
        self.originatedFrom = originatedFrom
        self.sourceService = sourceService

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.ownerUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.fromIntermediatePage = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isForReferralDeal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.referralDetail = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail()
                    self.referralDetail.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.originatedFrom = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.sourceService = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDMSFolderRequest')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 2)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 4)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 5)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 6)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.ownerUserId is not None:
            oprot.writeFieldBegin('ownerUserId', TType.STRING, 7)
            oprot.writeString(self.ownerUserId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerUserId)
            oprot.writeFieldEnd()
        if self.fromIntermediatePage is not None:
            oprot.writeFieldBegin('fromIntermediatePage', TType.BOOL, 8)
            oprot.writeBool(self.fromIntermediatePage)
            oprot.writeFieldEnd()
        if self.isForReferralDeal is not None:
            oprot.writeFieldBegin('isForReferralDeal', TType.BOOL, 9)
            oprot.writeBool(self.isForReferralDeal)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 10)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 11)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 12)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 13)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.referralDetail is not None:
            oprot.writeFieldBegin('referralDetail', TType.STRUCT, 14)
            self.referralDetail.write(oprot)
            oprot.writeFieldEnd()
        if self.originatedFrom is not None:
            oprot.writeFieldBegin('originatedFrom', TType.I32, 15)
            oprot.writeI32(self.originatedFrom)
            oprot.writeFieldEnd()
        if self.sourceService is not None:
            oprot.writeFieldBegin('sourceService', TType.I32, 16)
            oprot.writeI32(self.sourceService)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDMSFolderResponse(object):
    """
    Attributes:
     - status
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderId=None, ):
        self.status = status
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDealToDwsRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - accessLevel
     - primaryDealFromSplit
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'accessLevel', None, None, ),  # 3
        (4, TType.BOOL, 'primaryDealFromSplit', None, None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, dmsFolderId=None, userId=None, accessLevel=None, primaryDealFromSplit=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.accessLevel = accessLevel
        self.primaryDealFromSplit = primaryDealFromSplit
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.accessLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.primaryDealFromSplit = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDealToDwsRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.accessLevel is not None:
            oprot.writeFieldBegin('accessLevel', TType.I32, 3)
            oprot.writeI32(self.accessLevel)
            oprot.writeFieldEnd()
        if self.primaryDealFromSplit is not None:
            oprot.writeFieldBegin('primaryDealFromSplit', TType.BOOL, 4)
            oprot.writeBool(self.primaryDealFromSplit)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDealToDwsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDealToDwsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDmsFolderForReferralDealRequest(object):
    """
    Attributes:
     - userId
     - sideRepresented
     - ownerUserId
     - ownerTeamId
     - primaryDmsTransactionId
     - referralFee
     - dealType
     - additionalFields
     - accessLevel
     - primaryDealFromSplit
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'sideRepresented', None, None, ),  # 2
        (3, TType.STRING, 'ownerUserId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'ownerTeamId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'primaryDmsTransactionId', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'referralFee', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 6
        (7, TType.I32, 'dealType', None, None, ),  # 7
        (8, TType.STRUCT, 'additionalFields', (gen.urbancompass.dms_translation_model.ttypes.AdditionalReferralDealFields, gen.urbancompass.dms_translation_model.ttypes.AdditionalReferralDealFields.thrift_spec), None, ),  # 8
        (9, TType.I32, 'accessLevel', None, None, ),  # 9
        (10, TType.BOOL, 'primaryDealFromSplit', None, None, ),  # 10
        (11, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 11
    )
    def __init__(self, userId=None, sideRepresented=None, ownerUserId=None, ownerTeamId=None, primaryDmsTransactionId=None, referralFee=None, dealType=None, additionalFields=None, accessLevel=None, primaryDealFromSplit=None, impersonatorId=None, ):
        self.userId = userId
        self.sideRepresented = sideRepresented
        self.ownerUserId = ownerUserId
        self.ownerTeamId = ownerTeamId
        self.primaryDmsTransactionId = primaryDmsTransactionId
        self.referralFee = referralFee
        self.dealType = dealType
        self.additionalFields = additionalFields
        self.accessLevel = accessLevel
        self.primaryDealFromSplit = primaryDealFromSplit
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.ownerUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.ownerTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.primaryDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.referralFee = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.referralFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.additionalFields = gen.urbancompass.dms_translation_model.ttypes.AdditionalReferralDealFields()
                    self.additionalFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.accessLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.primaryDealFromSplit = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDmsFolderForReferralDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 2)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.ownerUserId is not None:
            oprot.writeFieldBegin('ownerUserId', TType.STRING, 3)
            oprot.writeString(self.ownerUserId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerUserId)
            oprot.writeFieldEnd()
        if self.ownerTeamId is not None:
            oprot.writeFieldBegin('ownerTeamId', TType.STRING, 4)
            oprot.writeString(self.ownerTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerTeamId)
            oprot.writeFieldEnd()
        if self.primaryDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.primaryDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsTransactionId)
            oprot.writeFieldEnd()
        if self.referralFee is not None:
            oprot.writeFieldBegin('referralFee', TType.STRUCT, 6)
            self.referralFee.write(oprot)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 7)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.additionalFields is not None:
            oprot.writeFieldBegin('additionalFields', TType.STRUCT, 8)
            self.additionalFields.write(oprot)
            oprot.writeFieldEnd()
        if self.accessLevel is not None:
            oprot.writeFieldBegin('accessLevel', TType.I32, 9)
            oprot.writeI32(self.accessLevel)
            oprot.writeFieldEnd()
        if self.primaryDealFromSplit is not None:
            oprot.writeFieldBegin('primaryDealFromSplit', TType.BOOL, 10)
            oprot.writeBool(self.primaryDealFromSplit)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 11)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDmsFolderForReferralDealResponse(object):
    """
    Attributes:
     - status
     - dmsFolderId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
    )
    def __init__(self, status=None, dmsFolderId=None, dmsTransactionId=None, ):
        self.status = status
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDmsFolderForReferralDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSFolderResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSListingDocumentRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsListingId
     - checklistItemId
     - forDeletedListing
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'checklistItemId', None, None, ),  # 4
        (5, TType.BOOL, 'forDeletedListing', None, None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsListingId=None, checklistItemId=None, forDeletedListing=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.checklistItemId = checklistItemId
        self.forDeletedListing = forDeletedListing
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.forDeletedListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSListingDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 3)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 4)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.forDeletedListing is not None:
            oprot.writeFieldBegin('forDeletedListing', TType.BOOL, 5)
            oprot.writeBool(self.forDeletedListing)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSListingDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSListingDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSListingRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsListingId
     - reasonForWithdrawal
     - impersonatorId
     - asOfferForActivityLog
     - doNotCallLDFS
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'reasonForWithdrawal', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'asOfferForActivityLog', None, None, ),  # 6
        (7, TType.BOOL, 'doNotCallLDFS', None, None, ),  # 7
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsListingId=None, reasonForWithdrawal=None, impersonatorId=None, asOfferForActivityLog=None, doNotCallLDFS=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.reasonForWithdrawal = reasonForWithdrawal
        self.impersonatorId = impersonatorId
        self.asOfferForActivityLog = asOfferForActivityLog
        self.doNotCallLDFS = doNotCallLDFS

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.reasonForWithdrawal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.asOfferForActivityLog = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.doNotCallLDFS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 3)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.reasonForWithdrawal is not None:
            oprot.writeFieldBegin('reasonForWithdrawal', TType.STRING, 4)
            oprot.writeString(self.reasonForWithdrawal.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForWithdrawal)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.asOfferForActivityLog is not None:
            oprot.writeFieldBegin('asOfferForActivityLog', TType.BOOL, 6)
            oprot.writeBool(self.asOfferForActivityLog)
            oprot.writeFieldEnd()
        if self.doNotCallLDFS is not None:
            oprot.writeFieldBegin('doNotCallLDFS', TType.BOOL, 7)
            oprot.writeBool(self.doNotCallLDFS)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSListingResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSTransactionDocumentRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsTransactionId
     - checklistItemId
     - forDeletedTransaction
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'checklistItemId', None, None, ),  # 4
        (5, TType.BOOL, 'forDeletedTransaction', None, None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsTransactionId=None, checklistItemId=None, forDeletedTransaction=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId
        self.checklistItemId = checklistItemId
        self.forDeletedTransaction = forDeletedTransaction
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.forDeletedTransaction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSTransactionDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 4)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.forDeletedTransaction is not None:
            oprot.writeFieldBegin('forDeletedTransaction', TType.BOOL, 5)
            oprot.writeBool(self.forDeletedTransaction)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSTransactionDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSTransactionDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSTransactionRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsTransactionId
     - reasonForCancellation
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'reasonForCancellation', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsTransactionId=None, reasonForCancellation=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId
        self.reasonForCancellation = reasonForCancellation
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.reasonForCancellation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.reasonForCancellation is not None:
            oprot.writeFieldBegin('reasonForCancellation', TType.STRING, 4)
            oprot.writeString(self.reasonForCancellation.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForCancellation)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSTransactionResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDraftRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, dmsFolderId=None, userId=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDraftRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsSyncInternalRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsListingSyncPayload
     - dmsTransactionSyncPayload
     - deleteOffer
     - reasonForCancellation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'dmsListingSyncPayload', (gen.urbancompass.dms_state_model.ttypes.DmsListingSyncPayload, gen.urbancompass.dms_state_model.ttypes.DmsListingSyncPayload.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'dmsTransactionSyncPayload', (gen.urbancompass.dms_state_model.ttypes.DmsTransactionSyncPayload, gen.urbancompass.dms_state_model.ttypes.DmsTransactionSyncPayload.thrift_spec), None, ),  # 4
        (5, TType.BOOL, 'deleteOffer', None, None, ),  # 5
        (6, TType.STRING, 'reasonForCancellation', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsListingSyncPayload=None, dmsTransactionSyncPayload=None, deleteOffer=None, reasonForCancellation=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsListingSyncPayload = dmsListingSyncPayload
        self.dmsTransactionSyncPayload = dmsTransactionSyncPayload
        self.deleteOffer = deleteOffer
        self.reasonForCancellation = reasonForCancellation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dmsListingSyncPayload = gen.urbancompass.dms_state_model.ttypes.DmsListingSyncPayload()
                    self.dmsListingSyncPayload.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.dmsTransactionSyncPayload = gen.urbancompass.dms_state_model.ttypes.DmsTransactionSyncPayload()
                    self.dmsTransactionSyncPayload.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.deleteOffer = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.reasonForCancellation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsSyncInternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingSyncPayload is not None:
            oprot.writeFieldBegin('dmsListingSyncPayload', TType.STRUCT, 3)
            self.dmsListingSyncPayload.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionSyncPayload is not None:
            oprot.writeFieldBegin('dmsTransactionSyncPayload', TType.STRUCT, 4)
            self.dmsTransactionSyncPayload.write(oprot)
            oprot.writeFieldEnd()
        if self.deleteOffer is not None:
            oprot.writeFieldBegin('deleteOffer', TType.BOOL, 5)
            oprot.writeBool(self.deleteOffer)
            oprot.writeFieldEnd()
        if self.reasonForCancellation is not None:
            oprot.writeFieldBegin('reasonForCancellation', TType.STRING, 6)
            oprot.writeString(self.reasonForCancellation.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForCancellation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsSyncInternalResponse(object):
    """
    Attributes:
     - status
     - extraInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'extraInfo', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, extraInfo=None, ):
        self.status = status
        self.extraInfo = extraInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.extraInfo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsSyncInternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.extraInfo is not None:
            oprot.writeFieldBegin('extraInfo', TType.STRING, 2)
            oprot.writeString(self.extraInfo.encode('utf-8') if sys.version_info[0] == 2 else self.extraInfo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EditDocumentChecklistItemsRequest(object):
    """
    Attributes:
     - userId
     - documentId
     - dmsFolderId
     - checklistItemIds
     - stage
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'checklistItemIds', (TType.I32, None, False), None, ),  # 4
        (5, TType.I32, 'stage', None, None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, documentId=None, dmsFolderId=None, checklistItemIds=None, stage=None, impersonatorId=None, ):
        self.userId = userId
        self.documentId = documentId
        self.dmsFolderId = dmsFolderId
        self.checklistItemIds = checklistItemIds
        self.stage = stage
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.checklistItemIds = []
                    (_etype104, _size107) = iprot.readListBegin()
                    for _i105 in range(_size107):
                        _elem106 = iprot.readI32()
                        self.checklistItemIds.append(_elem106)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EditDocumentChecklistItemsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistItemIds is not None:
            oprot.writeFieldBegin('checklistItemIds', TType.LIST, 4)
            oprot.writeListBegin(TType.I32, len(self.checklistItemIds))
            for _iter108 in self.checklistItemIds:
                oprot.writeI32(_iter108)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 5)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EditDocumentChecklistItemsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EditDocumentChecklistItemsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersByAddressRequest(object):
    """
    Attributes:
     - dmsFolderIdList
     - addressQuery
     - userId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dmsFolderIdList', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'addressQuery', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderIdList=None, addressQuery=None, userId=None, impersonatorId=None, ):
        self.dmsFolderIdList = dmsFolderIdList
        self.addressQuery = addressQuery
        self.userId = userId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dmsFolderIdList = []
                    (_etype109, _size112) = iprot.readListBegin()
                    for _i110 in range(_size112):
                        _elem111 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIdList.append(_elem111)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.addressQuery = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersByAddressRequest')
        if self.dmsFolderIdList is not None:
            oprot.writeFieldBegin('dmsFolderIdList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIdList))
            for _iter113 in self.dmsFolderIdList:
                oprot.writeString(_iter113.encode('utf-8') if sys.version_info[0] == 2 else _iter113)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.addressQuery is not None:
            oprot.writeFieldBegin('addressQuery', TType.STRING, 2)
            oprot.writeString(self.addressQuery.encode('utf-8') if sys.version_info[0] == 2 else self.addressQuery)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersByAddressResponse(object):
    """
    Attributes:
     - status
     - dmsFolderIdList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolderIdList', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderIdList=None, ):
        self.status = status
        self.dmsFolderIdList = dmsFolderIdList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIdList = []
                    (_etype114, _size117) = iprot.readListBegin()
                    for _i115 in range(_size117):
                        _elem116 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIdList.append(_elem116)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersByAddressResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIdList is not None:
            oprot.writeFieldBegin('dmsFolderIdList', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIdList))
            for _iter118 in self.dmsFolderIdList:
                oprot.writeString(_iter118.encode('utf-8') if sys.version_info[0] == 2 else _iter118)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersRequest(object):
    """
    Attributes:
     - dmsFolderIdList
     - filterQuery
     - userId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dmsFolderIdList', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRUCT, 'filterQuery', (gen.urbancompass.dms_common.dms_deal.ttypes.DealQuery, gen.urbancompass.dms_common.dms_deal.ttypes.DealQuery.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderIdList=None, filterQuery=None, userId=None, impersonatorId=None, ):
        self.dmsFolderIdList = dmsFolderIdList
        self.filterQuery = filterQuery
        self.userId = userId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dmsFolderIdList = []
                    (_etype119, _size122) = iprot.readListBegin()
                    for _i120 in range(_size122):
                        _elem121 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIdList.append(_elem121)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.filterQuery = gen.urbancompass.dms_common.dms_deal.ttypes.DealQuery()
                    self.filterQuery.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersRequest')
        if self.dmsFolderIdList is not None:
            oprot.writeFieldBegin('dmsFolderIdList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIdList))
            for _iter123 in self.dmsFolderIdList:
                oprot.writeString(_iter123.encode('utf-8') if sys.version_info[0] == 2 else _iter123)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.filterQuery is not None:
            oprot.writeFieldBegin('filterQuery', TType.STRUCT, 2)
            self.filterQuery.write(oprot)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersResponse(object):
    """
    Attributes:
     - status
     - dmsFolderIdList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolderIdList', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderIdList=None, ):
        self.status = status
        self.dmsFolderIdList = dmsFolderIdList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIdList = []
                    (_etype124, _size127) = iprot.readListBegin()
                    for _i125 in range(_size127):
                        _elem126 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIdList.append(_elem126)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIdList is not None:
            oprot.writeFieldBegin('dmsFolderIdList', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIdList))
            for _iter128 in self.dmsFolderIdList:
                oprot.writeString(_iter128.encode('utf-8') if sys.version_info[0] == 2 else _iter128)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetActivityLogsForFolderInternalRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetActivityLogsForFolderInternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetActivityLogsForFolderResponse(object):
    """
    Attributes:
     - status
     - activityLogs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'activityLogs', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsFolderActivityLog, gen.urbancompass.dms_state_model.ttypes.DmsFolderActivityLog.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, activityLogs=None, ):
        self.status = status
        self.activityLogs = activityLogs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.activityLogs = []
                    (_etype129, _size132) = iprot.readListBegin()
                    for _i130 in range(_size132):
                        _elem131 = gen.urbancompass.dms_state_model.ttypes.DmsFolderActivityLog()
                        _elem131.read(iprot)
                        self.activityLogs.append(_elem131)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetActivityLogsForFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.activityLogs is not None:
            oprot.writeFieldBegin('activityLogs', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.activityLogs))
            for _iter133 in self.activityLogs:
                _iter133.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentSplitStateServiceRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - closeDate
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'closeDate', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, userId=None, dmsFolderId=None, closeDate=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.closeDate = closeDate
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentSplitStateServiceRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 3)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentsInfoByTeamIdRequest(object):
    """
    Attributes:
     - teamId
     - dmsListingId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
    )
    def __init__(self, teamId=None, dmsListingId=None, dmsFolderId=None, ):
        self.teamId = teamId
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentsInfoByTeamIdRequest')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentsInfoByTeamIdResponse(object):
    """
    Attributes:
     - status
     - agentsInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'agentsInfo', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.AgentInfo, gen.urbancompass.dms_translation_model.ttypes.AgentInfo.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, agentsInfo=None, ):
        self.status = status
        self.agentsInfo = agentsInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.agentsInfo = []
                    (_etype134, _size137) = iprot.readListBegin()
                    for _i135 in range(_size137):
                        _elem136 = gen.urbancompass.dms_translation_model.ttypes.AgentInfo()
                        _elem136.read(iprot)
                        self.agentsInfo.append(_elem136)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentsInfoByTeamIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.agentsInfo is not None:
            oprot.writeFieldBegin('agentsInfo', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.agentsInfo))
            for _iter138 in self.agentsInfo:
                _iter138.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAggregateDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - includeChecklists
     - includeAggregateDocumentFields
     - includeDeletedTransaction
     - includeDeletedListing
     - impersonatorId
     - includedDeletedFolder
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'includeChecklists', None, None, ),  # 5
        (6, TType.BOOL, 'includeAggregateDocumentFields', None, None, ),  # 6
        (7, TType.BOOL, 'includeDeletedTransaction', None, None, ),  # 7
        (8, TType.BOOL, 'includeDeletedListing', None, None, ),  # 8
        (9, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'includedDeletedFolder', None, None, ),  # 10
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, includeChecklists=None, includeAggregateDocumentFields=None, includeDeletedTransaction=None, includeDeletedListing=None, impersonatorId=None, includedDeletedFolder=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.includeChecklists = includeChecklists
        self.includeAggregateDocumentFields = includeAggregateDocumentFields
        self.includeDeletedTransaction = includeDeletedTransaction
        self.includeDeletedListing = includeDeletedListing
        self.impersonatorId = impersonatorId
        self.includedDeletedFolder = includedDeletedFolder

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.includeChecklists = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.includeAggregateDocumentFields = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeDeletedTransaction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.includeDeletedListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.includedDeletedFolder = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAggregateDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 3)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 4)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.includeChecklists is not None:
            oprot.writeFieldBegin('includeChecklists', TType.BOOL, 5)
            oprot.writeBool(self.includeChecklists)
            oprot.writeFieldEnd()
        if self.includeAggregateDocumentFields is not None:
            oprot.writeFieldBegin('includeAggregateDocumentFields', TType.BOOL, 6)
            oprot.writeBool(self.includeAggregateDocumentFields)
            oprot.writeFieldEnd()
        if self.includeDeletedTransaction is not None:
            oprot.writeFieldBegin('includeDeletedTransaction', TType.BOOL, 7)
            oprot.writeBool(self.includeDeletedTransaction)
            oprot.writeFieldEnd()
        if self.includeDeletedListing is not None:
            oprot.writeFieldBegin('includeDeletedListing', TType.BOOL, 8)
            oprot.writeBool(self.includeDeletedListing)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 9)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.includedDeletedFolder is not None:
            oprot.writeFieldBegin('includedDeletedFolder', TType.BOOL, 10)
            oprot.writeBool(self.includedDeletedFolder)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAggregateDMSFolderResponse(object):
    """
    Attributes:
     - status
     - data
     - dualRepSide
     - otherSideDualRepDmsListing
     - otherSideDualRepDmsTransaction
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'data', (gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData, gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData.thrift_spec), None, ),  # 2
        (3, TType.I32, 'dualRepSide', None, None, ),  # 3
        (4, TType.STRUCT, 'otherSideDualRepDmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'otherSideDualRepDmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 5
    )
    def __init__(self, status=None, data=None, dualRepSide=None, otherSideDualRepDmsListing=None, otherSideDualRepDmsTransaction=None, ):
        self.status = status
        self.data = data
        self.dualRepSide = dualRepSide
        self.otherSideDualRepDmsListing = otherSideDualRepDmsListing
        self.otherSideDualRepDmsTransaction = otherSideDualRepDmsTransaction

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.data = gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData()
                    self.data.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.otherSideDualRepDmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.otherSideDualRepDmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAggregateDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRUCT, 2)
            self.data.write(oprot)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 3)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsListing is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsListing', TType.STRUCT, 4)
            self.otherSideDualRepDmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsTransaction is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsTransaction', TType.STRUCT, 5)
            self.otherSideDualRepDmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAggregateInfoForGlideSyncRequest(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAggregateInfoForGlideSyncRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAggregateInfoForGlideSyncResponse(object):
    """
    Attributes:
     - status
     - data
     - otherSideClientIds
     - otherSideClientIdsTs
     - otherSideAgentIds
     - otherSideAgentIdsTs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'data', (gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData, gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'otherSideClientIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.I64, 'otherSideClientIdsTs', None, None, ),  # 4
        (5, TType.LIST, 'otherSideAgentIds', (TType.STRUCT, (gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId, gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId.thrift_spec), False), None, ),  # 5
        (6, TType.I64, 'otherSideAgentIdsTs', None, None, ),  # 6
    )
    def __init__(self, status=None, data=None, otherSideClientIds=None, otherSideClientIdsTs=None, otherSideAgentIds=None, otherSideAgentIdsTs=None, ):
        self.status = status
        self.data = data
        self.otherSideClientIds = otherSideClientIds
        self.otherSideClientIdsTs = otherSideClientIdsTs
        self.otherSideAgentIds = otherSideAgentIds
        self.otherSideAgentIdsTs = otherSideAgentIdsTs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.data = gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData()
                    self.data.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.otherSideClientIds = []
                    (_etype139, _size142) = iprot.readListBegin()
                    for _i140 in range(_size142):
                        _elem141 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.otherSideClientIds.append(_elem141)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.otherSideClientIdsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.otherSideAgentIds = []
                    (_etype143, _size146) = iprot.readListBegin()
                    for _i144 in range(_size146):
                        _elem145 = gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId()
                        _elem145.read(iprot)
                        self.otherSideAgentIds.append(_elem145)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.otherSideAgentIdsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAggregateInfoForGlideSyncResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRUCT, 2)
            self.data.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideClientIds is not None:
            oprot.writeFieldBegin('otherSideClientIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.otherSideClientIds))
            for _iter147 in self.otherSideClientIds:
                oprot.writeString(_iter147.encode('utf-8') if sys.version_info[0] == 2 else _iter147)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideClientIdsTs is not None:
            oprot.writeFieldBegin('otherSideClientIdsTs', TType.I64, 4)
            oprot.writeI64(self.otherSideClientIdsTs)
            oprot.writeFieldEnd()
        if self.otherSideAgentIds is not None:
            oprot.writeFieldBegin('otherSideAgentIds', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideAgentIds))
            for _iter148 in self.otherSideAgentIds:
                _iter148.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideAgentIdsTs is not None:
            oprot.writeFieldBegin('otherSideAgentIdsTs', TType.I64, 6)
            oprot.writeI64(self.otherSideAgentIdsTs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllChecklistsRequest(object):
    """
    Attributes:
     - dmsFolderId
     - checklistType
     - stage
     - userId
     - isStaff
     - dmsTransactionId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistType', None, None, ),  # 2
        (3, TType.I32, 'stage', None, None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'isStaff', None, None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 7
    )
    def __init__(self, dmsFolderId=None, checklistType=None, stage=None, userId=None, isStaff=None, dmsTransactionId=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.checklistType = checklistType
        self.stage = stage
        self.userId = userId
        self.isStaff = isStaff
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isStaff = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllChecklistsRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 2)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 3)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.isStaff is not None:
            oprot.writeFieldBegin('isStaff', TType.BOOL, 5)
            oprot.writeBool(self.isStaff)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 7)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllChecklistsResponse(object):
    """
    Attributes:
     - status
     - checklists
     - dmsFolder
     - dmsListing
     - dmsTransaction
     - dualRepSide
     - otherSideDualRepDmsListing
     - otherSideDualRepDmsTransaction
     - isSubmittedToCommission
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'checklists', (gen.urbancompass.dms_state_model.ttypes.DmsChecklists, gen.urbancompass.dms_state_model.ttypes.DmsChecklists.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 5
        (6, TType.I32, 'dualRepSide', None, None, ),  # 6
        (7, TType.STRUCT, 'otherSideDualRepDmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'otherSideDualRepDmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 8
        (9, TType.BOOL, 'isSubmittedToCommission', None, None, ),  # 9
    )
    def __init__(self, status=None, checklists=None, dmsFolder=None, dmsListing=None, dmsTransaction=None, dualRepSide=None, otherSideDualRepDmsListing=None, otherSideDualRepDmsTransaction=None, isSubmittedToCommission=None, ):
        self.status = status
        self.checklists = checklists
        self.dmsFolder = dmsFolder
        self.dmsListing = dmsListing
        self.dmsTransaction = dmsTransaction
        self.dualRepSide = dualRepSide
        self.otherSideDualRepDmsListing = otherSideDualRepDmsListing
        self.otherSideDualRepDmsTransaction = otherSideDualRepDmsTransaction
        self.isSubmittedToCommission = isSubmittedToCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.checklists = gen.urbancompass.dms_state_model.ttypes.DmsChecklists()
                    self.checklists.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.otherSideDualRepDmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.otherSideDualRepDmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isSubmittedToCommission = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllChecklistsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklists is not None:
            oprot.writeFieldBegin('checklists', TType.STRUCT, 2)
            self.checklists.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 3)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 4)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 5)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 6)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsListing is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsListing', TType.STRUCT, 7)
            self.otherSideDualRepDmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsTransaction is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsTransaction', TType.STRUCT, 8)
            self.otherSideDualRepDmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.isSubmittedToCommission is not None:
            oprot.writeFieldBegin('isSubmittedToCommission', TType.BOOL, 9)
            oprot.writeBool(self.isSubmittedToCommission)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllSubStageRequest(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllSubStageRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllSubStageResponse(object):
    """
    Attributes:
     - status
     - subStageForDisplay
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'subStageForDisplay', (TType.I32, None, TType.BOOL, None, False), None, ),  # 2
    )
    def __init__(self, status=None, subStageForDisplay=None, ):
        self.status = status
        self.subStageForDisplay = subStageForDisplay

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.subStageForDisplay = {}
                    (_ktype150, _vtype151, _size154) = iprot.readMapBegin()
                    for _i149 in range(_size154):
                        _key152 = iprot.readI32()
                        _val153 = iprot.readBool()
                        self.subStageForDisplay[_key152] = _val153
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllSubStageResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.subStageForDisplay is not None:
            oprot.writeFieldBegin('subStageForDisplay', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.BOOL, len(self.subStageForDisplay))
            for _kiter155, _viter156 in self.subStageForDisplay.items():
                oprot.writeI32(_kiter155)
                oprot.writeBool(_viter156)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAndFixIfNeededDMSAgentsForDualRepRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - otherSideDualRepDmsListing
     - otherSideDualRepDmsTransaction
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'otherSideDualRepDmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'otherSideDualRepDmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, dmsFolderId=None, otherSideDualRepDmsListing=None, otherSideDualRepDmsTransaction=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.otherSideDualRepDmsListing = otherSideDualRepDmsListing
        self.otherSideDualRepDmsTransaction = otherSideDualRepDmsTransaction
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.otherSideDualRepDmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.otherSideDualRepDmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAndFixIfNeededDMSAgentsForDualRepRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsListing is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsListing', TType.STRUCT, 3)
            self.otherSideDualRepDmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsTransaction is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsTransaction', TType.STRUCT, 4)
            self.otherSideDualRepDmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAndFixIfNeededDMSAgentsForDualRepResponse(object):
    """
    Attributes:
     - status
     - dmsAgents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsAgents=None, ):
        self.status = status
        self.dmsAgents = dmsAgents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype157, _size160) = iprot.readListBegin()
                    for _i158 in range(_size160):
                        _elem159 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem159.read(iprot)
                        self.dmsAgents.append(_elem159)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAndFixIfNeededDMSAgentsForDualRepResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter161 in self.dmsAgents:
                _iter161.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCancelledDMSTransactionsRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCancelledDMSTransactionsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCancelledDMSTransactionsResponse(object):
    """
    Attributes:
     - status
     - cancelledDMSTransactions
     - sideRepresented
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'cancelledDMSTransactions', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.CancelledDMSTransaction, gen.urbancompass.dms_state_model.ttypes.CancelledDMSTransaction.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
    )
    def __init__(self, status=None, cancelledDMSTransactions=None, sideRepresented=None, ):
        self.status = status
        self.cancelledDMSTransactions = cancelledDMSTransactions
        self.sideRepresented = sideRepresented

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.cancelledDMSTransactions = []
                    (_etype162, _size165) = iprot.readListBegin()
                    for _i163 in range(_size165):
                        _elem164 = gen.urbancompass.dms_state_model.ttypes.CancelledDMSTransaction()
                        _elem164.read(iprot)
                        self.cancelledDMSTransactions.append(_elem164)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCancelledDMSTransactionsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.cancelledDMSTransactions is not None:
            oprot.writeFieldBegin('cancelledDMSTransactions', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.cancelledDMSTransactions))
            for _iter166 in self.cancelledDMSTransactions:
                _iter166.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCapabilitiesOnDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
    )
    def __init__(self, userId=None, dmsFolderId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCapabilitiesOnDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCapabilitiesOnDMSFolderResponse(object):
    """
    Attributes:
     - status
     - userCapabilities
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'userCapabilities', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.UserCapabilities, gen.urbancompass.dms_state_model.ttypes.UserCapabilities.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, userCapabilities=None, ):
        self.status = status
        self.userCapabilities = userCapabilities

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.userCapabilities = []
                    (_etype167, _size170) = iprot.readListBegin()
                    for _i168 in range(_size170):
                        _elem169 = gen.urbancompass.dms_state_model.ttypes.UserCapabilities()
                        _elem169.read(iprot)
                        self.userCapabilities.append(_elem169)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCapabilitiesOnDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.userCapabilities is not None:
            oprot.writeFieldBegin('userCapabilities', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.userCapabilities))
            for _iter171 in self.userCapabilities:
                _iter171.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistDebugRequest(object):
    """
    Attributes:
     - userId
     - checklistType
     - sideRepresented
     - propertyType
     - listingType
     - propertyBuiltYear
     - state
     - market
     - dealType
     - purposeTypes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistType', None, None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.I32, 'propertyType', None, None, ),  # 4
        (5, TType.I32, 'listingType', None, None, ),  # 5
        (6, TType.I32, 'propertyBuiltYear', None, None, ),  # 6
        (7, TType.STRING, 'state', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'market', 'UTF8', None, ),  # 8
        (9, TType.I32, 'dealType', None, None, ),  # 9
        (10, TType.LIST, 'purposeTypes', (TType.I32, None, False), None, ),  # 10
    )
    def __init__(self, userId=None, checklistType=None, sideRepresented=None, propertyType=None, listingType=None, propertyBuiltYear=None, state=None, market=None, dealType=None, purposeTypes=None, ):
        self.userId = userId
        self.checklistType = checklistType
        self.sideRepresented = sideRepresented
        self.propertyType = propertyType
        self.listingType = listingType
        self.propertyBuiltYear = propertyBuiltYear
        self.state = state
        self.market = market
        self.dealType = dealType
        self.purposeTypes = purposeTypes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.propertyBuiltYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.purposeTypes = []
                    (_etype172, _size175) = iprot.readListBegin()
                    for _i173 in range(_size175):
                        _elem174 = iprot.readI32()
                        self.purposeTypes.append(_elem174)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 2)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 4)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 5)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyBuiltYear is not None:
            oprot.writeFieldBegin('propertyBuiltYear', TType.I32, 6)
            oprot.writeI32(self.propertyBuiltYear)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 7)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 8)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 9)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.purposeTypes is not None:
            oprot.writeFieldBegin('purposeTypes', TType.LIST, 10)
            oprot.writeListBegin(TType.I32, len(self.purposeTypes))
            for _iter176 in self.purposeTypes:
                oprot.writeI32(_iter176)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistDebugResponse(object):
    """
    Attributes:
     - status
     - checklists
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'checklists', (gen.urbancompass.dms_state_model.ttypes.DmsChecklists, gen.urbancompass.dms_state_model.ttypes.DmsChecklists.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, checklists=None, ):
        self.status = status
        self.checklists = checklists

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.checklists = gen.urbancompass.dms_state_model.ttypes.DmsChecklists()
                    self.checklists.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklists is not None:
            oprot.writeFieldBegin('checklists', TType.STRUCT, 2)
            self.checklists.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistItemRequest(object):
    """
    Attributes:
     - userId
     - itemId
     - stage
     - dmsListingId
     - dmsTransactionId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
        (3, TType.I32, 'stage', None, None, ),  # 3
        (4, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, itemId=None, stage=None, dmsListingId=None, dmsTransactionId=None, impersonatorId=None, dmsFolderId=None, ):
        self.userId = userId
        self.itemId = itemId
        self.stage = stage
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistItemRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 3)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 4)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistItemResponse(object):
    """
    Attributes:
     - status
     - listingChecklistItem
     - transactionChecklistItem
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'listingChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsListingChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsListingChecklistItem.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'transactionChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem.thrift_spec), None, ),  # 3
    )
    def __init__(self, status=None, listingChecklistItem=None, transactionChecklistItem=None, ):
        self.status = status
        self.listingChecklistItem = listingChecklistItem
        self.transactionChecklistItem = transactionChecklistItem

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listingChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsListingChecklistItem()
                    self.listingChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.transactionChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem()
                    self.transactionChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistItemResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.listingChecklistItem is not None:
            oprot.writeFieldBegin('listingChecklistItem', TType.STRUCT, 2)
            self.listingChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.transactionChecklistItem is not None:
            oprot.writeFieldBegin('transactionChecklistItem', TType.STRUCT, 3)
            self.transactionChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetClosingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, dmsFolderId=None, userId=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetClosingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetClosingResponse(object):
    """
    Attributes:
     - status
     - closing
     - code
     - errors
     - error
     - dmsDocuments
     - disableSubmitToCommission
     - disableSubmitToCommissionReasons
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'closing', (gen.urbancompass.closings.closings_service.ttypes.Closing, gen.urbancompass.closings.closings_service.ttypes.Closing.thrift_spec), None, ),  # 2
        (3, TType.I32, 'code', None, None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'error', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'dmsDocuments', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.ClosingDmsChecklistDocument, gen.urbancompass.dms_state_model.ttypes.ClosingDmsChecklistDocument.thrift_spec), False), None, ),  # 6
        (7, TType.BOOL, 'disableSubmitToCommission', None, None, ),  # 7
        (8, TType.LIST, 'disableSubmitToCommissionReasons', (TType.I32, None, False), None, ),  # 8
    )
    def __init__(self, status=None, closing=None, code=None, errors=None, error=None, dmsDocuments=None, disableSubmitToCommission=None, disableSubmitToCommissionReasons=None, ):
        self.status = status
        self.closing = closing
        self.code = code
        self.errors = errors
        self.error = error
        self.dmsDocuments = dmsDocuments
        self.disableSubmitToCommission = disableSubmitToCommission
        self.disableSubmitToCommissionReasons = disableSubmitToCommissionReasons

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.closing = gen.urbancompass.closings.closings_service.ttypes.Closing()
                    self.closing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype178, _vtype179, _size182) = iprot.readMapBegin()
                    for _i177 in range(_size182):
                        _key180 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val181 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key180] = _val181
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.dmsDocuments = []
                    (_etype183, _size186) = iprot.readListBegin()
                    for _i184 in range(_size186):
                        _elem185 = gen.urbancompass.dms_state_model.ttypes.ClosingDmsChecklistDocument()
                        _elem185.read(iprot)
                        self.dmsDocuments.append(_elem185)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.disableSubmitToCommission = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.disableSubmitToCommissionReasons = []
                    (_etype187, _size190) = iprot.readListBegin()
                    for _i188 in range(_size190):
                        _elem189 = iprot.readI32()
                        self.disableSubmitToCommissionReasons.append(_elem189)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetClosingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closing is not None:
            oprot.writeFieldBegin('closing', TType.STRUCT, 2)
            self.closing.write(oprot)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 3)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter191, _viter192 in self.errors.items():
                oprot.writeString(_kiter191.encode('utf-8') if sys.version_info[0] == 2 else _kiter191)
                oprot.writeString(_viter192.encode('utf-8') if sys.version_info[0] == 2 else _viter192)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 5)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.dmsDocuments is not None:
            oprot.writeFieldBegin('dmsDocuments', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsDocuments))
            for _iter193 in self.dmsDocuments:
                _iter193.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.disableSubmitToCommission is not None:
            oprot.writeFieldBegin('disableSubmitToCommission', TType.BOOL, 7)
            oprot.writeBool(self.disableSubmitToCommission)
            oprot.writeFieldEnd()
        if self.disableSubmitToCommissionReasons is not None:
            oprot.writeFieldBegin('disableSubmitToCommissionReasons', TType.LIST, 8)
            oprot.writeListBegin(TType.I32, len(self.disableSubmitToCommissionReasons))
            for _iter194 in self.disableSubmitToCommissionReasons:
                oprot.writeI32(_iter194)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderByTransactionRequest(object):
    """
    Attributes:
     - userId
     - dmsTransactionId
     - impersonatorId
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'includeDeleted', None, None, ),  # 4
    )
    def __init__(self, userId=None, dmsTransactionId=None, impersonatorId=None, includeDeleted=None, ):
        self.userId = userId
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderByTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 4)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderByTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsFolder
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
    )
    def __init__(self, status=None, dmsFolder=None, dmsTransactionId=None, ):
        self.status = status
        self.dmsFolder = dmsFolder
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderByTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 2)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderOverviewRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderOverviewRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderOverviewResponse(object):
    """
    Attributes:
     - status
     - dmsFolder
     - dmsListing
     - dmsTransactionId
     - listingDocumentsChecklistItem
     - transactionDocumentsChecklistItem
     - closedDocumentsChecklistItem
     - withdrawnCancelledDocumentsChecklistItem
     - dmsTransaction
     - commissionRequestChecklistItem
     - typeLocked
     - closing
     - hasAccessToClosing
     - dualRepSide
     - otherSideDualRepDmsListing
     - containsUndeletedDocuments
     - referredBy
     - referredTo
     - closingStatus
     - referralDetail
     - numberOfUnresolvedComments
     - issueTypeToCountMapping
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'listingDocumentsChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'transactionDocumentsChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'closedDocumentsChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'commissionRequestChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem.thrift_spec), None, ),  # 9
        (10, TType.BOOL, 'typeLocked', None, None, ),  # 10
        (11, TType.STRUCT, 'closing', (gen.urbancompass.closings.closings_service.ttypes.Closing, gen.urbancompass.closings.closings_service.ttypes.Closing.thrift_spec), None, ),  # 11
        (12, TType.BOOL, 'hasAccessToClosing', None, None, ),  # 12
        (13, TType.STRUCT, 'withdrawnCancelledDocumentsChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem.thrift_spec), None, ),  # 13
        (14, TType.I32, 'dualRepSide', None, None, ),  # 14
        (15, TType.STRUCT, 'otherSideDualRepDmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 15
        (16, TType.BOOL, 'containsUndeletedDocuments', None, None, ),  # 16
        (17, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 17
        (18, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 18
        (19, TType.I32, 'closingStatus', None, None, ),  # 19
        (20, TType.STRUCT, 'referralDetail', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail.thrift_spec), None, ),  # 20
        (21, TType.I32, 'numberOfUnresolvedComments', None, None, ),  # 21
        (22, TType.MAP, 'issueTypeToCountMapping', (TType.I32, None, TType.I32, None, False), None, ),  # 22
    )
    def __init__(self, status=None, dmsFolder=None, dmsListing=None, dmsTransactionId=None, listingDocumentsChecklistItem=None, transactionDocumentsChecklistItem=None, closedDocumentsChecklistItem=None, dmsTransaction=None, commissionRequestChecklistItem=None, typeLocked=None, closing=None, hasAccessToClosing=None, withdrawnCancelledDocumentsChecklistItem=None, dualRepSide=None, otherSideDualRepDmsListing=None, containsUndeletedDocuments=None, referredBy=None, referredTo=None, closingStatus=None, referralDetail=None, numberOfUnresolvedComments=None, issueTypeToCountMapping=None, ):
        self.status = status
        self.dmsFolder = dmsFolder
        self.dmsListing = dmsListing
        self.dmsTransactionId = dmsTransactionId
        self.listingDocumentsChecklistItem = listingDocumentsChecklistItem
        self.transactionDocumentsChecklistItem = transactionDocumentsChecklistItem
        self.closedDocumentsChecklistItem = closedDocumentsChecklistItem
        self.dmsTransaction = dmsTransaction
        self.commissionRequestChecklistItem = commissionRequestChecklistItem
        self.typeLocked = typeLocked
        self.closing = closing
        self.hasAccessToClosing = hasAccessToClosing
        self.withdrawnCancelledDocumentsChecklistItem = withdrawnCancelledDocumentsChecklistItem
        self.dualRepSide = dualRepSide
        self.otherSideDualRepDmsListing = otherSideDualRepDmsListing
        self.containsUndeletedDocuments = containsUndeletedDocuments
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.closingStatus = closingStatus
        self.referralDetail = referralDetail
        self.numberOfUnresolvedComments = numberOfUnresolvedComments
        self.issueTypeToCountMapping = issueTypeToCountMapping

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.listingDocumentsChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem()
                    self.listingDocumentsChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.transactionDocumentsChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem()
                    self.transactionDocumentsChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.closedDocumentsChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem()
                    self.closedDocumentsChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.commissionRequestChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem()
                    self.commissionRequestChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.typeLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.closing = gen.urbancompass.closings.closings_service.ttypes.Closing()
                    self.closing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.hasAccessToClosing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.withdrawnCancelledDocumentsChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem()
                    self.withdrawnCancelledDocumentsChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.otherSideDualRepDmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.containsUndeletedDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.closingStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRUCT:
                    self.referralDetail = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail()
                    self.referralDetail.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I32:
                    self.numberOfUnresolvedComments = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.MAP:
                    self.issueTypeToCountMapping = {}
                    (_ktype196, _vtype197, _size200) = iprot.readMapBegin()
                    for _i195 in range(_size200):
                        _key198 = iprot.readI32()
                        _val199 = iprot.readI32()
                        self.issueTypeToCountMapping[_key198] = _val199
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderOverviewResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 2)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 3)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 4)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.listingDocumentsChecklistItem is not None:
            oprot.writeFieldBegin('listingDocumentsChecklistItem', TType.STRUCT, 5)
            self.listingDocumentsChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.transactionDocumentsChecklistItem is not None:
            oprot.writeFieldBegin('transactionDocumentsChecklistItem', TType.STRUCT, 6)
            self.transactionDocumentsChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.closedDocumentsChecklistItem is not None:
            oprot.writeFieldBegin('closedDocumentsChecklistItem', TType.STRUCT, 7)
            self.closedDocumentsChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 8)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.commissionRequestChecklistItem is not None:
            oprot.writeFieldBegin('commissionRequestChecklistItem', TType.STRUCT, 9)
            self.commissionRequestChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.typeLocked is not None:
            oprot.writeFieldBegin('typeLocked', TType.BOOL, 10)
            oprot.writeBool(self.typeLocked)
            oprot.writeFieldEnd()
        if self.closing is not None:
            oprot.writeFieldBegin('closing', TType.STRUCT, 11)
            self.closing.write(oprot)
            oprot.writeFieldEnd()
        if self.hasAccessToClosing is not None:
            oprot.writeFieldBegin('hasAccessToClosing', TType.BOOL, 12)
            oprot.writeBool(self.hasAccessToClosing)
            oprot.writeFieldEnd()
        if self.withdrawnCancelledDocumentsChecklistItem is not None:
            oprot.writeFieldBegin('withdrawnCancelledDocumentsChecklistItem', TType.STRUCT, 13)
            self.withdrawnCancelledDocumentsChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 14)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsListing is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsListing', TType.STRUCT, 15)
            self.otherSideDualRepDmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.containsUndeletedDocuments is not None:
            oprot.writeFieldBegin('containsUndeletedDocuments', TType.BOOL, 16)
            oprot.writeBool(self.containsUndeletedDocuments)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 17)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 18)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.closingStatus is not None:
            oprot.writeFieldBegin('closingStatus', TType.I32, 19)
            oprot.writeI32(self.closingStatus)
            oprot.writeFieldEnd()
        if self.referralDetail is not None:
            oprot.writeFieldBegin('referralDetail', TType.STRUCT, 20)
            self.referralDetail.write(oprot)
            oprot.writeFieldEnd()
        if self.numberOfUnresolvedComments is not None:
            oprot.writeFieldBegin('numberOfUnresolvedComments', TType.I32, 21)
            oprot.writeI32(self.numberOfUnresolvedComments)
            oprot.writeFieldEnd()
        if self.issueTypeToCountMapping is not None:
            oprot.writeFieldBegin('issueTypeToCountMapping', TType.MAP, 22)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.issueTypeToCountMapping))
            for _kiter201, _viter202 in self.issueTypeToCountMapping.items():
                oprot.writeI32(_kiter201)
                oprot.writeI32(_viter202)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderRemindersRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderRemindersRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderRemindersResponse(object):
    """
    Attributes:
     - status
     - reminderList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'reminderList', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsFolderReminder, gen.urbancompass.dms_state_model.ttypes.DmsFolderReminder.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, reminderList=None, ):
        self.status = status
        self.reminderList = reminderList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.reminderList = []
                    (_etype203, _size206) = iprot.readListBegin()
                    for _i204 in range(_size206):
                        _elem205 = gen.urbancompass.dms_state_model.ttypes.DmsFolderReminder()
                        _elem205.read(iprot)
                        self.reminderList.append(_elem205)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderRemindersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.reminderList is not None:
            oprot.writeFieldBegin('reminderList', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.reminderList))
            for _iter207 in self.reminderList:
                _iter207.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'includeDeleted', None, None, ),  # 4
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, includeDeleted=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 4)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderResponse(object):
    """
    Attributes:
     - status
     - dmsFolder
     - referredBy
     - referredTo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 4
    )
    def __init__(self, status=None, dmsFolder=None, referredBy=None, referredTo=None, ):
        self.status = status
        self.dmsFolder = dmsFolder
        self.referredBy = referredBy
        self.referredTo = referredTo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 2)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 3)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 4)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersByCloseDateRangeRequest(object):
    """
    Attributes:
     - closeDateRange
     - excludeReferral
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'closeDateRange', (gen.urbancompass.dms_common.dms_deal.ttypes.DateRange, gen.urbancompass.dms_common.dms_deal.ttypes.DateRange.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'excludeReferral', None, None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, closeDateRange=None, excludeReferral=None, impersonatorId=None, ):
        self.closeDateRange = closeDateRange
        self.excludeReferral = excludeReferral
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.closeDateRange = gen.urbancompass.dms_common.dms_deal.ttypes.DateRange()
                    self.closeDateRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.excludeReferral = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersByCloseDateRangeRequest')
        if self.closeDateRange is not None:
            oprot.writeFieldBegin('closeDateRange', TType.STRUCT, 1)
            self.closeDateRange.write(oprot)
            oprot.writeFieldEnd()
        if self.excludeReferral is not None:
            oprot.writeFieldBegin('excludeReferral', TType.BOOL, 2)
            oprot.writeBool(self.excludeReferral)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersByCloseDateRangeResponse(object):
    """
    Attributes:
     - status
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'data', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData, gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, data=None, ):
        self.status = status
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype208, _size211) = iprot.readListBegin()
                    for _i209 in range(_size211):
                        _elem210 = gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData()
                        _elem210.read(iprot)
                        self.data.append(_elem210)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersByCloseDateRangeResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter212 in self.data:
                _iter212.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTByIdDebugRequest(object):
    """
    Attributes:
     - userId
     - btId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'btId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, btId=None, impersonatorId=None, ):
        self.userId = userId
        self.btId = btId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTByIdDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 2)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTByIdDebugResponse(object):
    """
    Attributes:
     - status
     - dmsFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolders', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTByIdDebug, gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTByIdDebug.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolders=None, ):
        self.status = status
        self.dmsFolders = dmsFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolders = []
                    (_etype213, _size216) = iprot.readListBegin()
                    for _i214 in range(_size216):
                        _elem215 = gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTByIdDebug()
                        _elem215.read(iprot)
                        self.dmsFolders.append(_elem215)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTByIdDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolders is not None:
            oprot.writeFieldBegin('dmsFolders', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsFolders))
            for _iter217 in self.dmsFolders:
                _iter217.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTDebugRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderIds
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderIds=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderIds = dmsFolderIds
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype218, _size221) = iprot.readListBegin()
                    for _i219 in range(_size221):
                        _elem220 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem220)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter222 in self.dmsFolderIds:
                oprot.writeString(_iter222.encode('utf-8') if sys.version_info[0] == 2 else _iter222)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTDebugResponse(object):
    """
    Attributes:
     - status
     - userId
     - dmsFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'dmsFolders', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTDebug, gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTDebug.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, userId=None, dmsFolders=None, ):
        self.status = status
        self.userId = userId
        self.dmsFolders = dmsFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.dmsFolders = []
                    (_etype223, _size226) = iprot.readListBegin()
                    for _i224 in range(_size226):
                        _elem225 = gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTDebug()
                        _elem225.read(iprot)
                        self.dmsFolders.append(_elem225)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolders is not None:
            oprot.writeFieldBegin('dmsFolders', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsFolders))
            for _iter227 in self.dmsFolders:
                _iter227.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersRequest(object):
    """
    Attributes:
     - userId
     - teams
     - groupIds
     - agent
     - propertyAddress
     - stage
     - stages
     - subStages
     - hasPendingDocuments
     - hasUnresolvedNotes
     - documentReviewStatus
     - folderSortingRequest
     - ctcServiceTypes
     - limit
     - offset
     - includeTotalCount
     - ignoreDefaultLimit
     - onlyListingWithAddress
     - includeDeletedTransaction
     - includeDeletedListing
     - excludeReferral
     - onlyIncludeLatestListingTransaction
     - dealTypes
     - includeStagesAndDealTypes
     - followOptimization
     - textQuery
     - impersonatorId
     - matchedAgentIds
     - matchedTeamIds
     - includeSubmittedListingOnly
     - folderTypes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'teams', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'groupIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.STRING, 'agent', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 5
        (6, TType.I32, 'stage', None, None, ),  # 6
        (7, TType.BOOL, 'hasPendingDocuments', None, None, ),  # 7
        (8, TType.I32, 'documentReviewStatus', None, None, ),  # 8
        (9, TType.STRUCT, 'folderSortingRequest', (gen.urbancompass.dms_common.dms_folder.ttypes.FolderSortingRequest, gen.urbancompass.dms_common.dms_folder.ttypes.FolderSortingRequest.thrift_spec), None, ),  # 9
        (10, TType.LIST, 'subStages', (TType.I32, None, False), None, ),  # 10
        (11, TType.I32, 'limit', None, None, ),  # 11
        (12, TType.I32, 'offset', None, None, ),  # 12
        (13, TType.BOOL, 'includeTotalCount', None, None, ),  # 13
        (14, TType.BOOL, 'onlyListingWithAddress', None, None, ),  # 14
        (15, TType.BOOL, 'ignoreDefaultLimit', None, None, ),  # 15
        (16, TType.BOOL, 'includeDeletedTransaction', None, None, ),  # 16
        (17, TType.BOOL, 'includeDeletedListing', None, None, ),  # 17
        (18, TType.BOOL, 'excludeReferral', None, None, ),  # 18
        (19, TType.BOOL, 'onlyIncludeLatestListingTransaction', None, None, ),  # 19
        (20, TType.LIST, 'ctcServiceTypes', (TType.I32, None, False), None, ),  # 20
        (21, TType.BOOL, 'followOptimization', None, None, ),  # 21
        (22, TType.STRING, 'textQuery', 'UTF8', None, ),  # 22
        (23, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 23
        (24, TType.LIST, 'matchedAgentIds', (TType.STRING, 'UTF8', False), None, ),  # 24
        (25, TType.LIST, 'matchedTeamIds', (TType.STRING, 'UTF8', False), None, ),  # 25
        (26, TType.BOOL, 'hasUnresolvedNotes', None, None, ),  # 26
        (27, TType.LIST, 'dealTypes', (TType.I32, None, False), None, ),  # 27
        (28, TType.LIST, 'stages', (TType.I32, None, False), None, ),  # 28
        (29, TType.BOOL, 'includeStagesAndDealTypes', None, None, ),  # 29
        (30, TType.BOOL, 'includeSubmittedListingOnly', None, None, ),  # 30
        (31, TType.LIST, 'folderTypes', (TType.I32, None, False), None, ),  # 31
    )
    def __init__(self, userId=None, teams=None, groupIds=None, agent=None, propertyAddress=None, stage=None, hasPendingDocuments=None, documentReviewStatus=None, folderSortingRequest=None, subStages=None, limit=None, offset=None, includeTotalCount=None, onlyListingWithAddress=None, ignoreDefaultLimit=None, includeDeletedTransaction=None, includeDeletedListing=None, excludeReferral=None, onlyIncludeLatestListingTransaction=None, ctcServiceTypes=None, followOptimization=None, textQuery=None, impersonatorId=None, matchedAgentIds=None, matchedTeamIds=None, hasUnresolvedNotes=None, dealTypes=None, stages=None, includeStagesAndDealTypes=None, includeSubmittedListingOnly=None, folderTypes=None, ):
        self.userId = userId
        self.teams = teams
        self.groupIds = groupIds
        self.agent = agent
        self.propertyAddress = propertyAddress
        self.stage = stage
        self.hasPendingDocuments = hasPendingDocuments
        self.documentReviewStatus = documentReviewStatus
        self.folderSortingRequest = folderSortingRequest
        self.subStages = subStages
        self.limit = limit
        self.offset = offset
        self.includeTotalCount = includeTotalCount
        self.onlyListingWithAddress = onlyListingWithAddress
        self.ignoreDefaultLimit = ignoreDefaultLimit
        self.includeDeletedTransaction = includeDeletedTransaction
        self.includeDeletedListing = includeDeletedListing
        self.excludeReferral = excludeReferral
        self.onlyIncludeLatestListingTransaction = onlyIncludeLatestListingTransaction
        self.ctcServiceTypes = ctcServiceTypes
        self.followOptimization = followOptimization
        self.textQuery = textQuery
        self.impersonatorId = impersonatorId
        self.matchedAgentIds = matchedAgentIds
        self.matchedTeamIds = matchedTeamIds
        self.hasUnresolvedNotes = hasUnresolvedNotes
        self.dealTypes = dealTypes
        self.stages = stages
        self.includeStagesAndDealTypes = includeStagesAndDealTypes
        self.includeSubmittedListingOnly = includeSubmittedListingOnly
        self.folderTypes = folderTypes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.teams = []
                    (_etype228, _size231) = iprot.readListBegin()
                    for _i229 in range(_size231):
                        _elem230 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.teams.append(_elem230)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.groupIds = []
                    (_etype232, _size235) = iprot.readListBegin()
                    for _i233 in range(_size235):
                        _elem234 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.groupIds.append(_elem234)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.agent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.hasPendingDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.documentReviewStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.folderSortingRequest = gen.urbancompass.dms_common.dms_folder.ttypes.FolderSortingRequest()
                    self.folderSortingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.subStages = []
                    (_etype236, _size239) = iprot.readListBegin()
                    for _i237 in range(_size239):
                        _elem238 = iprot.readI32()
                        self.subStages.append(_elem238)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.includeTotalCount = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.onlyListingWithAddress = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.ignoreDefaultLimit = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.includeDeletedTransaction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.includeDeletedListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.excludeReferral = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.onlyIncludeLatestListingTransaction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.ctcServiceTypes = []
                    (_etype240, _size243) = iprot.readListBegin()
                    for _i241 in range(_size243):
                        _elem242 = iprot.readI32()
                        self.ctcServiceTypes.append(_elem242)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.BOOL:
                    self.followOptimization = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.textQuery = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.LIST:
                    self.matchedAgentIds = []
                    (_etype244, _size247) = iprot.readListBegin()
                    for _i245 in range(_size247):
                        _elem246 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.matchedAgentIds.append(_elem246)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.LIST:
                    self.matchedTeamIds = []
                    (_etype248, _size251) = iprot.readListBegin()
                    for _i249 in range(_size251):
                        _elem250 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.matchedTeamIds.append(_elem250)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.BOOL:
                    self.hasUnresolvedNotes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.LIST:
                    self.dealTypes = []
                    (_etype252, _size255) = iprot.readListBegin()
                    for _i253 in range(_size255):
                        _elem254 = iprot.readI32()
                        self.dealTypes.append(_elem254)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.LIST:
                    self.stages = []
                    (_etype256, _size259) = iprot.readListBegin()
                    for _i257 in range(_size259):
                        _elem258 = iprot.readI32()
                        self.stages.append(_elem258)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.BOOL:
                    self.includeStagesAndDealTypes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.BOOL:
                    self.includeSubmittedListingOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.LIST:
                    self.folderTypes = []
                    (_etype260, _size263) = iprot.readListBegin()
                    for _i261 in range(_size263):
                        _elem262 = iprot.readI32()
                        self.folderTypes.append(_elem262)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.teams is not None:
            oprot.writeFieldBegin('teams', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.teams))
            for _iter264 in self.teams:
                oprot.writeString(_iter264.encode('utf-8') if sys.version_info[0] == 2 else _iter264)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.groupIds is not None:
            oprot.writeFieldBegin('groupIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.groupIds))
            for _iter265 in self.groupIds:
                oprot.writeString(_iter265.encode('utf-8') if sys.version_info[0] == 2 else _iter265)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agent is not None:
            oprot.writeFieldBegin('agent', TType.STRING, 4)
            oprot.writeString(self.agent.encode('utf-8') if sys.version_info[0] == 2 else self.agent)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 5)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 6)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.hasPendingDocuments is not None:
            oprot.writeFieldBegin('hasPendingDocuments', TType.BOOL, 7)
            oprot.writeBool(self.hasPendingDocuments)
            oprot.writeFieldEnd()
        if self.documentReviewStatus is not None:
            oprot.writeFieldBegin('documentReviewStatus', TType.I32, 8)
            oprot.writeI32(self.documentReviewStatus)
            oprot.writeFieldEnd()
        if self.folderSortingRequest is not None:
            oprot.writeFieldBegin('folderSortingRequest', TType.STRUCT, 9)
            self.folderSortingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.subStages is not None:
            oprot.writeFieldBegin('subStages', TType.LIST, 10)
            oprot.writeListBegin(TType.I32, len(self.subStages))
            for _iter266 in self.subStages:
                oprot.writeI32(_iter266)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 11)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 12)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.includeTotalCount is not None:
            oprot.writeFieldBegin('includeTotalCount', TType.BOOL, 13)
            oprot.writeBool(self.includeTotalCount)
            oprot.writeFieldEnd()
        if self.onlyListingWithAddress is not None:
            oprot.writeFieldBegin('onlyListingWithAddress', TType.BOOL, 14)
            oprot.writeBool(self.onlyListingWithAddress)
            oprot.writeFieldEnd()
        if self.ignoreDefaultLimit is not None:
            oprot.writeFieldBegin('ignoreDefaultLimit', TType.BOOL, 15)
            oprot.writeBool(self.ignoreDefaultLimit)
            oprot.writeFieldEnd()
        if self.includeDeletedTransaction is not None:
            oprot.writeFieldBegin('includeDeletedTransaction', TType.BOOL, 16)
            oprot.writeBool(self.includeDeletedTransaction)
            oprot.writeFieldEnd()
        if self.includeDeletedListing is not None:
            oprot.writeFieldBegin('includeDeletedListing', TType.BOOL, 17)
            oprot.writeBool(self.includeDeletedListing)
            oprot.writeFieldEnd()
        if self.excludeReferral is not None:
            oprot.writeFieldBegin('excludeReferral', TType.BOOL, 18)
            oprot.writeBool(self.excludeReferral)
            oprot.writeFieldEnd()
        if self.onlyIncludeLatestListingTransaction is not None:
            oprot.writeFieldBegin('onlyIncludeLatestListingTransaction', TType.BOOL, 19)
            oprot.writeBool(self.onlyIncludeLatestListingTransaction)
            oprot.writeFieldEnd()
        if self.ctcServiceTypes is not None:
            oprot.writeFieldBegin('ctcServiceTypes', TType.LIST, 20)
            oprot.writeListBegin(TType.I32, len(self.ctcServiceTypes))
            for _iter267 in self.ctcServiceTypes:
                oprot.writeI32(_iter267)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.followOptimization is not None:
            oprot.writeFieldBegin('followOptimization', TType.BOOL, 21)
            oprot.writeBool(self.followOptimization)
            oprot.writeFieldEnd()
        if self.textQuery is not None:
            oprot.writeFieldBegin('textQuery', TType.STRING, 22)
            oprot.writeString(self.textQuery.encode('utf-8') if sys.version_info[0] == 2 else self.textQuery)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 23)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.matchedAgentIds is not None:
            oprot.writeFieldBegin('matchedAgentIds', TType.LIST, 24)
            oprot.writeListBegin(TType.STRING, len(self.matchedAgentIds))
            for _iter268 in self.matchedAgentIds:
                oprot.writeString(_iter268.encode('utf-8') if sys.version_info[0] == 2 else _iter268)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.matchedTeamIds is not None:
            oprot.writeFieldBegin('matchedTeamIds', TType.LIST, 25)
            oprot.writeListBegin(TType.STRING, len(self.matchedTeamIds))
            for _iter269 in self.matchedTeamIds:
                oprot.writeString(_iter269.encode('utf-8') if sys.version_info[0] == 2 else _iter269)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hasUnresolvedNotes is not None:
            oprot.writeFieldBegin('hasUnresolvedNotes', TType.BOOL, 26)
            oprot.writeBool(self.hasUnresolvedNotes)
            oprot.writeFieldEnd()
        if self.dealTypes is not None:
            oprot.writeFieldBegin('dealTypes', TType.LIST, 27)
            oprot.writeListBegin(TType.I32, len(self.dealTypes))
            for _iter270 in self.dealTypes:
                oprot.writeI32(_iter270)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stages is not None:
            oprot.writeFieldBegin('stages', TType.LIST, 28)
            oprot.writeListBegin(TType.I32, len(self.stages))
            for _iter271 in self.stages:
                oprot.writeI32(_iter271)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeStagesAndDealTypes is not None:
            oprot.writeFieldBegin('includeStagesAndDealTypes', TType.BOOL, 29)
            oprot.writeBool(self.includeStagesAndDealTypes)
            oprot.writeFieldEnd()
        if self.includeSubmittedListingOnly is not None:
            oprot.writeFieldBegin('includeSubmittedListingOnly', TType.BOOL, 30)
            oprot.writeBool(self.includeSubmittedListingOnly)
            oprot.writeFieldEnd()
        if self.folderTypes is not None:
            oprot.writeFieldBegin('folderTypes', TType.LIST, 31)
            oprot.writeListBegin(TType.I32, len(self.folderTypes))
            for _iter272 in self.folderTypes:
                oprot.writeI32(_iter272)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersResponse(object):
    """
    Attributes:
     - status
     - data
     - totalCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'data', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData, gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalCount', None, None, ),  # 3
    )
    def __init__(self, status=None, data=None, totalCount=None, ):
        self.status = status
        self.data = data
        self.totalCount = totalCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype273, _size276) = iprot.readListBegin()
                    for _i274 in range(_size276):
                        _elem275 = gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData()
                        _elem275.read(iprot)
                        self.data.append(_elem275)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter277 in self.data:
                _iter277.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalCount is not None:
            oprot.writeFieldBegin('totalCount', TType.I32, 3)
            oprot.writeI32(self.totalCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSListingRequest(object):
    """
    Attributes:
     - userId
     - dmsListingId
     - includeDeleted
     - includeChecklist
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'includeDeleted', None, None, ),  # 3
        (4, TType.BOOL, 'includeChecklist', None, None, ),  # 4
        (5, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, dmsListingId=None, includeDeleted=None, includeChecklist=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsListingId = dmsListingId
        self.includeDeleted = includeDeleted
        self.includeChecklist = includeChecklist
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.includeChecklist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 3)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        if self.includeChecklist is not None:
            oprot.writeFieldBegin('includeChecklist', TType.BOOL, 4)
            oprot.writeBool(self.includeChecklist)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 5)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSListingResponse(object):
    """
    Attributes:
     - status
     - dmsListing
     - originalValueOfPatchedFields
     - patchedFields
     - dmsAgents
     - prohibitDeleteDmsListing
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'originalValueOfPatchedFields', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'patchedFields', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 5
        (6, TType.BOOL, 'prohibitDeleteDmsListing', None, None, ),  # 6
    )
    def __init__(self, status=None, dmsListing=None, originalValueOfPatchedFields=None, patchedFields=None, dmsAgents=None, prohibitDeleteDmsListing=None, ):
        self.status = status
        self.dmsListing = dmsListing
        self.originalValueOfPatchedFields = originalValueOfPatchedFields
        self.patchedFields = patchedFields
        self.dmsAgents = dmsAgents
        self.prohibitDeleteDmsListing = prohibitDeleteDmsListing

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.originalValueOfPatchedFields = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.originalValueOfPatchedFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.patchedFields = []
                    (_etype278, _size281) = iprot.readListBegin()
                    for _i279 in range(_size281):
                        _elem280 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.patchedFields.append(_elem280)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype282, _size285) = iprot.readListBegin()
                    for _i283 in range(_size285):
                        _elem284 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem284.read(iprot)
                        self.dmsAgents.append(_elem284)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.prohibitDeleteDmsListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 2)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.originalValueOfPatchedFields is not None:
            oprot.writeFieldBegin('originalValueOfPatchedFields', TType.STRUCT, 3)
            self.originalValueOfPatchedFields.write(oprot)
            oprot.writeFieldEnd()
        if self.patchedFields is not None:
            oprot.writeFieldBegin('patchedFields', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.patchedFields))
            for _iter286 in self.patchedFields:
                oprot.writeString(_iter286.encode('utf-8') if sys.version_info[0] == 2 else _iter286)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter287 in self.dmsAgents:
                _iter287.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.prohibitDeleteDmsListing is not None:
            oprot.writeFieldBegin('prohibitDeleteDmsListing', TType.BOOL, 6)
            oprot.writeBool(self.prohibitDeleteDmsListing)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSOfferDataRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSOfferDataRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSOfferDataResponse(object):
    """
    Attributes:
     - status
     - dmsFolder
     - dmsListing
     - dmsTransaction
     - originalValueOfPatchedFields
     - patchedFields
     - dmsContacts
     - dlfsContacts
     - dmsAgents
     - dualRepSide
     - otherSideDualRepDmsListing
     - otherSideDualRepDmsTransaction
     - otherSideDualRepAgents
     - prohibitDeleteDmsOffer
     - referredBy
     - referredTo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'originalValueOfPatchedFields', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'patchedFields', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), False), None, ),  # 7
        (8, TType.LIST, 'dlfsContacts', (TType.STRUCT, (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), False), None, ),  # 8
        (9, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 9
        (10, TType.I32, 'dualRepSide', None, None, ),  # 10
        (11, TType.STRUCT, 'otherSideDualRepDmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 11
        (12, TType.STRUCT, 'otherSideDualRepDmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 12
        (13, TType.LIST, 'otherSideDualRepAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 13
        (14, TType.BOOL, 'prohibitDeleteDmsOffer', None, None, ),  # 14
        (15, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 15
        (16, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 16
    )
    def __init__(self, status=None, dmsFolder=None, dmsListing=None, dmsTransaction=None, originalValueOfPatchedFields=None, patchedFields=None, dmsContacts=None, dlfsContacts=None, dmsAgents=None, dualRepSide=None, otherSideDualRepDmsListing=None, otherSideDualRepDmsTransaction=None, otherSideDualRepAgents=None, prohibitDeleteDmsOffer=None, referredBy=None, referredTo=None, ):
        self.status = status
        self.dmsFolder = dmsFolder
        self.dmsListing = dmsListing
        self.dmsTransaction = dmsTransaction
        self.originalValueOfPatchedFields = originalValueOfPatchedFields
        self.patchedFields = patchedFields
        self.dmsContacts = dmsContacts
        self.dlfsContacts = dlfsContacts
        self.dmsAgents = dmsAgents
        self.dualRepSide = dualRepSide
        self.otherSideDualRepDmsListing = otherSideDualRepDmsListing
        self.otherSideDualRepDmsTransaction = otherSideDualRepDmsTransaction
        self.otherSideDualRepAgents = otherSideDualRepAgents
        self.prohibitDeleteDmsOffer = prohibitDeleteDmsOffer
        self.referredBy = referredBy
        self.referredTo = referredTo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.originalValueOfPatchedFields = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.originalValueOfPatchedFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.patchedFields = []
                    (_etype288, _size291) = iprot.readListBegin()
                    for _i289 in range(_size291):
                        _elem290 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.patchedFields.append(_elem290)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype292, _size295) = iprot.readListBegin()
                    for _i293 in range(_size295):
                        _elem294 = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                        _elem294.read(iprot)
                        self.dmsContacts.append(_elem294)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.dlfsContacts = []
                    (_etype296, _size299) = iprot.readListBegin()
                    for _i297 in range(_size299):
                        _elem298 = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                        _elem298.read(iprot)
                        self.dlfsContacts.append(_elem298)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype300, _size303) = iprot.readListBegin()
                    for _i301 in range(_size303):
                        _elem302 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem302.read(iprot)
                        self.dmsAgents.append(_elem302)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.otherSideDualRepDmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepDmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.otherSideDualRepDmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.otherSideDualRepAgents = []
                    (_etype304, _size307) = iprot.readListBegin()
                    for _i305 in range(_size307):
                        _elem306 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem306.read(iprot)
                        self.otherSideDualRepAgents.append(_elem306)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.prohibitDeleteDmsOffer = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSOfferDataResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 2)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 3)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 4)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.originalValueOfPatchedFields is not None:
            oprot.writeFieldBegin('originalValueOfPatchedFields', TType.STRUCT, 5)
            self.originalValueOfPatchedFields.write(oprot)
            oprot.writeFieldEnd()
        if self.patchedFields is not None:
            oprot.writeFieldBegin('patchedFields', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.patchedFields))
            for _iter308 in self.patchedFields:
                oprot.writeString(_iter308.encode('utf-8') if sys.version_info[0] == 2 else _iter308)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter309 in self.dmsContacts:
                _iter309.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dlfsContacts is not None:
            oprot.writeFieldBegin('dlfsContacts', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.dlfsContacts))
            for _iter310 in self.dlfsContacts:
                _iter310.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter311 in self.dmsAgents:
                _iter311.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 10)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsListing is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsListing', TType.STRUCT, 11)
            self.otherSideDualRepDmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsTransaction is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsTransaction', TType.STRUCT, 12)
            self.otherSideDualRepDmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideDualRepAgents is not None:
            oprot.writeFieldBegin('otherSideDualRepAgents', TType.LIST, 13)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideDualRepAgents))
            for _iter312 in self.otherSideDualRepAgents:
                _iter312.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.prohibitDeleteDmsOffer is not None:
            oprot.writeFieldBegin('prohibitDeleteDmsOffer', TType.BOOL, 14)
            oprot.writeBool(self.prohibitDeleteDmsOffer)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 15)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 16)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSPayloadForNotificationRequest(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSPayloadForNotificationRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSPayloadForNotificationResponse(object):
    """
    Attributes:
     - status
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'data', (gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData, gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, data=None, ):
        self.status = status
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.data = gen.urbancompass.dms_state_model.ttypes.AggregateDmsFolderData()
                    self.data.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSPayloadForNotificationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRUCT, 2)
            self.data.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSTransactionRequest(object):
    """
    Attributes:
     - userId
     - dmsTransactionId
     - includeDeleted
     - includeChecklist
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'includeDeleted', None, None, ),  # 3
        (4, TType.BOOL, 'includeChecklist', None, None, ),  # 4
        (5, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, dmsTransactionId=None, includeDeleted=None, includeChecklist=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsTransactionId = dmsTransactionId
        self.includeDeleted = includeDeleted
        self.includeChecklist = includeChecklist
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.includeChecklist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 3)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        if self.includeChecklist is not None:
            oprot.writeFieldBegin('includeChecklist', TType.BOOL, 4)
            oprot.writeBool(self.includeChecklist)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 5)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsTransaction
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dmsTransaction=None, ):
        self.status = status
        self.dmsTransaction = dmsTransaction

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 2)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsContactsRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsContactsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsContactsResponse(object):
    """
    Attributes:
     - status
     - dmsContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsContacts=None, ):
        self.status = status
        self.dmsContacts = dmsContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype313, _size316) = iprot.readListBegin()
                    for _i314 in range(_size316):
                        _elem315 = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                        _elem315.read(iprot)
                        self.dmsContacts.append(_elem315)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsContactsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter317 in self.dmsContacts:
                _iter317.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsFolderComplianceStatusRequest(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsFolderComplianceStatusRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsFolderComplianceStatusResponse(object):
    """
    Attributes:
     - status
     - totalNumberOfCompliance
     - numberOfComplianceDone
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'totalNumberOfCompliance', None, None, ),  # 2
        (3, TType.I32, 'numberOfComplianceDone', None, None, ),  # 3
    )
    def __init__(self, status=None, totalNumberOfCompliance=None, numberOfComplianceDone=None, ):
        self.status = status
        self.totalNumberOfCompliance = totalNumberOfCompliance
        self.numberOfComplianceDone = numberOfComplianceDone

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.totalNumberOfCompliance = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.numberOfComplianceDone = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsFolderComplianceStatusResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.totalNumberOfCompliance is not None:
            oprot.writeFieldBegin('totalNumberOfCompliance', TType.I32, 2)
            oprot.writeI32(self.totalNumberOfCompliance)
            oprot.writeFieldEnd()
        if self.numberOfComplianceDone is not None:
            oprot.writeFieldBegin('numberOfComplianceDone', TType.I32, 3)
            oprot.writeI32(self.numberOfComplianceDone)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsFoldersWithNoStaffGroupIdRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsFoldersWithNoStaffGroupIdRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsFoldersWithNoStaffGroupIdResponse(object):
    """
    Attributes:
     - status
     - data
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'data', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, data=None, ):
        self.status = status
        self.data = data

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.data = []
                    (_etype318, _size321) = iprot.readListBegin()
                    for _i319 in range(_size321):
                        _elem320 = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                        _elem320.read(iprot)
                        self.data.append(_elem320)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsFoldersWithNoStaffGroupIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.data))
            for _iter322 in self.data:
                _iter322.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetNextActionRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetNextActionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetNextActionResponse(object):
    """
    Attributes:
     - status
     - nextAction
     - sideRepresented
     - isPrincipal
     - referralType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'nextAction', None, None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.BOOL, 'isPrincipal', None, None, ),  # 4
        (5, TType.I32, 'referralType', None, None, ),  # 5
    )
    def __init__(self, status=None, nextAction=None, sideRepresented=None, isPrincipal=None, referralType=None, ):
        self.status = status
        self.nextAction = nextAction
        self.sideRepresented = sideRepresented
        self.isPrincipal = isPrincipal
        self.referralType = referralType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.nextAction = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isPrincipal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetNextActionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.nextAction is not None:
            oprot.writeFieldBegin('nextAction', TType.I32, 2)
            oprot.writeI32(self.nextAction)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.isPrincipal is not None:
            oprot.writeFieldBegin('isPrincipal', TType.BOOL, 4)
            oprot.writeBool(self.isPrincipal)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 5)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPayloadInfoForCommunicationServiceRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - stage
     - resourceType
     - resourceId
     - forDeleted
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'stage', None, None, ),  # 3
        (4, TType.I32, 'resourceType', None, None, ),  # 4
        (5, TType.STRING, 'resourceId', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'forDeleted', None, None, ),  # 6
        (7, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, dmsFolderId=None, stage=None, resourceType=None, resourceId=None, forDeleted=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.stage = stage
        self.resourceType = resourceType
        self.resourceId = resourceId
        self.forDeleted = forDeleted
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.resourceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.resourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.forDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPayloadInfoForCommunicationServiceRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 3)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.resourceType is not None:
            oprot.writeFieldBegin('resourceType', TType.I32, 4)
            oprot.writeI32(self.resourceType)
            oprot.writeFieldEnd()
        if self.resourceId is not None:
            oprot.writeFieldBegin('resourceId', TType.STRING, 5)
            oprot.writeString(self.resourceId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceId)
            oprot.writeFieldEnd()
        if self.forDeleted is not None:
            oprot.writeFieldBegin('forDeleted', TType.BOOL, 6)
            oprot.writeBool(self.forDeleted)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 7)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPayloadInfoForCommunicationServiceResponse(object):
    """
    Attributes:
     - status
     - payloadInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'payloadInfo', (gen.urbancompass.dms_communication_model.ttypes.PayloadInfo, gen.urbancompass.dms_communication_model.ttypes.PayloadInfo.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, payloadInfo=None, ):
        self.status = status
        self.payloadInfo = payloadInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.payloadInfo = gen.urbancompass.dms_communication_model.ttypes.PayloadInfo()
                    self.payloadInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPayloadInfoForCommunicationServiceResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.payloadInfo is not None:
            oprot.writeFieldBegin('payloadInfo', TType.STRUCT, 2)
            self.payloadInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPermittedDMSFolderIDsRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderIds
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderIds=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderIds = dmsFolderIds
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype323, _size326) = iprot.readListBegin()
                    for _i324 in range(_size326):
                        _elem325 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem325)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPermittedDMSFolderIDsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter327 in self.dmsFolderIds:
                oprot.writeString(_iter327.encode('utf-8') if sys.version_info[0] == 2 else _iter327)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPermittedDMSFolderIDsResponse(object):
    """
    Attributes:
     - status
     - permittedDmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'permittedDmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, permittedDmsFolderIds=None, ):
        self.status = status
        self.permittedDmsFolderIds = permittedDmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.permittedDmsFolderIds = []
                    (_etype328, _size331) = iprot.readListBegin()
                    for _i329 in range(_size331):
                        _elem330 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.permittedDmsFolderIds.append(_elem330)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPermittedDMSFolderIDsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.permittedDmsFolderIds is not None:
            oprot.writeFieldBegin('permittedDmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.permittedDmsFolderIds))
            for _iter332 in self.permittedDmsFolderIds:
                oprot.writeString(_iter332.encode('utf-8') if sys.version_info[0] == 2 else _iter332)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPrincipalProfilesForTeamRequest(object):
    """
    Attributes:
     - teamId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
    )
    def __init__(self, teamId=None, ):
        self.teamId = teamId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPrincipalProfilesForTeamRequest')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPrincipalProfilesForTeamResponse(object):
    """
    Attributes:
     - status
     - principalEmails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'principalEmails', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, principalEmails=None, ):
        self.status = status
        self.principalEmails = principalEmails

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.principalEmails = []
                    (_etype333, _size336) = iprot.readListBegin()
                    for _i334 in range(_size336):
                        _elem335 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.principalEmails.append(_elem335)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPrincipalProfilesForTeamResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.principalEmails is not None:
            oprot.writeFieldBegin('principalEmails', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.principalEmails))
            for _iter337 in self.principalEmails:
                oprot.writeString(_iter337.encode('utf-8') if sys.version_info[0] == 2 else _iter337)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetStaticReferralChecklistItemsRequest(object):
    """
    Attributes:
     - dealType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'dealType', None, None, ),  # 1
    )
    def __init__(self, dealType=None, ):
        self.dealType = dealType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetStaticReferralChecklistItemsRequest')
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 1)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetStaticReferralChecklistItemsResponse(object):
    """
    Attributes:
     - status
     - checklistItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklistItems', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, checklistItems=None, ):
        self.status = status
        self.checklistItems = checklistItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistItems = []
                    (_etype338, _size341) = iprot.readListBegin()
                    for _i339 in range(_size341):
                        _elem340 = gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem()
                        _elem340.read(iprot)
                        self.checklistItems.append(_elem340)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetStaticReferralChecklistItemsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItems is not None:
            oprot.writeFieldBegin('checklistItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklistItems))
            for _iter342 in self.checklistItems:
                _iter342.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamDmsFoldersMatchingLocationRequest(object):
    """
    Attributes:
     - teamId
     - sideRepresentation
     - zipCode
     - address
     - userId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'sideRepresentation', None, None, ),  # 2
        (3, TType.STRING, 'zipCode', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'address', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'userId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, teamId=None, sideRepresentation=None, zipCode=None, address=None, userId=None, impersonatorId=None, ):
        self.teamId = teamId
        self.sideRepresentation = sideRepresentation
        self.zipCode = zipCode
        self.address = address
        self.userId = userId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.sideRepresentation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamDmsFoldersMatchingLocationRequest')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.sideRepresentation is not None:
            oprot.writeFieldBegin('sideRepresentation', TType.I32, 2)
            oprot.writeI32(self.sideRepresentation)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 3)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 4)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 5)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamDmsFoldersMatchingLocationResponse(object):
    """
    Attributes:
     - status
     - folders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'folders', (TType.STRUCT, (gen.urbancompass.dms_common.dms_folder.ttypes.TeamDmsFolderMatchingLocation, gen.urbancompass.dms_common.dms_folder.ttypes.TeamDmsFolderMatchingLocation.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, folders=None, ):
        self.status = status
        self.folders = folders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.folders = []
                    (_etype343, _size346) = iprot.readListBegin()
                    for _i344 in range(_size346):
                        _elem345 = gen.urbancompass.dms_common.dms_folder.ttypes.TeamDmsFolderMatchingLocation()
                        _elem345.read(iprot)
                        self.folders.append(_elem345)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamDmsFoldersMatchingLocationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.folders is not None:
            oprot.writeFieldBegin('folders', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.folders))
            for _iter347 in self.folders:
                _iter347.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserInternalRequest(object):
    """
    Attributes:
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
    )
    def __init__(self, userId=None, ):
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserInternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetWithdrawnDMSListingsRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
    )
    def __init__(self, userId=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetWithdrawnDMSListingsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetWithdrawnDMSListingsResponse(object):
    """
    Attributes:
     - status
     - withdrawnDMSListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'withdrawnDMSListings', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.WithdrawnDMSListing, gen.urbancompass.dms_state_model.ttypes.WithdrawnDMSListing.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, withdrawnDMSListings=None, ):
        self.status = status
        self.withdrawnDMSListings = withdrawnDMSListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.withdrawnDMSListings = []
                    (_etype348, _size351) = iprot.readListBegin()
                    for _i349 in range(_size351):
                        _elem350 = gen.urbancompass.dms_state_model.ttypes.WithdrawnDMSListing()
                        _elem350.read(iprot)
                        self.withdrawnDMSListings.append(_elem350)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetWithdrawnDMSListingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.withdrawnDMSListings is not None:
            oprot.writeFieldBegin('withdrawnDMSListings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.withdrawnDMSListings))
            for _iter352 in self.withdrawnDMSListings:
                _iter352.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SendNotificationsToKafkaRequest(object):
    """
    Attributes:
     - notifications
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'notifications', (TType.STRUCT, (gen.urbancompass.dms_common.dms_notification.ttypes.DMSNotification, gen.urbancompass.dms_common.dms_notification.ttypes.DMSNotification.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, notifications=None, ):
        self.notifications = notifications

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.notifications = []
                    (_etype353, _size356) = iprot.readListBegin()
                    for _i354 in range(_size356):
                        _elem355 = gen.urbancompass.dms_common.dms_notification.ttypes.DMSNotification()
                        _elem355.read(iprot)
                        self.notifications.append(_elem355)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SendNotificationsToKafkaRequest')
        if self.notifications is not None:
            oprot.writeFieldBegin('notifications', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.notifications))
            for _iter357 in self.notifications:
                _iter357.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SendNotificationsToKafkaResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SendNotificationsToKafkaResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetDMSContactsRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - dmsTransactionId
     - dmsContacts
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, dmsFolderId=None, dmsTransactionId=None, dmsContacts=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId
        self.dmsContacts = dmsContacts
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype358, _size361) = iprot.readListBegin()
                    for _i359 in range(_size361):
                        _elem360 = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                        _elem360.read(iprot)
                        self.dmsContacts.append(_elem360)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetDMSContactsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter362 in self.dmsContacts:
                _iter362.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetDMSContactsResponse(object):
    """
    Attributes:
     - status
     - dmsContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsContacts=None, ):
        self.status = status
        self.dmsContacts = dmsContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype363, _size366) = iprot.readListBegin()
                    for _i364 in range(_size366):
                        _elem365 = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                        _elem365.read(iprot)
                        self.dmsContacts.append(_elem365)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetDMSContactsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter367 in self.dmsContacts:
                _iter367.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShareDMSFolderInternalRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - userToShareWith
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userToShareWith', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, userId=None, userToShareWith=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.userToShareWith = userToShareWith
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userToShareWith = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShareDMSFolderInternalRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userToShareWith is not None:
            oprot.writeFieldBegin('userToShareWith', TType.STRING, 3)
            oprot.writeString(self.userToShareWith.encode('utf-8') if sys.version_info[0] == 2 else self.userToShareWith)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShareDMSFolderInternalResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShareDMSFolderInternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SortDmsFoldersRequest(object):
    """
    Attributes:
     - dmsFolderIds
     - dmsFolderSortingOption
     - descending
     - userId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'dmsFolderSortingOption', None, None, ),  # 2
        (3, TType.BOOL, 'descending', None, None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, dmsFolderIds=None, dmsFolderSortingOption=None, descending=None, userId=None, impersonatorId=None, ):
        self.dmsFolderIds = dmsFolderIds
        self.dmsFolderSortingOption = dmsFolderSortingOption
        self.descending = descending
        self.userId = userId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype368, _size371) = iprot.readListBegin()
                    for _i369 in range(_size371):
                        _elem370 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem370)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dmsFolderSortingOption = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.descending = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SortDmsFoldersRequest')
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter372 in self.dmsFolderIds:
                oprot.writeString(_iter372.encode('utf-8') if sys.version_info[0] == 2 else _iter372)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsFolderSortingOption is not None:
            oprot.writeFieldBegin('dmsFolderSortingOption', TType.I32, 2)
            oprot.writeI32(self.dmsFolderSortingOption)
            oprot.writeFieldEnd()
        if self.descending is not None:
            oprot.writeFieldBegin('descending', TType.BOOL, 3)
            oprot.writeBool(self.descending)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SortDmsFoldersResponse(object):
    """
    Attributes:
     - status
     - dmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderIds=None, ):
        self.status = status
        self.dmsFolderIds = dmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype373, _size376) = iprot.readListBegin()
                    for _i374 in range(_size376):
                        _elem375 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem375)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SortDmsFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter377 in self.dmsFolderIds:
                oprot.writeString(_iter377.encode('utf-8') if sys.version_info[0] == 2 else _iter377)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SplitDocumentRequest(object):
    """
    Attributes:
     - userId
     - documentId
     - checklistIdToPages
     - stage
     - dmsFolderId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.MAP, 'checklistIdToPages', (TType.I32, None, TType.STRUCT, (gen.urbancompass.dms_document.ttypes.PageInterval, gen.urbancompass.dms_document.ttypes.PageInterval.thrift_spec), False), None, ),  # 3
        (4, TType.I32, 'stage', None, None, ),  # 4
        (5, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, documentId=None, checklistIdToPages=None, stage=None, dmsFolderId=None, impersonatorId=None, ):
        self.userId = userId
        self.documentId = documentId
        self.checklistIdToPages = checklistIdToPages
        self.stage = stage
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.checklistIdToPages = {}
                    (_ktype379, _vtype380, _size383) = iprot.readMapBegin()
                    for _i378 in range(_size383):
                        _key381 = iprot.readI32()
                        _val382 = gen.urbancompass.dms_document.ttypes.PageInterval()
                        _val382.read(iprot)
                        self.checklistIdToPages[_key381] = _val382
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SplitDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.checklistIdToPages is not None:
            oprot.writeFieldBegin('checklistIdToPages', TType.MAP, 3)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.checklistIdToPages))
            for _kiter384, _viter385 in self.checklistIdToPages.items():
                oprot.writeI32(_kiter384)
                _viter385.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 4)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 5)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SplitDocumentResponse(object):
    """
    Attributes:
     - status
     - checklistIdtoDocumentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'checklistIdtoDocumentId', (TType.I32, None, TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, checklistIdtoDocumentId=None, ):
        self.status = status
        self.checklistIdtoDocumentId = checklistIdtoDocumentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.checklistIdtoDocumentId = {}
                    (_ktype387, _vtype388, _size391) = iprot.readMapBegin()
                    for _i386 in range(_size391):
                        _key389 = iprot.readI32()
                        _val390 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.checklistIdtoDocumentId[_key389] = _val390
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SplitDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistIdtoDocumentId is not None:
            oprot.writeFieldBegin('checklistIdtoDocumentId', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRING, len(self.checklistIdtoDocumentId))
            for _kiter392, _viter393 in self.checklistIdtoDocumentId.items():
                oprot.writeI32(_kiter392)
                oprot.writeString(_viter393.encode('utf-8') if sys.version_info[0] == 2 else _viter393)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnclaimDealRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
    )
    def __init__(self, userId=None, dmsFolderId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnclaimDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnclaimDealResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnclaimDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnshareDMSFolderInternalRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - userToUnshareWith
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userToUnshareWith', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, userId=None, userToUnshareWith=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.userToUnshareWith = userToUnshareWith
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userToUnshareWith = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnshareDMSFolderInternalRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userToUnshareWith is not None:
            oprot.writeFieldBegin('userToUnshareWith', TType.STRING, 3)
            oprot.writeString(self.userToUnshareWith.encode('utf-8') if sys.version_info[0] == 2 else self.userToUnshareWith)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnshareDMSFolderInternalResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnshareDMSFolderInternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateChecklistItemRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - listingChecklistItem
     - transactionChecklistItem
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'listingChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsListingChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsListingChecklistItem.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'transactionChecklistItem', (gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem.thrift_spec), None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, listingChecklistItem=None, transactionChecklistItem=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.listingChecklistItem = listingChecklistItem
        self.transactionChecklistItem = transactionChecklistItem

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.listingChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsListingChecklistItem()
                    self.listingChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.transactionChecklistItem = gen.urbancompass.dms_state_model.ttypes.DmsTransactionChecklistItem()
                    self.transactionChecklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateChecklistItemRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 4)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.listingChecklistItem is not None:
            oprot.writeFieldBegin('listingChecklistItem', TType.STRUCT, 6)
            self.listingChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.transactionChecklistItem is not None:
            oprot.writeFieldBegin('transactionChecklistItem', TType.STRUCT, 7)
            self.transactionChecklistItem.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateChecklistItemResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateChecklistItemResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateClosingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - closingRequest
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'closingRequest', (gen.urbancompass.closings.closings_service.ttypes.ClosingRequest, gen.urbancompass.closings.closings_service.ttypes.ClosingRequest.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, userId=None, closingRequest=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.closingRequest = closingRequest
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.closingRequest = gen.urbancompass.closings.closings_service.ttypes.ClosingRequest()
                    self.closingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateClosingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.closingRequest is not None:
            oprot.writeFieldBegin('closingRequest', TType.STRUCT, 3)
            self.closingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateClosingResponse(object):
    """
    Attributes:
     - status
     - closing
     - code
     - errors
     - error
     - dmsDocuments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'closing', (gen.urbancompass.closings.closings_service.ttypes.Closing, gen.urbancompass.closings.closings_service.ttypes.Closing.thrift_spec), None, ),  # 2
        (3, TType.I32, 'code', None, None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'error', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'dmsDocuments', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.ClosingDmsChecklistDocument, gen.urbancompass.dms_state_model.ttypes.ClosingDmsChecklistDocument.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, status=None, closing=None, code=None, errors=None, error=None, dmsDocuments=None, ):
        self.status = status
        self.closing = closing
        self.code = code
        self.errors = errors
        self.error = error
        self.dmsDocuments = dmsDocuments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.closing = gen.urbancompass.closings.closings_service.ttypes.Closing()
                    self.closing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype395, _vtype396, _size399) = iprot.readMapBegin()
                    for _i394 in range(_size399):
                        _key397 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val398 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key397] = _val398
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.dmsDocuments = []
                    (_etype400, _size403) = iprot.readListBegin()
                    for _i401 in range(_size403):
                        _elem402 = gen.urbancompass.dms_state_model.ttypes.ClosingDmsChecklistDocument()
                        _elem402.read(iprot)
                        self.dmsDocuments.append(_elem402)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateClosingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closing is not None:
            oprot.writeFieldBegin('closing', TType.STRUCT, 2)
            self.closing.write(oprot)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 3)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter404, _viter405 in self.errors.items():
                oprot.writeString(_kiter404.encode('utf-8') if sys.version_info[0] == 2 else _kiter404)
                oprot.writeString(_viter405.encode('utf-8') if sys.version_info[0] == 2 else _viter405)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 5)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.dmsDocuments is not None:
            oprot.writeFieldBegin('dmsDocuments', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsDocuments))
            for _iter406 in self.dmsDocuments:
                _iter406.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSAgentsForDualRepRequest(object):
    """
    Attributes:
     - dmsFolderId
     - dmsTransactionId
     - dualRepAgents
     - otherSideDmsFolderCreated
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'dualRepAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 3
        (4, TType.BOOL, 'otherSideDmsFolderCreated', None, None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, dmsTransactionId=None, dualRepAgents=None, otherSideDmsFolderCreated=None, ):
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId
        self.dualRepAgents = dualRepAgents
        self.otherSideDmsFolderCreated = otherSideDmsFolderCreated

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.dualRepAgents = []
                    (_etype407, _size410) = iprot.readListBegin()
                    for _i408 in range(_size410):
                        _elem409 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem409.read(iprot)
                        self.dualRepAgents.append(_elem409)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.otherSideDmsFolderCreated = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSAgentsForDualRepRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dualRepAgents is not None:
            oprot.writeFieldBegin('dualRepAgents', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.dualRepAgents))
            for _iter411 in self.dualRepAgents:
                _iter411.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideDmsFolderCreated is not None:
            oprot.writeFieldBegin('otherSideDmsFolderCreated', TType.BOOL, 4)
            oprot.writeBool(self.otherSideDmsFolderCreated)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSAgentsForDualRepResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSAgentsForDualRepResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - folderFieldsToUpdate
     - listingType
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'folderFieldsToUpdate', (gen.urbancompass.dms_state_model.ttypes.DmsFolder, gen.urbancompass.dms_state_model.ttypes.DmsFolder.thrift_spec), None, ),  # 3
        (4, TType.I32, 'listingType', None, None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, dmsFolderId=None, folderFieldsToUpdate=None, listingType=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.folderFieldsToUpdate = folderFieldsToUpdate
        self.listingType = listingType
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.folderFieldsToUpdate = gen.urbancompass.dms_state_model.ttypes.DmsFolder()
                    self.folderFieldsToUpdate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.folderFieldsToUpdate is not None:
            oprot.writeFieldBegin('folderFieldsToUpdate', TType.STRUCT, 3)
            self.folderFieldsToUpdate.write(oprot)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 4)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSFolderResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingDocumentRequest(object):
    """
    Attributes:
     - userId
     - dmsListingId
     - dmsFolderId
     - documentId
     - checklistItemId
     - impersonatorId
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'documentId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'checklistItemId', None, None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'includeDeleted', None, None, ),  # 7
    )
    def __init__(self, userId=None, dmsListingId=None, dmsFolderId=None, documentId=None, checklistItemId=None, impersonatorId=None, includeDeleted=None, ):
        self.userId = userId
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId
        self.documentId = documentId
        self.checklistItemId = checklistItemId
        self.impersonatorId = impersonatorId
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 4)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 5)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 7)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingRequest(object):
    """
    Attributes:
     - userId
     - team
     - dmsListingId
     - dmsFolderId
     - dealListingId
     - listingId
     - dmsListingToUpdate
     - onlyUpdateStatus
     - propertyType
     - listingType
     - propertyAddress
     - city
     - state
     - zipcode
     - listPrice
     - yearBuilt
     - usedConcierge
     - mediaUrl
     - unit
     - expirationDate
     - yearlyRent
     - impersonatorId
     - dmsAgents
     - doNotCallLDFS
     - origin
     - fieldsToReset
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'propertyType', None, None, ),  # 5
        (6, TType.I32, 'listingType', None, None, ),  # 6
        (7, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'city', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'state', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'zipcode', 'UTF8', None, ),  # 10
        (11, TType.DOUBLE, 'listPrice', None, None, ),  # 11
        (12, TType.I32, 'yearBuilt', None, None, ),  # 12
        (13, TType.STRING, 'team', 'UTF8', None, ),  # 13
        (14, TType.BOOL, 'usedConcierge', None, None, ),  # 14
        (15, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'unit', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'expirationDate', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'listingId', 'UTF8', None, ),  # 18
        (19, TType.DOUBLE, 'yearlyRent', None, None, ),  # 19
        (20, TType.STRUCT, 'dmsListingToUpdate', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 20
        (21, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'onlyUpdateStatus', None, None, ),  # 22
        (23, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 23
        (24, TType.BOOL, 'doNotCallLDFS', None, None, ),  # 24
        (25, TType.I32, 'origin', None, None, ),  # 25
        (26, TType.SET, 'fieldsToReset', (TType.STRING, 'UTF8', False), None, ),  # 26
    )
    def __init__(self, userId=None, dmsListingId=None, dmsFolderId=None, dealListingId=None, propertyType=None, listingType=None, propertyAddress=None, city=None, state=None, zipcode=None, listPrice=None, yearBuilt=None, team=None, usedConcierge=None, mediaUrl=None, unit=None, expirationDate=None, listingId=None, yearlyRent=None, dmsListingToUpdate=None, impersonatorId=None, onlyUpdateStatus=None, dmsAgents=None, doNotCallLDFS=None, origin=None, fieldsToReset=None, ):
        self.userId = userId
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId
        self.dealListingId = dealListingId
        self.propertyType = propertyType
        self.listingType = listingType
        self.propertyAddress = propertyAddress
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.yearBuilt = yearBuilt
        self.team = team
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.unit = unit
        self.expirationDate = expirationDate
        self.listingId = listingId
        self.yearlyRent = yearlyRent
        self.dmsListingToUpdate = dmsListingToUpdate
        self.impersonatorId = impersonatorId
        self.onlyUpdateStatus = onlyUpdateStatus
        self.dmsAgents = dmsAgents
        self.doNotCallLDFS = doNotCallLDFS
        self.origin = origin
        self.fieldsToReset = fieldsToReset

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.expirationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.DOUBLE:
                    self.yearlyRent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRUCT:
                    self.dmsListingToUpdate = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListingToUpdate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.onlyUpdateStatus = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype412, _size415) = iprot.readListBegin()
                    for _i413 in range(_size415):
                        _elem414 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem414.read(iprot)
                        self.dmsAgents.append(_elem414)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.doNotCallLDFS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.SET:
                    self.fieldsToReset = set()
                    (_etype417, _size419) = iprot.readSetBegin()
                    for _i416 in range(_size419):
                        _elem418 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fieldsToReset.add(_elem418)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 4)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 5)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 6)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 7)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 8)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 9)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 10)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 11)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 12)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 13)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 14)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 15)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 16)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.STRING, 17)
            oprot.writeString(self.expirationDate.encode('utf-8') if sys.version_info[0] == 2 else self.expirationDate)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 18)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.yearlyRent is not None:
            oprot.writeFieldBegin('yearlyRent', TType.DOUBLE, 19)
            oprot.writeDouble(self.yearlyRent)
            oprot.writeFieldEnd()
        if self.dmsListingToUpdate is not None:
            oprot.writeFieldBegin('dmsListingToUpdate', TType.STRUCT, 20)
            self.dmsListingToUpdate.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 21)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.onlyUpdateStatus is not None:
            oprot.writeFieldBegin('onlyUpdateStatus', TType.BOOL, 22)
            oprot.writeBool(self.onlyUpdateStatus)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 23)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter420 in self.dmsAgents:
                _iter420.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.doNotCallLDFS is not None:
            oprot.writeFieldBegin('doNotCallLDFS', TType.BOOL, 24)
            oprot.writeBool(self.doNotCallLDFS)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 25)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.fieldsToReset is not None:
            oprot.writeFieldBegin('fieldsToReset', TType.SET, 26)
            oprot.writeSetBegin(TType.STRING, len(self.fieldsToReset))
            for _iter421 in self.fieldsToReset:
                oprot.writeString(_iter421.encode('utf-8') if sys.version_info[0] == 2 else _iter421)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingResponse(object):
    """
    Attributes:
     - status
     - expiresIn
     - dmsAgents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'expiresIn', None, None, ),  # 2
        (3, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, expiresIn=None, dmsAgents=None, ):
        self.status = status
        self.expiresIn = expiresIn
        self.dmsAgents = dmsAgents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype422, _size425) = iprot.readListBegin()
                    for _i423 in range(_size425):
                        _elem424 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem424.read(iprot)
                        self.dmsAgents.append(_elem424)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 2)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter426 in self.dmsAgents:
                _iter426.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSTransactionDocumentRequest(object):
    """
    Attributes:
     - userId
     - dmsTransactionId
     - dmsFolderId
     - checklistItemId
     - documentId
     - impersonatorId
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'checklistItemId', None, None, ),  # 4
        (5, TType.STRING, 'documentId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'includeDeleted', None, None, ),  # 7
    )
    def __init__(self, userId=None, dmsTransactionId=None, dmsFolderId=None, checklistItemId=None, documentId=None, impersonatorId=None, includeDeleted=None, ):
        self.userId = userId
        self.dmsTransactionId = dmsTransactionId
        self.dmsFolderId = dmsFolderId
        self.checklistItemId = checklistItemId
        self.documentId = documentId
        self.impersonatorId = impersonatorId
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSTransactionDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 4)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 5)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 7)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSTransactionDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSTransactionDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSTransactionRequest(object):
    """
    Attributes:
     - userId
     - dmsTransactionId
     - dmsFolderId
     - dmsListingId
     - currentStage
     - currentSubStage
     - closeDate
     - acceptanceDate
     - commissionRate
     - closePrice
     - commissionRateAmount
     - dmsTransactionToUpdate
     - impersonatorId
     - shouldCreateDualRepDmsFolder
     - dualRepAgent
     - clientFromDmsContact
     - origin
     - fieldsToReset
     - syntheticEntity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'currentStage', None, None, ),  # 5
        (6, TType.I32, 'currentSubStage', None, None, ),  # 6
        (7, TType.STRING, 'closeDate', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'acceptanceDate', 'UTF8', None, ),  # 8
        (9, TType.DOUBLE, 'commissionRate', None, None, ),  # 9
        (10, TType.DOUBLE, 'closePrice', None, None, ),  # 10
        (11, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 11
        (12, TType.STRUCT, 'dmsTransactionToUpdate', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 12
        (13, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 13
        (14, TType.BOOL, 'shouldCreateDualRepDmsFolder', None, None, ),  # 14
        (15, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), None, ),  # 15
        (16, TType.STRUCT, 'clientFromDmsContact', (gen.urbancompass.dms_state_model.ttypes.DmsContact, gen.urbancompass.dms_state_model.ttypes.DmsContact.thrift_spec), None, ),  # 16
        (17, TType.I32, 'origin', None, None, ),  # 17
        (18, TType.SET, 'fieldsToReset', (TType.STRING, 'UTF8', False), None, ),  # 18
        (19, TType.I32, 'syntheticEntity', None, None, ),  # 19
    )
    def __init__(self, userId=None, dmsTransactionId=None, dmsFolderId=None, dmsListingId=None, currentStage=None, currentSubStage=None, closeDate=None, acceptanceDate=None, commissionRate=None, closePrice=None, commissionRateAmount=None, dmsTransactionToUpdate=None, impersonatorId=None, shouldCreateDualRepDmsFolder=None, dualRepAgent=None, clientFromDmsContact=None, origin=None, fieldsToReset=None, syntheticEntity=None, ):
        self.userId = userId
        self.dmsTransactionId = dmsTransactionId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.closeDate = closeDate
        self.acceptanceDate = acceptanceDate
        self.commissionRate = commissionRate
        self.closePrice = closePrice
        self.commissionRateAmount = commissionRateAmount
        self.dmsTransactionToUpdate = dmsTransactionToUpdate
        self.impersonatorId = impersonatorId
        self.shouldCreateDualRepDmsFolder = shouldCreateDualRepDmsFolder
        self.dualRepAgent = dualRepAgent
        self.clientFromDmsContact = clientFromDmsContact
        self.origin = origin
        self.fieldsToReset = fieldsToReset
        self.syntheticEntity = syntheticEntity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.acceptanceDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.dmsTransactionToUpdate = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransactionToUpdate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.shouldCreateDualRepDmsFolder = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.clientFromDmsContact = gen.urbancompass.dms_state_model.ttypes.DmsContact()
                    self.clientFromDmsContact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.SET:
                    self.fieldsToReset = set()
                    (_etype428, _size430) = iprot.readSetBegin()
                    for _i427 in range(_size430):
                        _elem429 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fieldsToReset.add(_elem429)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.syntheticEntity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 4)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 5)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 6)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 7)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.STRING, 8)
            oprot.writeString(self.acceptanceDate.encode('utf-8') if sys.version_info[0] == 2 else self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 9)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 10)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 11)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.dmsTransactionToUpdate is not None:
            oprot.writeFieldBegin('dmsTransactionToUpdate', TType.STRUCT, 12)
            self.dmsTransactionToUpdate.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 13)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.shouldCreateDualRepDmsFolder is not None:
            oprot.writeFieldBegin('shouldCreateDualRepDmsFolder', TType.BOOL, 14)
            oprot.writeBool(self.shouldCreateDualRepDmsFolder)
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 15)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.clientFromDmsContact is not None:
            oprot.writeFieldBegin('clientFromDmsContact', TType.STRUCT, 16)
            self.clientFromDmsContact.write(oprot)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 17)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.fieldsToReset is not None:
            oprot.writeFieldBegin('fieldsToReset', TType.SET, 18)
            oprot.writeSetBegin(TType.STRING, len(self.fieldsToReset))
            for _iter431 in self.fieldsToReset:
                oprot.writeString(_iter431.encode('utf-8') if sys.version_info[0] == 2 else _iter431)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.syntheticEntity is not None:
            oprot.writeFieldBegin('syntheticEntity', TType.I32, 19)
            oprot.writeI32(self.syntheticEntity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsTransactionId
     - dualRepSide
     - otherSideDualRepDmsFolderId
     - otherSideDualRepFolderBtId
     - otherSideDualRepAgents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'dualRepSide', None, None, ),  # 3
        (4, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'otherSideDualRepAgents', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsAgent, gen.urbancompass.dms_state_model.ttypes.DmsAgent.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, status=None, dmsTransactionId=None, dualRepSide=None, otherSideDualRepDmsFolderId=None, otherSideDualRepFolderBtId=None, otherSideDualRepAgents=None, ):
        self.status = status
        self.dmsTransactionId = dmsTransactionId
        self.dualRepSide = dualRepSide
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepAgents = otherSideDualRepAgents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.otherSideDualRepAgents = []
                    (_etype432, _size435) = iprot.readListBegin()
                    for _i433 in range(_size435):
                        _elem434 = gen.urbancompass.dms_state_model.ttypes.DmsAgent()
                        _elem434.read(iprot)
                        self.otherSideDualRepAgents.append(_elem434)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 3)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 4)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 5)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepAgents is not None:
            oprot.writeFieldBegin('otherSideDualRepAgents', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideDualRepAgents))
            for _iter436 in self.otherSideDualRepAgents:
                _iter436.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSTransactionSubStageFromDCRequest(object):
    """
    Attributes:
     - dmsTransactionId
     - dealStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'dealStatus', None, None, ),  # 2
    )
    def __init__(self, dmsTransactionId=None, dealStatus=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.dealStatus = dealStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dealStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSTransactionSubStageFromDCRequest')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dealStatus is not None:
            oprot.writeFieldBegin('dealStatus', TType.I32, 2)
            oprot.writeI32(self.dealStatus)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSTransactionSubStageFromDCResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSTransactionSubStageFromDCResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateReferralDetailRequest(object):
    """
    Attributes:
     - userId
     - dmsFolderId
     - referredBy
     - referredTo
     - referralDetail
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'referralDetail', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, dmsFolderId=None, referredBy=None, referredTo=None, referralDetail=None, impersonatorId=None, ):
        self.userId = userId
        self.dmsFolderId = dmsFolderId
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.referralDetail = referralDetail
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.referralDetail = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail()
                    self.referralDetail.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateReferralDetailRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 3)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 4)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.referralDetail is not None:
            oprot.writeFieldBegin('referralDetail', TType.STRUCT, 5)
            self.referralDetail.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateReferralDetailResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateReferralDetailResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertCustomChecklistItemByItemIdRequest(object):
    """
    Attributes:
     - userId
     - itemId
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - isRequired
     - stage
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'isRequired', None, None, ),  # 6
        (7, TType.I32, 'stage', None, None, ),  # 7
        (8, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, itemId=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, isRequired=None, stage=None, impersonatorId=None, ):
        self.userId = userId
        self.itemId = itemId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.isRequired = isRequired
        self.stage = stage
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertCustomChecklistItemByItemIdRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 4)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 6)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 7)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 8)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertCustomChecklistItemByItemIdResponse(object):
    """
    Attributes:
     - status
     - itemId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
    )
    def __init__(self, status=None, itemId=None, ):
        self.status = status
        self.itemId = itemId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertCustomChecklistItemByItemIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertDMSTransactionRequest(object):
    """
    Attributes:
     - dmsListingId
     - userId
     - team
     - dmsFolderId
     - dmsTransaction
     - impersonatorId
     - origin
     - dmsTransactionId
     - syntheticEntity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'team', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'origin', None, None, ),  # 7
        (8, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'syntheticEntity', None, None, ),  # 9
    )
    def __init__(self, dmsListingId=None, userId=None, team=None, dmsFolderId=None, dmsTransaction=None, impersonatorId=None, origin=None, dmsTransactionId=None, syntheticEntity=None, ):
        self.dmsListingId = dmsListingId
        self.userId = userId
        self.team = team
        self.dmsFolderId = dmsFolderId
        self.dmsTransaction = dmsTransaction
        self.impersonatorId = impersonatorId
        self.origin = origin
        self.dmsTransactionId = dmsTransactionId
        self.syntheticEntity = syntheticEntity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.syntheticEntity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertDMSTransactionRequest')
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 1)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 3)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 4)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 5)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 7)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 8)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.syntheticEntity is not None:
            oprot.writeFieldBegin('syntheticEntity', TType.I32, 9)
            oprot.writeI32(self.syntheticEntity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertDMSTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsTransactionId=None, ):
        self.status = status
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ValidateOneFieldRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - validateOneFieldRequest
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'validateOneFieldRequest', (gen.urbancompass.closings.closings_service.ttypes.ValidateOneFieldRequest, gen.urbancompass.closings.closings_service.ttypes.ValidateOneFieldRequest.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
    )
    def __init__(self, dmsFolderId=None, userId=None, validateOneFieldRequest=None, impersonatorId=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.validateOneFieldRequest = validateOneFieldRequest
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.validateOneFieldRequest = gen.urbancompass.closings.closings_service.ttypes.ValidateOneFieldRequest()
                    self.validateOneFieldRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ValidateOneFieldRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.validateOneFieldRequest is not None:
            oprot.writeFieldBegin('validateOneFieldRequest', TType.STRUCT, 3)
            self.validateOneFieldRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ValidateOneFieldResponse(object):
    """
    Attributes:
     - status
     - code
     - error
     - errors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'code', None, None, ),  # 2
        (3, TType.STRING, 'error', 'UTF8', None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, status=None, code=None, error=None, errors=None, ):
        self.status = status
        self.code = code
        self.error = error
        self.errors = errors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype438, _vtype439, _size442) = iprot.readMapBegin()
                    for _i437 in range(_size442):
                        _key440 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val441 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key440] = _val441
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ValidateOneFieldResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 2)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 3)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter443, _viter444 in self.errors.items():
                oprot.writeString(_kiter443.encode('utf-8') if sys.version_info[0] == 2 else _kiter443)
                oprot.writeString(_viter444.encode('utf-8') if sys.version_info[0] == 2 else _viter444)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetDMSFoldersOverviewResponse(object):
    """
    Attributes:
     - status
     - overviewOfDmsFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'overviewOfDmsFolders', (TType.STRING, 'UTF8', TType.STRUCT, (GetDMSFolderOverviewResponse, GetDMSFolderOverviewResponse.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, overviewOfDmsFolders=None, ):
        self.status = status
        self.overviewOfDmsFolders = overviewOfDmsFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.overviewOfDmsFolders = {}
                    (_ktype446, _vtype447, _size450) = iprot.readMapBegin()
                    for _i445 in range(_size450):
                        _key448 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val449 = GetDMSFolderOverviewResponse()
                        _val449.read(iprot)
                        self.overviewOfDmsFolders[_key448] = _val449
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetDMSFoldersOverviewResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.overviewOfDmsFolders is not None:
            oprot.writeFieldBegin('overviewOfDmsFolders', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.overviewOfDmsFolders))
            for _kiter451, _viter452 in self.overviewOfDmsFolders.items():
                oprot.writeString(_kiter451.encode('utf-8') if sys.version_info[0] == 2 else _kiter451)
                _viter452.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
