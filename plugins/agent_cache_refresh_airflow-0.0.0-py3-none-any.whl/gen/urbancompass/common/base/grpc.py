# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import uc.grpc.codec as _grpc_codec



class BaseServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.echo = channel.unary_unary(
        '/BaseService/echo',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(EchoResponse),
        )
    self.getServiceHealth = channel.unary_unary(
        '/BaseService/getServiceHealth',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ServiceHealth),
        )
    self.getSystemHealth = channel.unary_unary(
        '/BaseService/getSystemHealth',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SystemHealth),
        )



class BaseServiceServicer(object):
  """
    The BaseService Service definition
  """

  def echo(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getServiceHealth(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getSystemHealth(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_BaseServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'echo': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.echo(req),
          request_deserializer=_grpc_codec.deserializer(EchoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getServiceHealth': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getServiceHealth(req),
          request_deserializer=_grpc_codec.deserializer(None),
          response_serializer=_grpc_codec.serialize,
      ),
      'getSystemHealth': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getSystemHealth(req),
          request_deserializer=_grpc_codec.deserializer(None),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'BaseService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_BaseServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'echo': grpc.unary_unary_rpc_method_handler(
          servicer.echo,
          request_deserializer=_grpc_codec.deserializer(EchoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getServiceHealth': grpc.unary_unary_rpc_method_handler(
          servicer.getServiceHealth,
          request_deserializer=_grpc_codec.deserializer(None),
          response_serializer=_grpc_codec.serialize,
      ),
      'getSystemHealth': grpc.unary_unary_rpc_method_handler(
          servicer.getSystemHealth,
          request_deserializer=_grpc_codec.deserializer(None),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'BaseService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

