
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class LogicType(object):
    OR = 0
    AND = 1
    NOT = 2

    _VALUES_TO_NAMES = {
        0: "OR",
        1: "AND",
        2: "NOT",
    }

    _NAMES_TO_VALUES = {
        "OR": 0,
        "AND": 1,
        "NOT": 2,
    }


class RelativeTimeUnit(object):
    DAYS = 0
    MONTHS = 1
    YEARS = 2

    _VALUES_TO_NAMES = {
        0: "DAYS",
        1: "MONTHS",
        2: "YEARS",
    }

    _NAMES_TO_VALUES = {
        "DAYS": 0,
        "MONTHS": 1,
        "YEARS": 2,
    }


class SearchFeeType(object):
    NO_FEE = 0
    FREE_RENT = 1
    UC_OP = 2
    CYOF = 3

    _VALUES_TO_NAMES = {
        0: "NO_FEE",
        1: "FREE_RENT",
        2: "UC_OP",
        3: "CYOF",
    }

    _NAMES_TO_VALUES = {
        "NO_FEE": 0,
        "FREE_RENT": 1,
        "UC_OP": 2,
        "CYOF": 3,
    }


class WeekDay(object):
    MONDAY = 0
    TUESDAY = 1
    WEDNESDAY = 2
    THURSDAY = 3
    FRIDAY = 4
    SATURDAY = 5
    SUNDAY = 6

    _VALUES_TO_NAMES = {
        0: "MONDAY",
        1: "TUESDAY",
        2: "WEDNESDAY",
        3: "THURSDAY",
        4: "FRIDAY",
        5: "SATURDAY",
        6: "SUNDAY",
    }

    _NAMES_TO_VALUES = {
        "MONDAY": 0,
        "TUESDAY": 1,
        "WEDNESDAY": 2,
        "THURSDAY": 3,
        "FRIDAY": 4,
        "SATURDAY": 5,
        "SUNDAY": 6,
    }


class GeoLocation(object):
    """
    Attributes:
     - latitude
     - longitude
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'latitude', None, None, ),  # 1
        (2, TType.DOUBLE, 'longitude', None, None, ),  # 2
    )
    def __init__(self, latitude=None, longitude=None, ):
        self.latitude = latitude
        self.longitude = longitude

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.latitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.longitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GeoLocation')
        if self.latitude is not None:
            oprot.writeFieldBegin('latitude', TType.DOUBLE, 1)
            oprot.writeDouble(self.latitude)
            oprot.writeFieldEnd()
        if self.longitude is not None:
            oprot.writeFieldBegin('longitude', TType.DOUBLE, 2)
            oprot.writeDouble(self.longitude)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LocationGroup(object):
    """
    Attributes:
     - neighborhoodList
     - parentName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'neighborhoodList', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'parentName', 'UTF8', None, ),  # 2
    )
    def __init__(self, neighborhoodList=None, parentName=None, ):
        self.neighborhoodList = neighborhoodList
        self.parentName = parentName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.neighborhoodList = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.neighborhoodList.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.parentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LocationGroup')
        if self.neighborhoodList is not None:
            oprot.writeFieldBegin('neighborhoodList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.neighborhoodList))
            for _iter6 in self.neighborhoodList:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.parentName is not None:
            oprot.writeFieldBegin('parentName', TType.STRING, 2)
            oprot.writeString(self.parentName.encode('utf-8') if sys.version_info[0] == 2 else self.parentName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MinMaxPair(object):
    """
    Attributes:
     - min
     - max
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'min', None, None, ),  # 1
        (2, TType.DOUBLE, 'max', None, None, ),  # 2
    )
    def __init__(self, min=None, max=None, ):
        self.min = min
        self.max = max

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.min = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.max = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MinMaxPair')
        if self.min is not None:
            oprot.writeFieldBegin('min', TType.DOUBLE, 1)
            oprot.writeDouble(self.min)
            oprot.writeFieldEnd()
        if self.max is not None:
            oprot.writeFieldBegin('max', TType.DOUBLE, 2)
            oprot.writeDouble(self.max)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NeighborhoodInfo(object):
    """
    Attributes:
     - name
     - type
     - postalCity
     - county
     - state
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'type', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'postalCity', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'county', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'state', 'UTF8', None, ),  # 5
    )
    def __init__(self, name=None, type=None, postalCity=None, county=None, state=None, ):
        self.name = name
        self.type = type
        self.postalCity = postalCity
        self.county = county
        self.state = state

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.postalCity = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.county = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NeighborhoodInfo')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 2)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.postalCity is not None:
            oprot.writeFieldBegin('postalCity', TType.STRING, 3)
            oprot.writeString(self.postalCity.encode('utf-8') if sys.version_info[0] == 2 else self.postalCity)
            oprot.writeFieldEnd()
        if self.county is not None:
            oprot.writeFieldBegin('county', TType.STRING, 4)
            oprot.writeString(self.county.encode('utf-8') if sys.version_info[0] == 2 else self.county)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 5)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RelativeDate(object):
    """
    Attributes:
     - amountOfTime
     - relativeTimeUnit
     - relativeToTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'amountOfTime', None, None, ),  # 1
        (2, TType.I32, 'relativeTimeUnit', None, None, ),  # 2
        (3, TType.I64, 'relativeToTimestamp', None, None, ),  # 3
    )
    def __init__(self, amountOfTime=None, relativeTimeUnit=None, relativeToTimestamp=None, ):
        self.amountOfTime = amountOfTime
        self.relativeTimeUnit = relativeTimeUnit
        self.relativeToTimestamp = relativeToTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.amountOfTime = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.relativeTimeUnit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.relativeToTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RelativeDate')
        if self.amountOfTime is not None:
            oprot.writeFieldBegin('amountOfTime', TType.I32, 1)
            oprot.writeI32(self.amountOfTime)
            oprot.writeFieldEnd()
        if self.relativeTimeUnit is not None:
            oprot.writeFieldBegin('relativeTimeUnit', TType.I32, 2)
            oprot.writeI32(self.relativeTimeUnit)
            oprot.writeFieldEnd()
        if self.relativeToTimestamp is not None:
            oprot.writeFieldBegin('relativeToTimestamp', TType.I64, 3)
            oprot.writeI64(self.relativeToTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StringKeyValueList(object):
    """
    Attributes:
     - key
     - values
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'key', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'values', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, key=None, values=None, ):
        self.key = key
        self.values = values

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.key = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.values.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StringKeyValueList')
        if self.key is not None:
            oprot.writeFieldBegin('key', TType.STRING, 1)
            oprot.writeString(self.key.encode('utf-8') if sys.version_info[0] == 2 else self.key)
            oprot.writeFieldEnd()
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.values))
            for _iter11 in self.values:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StringKeyValuePair(object):
    """
    Attributes:
     - key
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'key', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
    )
    def __init__(self, key=None, value=None, ):
        self.key = key
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.key = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StringKeyValuePair')
        if self.key is not None:
            oprot.writeFieldBegin('key', TType.STRING, 1)
            oprot.writeString(self.key.encode('utf-8') if sys.version_info[0] == 2 else self.key)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StringValuesWithLogicType(object):
    """
    Attributes:
     - logicType
     - listValues
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'logicType', None, 0, ),  # 1
        (2, TType.LIST, 'listValues', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, logicType=thrift_spec[1][4], listValues=None, ):
        self.logicType = logicType
        self.listValues = listValues

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.logicType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listValues = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listValues.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StringValuesWithLogicType')
        if self.logicType is not None:
            oprot.writeFieldBegin('logicType', TType.I32, 1)
            oprot.writeI32(self.logicType)
            oprot.writeFieldEnd()
        if self.listValues is not None:
            oprot.writeFieldBegin('listValues', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.listValues))
            for _iter16 in self.listValues:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GeoBoundingBox(object):
    """
    Attributes:
     - swPoint
     - nePoint
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'swPoint', (GeoLocation, GeoLocation.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'nePoint', (GeoLocation, GeoLocation.thrift_spec), None, ),  # 2
    )
    def __init__(self, swPoint=None, nePoint=None, ):
        self.swPoint = swPoint
        self.nePoint = nePoint

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.swPoint = GeoLocation()
                    self.swPoint.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.nePoint = GeoLocation()
                    self.nePoint.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GeoBoundingBox')
        if self.swPoint is not None:
            oprot.writeFieldBegin('swPoint', TType.STRUCT, 1)
            self.swPoint.write(oprot)
            oprot.writeFieldEnd()
        if self.nePoint is not None:
            oprot.writeFieldBegin('nePoint', TType.STRUCT, 2)
            self.nePoint.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GeoCircle(object):
    """
    Attributes:
     - center
     - radiusInMeters
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'center', (GeoLocation, GeoLocation.thrift_spec), None, ),  # 1
        (2, TType.DOUBLE, 'radiusInMeters', None, None, ),  # 2
    )
    def __init__(self, center=None, radiusInMeters=None, ):
        self.center = center
        self.radiusInMeters = radiusInMeters

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.center = GeoLocation()
                    self.center.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.radiusInMeters = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GeoCircle')
        if self.center is not None:
            oprot.writeFieldBegin('center', TType.STRUCT, 1)
            self.center.write(oprot)
            oprot.writeFieldEnd()
        if self.radiusInMeters is not None:
            oprot.writeFieldBegin('radiusInMeters', TType.DOUBLE, 2)
            oprot.writeDouble(self.radiusInMeters)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MinMaxPairValuesWithLogicType(object):
    """
    Attributes:
     - logicType
     - listValues
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'logicType', None, 0, ),  # 1
        (2, TType.LIST, 'listValues', (TType.STRUCT, (MinMaxPair, MinMaxPair.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, logicType=thrift_spec[1][4], listValues=None, ):
        self.logicType = logicType
        self.listValues = listValues

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.logicType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listValues = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = MinMaxPair()
                        _elem19.read(iprot)
                        self.listValues.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MinMaxPairValuesWithLogicType')
        if self.logicType is not None:
            oprot.writeFieldBegin('logicType', TType.I32, 1)
            oprot.writeI32(self.logicType)
            oprot.writeFieldEnd()
        if self.listValues is not None:
            oprot.writeFieldBegin('listValues', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listValues))
            for _iter21 in self.listValues:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Note(object):
    """
    Attributes:
     - _id
     - author
     - authorId
     - location
     - createdAt
     - txt
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'author', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'location', (GeoLocation, GeoLocation.thrift_spec), None, ),  # 3
        (4, TType.I64, 'createdAt', None, None, ),  # 4
        (5, TType.STRING, 'txt', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'listings', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.STRING, 'authorId', 'UTF8', None, ),  # 7
    )
    def __init__(self, _id=None, author=None, location=None, createdAt=None, txt=None, listings=None, authorId=None, ):
        self._id = _id
        self.author = author
        self.location = location
        self.createdAt = createdAt
        self.txt = txt
        self.listings = listings
        self.authorId = authorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.author = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.location = GeoLocation()
                    self.location.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.txt = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listings.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.authorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Note')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.author is not None:
            oprot.writeFieldBegin('author', TType.STRING, 2)
            oprot.writeString(self.author.encode('utf-8') if sys.version_info[0] == 2 else self.author)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.STRUCT, 3)
            self.location.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 4)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.txt is not None:
            oprot.writeFieldBegin('txt', TType.STRING, 5)
            oprot.writeString(self.txt.encode('utf-8') if sys.version_info[0] == 2 else self.txt)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.listings))
            for _iter26 in self.listings:
                oprot.writeString(_iter26.encode('utf-8') if sys.version_info[0] == 2 else _iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.authorId is not None:
            oprot.writeFieldBegin('authorId', TType.STRING, 7)
            oprot.writeString(self.authorId.encode('utf-8') if sys.version_info[0] == 2 else self.authorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RelativeDateRange(object):
    """
    Attributes:
     - min
     - max
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'min', (RelativeDate, RelativeDate.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'max', (RelativeDate, RelativeDate.thrift_spec), None, ),  # 2
    )
    def __init__(self, min=None, max=None, ):
        self.min = min
        self.max = max

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.min = RelativeDate()
                    self.min.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.max = RelativeDate()
                    self.max.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RelativeDateRange')
        if self.min is not None:
            oprot.writeFieldBegin('min', TType.STRUCT, 1)
            self.min.write(oprot)
            oprot.writeFieldEnd()
        if self.max is not None:
            oprot.writeFieldBegin('max', TType.STRUCT, 2)
            self.max.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
