
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class GetContactInvitesOrder(object):
    CREATED_AT = 0
    CREATED_AT_DESC = 1
    CREATED_AT_DESC_NULLS_FIRST = 2
    CREATED_AT_DESC_NULLS_LAST = 3
    CREATED_AT_NULLS_FIRST = 4
    ID = 5
    ID_DESC = 6
    ID_DESC_NULLS_FIRST = 7
    ID_DESC_NULLS_LAST = 8
    ID_NULLS_FIRST = 9
    NAME = 10
    NAME_DESC = 11
    NAME_DESC_NULLS_FIRST = 12
    NAME_DESC_NULLS_LAST = 13
    NAME_NULLS_FIRST = 14
    UPDATED_AT = 15
    UPDATED_AT_DESC = 16
    UPDATED_AT_DESC_NULLS_FIRST = 17
    UPDATED_AT_DESC_NULLS_LAST = 18
    UPDATED_AT_NULLS_FIRST = 19

    _VALUES_TO_NAMES = {
        0: "CREATED_AT",
        1: "CREATED_AT_DESC",
        2: "CREATED_AT_DESC_NULLS_FIRST",
        3: "CREATED_AT_DESC_NULLS_LAST",
        4: "CREATED_AT_NULLS_FIRST",
        5: "ID",
        6: "ID_DESC",
        7: "ID_DESC_NULLS_FIRST",
        8: "ID_DESC_NULLS_LAST",
        9: "ID_NULLS_FIRST",
        10: "NAME",
        11: "NAME_DESC",
        12: "NAME_DESC_NULLS_FIRST",
        13: "NAME_DESC_NULLS_LAST",
        14: "NAME_NULLS_FIRST",
        15: "UPDATED_AT",
        16: "UPDATED_AT_DESC",
        17: "UPDATED_AT_DESC_NULLS_FIRST",
        18: "UPDATED_AT_DESC_NULLS_LAST",
        19: "UPDATED_AT_NULLS_FIRST",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT": 0,
        "CREATED_AT_DESC": 1,
        "CREATED_AT_DESC_NULLS_FIRST": 2,
        "CREATED_AT_DESC_NULLS_LAST": 3,
        "CREATED_AT_NULLS_FIRST": 4,
        "ID": 5,
        "ID_DESC": 6,
        "ID_DESC_NULLS_FIRST": 7,
        "ID_DESC_NULLS_LAST": 8,
        "ID_NULLS_FIRST": 9,
        "NAME": 10,
        "NAME_DESC": 11,
        "NAME_DESC_NULLS_FIRST": 12,
        "NAME_DESC_NULLS_LAST": 13,
        "NAME_NULLS_FIRST": 14,
        "UPDATED_AT": 15,
        "UPDATED_AT_DESC": 16,
        "UPDATED_AT_DESC_NULLS_FIRST": 17,
        "UPDATED_AT_DESC_NULLS_LAST": 18,
        "UPDATED_AT_NULLS_FIRST": 19,
    }


class ContactInvite(object):
    """
    Attributes:
     - accountCreatedAt
     - contactId
     - createdAt
     - email
     - sentViaCompass
     - id
     - name
     - sentAt
     - updatedAt
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'accountCreatedAt', None, None, ),  # 1
        (2, TType.STRING, 'contactId', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'sentViaCompass', None, None, ),  # 5
        (6, TType.STRING, 'id', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'name', 'UTF8', None, ),  # 7
        (8, TType.I64, 'sentAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.STRING, 'userId', 'UTF8', None, ),  # 10
    )
    def __init__(self, accountCreatedAt=None, contactId=None, createdAt=None, email=None, sentViaCompass=None, id=None, name=None, sentAt=None, updatedAt=None, userId=None, ):
        self.accountCreatedAt = accountCreatedAt
        self.contactId = contactId
        self.createdAt = createdAt
        self.email = email
        self.sentViaCompass = sentViaCompass
        self.id = id
        self.name = name
        self.sentAt = sentAt
        self.updatedAt = updatedAt
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.accountCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.sentViaCompass = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.sentAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactInvite')
        if self.accountCreatedAt is not None:
            oprot.writeFieldBegin('accountCreatedAt', TType.I64, 1)
            oprot.writeI64(self.accountCreatedAt)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 2)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.sentViaCompass is not None:
            oprot.writeFieldBegin('sentViaCompass', TType.BOOL, 5)
            oprot.writeBool(self.sentViaCompass)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 6)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 7)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.sentAt is not None:
            oprot.writeFieldBegin('sentAt', TType.I64, 8)
            oprot.writeI64(self.sentAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 10)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
