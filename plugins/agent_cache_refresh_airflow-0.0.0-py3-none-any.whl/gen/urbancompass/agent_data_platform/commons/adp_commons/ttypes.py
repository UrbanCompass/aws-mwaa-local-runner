
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class AgentStatus(object):
    RECRUIT = 0
    PREBOARDING = 1
    SEPARATED = 2
    AGENT = 3
    DECLINED = 4
    IN_TRANSITION = 5

    _VALUES_TO_NAMES = {
        0: "RECRUIT",
        1: "PREBOARDING",
        2: "SEPARATED",
        3: "AGENT",
        4: "DECLINED",
        5: "IN_TRANSITION",
    }

    _NAMES_TO_VALUES = {
        "RECRUIT": 0,
        "PREBOARDING": 1,
        "SEPARATED": 2,
        "AGENT": 3,
        "DECLINED": 4,
        "IN_TRANSITION": 5,
    }


class CatalogStatus(object):
    ACTIVE = 0
    INACTIVE = 1

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "INACTIVE",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "INACTIVE": 1,
    }


class ChangeRequestType(object):
    NEW = 0
    ADD_PERSON_EXISTING = 1
    ADD_PERSON_NEW = 2
    ADD_ROLE_EXISTING = 3
    ADD_ROLE_NEW = 4
    CHANGE_ROLE_EXISTING = 5
    CHANGE_ROLE_NEW = 6
    MOVE_EXISTING = 7
    MOVE_NEW = 8
    MOVE_CHANGE_ROLE_EXISTING = 9
    MOVE_CHANGE_ROLE_NEW = 10
    RENEGOTIATE_EXISTING = 11
    RENEGOTIATE_NEW = 12
    SEPARATE_COMPASS = 13
    DISSOLVE_TEAM = 14
    EXISTING = 15

    _VALUES_TO_NAMES = {
        0: "NEW",
        1: "ADD_PERSON_EXISTING",
        2: "ADD_PERSON_NEW",
        3: "ADD_ROLE_EXISTING",
        4: "ADD_ROLE_NEW",
        5: "CHANGE_ROLE_EXISTING",
        6: "CHANGE_ROLE_NEW",
        7: "MOVE_EXISTING",
        8: "MOVE_NEW",
        9: "MOVE_CHANGE_ROLE_EXISTING",
        10: "MOVE_CHANGE_ROLE_NEW",
        11: "RENEGOTIATE_EXISTING",
        12: "RENEGOTIATE_NEW",
        13: "SEPARATE_COMPASS",
        14: "DISSOLVE_TEAM",
        15: "EXISTING",
    }

    _NAMES_TO_VALUES = {
        "NEW": 0,
        "ADD_PERSON_EXISTING": 1,
        "ADD_PERSON_NEW": 2,
        "ADD_ROLE_EXISTING": 3,
        "ADD_ROLE_NEW": 4,
        "CHANGE_ROLE_EXISTING": 5,
        "CHANGE_ROLE_NEW": 6,
        "MOVE_EXISTING": 7,
        "MOVE_NEW": 8,
        "MOVE_CHANGE_ROLE_EXISTING": 9,
        "MOVE_CHANGE_ROLE_NEW": 10,
        "RENEGOTIATE_EXISTING": 11,
        "RENEGOTIATE_NEW": 12,
        "SEPARATE_COMPASS": 13,
        "DISSOLVE_TEAM": 14,
        "EXISTING": 15,
    }


class CompassBrokerage(object):
    COMPASS = 0
    PACIFIC_UNION = 1
    ALAIN_PINEL = 2

    _VALUES_TO_NAMES = {
        0: "COMPASS",
        1: "PACIFIC_UNION",
        2: "ALAIN_PINEL",
    }

    _NAMES_TO_VALUES = {
        "COMPASS": 0,
        "PACIFIC_UNION": 1,
        "ALAIN_PINEL": 2,
    }


class ContractStatus(object):
    NEW = 0
    ACTIVE = 1
    ARCHIVE = 2
    VOID = 3

    _VALUES_TO_NAMES = {
        0: "NEW",
        1: "ACTIVE",
        2: "ARCHIVE",
        3: "VOID",
    }

    _NAMES_TO_VALUES = {
        "NEW": 0,
        "ACTIVE": 1,
        "ARCHIVE": 2,
        "VOID": 3,
    }


class IcaDraftStatus(object):
    ACTIVE = 0
    SOFT_DELETE = 1

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "SOFT_DELETE",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "SOFT_DELETE": 1,
    }


class IcaStatus(object):
    NEW = 0
    SENT_FOR_SIGNATURE = 1
    EXECUTED = 2
    REJECTED = 3
    VOID = 4
    SENT_TO_SPRINGCM = 5
    MIGRATED = 6

    _VALUES_TO_NAMES = {
        0: "NEW",
        1: "SENT_FOR_SIGNATURE",
        2: "EXECUTED",
        3: "REJECTED",
        4: "VOID",
        5: "SENT_TO_SPRINGCM",
        6: "MIGRATED",
    }

    _NAMES_TO_VALUES = {
        "NEW": 0,
        "SENT_FOR_SIGNATURE": 1,
        "EXECUTED": 2,
        "REJECTED": 3,
        "VOID": 4,
        "SENT_TO_SPRINGCM": 5,
        "MIGRATED": 6,
    }


class LicenseStatus(object):
    AGENT_WITH_VALID_LICENSE = 0
    AGENT_MISSING_LICENSE = 1
    UNLICENSED_TEAM_MEMBER = 2

    _VALUES_TO_NAMES = {
        0: "AGENT_WITH_VALID_LICENSE",
        1: "AGENT_MISSING_LICENSE",
        2: "UNLICENSED_TEAM_MEMBER",
    }

    _NAMES_TO_VALUES = {
        "AGENT_WITH_VALID_LICENSE": 0,
        "AGENT_MISSING_LICENSE": 1,
        "UNLICENSED_TEAM_MEMBER": 2,
    }


class RedisDatabaseId(object):
    DEFAULT = 0
    CONTRACTS = 1
    AMD_REGION_UPDATE = 2
    COMM_TERMS = 3
    TERM_CATALOG = 4

    _VALUES_TO_NAMES = {
        0: "DEFAULT",
        1: "CONTRACTS",
        2: "AMD_REGION_UPDATE",
        3: "COMM_TERMS",
        4: "TERM_CATALOG",
    }

    _NAMES_TO_VALUES = {
        "DEFAULT": 0,
        "CONTRACTS": 1,
        "AMD_REGION_UPDATE": 2,
        "COMM_TERMS": 3,
        "TERM_CATALOG": 4,
    }


class RequestSource(object):
    NOT_DEFINED = 0
    COMPASS_UI = 1
    SPRING_CM = 2
    STREAMING_HANDLER = 3

    _VALUES_TO_NAMES = {
        0: "NOT_DEFINED",
        1: "COMPASS_UI",
        2: "SPRING_CM",
        3: "STREAMING_HANDLER",
    }

    _NAMES_TO_VALUES = {
        "NOT_DEFINED": 0,
        "COMPASS_UI": 1,
        "SPRING_CM": 2,
        "STREAMING_HANDLER": 3,
    }


class SplitLanguageChoice(object):
    ROLE_AGENT_DEFAULT = 0
    ROLE_AGENT_ALTERNATE_1 = 1

    _VALUES_TO_NAMES = {
        0: "ROLE_AGENT_DEFAULT",
        1: "ROLE_AGENT_ALTERNATE_1",
    }

    _NAMES_TO_VALUES = {
        "ROLE_AGENT_DEFAULT": 0,
        "ROLE_AGENT_ALTERNATE_1": 1,
    }


class SpringCmWorkflowStatus(object):
    PREVIEW_READY = 0
    LEGAL_REVIEW = 1
    DEAL_DESK_REVIEW = 2
    SENT_FOR_SIGNATURE = 3
    CANCELED = 4
    EXECUTED = 5
    TRANSMITTED = 6
    TRANSMISSION_SUCCESS = 7
    TRANSMISSION_FAIL = 8
    PENDING_CANCELATION = 9
    CANCELATION_FAILED = 10
    VOID = 11
    REJECTED = 12
    MANAGER_REVIEW = 13
    EXTERNAL_REVIEW = 14

    _VALUES_TO_NAMES = {
        0: "PREVIEW_READY",
        1: "LEGAL_REVIEW",
        2: "DEAL_DESK_REVIEW",
        3: "SENT_FOR_SIGNATURE",
        4: "CANCELED",
        5: "EXECUTED",
        6: "TRANSMITTED",
        7: "TRANSMISSION_SUCCESS",
        8: "TRANSMISSION_FAIL",
        9: "PENDING_CANCELATION",
        10: "CANCELATION_FAILED",
        11: "VOID",
        12: "REJECTED",
        13: "MANAGER_REVIEW",
        14: "EXTERNAL_REVIEW",
    }

    _NAMES_TO_VALUES = {
        "PREVIEW_READY": 0,
        "LEGAL_REVIEW": 1,
        "DEAL_DESK_REVIEW": 2,
        "SENT_FOR_SIGNATURE": 3,
        "CANCELED": 4,
        "EXECUTED": 5,
        "TRANSMITTED": 6,
        "TRANSMISSION_SUCCESS": 7,
        "TRANSMISSION_FAIL": 8,
        "PENDING_CANCELATION": 9,
        "CANCELATION_FAILED": 10,
        "VOID": 11,
        "REJECTED": 12,
        "MANAGER_REVIEW": 13,
        "EXTERNAL_REVIEW": 14,
    }


class TeamRole(object):
    PRINCIPAL_AGENT = 0
    AGENT = 1
    UNLICENSED_TEAM_MEMBER = 2
    REFERRAL_DIRECTOR = 3
    SALES_MANAGER = 4

    _VALUES_TO_NAMES = {
        0: "PRINCIPAL_AGENT",
        1: "AGENT",
        2: "UNLICENSED_TEAM_MEMBER",
        3: "REFERRAL_DIRECTOR",
        4: "SALES_MANAGER",
    }

    _NAMES_TO_VALUES = {
        "PRINCIPAL_AGENT": 0,
        "AGENT": 1,
        "UNLICENSED_TEAM_MEMBER": 2,
        "REFERRAL_DIRECTOR": 3,
        "SALES_MANAGER": 4,
    }


class TransactionType(object):
    NET_NEW = 0
    AMENDMENT = 1
    AMENDMENT_AND_REINSTATE = 2
    INCENTIVE_SUMMARY = 3
    UTM = 4

    _VALUES_TO_NAMES = {
        0: "NET_NEW",
        1: "AMENDMENT",
        2: "AMENDMENT_AND_REINSTATE",
        3: "INCENTIVE_SUMMARY",
        4: "UTM",
    }

    _NAMES_TO_VALUES = {
        "NET_NEW": 0,
        "AMENDMENT": 1,
        "AMENDMENT_AND_REINSTATE": 2,
        "INCENTIVE_SUMMARY": 3,
        "UTM": 4,
    }

