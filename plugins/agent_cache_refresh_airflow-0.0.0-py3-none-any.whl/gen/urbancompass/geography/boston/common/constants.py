
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CITY_CLUSTER_ZOOM = 10
DEFAULT_CENTER_LATITUDE = 42.358209
DEFAULT_CENTER_LONGITUDE = -71.060248
DEFAULT_ZOOM = 14
FULL_DISPLAY_NAME = "Greater Boston"
GEO_ID = "boston"
MAX_ZOOM = 19
MIN_ZOOM = 8
NEIGHBORHOOD_CLUSTER_ZOOM = 13
# else
SHORT_DISPLAY_NAME = "Greater Boston"
# else
