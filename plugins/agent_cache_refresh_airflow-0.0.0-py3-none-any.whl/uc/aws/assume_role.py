# -*- coding: utf-8 -*-
"""
boto 3.X module that creates refreshable AWS sessions using IAM assume role method.

:copyright: (c) 2020 by Urban Compass, Inc.
"""
import logging
import uuid

from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

import boto3

DEFAULT_REGION = "us-east-1"

# Lets disable non-critical boto3 logging.
logging.getLogger("boto3").setLevel(logging.CRITICAL)


def assume_role_session(
    role_arn, session_name="generic-assume-role-session", region=DEFAULT_REGION
):
    """STS Assume Role with automatic credential renewal.

      Note for K8S:  Make sure your cloudformation.yaml allows AssumeRole on
      the role_arn to be assumed here.  Example:
         -
           PolicyName: "PubSubSubscriber_AssumeRole"
           PolicyDocument:
             Version: "2012-10-17"
             Statement:
               - Effect: "Allow"
                 Action:
                   - "sts:AssumeRole"
                 Resource: {{.PubSubSubscriber_AssumeRole}}

      Note: The mechanism in which boto3 looks for credentials is to search through
      a list of possible locations and stop as soon as it finds credentials.
      The order in which Boto3 searches for credentials is:

      * Passing credentials as parameters in the boto.client() method
      * Passing credentials as parameters when creating a Session object
      * Environment variables
      * Shared credential file (~/.aws/credentials)
      * AWS config file (~/.aws/config)
      * Assume Role provider
      * Boto2 config file (/etc/boto.cfg and ~/.boto)
      * Instance metadata service on an Amazon EC2 instance that has
        an IAM role configured.

    Args:
      role_arn: iam role arn to assume
      session_name: an optional name (prefix) for assume role session
      region: the region in which to assume role

    """

    sts_client = boto3.Session(region_name=DEFAULT_REGION).client("sts")
    session_name = "{}_{}".format(session_name, str(uuid.uuid1().clock_seq_hi_variant))

    def refresh():
        assume_role_object = sts_client.assume_role(RoleArn=role_arn, RoleSessionName=session_name)
        credentials = assume_role_object["Credentials"]
        return dict(
            access_key=credentials["AccessKeyId"],
            secret_key=credentials["SecretAccessKey"],
            token=credentials["SessionToken"],
            expiry_time=credentials["Expiration"].isoformat(),
        )

    session_credentials = RefreshableCredentials.create_from_metadata(
        metadata=refresh(), refresh_using=refresh, method="sts-assume-role"
    )
    s = get_session()
    s._credentials = session_credentials
    s.set_config_variable("region", region)
    return boto3.Session(botocore_session=s)
