
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
AVAILABLE_RENTAL_STATUSES = [
    5,
    0,
    1,
]
AVAILABLE_SALE_STATUSES = [
    9,
    2,
]
LISTING_STATUSES = {
    12: "Canceled",
    10: "Sold",
    4: "Expired",
    8: "Under Agreement",
    11: "Temporarily Withdrawn",
    2: "Contingent",
    5: "Rented",
    3: "Contingent",
    1: "Under Agreement",
    0: "Active",
    14: "Coming Soon",
}
OFF_MARKET_RENTAL_STATUSES = [
    2,
    6,
    4,
    3,
]
OFF_MARKET_SALE_STATUSES = [
    8,
    10,
    7,
    6,
]
RENTAL_STATUSES = {
    6: "Canceled",
    3: "Expired",
    4: "Rented",
    5: "Active",
    1: "Contingent",
    0: "Under Agreement",
    2: "Temporarily Withdrawn",
    7: "Coming Soon",
}
SALE_STATUSES = {
    10: "Canceled",
    8: "Sold",
    7: "Expired",
    3: "Under Agreement",
    6: "Temporarily Withdrawn",
    2: "Contingent",
    9: "Active",
    12: "Coming Soon",
}
