# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.dms_document.ttypes as dms_document
import gen.urbancompass.dms_common.dms_listing.ttypes as dms_listing
import uc.grpc.codec as _grpc_codec



class DmsDocumentServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.claimDocumentForReview = channel.unary_unary(
        '/DmsDocumentService/claimDocumentForReview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ClaimDocumentForReviewResponse),
        )
    self.convertDocumentToPdf = channel.unary_unary(
        '/DmsDocumentService/convertDocumentToPdf',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ConvertDocumentToPdfResponse),
        )
    self.deleteDocument = channel.unary_unary(
        '/DmsDocumentService/deleteDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDocumentResponse),
        )
    self.getAllUploadsByGroupingId = channel.unary_unary(
        '/DmsDocumentService/getAllUploadsByGroupingId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllUploadsByGroupingIdResponse),
        )
    self.getDocument = channel.unary_unary(
        '/DmsDocumentService/getDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDocumentResponse),
        )
    self.getDocumentGroupingSummaries = channel.unary_unary(
        '/DmsDocumentService/getDocumentGroupingSummaries',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDocumentGroupingSummariesResponse),
        )
    self.getDocumentListMetadata = channel.unary_unary(
        '/DmsDocumentService/getDocumentListMetadata',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDocumentListMetadataResponse),
        )
    self.reviewDocument = channel.unary_unary(
        '/DmsDocumentService/reviewDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReviewDocumentResponse),
        )
    self.saveDocument = channel.unary_unary(
        '/DmsDocumentService/saveDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SaveDocumentResponse),
        )
    self.saveDocumentNote = channel.unary_unary(
        '/DmsDocumentService/saveDocumentNote',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SaveDocumentNoteResponse),
        )
    self.shareGroupingDocuments = channel.unary_unary(
        '/DmsDocumentService/shareGroupingDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ShareGroupingDocumentsResponse),
        )
    self.splitDocument = channel.unary_unary(
        '/DmsDocumentService/splitDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SplitDocumentResponse),
        )
    self.submitDocumentForReview = channel.unary_unary(
        '/DmsDocumentService/submitDocumentForReview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SubmitDocumentForReviewResponse),
        )
    self.unclaimDocumentForReview = channel.unary_unary(
        '/DmsDocumentService/unclaimDocumentForReview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UnclaimDocumentForReviewResponse),
        )
    self.unshareGroupingDocuments = channel.unary_unary(
        '/DmsDocumentService/unshareGroupingDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UnshareGroupingDocumentsResponse),
        )
    self.updateDocument = channel.unary_unary(
        '/DmsDocumentService/updateDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDocumentResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class DmsDocumentServiceServicer(BaseServiceServicer):
  """
    The DmsDocumentService Service definition
  """

  def claimDocumentForReview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def convertDocumentToPdf(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllUploadsByGroupingId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDocumentGroupingSummaries(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDocumentListMetadata(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def reviewDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def saveDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def saveDocumentNote(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def shareGroupingDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def splitDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def submitDocumentForReview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def unclaimDocumentForReview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def unshareGroupingDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_DmsDocumentServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'claimDocumentForReview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.claimDocumentForReview(req),
          request_deserializer=_grpc_codec.deserializer(ClaimDocumentForReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'convertDocumentToPdf': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.convertDocumentToPdf(req),
          request_deserializer=_grpc_codec.deserializer(ConvertDocumentToPdfRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDocument(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUploadsByGroupingId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllUploadsByGroupingId(req),
          request_deserializer=_grpc_codec.deserializer(GetAllUploadsByGroupingIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDocument(req),
          request_deserializer=_grpc_codec.deserializer(GetDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocumentGroupingSummaries': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDocumentGroupingSummaries(req),
          request_deserializer=_grpc_codec.deserializer(GetDocumentGroupingSummariesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocumentListMetadata': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDocumentListMetadata(req),
          request_deserializer=_grpc_codec.deserializer(GetDocumentListMetadataRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reviewDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reviewDocument(req),
          request_deserializer=_grpc_codec.deserializer(ReviewDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.saveDocument(req),
          request_deserializer=_grpc_codec.deserializer(SaveDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveDocumentNote': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.saveDocumentNote(req),
          request_deserializer=_grpc_codec.deserializer(SaveDocumentNoteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'shareGroupingDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.shareGroupingDocuments(req),
          request_deserializer=_grpc_codec.deserializer(ShareGroupingDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'splitDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.splitDocument(req),
          request_deserializer=_grpc_codec.deserializer(SplitDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'submitDocumentForReview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.submitDocumentForReview(req),
          request_deserializer=_grpc_codec.deserializer(SubmitDocumentForReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unclaimDocumentForReview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.unclaimDocumentForReview(req),
          request_deserializer=_grpc_codec.deserializer(UnclaimDocumentForReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unshareGroupingDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.unshareGroupingDocuments(req),
          request_deserializer=_grpc_codec.deserializer(UnshareGroupingDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDocument(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsDocumentService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_DmsDocumentServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'claimDocumentForReview': grpc.unary_unary_rpc_method_handler(
          servicer.claimDocumentForReview,
          request_deserializer=_grpc_codec.deserializer(ClaimDocumentForReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'convertDocumentToPdf': grpc.unary_unary_rpc_method_handler(
          servicer.convertDocumentToPdf,
          request_deserializer=_grpc_codec.deserializer(ConvertDocumentToPdfRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDocument': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDocument,
          request_deserializer=_grpc_codec.deserializer(DeleteDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUploadsByGroupingId': grpc.unary_unary_rpc_method_handler(
          servicer.getAllUploadsByGroupingId,
          request_deserializer=_grpc_codec.deserializer(GetAllUploadsByGroupingIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocument': grpc.unary_unary_rpc_method_handler(
          servicer.getDocument,
          request_deserializer=_grpc_codec.deserializer(GetDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocumentGroupingSummaries': grpc.unary_unary_rpc_method_handler(
          servicer.getDocumentGroupingSummaries,
          request_deserializer=_grpc_codec.deserializer(GetDocumentGroupingSummariesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocumentListMetadata': grpc.unary_unary_rpc_method_handler(
          servicer.getDocumentListMetadata,
          request_deserializer=_grpc_codec.deserializer(GetDocumentListMetadataRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reviewDocument': grpc.unary_unary_rpc_method_handler(
          servicer.reviewDocument,
          request_deserializer=_grpc_codec.deserializer(ReviewDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveDocument': grpc.unary_unary_rpc_method_handler(
          servicer.saveDocument,
          request_deserializer=_grpc_codec.deserializer(SaveDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveDocumentNote': grpc.unary_unary_rpc_method_handler(
          servicer.saveDocumentNote,
          request_deserializer=_grpc_codec.deserializer(SaveDocumentNoteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'shareGroupingDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.shareGroupingDocuments,
          request_deserializer=_grpc_codec.deserializer(ShareGroupingDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'splitDocument': grpc.unary_unary_rpc_method_handler(
          servicer.splitDocument,
          request_deserializer=_grpc_codec.deserializer(SplitDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'submitDocumentForReview': grpc.unary_unary_rpc_method_handler(
          servicer.submitDocumentForReview,
          request_deserializer=_grpc_codec.deserializer(SubmitDocumentForReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unclaimDocumentForReview': grpc.unary_unary_rpc_method_handler(
          servicer.unclaimDocumentForReview,
          request_deserializer=_grpc_codec.deserializer(UnclaimDocumentForReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unshareGroupingDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.unshareGroupingDocuments,
          request_deserializer=_grpc_codec.deserializer(UnshareGroupingDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDocument': grpc.unary_unary_rpc_method_handler(
          servicer.updateDocument,
          request_deserializer=_grpc_codec.deserializer(UpdateDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsDocumentService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

