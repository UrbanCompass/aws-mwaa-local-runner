
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes

from thrift.transport import TTransport


class Description(object):
    """
    Attributes:
     - fieldName
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'fieldName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
    )
    def __init__(self, fieldName=None, value=None, ):
        self.fieldName = fieldName
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.fieldName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Description')
        if self.fieldName is not None:
            oprot.writeFieldBegin('fieldName', TType.STRING, 1)
            oprot.writeString(self.fieldName.encode('utf-8') if sys.version_info[0] == 2 else self.fieldName)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LeadGenerationResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LeadGenerationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PartnerLeadGenerationRequest(object):
    """
    Attributes:
     - firstName
     - lastName
     - email
     - phone
     - company
     - state
     - descriptions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'firstName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'lastName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'phone', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'company', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'state', 'UTF8', None, ),  # 6
        (7, TType.LIST, 'descriptions', (TType.STRUCT, (Description, Description.thrift_spec), False), None, ),  # 7
    )
    def __init__(self, firstName=None, lastName=None, email=None, phone=None, company=None, state=None, descriptions=None, ):
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.phone = phone
        self.company = company
        self.state = state
        self.descriptions = descriptions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.descriptions = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = Description()
                        _elem4.read(iprot)
                        self.descriptions.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PartnerLeadGenerationRequest')
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 1)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 2)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 4)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 5)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 6)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.descriptions is not None:
            oprot.writeFieldBegin('descriptions', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.descriptions))
            for _iter6 in self.descriptions:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LeadGenerationRequest(object):
    """
    Attributes:
     - partner
     - partnerLeadGenerationRequest
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'partner', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'partnerLeadGenerationRequest', (PartnerLeadGenerationRequest, PartnerLeadGenerationRequest.thrift_spec), None, ),  # 2
    )
    def __init__(self, partner=None, partnerLeadGenerationRequest=None, ):
        self.partner = partner
        self.partnerLeadGenerationRequest = partnerLeadGenerationRequest

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.partner = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.partnerLeadGenerationRequest = PartnerLeadGenerationRequest()
                    self.partnerLeadGenerationRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LeadGenerationRequest')
        if self.partner is not None:
            oprot.writeFieldBegin('partner', TType.STRING, 1)
            oprot.writeString(self.partner.encode('utf-8') if sys.version_info[0] == 2 else self.partner)
            oprot.writeFieldEnd()
        if self.partnerLeadGenerationRequest is not None:
            oprot.writeFieldBegin('partnerLeadGenerationRequest', TType.STRUCT, 2)
            self.partnerLeadGenerationRequest.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
