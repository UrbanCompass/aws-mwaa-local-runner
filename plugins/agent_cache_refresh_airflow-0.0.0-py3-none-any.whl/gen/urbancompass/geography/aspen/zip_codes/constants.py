
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
ZIP_CODES = [
    "80423",
    "80426",
    "80428",
    "80463",
    "80467",
    "80469",
    "80477",
    "80479",
    "80483",
    "80487",
    "81210",
    "81224",
    "81225",
    "81230",
    "81237",
    "81239",
    "81241",
    "81243",
    "81434",
    "81601",
    "81611",
    "81612",
    "81615",
    "81620",
    "81621",
    "81623",
    "81631",
    "81632",
    "81635",
    "81637",
    "81639",
    "81641",
    "81642",
    "81645",
    "81647",
    "81648",
    "81649",
    "81650",
    "81652",
    "81654",
    "81655",
    "81656",
    "81657",
]
