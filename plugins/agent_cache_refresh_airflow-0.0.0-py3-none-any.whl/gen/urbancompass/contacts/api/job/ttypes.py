
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.contacts.api.contact.ttypes

from thrift.transport import TTransport


class Status(object):
    COMPLETE = 0
    FAILED = 1
    INTERRUPTED = 2
    QUEUED = 3
    RETRYING = 4
    WORKING = 5

    _VALUES_TO_NAMES = {
        0: "COMPLETE",
        1: "FAILED",
        2: "INTERRUPTED",
        3: "QUEUED",
        4: "RETRYING",
        5: "WORKING",
    }

    _NAMES_TO_VALUES = {
        "COMPLETE": 0,
        "FAILED": 1,
        "INTERRUPTED": 2,
        "QUEUED": 3,
        "RETRYING": 4,
        "WORKING": 5,
    }


class BulkImportResultError(object):
    """
    Attributes:
     - contact
     - errors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'contact', (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'errors', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, contact=None, errors=None, ):
        self.contact = contact
        self.errors = errors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.contact = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.errors = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkImportResultError')
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 1)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.errors))
            for _iter21 in self.errors:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BulkImportResultSuccess(object):
    """
    Attributes:
     - contact
     - merged
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'contact', (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'merged', None, None, ),  # 2
    )
    def __init__(self, contact=None, merged=None, ):
        self.contact = contact
        self.merged = merged

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.contact = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.merged = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkImportResultSuccess')
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 1)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        if self.merged is not None:
            oprot.writeFieldBegin('merged', TType.BOOL, 2)
            oprot.writeBool(self.merged)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Results(object):
    """
    Attributes:
     - at
     - total
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'at', None, None, ),  # 1
        (2, TType.I32, 'total', None, None, ),  # 2
    )
    def __init__(self, at=None, total=None, ):
        self.at = at
        self.total = total

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.at = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.total = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Results')
        if self.at is not None:
            oprot.writeFieldBegin('at', TType.I32, 1)
            oprot.writeI32(self.at)
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.I32, 2)
            oprot.writeI32(self.total)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BulkImportResultsMetadata(object):
    """
    Attributes:
     - successfullyImported
     - importErrors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'successfullyImported', (TType.STRUCT, (BulkImportResultSuccess, BulkImportResultSuccess.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'importErrors', (TType.STRUCT, (BulkImportResultError, BulkImportResultError.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, successfullyImported=None, importErrors=None, ):
        self.successfullyImported = successfullyImported
        self.importErrors = importErrors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.successfullyImported = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = BulkImportResultSuccess()
                        _elem34.read(iprot)
                        self.successfullyImported.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.importErrors = []
                    (_etype36, _size39) = iprot.readListBegin()
                    for _i37 in range(_size39):
                        _elem38 = BulkImportResultError()
                        _elem38.read(iprot)
                        self.importErrors.append(_elem38)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkImportResultsMetadata')
        if self.successfullyImported is not None:
            oprot.writeFieldBegin('successfullyImported', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.successfullyImported))
            for _iter44 in self.successfullyImported:
                _iter44.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.importErrors is not None:
            oprot.writeFieldBegin('importErrors', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.importErrors))
            for _iter49 in self.importErrors:
                _iter49.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResultsMetadata(object):
    """
    Attributes:
     - bulkImportMetadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'bulkImportMetadata', (BulkImportResultsMetadata, BulkImportResultsMetadata.thrift_spec), None, ),  # 1
    )
    def __init__(self, bulkImportMetadata=None, ):
        self.bulkImportMetadata = bulkImportMetadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.bulkImportMetadata = BulkImportResultsMetadata()
                    self.bulkImportMetadata.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResultsMetadata')
        if self.bulkImportMetadata is not None:
            oprot.writeFieldBegin('bulkImportMetadata', TType.STRUCT, 1)
            self.bulkImportMetadata.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Job(object):
    """
    Attributes:
     - id
     - updatedAt
     - results
     - status
     - extraData
     - resultsMetadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'updatedAt', None, None, ),  # 2
        (3, TType.STRUCT, 'results', (Results, Results.thrift_spec), None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.MAP, 'extraData', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRUCT, 'resultsMetadata', (ResultsMetadata, ResultsMetadata.thrift_spec), None, ),  # 6
    )
    def __init__(self, id=None, updatedAt=None, results=None, status=None, extraData=None, resultsMetadata=None, ):
        self.id = id
        self.updatedAt = updatedAt
        self.results = results
        self.status = status
        self.extraData = extraData
        self.resultsMetadata = resultsMetadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.results = Results()
                    self.results.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.extraData = {}
                    (_ktype79, _vtype80, _size83) = iprot.readMapBegin()
                    for _i78 in range(_size83):
                        _key81 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val82 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.extraData[_key81] = _val82
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.resultsMetadata = ResultsMetadata()
                    self.resultsMetadata.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Job')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 2)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.results is not None:
            oprot.writeFieldBegin('results', TType.STRUCT, 3)
            self.results.write(oprot)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.extraData is not None:
            oprot.writeFieldBegin('extraData', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.extraData))
            for _kiter84, _viter85 in self.extraData.items():
                oprot.writeString(_kiter84.encode('utf-8') if sys.version_info[0] == 2 else _kiter84)
                oprot.writeString(_viter85.encode('utf-8') if sys.version_info[0] == 2 else _viter85)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.resultsMetadata is not None:
            oprot.writeFieldBegin('resultsMetadata', TType.STRUCT, 6)
            self.resultsMetadata.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
