
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class AGENT_CAPABILITY(object):
    LEADS = 0
    DEALS = 1
    SUITE = 2
    AGENT_NETWORK = 3
    AGENT_PERFORMANCE = 4
    LISTING_STRATEGY = 5
    MY_LISTINGS = 6
    LEGAL_ROOM_COUNT_COLUMN = 7
    HALF_BATHROOMS_COLUMN = 8
    PPSF_COLUMN = 9
    RENTAL_SEARCH = 10
    VALUATION = 11
    FOLDERS = 12

    _VALUES_TO_NAMES = {
        0: "LEADS",
        1: "DEALS",
        2: "SUITE",
        3: "AGENT_NETWORK",
        4: "AGENT_PERFORMANCE",
        5: "LISTING_STRATEGY",
        6: "MY_LISTINGS",
        7: "LEGAL_ROOM_COUNT_COLUMN",
        8: "HALF_BATHROOMS_COLUMN",
        9: "PPSF_COLUMN",
        10: "RENTAL_SEARCH",
        11: "VALUATION",
        12: "FOLDERS",
    }

    _NAMES_TO_VALUES = {
        "LEADS": 0,
        "DEALS": 1,
        "SUITE": 2,
        "AGENT_NETWORK": 3,
        "AGENT_PERFORMANCE": 4,
        "LISTING_STRATEGY": 5,
        "MY_LISTINGS": 6,
        "LEGAL_ROOM_COUNT_COLUMN": 7,
        "HALF_BATHROOMS_COLUMN": 8,
        "PPSF_COLUMN": 9,
        "RENTAL_SEARCH": 10,
        "VALUATION": 11,
        "FOLDERS": 12,
    }


class CONSUMER_SEARCH_PERMISSION(object):
    VOW_VISIBLE = 0
    SHORT_TERM_RENTAL_SEARCH = 1

    _VALUES_TO_NAMES = {
        0: "VOW_VISIBLE",
        1: "SHORT_TERM_RENTAL_SEARCH",
    }

    _NAMES_TO_VALUES = {
        "VOW_VISIBLE": 0,
        "SHORT_TERM_RENTAL_SEARCH": 1,
    }

