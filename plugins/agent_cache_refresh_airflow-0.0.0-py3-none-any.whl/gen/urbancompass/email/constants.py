
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
INVITATION_ORIGIN_VALUES = {
    0: "New Lead",
    1: "Client Invitation",
    2: "Collections Invitation",
    3: "Collections Landing Page",
    4: "Photography Invitation",
}
