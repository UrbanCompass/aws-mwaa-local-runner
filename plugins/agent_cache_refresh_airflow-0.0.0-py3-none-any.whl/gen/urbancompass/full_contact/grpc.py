# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.user.user.ttypes as user
import uc.grpc.codec as _grpc_codec



class FullContactServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.invalidate = channel.unary_unary(
        '/FullContactService/invalidate',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(InvalidateResponse),
        )
    self.query = channel.unary_unary(
        '/FullContactService/query',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(QueryResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class FullContactServiceServicer(BaseServiceServicer):
  """
    The FullContactService Service definition
  """

  def invalidate(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def query(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_FullContactServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'invalidate': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.invalidate(req),
          request_deserializer=_grpc_codec.deserializer(InvalidateRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'query': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.query(req),
          request_deserializer=_grpc_codec.deserializer(QueryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'FullContactService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_FullContactServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'invalidate': grpc.unary_unary_rpc_method_handler(
          servicer.invalidate,
          request_deserializer=_grpc_codec.deserializer(InvalidateRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'query': grpc.unary_unary_rpc_method_handler(
          servicer.query,
          request_deserializer=_grpc_codec.deserializer(QueryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'FullContactService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

