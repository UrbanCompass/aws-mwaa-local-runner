
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.application.ttypes
import gen.urbancompass.people.api.person.ttypes

from thrift.transport import TTransport


class AssetEnrichOptions(object):
    TAGS = 0
    LAST_USED = 1
    FAVORITED = 2
    PERSON = 3
    DEFAULT = 4
    USAGE = 5

    _VALUES_TO_NAMES = {
        0: "TAGS",
        1: "LAST_USED",
        2: "FAVORITED",
        3: "PERSON",
        4: "DEFAULT",
        5: "USAGE",
    }

    _NAMES_TO_VALUES = {
        "TAGS": 0,
        "LAST_USED": 1,
        "FAVORITED": 2,
        "PERSON": 3,
        "DEFAULT": 4,
        "USAGE": 5,
    }


class AssetOrigin(object):
    LOCAL = 0
    GOOGLE_DRIVE = 1
    DROPBOX = 2

    _VALUES_TO_NAMES = {
        0: "LOCAL",
        1: "GOOGLE_DRIVE",
        2: "DROPBOX",
    }

    _NAMES_TO_VALUES = {
        "LOCAL": 0,
        "GOOGLE_DRIVE": 1,
        "DROPBOX": 2,
    }


class AssetSearchType(object):
    PARTIAL_LEFT_RIGHT = 0
    PARTIAL_RIGHT_ALL_WORDS = 1

    _VALUES_TO_NAMES = {
        0: "PARTIAL_LEFT_RIGHT",
        1: "PARTIAL_RIGHT_ALL_WORDS",
    }

    _NAMES_TO_VALUES = {
        "PARTIAL_LEFT_RIGHT": 0,
        "PARTIAL_RIGHT_ALL_WORDS": 1,
    }


class AssetType(object):
    INDIVIDUAL = 0
    TEAM = 1
    BRANDFOLDER = 2
    MATTERPORT = 3
    MLS = 4
    ANALYTICS = 5
    LOGO = 6
    PHOTO_INGESTION = 7

    _VALUES_TO_NAMES = {
        0: "INDIVIDUAL",
        1: "TEAM",
        2: "BRANDFOLDER",
        3: "MATTERPORT",
        4: "MLS",
        5: "ANALYTICS",
        6: "LOGO",
        7: "PHOTO_INGESTION",
    }

    _NAMES_TO_VALUES = {
        "INDIVIDUAL": 0,
        "TEAM": 1,
        "BRANDFOLDER": 2,
        "MATTERPORT": 3,
        "MLS": 4,
        "ANALYTICS": 5,
        "LOGO": 6,
        "PHOTO_INGESTION": 7,
    }


class AssetUsageObjectType(object):
    MC_COLLATERAL = 0
    CRM_EMAIL = 1
    DIGITAL_AD = 2
    VIDEO_STUDIO = 3

    _VALUES_TO_NAMES = {
        0: "MC_COLLATERAL",
        1: "CRM_EMAIL",
        2: "DIGITAL_AD",
        3: "VIDEO_STUDIO",
    }

    _NAMES_TO_VALUES = {
        "MC_COLLATERAL": 0,
        "CRM_EMAIL": 1,
        "DIGITAL_AD": 2,
        "VIDEO_STUDIO": 3,
    }


class AssetsSortableFields(object):
    ID = 0
    NAME = 1
    CREATED_AT = 2
    CREATED_BY = 3
    UPDATED_AT = 4
    UPDATED_BY = 5
    TAG = 6
    FAVORITE = 7
    LAST_USED = 8

    _VALUES_TO_NAMES = {
        0: "ID",
        1: "NAME",
        2: "CREATED_AT",
        3: "CREATED_BY",
        4: "UPDATED_AT",
        5: "UPDATED_BY",
        6: "TAG",
        7: "FAVORITE",
        8: "LAST_USED",
    }

    _NAMES_TO_VALUES = {
        "ID": 0,
        "NAME": 1,
        "CREATED_AT": 2,
        "CREATED_BY": 3,
        "UPDATED_AT": 4,
        "UPDATED_BY": 5,
        "TAG": 6,
        "FAVORITE": 7,
        "LAST_USED": 8,
    }


class AssetsTimeRangeFilterableFields(object):
    CREATED_AT = 0
    UPDATED_AT = 1
    DELETED_AT = 2

    _VALUES_TO_NAMES = {
        0: "CREATED_AT",
        1: "UPDATED_AT",
        2: "DELETED_AT",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT": 0,
        "UPDATED_AT": 1,
        "DELETED_AT": 2,
    }


class CategoryFilterTypes(object):
    USERUPLOADS = 0
    MATTERPORT = 1
    FAVORITES = 2

    _VALUES_TO_NAMES = {
        0: "USERUPLOADS",
        1: "MATTERPORT",
        2: "FAVORITES",
    }

    _NAMES_TO_VALUES = {
        "USERUPLOADS": 0,
        "MATTERPORT": 1,
        "FAVORITES": 2,
    }


class CollectionClient(object):
    PHOTO_INGESTION_PROJECT = 0
    DEAL = 1

    _VALUES_TO_NAMES = {
        0: "PHOTO_INGESTION_PROJECT",
        1: "DEAL",
    }

    _NAMES_TO_VALUES = {
        "PHOTO_INGESTION_PROJECT": 0,
        "DEAL": 1,
    }


class CollectionEnrichOption(object):
    ASSETS = 0

    _VALUES_TO_NAMES = {
        0: "ASSETS",
    }

    _NAMES_TO_VALUES = {
        "ASSETS": 0,
    }


class FolderEnrichOptions(object):
    PERSON = 0
    SUBFOLDER_IDS = 1
    ASSETS = 2
    TAGS = 3

    _VALUES_TO_NAMES = {
        0: "PERSON",
        1: "SUBFOLDER_IDS",
        2: "ASSETS",
        3: "TAGS",
    }

    _NAMES_TO_VALUES = {
        "PERSON": 0,
        "SUBFOLDER_IDS": 1,
        "ASSETS": 2,
        "TAGS": 3,
    }


class FolderType(object):
    INDIVIDUAL = 0
    TEAM = 1
    BRANDFOLDER = 2

    _VALUES_TO_NAMES = {
        0: "INDIVIDUAL",
        1: "TEAM",
        2: "BRANDFOLDER",
    }

    _NAMES_TO_VALUES = {
        "INDIVIDUAL": 0,
        "TEAM": 1,
        "BRANDFOLDER": 2,
    }


class FoldersSortableFields(object):
    ID = 0
    NAME = 1
    CREATED_AT = 2
    CREATED_BY = 3
    UPDATED_AT = 4
    UPDATED_BY = 5
    FOLDER_TYPE = 6

    _VALUES_TO_NAMES = {
        0: "ID",
        1: "NAME",
        2: "CREATED_AT",
        3: "CREATED_BY",
        4: "UPDATED_AT",
        5: "UPDATED_BY",
        6: "FOLDER_TYPE",
    }

    _NAMES_TO_VALUES = {
        "ID": 0,
        "NAME": 1,
        "CREATED_AT": 2,
        "CREATED_BY": 3,
        "UPDATED_AT": 4,
        "UPDATED_BY": 5,
        "FOLDER_TYPE": 6,
    }


class FoldersTimeRangeFilterableFields(object):
    CREATED_AT = 0
    UPDATED_AT = 1
    DELETED_AT = 2

    _VALUES_TO_NAMES = {
        0: "CREATED_AT",
        1: "UPDATED_AT",
        2: "DELETED_AT",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT": 0,
        "UPDATED_AT": 1,
        "DELETED_AT": 2,
    }


class IngestionMediaCategory(object):
    HIGH_QUALITY = 0
    MLS_QUALITY = 1
    NON_LISTING = 2
    FLOORPLAN = 3

    _VALUES_TO_NAMES = {
        0: "HIGH_QUALITY",
        1: "MLS_QUALITY",
        2: "NON_LISTING",
        3: "FLOORPLAN",
    }

    _NAMES_TO_VALUES = {
        "HIGH_QUALITY": 0,
        "MLS_QUALITY": 1,
        "NON_LISTING": 2,
        "FLOORPLAN": 3,
    }


class MediaFilterTypes(object):
    IMAGE = 0
    VIDEO = 1
    TOUR = 2

    _VALUES_TO_NAMES = {
        0: "IMAGE",
        1: "VIDEO",
        2: "TOUR",
    }

    _NAMES_TO_VALUES = {
        "IMAGE": 0,
        "VIDEO": 1,
        "TOUR": 2,
    }


class Tab(object):
    MYMEDIA = 0
    FAVORITES = 1
    LISTINGASSETS = 2

    _VALUES_TO_NAMES = {
        0: "MYMEDIA",
        1: "FAVORITES",
        2: "LISTINGASSETS",
    }

    _NAMES_TO_VALUES = {
        "MYMEDIA": 0,
        "FAVORITES": 1,
        "LISTINGASSETS": 2,
    }


class UserLibraryVisibility(object):
    VISIBLE = 0
    UNDISCOVERABLE = 1

    _VALUES_TO_NAMES = {
        0: "VISIBLE",
        1: "UNDISCOVERABLE",
    }

    _NAMES_TO_VALUES = {
        "VISIBLE": 0,
        "UNDISCOVERABLE": 1,
    }


class AssetDetails(object):
    """
    Attributes:
     - url
     - height
     - width
     - size
     - duration
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'url', 'UTF8', None, ),  # 1
        (2, TType.I64, 'height', None, None, ),  # 2
        (3, TType.I64, 'width', None, None, ),  # 3
        (4, TType.I64, 'size', None, None, ),  # 4
        (5, TType.I64, 'duration', None, None, ),  # 5
    )
    def __init__(self, url=None, height=None, width=None, size=None, duration=None, ):
        self.url = url
        self.height = height
        self.width = width
        self.size = size
        self.duration = duration

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.height = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.width = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.size = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.duration = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssetDetails')
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 1)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.height is not None:
            oprot.writeFieldBegin('height', TType.I64, 2)
            oprot.writeI64(self.height)
            oprot.writeFieldEnd()
        if self.width is not None:
            oprot.writeFieldBegin('width', TType.I64, 3)
            oprot.writeI64(self.width)
            oprot.writeFieldEnd()
        if self.size is not None:
            oprot.writeFieldBegin('size', TType.I64, 4)
            oprot.writeI64(self.size)
            oprot.writeFieldEnd()
        if self.duration is not None:
            oprot.writeFieldBegin('duration', TType.I64, 5)
            oprot.writeI64(self.duration)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AssetUsageObject(object):
    """
    Attributes:
     - objectType
     - objectId
     - objectTitle
     - objectUrl
     - objectThumbnailUrl
     - assetUuid
     - createdAt
     - objectHeight
     - objectWidth
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'objectType', None, None, ),  # 1
        (2, TType.STRING, 'objectId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'objectTitle', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'objectUrl', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'objectThumbnailUrl', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'assetUuid', 'UTF8', None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'objectHeight', None, None, ),  # 8
        (9, TType.I64, 'objectWidth', None, None, ),  # 9
    )
    def __init__(self, objectType=None, objectId=None, objectTitle=None, objectUrl=None, objectThumbnailUrl=None, assetUuid=None, createdAt=None, objectHeight=None, objectWidth=None, ):
        self.objectType = objectType
        self.objectId = objectId
        self.objectTitle = objectTitle
        self.objectUrl = objectUrl
        self.objectThumbnailUrl = objectThumbnailUrl
        self.assetUuid = assetUuid
        self.createdAt = createdAt
        self.objectHeight = objectHeight
        self.objectWidth = objectWidth

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.objectType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.objectId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.objectTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.objectUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.objectThumbnailUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.assetUuid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.objectHeight = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.objectWidth = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssetUsageObject')
        if self.objectType is not None:
            oprot.writeFieldBegin('objectType', TType.I32, 1)
            oprot.writeI32(self.objectType)
            oprot.writeFieldEnd()
        if self.objectId is not None:
            oprot.writeFieldBegin('objectId', TType.STRING, 2)
            oprot.writeString(self.objectId.encode('utf-8') if sys.version_info[0] == 2 else self.objectId)
            oprot.writeFieldEnd()
        if self.objectTitle is not None:
            oprot.writeFieldBegin('objectTitle', TType.STRING, 3)
            oprot.writeString(self.objectTitle.encode('utf-8') if sys.version_info[0] == 2 else self.objectTitle)
            oprot.writeFieldEnd()
        if self.objectUrl is not None:
            oprot.writeFieldBegin('objectUrl', TType.STRING, 4)
            oprot.writeString(self.objectUrl.encode('utf-8') if sys.version_info[0] == 2 else self.objectUrl)
            oprot.writeFieldEnd()
        if self.objectThumbnailUrl is not None:
            oprot.writeFieldBegin('objectThumbnailUrl', TType.STRING, 5)
            oprot.writeString(self.objectThumbnailUrl.encode('utf-8') if sys.version_info[0] == 2 else self.objectThumbnailUrl)
            oprot.writeFieldEnd()
        if self.assetUuid is not None:
            oprot.writeFieldBegin('assetUuid', TType.STRING, 6)
            oprot.writeString(self.assetUuid.encode('utf-8') if sys.version_info[0] == 2 else self.assetUuid)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.objectHeight is not None:
            oprot.writeFieldBegin('objectHeight', TType.I64, 8)
            oprot.writeI64(self.objectHeight)
            oprot.writeFieldEnd()
        if self.objectWidth is not None:
            oprot.writeFieldBegin('objectWidth', TType.I64, 9)
            oprot.writeI64(self.objectWidth)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AssetsSort(object):
    """
    Attributes:
     - orderBy
     - orderAsc
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'orderBy', None, None, ),  # 1
        (2, TType.BOOL, 'orderAsc', None, None, ),  # 2
    )
    def __init__(self, orderBy=None, orderAsc=None, ):
        self.orderBy = orderBy
        self.orderAsc = orderAsc

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.orderAsc = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssetsSort')
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 1)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.orderAsc is not None:
            oprot.writeFieldBegin('orderAsc', TType.BOOL, 2)
            oprot.writeBool(self.orderAsc)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AssetsTimeRangeFilter(object):
    """
    Attributes:
     - timeRangeField
     - startTimestamp
     - endTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'timeRangeField', None, None, ),  # 1
        (2, TType.I64, 'startTimestamp', None, None, ),  # 2
        (3, TType.I64, 'endTimestamp', None, None, ),  # 3
    )
    def __init__(self, timeRangeField=None, startTimestamp=None, endTimestamp=None, ):
        self.timeRangeField = timeRangeField
        self.startTimestamp = startTimestamp
        self.endTimestamp = endTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.timeRangeField = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.startTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.endTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssetsTimeRangeFilter')
        if self.timeRangeField is not None:
            oprot.writeFieldBegin('timeRangeField', TType.I32, 1)
            oprot.writeI32(self.timeRangeField)
            oprot.writeFieldEnd()
        if self.startTimestamp is not None:
            oprot.writeFieldBegin('startTimestamp', TType.I64, 2)
            oprot.writeI64(self.startTimestamp)
            oprot.writeFieldEnd()
        if self.endTimestamp is not None:
            oprot.writeFieldBegin('endTimestamp', TType.I64, 3)
            oprot.writeI64(self.endTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BrandfolderCuratedImages(object):
    """
    Attributes:
     - folderId
     - assetIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'folderId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'assetIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, folderId=None, assetIds=None, ):
        self.folderId = folderId
        self.assetIds = assetIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.folderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.assetIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.assetIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BrandfolderCuratedImages')
        if self.folderId is not None:
            oprot.writeFieldBegin('folderId', TType.STRING, 1)
            oprot.writeString(self.folderId.encode('utf-8') if sys.version_info[0] == 2 else self.folderId)
            oprot.writeFieldEnd()
        if self.assetIds is not None:
            oprot.writeFieldBegin('assetIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.assetIds))
            for _iter6 in self.assetIds:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExternalServiceMetadata(object):
    """
    Attributes:
     - ingestionMediaCategory
     - ingestionProjectId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'ingestionMediaCategory', None, None, ),  # 1
        (2, TType.STRING, 'ingestionProjectId', 'UTF8', None, ),  # 2
    )
    def __init__(self, ingestionMediaCategory=None, ingestionProjectId=None, ):
        self.ingestionMediaCategory = ingestionMediaCategory
        self.ingestionProjectId = ingestionProjectId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.ingestionMediaCategory = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.ingestionProjectId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExternalServiceMetadata')
        if self.ingestionMediaCategory is not None:
            oprot.writeFieldBegin('ingestionMediaCategory', TType.I32, 1)
            oprot.writeI32(self.ingestionMediaCategory)
            oprot.writeFieldEnd()
        if self.ingestionProjectId is not None:
            oprot.writeFieldBegin('ingestionProjectId', TType.STRING, 2)
            oprot.writeString(self.ingestionProjectId.encode('utf-8') if sys.version_info[0] == 2 else self.ingestionProjectId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FoldersSort(object):
    """
    Attributes:
     - orderBy
     - orderAsc
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'orderBy', None, None, ),  # 1
        (2, TType.BOOL, 'orderAsc', None, None, ),  # 2
    )
    def __init__(self, orderBy=None, orderAsc=None, ):
        self.orderBy = orderBy
        self.orderAsc = orderAsc

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.orderAsc = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FoldersSort')
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 1)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.orderAsc is not None:
            oprot.writeFieldBegin('orderAsc', TType.BOOL, 2)
            oprot.writeBool(self.orderAsc)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FoldersTimeRangeFilter(object):
    """
    Attributes:
     - timeRangeField
     - startTimestamp
     - endTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'timeRangeField', None, None, ),  # 1
        (2, TType.I64, 'startTimestamp', None, None, ),  # 2
        (3, TType.I64, 'endTimestamp', None, None, ),  # 3
    )
    def __init__(self, timeRangeField=None, startTimestamp=None, endTimestamp=None, ):
        self.timeRangeField = timeRangeField
        self.startTimestamp = startTimestamp
        self.endTimestamp = endTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.timeRangeField = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.startTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.endTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FoldersTimeRangeFilter')
        if self.timeRangeField is not None:
            oprot.writeFieldBegin('timeRangeField', TType.I32, 1)
            oprot.writeI32(self.timeRangeField)
            oprot.writeFieldEnd()
        if self.startTimestamp is not None:
            oprot.writeFieldBegin('startTimestamp', TType.I64, 2)
            oprot.writeI64(self.startTimestamp)
            oprot.writeFieldEnd()
        if self.endTimestamp is not None:
            oprot.writeFieldBegin('endTimestamp', TType.I64, 3)
            oprot.writeI64(self.endTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Metadata(object):
    """
    Attributes:
     - createdAt
     - createdById
     - createdBy
     - updatedAt
     - updatedById
     - updatedBy
     - deletedAt
     - deletedById
     - deletedBy
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'createdAt', None, None, ),  # 1
        (2, TType.STRING, 'createdById', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'createdBy', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.STRING, 'updatedById', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'updatedBy', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 6
        (7, TType.I64, 'deletedAt', None, None, ),  # 7
        (8, TType.STRING, 'deletedById', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'deletedBy', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 9
    )
    def __init__(self, createdAt=None, createdById=None, createdBy=None, updatedAt=None, updatedById=None, updatedBy=None, deletedAt=None, deletedById=None, deletedBy=None, ):
        self.createdAt = createdAt
        self.createdById = createdById
        self.createdBy = createdBy
        self.updatedAt = updatedAt
        self.updatedById = updatedById
        self.updatedBy = updatedBy
        self.deletedAt = deletedAt
        self.deletedById = deletedById
        self.deletedBy = deletedBy

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.createdById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.createdBy = gen.urbancompass.people.api.person.ttypes.Person()
                    self.createdBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.updatedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.updatedBy = gen.urbancompass.people.api.person.ttypes.Person()
                    self.updatedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.deletedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.deletedBy = gen.urbancompass.people.api.person.ttypes.Person()
                    self.deletedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Metadata')
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 1)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdById is not None:
            oprot.writeFieldBegin('createdById', TType.STRING, 2)
            oprot.writeString(self.createdById.encode('utf-8') if sys.version_info[0] == 2 else self.createdById)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRUCT, 3)
            self.createdBy.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.updatedById is not None:
            oprot.writeFieldBegin('updatedById', TType.STRING, 5)
            oprot.writeString(self.updatedById.encode('utf-8') if sys.version_info[0] == 2 else self.updatedById)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRUCT, 6)
            self.updatedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 7)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        if self.deletedById is not None:
            oprot.writeFieldBegin('deletedById', TType.STRING, 8)
            oprot.writeString(self.deletedById.encode('utf-8') if sys.version_info[0] == 2 else self.deletedById)
            oprot.writeFieldEnd()
        if self.deletedBy is not None:
            oprot.writeFieldBegin('deletedBy', TType.STRUCT, 9)
            self.deletedBy.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Tag(object):
    """
    Attributes:
     - name
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
    )
    def __init__(self, name=None, ):
        self.name = name

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Tag')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Asset(object):
    """
    Attributes:
     - id
     - name
     - folderId
     - type
     - favorite
     - thumbnailDetails
     - originalDetails
     - metadata
     - lastUsed
     - tags
     - origin
     - mimeType
     - favoritedAt
     - listingIdSHA
     - content
     - gifDetails
     - externalResourceId
     - externalResourceType
     - isDefault
     - assetUsage
     - externalServiceMetadata
     - userLibraryVisibility
     - dealId
     - ownerId
     - collectionIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'folderId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'type', None, None, ),  # 4
        (5, TType.BOOL, 'favorite', None, None, ),  # 5
        (6, TType.STRUCT, 'thumbnailDetails', (AssetDetails, AssetDetails.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'originalDetails', (AssetDetails, AssetDetails.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'metadata', (Metadata, Metadata.thrift_spec), None, ),  # 8
        (9, TType.I64, 'lastUsed', None, None, ),  # 9
        (10, TType.LIST, 'tags', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 10
        (11, TType.I32, 'origin', None, None, ),  # 11
        (12, TType.STRING, 'mimeType', 'UTF8', None, ),  # 12
        (13, TType.I64, 'favoritedAt', None, None, ),  # 13
        (14, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'content', 'UTF8', None, ),  # 15
        (16, TType.STRUCT, 'gifDetails', (AssetDetails, AssetDetails.thrift_spec), None, ),  # 16
        (17, TType.STRING, 'externalResourceId', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'externalResourceType', 'UTF8', None, ),  # 18
        (19, TType.BOOL, 'isDefault', None, None, ),  # 19
        (20, TType.LIST, 'assetUsage', (TType.STRUCT, (AssetUsageObject, AssetUsageObject.thrift_spec), False), None, ),  # 20
        (21, TType.STRUCT, 'externalServiceMetadata', (ExternalServiceMetadata, ExternalServiceMetadata.thrift_spec), None, ),  # 21
        (22, TType.I32, 'userLibraryVisibility', None, None, ),  # 22
        (23, TType.STRING, 'dealId', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'ownerId', 'UTF8', None, ),  # 24
        (25, TType.LIST, 'collectionIds', (TType.STRING, 'UTF8', False), None, ),  # 25
    )
    def __init__(self, id=None, name=None, folderId=None, type=None, favorite=None, thumbnailDetails=None, originalDetails=None, metadata=None, lastUsed=None, tags=None, origin=None, mimeType=None, favoritedAt=None, listingIdSHA=None, content=None, gifDetails=None, externalResourceId=None, externalResourceType=None, isDefault=None, assetUsage=None, externalServiceMetadata=None, userLibraryVisibility=None, dealId=None, ownerId=None, collectionIds=None, ):
        self.id = id
        self.name = name
        self.folderId = folderId
        self.type = type
        self.favorite = favorite
        self.thumbnailDetails = thumbnailDetails
        self.originalDetails = originalDetails
        self.metadata = metadata
        self.lastUsed = lastUsed
        self.tags = tags
        self.origin = origin
        self.mimeType = mimeType
        self.favoritedAt = favoritedAt
        self.listingIdSHA = listingIdSHA
        self.content = content
        self.gifDetails = gifDetails
        self.externalResourceId = externalResourceId
        self.externalResourceType = externalResourceType
        self.isDefault = isDefault
        self.assetUsage = assetUsage
        self.externalServiceMetadata = externalServiceMetadata
        self.userLibraryVisibility = userLibraryVisibility
        self.dealId = dealId
        self.ownerId = ownerId
        self.collectionIds = collectionIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.folderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.favorite = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.thumbnailDetails = AssetDetails()
                    self.thumbnailDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.originalDetails = AssetDetails()
                    self.originalDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.metadata = Metadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.lastUsed = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.tags = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = Tag()
                        _elem9.read(iprot)
                        self.tags.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.origin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.mimeType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.favoritedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.content = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.gifDetails = AssetDetails()
                    self.gifDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.externalResourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.externalResourceType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.isDefault = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.assetUsage = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = AssetUsageObject()
                        _elem13.read(iprot)
                        self.assetUsage.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRUCT:
                    self.externalServiceMetadata = ExternalServiceMetadata()
                    self.externalServiceMetadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I32:
                    self.userLibraryVisibility = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.dealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.ownerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.LIST:
                    self.collectionIds = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.collectionIds.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Asset')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.folderId is not None:
            oprot.writeFieldBegin('folderId', TType.STRING, 3)
            oprot.writeString(self.folderId.encode('utf-8') if sys.version_info[0] == 2 else self.folderId)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 4)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.favorite is not None:
            oprot.writeFieldBegin('favorite', TType.BOOL, 5)
            oprot.writeBool(self.favorite)
            oprot.writeFieldEnd()
        if self.thumbnailDetails is not None:
            oprot.writeFieldBegin('thumbnailDetails', TType.STRUCT, 6)
            self.thumbnailDetails.write(oprot)
            oprot.writeFieldEnd()
        if self.originalDetails is not None:
            oprot.writeFieldBegin('originalDetails', TType.STRUCT, 7)
            self.originalDetails.write(oprot)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 8)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.lastUsed is not None:
            oprot.writeFieldBegin('lastUsed', TType.I64, 9)
            oprot.writeI64(self.lastUsed)
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.tags))
            for _iter19 in self.tags:
                _iter19.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.origin is not None:
            oprot.writeFieldBegin('origin', TType.I32, 11)
            oprot.writeI32(self.origin)
            oprot.writeFieldEnd()
        if self.mimeType is not None:
            oprot.writeFieldBegin('mimeType', TType.STRING, 12)
            oprot.writeString(self.mimeType.encode('utf-8') if sys.version_info[0] == 2 else self.mimeType)
            oprot.writeFieldEnd()
        if self.favoritedAt is not None:
            oprot.writeFieldBegin('favoritedAt', TType.I64, 13)
            oprot.writeI64(self.favoritedAt)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 14)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 15)
            oprot.writeString(self.content.encode('utf-8') if sys.version_info[0] == 2 else self.content)
            oprot.writeFieldEnd()
        if self.gifDetails is not None:
            oprot.writeFieldBegin('gifDetails', TType.STRUCT, 16)
            self.gifDetails.write(oprot)
            oprot.writeFieldEnd()
        if self.externalResourceId is not None:
            oprot.writeFieldBegin('externalResourceId', TType.STRING, 17)
            oprot.writeString(self.externalResourceId.encode('utf-8') if sys.version_info[0] == 2 else self.externalResourceId)
            oprot.writeFieldEnd()
        if self.externalResourceType is not None:
            oprot.writeFieldBegin('externalResourceType', TType.STRING, 18)
            oprot.writeString(self.externalResourceType.encode('utf-8') if sys.version_info[0] == 2 else self.externalResourceType)
            oprot.writeFieldEnd()
        if self.isDefault is not None:
            oprot.writeFieldBegin('isDefault', TType.BOOL, 19)
            oprot.writeBool(self.isDefault)
            oprot.writeFieldEnd()
        if self.assetUsage is not None:
            oprot.writeFieldBegin('assetUsage', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.assetUsage))
            for _iter20 in self.assetUsage:
                _iter20.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.externalServiceMetadata is not None:
            oprot.writeFieldBegin('externalServiceMetadata', TType.STRUCT, 21)
            self.externalServiceMetadata.write(oprot)
            oprot.writeFieldEnd()
        if self.userLibraryVisibility is not None:
            oprot.writeFieldBegin('userLibraryVisibility', TType.I32, 22)
            oprot.writeI32(self.userLibraryVisibility)
            oprot.writeFieldEnd()
        if self.dealId is not None:
            oprot.writeFieldBegin('dealId', TType.STRING, 23)
            oprot.writeString(self.dealId.encode('utf-8') if sys.version_info[0] == 2 else self.dealId)
            oprot.writeFieldEnd()
        if self.ownerId is not None:
            oprot.writeFieldBegin('ownerId', TType.STRING, 24)
            oprot.writeString(self.ownerId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerId)
            oprot.writeFieldEnd()
        if self.collectionIds is not None:
            oprot.writeFieldBegin('collectionIds', TType.LIST, 25)
            oprot.writeListBegin(TType.STRING, len(self.collectionIds))
            for _iter21 in self.collectionIds:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AssetFilterQuery(object):
    """
    Attributes:
     - deleted
     - textSearchOnName
     - hasBeenUsed
     - timeRangeFilter
     - favorited
     - assetTypes
     - listingIdSHAs
     - mediaTypes
     - ingestionProjectIds
     - ingestionMediaCategories
     - createdByIds
     - userLibraryVisibilities
     - dealIds
     - collectionIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'deleted', None, None, ),  # 1
        (2, TType.STRING, 'textSearchOnName', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'hasBeenUsed', None, None, ),  # 3
        (4, TType.STRUCT, 'timeRangeFilter', (AssetsTimeRangeFilter, AssetsTimeRangeFilter.thrift_spec), None, ),  # 4
        (5, TType.BOOL, 'favorited', None, None, ),  # 5
        (6, TType.LIST, 'assetTypes', (TType.I32, None, False), None, ),  # 6
        (7, TType.LIST, 'listingIdSHAs', (TType.STRING, 'UTF8', False), None, ),  # 7
        (8, TType.LIST, 'mediaTypes', (TType.I32, None, False), None, ),  # 8
        (9, TType.LIST, 'ingestionProjectIds', (TType.STRING, 'UTF8', False), None, ),  # 9
        (10, TType.LIST, 'ingestionMediaCategories', (TType.I32, None, False), None, ),  # 10
        (11, TType.LIST, 'createdByIds', (TType.STRING, 'UTF8', False), None, ),  # 11
        (12, TType.LIST, 'userLibraryVisibilities', (TType.I32, None, False), None, ),  # 12
        (13, TType.LIST, 'dealIds', (TType.STRING, 'UTF8', False), None, ),  # 13
        (14, TType.LIST, 'collectionIds', (TType.STRING, 'UTF8', False), None, ),  # 14
    )
    def __init__(self, deleted=None, textSearchOnName=None, hasBeenUsed=None, timeRangeFilter=None, favorited=None, assetTypes=None, listingIdSHAs=None, mediaTypes=None, ingestionProjectIds=None, ingestionMediaCategories=None, createdByIds=None, userLibraryVisibilities=None, dealIds=None, collectionIds=None, ):
        self.deleted = deleted
        self.textSearchOnName = textSearchOnName
        self.hasBeenUsed = hasBeenUsed
        self.timeRangeFilter = timeRangeFilter
        self.favorited = favorited
        self.assetTypes = assetTypes
        self.listingIdSHAs = listingIdSHAs
        self.mediaTypes = mediaTypes
        self.ingestionProjectIds = ingestionProjectIds
        self.ingestionMediaCategories = ingestionMediaCategories
        self.createdByIds = createdByIds
        self.userLibraryVisibilities = userLibraryVisibilities
        self.dealIds = dealIds
        self.collectionIds = collectionIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.deleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textSearchOnName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasBeenUsed = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.timeRangeFilter = AssetsTimeRangeFilter()
                    self.timeRangeFilter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.favorited = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.assetTypes = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readI32()
                        self.assetTypes.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.listingIdSHAs = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAs.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.mediaTypes = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = iprot.readI32()
                        self.mediaTypes.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.ingestionProjectIds = []
                    (_etype34, _size37) = iprot.readListBegin()
                    for _i35 in range(_size37):
                        _elem36 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.ingestionProjectIds.append(_elem36)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.ingestionMediaCategories = []
                    (_etype38, _size41) = iprot.readListBegin()
                    for _i39 in range(_size41):
                        _elem40 = iprot.readI32()
                        self.ingestionMediaCategories.append(_elem40)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.createdByIds = []
                    (_etype42, _size45) = iprot.readListBegin()
                    for _i43 in range(_size45):
                        _elem44 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.createdByIds.append(_elem44)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.userLibraryVisibilities = []
                    (_etype46, _size49) = iprot.readListBegin()
                    for _i47 in range(_size49):
                        _elem48 = iprot.readI32()
                        self.userLibraryVisibilities.append(_elem48)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.dealIds = []
                    (_etype50, _size53) = iprot.readListBegin()
                    for _i51 in range(_size53):
                        _elem52 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dealIds.append(_elem52)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.collectionIds = []
                    (_etype54, _size57) = iprot.readListBegin()
                    for _i55 in range(_size57):
                        _elem56 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.collectionIds.append(_elem56)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssetFilterQuery')
        if self.deleted is not None:
            oprot.writeFieldBegin('deleted', TType.BOOL, 1)
            oprot.writeBool(self.deleted)
            oprot.writeFieldEnd()
        if self.textSearchOnName is not None:
            oprot.writeFieldBegin('textSearchOnName', TType.STRING, 2)
            oprot.writeString(self.textSearchOnName.encode('utf-8') if sys.version_info[0] == 2 else self.textSearchOnName)
            oprot.writeFieldEnd()
        if self.hasBeenUsed is not None:
            oprot.writeFieldBegin('hasBeenUsed', TType.BOOL, 3)
            oprot.writeBool(self.hasBeenUsed)
            oprot.writeFieldEnd()
        if self.timeRangeFilter is not None:
            oprot.writeFieldBegin('timeRangeFilter', TType.STRUCT, 4)
            self.timeRangeFilter.write(oprot)
            oprot.writeFieldEnd()
        if self.favorited is not None:
            oprot.writeFieldBegin('favorited', TType.BOOL, 5)
            oprot.writeBool(self.favorited)
            oprot.writeFieldEnd()
        if self.assetTypes is not None:
            oprot.writeFieldBegin('assetTypes', TType.LIST, 6)
            oprot.writeListBegin(TType.I32, len(self.assetTypes))
            for _iter58 in self.assetTypes:
                oprot.writeI32(_iter58)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingIdSHAs is not None:
            oprot.writeFieldBegin('listingIdSHAs', TType.LIST, 7)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAs))
            for _iter59 in self.listingIdSHAs:
                oprot.writeString(_iter59.encode('utf-8') if sys.version_info[0] == 2 else _iter59)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.mediaTypes is not None:
            oprot.writeFieldBegin('mediaTypes', TType.LIST, 8)
            oprot.writeListBegin(TType.I32, len(self.mediaTypes))
            for _iter60 in self.mediaTypes:
                oprot.writeI32(_iter60)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ingestionProjectIds is not None:
            oprot.writeFieldBegin('ingestionProjectIds', TType.LIST, 9)
            oprot.writeListBegin(TType.STRING, len(self.ingestionProjectIds))
            for _iter61 in self.ingestionProjectIds:
                oprot.writeString(_iter61.encode('utf-8') if sys.version_info[0] == 2 else _iter61)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ingestionMediaCategories is not None:
            oprot.writeFieldBegin('ingestionMediaCategories', TType.LIST, 10)
            oprot.writeListBegin(TType.I32, len(self.ingestionMediaCategories))
            for _iter62 in self.ingestionMediaCategories:
                oprot.writeI32(_iter62)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdByIds is not None:
            oprot.writeFieldBegin('createdByIds', TType.LIST, 11)
            oprot.writeListBegin(TType.STRING, len(self.createdByIds))
            for _iter63 in self.createdByIds:
                oprot.writeString(_iter63.encode('utf-8') if sys.version_info[0] == 2 else _iter63)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userLibraryVisibilities is not None:
            oprot.writeFieldBegin('userLibraryVisibilities', TType.LIST, 12)
            oprot.writeListBegin(TType.I32, len(self.userLibraryVisibilities))
            for _iter64 in self.userLibraryVisibilities:
                oprot.writeI32(_iter64)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dealIds is not None:
            oprot.writeFieldBegin('dealIds', TType.LIST, 13)
            oprot.writeListBegin(TType.STRING, len(self.dealIds))
            for _iter65 in self.dealIds:
                oprot.writeString(_iter65.encode('utf-8') if sys.version_info[0] == 2 else _iter65)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.collectionIds is not None:
            oprot.writeFieldBegin('collectionIds', TType.LIST, 14)
            oprot.writeListBegin(TType.STRING, len(self.collectionIds))
            for _iter66 in self.collectionIds:
                oprot.writeString(_iter66.encode('utf-8') if sys.version_info[0] == 2 else _iter66)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FoldersFilterQuery(object):
    """
    Attributes:
     - deleted
     - textSearchOnName
     - folderTypes
     - timeRangeFilter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'deleted', None, None, ),  # 1
        (2, TType.STRING, 'textSearchOnName', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'folderTypes', (TType.I32, None, False), None, ),  # 3
        (4, TType.STRUCT, 'timeRangeFilter', (FoldersTimeRangeFilter, FoldersTimeRangeFilter.thrift_spec), None, ),  # 4
    )
    def __init__(self, deleted=None, textSearchOnName=None, folderTypes=None, timeRangeFilter=None, ):
        self.deleted = deleted
        self.textSearchOnName = textSearchOnName
        self.folderTypes = folderTypes
        self.timeRangeFilter = timeRangeFilter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.deleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textSearchOnName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.folderTypes = []
                    (_etype67, _size70) = iprot.readListBegin()
                    for _i68 in range(_size70):
                        _elem69 = iprot.readI32()
                        self.folderTypes.append(_elem69)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.timeRangeFilter = FoldersTimeRangeFilter()
                    self.timeRangeFilter.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FoldersFilterQuery')
        if self.deleted is not None:
            oprot.writeFieldBegin('deleted', TType.BOOL, 1)
            oprot.writeBool(self.deleted)
            oprot.writeFieldEnd()
        if self.textSearchOnName is not None:
            oprot.writeFieldBegin('textSearchOnName', TType.STRING, 2)
            oprot.writeString(self.textSearchOnName.encode('utf-8') if sys.version_info[0] == 2 else self.textSearchOnName)
            oprot.writeFieldEnd()
        if self.folderTypes is not None:
            oprot.writeFieldBegin('folderTypes', TType.LIST, 3)
            oprot.writeListBegin(TType.I32, len(self.folderTypes))
            for _iter71 in self.folderTypes:
                oprot.writeI32(_iter71)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.timeRangeFilter is not None:
            oprot.writeFieldBegin('timeRangeFilter', TType.STRUCT, 4)
            self.timeRangeFilter.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Assets(object):
    """
    Attributes:
     - assets
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'assets', (TType.STRUCT, (Asset, Asset.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'totalResults', None, None, ),  # 2
    )
    def __init__(self, assets=None, totalResults=None, ):
        self.assets = assets
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.assets = []
                    (_etype72, _size75) = iprot.readListBegin()
                    for _i73 in range(_size75):
                        _elem74 = Asset()
                        _elem74.read(iprot)
                        self.assets.append(_elem74)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Assets')
        if self.assets is not None:
            oprot.writeFieldBegin('assets', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.assets))
            for _iter76 in self.assets:
                _iter76.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 2)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Collection(object):
    """
    Attributes:
     - id
     - collectionClient
     - createdAt
     - updatedAt
     - deletedAt
     - assets
     - assetTotalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'collectionClient', None, None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.I64, 'deletedAt', None, None, ),  # 5
        (6, TType.LIST, 'assets', (TType.STRUCT, (Asset, Asset.thrift_spec), False), None, ),  # 6
        (7, TType.I32, 'assetTotalResults', None, None, ),  # 7
    )
    def __init__(self, id=None, collectionClient=None, createdAt=None, updatedAt=None, deletedAt=None, assets=None, assetTotalResults=None, ):
        self.id = id
        self.collectionClient = collectionClient
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.deletedAt = deletedAt
        self.assets = assets
        self.assetTotalResults = assetTotalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.collectionClient = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.assets = []
                    (_etype77, _size80) = iprot.readListBegin()
                    for _i78 in range(_size80):
                        _elem79 = Asset()
                        _elem79.read(iprot)
                        self.assets.append(_elem79)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.assetTotalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Collection')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.collectionClient is not None:
            oprot.writeFieldBegin('collectionClient', TType.I32, 2)
            oprot.writeI32(self.collectionClient)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 5)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        if self.assets is not None:
            oprot.writeFieldBegin('assets', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.assets))
            for _iter81 in self.assets:
                _iter81.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.assetTotalResults is not None:
            oprot.writeFieldBegin('assetTotalResults', TType.I32, 7)
            oprot.writeI32(self.assetTotalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AssetLibCollections(object):
    """
    Attributes:
     - collections
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'collections', (TType.STRUCT, (Collection, Collection.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'totalResults', None, None, ),  # 2
    )
    def __init__(self, collections=None, totalResults=None, ):
        self.collections = collections
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.collections = []
                    (_etype82, _size85) = iprot.readListBegin()
                    for _i83 in range(_size85):
                        _elem84 = Collection()
                        _elem84.read(iprot)
                        self.collections.append(_elem84)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssetLibCollections')
        if self.collections is not None:
            oprot.writeFieldBegin('collections', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.collections))
            for _iter86 in self.collections:
                _iter86.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 2)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Folder(object):
    """
    Attributes:
     - id
     - type
     - ownerId
     - name
     - parentFolderId
     - childFolderIds
     - metadata
     - assets
     - tags
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
        (3, TType.STRING, 'ownerId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'name', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'parentFolderId', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'childFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.STRUCT, 'metadata', (Metadata, Metadata.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'assets', (Assets, Assets.thrift_spec), None, ),  # 8
        (9, TType.LIST, 'tags', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 9
    )
    def __init__(self, id=None, type=None, ownerId=None, name=None, parentFolderId=None, childFolderIds=None, metadata=None, assets=None, tags=None, ):
        self.id = id
        self.type = type
        self.ownerId = ownerId
        self.name = name
        self.parentFolderId = parentFolderId
        self.childFolderIds = childFolderIds
        self.metadata = metadata
        self.assets = assets
        self.tags = tags

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.ownerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.parentFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.childFolderIds = []
                    (_etype87, _size90) = iprot.readListBegin()
                    for _i88 in range(_size90):
                        _elem89 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.childFolderIds.append(_elem89)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.metadata = Metadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.assets = Assets()
                    self.assets.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.tags = []
                    (_etype91, _size94) = iprot.readListBegin()
                    for _i92 in range(_size94):
                        _elem93 = Tag()
                        _elem93.read(iprot)
                        self.tags.append(_elem93)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Folder')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.ownerId is not None:
            oprot.writeFieldBegin('ownerId', TType.STRING, 3)
            oprot.writeString(self.ownerId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 4)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.parentFolderId is not None:
            oprot.writeFieldBegin('parentFolderId', TType.STRING, 5)
            oprot.writeString(self.parentFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.parentFolderId)
            oprot.writeFieldEnd()
        if self.childFolderIds is not None:
            oprot.writeFieldBegin('childFolderIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.childFolderIds))
            for _iter95 in self.childFolderIds:
                oprot.writeString(_iter95.encode('utf-8') if sys.version_info[0] == 2 else _iter95)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 7)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.assets is not None:
            oprot.writeFieldBegin('assets', TType.STRUCT, 8)
            self.assets.write(oprot)
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.tags))
            for _iter96 in self.tags:
                _iter96.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Folders(object):
    """
    Attributes:
     - folders
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'folders', (TType.STRUCT, (Folder, Folder.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'totalResults', None, None, ),  # 2
    )
    def __init__(self, folders=None, totalResults=None, ):
        self.folders = folders
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.folders = []
                    (_etype97, _size100) = iprot.readListBegin()
                    for _i98 in range(_size100):
                        _elem99 = Folder()
                        _elem99.read(iprot)
                        self.folders.append(_elem99)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Folders')
        if self.folders is not None:
            oprot.writeFieldBegin('folders', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.folders))
            for _iter101 in self.folders:
                _iter101.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 2)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
