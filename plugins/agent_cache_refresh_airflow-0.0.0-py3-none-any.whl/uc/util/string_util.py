# -*- coding: utf-8 -*-
"""
:copyright: (c) 2017 by Urban Compass, Inc.
"""
import hashlib

import re


UNCHANGED_CASE = None
CAMEL_CASE = 0
SNAKE_CASE = 1

SINGLE_QUOTE = "'"
DOUBLE_QUOTE = '"'
ALL_QUOTES = "(?:'|\")"


def fix_variable_case(strvalue, string_case):
    if string_case == UNCHANGED_CASE:
        return strvalue
    if string_case == SNAKE_CASE:
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", strvalue).lower()
    if string_case == CAMEL_CASE:
        words = strvalue.split("_")
        return "".join([word.capitalize() if idx != 0 else word for idx, word in enumerate(words)])
    return strvalue


def quote_string(s, is_single=False):
    quote_type = "'" if is_single else '"'
    return "{quote_type}{string}{quote_type}".format(string=s, quote_type=quote_type)


def unquote_string(s, quote_type=ALL_QUOTES):
    """
    Strip outermost matching pair of quotes.
    :param s: (str) the string to be stripped
    :param quote_style: (str) char/regex to be stripped
    :return: (str) the original string with the opening/closing quotes stripped
    """
    # NOTE: Currently, this function only strips out quotes, but it can be updated to strip out any
    # character
    if quote_type in [SINGLE_QUOTE, DOUBLE_QUOTE, ALL_QUOTES]:
        return re.match(r"^({quote_type}?)(.*)\1$".format(quote_type=quote_type), s).group(2)
    return s


def safe_string_to_float(s):
    """
    Safe string conversion to float
    :param s: the string to be converted
    :return: the float or nan
    """
    try:
        ret = float(s)
    except (ValueError, TypeError):
        ret = float("nan")
    return ret


def sha(msg):
    """
    Computes sha of a string
    :param msg: the input message
    :return: the hex sha of the message
    """
    m = hashlib.sha1()
    m.update(msg)
    return m.hexdigest()
