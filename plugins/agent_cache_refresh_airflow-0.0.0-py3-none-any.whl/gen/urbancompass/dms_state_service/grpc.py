# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.closings.closings_service.ttypes as closings_service
import gen.urbancompass.contacts.api.contact.ttypes as contact
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes as deals_workflow_model
import gen.urbancompass.dms_common.dms_communication.ttypes as dms_communication
import gen.urbancompass.dms_communication_model.ttypes as dms_communication_model
import gen.urbancompass.dms_common.dms_deal.ttypes as dms_deal
import gen.urbancompass.dms_document.ttypes as dms_document
import gen.urbancompass.dms_event_publisher.ttypes as dms_event_publisher
import gen.urbancompass.dms_common.dms_folder.ttypes as dms_folder
import gen.urbancompass.dms_common.dms_glide.ttypes as dms_glide
import gen.urbancompass.dms_common.dms_listing.ttypes as dms_listing
import gen.urbancompass.dms_common.dms_notification.ttypes as dms_notification
import gen.urbancompass.dms_state_model.ttypes as dms_state_model
import gen.urbancompass.dms_translation_model.ttypes as dms_translation_model
import gen.urbancompass.listing.listing.ttypes as listing
import gen.urbancompass.listing.listing_compliance.ttypes as listing_compliance
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes as region_compliance_checklist_db_helper
import uc.grpc.codec as _grpc_codec



class DmsStateServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.addChecklistItemNote = channel.unary_unary(
        '/DmsStateService/addChecklistItemNote',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddChecklistItemNoteResponse),
        )
    self.addCustomChecklistItem = channel.unary_unary(
        '/DmsStateService/addCustomChecklistItem',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddCustomChecklistItemResponse),
        )
    self.addDMSContacts = channel.unary_unary(
        '/DmsStateService/addDMSContacts',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSContactsResponse),
        )
    self.addDMSListing = channel.unary_unary(
        '/DmsStateService/addDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSListingResponse),
        )
    self.addDMSListingDocument = channel.unary_unary(
        '/DmsStateService/addDMSListingDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSListingDocumentResponse),
        )
    self.addDMSOffer = channel.unary_unary(
        '/DmsStateService/addDMSOffer',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSOfferResponse),
        )
    self.addDMSTransaction = channel.unary_unary(
        '/DmsStateService/addDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSTransactionResponse),
        )
    self.addDMSTransactionDocument = channel.unary_unary(
        '/DmsStateService/addDMSTransactionDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSTransactionDocumentResponse),
        )
    self.backfillDmsFolderWithMarketAndOffice = channel.unary_unary(
        '/DmsStateService/backfillDmsFolderWithMarketAndOffice',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BackfillDmsFolderWithMarketAndOfficeResponse),
        )
    self.batchGetChecklistItemNoteInfo = channel.unary_unary(
        '/DmsStateService/batchGetChecklistItemNoteInfo',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetChecklistItemNoteInfoResponse),
        )
    self.batchGetDMSFolderOverview = channel.unary_unary(
        '/DmsStateService/batchGetDMSFolderOverview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetDMSFoldersOverviewResponse),
        )
    self.calculateCommissionsAndAllocations = channel.unary_unary(
        '/DmsStateService/calculateCommissionsAndAllocations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.UpdateClosingResponse),
        )
    self.checkChecklistItemNoteCondition = channel.unary_unary(
        '/DmsStateService/checkChecklistItemNoteCondition',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckChecklistItemNoteConditionResponse),
        )
    self.checkDmsFolderCondition = channel.unary_unary(
        '/DmsStateService/checkDmsFolderCondition',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckDmsFolderConditionResponse),
        )
    self.claimDeal = channel.unary_unary(
        '/DmsStateService/claimDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ClaimDealResponse),
        )
    self.createClosing = channel.unary_unary(
        '/DmsStateService/createClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.CreateClosingResponse),
        )
    self.createDMSFolder = channel.unary_unary(
        '/DmsStateService/createDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateDMSFolderResponse),
        )
    self.createDMSFolderForDualRep = channel.unary_unary(
        '/DmsStateService/createDMSFolderForDualRep',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateDMSFolderForDualRepResponse),
        )
    self.createDealToDws = channel.unary_unary(
        '/DmsStateService/createDealToDws',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateDealToDwsResponse),
        )
    self.createDmsFolderForReferralDeal = channel.unary_unary(
        '/DmsStateService/createDmsFolderForReferralDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateDmsFolderForReferralDealResponse),
        )
    self.deleteDMSFolder = channel.unary_unary(
        '/DmsStateService/deleteDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSFolderResponse),
        )
    self.deleteDMSListing = channel.unary_unary(
        '/DmsStateService/deleteDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSListingResponse),
        )
    self.deleteDMSListingDocument = channel.unary_unary(
        '/DmsStateService/deleteDMSListingDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSListingDocumentResponse),
        )
    self.deleteDMSTransaction = channel.unary_unary(
        '/DmsStateService/deleteDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionResponse),
        )
    self.deleteDMSTransactionDocument = channel.unary_unary(
        '/DmsStateService/deleteDMSTransactionDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionDocumentResponse),
        )
    self.deleteDraft = channel.unary_unary(
        '/DmsStateService/deleteDraft',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.UpdateClosingResponse),
        )
    self.dmsSyncInternal = channel.unary_unary(
        '/DmsStateService/dmsSyncInternal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DmsSyncInternalResponse),
        )
    self.editDocumentChecklistItems = channel.unary_unary(
        '/DmsStateService/editDocumentChecklistItems',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(EditDocumentChecklistItemsResponse),
        )
    self.filterDMSFolders = channel.unary_unary(
        '/DmsStateService/filterDMSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FilterDMSFoldersResponse),
        )
    self.filterDMSFoldersByAddress = channel.unary_unary(
        '/DmsStateService/filterDMSFoldersByAddress',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FilterDMSFoldersByAddressResponse),
        )
    self.getActivityLogsForFolder = channel.unary_unary(
        '/DmsStateService/getActivityLogsForFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetActivityLogsForFolderResponse),
        )
    self.getAgentSplit = channel.unary_unary(
        '/DmsStateService/getAgentSplit',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.GetAgentSplitResponse),
        )
    self.getAgentsInfoByTeamId = channel.unary_unary(
        '/DmsStateService/getAgentsInfoByTeamId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAgentsInfoByTeamIdResponse),
        )
    self.getAggregateDMSFolder = channel.unary_unary(
        '/DmsStateService/getAggregateDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAggregateDMSFolderResponse),
        )
    self.getAggregateInfoForGlideSync = channel.unary_unary(
        '/DmsStateService/getAggregateInfoForGlideSync',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAggregateInfoForGlideSyncResponse),
        )
    self.getAllChecklists = channel.unary_unary(
        '/DmsStateService/getAllChecklists',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllChecklistsResponse),
        )
    self.getAllSubStage = channel.unary_unary(
        '/DmsStateService/getAllSubStage',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllSubStageResponse),
        )
    self.getAndFixIfNeededDMSAgentsForDualRep = channel.unary_unary(
        '/DmsStateService/getAndFixIfNeededDMSAgentsForDualRep',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAndFixIfNeededDMSAgentsForDualRepResponse),
        )
    self.getCancelledDMSTransactions = channel.unary_unary(
        '/DmsStateService/getCancelledDMSTransactions',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetCancelledDMSTransactionsResponse),
        )
    self.getCapabilitiesOnDMSFolder = channel.unary_unary(
        '/DmsStateService/getCapabilitiesOnDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetCapabilitiesOnDMSFolderResponse),
        )
    self.getChecklistDebug = channel.unary_unary(
        '/DmsStateService/getChecklistDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistDebugResponse),
        )
    self.getChecklistItem = channel.unary_unary(
        '/DmsStateService/getChecklistItem',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistItemResponse),
        )
    self.getClosing = channel.unary_unary(
        '/DmsStateService/getClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetClosingResponse),
        )
    self.getDMSContacts = channel.unary_unary(
        '/DmsStateService/getDMSContacts',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDmsContactsResponse),
        )
    self.getDMSFolder = channel.unary_unary(
        '/DmsStateService/getDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderResponse),
        )
    self.getDMSFolderByTransaction = channel.unary_unary(
        '/DmsStateService/getDMSFolderByTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderByTransactionResponse),
        )
    self.getDMSFolderOverview = channel.unary_unary(
        '/DmsStateService/getDMSFolderOverview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderOverviewResponse),
        )
    self.getDMSFolderReminders = channel.unary_unary(
        '/DmsStateService/getDMSFolderReminders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderRemindersResponse),
        )
    self.getDMSFolders = channel.unary_unary(
        '/DmsStateService/getDMSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersResponse),
        )
    self.getDMSFoldersByCloseDateRange = channel.unary_unary(
        '/DmsStateService/getDMSFoldersByCloseDateRange',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersByCloseDateRangeResponse),
        )
    self.getDMSFoldersForBTByIdDebug = channel.unary_unary(
        '/DmsStateService/getDMSFoldersForBTByIdDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTByIdDebugResponse),
        )
    self.getDMSFoldersForBTDebug = channel.unary_unary(
        '/DmsStateService/getDMSFoldersForBTDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTDebugResponse),
        )
    self.getDMSListing = channel.unary_unary(
        '/DmsStateService/getDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSListingResponse),
        )
    self.getDMSOfferData = channel.unary_unary(
        '/DmsStateService/getDMSOfferData',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSOfferDataResponse),
        )
    self.getDMSPayloadForNotification = channel.unary_unary(
        '/DmsStateService/getDMSPayloadForNotification',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSPayloadForNotificationResponse),
        )
    self.getDMSTransaction = channel.unary_unary(
        '/DmsStateService/getDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSTransactionResponse),
        )
    self.getDmsFolderComplianceStatus = channel.unary_unary(
        '/DmsStateService/getDmsFolderComplianceStatus',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDmsFolderComplianceStatusResponse),
        )
    self.getDmsFoldersWithNoStaffGroupId = channel.unary_unary(
        '/DmsStateService/getDmsFoldersWithNoStaffGroupId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDmsFoldersWithNoStaffGroupIdResponse),
        )
    self.getNextAction = channel.unary_unary(
        '/DmsStateService/getNextAction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetNextActionResponse),
        )
    self.getPayloadInfoForCommunicationService = channel.unary_unary(
        '/DmsStateService/getPayloadInfoForCommunicationService',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetPayloadInfoForCommunicationServiceResponse),
        )
    self.getPermittedDMSFolderIDs = channel.unary_unary(
        '/DmsStateService/getPermittedDMSFolderIDs',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetPermittedDMSFolderIDsResponse),
        )
    self.getPrincipalProfilesForTeam = channel.unary_unary(
        '/DmsStateService/getPrincipalProfilesForTeam',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetPrincipalProfilesForTeamResponse),
        )
    self.getStaticReferralChecklistItems = channel.unary_unary(
        '/DmsStateService/getStaticReferralChecklistItems',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetStaticReferralChecklistItemsResponse),
        )
    self.getTeamDmsFoldersMatchingLocation = channel.unary_unary(
        '/DmsStateService/getTeamDmsFoldersMatchingLocation',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetTeamDmsFoldersMatchingLocationResponse),
        )
    self.getUser = channel.unary_unary(
        '/DmsStateService/getUser',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.GetUserResponse),
        )
    self.getWithdrawnDMSListings = channel.unary_unary(
        '/DmsStateService/getWithdrawnDMSListings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetWithdrawnDMSListingsResponse),
        )
    self.internalGetDMSFolders = channel.unary_unary(
        '/DmsStateService/internalGetDMSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersResponse),
        )
    self.sendNotificationsToKafka = channel.unary_unary(
        '/DmsStateService/sendNotificationsToKafka',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SendNotificationsToKafkaResponse),
        )
    self.setDMSContacts = channel.unary_unary(
        '/DmsStateService/setDMSContacts',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SetDMSContactsResponse),
        )
    self.shareDMSFolder = channel.unary_unary(
        '/DmsStateService/shareDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ShareDMSFolderInternalResponse),
        )
    self.sortDmsFolders = channel.unary_unary(
        '/DmsStateService/sortDmsFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SortDmsFoldersResponse),
        )
    self.splitDocument = channel.unary_unary(
        '/DmsStateService/splitDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SplitDocumentResponse),
        )
    self.unclaimDeal = channel.unary_unary(
        '/DmsStateService/unclaimDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UnclaimDealResponse),
        )
    self.unshareDMSFolder = channel.unary_unary(
        '/DmsStateService/unshareDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UnshareDMSFolderInternalResponse),
        )
    self.updateChecklistItem = channel.unary_unary(
        '/DmsStateService/updateChecklistItem',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateChecklistItemResponse),
        )
    self.updateClosing = channel.unary_unary(
        '/DmsStateService/updateClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateClosingResponse),
        )
    self.updateDMSAgentsForDualRep = channel.unary_unary(
        '/DmsStateService/updateDMSAgentsForDualRep',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSAgentsForDualRepResponse),
        )
    self.updateDMSFolder = channel.unary_unary(
        '/DmsStateService/updateDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSFolderResponse),
        )
    self.updateDMSListing = channel.unary_unary(
        '/DmsStateService/updateDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSListingResponse),
        )
    self.updateDMSListingDocument = channel.unary_unary(
        '/DmsStateService/updateDMSListingDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSListingDocumentResponse),
        )
    self.updateDMSTransaction = channel.unary_unary(
        '/DmsStateService/updateDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionResponse),
        )
    self.updateDMSTransactionDocument = channel.unary_unary(
        '/DmsStateService/updateDMSTransactionDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionDocumentResponse),
        )
    self.updateDMSTransactionSubStageFromDC = channel.unary_unary(
        '/DmsStateService/updateDMSTransactionSubStageFromDC',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionSubStageFromDCResponse),
        )
    self.updateReferralDetail = channel.unary_unary(
        '/DmsStateService/updateReferralDetail',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateReferralDetailResponse),
        )
    self.upsertCustomChecklistItemByItemId = channel.unary_unary(
        '/DmsStateService/upsertCustomChecklistItemByItemId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpsertCustomChecklistItemByItemIdResponse),
        )
    self.upsertDMSTransaction = channel.unary_unary(
        '/DmsStateService/upsertDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpsertDMSTransactionResponse),
        )
    self.validateOneField = channel.unary_unary(
        '/DmsStateService/validateOneField',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ValidateOneFieldResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class DmsStateServiceServicer(BaseServiceServicer):
  """
    The DmsStateService Service definition
  """

  def addChecklistItemNote(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addCustomChecklistItem(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSContacts(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSListingDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSOffer(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSTransactionDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def backfillDmsFolderWithMarketAndOffice(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetChecklistItemNoteInfo(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetDMSFolderOverview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def calculateCommissionsAndAllocations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkChecklistItemNoteCondition(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkDmsFolderCondition(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def claimDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createDMSFolderForDualRep(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createDealToDws(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createDmsFolderForReferralDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSListingDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSTransactionDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDraft(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def dmsSyncInternal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def editDocumentChecklistItems(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def filterDMSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def filterDMSFoldersByAddress(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getActivityLogsForFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentSplit(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentsInfoByTeamId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAggregateDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAggregateInfoForGlideSync(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllChecklists(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllSubStage(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAndFixIfNeededDMSAgentsForDualRep(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getCancelledDMSTransactions(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getCapabilitiesOnDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklistDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklistItem(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSContacts(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolderByTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolderOverview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolderReminders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFoldersByCloseDateRange(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFoldersForBTByIdDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFoldersForBTDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSOfferData(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSPayloadForNotification(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDmsFolderComplianceStatus(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDmsFoldersWithNoStaffGroupId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getNextAction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getPayloadInfoForCommunicationService(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getPermittedDMSFolderIDs(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getPrincipalProfilesForTeam(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getStaticReferralChecklistItems(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeamDmsFoldersMatchingLocation(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUser(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getWithdrawnDMSListings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def internalGetDMSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def sendNotificationsToKafka(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def setDMSContacts(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def shareDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def sortDmsFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def splitDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def unclaimDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def unshareDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateChecklistItem(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSAgentsForDualRep(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSListingDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSTransactionDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSTransactionSubStageFromDC(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateReferralDetail(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def upsertCustomChecklistItemByItemId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def upsertDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def validateOneField(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_DmsStateServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'addChecklistItemNote': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addChecklistItemNote(req),
          request_deserializer=_grpc_codec.deserializer(AddChecklistItemNoteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addCustomChecklistItem': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addCustomChecklistItem(req),
          request_deserializer=_grpc_codec.deserializer(AddCustomChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSContacts': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSContacts(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSContactsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSListingDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSListingDocument(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSListingDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSOffer': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSOffer(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSTransactionDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSTransactionDocument(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSTransactionDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'backfillDmsFolderWithMarketAndOffice': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.backfillDmsFolderWithMarketAndOffice(req),
          request_deserializer=_grpc_codec.deserializer(BackfillDmsFolderWithMarketAndOfficeRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetChecklistItemNoteInfo': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetChecklistItemNoteInfo(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetChecklistItemNoteInfoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetDMSFolderOverview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetDMSFolderOverview(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetDMSFoldersOverviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionsAndAllocations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.calculateCommissionsAndAllocations(req),
          request_deserializer=_grpc_codec.deserializer(CommissionsAndAllocationsCalculationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkChecklistItemNoteCondition': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkChecklistItemNoteCondition(req),
          request_deserializer=_grpc_codec.deserializer(CheckChecklistItemNoteConditionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkDmsFolderCondition': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkDmsFolderCondition(req),
          request_deserializer=_grpc_codec.deserializer(CheckDmsFolderConditionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'claimDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.claimDeal(req),
          request_deserializer=_grpc_codec.deserializer(ClaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createClosing(req),
          request_deserializer=_grpc_codec.deserializer(CreateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(CreateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDMSFolderForDualRep': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createDMSFolderForDualRep(req),
          request_deserializer=_grpc_codec.deserializer(CreateDMSFolderForDualRepRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDealToDws': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createDealToDws(req),
          request_deserializer=_grpc_codec.deserializer(CreateDealToDwsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDmsFolderForReferralDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createDmsFolderForReferralDeal(req),
          request_deserializer=_grpc_codec.deserializer(CreateDmsFolderForReferralDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSListingDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSListingDocument(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSListingDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSTransactionDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSTransactionDocument(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDraft': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDraft(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDraftRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'dmsSyncInternal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.dmsSyncInternal(req),
          request_deserializer=_grpc_codec.deserializer(DmsSyncInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'editDocumentChecklistItems': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.editDocumentChecklistItems(req),
          request_deserializer=_grpc_codec.deserializer(EditDocumentChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.filterDMSFolders(req),
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFoldersByAddress': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.filterDMSFoldersByAddress(req),
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getActivityLogsForFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getActivityLogsForFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetActivityLogsForFolderInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentSplit': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentSplit(req),
          request_deserializer=_grpc_codec.deserializer(GetAgentSplitStateServiceRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentsInfoByTeamId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentsInfoByTeamId(req),
          request_deserializer=_grpc_codec.deserializer(GetAgentsInfoByTeamIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAggregateDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAggregateDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetAggregateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAggregateInfoForGlideSync': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAggregateInfoForGlideSync(req),
          request_deserializer=_grpc_codec.deserializer(GetAggregateInfoForGlideSyncRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllChecklists': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllChecklists(req),
          request_deserializer=_grpc_codec.deserializer(GetAllChecklistsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllSubStage': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllSubStage(req),
          request_deserializer=_grpc_codec.deserializer(GetAllSubStageRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAndFixIfNeededDMSAgentsForDualRep': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAndFixIfNeededDMSAgentsForDualRep(req),
          request_deserializer=_grpc_codec.deserializer(GetAndFixIfNeededDMSAgentsForDualRepRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCancelledDMSTransactions': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getCancelledDMSTransactions(req),
          request_deserializer=_grpc_codec.deserializer(GetCancelledDMSTransactionsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCapabilitiesOnDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getCapabilitiesOnDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetCapabilitiesOnDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklistDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistItem': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklistItem(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getClosing(req),
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSContacts': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSContacts(req),
          request_deserializer=_grpc_codec.deserializer(GetDmsContactsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderByTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolderByTransaction(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderByTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderOverview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolderOverview(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderOverviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderReminders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolderReminders(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderRemindersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolders(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersByCloseDateRange': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFoldersByCloseDateRange(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersByCloseDateRangeRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTByIdDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFoldersForBTByIdDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTByIdDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFoldersForBTDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSOfferData': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSOfferData(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSOfferDataRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSPayloadForNotification': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSPayloadForNotification(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSPayloadForNotificationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsFolderComplianceStatus': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDmsFolderComplianceStatus(req),
          request_deserializer=_grpc_codec.deserializer(GetDmsFolderComplianceStatusRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsFoldersWithNoStaffGroupId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDmsFoldersWithNoStaffGroupId(req),
          request_deserializer=_grpc_codec.deserializer(GetDmsFoldersWithNoStaffGroupIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getNextAction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getNextAction(req),
          request_deserializer=_grpc_codec.deserializer(GetNextActionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPayloadInfoForCommunicationService': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getPayloadInfoForCommunicationService(req),
          request_deserializer=_grpc_codec.deserializer(GetPayloadInfoForCommunicationServiceRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPermittedDMSFolderIDs': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getPermittedDMSFolderIDs(req),
          request_deserializer=_grpc_codec.deserializer(GetPermittedDMSFolderIDsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPrincipalProfilesForTeam': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getPrincipalProfilesForTeam(req),
          request_deserializer=_grpc_codec.deserializer(GetPrincipalProfilesForTeamRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getStaticReferralChecklistItems': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getStaticReferralChecklistItems(req),
          request_deserializer=_grpc_codec.deserializer(GetStaticReferralChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamDmsFoldersMatchingLocation': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeamDmsFoldersMatchingLocation(req),
          request_deserializer=_grpc_codec.deserializer(GetTeamDmsFoldersMatchingLocationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUser(req),
          request_deserializer=_grpc_codec.deserializer(GetUserInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getWithdrawnDMSListings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getWithdrawnDMSListings(req),
          request_deserializer=_grpc_codec.deserializer(GetWithdrawnDMSListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'internalGetDMSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.internalGetDMSFolders(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'sendNotificationsToKafka': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.sendNotificationsToKafka(req),
          request_deserializer=_grpc_codec.deserializer(SendNotificationsToKafkaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setDMSContacts': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.setDMSContacts(req),
          request_deserializer=_grpc_codec.deserializer(SetDMSContactsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'shareDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.shareDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(ShareDMSFolderInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'sortDmsFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.sortDmsFolders(req),
          request_deserializer=_grpc_codec.deserializer(SortDmsFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'splitDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.splitDocument(req),
          request_deserializer=_grpc_codec.deserializer(SplitDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unclaimDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.unclaimDeal(req),
          request_deserializer=_grpc_codec.deserializer(UnclaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unshareDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.unshareDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(UnshareDMSFolderInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateChecklistItem': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateChecklistItem(req),
          request_deserializer=_grpc_codec.deserializer(UpdateChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateClosing(req),
          request_deserializer=_grpc_codec.deserializer(UpdateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSAgentsForDualRep': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSAgentsForDualRep(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSAgentsForDualRepRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSListingDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSListingDocument(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSTransactionDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSTransactionDocument(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSTransactionSubStageFromDC': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSTransactionSubStageFromDC(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionSubStageFromDCRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateReferralDetail': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateReferralDetail(req),
          request_deserializer=_grpc_codec.deserializer(UpdateReferralDetailRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertCustomChecklistItemByItemId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.upsertCustomChecklistItemByItemId(req),
          request_deserializer=_grpc_codec.deserializer(UpsertCustomChecklistItemByItemIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.upsertDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(UpsertDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'validateOneField': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.validateOneField(req),
          request_deserializer=_grpc_codec.deserializer(ValidateOneFieldRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsStateService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_DmsStateServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'addChecklistItemNote': grpc.unary_unary_rpc_method_handler(
          servicer.addChecklistItemNote,
          request_deserializer=_grpc_codec.deserializer(AddChecklistItemNoteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addCustomChecklistItem': grpc.unary_unary_rpc_method_handler(
          servicer.addCustomChecklistItem,
          request_deserializer=_grpc_codec.deserializer(AddCustomChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSContacts': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSContacts,
          request_deserializer=_grpc_codec.deserializer(AddDMSContactsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSListing,
          request_deserializer=_grpc_codec.deserializer(AddDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSListingDocument': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSListingDocument,
          request_deserializer=_grpc_codec.deserializer(AddDMSListingDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSOffer': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSOffer,
          request_deserializer=_grpc_codec.deserializer(AddDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(AddDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSTransactionDocument': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSTransactionDocument,
          request_deserializer=_grpc_codec.deserializer(AddDMSTransactionDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'backfillDmsFolderWithMarketAndOffice': grpc.unary_unary_rpc_method_handler(
          servicer.backfillDmsFolderWithMarketAndOffice,
          request_deserializer=_grpc_codec.deserializer(BackfillDmsFolderWithMarketAndOfficeRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetChecklistItemNoteInfo': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetChecklistItemNoteInfo,
          request_deserializer=_grpc_codec.deserializer(BatchGetChecklistItemNoteInfoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetDMSFolderOverview': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetDMSFolderOverview,
          request_deserializer=_grpc_codec.deserializer(BatchGetDMSFoldersOverviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionsAndAllocations': grpc.unary_unary_rpc_method_handler(
          servicer.calculateCommissionsAndAllocations,
          request_deserializer=_grpc_codec.deserializer(CommissionsAndAllocationsCalculationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkChecklistItemNoteCondition': grpc.unary_unary_rpc_method_handler(
          servicer.checkChecklistItemNoteCondition,
          request_deserializer=_grpc_codec.deserializer(CheckChecklistItemNoteConditionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkDmsFolderCondition': grpc.unary_unary_rpc_method_handler(
          servicer.checkDmsFolderCondition,
          request_deserializer=_grpc_codec.deserializer(CheckDmsFolderConditionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'claimDeal': grpc.unary_unary_rpc_method_handler(
          servicer.claimDeal,
          request_deserializer=_grpc_codec.deserializer(ClaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createClosing': grpc.unary_unary_rpc_method_handler(
          servicer.createClosing,
          request_deserializer=_grpc_codec.deserializer(CreateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.createDMSFolder,
          request_deserializer=_grpc_codec.deserializer(CreateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDMSFolderForDualRep': grpc.unary_unary_rpc_method_handler(
          servicer.createDMSFolderForDualRep,
          request_deserializer=_grpc_codec.deserializer(CreateDMSFolderForDualRepRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDealToDws': grpc.unary_unary_rpc_method_handler(
          servicer.createDealToDws,
          request_deserializer=_grpc_codec.deserializer(CreateDealToDwsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDmsFolderForReferralDeal': grpc.unary_unary_rpc_method_handler(
          servicer.createDmsFolderForReferralDeal,
          request_deserializer=_grpc_codec.deserializer(CreateDmsFolderForReferralDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSFolder,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSListing,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSListingDocument': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSListingDocument,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSListingDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSTransactionDocument': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSTransactionDocument,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDraft': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDraft,
          request_deserializer=_grpc_codec.deserializer(DeleteDraftRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'dmsSyncInternal': grpc.unary_unary_rpc_method_handler(
          servicer.dmsSyncInternal,
          request_deserializer=_grpc_codec.deserializer(DmsSyncInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'editDocumentChecklistItems': grpc.unary_unary_rpc_method_handler(
          servicer.editDocumentChecklistItems,
          request_deserializer=_grpc_codec.deserializer(EditDocumentChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.filterDMSFolders,
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFoldersByAddress': grpc.unary_unary_rpc_method_handler(
          servicer.filterDMSFoldersByAddress,
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getActivityLogsForFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getActivityLogsForFolder,
          request_deserializer=_grpc_codec.deserializer(GetActivityLogsForFolderInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentSplit': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentSplit,
          request_deserializer=_grpc_codec.deserializer(GetAgentSplitStateServiceRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentsInfoByTeamId': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentsInfoByTeamId,
          request_deserializer=_grpc_codec.deserializer(GetAgentsInfoByTeamIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAggregateDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getAggregateDMSFolder,
          request_deserializer=_grpc_codec.deserializer(GetAggregateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAggregateInfoForGlideSync': grpc.unary_unary_rpc_method_handler(
          servicer.getAggregateInfoForGlideSync,
          request_deserializer=_grpc_codec.deserializer(GetAggregateInfoForGlideSyncRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllChecklists': grpc.unary_unary_rpc_method_handler(
          servicer.getAllChecklists,
          request_deserializer=_grpc_codec.deserializer(GetAllChecklistsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllSubStage': grpc.unary_unary_rpc_method_handler(
          servicer.getAllSubStage,
          request_deserializer=_grpc_codec.deserializer(GetAllSubStageRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAndFixIfNeededDMSAgentsForDualRep': grpc.unary_unary_rpc_method_handler(
          servicer.getAndFixIfNeededDMSAgentsForDualRep,
          request_deserializer=_grpc_codec.deserializer(GetAndFixIfNeededDMSAgentsForDualRepRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCancelledDMSTransactions': grpc.unary_unary_rpc_method_handler(
          servicer.getCancelledDMSTransactions,
          request_deserializer=_grpc_codec.deserializer(GetCancelledDMSTransactionsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCapabilitiesOnDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getCapabilitiesOnDMSFolder,
          request_deserializer=_grpc_codec.deserializer(GetCapabilitiesOnDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklistDebug,
          request_deserializer=_grpc_codec.deserializer(GetChecklistDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistItem': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklistItem,
          request_deserializer=_grpc_codec.deserializer(GetChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosing': grpc.unary_unary_rpc_method_handler(
          servicer.getClosing,
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSContacts': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSContacts,
          request_deserializer=_grpc_codec.deserializer(GetDmsContactsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolder,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderByTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolderByTransaction,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderByTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderOverview': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolderOverview,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderOverviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderReminders': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolderReminders,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderRemindersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolders,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersByCloseDateRange': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFoldersByCloseDateRange,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersByCloseDateRangeRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTByIdDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFoldersForBTByIdDebug,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTByIdDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFoldersForBTDebug,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSListing,
          request_deserializer=_grpc_codec.deserializer(GetDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSOfferData': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSOfferData,
          request_deserializer=_grpc_codec.deserializer(GetDMSOfferDataRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSPayloadForNotification': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSPayloadForNotification,
          request_deserializer=_grpc_codec.deserializer(GetDMSPayloadForNotificationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(GetDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsFolderComplianceStatus': grpc.unary_unary_rpc_method_handler(
          servicer.getDmsFolderComplianceStatus,
          request_deserializer=_grpc_codec.deserializer(GetDmsFolderComplianceStatusRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsFoldersWithNoStaffGroupId': grpc.unary_unary_rpc_method_handler(
          servicer.getDmsFoldersWithNoStaffGroupId,
          request_deserializer=_grpc_codec.deserializer(GetDmsFoldersWithNoStaffGroupIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getNextAction': grpc.unary_unary_rpc_method_handler(
          servicer.getNextAction,
          request_deserializer=_grpc_codec.deserializer(GetNextActionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPayloadInfoForCommunicationService': grpc.unary_unary_rpc_method_handler(
          servicer.getPayloadInfoForCommunicationService,
          request_deserializer=_grpc_codec.deserializer(GetPayloadInfoForCommunicationServiceRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPermittedDMSFolderIDs': grpc.unary_unary_rpc_method_handler(
          servicer.getPermittedDMSFolderIDs,
          request_deserializer=_grpc_codec.deserializer(GetPermittedDMSFolderIDsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPrincipalProfilesForTeam': grpc.unary_unary_rpc_method_handler(
          servicer.getPrincipalProfilesForTeam,
          request_deserializer=_grpc_codec.deserializer(GetPrincipalProfilesForTeamRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getStaticReferralChecklistItems': grpc.unary_unary_rpc_method_handler(
          servicer.getStaticReferralChecklistItems,
          request_deserializer=_grpc_codec.deserializer(GetStaticReferralChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamDmsFoldersMatchingLocation': grpc.unary_unary_rpc_method_handler(
          servicer.getTeamDmsFoldersMatchingLocation,
          request_deserializer=_grpc_codec.deserializer(GetTeamDmsFoldersMatchingLocationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          servicer.getUser,
          request_deserializer=_grpc_codec.deserializer(GetUserInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getWithdrawnDMSListings': grpc.unary_unary_rpc_method_handler(
          servicer.getWithdrawnDMSListings,
          request_deserializer=_grpc_codec.deserializer(GetWithdrawnDMSListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'internalGetDMSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.internalGetDMSFolders,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'sendNotificationsToKafka': grpc.unary_unary_rpc_method_handler(
          servicer.sendNotificationsToKafka,
          request_deserializer=_grpc_codec.deserializer(SendNotificationsToKafkaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setDMSContacts': grpc.unary_unary_rpc_method_handler(
          servicer.setDMSContacts,
          request_deserializer=_grpc_codec.deserializer(SetDMSContactsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'shareDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.shareDMSFolder,
          request_deserializer=_grpc_codec.deserializer(ShareDMSFolderInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'sortDmsFolders': grpc.unary_unary_rpc_method_handler(
          servicer.sortDmsFolders,
          request_deserializer=_grpc_codec.deserializer(SortDmsFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'splitDocument': grpc.unary_unary_rpc_method_handler(
          servicer.splitDocument,
          request_deserializer=_grpc_codec.deserializer(SplitDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unclaimDeal': grpc.unary_unary_rpc_method_handler(
          servicer.unclaimDeal,
          request_deserializer=_grpc_codec.deserializer(UnclaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unshareDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.unshareDMSFolder,
          request_deserializer=_grpc_codec.deserializer(UnshareDMSFolderInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateChecklistItem': grpc.unary_unary_rpc_method_handler(
          servicer.updateChecklistItem,
          request_deserializer=_grpc_codec.deserializer(UpdateChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosing': grpc.unary_unary_rpc_method_handler(
          servicer.updateClosing,
          request_deserializer=_grpc_codec.deserializer(UpdateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSAgentsForDualRep': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSAgentsForDualRep,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSAgentsForDualRepRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSFolder,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSListing,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSListingDocument': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSListingDocument,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSTransactionDocument': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSTransactionDocument,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSTransactionSubStageFromDC': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSTransactionSubStageFromDC,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSTransactionSubStageFromDCRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateReferralDetail': grpc.unary_unary_rpc_method_handler(
          servicer.updateReferralDetail,
          request_deserializer=_grpc_codec.deserializer(UpdateReferralDetailRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertCustomChecklistItemByItemId': grpc.unary_unary_rpc_method_handler(
          servicer.upsertCustomChecklistItemByItemId,
          request_deserializer=_grpc_codec.deserializer(UpsertCustomChecklistItemByItemIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.upsertDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(UpsertDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'validateOneField': grpc.unary_unary_rpc_method_handler(
          servicer.validateOneField,
          request_deserializer=_grpc_codec.deserializer(ValidateOneFieldRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsStateService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

