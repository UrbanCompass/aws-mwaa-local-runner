
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.values.ttypes

from thrift.transport import TTransport


class DrilldownOpenSettings(object):
    CURRENT_TAB = 0
    NEW_TAB = 1
    NEW_WINDOW = 2

    _VALUES_TO_NAMES = {
        0: "CURRENT_TAB",
        1: "NEW_TAB",
        2: "NEW_WINDOW",
    }

    _NAMES_TO_VALUES = {
        "CURRENT_TAB": 0,
        "NEW_TAB": 1,
        "NEW_WINDOW": 2,
    }


class DrilldownParameterFromConstant(object):
    """
    Attributes:
     - destinationParameterName
     - values
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'destinationParameterName', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'values', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar, gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, destinationParameterName=None, values=None, ):
        self.destinationParameterName = destinationParameterName
        self.values = values

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.destinationParameterName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar()
                        _elem4.read(iprot)
                        self.values.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrilldownParameterFromConstant')
        if self.destinationParameterName is not None:
            oprot.writeFieldBegin('destinationParameterName', TType.STRING, 1)
            oprot.writeString(self.destinationParameterName.encode('utf-8') if sys.version_info[0] == 2 else self.destinationParameterName)
            oprot.writeFieldEnd()
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.values))
            for _iter6 in self.values:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DrilldownParameterFromParameter(object):
    """
    Attributes:
     - sourceParameterName
     - destinationParameterName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'sourceParameterName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'destinationParameterName', 'UTF8', None, ),  # 2
    )
    def __init__(self, sourceParameterName=None, destinationParameterName=None, ):
        self.sourceParameterName = sourceParameterName
        self.destinationParameterName = destinationParameterName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.sourceParameterName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.destinationParameterName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrilldownParameterFromParameter')
        if self.sourceParameterName is not None:
            oprot.writeFieldBegin('sourceParameterName', TType.STRING, 1)
            oprot.writeString(self.sourceParameterName.encode('utf-8') if sys.version_info[0] == 2 else self.sourceParameterName)
            oprot.writeFieldEnd()
        if self.destinationParameterName is not None:
            oprot.writeFieldBegin('destinationParameterName', TType.STRING, 2)
            oprot.writeString(self.destinationParameterName.encode('utf-8') if sys.version_info[0] == 2 else self.destinationParameterName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DrilldownParameterFromSeriesRef(object):
    """
    Attributes:
     - destinationParameterName
     - ref
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'destinationParameterName', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'ref', (gen.urbancompass.bi.dashboard.data.series_ref.ttypes.SeriesRef, gen.urbancompass.bi.dashboard.data.series_ref.ttypes.SeriesRef.thrift_spec), None, ),  # 2
    )
    def __init__(self, destinationParameterName=None, ref=None, ):
        self.destinationParameterName = destinationParameterName
        self.ref = ref

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.destinationParameterName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.ref = gen.urbancompass.bi.dashboard.data.series_ref.ttypes.SeriesRef()
                    self.ref.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrilldownParameterFromSeriesRef')
        if self.destinationParameterName is not None:
            oprot.writeFieldBegin('destinationParameterName', TType.STRING, 1)
            oprot.writeString(self.destinationParameterName.encode('utf-8') if sys.version_info[0] == 2 else self.destinationParameterName)
            oprot.writeFieldEnd()
        if self.ref is not None:
            oprot.writeFieldBegin('ref', TType.STRUCT, 2)
            self.ref.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExternalURLDrilldown(object):
    """
    Attributes:
     - urlSeriesRef
     - openSettings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'urlSeriesRef', (gen.urbancompass.bi.dashboard.data.series_ref.ttypes.SeriesRef, gen.urbancompass.bi.dashboard.data.series_ref.ttypes.SeriesRef.thrift_spec), None, ),  # 1
        (2, TType.I32, 'openSettings', None, None, ),  # 2
    )
    def __init__(self, urlSeriesRef=None, openSettings=None, ):
        self.urlSeriesRef = urlSeriesRef
        self.openSettings = openSettings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.urlSeriesRef = gen.urbancompass.bi.dashboard.data.series_ref.ttypes.SeriesRef()
                    self.urlSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.openSettings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExternalURLDrilldown')
        if self.urlSeriesRef is not None:
            oprot.writeFieldBegin('urlSeriesRef', TType.STRUCT, 1)
            self.urlSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.openSettings is not None:
            oprot.writeFieldBegin('openSettings', TType.I32, 2)
            oprot.writeI32(self.openSettings)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DrilldownParameter(object):
    """
    Attributes:
     - forwardedParameter
     - constantParameter
     - seriesRefParameter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'forwardedParameter', (DrilldownParameterFromParameter, DrilldownParameterFromParameter.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'constantParameter', (DrilldownParameterFromConstant, DrilldownParameterFromConstant.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'seriesRefParameter', (DrilldownParameterFromSeriesRef, DrilldownParameterFromSeriesRef.thrift_spec), None, ),  # 3
    )
    def __init__(self, forwardedParameter=None, constantParameter=None, seriesRefParameter=None, ):
        self.forwardedParameter = forwardedParameter
        self.constantParameter = constantParameter
        self.seriesRefParameter = seriesRefParameter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.forwardedParameter = DrilldownParameterFromParameter()
                    self.forwardedParameter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.constantParameter = DrilldownParameterFromConstant()
                    self.constantParameter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.seriesRefParameter = DrilldownParameterFromSeriesRef()
                    self.seriesRefParameter.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrilldownParameter')
        if self.forwardedParameter is not None:
            oprot.writeFieldBegin('forwardedParameter', TType.STRUCT, 1)
            self.forwardedParameter.write(oprot)
            oprot.writeFieldEnd()
        if self.constantParameter is not None:
            oprot.writeFieldBegin('constantParameter', TType.STRUCT, 2)
            self.constantParameter.write(oprot)
            oprot.writeFieldEnd()
        if self.seriesRefParameter is not None:
            oprot.writeFieldBegin('seriesRefParameter', TType.STRUCT, 3)
            self.seriesRefParameter.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExternalDashboardDrilldown(object):
    """
    Attributes:
     - drilldownDashboardName
     - parameters
     - openSettings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'drilldownDashboardName', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'parameters', (TType.STRUCT, (DrilldownParameter, DrilldownParameter.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'openSettings', None, None, ),  # 3
    )
    def __init__(self, drilldownDashboardName=None, parameters=None, openSettings=None, ):
        self.drilldownDashboardName = drilldownDashboardName
        self.parameters = parameters
        self.openSettings = openSettings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.drilldownDashboardName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.parameters = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = DrilldownParameter()
                        _elem9.read(iprot)
                        self.parameters.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.openSettings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExternalDashboardDrilldown')
        if self.drilldownDashboardName is not None:
            oprot.writeFieldBegin('drilldownDashboardName', TType.STRING, 1)
            oprot.writeString(self.drilldownDashboardName.encode('utf-8') if sys.version_info[0] == 2 else self.drilldownDashboardName)
            oprot.writeFieldEnd()
        if self.parameters is not None:
            oprot.writeFieldBegin('parameters', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.parameters))
            for _iter11 in self.parameters:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.openSettings is not None:
            oprot.writeFieldBegin('openSettings', TType.I32, 3)
            oprot.writeI32(self.openSettings)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Drilldown(object):
    """
    Attributes:
     - externalDashboardDrilldown
     - externalURLDrilldown
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'externalDashboardDrilldown', (ExternalDashboardDrilldown, ExternalDashboardDrilldown.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'externalURLDrilldown', (ExternalURLDrilldown, ExternalURLDrilldown.thrift_spec), None, ),  # 2
    )
    def __init__(self, externalDashboardDrilldown=None, externalURLDrilldown=None, ):
        self.externalDashboardDrilldown = externalDashboardDrilldown
        self.externalURLDrilldown = externalURLDrilldown

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.externalDashboardDrilldown = ExternalDashboardDrilldown()
                    self.externalDashboardDrilldown.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.externalURLDrilldown = ExternalURLDrilldown()
                    self.externalURLDrilldown.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Drilldown')
        if self.externalDashboardDrilldown is not None:
            oprot.writeFieldBegin('externalDashboardDrilldown', TType.STRUCT, 1)
            self.externalDashboardDrilldown.write(oprot)
            oprot.writeFieldEnd()
        if self.externalURLDrilldown is not None:
            oprot.writeFieldBegin('externalURLDrilldown', TType.STRUCT, 2)
            self.externalURLDrilldown.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
