
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class COMPLIANCE_TYPES(object):
    BASE = 0
    VOW_LISTING_DISPLAY = 1
    MLS_LOGO_DISPLAY = 2
    VOW_ADDRESS_DISPLAY = 3
    NO_ADDRESS_FOR_LOGGED_OUT_USER_DEPRECATED = 4
    HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER = 5
    DUMMY_COMPLIANCE_PLACE_HOLDER = 6
    NO_ADDRESS_FOR_LOGGED_OUT_USER = 7

    _VALUES_TO_NAMES = {
        0: "BASE",
        1: "VOW_LISTING_DISPLAY",
        2: "MLS_LOGO_DISPLAY",
        3: "VOW_ADDRESS_DISPLAY",
        4: "NO_ADDRESS_FOR_LOGGED_OUT_USER_DEPRECATED",
        5: "HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER",
        6: "DUMMY_COMPLIANCE_PLACE_HOLDER",
        7: "NO_ADDRESS_FOR_LOGGED_OUT_USER",
    }

    _NAMES_TO_VALUES = {
        "BASE": 0,
        "VOW_LISTING_DISPLAY": 1,
        "MLS_LOGO_DISPLAY": 2,
        "VOW_ADDRESS_DISPLAY": 3,
        "NO_ADDRESS_FOR_LOGGED_OUT_USER_DEPRECATED": 4,
        "HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER": 5,
        "DUMMY_COMPLIANCE_PLACE_HOLDER": 6,
        "NO_ADDRESS_FOR_LOGGED_OUT_USER": 7,
    }

