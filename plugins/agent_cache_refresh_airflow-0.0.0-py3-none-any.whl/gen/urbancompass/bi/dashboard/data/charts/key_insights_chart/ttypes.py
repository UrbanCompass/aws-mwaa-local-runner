
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes

from thrift.transport import TTransport


class KeyInsightsCategory(object):
    TOP_LISTING_FOR_VIEWS = 0
    TOP_TRAFFIC_SOURCE_FOR_VISITORS = 1
    TOP_SOCIAL_TRAFFIC_FOR_VISITORS = 2
    VIEWS_FROM_NEW_VISITORS = 3
    VIEWS_FROM_MOBILE = 4
    AVERAGE_TIME_SPENT = 5
    TOP_COLLECTION_FOR_VIEWS = 6
    AD_VIEWINGS = 7
    ENGAGEMENT = 8
    BEST_VIEWING_DAY = 9
    TRAFFIC_LIFT = 10
    AD_PROGRESS = 11

    _VALUES_TO_NAMES = {
        0: "TOP_LISTING_FOR_VIEWS",
        1: "TOP_TRAFFIC_SOURCE_FOR_VISITORS",
        2: "TOP_SOCIAL_TRAFFIC_FOR_VISITORS",
        3: "VIEWS_FROM_NEW_VISITORS",
        4: "VIEWS_FROM_MOBILE",
        5: "AVERAGE_TIME_SPENT",
        6: "TOP_COLLECTION_FOR_VIEWS",
        7: "AD_VIEWINGS",
        8: "ENGAGEMENT",
        9: "BEST_VIEWING_DAY",
        10: "TRAFFIC_LIFT",
        11: "AD_PROGRESS",
    }

    _NAMES_TO_VALUES = {
        "TOP_LISTING_FOR_VIEWS": 0,
        "TOP_TRAFFIC_SOURCE_FOR_VISITORS": 1,
        "TOP_SOCIAL_TRAFFIC_FOR_VISITORS": 2,
        "VIEWS_FROM_NEW_VISITORS": 3,
        "VIEWS_FROM_MOBILE": 4,
        "AVERAGE_TIME_SPENT": 5,
        "TOP_COLLECTION_FOR_VIEWS": 6,
        "AD_VIEWINGS": 7,
        "ENGAGEMENT": 8,
        "BEST_VIEWING_DAY": 9,
        "TRAFFIC_LIFT": 10,
        "AD_PROGRESS": 11,
    }


class KeyInsight(object):
    """
    Attributes:
     - valueSeriesRef
     - sourceSeriesRef
     - category
     - iconId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'valueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'sourceSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
        (3, TType.I32, 'category', None, None, ),  # 3
        (4, TType.STRING, 'iconId', 'UTF8', None, ),  # 4
    )
    def __init__(self, valueSeriesRef=None, sourceSeriesRef=None, category=None, iconId=None, ):
        self.valueSeriesRef = valueSeriesRef
        self.sourceSeriesRef = sourceSeriesRef
        self.category = category
        self.iconId = iconId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.valueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.valueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.sourceSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.sourceSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.category = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.iconId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('KeyInsight')
        if self.valueSeriesRef is not None:
            oprot.writeFieldBegin('valueSeriesRef', TType.STRUCT, 1)
            self.valueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.sourceSeriesRef is not None:
            oprot.writeFieldBegin('sourceSeriesRef', TType.STRUCT, 2)
            self.sourceSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.category is not None:
            oprot.writeFieldBegin('category', TType.I32, 3)
            oprot.writeI32(self.category)
            oprot.writeFieldEnd()
        if self.iconId is not None:
            oprot.writeFieldBegin('iconId', TType.STRING, 4)
            oprot.writeString(self.iconId.encode('utf-8') if sys.version_info[0] == 2 else self.iconId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class KeyInsightsChart(object):
    """
    Attributes:
     - title
     - insights
     - pageName
     - description
     - icon
     - titleForReport
     - emptyView
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'insights', (TType.STRUCT, (KeyInsight, KeyInsight.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'pageName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'description', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'icon', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'titleForReport', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'emptyView', (gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView, gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView.thrift_spec), None, ),  # 7
    )
    def __init__(self, title=None, insights=None, pageName=None, description=None, icon=None, titleForReport=None, emptyView=None, ):
        self.title = title
        self.insights = insights
        self.pageName = pageName
        self.description = description
        self.icon = icon
        self.titleForReport = titleForReport
        self.emptyView = emptyView

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.insights = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = KeyInsight()
                        _elem4.read(iprot)
                        self.insights.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.pageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.icon = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.titleForReport = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.emptyView = gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView()
                    self.emptyView.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('KeyInsightsChart')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.insights is not None:
            oprot.writeFieldBegin('insights', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.insights))
            for _iter6 in self.insights:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.pageName is not None:
            oprot.writeFieldBegin('pageName', TType.STRING, 3)
            oprot.writeString(self.pageName.encode('utf-8') if sys.version_info[0] == 2 else self.pageName)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 4)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.icon is not None:
            oprot.writeFieldBegin('icon', TType.STRING, 5)
            oprot.writeString(self.icon.encode('utf-8') if sys.version_info[0] == 2 else self.icon)
            oprot.writeFieldEnd()
        if self.titleForReport is not None:
            oprot.writeFieldBegin('titleForReport', TType.STRING, 6)
            oprot.writeString(self.titleForReport.encode('utf-8') if sys.version_info[0] == 2 else self.titleForReport)
            oprot.writeFieldEnd()
        if self.emptyView is not None:
            oprot.writeFieldBegin('emptyView', TType.STRUCT, 7)
            self.emptyView.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
