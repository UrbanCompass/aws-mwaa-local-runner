
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes

from thrift.transport import TTransport


class Breadcrumb(object):
    """
    Attributes:
     - titleRef
     - descriptionRef
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'titleRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'descriptionRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
    )
    def __init__(self, titleRef=None, descriptionRef=None, ):
        self.titleRef = titleRef
        self.descriptionRef = descriptionRef

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.titleRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.titleRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.descriptionRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.descriptionRef.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Breadcrumb')
        if self.titleRef is not None:
            oprot.writeFieldBegin('titleRef', TType.STRUCT, 1)
            self.titleRef.write(oprot)
            oprot.writeFieldEnd()
        if self.descriptionRef is not None:
            oprot.writeFieldBegin('descriptionRef', TType.STRUCT, 2)
            self.descriptionRef.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BreadcrumbTrail(object):
    """
    Attributes:
     - breadcrumbs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'breadcrumbs', (TType.STRUCT, (Breadcrumb, Breadcrumb.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, breadcrumbs=None, ):
        self.breadcrumbs = breadcrumbs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.breadcrumbs = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = Breadcrumb()
                        _elem4.read(iprot)
                        self.breadcrumbs.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BreadcrumbTrail')
        if self.breadcrumbs is not None:
            oprot.writeFieldBegin('breadcrumbs', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.breadcrumbs))
            for _iter6 in self.breadcrumbs:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
