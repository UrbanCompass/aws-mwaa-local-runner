
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class DmsNotificationStatus(object):
    SENDING = 0
    SUCCESS = 1
    FAILED = 2
    PENDING = 3
    NOT_ELIGIBLE = 4
    TO_RETRY = 5

    _VALUES_TO_NAMES = {
        0: "SENDING",
        1: "SUCCESS",
        2: "FAILED",
        3: "PENDING",
        4: "NOT_ELIGIBLE",
        5: "TO_RETRY",
    }

    _NAMES_TO_VALUES = {
        "SENDING": 0,
        "SUCCESS": 1,
        "FAILED": 2,
        "PENDING": 3,
        "NOT_ELIGIBLE": 4,
        "TO_RETRY": 5,
    }


class DmsNotificationType(object):
    DOCUMENT_APPROVED = 0
    CLOSE_DATE_REACHED = 1
    READY_TO_SUBMIT = 2
    LISTING_CHECKLIST_ITEM_NOTE_ADDED = 3
    TRANSACTION_CHECKLIST_ITEM_NOTE_ADDED = 4
    CHECKLIST_ITEM_NOTE_AGGREGATE_TRIGGER = 5
    CHECKLIST_ITEM_NOTE_AGGREGATED = 6
    COMMISSION_REQUEST_REMINDER = 7
    CDA_COMMENT_ADDED = 8
    CDA_COMMENT_AGGREGATE_TRIGGER = 9
    CDA_COMMENT_AGGREGATED = 10

    _VALUES_TO_NAMES = {
        0: "DOCUMENT_APPROVED",
        1: "CLOSE_DATE_REACHED",
        2: "READY_TO_SUBMIT",
        3: "LISTING_CHECKLIST_ITEM_NOTE_ADDED",
        4: "TRANSACTION_CHECKLIST_ITEM_NOTE_ADDED",
        5: "CHECKLIST_ITEM_NOTE_AGGREGATE_TRIGGER",
        6: "CHECKLIST_ITEM_NOTE_AGGREGATED",
        7: "COMMISSION_REQUEST_REMINDER",
        8: "CDA_COMMENT_ADDED",
        9: "CDA_COMMENT_AGGREGATE_TRIGGER",
        10: "CDA_COMMENT_AGGREGATED",
    }

    _NAMES_TO_VALUES = {
        "DOCUMENT_APPROVED": 0,
        "CLOSE_DATE_REACHED": 1,
        "READY_TO_SUBMIT": 2,
        "LISTING_CHECKLIST_ITEM_NOTE_ADDED": 3,
        "TRANSACTION_CHECKLIST_ITEM_NOTE_ADDED": 4,
        "CHECKLIST_ITEM_NOTE_AGGREGATE_TRIGGER": 5,
        "CHECKLIST_ITEM_NOTE_AGGREGATED": 6,
        "COMMISSION_REQUEST_REMINDER": 7,
        "CDA_COMMENT_ADDED": 8,
        "CDA_COMMENT_AGGREGATE_TRIGGER": 9,
        "CDA_COMMENT_AGGREGATED": 10,
    }


class Template(object):
    CDA_DOC_GENERATION_NOTIFICATION = 0

    _VALUES_TO_NAMES = {
        0: "CDA_DOC_GENERATION_NOTIFICATION",
    }

    _NAMES_TO_VALUES = {
        "CDA_DOC_GENERATION_NOTIFICATION": 0,
    }


class DmsNotificationEventPayload(object):
    """
    Attributes:
     - id
     - payload
     - createdAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'payload', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
    )
    def __init__(self, id=None, payload=None, createdAt=None, ):
        self.id = id
        self.payload = payload
        self.createdAt = createdAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.payload = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsNotificationEventPayload')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.payload is not None:
            oprot.writeFieldBegin('payload', TType.STRING, 2)
            oprot.writeString(self.payload.encode('utf-8') if sys.version_info[0] == 2 else self.payload)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsNotificationRecipient(object):
    """
    Attributes:
     - id
     - payloadId
     - recipientId
     - email
     - notificationStatus
     - dmsFolderId
     - dmsNotificationType
     - createdAt
     - updatedAt
     - lastSentCloseDateNotification
     - notificationEntityKey
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.I64, 'payloadId', None, None, ),  # 2
        (3, TType.STRING, 'recipientId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.I32, 'notificationStatus', None, None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'dmsNotificationType', None, None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.I64, 'lastSentCloseDateNotification', None, None, ),  # 10
        (11, TType.STRING, 'notificationEntityKey', 'UTF8', None, ),  # 11
    )
    def __init__(self, id=None, payloadId=None, recipientId=None, email=None, notificationStatus=None, dmsFolderId=None, dmsNotificationType=None, createdAt=None, updatedAt=None, lastSentCloseDateNotification=None, notificationEntityKey=None, ):
        self.id = id
        self.payloadId = payloadId
        self.recipientId = recipientId
        self.email = email
        self.notificationStatus = notificationStatus
        self.dmsFolderId = dmsFolderId
        self.dmsNotificationType = dmsNotificationType
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.lastSentCloseDateNotification = lastSentCloseDateNotification
        self.notificationEntityKey = notificationEntityKey

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.payloadId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.notificationStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.dmsNotificationType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastSentCloseDateNotification = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.notificationEntityKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsNotificationRecipient')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.payloadId is not None:
            oprot.writeFieldBegin('payloadId', TType.I64, 2)
            oprot.writeI64(self.payloadId)
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 3)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.notificationStatus is not None:
            oprot.writeFieldBegin('notificationStatus', TType.I32, 5)
            oprot.writeI32(self.notificationStatus)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsNotificationType is not None:
            oprot.writeFieldBegin('dmsNotificationType', TType.I32, 7)
            oprot.writeI32(self.dmsNotificationType)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.lastSentCloseDateNotification is not None:
            oprot.writeFieldBegin('lastSentCloseDateNotification', TType.I64, 10)
            oprot.writeI64(self.lastSentCloseDateNotification)
            oprot.writeFieldEnd()
        if self.notificationEntityKey is not None:
            oprot.writeFieldBegin('notificationEntityKey', TType.STRING, 11)
            oprot.writeString(self.notificationEntityKey.encode('utf-8') if sys.version_info[0] == 2 else self.notificationEntityKey)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TemplateNotificationRecipient(object):
    """
    Attributes:
     - id
     - payloadId
     - recipientId
     - email
     - notificationStatus
     - dmsNotificationType
     - createdAt
     - updatedAt
     - notificationEntityKey
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.I64, 'payloadId', None, None, ),  # 2
        (3, TType.STRING, 'recipientId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.I32, 'notificationStatus', None, None, ),  # 5
        (6, TType.I32, 'dmsNotificationType', None, None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'updatedAt', None, None, ),  # 8
        (9, TType.STRING, 'notificationEntityKey', 'UTF8', None, ),  # 9
    )
    def __init__(self, id=None, payloadId=None, recipientId=None, email=None, notificationStatus=None, dmsNotificationType=None, createdAt=None, updatedAt=None, notificationEntityKey=None, ):
        self.id = id
        self.payloadId = payloadId
        self.recipientId = recipientId
        self.email = email
        self.notificationStatus = notificationStatus
        self.dmsNotificationType = dmsNotificationType
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.notificationEntityKey = notificationEntityKey

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.payloadId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.notificationStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.dmsNotificationType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.notificationEntityKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TemplateNotificationRecipient')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.payloadId is not None:
            oprot.writeFieldBegin('payloadId', TType.I64, 2)
            oprot.writeI64(self.payloadId)
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 3)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.notificationStatus is not None:
            oprot.writeFieldBegin('notificationStatus', TType.I32, 5)
            oprot.writeI32(self.notificationStatus)
            oprot.writeFieldEnd()
        if self.dmsNotificationType is not None:
            oprot.writeFieldBegin('dmsNotificationType', TType.I32, 6)
            oprot.writeI32(self.dmsNotificationType)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 8)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.notificationEntityKey is not None:
            oprot.writeFieldBegin('notificationEntityKey', TType.STRING, 9)
            oprot.writeString(self.notificationEntityKey.encode('utf-8') if sys.version_info[0] == 2 else self.notificationEntityKey)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
