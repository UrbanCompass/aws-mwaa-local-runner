# -*- coding: utf-8 -*-
"""
:copyright: (c) 2014 by Urban Compass, Inc.
"""

import logging


class Counter(object):
    """A simple counter.

    This class is not thread-safe
    """

    def __init__(self, name, reporters):
        """Create a counter that broadcasts its changes to a list of reporters."""
        self.name = name
        self.count = 0
        self._reporters = reporters

    def increment(self, delta=1):
        """Increment the counter with `delta`

        :keyword delta: The delta to add to the counter
        """
        self.count += delta
        for r in self._reporters:
            r.report_increment(delta, self.count)
        return self.count


class CounterReporter(object):
    """Interface for reporting a counter's effects."""

    def report_increment(self, delta, count):
        pass


class LoggingCounterReporter(CounterReporter):
    """
    A counter that sends its results to logging module
    :return:
    """

    def __init__(self, name, log_level="INFO"):
        self.name = name
        self._log_level = logging.getLevelName(log_level)

    def report_increment(self, delta, count):
        logging.log(self._log_level, "{}: {}".format(self.name, count))


class DatadogCounterReporter(CounterReporter):
    def __init__(self, name, client, tags=None):
        """
        :param name: counter name
        :type name: str

        :param client: properly initialized StatsD client
        :type client: base.dd_statsd.StatsD

        :param tags: tags to apply to the metric. Tag keys and values can't have spaces
        :type tags: dict[str,str]
        """
        self.metric_name = name
        self.statsd = client
        self.tags = tags

    def report_increment(self, delta, count):
        """Doesn't do anything with the count, only reports delta"""
        self.statsd.count(self.metric_name, delta, tags=self.tags)
