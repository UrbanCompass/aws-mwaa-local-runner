
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CLOSING_TO_DEAL_LISTING_TYPE = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
}
CLOSING_TO_DEAL_PROPERTY_TYPE = {
    0: 9,
    1: 9,
    2: 0,
    3: 1,
    4: 10,
    5: 6,
    6: 11,
    7: 7,
    8: 3,
    9: 5,
    10: 2,
    11: 4,
    12: 7,
    13: 7,
}
CLOSING_TO_DEAL_SPLIT_OVERRIDE_REASON = {
    0: 1,
    1: 2,
    2: 3,
    3: 4,
    4: 5,
    5: 6,
    6: 7,
    9999: 0,
}
DEAL_TO_CLOSING_LISTING_TYPE = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
}
DEAL_TO_CLOSING_PROPERTY_TYPE = {
    9: 0,
    0: 2,
    1: 3,
    10: 4,
    6: 5,
    11: 6,
    3: 8,
    5: 9,
    2: 10,
    4: 11,
    7: 12,
    8: 13,
}
DEAL_TO_CLOSING_SPLIT_OVERRIDE_REASON = {
    1: 0,
    2: 1,
    3: 2,
    4: 3,
    5: 4,
    6: 5,
    7: 6,
    0: 9999,
}
PROPERTY_TYPE_TO_LISTING_TYPE = {
    0: 0,
    7: 2,
    8: 2,
}
