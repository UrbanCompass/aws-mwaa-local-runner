
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class VerificationFlag(object):
    RELIABLE = 0
    UNAVAILABLE = 1
    NOT_SURE = 2

    _VALUES_TO_NAMES = {
        0: "RELIABLE",
        1: "UNAVAILABLE",
        2: "NOT_SURE",
    }

    _NAMES_TO_VALUES = {
        "RELIABLE": 0,
        "UNAVAILABLE": 1,
        "NOT_SURE": 2,
    }


class ContactEmailAddress(object):
    """
    Attributes:
     - id
     - label
     - address
     - source
     - verificationFlag
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'address', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'source', 'UTF8', None, ),  # 4
        (5, TType.I32, 'verificationFlag', None, None, ),  # 5
    )
    def __init__(self, id=None, label=None, address=None, source=None, verificationFlag=None, ):
        self.id = id
        self.label = label
        self.address = address
        self.source = source
        self.verificationFlag = verificationFlag

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.verificationFlag = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactEmailAddress')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 3)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 4)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        if self.verificationFlag is not None:
            oprot.writeFieldBegin('verificationFlag', TType.I32, 5)
            oprot.writeI32(self.verificationFlag)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactMobileIdentifier(object):
    """
    Attributes:
     - id
     - label
     - remoteId
     - source
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'remoteId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'source', 'UTF8', None, ),  # 4
    )
    def __init__(self, id=None, label=None, remoteId=None, source=None, ):
        self.id = id
        self.label = label
        self.remoteId = remoteId
        self.source = source

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.remoteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactMobileIdentifier')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.remoteId is not None:
            oprot.writeFieldBegin('remoteId', TType.STRING, 3)
            oprot.writeString(self.remoteId.encode('utf-8') if sys.version_info[0] == 2 else self.remoteId)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 4)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactPhoneNumber(object):
    """
    Attributes:
     - id
     - label
     - number
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'number', 'UTF8', None, ),  # 3
    )
    def __init__(self, id=None, label=None, number=None, ):
        self.id = id
        self.label = label
        self.number = number

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.number = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactPhoneNumber')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.number is not None:
            oprot.writeFieldBegin('number', TType.STRING, 3)
            oprot.writeString(self.number.encode('utf-8') if sys.version_info[0] == 2 else self.number)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShallowContact(object):
    """
    Attributes:
     - id
     - personId
     - createdAt
     - updatedAt
     - archivedAt
     - firstName
     - lastName
     - emailAddresses
     - avatarUrl
     - lastActive
     - lastContacted
     - phoneNumbers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'personId', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.I64, 'archivedAt', None, None, ),  # 5
        (6, TType.STRING, 'firstName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'lastName', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'emailAddresses', (TType.STRUCT, (ContactEmailAddress, ContactEmailAddress.thrift_spec), False), None, ),  # 8
        (9, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 9
        (10, TType.I64, 'lastActive', None, None, ),  # 10
        (11, TType.I64, 'lastContacted', None, None, ),  # 11
        (12, TType.LIST, 'phoneNumbers', (TType.STRUCT, (ContactPhoneNumber, ContactPhoneNumber.thrift_spec), False), None, ),  # 12
    )
    def __init__(self, id=None, personId=None, createdAt=None, updatedAt=None, archivedAt=None, firstName=None, lastName=None, emailAddresses=None, avatarUrl=None, lastActive=None, lastContacted=None, phoneNumbers=None, ):
        self.id = id
        self.personId = personId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.archivedAt = archivedAt
        self.firstName = firstName
        self.lastName = lastName
        self.emailAddresses = emailAddresses
        self.avatarUrl = avatarUrl
        self.lastActive = lastActive
        self.lastContacted = lastContacted
        self.phoneNumbers = phoneNumbers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.archivedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.emailAddresses = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = ContactEmailAddress()
                        _elem4.read(iprot)
                        self.emailAddresses.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastActive = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.lastContacted = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.phoneNumbers = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = ContactPhoneNumber()
                        _elem8.read(iprot)
                        self.phoneNumbers.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShallowContact')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 2)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.archivedAt is not None:
            oprot.writeFieldBegin('archivedAt', TType.I64, 5)
            oprot.writeI64(self.archivedAt)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 6)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 7)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.emailAddresses is not None:
            oprot.writeFieldBegin('emailAddresses', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.emailAddresses))
            for _iter10 in self.emailAddresses:
                _iter10.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 9)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.lastActive is not None:
            oprot.writeFieldBegin('lastActive', TType.I64, 10)
            oprot.writeI64(self.lastActive)
            oprot.writeFieldEnd()
        if self.lastContacted is not None:
            oprot.writeFieldBegin('lastContacted', TType.I64, 11)
            oprot.writeI64(self.lastContacted)
            oprot.writeFieldEnd()
        if self.phoneNumbers is not None:
            oprot.writeFieldBegin('phoneNumbers', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.phoneNumbers))
            for _iter11 in self.phoneNumbers:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
