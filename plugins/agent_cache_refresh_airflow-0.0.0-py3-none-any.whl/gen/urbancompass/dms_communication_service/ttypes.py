
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.dms_common.dms_communication.ttypes
import gen.urbancompass.dms_communication_model.ttypes
import gen.urbancompass.dms_document.ttypes
import gen.urbancompass.dms_common.dms_folder.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.dms_state_model.ttypes

from thrift.transport import TTransport


class GetEventPayloadsForFolderRequest(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetEventPayloadsForFolderRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ProfileName(object):
    """
    Attributes:
     - firstName
     - lastName
     - displayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'firstName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'lastName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'displayName', 'UTF8', None, ),  # 3
    )
    def __init__(self, firstName=None, lastName=None, displayName=None, ):
        self.firstName = firstName
        self.lastName = lastName
        self.displayName = displayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ProfileName')
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 1)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 2)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 3)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TriggerCommunicationServiceRequest(object):
    """
    Attributes:
     - clientType
     - recipientIds
     - dmsFolderId
     - dmsFolderName
     - eventType
     - resourceType
     - resourceId
     - resourceName
     - resourceStatus
     - operatorId
     - operatedAt
     - note
     - needToBeSent
     - stateCode
     - stage
     - prevValue
     - newValue
     - recipientId
     - checklistItemNameToPages
     - listDate
     - dmsTransaction
     - impersonatorId
     - forDeleted
     - dmsListingId
     - dmsTransactionId
     - dmsListing
     - checklistItemName
     - notificationType
     - dmsAgentCommunicationInfo
     - dmsClientCommunicationInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'clientType', None, None, ),  # 1
        (2, TType.LIST, 'recipientIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsFolderName', 'UTF8', None, ),  # 4
        (5, TType.I32, 'eventType', None, None, ),  # 5
        (6, TType.I32, 'resourceType', None, None, ),  # 6
        (7, TType.STRING, 'resourceId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'resourceName', 'UTF8', None, ),  # 8
        (9, TType.I32, 'resourceStatus', None, None, ),  # 9
        (10, TType.STRING, 'operatorId', 'UTF8', None, ),  # 10
        (11, TType.I64, 'operatedAt', None, None, ),  # 11
        (12, TType.STRING, 'note', 'UTF8', None, ),  # 12
        (13, TType.BOOL, 'needToBeSent', None, None, ),  # 13
        (14, TType.I32, 'stateCode', None, None, ),  # 14
        (15, TType.I32, 'stage', None, None, ),  # 15
        (16, TType.STRING, 'prevValue', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'newValue', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'recipientId', 'UTF8', None, ),  # 18
        (19, TType.MAP, 'checklistItemNameToPages', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.dms_document.ttypes.PageInterval, gen.urbancompass.dms_document.ttypes.PageInterval.thrift_spec), False), None, ),  # 19
        (20, TType.I64, 'listDate', None, None, ),  # 20
        (21, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_state_model.ttypes.DmsTransaction, gen.urbancompass.dms_state_model.ttypes.DmsTransaction.thrift_spec), None, ),  # 21
        (22, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 22
        (23, TType.BOOL, 'forDeleted', None, None, ),  # 23
        (24, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 25
        (26, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_state_model.ttypes.DmsListing, gen.urbancompass.dms_state_model.ttypes.DmsListing.thrift_spec), None, ),  # 26
        (27, TType.STRING, 'checklistItemName', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'notificationType', 'UTF8', None, ),  # 28
        (29, TType.STRUCT, 'dmsAgentCommunicationInfo', (gen.urbancompass.dms_communication_model.ttypes.DmsAgentCommunicationInfo, gen.urbancompass.dms_communication_model.ttypes.DmsAgentCommunicationInfo.thrift_spec), None, ),  # 29
        (30, TType.STRUCT, 'dmsClientCommunicationInfo', (gen.urbancompass.dms_communication_model.ttypes.DmsClientCommunicationInfo, gen.urbancompass.dms_communication_model.ttypes.DmsClientCommunicationInfo.thrift_spec), None, ),  # 30
    )
    def __init__(self, clientType=None, recipientIds=None, dmsFolderId=None, dmsFolderName=None, eventType=None, resourceType=None, resourceId=None, resourceName=None, resourceStatus=None, operatorId=None, operatedAt=None, note=None, needToBeSent=None, stateCode=None, stage=None, prevValue=None, newValue=None, recipientId=None, checklistItemNameToPages=None, listDate=None, dmsTransaction=None, impersonatorId=None, forDeleted=None, dmsListingId=None, dmsTransactionId=None, dmsListing=None, checklistItemName=None, notificationType=None, dmsAgentCommunicationInfo=None, dmsClientCommunicationInfo=None, ):
        self.clientType = clientType
        self.recipientIds = recipientIds
        self.dmsFolderId = dmsFolderId
        self.dmsFolderName = dmsFolderName
        self.eventType = eventType
        self.resourceType = resourceType
        self.resourceId = resourceId
        self.resourceName = resourceName
        self.resourceStatus = resourceStatus
        self.operatorId = operatorId
        self.operatedAt = operatedAt
        self.note = note
        self.needToBeSent = needToBeSent
        self.stateCode = stateCode
        self.stage = stage
        self.prevValue = prevValue
        self.newValue = newValue
        self.recipientId = recipientId
        self.checklistItemNameToPages = checklistItemNameToPages
        self.listDate = listDate
        self.dmsTransaction = dmsTransaction
        self.impersonatorId = impersonatorId
        self.forDeleted = forDeleted
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.dmsListing = dmsListing
        self.checklistItemName = checklistItemName
        self.notificationType = notificationType
        self.dmsAgentCommunicationInfo = dmsAgentCommunicationInfo
        self.dmsClientCommunicationInfo = dmsClientCommunicationInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.clientType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.recipientIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.recipientIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsFolderName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.eventType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.resourceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.resourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.resourceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.resourceStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.operatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.operatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.needToBeSent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.stateCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.prevValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.newValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.recipientId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.MAP:
                    self.checklistItemNameToPages = {}
                    (_ktype7, _vtype8, _size11) = iprot.readMapBegin()
                    for _i6 in range(_size11):
                        _key9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val10 = gen.urbancompass.dms_document.ttypes.PageInterval()
                        _val10.read(iprot)
                        self.checklistItemNameToPages[_key9] = _val10
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_state_model.ttypes.DmsTransaction()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.forDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_state_model.ttypes.DmsListing()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.checklistItemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.notificationType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRUCT:
                    self.dmsAgentCommunicationInfo = gen.urbancompass.dms_communication_model.ttypes.DmsAgentCommunicationInfo()
                    self.dmsAgentCommunicationInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.dmsClientCommunicationInfo = gen.urbancompass.dms_communication_model.ttypes.DmsClientCommunicationInfo()
                    self.dmsClientCommunicationInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TriggerCommunicationServiceRequest')
        if self.clientType is not None:
            oprot.writeFieldBegin('clientType', TType.I32, 1)
            oprot.writeI32(self.clientType)
            oprot.writeFieldEnd()
        if self.recipientIds is not None:
            oprot.writeFieldBegin('recipientIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.recipientIds))
            for _iter12 in self.recipientIds:
                oprot.writeString(_iter12.encode('utf-8') if sys.version_info[0] == 2 else _iter12)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsFolderName is not None:
            oprot.writeFieldBegin('dmsFolderName', TType.STRING, 4)
            oprot.writeString(self.dmsFolderName.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderName)
            oprot.writeFieldEnd()
        if self.eventType is not None:
            oprot.writeFieldBegin('eventType', TType.I32, 5)
            oprot.writeI32(self.eventType)
            oprot.writeFieldEnd()
        if self.resourceType is not None:
            oprot.writeFieldBegin('resourceType', TType.I32, 6)
            oprot.writeI32(self.resourceType)
            oprot.writeFieldEnd()
        if self.resourceId is not None:
            oprot.writeFieldBegin('resourceId', TType.STRING, 7)
            oprot.writeString(self.resourceId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceId)
            oprot.writeFieldEnd()
        if self.resourceName is not None:
            oprot.writeFieldBegin('resourceName', TType.STRING, 8)
            oprot.writeString(self.resourceName.encode('utf-8') if sys.version_info[0] == 2 else self.resourceName)
            oprot.writeFieldEnd()
        if self.resourceStatus is not None:
            oprot.writeFieldBegin('resourceStatus', TType.I32, 9)
            oprot.writeI32(self.resourceStatus)
            oprot.writeFieldEnd()
        if self.operatorId is not None:
            oprot.writeFieldBegin('operatorId', TType.STRING, 10)
            oprot.writeString(self.operatorId.encode('utf-8') if sys.version_info[0] == 2 else self.operatorId)
            oprot.writeFieldEnd()
        if self.operatedAt is not None:
            oprot.writeFieldBegin('operatedAt', TType.I64, 11)
            oprot.writeI64(self.operatedAt)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 12)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.needToBeSent is not None:
            oprot.writeFieldBegin('needToBeSent', TType.BOOL, 13)
            oprot.writeBool(self.needToBeSent)
            oprot.writeFieldEnd()
        if self.stateCode is not None:
            oprot.writeFieldBegin('stateCode', TType.I32, 14)
            oprot.writeI32(self.stateCode)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 15)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.prevValue is not None:
            oprot.writeFieldBegin('prevValue', TType.STRING, 16)
            oprot.writeString(self.prevValue.encode('utf-8') if sys.version_info[0] == 2 else self.prevValue)
            oprot.writeFieldEnd()
        if self.newValue is not None:
            oprot.writeFieldBegin('newValue', TType.STRING, 17)
            oprot.writeString(self.newValue.encode('utf-8') if sys.version_info[0] == 2 else self.newValue)
            oprot.writeFieldEnd()
        if self.recipientId is not None:
            oprot.writeFieldBegin('recipientId', TType.STRING, 18)
            oprot.writeString(self.recipientId.encode('utf-8') if sys.version_info[0] == 2 else self.recipientId)
            oprot.writeFieldEnd()
        if self.checklistItemNameToPages is not None:
            oprot.writeFieldBegin('checklistItemNameToPages', TType.MAP, 19)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.checklistItemNameToPages))
            for _kiter13, _viter14 in self.checklistItemNameToPages.items():
                oprot.writeString(_kiter13.encode('utf-8') if sys.version_info[0] == 2 else _kiter13)
                _viter14.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 20)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 21)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 22)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.forDeleted is not None:
            oprot.writeFieldBegin('forDeleted', TType.BOOL, 23)
            oprot.writeBool(self.forDeleted)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 24)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 25)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 26)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItemName is not None:
            oprot.writeFieldBegin('checklistItemName', TType.STRING, 27)
            oprot.writeString(self.checklistItemName.encode('utf-8') if sys.version_info[0] == 2 else self.checklistItemName)
            oprot.writeFieldEnd()
        if self.notificationType is not None:
            oprot.writeFieldBegin('notificationType', TType.STRING, 28)
            oprot.writeString(self.notificationType.encode('utf-8') if sys.version_info[0] == 2 else self.notificationType)
            oprot.writeFieldEnd()
        if self.dmsAgentCommunicationInfo is not None:
            oprot.writeFieldBegin('dmsAgentCommunicationInfo', TType.STRUCT, 29)
            self.dmsAgentCommunicationInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsClientCommunicationInfo is not None:
            oprot.writeFieldBegin('dmsClientCommunicationInfo', TType.STRUCT, 30)
            self.dmsClientCommunicationInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TriggerCommunicationServiceResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TriggerCommunicationServiceResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TriggerDailyDigestRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TriggerDailyDigestRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TriggerDailyDigestResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TriggerDailyDigestResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetEventPayloadsForFolderResponse(object):
    """
    Attributes:
     - status
     - eventPayloads
     - profileNamePayload
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'eventPayloads', (TType.STRUCT, (gen.urbancompass.dms_communication_model.ttypes.CommunicationEventPayload, gen.urbancompass.dms_communication_model.ttypes.CommunicationEventPayload.thrift_spec), False), None, ),  # 2
        (3, TType.MAP, 'profileNamePayload', (TType.STRING, 'UTF8', TType.STRUCT, (ProfileName, ProfileName.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, eventPayloads=None, profileNamePayload=None, ):
        self.status = status
        self.eventPayloads = eventPayloads
        self.profileNamePayload = profileNamePayload

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.eventPayloads = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = gen.urbancompass.dms_communication_model.ttypes.CommunicationEventPayload()
                        _elem17.read(iprot)
                        self.eventPayloads.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.profileNamePayload = {}
                    (_ktype20, _vtype21, _size24) = iprot.readMapBegin()
                    for _i19 in range(_size24):
                        _key22 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val23 = ProfileName()
                        _val23.read(iprot)
                        self.profileNamePayload[_key22] = _val23
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetEventPayloadsForFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.eventPayloads is not None:
            oprot.writeFieldBegin('eventPayloads', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.eventPayloads))
            for _iter25 in self.eventPayloads:
                _iter25.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.profileNamePayload is not None:
            oprot.writeFieldBegin('profileNamePayload', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.profileNamePayload))
            for _kiter26, _viter27 in self.profileNamePayload.items():
                oprot.writeString(_kiter26.encode('utf-8') if sys.version_info[0] == 2 else _kiter26)
                _viter27.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
