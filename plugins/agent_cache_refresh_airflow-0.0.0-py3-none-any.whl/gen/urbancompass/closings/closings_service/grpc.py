# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes as deals_workflow_model
import gen.urbancompass.dms_common.dms_listing.ttypes as dms_listing
import gen.urbancompass.listing.listing.ttypes as listing
import uc.grpc.codec as _grpc_codec



class ClosingsServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.batchGetClosingsForDms = channel.unary_unary(
        '/ClosingsService/batchGetClosingsForDms',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetClosingsForDmsResponse),
        )
    self.calculateCommissionsAndAllocations = channel.unary_unary(
        '/ClosingsService/calculateCommissionsAndAllocations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateClosingResponse),
        )
    self.checkClosingsUnderReview = channel.unary_unary(
        '/ClosingsService/checkClosingsUnderReview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckClosingsUnderReviewResponse),
        )
    self.checkWithNetsuite = channel.unary_unary(
        '/ClosingsService/checkWithNetsuite',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckWithNetsuiteResponse),
        )
    self.checkWithNetsuiteVendorBills = channel.unary_unary(
        '/ClosingsService/checkWithNetsuiteVendorBills',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckWithNetsuiteResponse),
        )
    self.createClosing = channel.unary_unary(
        '/ClosingsService/createClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateClosingResponse),
        )
    self.deleteDraft = channel.unary_unary(
        '/ClosingsService/deleteDraft',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateClosingResponse),
        )
    self.filterSubmittedClosings = channel.unary_unary(
        '/ClosingsService/filterSubmittedClosings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FilterSubmittedClosingsResponse),
        )
    self.getAgentSplit = channel.unary_unary(
        '/ClosingsService/getAgentSplit',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAgentSplitResponse),
        )
    self.getClosing = channel.unary_unary(
        '/ClosingsService/getClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetClosingResponse),
        )
    self.getClosingForDms = channel.unary_unary(
        '/ClosingsService/getClosingForDms',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetClosingResponse),
        )
    self.getUser = channel.unary_unary(
        '/ClosingsService/getUser',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetUserResponse),
        )
    self.listClosings = channel.unary_unary(
        '/ClosingsService/listClosings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ClosingListResponse),
        )
    self.listInContractClosings = channel.unary_unary(
        '/ClosingsService/listInContractClosings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ClosingListResponse),
        )
    self.listSubmittedClosings = channel.unary_unary(
        '/ClosingsService/listSubmittedClosings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ClosingListResponse),
        )
    self.manuallyCreateDealViaDws = channel.unary_unary(
        '/ClosingsService/manuallyCreateDealViaDws',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ManuallyCreateDealViaDwsResponse),
        )
    self.resendFailedNotification = channel.unary_unary(
        '/ClosingsService/resendFailedNotification',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ResendFailedNotificationResponse),
        )
    self.resubmitSubmittedClosing = channel.unary_unary(
        '/ClosingsService/resubmitSubmittedClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ResubmitSubmittedClosingResponse),
        )
    self.updateClosing = channel.unary_unary(
        '/ClosingsService/updateClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateClosingResponse),
        )
    self.validateOneField = channel.unary_unary(
        '/ClosingsService/validateOneField',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ValidateOneFieldResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class ClosingsServiceServicer(BaseServiceServicer):
  """
    The ClosingsService Service definition
  """

  def batchGetClosingsForDms(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def calculateCommissionsAndAllocations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkClosingsUnderReview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkWithNetsuite(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkWithNetsuiteVendorBills(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDraft(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def filterSubmittedClosings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentSplit(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getClosingForDms(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUser(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def listClosings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def listInContractClosings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def listSubmittedClosings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def manuallyCreateDealViaDws(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def resendFailedNotification(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def resubmitSubmittedClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def validateOneField(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_ClosingsServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'batchGetClosingsForDms': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetClosingsForDms(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetClosingsForDmsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionsAndAllocations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.calculateCommissionsAndAllocations(req),
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkClosingsUnderReview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkClosingsUnderReview(req),
          request_deserializer=_grpc_codec.deserializer(CheckClosingsUnderReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkWithNetsuite': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkWithNetsuite(req),
          request_deserializer=_grpc_codec.deserializer(CheckWithNetsuiteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkWithNetsuiteVendorBills': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkWithNetsuiteVendorBills(req),
          request_deserializer=_grpc_codec.deserializer(CheckWithNetsuiteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createClosing(req),
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDraft': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDraft(req),
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterSubmittedClosings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.filterSubmittedClosings(req),
          request_deserializer=_grpc_codec.deserializer(FilterSubmittedClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentSplit': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentSplit(req),
          request_deserializer=_grpc_codec.deserializer(GetAgentSplitRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getClosing(req),
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosingForDms': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getClosingForDms(req),
          request_deserializer=_grpc_codec.deserializer(GetClosingForDmsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUser(req),
          request_deserializer=_grpc_codec.deserializer(GetUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listClosings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.listClosings(req),
          request_deserializer=_grpc_codec.deserializer(ListClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listInContractClosings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.listInContractClosings(req),
          request_deserializer=_grpc_codec.deserializer(ListInContractClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listSubmittedClosings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.listSubmittedClosings(req),
          request_deserializer=_grpc_codec.deserializer(ListSubmittedClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'manuallyCreateDealViaDws': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.manuallyCreateDealViaDws(req),
          request_deserializer=_grpc_codec.deserializer(ManuallyCreateDealViaDwsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'resendFailedNotification': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.resendFailedNotification(req),
          request_deserializer=_grpc_codec.deserializer(ResendFailedNotificationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'resubmitSubmittedClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.resubmitSubmittedClosing(req),
          request_deserializer=_grpc_codec.deserializer(ResubmitSubmittedClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateClosing(req),
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'validateOneField': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.validateOneField(req),
          request_deserializer=_grpc_codec.deserializer(ValidateOneFieldRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'ClosingsService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_ClosingsServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'batchGetClosingsForDms': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetClosingsForDms,
          request_deserializer=_grpc_codec.deserializer(BatchGetClosingsForDmsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionsAndAllocations': grpc.unary_unary_rpc_method_handler(
          servicer.calculateCommissionsAndAllocations,
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkClosingsUnderReview': grpc.unary_unary_rpc_method_handler(
          servicer.checkClosingsUnderReview,
          request_deserializer=_grpc_codec.deserializer(CheckClosingsUnderReviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkWithNetsuite': grpc.unary_unary_rpc_method_handler(
          servicer.checkWithNetsuite,
          request_deserializer=_grpc_codec.deserializer(CheckWithNetsuiteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkWithNetsuiteVendorBills': grpc.unary_unary_rpc_method_handler(
          servicer.checkWithNetsuiteVendorBills,
          request_deserializer=_grpc_codec.deserializer(CheckWithNetsuiteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createClosing': grpc.unary_unary_rpc_method_handler(
          servicer.createClosing,
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDraft': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDraft,
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterSubmittedClosings': grpc.unary_unary_rpc_method_handler(
          servicer.filterSubmittedClosings,
          request_deserializer=_grpc_codec.deserializer(FilterSubmittedClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentSplit': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentSplit,
          request_deserializer=_grpc_codec.deserializer(GetAgentSplitRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosing': grpc.unary_unary_rpc_method_handler(
          servicer.getClosing,
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosingForDms': grpc.unary_unary_rpc_method_handler(
          servicer.getClosingForDms,
          request_deserializer=_grpc_codec.deserializer(GetClosingForDmsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          servicer.getUser,
          request_deserializer=_grpc_codec.deserializer(GetUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listClosings': grpc.unary_unary_rpc_method_handler(
          servicer.listClosings,
          request_deserializer=_grpc_codec.deserializer(ListClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listInContractClosings': grpc.unary_unary_rpc_method_handler(
          servicer.listInContractClosings,
          request_deserializer=_grpc_codec.deserializer(ListInContractClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listSubmittedClosings': grpc.unary_unary_rpc_method_handler(
          servicer.listSubmittedClosings,
          request_deserializer=_grpc_codec.deserializer(ListSubmittedClosingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'manuallyCreateDealViaDws': grpc.unary_unary_rpc_method_handler(
          servicer.manuallyCreateDealViaDws,
          request_deserializer=_grpc_codec.deserializer(ManuallyCreateDealViaDwsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'resendFailedNotification': grpc.unary_unary_rpc_method_handler(
          servicer.resendFailedNotification,
          request_deserializer=_grpc_codec.deserializer(ResendFailedNotificationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'resubmitSubmittedClosing': grpc.unary_unary_rpc_method_handler(
          servicer.resubmitSubmittedClosing,
          request_deserializer=_grpc_codec.deserializer(ResubmitSubmittedClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosing': grpc.unary_unary_rpc_method_handler(
          servicer.updateClosing,
          request_deserializer=_grpc_codec.deserializer(ClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'validateOneField': grpc.unary_unary_rpc_method_handler(
          servicer.validateOneField,
          request_deserializer=_grpc_codec.deserializer(ValidateOneFieldRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'ClosingsService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

