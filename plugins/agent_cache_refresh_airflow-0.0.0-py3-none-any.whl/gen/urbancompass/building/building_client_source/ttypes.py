
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class BuildingClientSource(object):
    BUILDING_EDITOR = 0
    BUILDING_PREVIEW_BATCH_PUBLISH = 1

    _VALUES_TO_NAMES = {
        0: "BUILDING_EDITOR",
        1: "BUILDING_PREVIEW_BATCH_PUBLISH",
    }

    _NAMES_TO_VALUES = {
        "BUILDING_EDITOR": 0,
        "BUILDING_PREVIEW_BATCH_PUBLISH": 1,
    }

