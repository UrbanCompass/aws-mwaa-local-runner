# -*- coding: utf-8 -*-
"""
:copyright: (c) 2012 by Urban Compass, Inc.

Our app class.

Standard usage is:

import uc.app

def add_args(parser):
  # add app-specific arguments to the parser

def main(options, args):
  # do stuff

if __name__ == '__main__':
  add_args(uc.app.parser)
  uc.app.run(main)
"""
import argparse
import cProfile
import errno
import logging
import os
import signal
import sys

from uc.base import uc_logging
from uc.base.app.dump_threads import dump_threads
from uc.base.app.secret_arguments import read_secrets_into_parsed_namespace

# A global ref to the options that have been parsed in parse_args.
OPTIONS = None


class Error(Exception):
    pass


def create_parser():
    parser = argparse.ArgumentParser(fromfile_prefix_chars="@")
    add_args(parser)
    return parser


def add_args(parser):
    """Add arguments to a parser.

    This is automatically called at import time on the global parser.
    """
    # keep all positional arguments untouched in options.args as a list of string.
    parser.add_argument("args", nargs="*", help=argparse.SUPPRESS)
    parser.add_argument(
        "--app_profile_output", default=None, type=str, help="Filename for profiling output"
    )
    parser.add_argument(
        "--app_name",
        default="default",
        help="Name of the application, for identification downstream",
    )
    parser.add_argument(
        "--app_host", default="development.localhost", help="Host where the app is running"
    )
    parser.add_argument(
        "--base_app_assume_role",
        required=False,
        default=None,
        help="ARN of AWS IAM role to assume via which to access resources",
    )
    parser.add_argument(
        "--instance_purpose", help="Purpose of the instance where the app is running"
    )
    parser.add_argument(
        "--instance_id", help="AWS instance id of the instance where the app is running"
    )
    parser.add_argument("--env", default="default", help="Environment this job is configured for")
    parser.add_argument(
        "--dump_threads_on_main_exit",
        default=False,
        action="store_true",
        help="Dump the currently running threads before exiting from the main.",
    )
    uc_logging.add_args(parser)


parser = create_parser()


def parse_args(*args, **kwargs):
    """Initialize app.options from a command line.

    Takes the same arguments as argparse.ArgumentParser.parse_args
    In particular, parse_args() will parse sys.args, while parse_args([]) will
    use all the default values.
    """
    global OPTIONS
    options = parser.parse_args(*args, **kwargs)
    read_secrets_into_parsed_namespace(options)
    OPTIONS = options
    return options


def _add_shutdown_handler(some_sig):
    """Registers a handler that exits gracefully.  We want this because we want to be able
    to tell the difference (via exit code) between restarts triggered manually during deploys, and
    actual app failures.

    Note that the handler is also responsible for sending the signal to all of the child processes as
    well.
    """

    def handler(_ignored_signum, _ignored_frame):
        if os.getpid() == os.getpgid(os.getpid()):
            previous = signal.signal(some_sig, signal.SIG_IGN)
            os.killpg(0, some_sig)  # Sends signal to all child process with this PGID
            signal.signal(some_sig, previous)
        sys.exit(0)

    signal.signal(some_sig, handler)
    if os.getpid() != os.getsid(0):
        # This process is not a session leader, so set the process group id for all child
        # processes to this PID
        try:
            os.setpgid(0, 0)
        except OSError as e:
            code = errno.errorcode.get(e.args[0])
            if code is not None:
                print(("ERROR %s(%s) in setpgid" % (e, code)))
            raise


def _add_dump_threads_handler(some_sig):
    """Registers a handler that dumps all the threads stack.

    We use this so that kill -3 will cause a thread dump, the same way as it does in java.
    """

    def handler(_ignored_signum, _ignored_frame):
        dump_threads(sys.stderr)

    signal.signal(some_sig, handler)


def _check_python_version():
    """Asserts that we're running the correct version of python."""
    major, minor, micro, releaselevel = (3, 7, 0, "final")
    version = sys.version_info
    if version.major != major:
        raise Error("Incorrect python major version: %s, expected %s" % (version.major, major))
    if version.minor < minor:  # Less strict with minor
        raise Error("Incorrect python minor version: %s, expected %s" % (version.minor, minor))
    if version.micro < micro:  # we just ignore the micro
        # raise Error('Incorrect python micro version: %s, expected %s' % (version.micro, micro))
        pass
    if version.releaselevel != releaselevel:
        raise Error(
            "Incorrect python releaselevel: %s, expected %s" % (version.releaselevel, releaselevel)
        )


def get_app_name():
    """Get the app name
    :return: The app name, a string, or None if unset.
    """
    return OPTIONS.app_name if OPTIONS else None


def get_host():
    """Get the app host
    :return: The app host, a string, or None if unset.
    """
    return OPTIONS.app_host if OPTIONS else None


def run(main, max_message_length=None):
    """Performs all initializations and runs the main function.

    main will be invoked as:
      main(options, args)
    where:
      options is the result of parse.parse_args and hence contains all the
              arguments that have been added with app.parser.add_argument.
      args are the unparsed arguments. Notice that args is options.args

    :param main: The main function that should be ran
    :param max_message_length: The override of the default uc logging max message length
    """
    _add_shutdown_handler(signal.SIGINT)
    _add_shutdown_handler(signal.SIGTERM)
    _add_dump_threads_handler(signal.SIGQUIT)
    options = parse_args()

    uc_logging.init_from_args(options, max_message_length=max_message_length)
    _check_python_version()

    try:
        logging.info("Starting main. app.py file is at: %r", __file__)
        if options.app_profile_output:
            logging.info(
                "profiling on, stats will be dumped to %s"
                % os.path.abspath(options.app_profile_output)
            )
            profiler = cProfile.Profile()
            profiler.runcall(main, options, options.args)
            logging.info(
                "profiling done, stats dumped to %s" % os.path.abspath(options.app_profile_output)
            )
            profiler.dump_stats(options.app_profile_output)
        else:
            main(options, options.args)
        logging.info("Finished main")
    except SystemExit as e:
        # Check error code.  If zero, its a graceful shutdown so lets not print a stack trace.
        if e.code == 0:
            logging.info("Exiting gracefully...")
        else:
            logging.exception("SystemExit(%r) caught in main:", e.code)
            raise e
    except Exception as e:
        logging.exception("Exception caught in main:")
        raise e
    finally:
        if options.dump_threads_on_main_exit:
            dump_threads(sys.stderr)
