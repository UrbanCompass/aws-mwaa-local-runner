# -*- coding: utf-8 -*-
"""
GRPC <-> Thrift codec.

:copyright: (c) 2016 by Urban Compass, Inc.
"""
import logging

from thrift.protocol import TBinaryProtocol
from thrift.transport import TTransport

from uc.grpc import DEFAULT_MAX_MESSAGE_LENGTH


def serialize(message):
    """Serialize a Thrift struct."""

    transport = TTransport.TMemoryBuffer()
    protocol = TBinaryProtocol.TBinaryProtocolAccelerated(transport)
    message.write(protocol)
    result = transport.getvalue()
    if len(result) > DEFAULT_MAX_MESSAGE_LENGTH:
        logging.warn(
            "Thrift struct: [%s] exceeds max message size: [%d]", message.__class__, len(result)
        )
    return result


def deserializer(cls):
    """Create a deserializer for the given Thrift struct."""

    def deserialize(data):
        transport = TTransport.TMemoryBuffer(data)
        protocol = TBinaryProtocol.TBinaryProtocolAccelerated(transport)
        if cls:
            value = cls()
            value.read(protocol)
            return value
        return transport.getvalue()

    return deserialize
