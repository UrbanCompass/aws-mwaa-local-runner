# -*- coding: utf-8 -*-
"""
Tools for converting json-like python data structures to thrift.

:copyright: (c) 2015 by UrbanCompass, Inc.
"""

import logging
from numbers import Number

from thrift.Thrift import TType
from thrift.protocol.TProtocol import TProtocolException

from uc.util.string_util import fix_variable_case


class _ParseError(Exception):
    """Internal exception used to report parse errors."""

    def __init__(self, msg, *msg_args):
        super(_ParseError, self).__init__()
        self.msg = msg % msg_args


class _InvalidMapKeyError(_ParseError):
    """Exception used to report invalid map keys (only string keys are supported)."""

    pass


class _InvalidValueError(_ParseError):
    """Exception used to report invalid values for a thrift field."""

    pass


class _UnknownFieldError(_ParseError):
    """Exception used to report missing unknown fields found while parsing structs."""

    pass


def _assert(error_class, condition, msg, *msg_args):
    if not condition:
        raise error_class(msg, *msg_args)


_STRING_TYPES = (TType.STRING, TType.UTF7, TType.UTF16)
_NUMBER_TYPES = (TType.I08, TType.I16, TType.I32, TType.I64, TType.DOUBLE, TType.BYTE)


class _JsonDictToThrift(object):
    def __init__(self, string_case, tolerate_errors):
        """Create a converter object.

        :param string_case: the string case expected in the input dict.
          Acceptable values are:
            None - expect the same case of the field name
            SNAKE_CASE - expect the field names to be snake_cased, so a field named anInt
              will be {"an_int": 1} in the jsondict.
        :param tolerate_errors: a tuple of exception classes that should be tolerated.
        """
        self._string_case = string_case
        assert isinstance(tolerate_errors, tuple)
        self._tolerate_errors = tolerate_errors

    def _parse_value(self, json_value, ttype, spec_args, value=None):
        """Parse a json value in the corresponding thrift entity.

        :param json_value: a non-null json value expressed as python data structure - i.e. a dict,
          list, string, number or boolean.
        :param ttype: the expected thrift TType of the result.
        :param spec_args: additional types for the type of the result, used for containers.
        For more details, see:
        https://github.com/apache/thrift/blob/0.9.0/compiler/cpp/src/generate/t_py_generator.cc#L652-L670
        :param value: only for STRUCT, a pre-existing value if one exists so that we can append to it.
        :returns: the parsed value. If ttype is STRUCT and value was provided, returns value mutated.
        """
        if ttype in _NUMBER_TYPES:
            _assert(
                _InvalidValueError,
                isinstance(json_value, Number),
                "Invalid value %r (number expected)",
                json_value,
            )
            return json_value
        elif ttype in _STRING_TYPES:
            _assert(
                _InvalidValueError,
                isinstance(json_value, str),
                "Invalid value %r (string expected)",
                json_value,
            )
            return json_value
        elif ttype == TType.BOOL:
            _assert(
                _InvalidValueError,
                isinstance(json_value, (bool, Number)),
                "Invalid value %r (bool expected)",
                json_value,
            )
            return bool(json_value)
        elif ttype == TType.STRUCT:
            _assert(
                _InvalidValueError,
                hasattr(json_value, "items"),
                "Invalid value %r (dict expected)",
                json_value,
            )
            value = value or spec_args[0]()
            self._jsondict_to_thrift(json_value, value)
            return value
        elif ttype == TType.LIST:
            _assert(
                _InvalidValueError,
                not isinstance(json_value, str),
                "Invalid value %r (list expected)",
                json_value,
            )
            return [self._parse_value(i, spec_args[0], spec_args[1]) for i in json_value]
        elif ttype == TType.SET:
            _assert(
                _InvalidValueError,
                not isinstance(json_value, str),
                "Invalid value %r (list expected)",
                json_value,
            )
            return {self._parse_value(i, spec_args[0], spec_args[1]) for i in json_value}
        elif ttype == TType.MAP:
            _assert(
                _InvalidValueError,
                hasattr(json_value, "items"),
                "Invalid value %r (dict expected)",
                json_value,
            )
            _assert(
                _InvalidMapKeyError,
                spec_args[0] in _STRING_TYPES,
                "Cannot parse map with non-string keys.",
            )
            return {
                self._parse_value(k, spec_args[0], None): self._parse_value(
                    v, spec_args[2], spec_args[3]
                )
                for (k, v) in list(json_value.items())
            }

    def _jsondict_to_thrift(self, jsondict, thrift_object):
        """Parse a thrift object from a json object expressed as python data structure.

        :param jsondict: the input json dict.
        :param thrift_object: the thrift object to read into the value.
          Notice that thrift_object will be modified in place and *NOT* cleared.

        When encountering errors in the input data structure or when the input data
        structure is not an acceptable representation of a thrift_object of this type
        this method raises TProtocolException.
        """
        key_map = {
            fix_variable_case(i[2], self._string_case): i[0] for i in thrift_object.thrift_spec if i
        }
        for k, v in list(jsondict.items()):
            # We get _cls out of Mongo as part of the MongoEngine upgrades because we had to turn on
            # inheritence in UcDocument.
            # The easiest way to deal with this was to simply ignore +cls when porting to Thrift objects
            if k == "_cls":
                continue
            i = key_map.get(k)
            try:
                _assert(_UnknownFieldError, i is not None, "Unknown field name")
                _, ttype, name, spec_args, default = thrift_object.thrift_spec[i]
                if v is None:
                    # Unset field.
                    setattr(thrift_object, name, None)
                    continue
                value = self._parse_value(v, ttype, spec_args, value=getattr(thrift_object, name))
                setattr(thrift_object, name, value)
            except _ParseError as c:
                msg = 'Error while processing struct %r, key "%s" : %s' % (
                    thrift_object.__class__.__name__,
                    k,
                    c.msg,
                )
                if isinstance(c, self._tolerate_errors):
                    logging.warn(msg)
                else:
                    logging.error(msg)
                    raise TProtocolException(message=msg)
        return thrift_object


def jsondict_to_thrift(
    jsondict, thrift_object, string_case=None, skip_unknown_fields=False, skip_invalid_values=False
):
    """Parse a thrift object from a json object expressed as python data structure.

    :param jsondict: the input json dict.
    :param thrift_object: the thrift object to read into the value.
      Notice that thrift_object will be modified in place and *NOT* cleared.
    :param string_case: the string case expected in the input dict.
      Acceptable values are:
        None - expect the same case of the field name
        SNAKE_CASE - expect the field names to be snake_cased, so a field named anInt
          will be {"an_int": 1} in the jsondict.
    :param skip_unknown_fields: skip unknown fields in thrift structs.
    :param skip_invalid_values: skip invalid values for thrift fields.

    When encountering errors in the input data structure or when the input data
    structure is not an acceptable representation of a thrift_object of this type
    this method raises TProtocolException.
    """
    tolerate_errors = []
    if skip_unknown_fields:
        tolerate_errors.append(_UnknownFieldError)
    if skip_invalid_values:
        tolerate_errors.append(_InvalidValueError)

    converter = _JsonDictToThrift(string_case=string_case, tolerate_errors=tuple(tolerate_errors))
    return converter._jsondict_to_thrift(jsondict, thrift_object)
