
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes

from thrift.transport import TTransport


class ComplianceChecklistCSVEntry(object):
    """
    Attributes:
     - name
     - checklistCriteriaId
     - complianceState
     - county
     - market
     - propertyType
     - listingType
     - version
     - checklistPrecedence
     - isNewConstruction
     - purposeType
     - dealType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'checklistCriteriaId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'complianceState', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'county', 'UTF8', None, ),  # 4
        (5, TType.I32, 'propertyType', None, None, ),  # 5
        (6, TType.I32, 'listingType', None, None, ),  # 6
        (7, TType.I32, 'version', None, None, ),  # 7
        (8, TType.I32, 'checklistPrecedence', None, None, ),  # 8
        (9, TType.BOOL, 'isNewConstruction', None, None, ),  # 9
        None,  # 10
        (11, TType.STRING, 'market', 'UTF8', None, ),  # 11
        (12, TType.I32, 'purposeType', None, None, ),  # 12
        (13, TType.I32, 'dealType', None, None, ),  # 13
    )
    def __init__(self, name=None, checklistCriteriaId=None, complianceState=None, county=None, propertyType=None, listingType=None, version=None, checklistPrecedence=None, isNewConstruction=None, market=None, purposeType=None, dealType=None, ):
        self.name = name
        self.checklistCriteriaId = checklistCriteriaId
        self.complianceState = complianceState
        self.county = county
        self.propertyType = propertyType
        self.listingType = listingType
        self.version = version
        self.checklistPrecedence = checklistPrecedence
        self.isNewConstruction = isNewConstruction
        self.market = market
        self.purposeType = purposeType
        self.dealType = dealType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.checklistCriteriaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.county = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.checklistPrecedence = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceChecklistCSVEntry')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.checklistCriteriaId is not None:
            oprot.writeFieldBegin('checklistCriteriaId', TType.STRING, 2)
            oprot.writeString(self.checklistCriteriaId.encode('utf-8') if sys.version_info[0] == 2 else self.checklistCriteriaId)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 3)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.county is not None:
            oprot.writeFieldBegin('county', TType.STRING, 4)
            oprot.writeString(self.county.encode('utf-8') if sys.version_info[0] == 2 else self.county)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 5)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 6)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 7)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.checklistPrecedence is not None:
            oprot.writeFieldBegin('checklistPrecedence', TType.I32, 8)
            oprot.writeI32(self.checklistPrecedence)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 9)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 11)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 12)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 13)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ComplianceDocument(object):
    """
    Attributes:
     - id
     - documentName
     - documentDescription
     - documentRequired
     - dealPhase
     - documentPriority
     - complianceState
     - createdTime
     - lastModifiedTime
     - documentInactive
     - sideRepresented
     - purposeType
     - createdBy
     - updatedBy
     - glideDocIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'documentName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'documentDescription', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'documentRequired', None, None, ),  # 4
        (5, TType.I32, 'dealPhase', None, None, ),  # 5
        (6, TType.I32, 'documentPriority', None, None, ),  # 6
        (7, TType.STRING, 'complianceState', 'UTF8', None, ),  # 7
        (8, TType.I64, 'createdTime', None, None, ),  # 8
        (9, TType.I64, 'lastModifiedTime', None, None, ),  # 9
        (10, TType.BOOL, 'documentInactive', None, None, ),  # 10
        (11, TType.I32, 'sideRepresented', None, None, ),  # 11
        (12, TType.I32, 'purposeType', None, None, ),  # 12
        (13, TType.STRING, 'createdBy', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 14
        (15, TType.LIST, 'glideDocIds', (TType.STRING, 'UTF8', False), None, ),  # 15
    )
    def __init__(self, id=None, documentName=None, documentDescription=None, documentRequired=None, dealPhase=None, documentPriority=None, complianceState=None, createdTime=None, lastModifiedTime=None, documentInactive=None, sideRepresented=None, purposeType=None, createdBy=None, updatedBy=None, glideDocIds=None, ):
        self.id = id
        self.documentName = documentName
        self.documentDescription = documentDescription
        self.documentRequired = documentRequired
        self.dealPhase = dealPhase
        self.documentPriority = documentPriority
        self.complianceState = complianceState
        self.createdTime = createdTime
        self.lastModifiedTime = lastModifiedTime
        self.documentInactive = documentInactive
        self.sideRepresented = sideRepresented
        self.purposeType = purposeType
        self.createdBy = createdBy
        self.updatedBy = updatedBy
        self.glideDocIds = glideDocIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.documentDescription = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.documentRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.dealPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.documentPriority = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.documentInactive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.glideDocIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.glideDocIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceDocument')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.documentName is not None:
            oprot.writeFieldBegin('documentName', TType.STRING, 2)
            oprot.writeString(self.documentName.encode('utf-8') if sys.version_info[0] == 2 else self.documentName)
            oprot.writeFieldEnd()
        if self.documentDescription is not None:
            oprot.writeFieldBegin('documentDescription', TType.STRING, 3)
            oprot.writeString(self.documentDescription.encode('utf-8') if sys.version_info[0] == 2 else self.documentDescription)
            oprot.writeFieldEnd()
        if self.documentRequired is not None:
            oprot.writeFieldBegin('documentRequired', TType.BOOL, 4)
            oprot.writeBool(self.documentRequired)
            oprot.writeFieldEnd()
        if self.dealPhase is not None:
            oprot.writeFieldBegin('dealPhase', TType.I32, 5)
            oprot.writeI32(self.dealPhase)
            oprot.writeFieldEnd()
        if self.documentPriority is not None:
            oprot.writeFieldBegin('documentPriority', TType.I32, 6)
            oprot.writeI32(self.documentPriority)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 7)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 8)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 9)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.documentInactive is not None:
            oprot.writeFieldBegin('documentInactive', TType.BOOL, 10)
            oprot.writeBool(self.documentInactive)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 11)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 12)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 13)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 14)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        if self.glideDocIds is not None:
            oprot.writeFieldBegin('glideDocIds', TType.LIST, 15)
            oprot.writeListBegin(TType.STRING, len(self.glideDocIds))
            for _iter6 in self.glideDocIds:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ComplianceDocumentCSVEntry(object):
    """
    Attributes:
     - documentName
     - documentDescription
     - documentRequired
     - dealPhase
     - documentPriority
     - complianceState
     - builtBeforeYear
     - builtAfterYear
     - csvChecklistCriteriaKey
     - documentInactive
     - sideRepresented
     - glideDocIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'documentName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentDescription', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'documentRequired', None, None, ),  # 3
        (4, TType.I32, 'dealPhase', None, None, ),  # 4
        (5, TType.I32, 'documentPriority', None, None, ),  # 5
        (6, TType.STRING, 'complianceState', 'UTF8', None, ),  # 6
        (7, TType.I32, 'builtBeforeYear', None, None, ),  # 7
        (8, TType.I32, 'builtAfterYear', None, None, ),  # 8
        (9, TType.STRING, 'csvChecklistCriteriaKey', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'documentInactive', None, None, ),  # 10
        (11, TType.I32, 'sideRepresented', None, None, ),  # 11
        (12, TType.LIST, 'glideDocIds', (TType.STRING, 'UTF8', False), None, ),  # 12
    )
    def __init__(self, documentName=None, documentDescription=None, documentRequired=None, dealPhase=None, documentPriority=None, complianceState=None, builtBeforeYear=None, builtAfterYear=None, csvChecklistCriteriaKey=None, documentInactive=None, sideRepresented=None, glideDocIds=None, ):
        self.documentName = documentName
        self.documentDescription = documentDescription
        self.documentRequired = documentRequired
        self.dealPhase = dealPhase
        self.documentPriority = documentPriority
        self.complianceState = complianceState
        self.builtBeforeYear = builtBeforeYear
        self.builtAfterYear = builtAfterYear
        self.csvChecklistCriteriaKey = csvChecklistCriteriaKey
        self.documentInactive = documentInactive
        self.sideRepresented = sideRepresented
        self.glideDocIds = glideDocIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.documentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentDescription = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.documentRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.dealPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.documentPriority = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.builtBeforeYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.builtAfterYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.csvChecklistCriteriaKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.documentInactive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.glideDocIds = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.glideDocIds.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceDocumentCSVEntry')
        if self.documentName is not None:
            oprot.writeFieldBegin('documentName', TType.STRING, 1)
            oprot.writeString(self.documentName.encode('utf-8') if sys.version_info[0] == 2 else self.documentName)
            oprot.writeFieldEnd()
        if self.documentDescription is not None:
            oprot.writeFieldBegin('documentDescription', TType.STRING, 2)
            oprot.writeString(self.documentDescription.encode('utf-8') if sys.version_info[0] == 2 else self.documentDescription)
            oprot.writeFieldEnd()
        if self.documentRequired is not None:
            oprot.writeFieldBegin('documentRequired', TType.BOOL, 3)
            oprot.writeBool(self.documentRequired)
            oprot.writeFieldEnd()
        if self.dealPhase is not None:
            oprot.writeFieldBegin('dealPhase', TType.I32, 4)
            oprot.writeI32(self.dealPhase)
            oprot.writeFieldEnd()
        if self.documentPriority is not None:
            oprot.writeFieldBegin('documentPriority', TType.I32, 5)
            oprot.writeI32(self.documentPriority)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 6)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.builtBeforeYear is not None:
            oprot.writeFieldBegin('builtBeforeYear', TType.I32, 7)
            oprot.writeI32(self.builtBeforeYear)
            oprot.writeFieldEnd()
        if self.builtAfterYear is not None:
            oprot.writeFieldBegin('builtAfterYear', TType.I32, 8)
            oprot.writeI32(self.builtAfterYear)
            oprot.writeFieldEnd()
        if self.csvChecklistCriteriaKey is not None:
            oprot.writeFieldBegin('csvChecklistCriteriaKey', TType.STRING, 9)
            oprot.writeString(self.csvChecklistCriteriaKey.encode('utf-8') if sys.version_info[0] == 2 else self.csvChecklistCriteriaKey)
            oprot.writeFieldEnd()
        if self.documentInactive is not None:
            oprot.writeFieldBegin('documentInactive', TType.BOOL, 10)
            oprot.writeBool(self.documentInactive)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 11)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.glideDocIds is not None:
            oprot.writeFieldBegin('glideDocIds', TType.LIST, 12)
            oprot.writeListBegin(TType.STRING, len(self.glideDocIds))
            for _iter11 in self.glideDocIds:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EnrichedComplianceDocument(object):
    """
    Attributes:
     - document
     - checklistCriteriaRelation
     - checklistCriteria
     - checklist
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'document', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'checklistCriteriaRelation', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'checklistCriteria', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'checklist', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist.thrift_spec), None, ),  # 4
    )
    def __init__(self, document=None, checklistCriteriaRelation=None, checklistCriteria=None, checklist=None, ):
        self.document = document
        self.checklistCriteriaRelation = checklistCriteriaRelation
        self.checklistCriteria = checklistCriteria
        self.checklist = checklist

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.document = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal()
                    self.document.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.checklistCriteriaRelation = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation()
                    self.checklistCriteriaRelation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.checklistCriteria = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria()
                    self.checklistCriteria.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.checklist = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist()
                    self.checklist.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichedComplianceDocument')
        if self.document is not None:
            oprot.writeFieldBegin('document', TType.STRUCT, 1)
            self.document.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistCriteriaRelation is not None:
            oprot.writeFieldBegin('checklistCriteriaRelation', TType.STRUCT, 2)
            self.checklistCriteriaRelation.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistCriteria is not None:
            oprot.writeFieldBegin('checklistCriteria', TType.STRUCT, 3)
            self.checklistCriteria.write(oprot)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.STRUCT, 4)
            self.checklist.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionChecklistMarket(object):
    """
    Attributes:
     - displayName
     - checklistRegion
     - checklistMarket
     - market
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'displayName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'checklistRegion', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'checklistMarket', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'market', 'UTF8', None, ),  # 4
    )
    def __init__(self, displayName=None, checklistRegion=None, checklistMarket=None, market=None, ):
        self.displayName = displayName
        self.checklistRegion = checklistRegion
        self.checklistMarket = checklistMarket
        self.market = market

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.checklistRegion = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.checklistMarket = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionChecklistMarket')
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 1)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.checklistRegion is not None:
            oprot.writeFieldBegin('checklistRegion', TType.STRING, 2)
            oprot.writeString(self.checklistRegion.encode('utf-8') if sys.version_info[0] == 2 else self.checklistRegion)
            oprot.writeFieldEnd()
        if self.checklistMarket is not None:
            oprot.writeFieldBegin('checklistMarket', TType.STRING, 3)
            oprot.writeString(self.checklistMarket.encode('utf-8') if sys.version_info[0] == 2 else self.checklistMarket)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 4)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionDocumentReviewSettings(object):
    """
    Attributes:
     - dmsForceSplitOnUploadEnabled
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'dmsForceSplitOnUploadEnabled', None, None, ),  # 1
    )
    def __init__(self, dmsForceSplitOnUploadEnabled=None, ):
        self.dmsForceSplitOnUploadEnabled = dmsForceSplitOnUploadEnabled

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.dmsForceSplitOnUploadEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionDocumentReviewSettings')
        if self.dmsForceSplitOnUploadEnabled is not None:
            oprot.writeFieldBegin('dmsForceSplitOnUploadEnabled', TType.BOOL, 1)
            oprot.writeBool(self.dmsForceSplitOnUploadEnabled)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionMarket(object):
    """
    Attributes:
     - region
     - market
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'region', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'market', 'UTF8', None, ),  # 2
    )
    def __init__(self, region=None, market=None, ):
        self.region = region
        self.market = market

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.region = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionMarket')
        if self.region is not None:
            oprot.writeFieldBegin('region', TType.STRING, 1)
            oprot.writeString(self.region.encode('utf-8') if sys.version_info[0] == 2 else self.region)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 2)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionSpecificCtcServiceType(object):
    """
    Attributes:
     - ctcServiceType
     - displayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'ctcServiceType', None, None, ),  # 1
        (2, TType.STRING, 'displayName', 'UTF8', None, ),  # 2
    )
    def __init__(self, ctcServiceType=None, displayName=None, ):
        self.ctcServiceType = ctcServiceType
        self.displayName = displayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionSpecificCtcServiceType')
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 1)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 2)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionSpecificPropertyType(object):
    """
    Attributes:
     - propertyType
     - displayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'propertyType', None, None, ),  # 1
        (2, TType.STRING, 'displayName', 'UTF8', None, ),  # 2
    )
    def __init__(self, propertyType=None, displayName=None, ):
        self.propertyType = propertyType
        self.displayName = displayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionSpecificPropertyType')
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 1)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 2)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ComplianceChecklist(object):
    """
    Attributes:
     - id
     - name
     - documents
     - complianceState
     - county
     - market
     - listingType
     - version
     - isNewConstruction
     - isDeleted
     - isDraft
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'documents', (TType.STRUCT, (ComplianceDocument, ComplianceDocument.thrift_spec), False), None, ),  # 3
        (4, TType.STRING, 'complianceState', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'county', 'UTF8', None, ),  # 5
        None,  # 6
        (7, TType.I32, 'listingType', None, None, ),  # 7
        (8, TType.I32, 'version', None, None, ),  # 8
        (9, TType.BOOL, 'isNewConstruction', None, None, ),  # 9
        (10, TType.BOOL, 'isDeleted', None, None, ),  # 10
        (11, TType.STRING, 'market', 'UTF8', None, ),  # 11
        (12, TType.BOOL, 'isDraft', None, None, ),  # 12
    )
    def __init__(self, id=None, name=None, documents=None, complianceState=None, county=None, listingType=None, version=None, isNewConstruction=None, isDeleted=None, market=None, isDraft=None, ):
        self.id = id
        self.name = name
        self.documents = documents
        self.complianceState = complianceState
        self.county = county
        self.listingType = listingType
        self.version = version
        self.isNewConstruction = isNewConstruction
        self.isDeleted = isDeleted
        self.market = market
        self.isDraft = isDraft

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.documents = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = ComplianceDocument()
                        _elem14.read(iprot)
                        self.documents.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.county = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isDraft = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceChecklist')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.documents is not None:
            oprot.writeFieldBegin('documents', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.documents))
            for _iter16 in self.documents:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 4)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.county is not None:
            oprot.writeFieldBegin('county', TType.STRING, 5)
            oprot.writeString(self.county.encode('utf-8') if sys.version_info[0] == 2 else self.county)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 7)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 8)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 9)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 10)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 11)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isDraft is not None:
            oprot.writeFieldBegin('isDraft', TType.BOOL, 12)
            oprot.writeBool(self.isDraft)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionSettings(object):
    """
    Attributes:
     - propertyTypes
     - markets
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'propertyTypes', (TType.STRUCT, (RegionSpecificPropertyType, RegionSpecificPropertyType.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'markets', (TType.STRUCT, (RegionChecklistMarket, RegionChecklistMarket.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, propertyTypes=None, markets=None, ):
        self.propertyTypes = propertyTypes
        self.markets = markets

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = RegionSpecificPropertyType()
                        _elem19.read(iprot)
                        self.propertyTypes.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.markets = []
                    (_etype21, _size24) = iprot.readListBegin()
                    for _i22 in range(_size24):
                        _elem23 = RegionChecklistMarket()
                        _elem23.read(iprot)
                        self.markets.append(_elem23)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionSettings')
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.propertyTypes))
            for _iter25 in self.propertyTypes:
                _iter25.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.markets is not None:
            oprot.writeFieldBegin('markets', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.markets))
            for _iter26 in self.markets:
                _iter26.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StateConfig(object):
    """
    Attributes:
     - name
     - hasMarkets
     - marketDisplayNameMap
     - marketEmailMap
     - marketToRegionMarketChecklistMap
     - defaultEmail
     - defaultRegionMarket
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'hasMarkets', None, None, ),  # 2
        (3, TType.MAP, 'marketDisplayNameMap', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.MAP, 'marketEmailMap', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.MAP, 'marketToRegionMarketChecklistMap', (TType.STRING, 'UTF8', TType.STRUCT, (RegionMarket, RegionMarket.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'defaultEmail', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'defaultRegionMarket', (RegionMarket, RegionMarket.thrift_spec), None, ),  # 7
    )
    def __init__(self, name=None, hasMarkets=None, marketDisplayNameMap=None, marketEmailMap=None, marketToRegionMarketChecklistMap=None, defaultEmail=None, defaultRegionMarket=None, ):
        self.name = name
        self.hasMarkets = hasMarkets
        self.marketDisplayNameMap = marketDisplayNameMap
        self.marketEmailMap = marketEmailMap
        self.marketToRegionMarketChecklistMap = marketToRegionMarketChecklistMap
        self.defaultEmail = defaultEmail
        self.defaultRegionMarket = defaultRegionMarket

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.hasMarkets = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.marketDisplayNameMap = {}
                    (_ktype28, _vtype29, _size32) = iprot.readMapBegin()
                    for _i27 in range(_size32):
                        _key30 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val31 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.marketDisplayNameMap[_key30] = _val31
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.marketEmailMap = {}
                    (_ktype34, _vtype35, _size38) = iprot.readMapBegin()
                    for _i33 in range(_size38):
                        _key36 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val37 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.marketEmailMap[_key36] = _val37
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.marketToRegionMarketChecklistMap = {}
                    (_ktype40, _vtype41, _size44) = iprot.readMapBegin()
                    for _i39 in range(_size44):
                        _key42 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val43 = RegionMarket()
                        _val43.read(iprot)
                        self.marketToRegionMarketChecklistMap[_key42] = _val43
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.defaultEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.defaultRegionMarket = RegionMarket()
                    self.defaultRegionMarket.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StateConfig')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.hasMarkets is not None:
            oprot.writeFieldBegin('hasMarkets', TType.BOOL, 2)
            oprot.writeBool(self.hasMarkets)
            oprot.writeFieldEnd()
        if self.marketDisplayNameMap is not None:
            oprot.writeFieldBegin('marketDisplayNameMap', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.marketDisplayNameMap))
            for _kiter45, _viter46 in self.marketDisplayNameMap.items():
                oprot.writeString(_kiter45.encode('utf-8') if sys.version_info[0] == 2 else _kiter45)
                oprot.writeString(_viter46.encode('utf-8') if sys.version_info[0] == 2 else _viter46)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.marketEmailMap is not None:
            oprot.writeFieldBegin('marketEmailMap', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.marketEmailMap))
            for _kiter47, _viter48 in self.marketEmailMap.items():
                oprot.writeString(_kiter47.encode('utf-8') if sys.version_info[0] == 2 else _kiter47)
                oprot.writeString(_viter48.encode('utf-8') if sys.version_info[0] == 2 else _viter48)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.marketToRegionMarketChecklistMap is not None:
            oprot.writeFieldBegin('marketToRegionMarketChecklistMap', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.marketToRegionMarketChecklistMap))
            for _kiter49, _viter50 in self.marketToRegionMarketChecklistMap.items():
                oprot.writeString(_kiter49.encode('utf-8') if sys.version_info[0] == 2 else _kiter49)
                _viter50.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.defaultEmail is not None:
            oprot.writeFieldBegin('defaultEmail', TType.STRING, 6)
            oprot.writeString(self.defaultEmail.encode('utf-8') if sys.version_info[0] == 2 else self.defaultEmail)
            oprot.writeFieldEnd()
        if self.defaultRegionMarket is not None:
            oprot.writeFieldBegin('defaultRegionMarket', TType.STRUCT, 7)
            self.defaultRegionMarket.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
