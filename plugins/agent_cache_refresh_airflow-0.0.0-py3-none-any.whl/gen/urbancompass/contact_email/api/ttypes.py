
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.notification.delivery.ttypes
import gen.urbancompass.email_campaign.models.ttypes

from thrift.transport import TTransport


class BulkMessageRecipientType(object):
    TO = 0
    CC = 1
    BCC = 2

    _VALUES_TO_NAMES = {
        0: "TO",
        1: "CC",
        2: "BCC",
    }

    _NAMES_TO_VALUES = {
        "TO": 0,
        "CC": 1,
        "BCC": 2,
    }


class BulkMessageStatus(object):
    DRAFT = 0
    PENDING = 1
    PROCESSED = 2
    SCHEDULED = 3

    _VALUES_TO_NAMES = {
        0: "DRAFT",
        1: "PENDING",
        2: "PROCESSED",
        3: "SCHEDULED",
    }

    _NAMES_TO_VALUES = {
        "DRAFT": 0,
        "PENDING": 1,
        "PROCESSED": 2,
        "SCHEDULED": 3,
    }


class GetBulkMessageOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    SENT_AT_ASC = 2
    SENT_AT_DESC = 3
    PROCESSED_AT_ASC = 4
    PROCESSED_AT_DESC = 5
    UPDATED_AT_ASC = 6
    UPDATED_AT_DESC = 7

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "SENT_AT_ASC",
        3: "SENT_AT_DESC",
        4: "PROCESSED_AT_ASC",
        5: "PROCESSED_AT_DESC",
        6: "UPDATED_AT_ASC",
        7: "UPDATED_AT_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "SENT_AT_ASC": 2,
        "SENT_AT_DESC": 3,
        "PROCESSED_AT_ASC": 4,
        "PROCESSED_AT_DESC": 5,
        "UPDATED_AT_ASC": 6,
        "UPDATED_AT_DESC": 7,
    }


class GetMessageEventsOrder(object):
    TIMESTAMP_ASC = 0
    TIMESTAMP_DESC = 1

    _VALUES_TO_NAMES = {
        0: "TIMESTAMP_ASC",
        1: "TIMESTAMP_DESC",
    }

    _NAMES_TO_VALUES = {
        "TIMESTAMP_ASC": 0,
        "TIMESTAMP_DESC": 1,
    }


class MessageEventType(object):
    OPEN = 1
    CLICK = 2
    RESPONSE = 3

    _VALUES_TO_NAMES = {
        1: "OPEN",
        2: "CLICK",
        3: "RESPONSE",
    }

    _NAMES_TO_VALUES = {
        "OPEN": 1,
        "CLICK": 2,
        "RESPONSE": 3,
    }


class MessageRecipientType(object):
    TO = 0
    CC = 1
    BCC = 2

    _VALUES_TO_NAMES = {
        0: "TO",
        1: "CC",
        2: "BCC",
    }

    _NAMES_TO_VALUES = {
        "TO": 0,
        "CC": 1,
        "BCC": 2,
    }


class MessageStatus(object):
    DRAFT = 0
    SCHEDULED = 1
    SENT = 2
    FAILED = 3
    PENDING = 4
    PROCESSING = 5

    _VALUES_TO_NAMES = {
        0: "DRAFT",
        1: "SCHEDULED",
        2: "SENT",
        3: "FAILED",
        4: "PENDING",
        5: "PROCESSING",
    }

    _NAMES_TO_VALUES = {
        "DRAFT": 0,
        "SCHEDULED": 1,
        "SENT": 2,
        "FAILED": 3,
        "PENDING": 4,
        "PROCESSING": 5,
    }


class MessageTemplateEnrichOptions(object):
    MINIMAL_WORKFLOW = 0

    _VALUES_TO_NAMES = {
        0: "MINIMAL_WORKFLOW",
    }

    _NAMES_TO_VALUES = {
        "MINIMAL_WORKFLOW": 0,
    }


class AccountShallow(object):
    """
    Attributes:
     - disabledAt
     - externalId
     - handle
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'disabledAt', None, None, ),  # 1
        (2, TType.STRING, 'externalId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'handle', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'id', 'UTF8', None, ),  # 4
    )
    def __init__(self, disabledAt=None, externalId=None, handle=None, id=None, ):
        self.disabledAt = disabledAt
        self.externalId = externalId
        self.handle = handle
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.disabledAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.handle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountShallow')
        if self.disabledAt is not None:
            oprot.writeFieldBegin('disabledAt', TType.I64, 1)
            oprot.writeI64(self.disabledAt)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 2)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.handle is not None:
            oprot.writeFieldBegin('handle', TType.STRING, 3)
            oprot.writeString(self.handle.encode('utf-8') if sys.version_info[0] == 2 else self.handle)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 4)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BulkMessageRecipient(object):
    """
    Attributes:
     - contactId
     - contactIdentityId
     - handle
     - type
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'contactIdentityId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'handle', 'UTF8', None, ),  # 3
        (4, TType.I32, 'type', None, None, ),  # 4
    )
    def __init__(self, contactId=None, contactIdentityId=None, handle=None, type=None, ):
        self.contactId = contactId
        self.contactIdentityId = contactIdentityId
        self.handle = handle
        self.type = type

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.contactIdentityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.handle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkMessageRecipient')
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 1)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.contactIdentityId is not None:
            oprot.writeFieldBegin('contactIdentityId', TType.STRING, 2)
            oprot.writeString(self.contactIdentityId.encode('utf-8') if sys.version_info[0] == 2 else self.contactIdentityId)
            oprot.writeFieldEnd()
        if self.handle is not None:
            oprot.writeFieldBegin('handle', TType.STRING, 3)
            oprot.writeString(self.handle.encode('utf-8') if sys.version_info[0] == 2 else self.handle)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 4)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Category(object):
    """
    Attributes:
     - id
     - name
     - userId
     - createdAt
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.I64, 'createdAt', None, None, ),  # 4
        (5, TType.I64, 'updatedAt', None, None, ),  # 5
    )
    def __init__(self, id=None, name=None, userId=None, createdAt=None, updatedAt=None, ):
        self.id = id
        self.name = name
        self.userId = userId
        self.createdAt = createdAt
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Category')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 4)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 5)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageAttachment(object):
    """
    Attributes:
     - filename
     - mimetype
     - url
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'filename', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'mimetype', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'url', 'UTF8', None, ),  # 3
    )
    def __init__(self, filename=None, mimetype=None, url=None, ):
        self.filename = filename
        self.mimetype = mimetype
        self.url = url

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.filename = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.mimetype = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageAttachment')
        if self.filename is not None:
            oprot.writeFieldBegin('filename', TType.STRING, 1)
            oprot.writeString(self.filename.encode('utf-8') if sys.version_info[0] == 2 else self.filename)
            oprot.writeFieldEnd()
        if self.mimetype is not None:
            oprot.writeFieldBegin('mimetype', TType.STRING, 2)
            oprot.writeString(self.mimetype.encode('utf-8') if sys.version_info[0] == 2 else self.mimetype)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 3)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageEvent(object):
    """
    Attributes:
     - id
     - messageId
     - eventType
     - extraData
     - timestamp
     - createdAt
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'messageId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'eventType', None, None, ),  # 3
        (4, TType.STRING, 'extraData', 'UTF8', None, ),  # 4
        (5, TType.I64, 'timestamp', None, None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
    )
    def __init__(self, id=None, messageId=None, eventType=None, extraData=None, timestamp=None, createdAt=None, updatedAt=None, ):
        self.id = id
        self.messageId = messageId
        self.eventType = eventType
        self.extraData = extraData
        self.timestamp = timestamp
        self.createdAt = createdAt
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.messageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.eventType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.extraData = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageEvent')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.messageId is not None:
            oprot.writeFieldBegin('messageId', TType.STRING, 2)
            oprot.writeString(self.messageId.encode('utf-8') if sys.version_info[0] == 2 else self.messageId)
            oprot.writeFieldEnd()
        if self.eventType is not None:
            oprot.writeFieldBegin('eventType', TType.I32, 3)
            oprot.writeI32(self.eventType)
            oprot.writeFieldEnd()
        if self.extraData is not None:
            oprot.writeFieldBegin('extraData', TType.STRING, 4)
            oprot.writeString(self.extraData.encode('utf-8') if sys.version_info[0] == 2 else self.extraData)
            oprot.writeFieldEnd()
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 5)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageMetadata(object):
    """
    Attributes:
     - autoSend
     - actionPlan
     - objectId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'autoSend', None, None, ),  # 1
        (2, TType.BOOL, 'actionPlan', None, None, ),  # 2
        (3, TType.STRING, 'objectId', 'UTF8', None, ),  # 3
    )
    def __init__(self, autoSend=None, actionPlan=None, objectId=None, ):
        self.autoSend = autoSend
        self.actionPlan = actionPlan
        self.objectId = objectId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.autoSend = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.actionPlan = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.objectId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageMetadata')
        if self.autoSend is not None:
            oprot.writeFieldBegin('autoSend', TType.BOOL, 1)
            oprot.writeBool(self.autoSend)
            oprot.writeFieldEnd()
        if self.actionPlan is not None:
            oprot.writeFieldBegin('actionPlan', TType.BOOL, 2)
            oprot.writeBool(self.actionPlan)
            oprot.writeFieldEnd()
        if self.objectId is not None:
            oprot.writeFieldBegin('objectId', TType.STRING, 3)
            oprot.writeString(self.objectId.encode('utf-8') if sys.version_info[0] == 2 else self.objectId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageRecipient(object):
    """
    Attributes:
     - recipientType
     - contactId
     - handle
     - contactIdentityId
     - avatarUrl
     - firstName
     - lastName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'recipientType', None, None, ),  # 1
        (2, TType.STRING, 'contactId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'handle', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'contactIdentityId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'firstName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'lastName', 'UTF8', None, ),  # 7
    )
    def __init__(self, recipientType=None, contactId=None, handle=None, contactIdentityId=None, avatarUrl=None, firstName=None, lastName=None, ):
        self.recipientType = recipientType
        self.contactId = contactId
        self.handle = handle
        self.contactIdentityId = contactIdentityId
        self.avatarUrl = avatarUrl
        self.firstName = firstName
        self.lastName = lastName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.recipientType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.handle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.contactIdentityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageRecipient')
        if self.recipientType is not None:
            oprot.writeFieldBegin('recipientType', TType.I32, 1)
            oprot.writeI32(self.recipientType)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 2)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.handle is not None:
            oprot.writeFieldBegin('handle', TType.STRING, 3)
            oprot.writeString(self.handle.encode('utf-8') if sys.version_info[0] == 2 else self.handle)
            oprot.writeFieldEnd()
        if self.contactIdentityId is not None:
            oprot.writeFieldBegin('contactIdentityId', TType.STRING, 4)
            oprot.writeString(self.contactIdentityId.encode('utf-8') if sys.version_info[0] == 2 else self.contactIdentityId)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 5)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 6)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 7)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageTemplateEnrichError(object):
    """
    Attributes:
     - errorMessage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'errorMessage', 'UTF8', None, ),  # 1
    )
    def __init__(self, errorMessage=None, ):
        self.errorMessage = errorMessage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.errorMessage = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageTemplateEnrichError')
        if self.errorMessage is not None:
            oprot.writeFieldBegin('errorMessage', TType.STRING, 1)
            oprot.writeString(self.errorMessage.encode('utf-8') if sys.version_info[0] == 2 else self.errorMessage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageTemplateMetadata(object):
    """
    Attributes:
     - legacyId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'legacyId', 'UTF8', None, ),  # 1
    )
    def __init__(self, legacyId=None, ):
        self.legacyId = legacyId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.legacyId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageTemplateMetadata')
        if self.legacyId is not None:
            oprot.writeFieldBegin('legacyId', TType.STRING, 1)
            oprot.writeString(self.legacyId.encode('utf-8') if sys.version_info[0] == 2 else self.legacyId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageVariable(object):
    """
    Attributes:
     - variable
     - displayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'variable', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'displayName', 'UTF8', None, ),  # 2
    )
    def __init__(self, variable=None, displayName=None, ):
        self.variable = variable
        self.displayName = displayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.variable = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageVariable')
        if self.variable is not None:
            oprot.writeFieldBegin('variable', TType.STRING, 1)
            oprot.writeString(self.variable.encode('utf-8') if sys.version_info[0] == 2 else self.variable)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 2)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MinimalWorkflow(object):
    """
    Attributes:
     - id
     - title
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'title', 'UTF8', None, ),  # 2
    )
    def __init__(self, id=None, title=None, ):
        self.id = id
        self.title = title

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MinimalWorkflow')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 2)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShallowPreviewMessage(object):
    """
    Attributes:
     - subject
     - body
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'subject', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'body', 'UTF8', None, ),  # 2
    )
    def __init__(self, subject=None, body=None, ):
        self.subject = subject
        self.body = body

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShallowPreviewMessage')
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 1)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 2)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TrackedLink(object):
    """
    Attributes:
     - id
     - messageId
     - userId
     - url
     - urlIdentifier
     - clickedAt
     - createdAt
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'messageId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'url', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'urlIdentifier', 'UTF8', None, ),  # 5
        (6, TType.I64, 'clickedAt', None, None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'updatedAt', None, None, ),  # 8
    )
    def __init__(self, id=None, messageId=None, userId=None, url=None, urlIdentifier=None, clickedAt=None, createdAt=None, updatedAt=None, ):
        self.id = id
        self.messageId = messageId
        self.userId = userId
        self.url = url
        self.urlIdentifier = urlIdentifier
        self.clickedAt = clickedAt
        self.createdAt = createdAt
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.messageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.urlIdentifier = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.clickedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TrackedLink')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.messageId is not None:
            oprot.writeFieldBegin('messageId', TType.STRING, 2)
            oprot.writeString(self.messageId.encode('utf-8') if sys.version_info[0] == 2 else self.messageId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 4)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.urlIdentifier is not None:
            oprot.writeFieldBegin('urlIdentifier', TType.STRING, 5)
            oprot.writeString(self.urlIdentifier.encode('utf-8') if sys.version_info[0] == 2 else self.urlIdentifier)
            oprot.writeFieldEnd()
        if self.clickedAt is not None:
            oprot.writeFieldBegin('clickedAt', TType.I64, 6)
            oprot.writeI64(self.clickedAt)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 8)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BulkMessageData(object):
    """
    Attributes:
     - contactId
     - recipients
     - subject
     - body
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'recipients', (TType.STRUCT, (BulkMessageRecipient, BulkMessageRecipient.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'subject', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'body', 'UTF8', None, ),  # 4
    )
    def __init__(self, contactId=None, recipients=None, subject=None, body=None, ):
        self.contactId = contactId
        self.recipients = recipients
        self.subject = subject
        self.body = body

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.recipients = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = BulkMessageRecipient()
                        _elem4.read(iprot)
                        self.recipients.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkMessageData')
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 1)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.recipients is not None:
            oprot.writeFieldBegin('recipients', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.recipients))
            for _iter6 in self.recipients:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 3)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 4)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Message(object):
    """
    Attributes:
     - id
     - accountId
     - status
     - contactId
     - subject
     - body
     - messageTemplateId
     - createdAt
     - responseTrackingEnabled
     - openTrackingEnabled
     - clickTrackingEnabled
     - attachments
     - recipients
     - scheduledAt
     - sentAt
     - sendingErrors
     - clickedAt
     - openedAt
     - respondedAt
     - allClicks
     - allOpens
     - account
     - sentFrom
     - metadata
     - responseRequiredBy
     - viaFallback
     - updatedAt
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'accountId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'status', None, None, ),  # 3
        (4, TType.STRING, 'contactId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'subject', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'body', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'messageTemplateId', 'UTF8', None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.BOOL, 'responseTrackingEnabled', None, None, ),  # 9
        (10, TType.BOOL, 'openTrackingEnabled', None, None, ),  # 10
        (11, TType.BOOL, 'clickTrackingEnabled', None, None, ),  # 11
        (12, TType.LIST, 'attachments', (TType.STRUCT, (MessageAttachment, MessageAttachment.thrift_spec), False), None, ),  # 12
        (13, TType.LIST, 'recipients', (TType.STRUCT, (MessageRecipient, MessageRecipient.thrift_spec), False), None, ),  # 13
        (14, TType.I64, 'scheduledAt', None, None, ),  # 14
        (15, TType.I64, 'sentAt', None, None, ),  # 15
        (16, TType.STRING, 'sendingErrors', 'UTF8', None, ),  # 16
        (17, TType.I64, 'clickedAt', None, None, ),  # 17
        (18, TType.I64, 'openedAt', None, None, ),  # 18
        (19, TType.I64, 'respondedAt', None, None, ),  # 19
        (20, TType.LIST, 'allClicks', (TType.I64, None, False), None, ),  # 20
        (21, TType.LIST, 'allOpens', (TType.I64, None, False), None, ),  # 21
        (22, TType.STRUCT, 'account', (AccountShallow, AccountShallow.thrift_spec), None, ),  # 22
        (23, TType.STRING, 'sentFrom', 'UTF8', None, ),  # 23
        (24, TType.STRUCT, 'metadata', (MessageMetadata, MessageMetadata.thrift_spec), None, ),  # 24
        (25, TType.I64, 'responseRequiredBy', None, None, ),  # 25
        (26, TType.BOOL, 'viaFallback', None, None, ),  # 26
        (27, TType.I64, 'updatedAt', None, None, ),  # 27
        (28, TType.STRING, 'userId', 'UTF8', None, ),  # 28
    )
    def __init__(self, id=None, accountId=None, status=None, contactId=None, subject=None, body=None, messageTemplateId=None, createdAt=None, responseTrackingEnabled=None, openTrackingEnabled=None, clickTrackingEnabled=None, attachments=None, recipients=None, scheduledAt=None, sentAt=None, sendingErrors=None, clickedAt=None, openedAt=None, respondedAt=None, allClicks=None, allOpens=None, account=None, sentFrom=None, metadata=None, responseRequiredBy=None, viaFallback=None, updatedAt=None, userId=None, ):
        self.id = id
        self.accountId = accountId
        self.status = status
        self.contactId = contactId
        self.subject = subject
        self.body = body
        self.messageTemplateId = messageTemplateId
        self.createdAt = createdAt
        self.responseTrackingEnabled = responseTrackingEnabled
        self.openTrackingEnabled = openTrackingEnabled
        self.clickTrackingEnabled = clickTrackingEnabled
        self.attachments = attachments
        self.recipients = recipients
        self.scheduledAt = scheduledAt
        self.sentAt = sentAt
        self.sendingErrors = sendingErrors
        self.clickedAt = clickedAt
        self.openedAt = openedAt
        self.respondedAt = respondedAt
        self.allClicks = allClicks
        self.allOpens = allOpens
        self.account = account
        self.sentFrom = sentFrom
        self.metadata = metadata
        self.responseRequiredBy = responseRequiredBy
        self.viaFallback = viaFallback
        self.updatedAt = updatedAt
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.accountId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.messageTemplateId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.responseTrackingEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.openTrackingEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.clickTrackingEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.attachments = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = MessageAttachment()
                        _elem9.read(iprot)
                        self.attachments.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.recipients = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = MessageRecipient()
                        _elem13.read(iprot)
                        self.recipients.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.scheduledAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I64:
                    self.sentAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.sendingErrors = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I64:
                    self.clickedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I64:
                    self.openedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I64:
                    self.respondedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.allClicks = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = iprot.readI64()
                        self.allClicks.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.allOpens = []
                    (_etype19, _size22) = iprot.readListBegin()
                    for _i20 in range(_size22):
                        _elem21 = iprot.readI64()
                        self.allOpens.append(_elem21)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRUCT:
                    self.account = AccountShallow()
                    self.account.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.sentFrom = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.metadata = MessageMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I64:
                    self.responseRequiredBy = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.BOOL:
                    self.viaFallback = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Message')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.accountId is not None:
            oprot.writeFieldBegin('accountId', TType.STRING, 2)
            oprot.writeString(self.accountId.encode('utf-8') if sys.version_info[0] == 2 else self.accountId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 3)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 4)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 5)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 6)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        if self.messageTemplateId is not None:
            oprot.writeFieldBegin('messageTemplateId', TType.STRING, 7)
            oprot.writeString(self.messageTemplateId.encode('utf-8') if sys.version_info[0] == 2 else self.messageTemplateId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.responseTrackingEnabled is not None:
            oprot.writeFieldBegin('responseTrackingEnabled', TType.BOOL, 9)
            oprot.writeBool(self.responseTrackingEnabled)
            oprot.writeFieldEnd()
        if self.openTrackingEnabled is not None:
            oprot.writeFieldBegin('openTrackingEnabled', TType.BOOL, 10)
            oprot.writeBool(self.openTrackingEnabled)
            oprot.writeFieldEnd()
        if self.clickTrackingEnabled is not None:
            oprot.writeFieldBegin('clickTrackingEnabled', TType.BOOL, 11)
            oprot.writeBool(self.clickTrackingEnabled)
            oprot.writeFieldEnd()
        if self.attachments is not None:
            oprot.writeFieldBegin('attachments', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.attachments))
            for _iter23 in self.attachments:
                _iter23.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.recipients is not None:
            oprot.writeFieldBegin('recipients', TType.LIST, 13)
            oprot.writeListBegin(TType.STRUCT, len(self.recipients))
            for _iter24 in self.recipients:
                _iter24.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.scheduledAt is not None:
            oprot.writeFieldBegin('scheduledAt', TType.I64, 14)
            oprot.writeI64(self.scheduledAt)
            oprot.writeFieldEnd()
        if self.sentAt is not None:
            oprot.writeFieldBegin('sentAt', TType.I64, 15)
            oprot.writeI64(self.sentAt)
            oprot.writeFieldEnd()
        if self.sendingErrors is not None:
            oprot.writeFieldBegin('sendingErrors', TType.STRING, 16)
            oprot.writeString(self.sendingErrors.encode('utf-8') if sys.version_info[0] == 2 else self.sendingErrors)
            oprot.writeFieldEnd()
        if self.clickedAt is not None:
            oprot.writeFieldBegin('clickedAt', TType.I64, 17)
            oprot.writeI64(self.clickedAt)
            oprot.writeFieldEnd()
        if self.openedAt is not None:
            oprot.writeFieldBegin('openedAt', TType.I64, 18)
            oprot.writeI64(self.openedAt)
            oprot.writeFieldEnd()
        if self.respondedAt is not None:
            oprot.writeFieldBegin('respondedAt', TType.I64, 19)
            oprot.writeI64(self.respondedAt)
            oprot.writeFieldEnd()
        if self.allClicks is not None:
            oprot.writeFieldBegin('allClicks', TType.LIST, 20)
            oprot.writeListBegin(TType.I64, len(self.allClicks))
            for _iter25 in self.allClicks:
                oprot.writeI64(_iter25)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.allOpens is not None:
            oprot.writeFieldBegin('allOpens', TType.LIST, 21)
            oprot.writeListBegin(TType.I64, len(self.allOpens))
            for _iter26 in self.allOpens:
                oprot.writeI64(_iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.account is not None:
            oprot.writeFieldBegin('account', TType.STRUCT, 22)
            self.account.write(oprot)
            oprot.writeFieldEnd()
        if self.sentFrom is not None:
            oprot.writeFieldBegin('sentFrom', TType.STRING, 23)
            oprot.writeString(self.sentFrom.encode('utf-8') if sys.version_info[0] == 2 else self.sentFrom)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 24)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.responseRequiredBy is not None:
            oprot.writeFieldBegin('responseRequiredBy', TType.I64, 25)
            oprot.writeI64(self.responseRequiredBy)
            oprot.writeFieldEnd()
        if self.viaFallback is not None:
            oprot.writeFieldBegin('viaFallback', TType.BOOL, 26)
            oprot.writeBool(self.viaFallback)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 27)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 28)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageTemplate(object):
    """
    Attributes:
     - id
     - name
     - subject
     - body
     - goal
     - clonedFromId
     - dependentClone
     - attachments
     - categories
     - lastUsedAt
     - usageCount
     - associatedWorkflows
     - globalTemplate
     - deletedAt
     - userId
     - createdAt
     - updatedAt
     - metadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'subject', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'body', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'goal', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'clonedFromId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'dependentClone', None, None, ),  # 7
        (8, TType.LIST, 'attachments', (TType.STRUCT, (MessageAttachment, MessageAttachment.thrift_spec), False), None, ),  # 8
        (9, TType.LIST, 'categories', (TType.STRUCT, (Category, Category.thrift_spec), False), None, ),  # 9
        (10, TType.I64, 'lastUsedAt', None, None, ),  # 10
        (11, TType.I32, 'usageCount', None, None, ),  # 11
        (12, TType.LIST, 'associatedWorkflows', (TType.STRUCT, (MinimalWorkflow, MinimalWorkflow.thrift_spec), False), None, ),  # 12
        (13, TType.BOOL, 'globalTemplate', None, None, ),  # 13
        (14, TType.I64, 'deletedAt', None, None, ),  # 14
        (15, TType.STRING, 'userId', 'UTF8', None, ),  # 15
        (16, TType.I64, 'createdAt', None, None, ),  # 16
        (17, TType.I64, 'updatedAt', None, None, ),  # 17
        (18, TType.STRUCT, 'metadata', (MessageTemplateMetadata, MessageTemplateMetadata.thrift_spec), None, ),  # 18
    )
    def __init__(self, id=None, name=None, subject=None, body=None, goal=None, clonedFromId=None, dependentClone=None, attachments=None, categories=None, lastUsedAt=None, usageCount=None, associatedWorkflows=None, globalTemplate=None, deletedAt=None, userId=None, createdAt=None, updatedAt=None, metadata=None, ):
        self.id = id
        self.name = name
        self.subject = subject
        self.body = body
        self.goal = goal
        self.clonedFromId = clonedFromId
        self.dependentClone = dependentClone
        self.attachments = attachments
        self.categories = categories
        self.lastUsedAt = lastUsedAt
        self.usageCount = usageCount
        self.associatedWorkflows = associatedWorkflows
        self.globalTemplate = globalTemplate
        self.deletedAt = deletedAt
        self.userId = userId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.metadata = metadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.goal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.clonedFromId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.dependentClone = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.attachments = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = MessageAttachment()
                        _elem29.read(iprot)
                        self.attachments.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.categories = []
                    (_etype31, _size34) = iprot.readListBegin()
                    for _i32 in range(_size34):
                        _elem33 = Category()
                        _elem33.read(iprot)
                        self.categories.append(_elem33)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastUsedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.usageCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.associatedWorkflows = []
                    (_etype35, _size38) = iprot.readListBegin()
                    for _i36 in range(_size38):
                        _elem37 = MinimalWorkflow()
                        _elem37.read(iprot)
                        self.associatedWorkflows.append(_elem37)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.globalTemplate = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRUCT:
                    self.metadata = MessageTemplateMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageTemplate')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 3)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 4)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        if self.goal is not None:
            oprot.writeFieldBegin('goal', TType.STRING, 5)
            oprot.writeString(self.goal.encode('utf-8') if sys.version_info[0] == 2 else self.goal)
            oprot.writeFieldEnd()
        if self.clonedFromId is not None:
            oprot.writeFieldBegin('clonedFromId', TType.STRING, 6)
            oprot.writeString(self.clonedFromId.encode('utf-8') if sys.version_info[0] == 2 else self.clonedFromId)
            oprot.writeFieldEnd()
        if self.dependentClone is not None:
            oprot.writeFieldBegin('dependentClone', TType.BOOL, 7)
            oprot.writeBool(self.dependentClone)
            oprot.writeFieldEnd()
        if self.attachments is not None:
            oprot.writeFieldBegin('attachments', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.attachments))
            for _iter39 in self.attachments:
                _iter39.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.categories is not None:
            oprot.writeFieldBegin('categories', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.categories))
            for _iter40 in self.categories:
                _iter40.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastUsedAt is not None:
            oprot.writeFieldBegin('lastUsedAt', TType.I64, 10)
            oprot.writeI64(self.lastUsedAt)
            oprot.writeFieldEnd()
        if self.usageCount is not None:
            oprot.writeFieldBegin('usageCount', TType.I32, 11)
            oprot.writeI32(self.usageCount)
            oprot.writeFieldEnd()
        if self.associatedWorkflows is not None:
            oprot.writeFieldBegin('associatedWorkflows', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.associatedWorkflows))
            for _iter41 in self.associatedWorkflows:
                _iter41.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.globalTemplate is not None:
            oprot.writeFieldBegin('globalTemplate', TType.BOOL, 13)
            oprot.writeBool(self.globalTemplate)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 14)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 15)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 16)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 17)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 18)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BulkMessage(object):
    """
    Attributes:
     - id
     - accountId
     - status
     - subject
     - body
     - messages
     - createdAt
     - recipients
     - shouldProcessMessage
     - messageTemplateId
     - scheduledAt
     - processedAt
     - updatedAt
     - openPercentage
     - clickPercentage
     - replyPercentage
     - attachments
     - clickTrackingEnabled
     - openTrackingEnabled
     - responseTrackingEnabled
     - globalRecipients
     - account
     - sentFrom
     - senderIdentity
     - nonTransactionalEmail
     - deliverableType
     - emailTags
     - previewText
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'accountId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'status', None, None, ),  # 3
        (4, TType.STRING, 'subject', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'body', 'UTF8', None, ),  # 5
        (6, TType.MAP, 'messages', (TType.STRING, 'UTF8', TType.STRUCT, (BulkMessageData, BulkMessageData.thrift_spec), False), None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.STRING, 'recipients', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'shouldProcessMessage', None, None, ),  # 9
        (10, TType.STRING, 'messageTemplateId', 'UTF8', None, ),  # 10
        (11, TType.I64, 'scheduledAt', None, None, ),  # 11
        (12, TType.I64, 'processedAt', None, None, ),  # 12
        (13, TType.I64, 'updatedAt', None, None, ),  # 13
        (14, TType.DOUBLE, 'openPercentage', None, None, ),  # 14
        (15, TType.DOUBLE, 'clickPercentage', None, None, ),  # 15
        (16, TType.DOUBLE, 'replyPercentage', None, None, ),  # 16
        (17, TType.LIST, 'attachments', (TType.STRUCT, (MessageAttachment, MessageAttachment.thrift_spec), False), None, ),  # 17
        (18, TType.BOOL, 'clickTrackingEnabled', None, None, ),  # 18
        (19, TType.BOOL, 'openTrackingEnabled', None, None, ),  # 19
        (20, TType.BOOL, 'responseTrackingEnabled', None, None, ),  # 20
        (21, TType.LIST, 'globalRecipients', (TType.STRUCT, (BulkMessageRecipient, BulkMessageRecipient.thrift_spec), False), None, ),  # 21
        (22, TType.STRUCT, 'account', (AccountShallow, AccountShallow.thrift_spec), None, ),  # 22
        (23, TType.STRING, 'sentFrom', 'UTF8', None, ),  # 23
        (24, TType.STRUCT, 'senderIdentity', (gen.urbancompass.email_campaign.models.ttypes.SenderIdentity, gen.urbancompass.email_campaign.models.ttypes.SenderIdentity.thrift_spec), None, ),  # 24
        (25, TType.BOOL, 'nonTransactionalEmail', None, None, ),  # 25
        (26, TType.I32, 'deliverableType', None, None, ),  # 26
        (27, TType.LIST, 'emailTags', (TType.STRING, 'UTF8', False), None, ),  # 27
        (28, TType.STRING, 'previewText', 'UTF8', None, ),  # 28
    )
    def __init__(self, id=None, accountId=None, status=None, subject=None, body=None, messages=None, createdAt=None, recipients=None, shouldProcessMessage=None, messageTemplateId=None, scheduledAt=None, processedAt=None, updatedAt=None, openPercentage=None, clickPercentage=None, replyPercentage=None, attachments=None, clickTrackingEnabled=None, openTrackingEnabled=None, responseTrackingEnabled=None, globalRecipients=None, account=None, sentFrom=None, senderIdentity=None, nonTransactionalEmail=None, deliverableType=None, emailTags=None, previewText=None, ):
        self.id = id
        self.accountId = accountId
        self.status = status
        self.subject = subject
        self.body = body
        self.messages = messages
        self.createdAt = createdAt
        self.recipients = recipients
        self.shouldProcessMessage = shouldProcessMessage
        self.messageTemplateId = messageTemplateId
        self.scheduledAt = scheduledAt
        self.processedAt = processedAt
        self.updatedAt = updatedAt
        self.openPercentage = openPercentage
        self.clickPercentage = clickPercentage
        self.replyPercentage = replyPercentage
        self.attachments = attachments
        self.clickTrackingEnabled = clickTrackingEnabled
        self.openTrackingEnabled = openTrackingEnabled
        self.responseTrackingEnabled = responseTrackingEnabled
        self.globalRecipients = globalRecipients
        self.account = account
        self.sentFrom = sentFrom
        self.senderIdentity = senderIdentity
        self.nonTransactionalEmail = nonTransactionalEmail
        self.deliverableType = deliverableType
        self.emailTags = emailTags
        self.previewText = previewText

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.accountId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.MAP:
                    self.messages = {}
                    (_ktype43, _vtype44, _size47) = iprot.readMapBegin()
                    for _i42 in range(_size47):
                        _key45 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val46 = BulkMessageData()
                        _val46.read(iprot)
                        self.messages[_key45] = _val46
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.recipients = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.shouldProcessMessage = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.messageTemplateId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.scheduledAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.processedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.openPercentage = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.DOUBLE:
                    self.clickPercentage = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.replyPercentage = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.attachments = []
                    (_etype48, _size51) = iprot.readListBegin()
                    for _i49 in range(_size51):
                        _elem50 = MessageAttachment()
                        _elem50.read(iprot)
                        self.attachments.append(_elem50)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.clickTrackingEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.openTrackingEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.BOOL:
                    self.responseTrackingEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.globalRecipients = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = BulkMessageRecipient()
                        _elem54.read(iprot)
                        self.globalRecipients.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRUCT:
                    self.account = AccountShallow()
                    self.account.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.sentFrom = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.senderIdentity = gen.urbancompass.email_campaign.models.ttypes.SenderIdentity()
                    self.senderIdentity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.BOOL:
                    self.nonTransactionalEmail = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I32:
                    self.deliverableType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.LIST:
                    self.emailTags = []
                    (_etype56, _size59) = iprot.readListBegin()
                    for _i57 in range(_size59):
                        _elem58 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emailTags.append(_elem58)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.previewText = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkMessage')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.accountId is not None:
            oprot.writeFieldBegin('accountId', TType.STRING, 2)
            oprot.writeString(self.accountId.encode('utf-8') if sys.version_info[0] == 2 else self.accountId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 3)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 4)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 5)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        if self.messages is not None:
            oprot.writeFieldBegin('messages', TType.MAP, 6)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.messages))
            for _kiter60, _viter61 in self.messages.items():
                oprot.writeString(_kiter60.encode('utf-8') if sys.version_info[0] == 2 else _kiter60)
                _viter61.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.recipients is not None:
            oprot.writeFieldBegin('recipients', TType.STRING, 8)
            oprot.writeString(self.recipients.encode('utf-8') if sys.version_info[0] == 2 else self.recipients)
            oprot.writeFieldEnd()
        if self.shouldProcessMessage is not None:
            oprot.writeFieldBegin('shouldProcessMessage', TType.BOOL, 9)
            oprot.writeBool(self.shouldProcessMessage)
            oprot.writeFieldEnd()
        if self.messageTemplateId is not None:
            oprot.writeFieldBegin('messageTemplateId', TType.STRING, 10)
            oprot.writeString(self.messageTemplateId.encode('utf-8') if sys.version_info[0] == 2 else self.messageTemplateId)
            oprot.writeFieldEnd()
        if self.scheduledAt is not None:
            oprot.writeFieldBegin('scheduledAt', TType.I64, 11)
            oprot.writeI64(self.scheduledAt)
            oprot.writeFieldEnd()
        if self.processedAt is not None:
            oprot.writeFieldBegin('processedAt', TType.I64, 12)
            oprot.writeI64(self.processedAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 13)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.openPercentage is not None:
            oprot.writeFieldBegin('openPercentage', TType.DOUBLE, 14)
            oprot.writeDouble(self.openPercentage)
            oprot.writeFieldEnd()
        if self.clickPercentage is not None:
            oprot.writeFieldBegin('clickPercentage', TType.DOUBLE, 15)
            oprot.writeDouble(self.clickPercentage)
            oprot.writeFieldEnd()
        if self.replyPercentage is not None:
            oprot.writeFieldBegin('replyPercentage', TType.DOUBLE, 16)
            oprot.writeDouble(self.replyPercentage)
            oprot.writeFieldEnd()
        if self.attachments is not None:
            oprot.writeFieldBegin('attachments', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.attachments))
            for _iter62 in self.attachments:
                _iter62.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.clickTrackingEnabled is not None:
            oprot.writeFieldBegin('clickTrackingEnabled', TType.BOOL, 18)
            oprot.writeBool(self.clickTrackingEnabled)
            oprot.writeFieldEnd()
        if self.openTrackingEnabled is not None:
            oprot.writeFieldBegin('openTrackingEnabled', TType.BOOL, 19)
            oprot.writeBool(self.openTrackingEnabled)
            oprot.writeFieldEnd()
        if self.responseTrackingEnabled is not None:
            oprot.writeFieldBegin('responseTrackingEnabled', TType.BOOL, 20)
            oprot.writeBool(self.responseTrackingEnabled)
            oprot.writeFieldEnd()
        if self.globalRecipients is not None:
            oprot.writeFieldBegin('globalRecipients', TType.LIST, 21)
            oprot.writeListBegin(TType.STRUCT, len(self.globalRecipients))
            for _iter63 in self.globalRecipients:
                _iter63.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.account is not None:
            oprot.writeFieldBegin('account', TType.STRUCT, 22)
            self.account.write(oprot)
            oprot.writeFieldEnd()
        if self.sentFrom is not None:
            oprot.writeFieldBegin('sentFrom', TType.STRING, 23)
            oprot.writeString(self.sentFrom.encode('utf-8') if sys.version_info[0] == 2 else self.sentFrom)
            oprot.writeFieldEnd()
        if self.senderIdentity is not None:
            oprot.writeFieldBegin('senderIdentity', TType.STRUCT, 24)
            self.senderIdentity.write(oprot)
            oprot.writeFieldEnd()
        if self.nonTransactionalEmail is not None:
            oprot.writeFieldBegin('nonTransactionalEmail', TType.BOOL, 25)
            oprot.writeBool(self.nonTransactionalEmail)
            oprot.writeFieldEnd()
        if self.deliverableType is not None:
            oprot.writeFieldBegin('deliverableType', TType.I32, 26)
            oprot.writeI32(self.deliverableType)
            oprot.writeFieldEnd()
        if self.emailTags is not None:
            oprot.writeFieldBegin('emailTags', TType.LIST, 27)
            oprot.writeListBegin(TType.STRING, len(self.emailTags))
            for _iter64 in self.emailTags:
                oprot.writeString(_iter64.encode('utf-8') if sys.version_info[0] == 2 else _iter64)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.previewText is not None:
            oprot.writeFieldBegin('previewText', TType.STRING, 28)
            oprot.writeString(self.previewText.encode('utf-8') if sys.version_info[0] == 2 else self.previewText)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
