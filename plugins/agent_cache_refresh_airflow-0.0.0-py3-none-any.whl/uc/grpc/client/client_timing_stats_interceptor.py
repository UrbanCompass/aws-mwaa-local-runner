# -*- coding: utf-8 -*-
"""
Interceptor that times outgoing RPCs with monitoring timers

Also propagate RPC timeout to metadata

:copyright: (c) 2018 by UrbanCompass, Inc.
"""
import grpc
from grpc._interceptor import _ClientCallDetails

from uc.base.monitoring.monitoring import timer


class ClientTimingStatsInterceptor(grpc.UnaryUnaryClientInterceptor):
    def __init__(self, timer_log_level, log_threshold_ms):
        self.timer_log_level = timer_log_level
        self.log_threshold_ms = log_threshold_ms

    def intercept_unary_unary(self, continuation, client_call_details, request):
        method_name_with_prefix = "{}{}".format(
            "grpc.client", client_call_details.method.replace("/", ".")
        )
        t = timer(
            method_name_with_prefix + ".elapsed.timer",
            log_level=self.timer_log_level or "WARN",
            log_threshold=self.log_threshold_ms,
            with_logging=True,
        )
        client_call_details = _ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            client_call_details.metadata,
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            client_call_details.compression,
        )
        t.start()
        response = continuation(client_call_details, request)
        t.stop()
        return response
