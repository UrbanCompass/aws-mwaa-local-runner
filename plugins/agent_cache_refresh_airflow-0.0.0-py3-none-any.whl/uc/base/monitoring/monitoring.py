# -*- coding: utf-8 -*-
"""
Monitoring

    Enables us to log metrics to Datadog

    Example usage:
    # foo.py

    from base.monitoring import counter, gauge, timer
    # Module metrics
    my_counter = counter('foo.counter').increment() # foo.counter = 1
    my_gauge = gauge('foo.my_gauge)
    my_gauge.set(10) # foo.my_gauge = 10

    # method metrics
    def counter_example():
      counter('foo.counter').increment()

    def gauge_example():
      value = 3.14

      gauge('foo').set(value, subname='pi') # 'foo.pi' = 3.14

    def timer_example():
      my_timer = timer('foo')
      my_timer.start()
      my_timer.stop()


    ### You can also decorate methods like so:

    method_timer = timer('foo')

    @method_timer.decorate
    def method_to_time():
    ...

Notice that the monitoring module must be initialized using command line arguments.
This typically happens as part of using the standard Compass python app:
  base.app.run(main)

In the (remote) case that calls to monitoring primitives happen before monitoring
has been initialized, those calls will result in ERROR level log messages.

:copyright: (c) 2014 by Urban Compass, Inc.
"""

import collections
import contextlib
import copy
import logging
import re
import threading
import time

from uc.base.monitoring.dd_statsd import StatsD
from uc.base.monitoring import annotations
from uc.base.monitoring import counters
from uc.base.monitoring import gauges
from uc.base.monitoring import timers

PERIOD_DEFAULT = 60  # The default reporting period for aggregation, in seconds
AGGREGATE_METHODS = {
    "SUM": "sum",
    "AVERAGE": "average",
    "COUNT": "count",
    "MIN": "min",
    "MAX": "max",
}


def add_args(parser):
    datadog_args = parser.add_argument_group("Datadog args")
    datadog_args.add_argument(
        "--port_to_datadog",
        action="store_true",
        help="Whether or not to send monitors.py-style metrics to Datadog",
    )
    datadog_args.add_argument(
        "--datadog_agent_host",
        default="localhost",
        help="Datadog agent host to send metrics to " "(default: %(default)r)",
    )

    monitoring_args = parser.add_argument_group("Monitoring args")
    monitoring_args.add_argument(
        "--metrics_logging_log_level",
        default="DEBUG",
        choices=["WARN", "INFO", "DEBUG"],
        help="Log level to log metrics at. (default: %(default)r)",
    )
    monitoring_args.add_argument(
        "--ignore_runtime_annotations",
        default=False,
        help="Whether we should not create runtime annotations",
    )
    monitoring_args.add_argument(
        "--polling_interval_in_seconds",
        default=10,
        type=int,
        help="How often to emit that the app is running.",
    )


def init(options, app_name, app_host, env, instance_purpose, instance_id):
    """Initialize monitoring from command line options.

    :param options: the parsed command line options.
    :param app_name: the name of this app.
    :param host: the name of this host.
    """
    global _MONITORING_STATE
    global _MONITOR_FACTORY
    _MONITORING_STATE = MonitoringState()
    _MONITOR_FACTORY = MonitorFactory(
        app_name,
        app_host,
        environment=env,
        instance_purpose=instance_purpose,
        instance_id=instance_id,
        monitoring_state=_MONITORING_STATE,
        log_level=options.metrics_logging_log_level,
        datadog_enabled=options.port_to_datadog,
        datadog_agent_host=options.datadog_agent_host,
    )
    _report_application_status(options.polling_interval_in_seconds)


def _report_application_status(polling_interval_in_seconds):
    def _emit_forever():
        running_status = _MONITOR_FACTORY.gauge(
            "",
            {
                "period": PERIOD_DEFAULT,
                "aggregate": True,
                "aggregate_method": AGGREGATE_METHODS["MAX"],
            },
        )
        while True:
            running_status.set(1, "running")
            time.sleep(polling_interval_in_seconds)

    t = threading.Thread(target=_emit_forever)
    t.daemon = True
    t.start()


class MonitoringState(object):
    """
    The current state of all the exported variables.

    This class is thread safe.
    """

    def __init__(self):
        self._gauges_lock = threading.Lock()
        self._counters_lock = threading.Lock()
        self._annotations_lock = threading.Lock()
        with self._gauges_lock:
            self._gauges = {}
        with self._counters_lock:
            self._counters = collections.defaultdict(int)

    def record_gauge(self, name, value):
        if name is not None:
            with self._gauges_lock:
                self._gauges[name] = value

    def get_counter(self, name):
        if name is not None:
            with self._counters_lock:
                return self._counters[name]

    def increment_counter(self, name, delta):
        if name is not None:
            with self._counters_lock:
                self._counters[name] += delta
                return self._counters[name]

    def get_state(self):
        """Get the current state of all the collected data."""
        with self._gauges_lock:
            gauges = copy.copy(self._gauges)
        with self._counters_lock:
            counters = copy.copy(self._counters)
        return {"gauges": gauges, "counters": counters}

    def create_gauge_reporter(self, name):
        class GaugeReporter(gauges.GaugeReporter):
            def report_gauge(inner_self, value, subname, name=name):
                full_name = ".".join([_f for _f in [name, subname] if _f])
                self.record_gauge(full_name, value)

        return GaugeReporter()

    def create_counter_reporter(self, name):
        class CounterReporter(counters.CounterReporter):
            def report_increment(inner_self, delta, count, name=name):
                # Notice that it is fully acceptable if we do not agree with the
                # counter on the absolute value of count, and delta is the only one
                # that matters.
                self.increment_counter(name, delta)

        return CounterReporter()

    def create_timer_reporter(self, name):
        class TimerReporter(timers.TimerReporter):
            def _send(inner_self, subname, delta_ms, t, name=name):
                full_name = ".".join([_f for _f in [name, subname] if _f])
                self.record_gauge(full_name, delta_ms)

        return TimerReporter()


# Regexps for sanitize_name
_SANITIZE_SPECIAL_CHARS_RE = re.compile("[^0-9a-zA-Z.:\\-_]+")
_DROP_TRAILING_UNDERSCORES_RE = re.compile("_+$")


class MonitorFactory(object):
    """Class for producing counters based on command line flags."""

    def __init__(
        self,
        app_name,
        app_host,
        environment,
        monitoring_state,
        log_level,
        instance_purpose=None,
        instance_id=None,
        datadog_enabled=False,
        datadog_agent_host=None,
        default_with_logging=False,
    ):
        self._monitoring_state = monitoring_state
        self.log_level = log_level
        self._default_with_logging = default_with_logging
        self.app_name = app_name
        self.metric_prefix = app_host
        self.datadog_enabled = datadog_enabled
        self.instance_id = instance_id  # TODO: Support i-INSTANCE_ID format
        self.instance_purpose = instance_purpose
        self.environment = environment

        """
    This used to take a metric_prefix and an app_name.

    Therefore, we need to be backwards compatible with source and app_name splitting

    Historical values:
    Code line:
    print source, app_name, metric_prefix

    Results from development and a staging machine (Prod patterns after staging)
    development.identity.auth_server identity.auth_server development
    staging.packer.0927081074d4af8bd.packer.build_amis_job packer.build_amis_job staging.packer.0927081074d4af8bd  # noqa
    """
        if self.datadog_enabled:
            # No need to tag host, env here since the Datadog agent will do it
            tags = {
                "service": app_name,
                "instance_id": instance_id,
                "instance_purpose": instance_purpose,
            }
            logging.warn(
                "Configuring datadog agent statsd to use hostname: {}".format(datadog_agent_host)
            )
            # Don't apply any prefixes by default
            self.dd_statsd_client = StatsD(datadog_agent_host, tags=tags, prefix=None)

    @classmethod
    def sanitize_name(cls, name):
        """Sanitize a name for use as a metric name."""
        return _DROP_TRAILING_UNDERSCORES_RE.sub("", _SANITIZE_SPECIAL_CHARS_RE.sub("_", name))

    def shutdown(self, timeout_in_seconds):
        pass

    def full_name(self, name):
        name_parts = (
            self.environment,
            self.instance_purpose,
            self.instance_id,
            self.app_name,
            name,
        )
        return ".".join(part for part in name_parts if part)

    def counter(self, name, metric_options=None, tags=None):
        """(See top level counter() docstring)"""
        full_name = self.full_name(name)
        reporters = [
            self._monitoring_state.create_counter_reporter(full_name),
            counters.LoggingCounterReporter(full_name, self.log_level),
        ]
        if self.datadog_enabled:
            # Ignore metric_options
            reporters.append(
                counters.DatadogCounterReporter(name, self.dd_statsd_client, tags=tags)
            )
        return counters.Counter(name, reporters)

    def gauge(self, name, metric_options=None, tags=None):
        """(See top level gauge() docstring)"""
        full_name = self.full_name(name)
        reporters = [
            self._monitoring_state.create_gauge_reporter(full_name),
            gauges.LoggingGaugeReporter(full_name, self.log_level),
        ]
        if self.datadog_enabled:
            # Ignore metric_options
            reporters.append(gauges.DatadogGaugeReporter(name, self.dd_statsd_client, tags=tags))
        return gauges.Gauge(name, reporters)

    def annotation(self, name, title, desc):
        full_name = self.full_name(name)
        reporters = list()
        reporters.append(annotations.LoggingAnnotationReporter(full_name, self.log_level))
        return annotations.Annotation(name, reporters)

    def _timer(
        self,
        timer_class,
        name,
        with_logging,
        metric_options=None,
        log_level=None,
        log_threshold_ms=1000,
        tags=None,
    ):
        full_name = self.full_name(name)
        reporters = [
            self._monitoring_state.create_timer_reporter(full_name),
        ]
        if with_logging or (with_logging is None and self._default_with_logging):
            reporters.append(
                timers.LoggingTimerReporter(
                    name, log_level or self.log_level, threshold_ms=log_threshold_ms
                )
            )
        if self.datadog_enabled:
            # Ignore metric_options
            reporters.append(timers.DatadogTimerReporter(name, self.dd_statsd_client, tags=tags))
        return timer_class(name, reporters)

    def timer(
        self,
        name,
        with_logging=None,
        metric_options=None,
        log_level=None,
        log_threshold=1000,
        tags=None,
    ):
        """(See top level timer() docstring)"""
        return self._timer(
            timers.Timer,
            name,
            with_logging,
            metric_options,
            log_level,
            log_threshold_ms=log_threshold,
            tags=tags,
        )

    def timer_with_subtimers(
        self, name, with_logging=None, metric_options=None, log_level=None, log_threshold=1000
    ):
        return self._timer(
            timers.TimerWithSubtimers, name, with_logging, metric_options, log_level, log_threshold
        )


sanitize_name = MonitorFactory.sanitize_name


def counter(name, period=PERIOD_DEFAULT, do_service_side_aggregation=True, tags=None):
    """Create a counter object

    :param period
    :param do_service_side_aggregation
    :param tags: a dict(str, str) of tags to apply to the metric.
      Tag keys and values can't have spaces
    """
    metric_options = {
        "period": period,
        "aggregate": do_service_side_aggregation,
        "aggregate_method": AGGREGATE_METHODS["SUM"],
    }
    return _MONITOR_FACTORY.counter(name, metric_options, tags=tags)


def gauge(
    name,
    period=PERIOD_DEFAULT,
    do_service_side_aggregation=True,
    aggregate_method=AGGREGATE_METHODS["AVERAGE"],
    tags=None,
):
    """Create a gauge object

    :param period
    :param do_service_side_aggregation
    :param tags: a dict(str, str) of tags to apply to the metric.
      Tag keys and values can't have spaces
    """
    metric_options = {
        "period": period,
        "aggregate": do_service_side_aggregation,
        "aggregate_method": aggregate_method,
    }
    return _MONITOR_FACTORY.gauge(name, metric_options, tags=tags)


def timer(
    name, with_logging=None, period=PERIOD_DEFAULT, log_level="WARN", log_threshold=1000, tags=None
):
    """Create a timer object

    :param period
    :param do_service_side_aggregation
    :param tags: a dict(str, str) of tags to apply to the metric.
      Tag keys and values can't have spaces
    """
    metric_options = {"period": period}
    return _MONITOR_FACTORY.timer(
        name,
        with_logging=with_logging,
        metric_options=metric_options,
        log_level=log_level,
        log_threshold=log_threshold,
        tags=tags,
    )


def timer_with_subtimers(
    name, with_logging=None, period=PERIOD_DEFAULT, log_level="WARN", log_threshold=1000
):
    """Doesn't work w/ Datadog"""
    metric_options = {"period": period}
    return _MONITOR_FACTORY.timer_with_subtimers(
        name,
        with_logging=with_logging,
        metric_options=metric_options,
        log_level=log_level,
        log_threshold=log_threshold,
    )


def annotation(name, title, desc=""):
    return _MONITOR_FACTORY.annotation(name, title, desc)


def get_monitoring_state():
    """Get a json dict representing the current state of all our exported vars."""
    return _MONITORING_STATE.get_state()


def shutdown(timeout_in_seconds=10):
    """
    Gracefully exit all background threads associated with our Monitoring

    :param timeout_in_seconds: How long to wait for background threads to shutdown
    """
    if not _MONITOR_FACTORY:
        logging.warn("Can not shutdown monitoring before monitoring module is configured")
    else:
        _MONITOR_FACTORY.shutdown(timeout_in_seconds)


# We use a reentrant lock to allow nested calls to use_fake_monitoring_for_test.
# OTOH this means that that contextmanager needs to be entered and exited in the
# same thread.
_USE_ONE_FAKE_AT_THE_TIME = threading.RLock()


@contextlib.contextmanager
def use_fake_monitoring_for_test():
    """A contextmanager for testing code that relies on monitoring.

    Use this function as:

      def test_my_feature(self):
        with use_fake_monitoring_for_test():
          # test that relies on monitoring

    Or, to use fake monitoring for all test cases in a class:

      class MyTest(test_case.UCTestCase):
        def setUp(self):
          super(MyTest, self).setUp()
          patch = use_fake_monitoring_for_test()
          patch.__enter__()
          self.addCleanup(patch.__exit__, None, None, None)
    """
    global _MONITOR_FACTORY
    global _MONITORING_STATE
    with _USE_ONE_FAKE_AT_THE_TIME:
        old_values = _MONITOR_FACTORY, _MONITORING_STATE
        try:
            _MONITORING_STATE = MonitoringState()
            _MONITOR_FACTORY = MonitorFactory(
                "Fake Monitoring",
                "test",
                "test",
                instance_purpose="test",
                instance_id="test_id",
                monitoring_state=_MONITORING_STATE,
                default_with_logging=True,
                log_level="INFO",
            )
            yield
        finally:
            _MONITOR_FACTORY, _MONITORING_STATE = old_values


# By default, we create a MonitorFactory that logs to error.
# These will be replaced by well-initialized objects in the call to
# init(...).
_MONITORING_STATE = MonitoringState()


def _MONITOR_FACTORY_WITH_LOGLEVEL(log_level):
    return MonitorFactory(
        "not_initialized_app",
        "unknown_host",
        "default",
        instance_purpose="default_purpose",
        instance_id="unknown_instance_id",
        monitoring_state=_MONITORING_STATE,
        default_with_logging=True,
        log_level=log_level,
    )


_MONITOR_FACTORY = _MONITOR_FACTORY_WITH_LOGLEVEL("ERROR")


def get_monitoring_factory():
    if not _MONITOR_FACTORY:
        raise ValueError("Please call monitoring.init() before using this factory!")
    return _MONITOR_FACTORY
