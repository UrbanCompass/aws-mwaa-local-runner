
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.listing.listing_pipeline.ttypes

from thrift.transport import TTransport


class DataUpdateSource(object):
    LISTING_UPDATE = 0
    IMAGE_UPDATE = 1
    NON_IMAGE_MEDIA_UPDATE = 2
    GEOCODING_UPDATE = 3
    PUBLIC_RECORD_UPDATE = 4
    BUILDING_UPDATE = 5
    PATCH_UPDATE = 6
    MANUAL_ENRICHMENT_UPDATE = 7

    _VALUES_TO_NAMES = {
        0: "LISTING_UPDATE",
        1: "IMAGE_UPDATE",
        2: "NON_IMAGE_MEDIA_UPDATE",
        3: "GEOCODING_UPDATE",
        4: "PUBLIC_RECORD_UPDATE",
        5: "BUILDING_UPDATE",
        6: "PATCH_UPDATE",
        7: "MANUAL_ENRICHMENT_UPDATE",
    }

    _NAMES_TO_VALUES = {
        "LISTING_UPDATE": 0,
        "IMAGE_UPDATE": 1,
        "NON_IMAGE_MEDIA_UPDATE": 2,
        "GEOCODING_UPDATE": 3,
        "PUBLIC_RECORD_UPDATE": 4,
        "BUILDING_UPDATE": 5,
        "PATCH_UPDATE": 6,
        "MANUAL_ENRICHMENT_UPDATE": 7,
    }


class EntityType(object):
    TRANSACTION = 0
    BUILDING = 1
    LISTING = 2
    IMAGE = 3
    NON_IMAGE_MEDIA = 4
    PROPERTY = 5
    GEOCODING = 6
    PATCH = 7
    LISTING_TO_BE_AGGREGATED = 8
    SCHOOL = 9
    ENRICHED_LISTING = 10
    AGENT_INFO = 11

    _VALUES_TO_NAMES = {
        0: "TRANSACTION",
        1: "BUILDING",
        2: "LISTING",
        3: "IMAGE",
        4: "NON_IMAGE_MEDIA",
        5: "PROPERTY",
        6: "GEOCODING",
        7: "PATCH",
        8: "LISTING_TO_BE_AGGREGATED",
        9: "SCHOOL",
        10: "ENRICHED_LISTING",
        11: "AGENT_INFO",
    }

    _NAMES_TO_VALUES = {
        "TRANSACTION": 0,
        "BUILDING": 1,
        "LISTING": 2,
        "IMAGE": 3,
        "NON_IMAGE_MEDIA": 4,
        "PROPERTY": 5,
        "GEOCODING": 6,
        "PATCH": 7,
        "LISTING_TO_BE_AGGREGATED": 8,
        "SCHOOL": 9,
        "ENRICHED_LISTING": 10,
        "AGENT_INFO": 11,
    }


class Priority(object):
    URGENT = 0
    IMPORTANT = 1
    NOT_IMPORTANT = 2

    _VALUES_TO_NAMES = {
        0: "URGENT",
        1: "IMPORTANT",
        2: "NOT_IMPORTANT",
    }

    _NAMES_TO_VALUES = {
        "URGENT": 0,
        "IMPORTANT": 1,
        "NOT_IMPORTANT": 2,
    }


class UpdateMode(object):
    INCREMENTAL = 0
    NON_INCREMENTAL = 1
    DELETE = 2
    UPSERT = 3

    _VALUES_TO_NAMES = {
        0: "INCREMENTAL",
        1: "NON_INCREMENTAL",
        2: "DELETE",
        3: "UPSERT",
    }

    _NAMES_TO_VALUES = {
        "INCREMENTAL": 0,
        "NON_INCREMENTAL": 1,
        "DELETE": 2,
        "UPSERT": 3,
    }


class DataUpdateKafkaValue(object):
    """
    Attributes:
     - entityId
     - entityType
     - priority
     - timestamp
     - version
     - geoId
     - listingDataUpdateSource
     - payload
     - updateMode
     - primaryListing
     - hydration
     - traceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'entityId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'entityType', None, None, ),  # 2
        (3, TType.I32, 'priority', None, None, ),  # 3
        (4, TType.I64, 'timestamp', None, None, ),  # 4
        (5, TType.I32, 'version', None, None, ),  # 5
        (6, TType.STRING, 'geoId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'listingDataUpdateSource', None, None, ),  # 7
        (8, TType.STRING, 'payload', 'UTF8', None, ),  # 8
        (9, TType.I32, 'updateMode', None, None, ),  # 9
        (10, TType.BOOL, 'primaryListing', None, None, ),  # 10
        (11, TType.BOOL, 'hydration', None, None, ),  # 11
        (12, TType.STRING, 'traceId', 'UTF8', None, ),  # 12
    )
    def __init__(self, entityId=None, entityType=None, priority=None, timestamp=None, version=None, geoId=None, listingDataUpdateSource=None, payload=None, updateMode=None, primaryListing=None, hydration=None, traceId=None, ):
        self.entityId = entityId
        self.entityType = entityType
        self.priority = priority
        self.timestamp = timestamp
        self.version = version
        self.geoId = geoId
        self.listingDataUpdateSource = listingDataUpdateSource
        self.payload = payload
        self.updateMode = updateMode
        self.primaryListing = primaryListing
        self.hydration = hydration
        self.traceId = traceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.entityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.entityType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.priority = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.listingDataUpdateSource = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.payload = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.updateMode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.primaryListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.hydration = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.traceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DataUpdateKafkaValue')
        if self.entityId is not None:
            oprot.writeFieldBegin('entityId', TType.STRING, 1)
            oprot.writeString(self.entityId.encode('utf-8') if sys.version_info[0] == 2 else self.entityId)
            oprot.writeFieldEnd()
        if self.entityType is not None:
            oprot.writeFieldBegin('entityType', TType.I32, 2)
            oprot.writeI32(self.entityType)
            oprot.writeFieldEnd()
        if self.priority is not None:
            oprot.writeFieldBegin('priority', TType.I32, 3)
            oprot.writeI32(self.priority)
            oprot.writeFieldEnd()
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 4)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 5)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 6)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.listingDataUpdateSource is not None:
            oprot.writeFieldBegin('listingDataUpdateSource', TType.I32, 7)
            oprot.writeI32(self.listingDataUpdateSource)
            oprot.writeFieldEnd()
        if self.payload is not None:
            oprot.writeFieldBegin('payload', TType.STRING, 8)
            oprot.writeString(self.payload.encode('utf-8') if sys.version_info[0] == 2 else self.payload)
            oprot.writeFieldEnd()
        if self.updateMode is not None:
            oprot.writeFieldBegin('updateMode', TType.I32, 9)
            oprot.writeI32(self.updateMode)
            oprot.writeFieldEnd()
        if self.primaryListing is not None:
            oprot.writeFieldBegin('primaryListing', TType.BOOL, 10)
            oprot.writeBool(self.primaryListing)
            oprot.writeFieldEnd()
        if self.hydration is not None:
            oprot.writeFieldBegin('hydration', TType.BOOL, 11)
            oprot.writeBool(self.hydration)
            oprot.writeFieldEnd()
        if self.traceId is not None:
            oprot.writeFieldBegin('traceId', TType.STRING, 12)
            oprot.writeString(self.traceId.encode('utf-8') if sys.version_info[0] == 2 else self.traceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EnrichedListingMessage(object):
    """
    Attributes:
     - listingId
     - updateMode
     - timestamp
     - listingRevision
     - priority
     - traceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'updateMode', None, None, ),  # 2
        (3, TType.I64, 'timestamp', None, None, ),  # 3
        (4, TType.STRUCT, 'listingRevision', (gen.urbancompass.listing.listing_pipeline.ttypes.ListingRevision, gen.urbancompass.listing.listing_pipeline.ttypes.ListingRevision.thrift_spec), None, ),  # 4
        (5, TType.I32, 'priority', None, None, ),  # 5
        (6, TType.STRING, 'traceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, listingId=None, updateMode=None, timestamp=None, listingRevision=None, priority=None, traceId=None, ):
        self.listingId = listingId
        self.updateMode = updateMode
        self.timestamp = timestamp
        self.listingRevision = listingRevision
        self.priority = priority
        self.traceId = traceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.updateMode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.listingRevision = gen.urbancompass.listing.listing_pipeline.ttypes.ListingRevision()
                    self.listingRevision.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.priority = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.traceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichedListingMessage')
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 1)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.updateMode is not None:
            oprot.writeFieldBegin('updateMode', TType.I32, 2)
            oprot.writeI32(self.updateMode)
            oprot.writeFieldEnd()
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 3)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.listingRevision is not None:
            oprot.writeFieldBegin('listingRevision', TType.STRUCT, 4)
            self.listingRevision.write(oprot)
            oprot.writeFieldEnd()
        if self.priority is not None:
            oprot.writeFieldBegin('priority', TType.I32, 5)
            oprot.writeI32(self.priority)
            oprot.writeFieldEnd()
        if self.traceId is not None:
            oprot.writeFieldBegin('traceId', TType.STRING, 6)
            oprot.writeString(self.traceId.encode('utf-8') if sys.version_info[0] == 2 else self.traceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DataUpdateKafkaMessage(object):
    """
    Attributes:
     - key
     - value
     - context
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'key', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'value', (DataUpdateKafkaValue, DataUpdateKafkaValue.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'context', 'UTF8', None, ),  # 3
    )
    def __init__(self, key=None, value=None, context=None, ):
        self.key = key
        self.value = value
        self.context = context

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.key = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.value = DataUpdateKafkaValue()
                    self.value.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.context = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DataUpdateKafkaMessage')
        if self.key is not None:
            oprot.writeFieldBegin('key', TType.STRING, 1)
            oprot.writeString(self.key.encode('utf-8') if sys.version_info[0] == 2 else self.key)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRUCT, 2)
            self.value.write(oprot)
            oprot.writeFieldEnd()
        if self.context is not None:
            oprot.writeFieldBegin('context', TType.STRING, 3)
            oprot.writeString(self.context.encode('utf-8') if sys.version_info[0] == 2 else self.context)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
