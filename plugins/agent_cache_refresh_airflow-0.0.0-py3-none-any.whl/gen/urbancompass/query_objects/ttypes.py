
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class FakeEnum(object):
    NUM1 = 0
    NUM2 = 1
    NUM3 = 2

    _VALUES_TO_NAMES = {
        0: "NUM1",
        1: "NUM2",
        2: "NUM3",
    }

    _NAMES_TO_VALUES = {
        "NUM1": 0,
        "NUM2": 1,
        "NUM3": 2,
    }


class FakeObjectsOfVariousTypesOfFields(object):
    """
    Attributes:
     - stringField
     - intField
     - bigIntField
     - floatField
     - boolField
     - enumField
     - jsonStringField
     - listField
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'stringField', 'UTF8', None, ),  # 1
        (2, TType.I32, 'intField', None, None, ),  # 2
        (3, TType.I64, 'bigIntField', None, None, ),  # 3
        (4, TType.DOUBLE, 'floatField', None, None, ),  # 4
        (5, TType.BOOL, 'boolField', None, None, ),  # 5
        (6, TType.I32, 'enumField', None, None, ),  # 6
        (7, TType.STRING, 'jsonStringField', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'listField', (TType.STRING, 'UTF8', False), None, ),  # 8
    )
    def __init__(self, stringField=None, intField=None, bigIntField=None, floatField=None, boolField=None, enumField=None, jsonStringField=None, listField=None, ):
        self.stringField = stringField
        self.intField = intField
        self.bigIntField = bigIntField
        self.floatField = floatField
        self.boolField = boolField
        self.enumField = enumField
        self.jsonStringField = jsonStringField
        self.listField = listField

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.stringField = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.intField = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.bigIntField = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.floatField = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.boolField = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.enumField = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.jsonStringField = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.listField = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listField.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FakeObjectsOfVariousTypesOfFields')
        if self.stringField is not None:
            oprot.writeFieldBegin('stringField', TType.STRING, 1)
            oprot.writeString(self.stringField.encode('utf-8') if sys.version_info[0] == 2 else self.stringField)
            oprot.writeFieldEnd()
        if self.intField is not None:
            oprot.writeFieldBegin('intField', TType.I32, 2)
            oprot.writeI32(self.intField)
            oprot.writeFieldEnd()
        if self.bigIntField is not None:
            oprot.writeFieldBegin('bigIntField', TType.I64, 3)
            oprot.writeI64(self.bigIntField)
            oprot.writeFieldEnd()
        if self.floatField is not None:
            oprot.writeFieldBegin('floatField', TType.DOUBLE, 4)
            oprot.writeDouble(self.floatField)
            oprot.writeFieldEnd()
        if self.boolField is not None:
            oprot.writeFieldBegin('boolField', TType.BOOL, 5)
            oprot.writeBool(self.boolField)
            oprot.writeFieldEnd()
        if self.enumField is not None:
            oprot.writeFieldBegin('enumField', TType.I32, 6)
            oprot.writeI32(self.enumField)
            oprot.writeFieldEnd()
        if self.jsonStringField is not None:
            oprot.writeFieldBegin('jsonStringField', TType.STRING, 7)
            oprot.writeString(self.jsonStringField.encode('utf-8') if sys.version_info[0] == 2 else self.jsonStringField)
            oprot.writeFieldEnd()
        if self.listField is not None:
            oprot.writeFieldBegin('listField', TType.LIST, 8)
            oprot.writeListBegin(TType.STRING, len(self.listField))
            for _iter6 in self.listField:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FakeObjectsOfVariousTypesOfFieldsNotInDb(object):
    """
    Attributes:
     - listEnumField
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listEnumField', (TType.I32, None, False), None, ),  # 1
    )
    def __init__(self, listEnumField=None, ):
        self.listEnumField = listEnumField

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listEnumField = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readI32()
                        self.listEnumField.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FakeObjectsOfVariousTypesOfFieldsNotInDb')
        if self.listEnumField is not None:
            oprot.writeFieldBegin('listEnumField', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.listEnumField))
            for _iter11 in self.listEnumField:
                oprot.writeI32(_iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryFields(object):
    """
    Attributes:
     - namesInThrift
     - columnPart
     - valuePart
     - onConflictPart
     - query
     - updatePart
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'namesInThrift', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'columnPart', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'valuePart', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'onConflictPart', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'query', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'updatePart', 'UTF8', None, ),  # 6
    )
    def __init__(self, namesInThrift=None, columnPart=None, valuePart=None, onConflictPart=None, query=None, updatePart=None, ):
        self.namesInThrift = namesInThrift
        self.columnPart = columnPart
        self.valuePart = valuePart
        self.onConflictPart = onConflictPart
        self.query = query
        self.updatePart = updatePart

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.namesInThrift = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.namesInThrift.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.columnPart = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.valuePart = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.onConflictPart = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.query = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.updatePart = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryFields')
        if self.namesInThrift is not None:
            oprot.writeFieldBegin('namesInThrift', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.namesInThrift))
            for _iter16 in self.namesInThrift:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.columnPart is not None:
            oprot.writeFieldBegin('columnPart', TType.STRING, 2)
            oprot.writeString(self.columnPart.encode('utf-8') if sys.version_info[0] == 2 else self.columnPart)
            oprot.writeFieldEnd()
        if self.valuePart is not None:
            oprot.writeFieldBegin('valuePart', TType.STRING, 3)
            oprot.writeString(self.valuePart.encode('utf-8') if sys.version_info[0] == 2 else self.valuePart)
            oprot.writeFieldEnd()
        if self.onConflictPart is not None:
            oprot.writeFieldBegin('onConflictPart', TType.STRING, 4)
            oprot.writeString(self.onConflictPart.encode('utf-8') if sys.version_info[0] == 2 else self.onConflictPart)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRING, 5)
            oprot.writeString(self.query.encode('utf-8') if sys.version_info[0] == 2 else self.query)
            oprot.writeFieldEnd()
        if self.updatePart is not None:
            oprot.writeFieldBegin('updatePart', TType.STRING, 6)
            oprot.writeString(self.updatePart.encode('utf-8') if sys.version_info[0] == 2 else self.updatePart)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
