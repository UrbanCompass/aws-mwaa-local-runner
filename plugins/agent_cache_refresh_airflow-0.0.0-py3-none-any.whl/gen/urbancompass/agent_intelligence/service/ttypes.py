
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.agent_intelligence.models.ttypes
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.listing.listing_compliance.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes
import gen.urbancompass.user.user.ttypes

from thrift.transport import TTransport


class AddAgentListingsByAddressRequest(object):
    """
    Attributes:
     - id
     - userId
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.agent_intelligence.models.ttypes.ManualClosedDeal, gen.urbancompass.agent_intelligence.models.ttypes.ManualClosedDeal.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, id=None, userId=None, listings=None, ):
        self.id = id
        self.userId = userId
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.agent_intelligence.models.ttypes.ManualClosedDeal()
                        _elem4.read(iprot)
                        self.listings.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddAgentListingsByAddressRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter6 in self.listings:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddAgentListingsByAddressResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddAgentListingsByAddressResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddAgentListingsByIdRequest(object):
    """
    Attributes:
     - id
     - userId
     - listingsIds
     - userType
     - userTypeOverrides
     - closedDealOverrides
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'listingsIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.I32, 'userType', None, None, ),  # 4
        (5, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 5
        (6, TType.STRUCT, 'closedDealOverrides', (gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealOverrides, gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealOverrides.thrift_spec), None, ),  # 6
    )
    def __init__(self, id=None, userId=None, listingsIds=None, userType=None, userTypeOverrides=None, closedDealOverrides=None, ):
        self.id = id
        self.userId = userId
        self.listingsIds = listingsIds
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.closedDealOverrides = closedDealOverrides

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listingsIds = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingsIds.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype12, _vtype13, _size16) = iprot.readMapBegin()
                    for _i11 in range(_size16):
                        _key14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val15 = iprot.readI32()
                        self.userTypeOverrides[_key14] = _val15
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.closedDealOverrides = gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealOverrides()
                    self.closedDealOverrides.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddAgentListingsByIdRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.listingsIds is not None:
            oprot.writeFieldBegin('listingsIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.listingsIds))
            for _iter17 in self.listingsIds:
                oprot.writeString(_iter17.encode('utf-8') if sys.version_info[0] == 2 else _iter17)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 4)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter18, _viter19 in self.userTypeOverrides.items():
                oprot.writeString(_kiter18.encode('utf-8') if sys.version_info[0] == 2 else _kiter18)
                oprot.writeI32(_viter19)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.closedDealOverrides is not None:
            oprot.writeFieldBegin('closedDealOverrides', TType.STRUCT, 6)
            self.closedDealOverrides.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddAgentListingsByIdResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddAgentListingsByIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddTeamListingsByAddressRequest(object):
    """
    Attributes:
     - id
     - userId
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.agent_intelligence.models.ttypes.ManualClosedDeal, gen.urbancompass.agent_intelligence.models.ttypes.ManualClosedDeal.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, id=None, userId=None, listings=None, ):
        self.id = id
        self.userId = userId
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = gen.urbancompass.agent_intelligence.models.ttypes.ManualClosedDeal()
                        _elem22.read(iprot)
                        self.listings.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddTeamListingsByAddressRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter24 in self.listings:
                _iter24.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddTeamListingsByAddressResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddTeamListingsByAddressResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddTeamListingsByIdRequest(object):
    """
    Attributes:
     - id
     - userId
     - listingsIds
     - userType
     - userTypeOverrides
     - closedDealOverrides
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'listingsIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.I32, 'userType', None, None, ),  # 4
        (5, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 5
        (6, TType.STRUCT, 'closedDealOverrides', (gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealOverrides, gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealOverrides.thrift_spec), None, ),  # 6
    )
    def __init__(self, id=None, userId=None, listingsIds=None, userType=None, userTypeOverrides=None, closedDealOverrides=None, ):
        self.id = id
        self.userId = userId
        self.listingsIds = listingsIds
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.closedDealOverrides = closedDealOverrides

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listingsIds = []
                    (_etype25, _size28) = iprot.readListBegin()
                    for _i26 in range(_size28):
                        _elem27 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingsIds.append(_elem27)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype30, _vtype31, _size34) = iprot.readMapBegin()
                    for _i29 in range(_size34):
                        _key32 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val33 = iprot.readI32()
                        self.userTypeOverrides[_key32] = _val33
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.closedDealOverrides = gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealOverrides()
                    self.closedDealOverrides.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddTeamListingsByIdRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.listingsIds is not None:
            oprot.writeFieldBegin('listingsIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.listingsIds))
            for _iter35 in self.listingsIds:
                oprot.writeString(_iter35.encode('utf-8') if sys.version_info[0] == 2 else _iter35)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 4)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter36, _viter37 in self.userTypeOverrides.items():
                oprot.writeString(_kiter36.encode('utf-8') if sys.version_info[0] == 2 else _kiter36)
                oprot.writeI32(_viter37)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.closedDealOverrides is not None:
            oprot.writeFieldBegin('closedDealOverrides', TType.STRUCT, 6)
            self.closedDealOverrides.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddTeamListingsByIdResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddTeamListingsByIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentProfileRequest(object):
    """
    Attributes:
     - id
     - filters
     - userType
     - userTypeOverrides
     - excludeListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'filters', (gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters, gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters.thrift_spec), None, ),  # 2
        (3, TType.I32, 'userType', None, None, ),  # 3
        (4, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 4
        (5, TType.BOOL, 'excludeListings', None, None, ),  # 5
    )
    def __init__(self, id=None, filters=None, userType=None, userTypeOverrides=None, excludeListings=None, ):
        self.id = id
        self.filters = filters
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.excludeListings = excludeListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.filters = gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters()
                    self.filters.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype39, _vtype40, _size43) = iprot.readMapBegin()
                    for _i38 in range(_size43):
                        _key41 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val42 = iprot.readI32()
                        self.userTypeOverrides[_key41] = _val42
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.excludeListings = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentProfileRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.filters is not None:
            oprot.writeFieldBegin('filters', TType.STRUCT, 2)
            self.filters.write(oprot)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 3)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter44, _viter45 in self.userTypeOverrides.items():
                oprot.writeString(_kiter44.encode('utf-8') if sys.version_info[0] == 2 else _kiter44)
                oprot.writeI32(_viter45)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.excludeListings is not None:
            oprot.writeFieldBegin('excludeListings', TType.BOOL, 5)
            oprot.writeBool(self.excludeListings)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentProfileResponse(object):
    """
    Attributes:
     - status
     - profile
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'profile', (gen.urbancompass.agent_intelligence.models.ttypes.AgentProfile, gen.urbancompass.agent_intelligence.models.ttypes.AgentProfile.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, profile=None, ):
        self.status = status
        self.profile = profile

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.profile = gen.urbancompass.agent_intelligence.models.ttypes.AgentProfile()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentProfileResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 2)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteAgentClosedDealsRequest(object):
    """
    Attributes:
     - id
     - userId
     - roles
     - listingIds
     - hexIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'listingIds', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'hexIds', (TType.STRING, 'UTF8', False), None, ),  # 5
    )
    def __init__(self, id=None, userId=None, roles=None, listingIds=None, hexIds=None, ):
        self.id = id
        self.userId = userId
        self.roles = roles
        self.listingIds = listingIds
        self.hexIds = hexIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype46, _size49) = iprot.readListBegin()
                    for _i47 in range(_size49):
                        _elem48 = gen.urbancompass.user.user.ttypes.Role()
                        _elem48.read(iprot)
                        self.roles.append(_elem48)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.listingIds = []
                    (_etype50, _size53) = iprot.readListBegin()
                    for _i51 in range(_size53):
                        _elem52 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIds.append(_elem52)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.hexIds = []
                    (_etype54, _size57) = iprot.readListBegin()
                    for _i55 in range(_size57):
                        _elem56 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.hexIds.append(_elem56)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteAgentClosedDealsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter58 in self.roles:
                _iter58.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingIds is not None:
            oprot.writeFieldBegin('listingIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.listingIds))
            for _iter59 in self.listingIds:
                oprot.writeString(_iter59.encode('utf-8') if sys.version_info[0] == 2 else _iter59)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hexIds is not None:
            oprot.writeFieldBegin('hexIds', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.hexIds))
            for _iter60 in self.hexIds:
                oprot.writeString(_iter60.encode('utf-8') if sys.version_info[0] == 2 else _iter60)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteAgentClosedDealsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteAgentClosedDealsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteTeamClosedDealsRequest(object):
    """
    Attributes:
     - id
     - userId
     - roles
     - listingIds
     - hexIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'listingIds', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'hexIds', (TType.STRING, 'UTF8', False), None, ),  # 5
    )
    def __init__(self, id=None, userId=None, roles=None, listingIds=None, hexIds=None, ):
        self.id = id
        self.userId = userId
        self.roles = roles
        self.listingIds = listingIds
        self.hexIds = hexIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype61, _size64) = iprot.readListBegin()
                    for _i62 in range(_size64):
                        _elem63 = gen.urbancompass.user.user.ttypes.Role()
                        _elem63.read(iprot)
                        self.roles.append(_elem63)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.listingIds = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIds.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.hexIds = []
                    (_etype69, _size72) = iprot.readListBegin()
                    for _i70 in range(_size72):
                        _elem71 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.hexIds.append(_elem71)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteTeamClosedDealsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter73 in self.roles:
                _iter73.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingIds is not None:
            oprot.writeFieldBegin('listingIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.listingIds))
            for _iter74 in self.listingIds:
                oprot.writeString(_iter74.encode('utf-8') if sys.version_info[0] == 2 else _iter74)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hexIds is not None:
            oprot.writeFieldBegin('hexIds', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.hexIds))
            for _iter75 in self.hexIds:
                oprot.writeString(_iter75.encode('utf-8') if sys.version_info[0] == 2 else _iter75)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteTeamClosedDealsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteTeamClosedDealsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadAgentClosedDealsRequest(object):
    """
    Attributes:
     - id
     - limit
     - offset
     - orderBy
     - userType
     - userTypeOverrides
     - closedDealsFilters
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'limit', None, None, ),  # 2
        (3, TType.I32, 'offset', None, None, ),  # 3
        (4, TType.I32, 'orderBy', None, None, ),  # 4
        (5, TType.I32, 'userType', None, None, ),  # 5
        (6, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 6
        (7, TType.STRUCT, 'closedDealsFilters', (gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealsFilters, gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealsFilters.thrift_spec), None, ),  # 7
    )
    def __init__(self, id=None, limit=None, offset=None, orderBy=None, userType=None, userTypeOverrides=None, closedDealsFilters=None, ):
        self.id = id
        self.limit = limit
        self.offset = offset
        self.orderBy = orderBy
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.closedDealsFilters = closedDealsFilters

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype77, _vtype78, _size81) = iprot.readMapBegin()
                    for _i76 in range(_size81):
                        _key79 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val80 = iprot.readI32()
                        self.userTypeOverrides[_key79] = _val80
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.closedDealsFilters = gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealsFilters()
                    self.closedDealsFilters.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadAgentClosedDealsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 2)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 3)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 4)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 5)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 6)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter82, _viter83 in self.userTypeOverrides.items():
                oprot.writeString(_kiter82.encode('utf-8') if sys.version_info[0] == 2 else _kiter82)
                oprot.writeI32(_viter83)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.closedDealsFilters is not None:
            oprot.writeFieldBegin('closedDealsFilters', TType.STRUCT, 7)
            self.closedDealsFilters.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadAgentClosedDealsResponse(object):
    """
    Attributes:
     - status
     - listings
     - count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.agent_intelligence.models.ttypes.IdentifiedProcessedListing, gen.urbancompass.agent_intelligence.models.ttypes.IdentifiedProcessedListing.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'count', None, None, ),  # 3
    )
    def __init__(self, status=None, listings=None, count=None, ):
        self.status = status
        self.listings = listings
        self.count = count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype84, _size87) = iprot.readListBegin()
                    for _i85 in range(_size87):
                        _elem86 = gen.urbancompass.agent_intelligence.models.ttypes.IdentifiedProcessedListing()
                        _elem86.read(iprot)
                        self.listings.append(_elem86)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadAgentClosedDealsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter88 in self.listings:
                _iter88.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 3)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadListingsRequest(object):
    """
    Attributes:
     - id
     - contactType
     - filters
     - userType
     - userTypeOverrides
     - offset
     - limit
     - listingStatus
     - entityType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'contactType', None, None, ),  # 2
        (3, TType.STRUCT, 'filters', (gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters, gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters.thrift_spec), None, ),  # 3
        (4, TType.I32, 'userType', None, None, ),  # 4
        (5, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 5
        (6, TType.I32, 'offset', None, None, ),  # 6
        (7, TType.I32, 'limit', None, None, ),  # 7
        (8, TType.I32, 'listingStatus', None, None, ),  # 8
        (9, TType.I32, 'entityType', None, None, ),  # 9
    )
    def __init__(self, id=None, contactType=None, filters=None, userType=None, userTypeOverrides=None, offset=None, limit=None, listingStatus=None, entityType=None, ):
        self.id = id
        self.contactType = contactType
        self.filters = filters
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.offset = offset
        self.limit = limit
        self.listingStatus = listingStatus
        self.entityType = entityType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.contactType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.filters = gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters()
                    self.filters.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype90, _vtype91, _size94) = iprot.readMapBegin()
                    for _i89 in range(_size94):
                        _key92 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val93 = iprot.readI32()
                        self.userTypeOverrides[_key92] = _val93
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.listingStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.entityType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadListingsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.I32, 2)
            oprot.writeI32(self.contactType)
            oprot.writeFieldEnd()
        if self.filters is not None:
            oprot.writeFieldBegin('filters', TType.STRUCT, 3)
            self.filters.write(oprot)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 4)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter95, _viter96 in self.userTypeOverrides.items():
                oprot.writeString(_kiter95.encode('utf-8') if sys.version_info[0] == 2 else _kiter95)
                oprot.writeI32(_viter96)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 6)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 7)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.listingStatus is not None:
            oprot.writeFieldBegin('listingStatus', TType.I32, 8)
            oprot.writeI32(self.listingStatus)
            oprot.writeFieldEnd()
        if self.entityType is not None:
            oprot.writeFieldBegin('entityType', TType.I32, 9)
            oprot.writeI32(self.entityType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadListingsResponse(object):
    """
    Attributes:
     - status
     - listings
     - count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'count', None, None, ),  # 3
    )
    def __init__(self, status=None, listings=None, count=None, ):
        self.status = status
        self.listings = listings
        self.count = count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype97, _size100) = iprot.readListBegin()
                    for _i98 in range(_size100):
                        _elem99 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem99.read(iprot)
                        self.listings.append(_elem99)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadListingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter101 in self.listings:
                _iter101.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 3)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadTeamClosedDealsRequest(object):
    """
    Attributes:
     - id
     - limit
     - offset
     - orderBy
     - userType
     - userTypeOverrides
     - closedDealsFilters
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'limit', None, None, ),  # 2
        (3, TType.I32, 'offset', None, None, ),  # 3
        (4, TType.I32, 'orderBy', None, None, ),  # 4
        (5, TType.I32, 'userType', None, None, ),  # 5
        (6, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 6
        (7, TType.STRUCT, 'closedDealsFilters', (gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealsFilters, gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealsFilters.thrift_spec), None, ),  # 7
    )
    def __init__(self, id=None, limit=None, offset=None, orderBy=None, userType=None, userTypeOverrides=None, closedDealsFilters=None, ):
        self.id = id
        self.limit = limit
        self.offset = offset
        self.orderBy = orderBy
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.closedDealsFilters = closedDealsFilters

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype103, _vtype104, _size107) = iprot.readMapBegin()
                    for _i102 in range(_size107):
                        _key105 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val106 = iprot.readI32()
                        self.userTypeOverrides[_key105] = _val106
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.closedDealsFilters = gen.urbancompass.agent_intelligence.models.ttypes.ClosedDealsFilters()
                    self.closedDealsFilters.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadTeamClosedDealsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 2)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 3)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 4)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 5)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 6)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter108, _viter109 in self.userTypeOverrides.items():
                oprot.writeString(_kiter108.encode('utf-8') if sys.version_info[0] == 2 else _kiter108)
                oprot.writeI32(_viter109)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.closedDealsFilters is not None:
            oprot.writeFieldBegin('closedDealsFilters', TType.STRUCT, 7)
            self.closedDealsFilters.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadTeamClosedDealsResponse(object):
    """
    Attributes:
     - status
     - listings
     - count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'listings', (TType.STRUCT, (gen.urbancompass.agent_intelligence.models.ttypes.IdentifiedProcessedListing, gen.urbancompass.agent_intelligence.models.ttypes.IdentifiedProcessedListing.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'count', None, None, ),  # 3
    )
    def __init__(self, status=None, listings=None, count=None, ):
        self.status = status
        self.listings = listings
        self.count = count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype110, _size113) = iprot.readListBegin()
                    for _i111 in range(_size113):
                        _elem112 = gen.urbancompass.agent_intelligence.models.ttypes.IdentifiedProcessedListing()
                        _elem112.read(iprot)
                        self.listings.append(_elem112)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadTeamClosedDealsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter114 in self.listings:
                _iter114.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 3)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ProfileNeighborhoodsRequest(object):
    """
    Attributes:
     - id
     - dealType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'dealType', None, None, ),  # 2
    )
    def __init__(self, id=None, dealType=None, ):
        self.id = id
        self.dealType = dealType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ProfileNeighborhoodsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 2)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ProfileNeighborhoodsResponse(object):
    """
    Attributes:
     - status
     - neighborhoods
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'neighborhoods', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, neighborhoods=None, ):
        self.status = status
        self.neighborhoods = neighborhoods

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.neighborhoods = []
                    (_etype115, _size118) = iprot.readListBegin()
                    for _i116 in range(_size118):
                        _elem117 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.neighborhoods.append(_elem117)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ProfileNeighborhoodsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.neighborhoods is not None:
            oprot.writeFieldBegin('neighborhoods', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.neighborhoods))
            for _iter119 in self.neighborhoods:
                oprot.writeString(_iter119.encode('utf-8') if sys.version_info[0] == 2 else _iter119)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchByNameRequest(object):
    """
    Attributes:
     - userId
     - name
     - limit
     - offset
     - orderBy
     - orderDesc
     - filters
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I32, 'limit', None, None, ),  # 3
        (4, TType.I32, 'offset', None, None, ),  # 4
        (5, TType.I32, 'orderBy', None, None, ),  # 5
        (6, TType.BOOL, 'orderDesc', None, None, ),  # 6
        (7, TType.STRUCT, 'filters', (gen.urbancompass.agent_intelligence.models.ttypes.SearchByNameFilters, gen.urbancompass.agent_intelligence.models.ttypes.SearchByNameFilters.thrift_spec), None, ),  # 7
    )
    def __init__(self, userId=None, name=None, limit=None, offset=None, orderBy=None, orderDesc=None, filters=None, ):
        self.userId = userId
        self.name = name
        self.limit = limit
        self.offset = offset
        self.orderBy = orderBy
        self.orderDesc = orderDesc
        self.filters = filters

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.orderDesc = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.filters = gen.urbancompass.agent_intelligence.models.ttypes.SearchByNameFilters()
                    self.filters.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchByNameRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 3)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 4)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 5)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.orderDesc is not None:
            oprot.writeFieldBegin('orderDesc', TType.BOOL, 6)
            oprot.writeBool(self.orderDesc)
            oprot.writeFieldEnd()
        if self.filters is not None:
            oprot.writeFieldBegin('filters', TType.STRUCT, 7)
            self.filters.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchRequest(object):
    """
    Attributes:
     - userId
     - locationId
     - compassOfficeId
     - filters
     - limit
     - offset
     - orderBy
     - orderDesc
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'locationId', None, None, ),  # 2
        (3, TType.STRING, 'compassOfficeId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'filters', (gen.urbancompass.agent_intelligence.models.ttypes.SearchFilters, gen.urbancompass.agent_intelligence.models.ttypes.SearchFilters.thrift_spec), None, ),  # 4
        (5, TType.I32, 'limit', None, None, ),  # 5
        (6, TType.I32, 'offset', None, None, ),  # 6
        (7, TType.I32, 'orderBy', None, None, ),  # 7
        (8, TType.BOOL, 'orderDesc', None, None, ),  # 8
    )
    def __init__(self, userId=None, locationId=None, compassOfficeId=None, filters=None, limit=None, offset=None, orderBy=None, orderDesc=None, ):
        self.userId = userId
        self.locationId = locationId
        self.compassOfficeId = compassOfficeId
        self.filters = filters
        self.limit = limit
        self.offset = offset
        self.orderBy = orderBy
        self.orderDesc = orderDesc

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.locationId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.compassOfficeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.filters = gen.urbancompass.agent_intelligence.models.ttypes.SearchFilters()
                    self.filters.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.orderDesc = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.locationId is not None:
            oprot.writeFieldBegin('locationId', TType.I64, 2)
            oprot.writeI64(self.locationId)
            oprot.writeFieldEnd()
        if self.compassOfficeId is not None:
            oprot.writeFieldBegin('compassOfficeId', TType.STRING, 3)
            oprot.writeString(self.compassOfficeId.encode('utf-8') if sys.version_info[0] == 2 else self.compassOfficeId)
            oprot.writeFieldEnd()
        if self.filters is not None:
            oprot.writeFieldBegin('filters', TType.STRUCT, 4)
            self.filters.write(oprot)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 5)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 6)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 7)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.orderDesc is not None:
            oprot.writeFieldBegin('orderDesc', TType.BOOL, 8)
            oprot.writeBool(self.orderDesc)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchResponse(object):
    """
    Attributes:
     - status
     - results
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'results', (TType.STRUCT, (gen.urbancompass.agent_intelligence.models.ttypes.SearchResult, gen.urbancompass.agent_intelligence.models.ttypes.SearchResult.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalResults', None, None, ),  # 3
    )
    def __init__(self, status=None, results=None, totalResults=None, ):
        self.status = status
        self.results = results
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.results = []
                    (_etype120, _size123) = iprot.readListBegin()
                    for _i121 in range(_size123):
                        _elem122 = gen.urbancompass.agent_intelligence.models.ttypes.SearchResult()
                        _elem122.read(iprot)
                        self.results.append(_elem122)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.results is not None:
            oprot.writeFieldBegin('results', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.results))
            for _iter124 in self.results:
                _iter124.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 3)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetAgentClosedDealsVisibilityRequest(object):
    """
    Attributes:
     - id
     - listingIds
     - listingHexIds
     - hideClosedDeals
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'listingIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'listingHexIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.BOOL, 'hideClosedDeals', None, None, ),  # 4
    )
    def __init__(self, id=None, listingIds=None, listingHexIds=None, hideClosedDeals=None, ):
        self.id = id
        self.listingIds = listingIds
        self.listingHexIds = listingHexIds
        self.hideClosedDeals = hideClosedDeals

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listingIds = []
                    (_etype125, _size128) = iprot.readListBegin()
                    for _i126 in range(_size128):
                        _elem127 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIds.append(_elem127)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listingHexIds = []
                    (_etype129, _size132) = iprot.readListBegin()
                    for _i130 in range(_size132):
                        _elem131 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingHexIds.append(_elem131)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hideClosedDeals = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetAgentClosedDealsVisibilityRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.listingIds is not None:
            oprot.writeFieldBegin('listingIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.listingIds))
            for _iter133 in self.listingIds:
                oprot.writeString(_iter133.encode('utf-8') if sys.version_info[0] == 2 else _iter133)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingHexIds is not None:
            oprot.writeFieldBegin('listingHexIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.listingHexIds))
            for _iter134 in self.listingHexIds:
                oprot.writeString(_iter134.encode('utf-8') if sys.version_info[0] == 2 else _iter134)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hideClosedDeals is not None:
            oprot.writeFieldBegin('hideClosedDeals', TType.BOOL, 4)
            oprot.writeBool(self.hideClosedDeals)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetAgentClosedDealsVisibilityResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetAgentClosedDealsVisibilityResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetShowIndividualsListingsRequest(object):
    """
    Attributes:
     - id
     - showIndividualsListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'showIndividualsListings', None, None, ),  # 2
    )
    def __init__(self, id=None, showIndividualsListings=None, ):
        self.id = id
        self.showIndividualsListings = showIndividualsListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.showIndividualsListings = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetShowIndividualsListingsRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.showIndividualsListings is not None:
            oprot.writeFieldBegin('showIndividualsListings', TType.BOOL, 2)
            oprot.writeBool(self.showIndividualsListings)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetShowIndividualsListingsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetShowIndividualsListingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetTeamClosedDealsVisibilityRequest(object):
    """
    Attributes:
     - id
     - listingIds
     - listingHexIds
     - hideClosedDeals
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'listingIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'listingHexIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.BOOL, 'hideClosedDeals', None, None, ),  # 4
    )
    def __init__(self, id=None, listingIds=None, listingHexIds=None, hideClosedDeals=None, ):
        self.id = id
        self.listingIds = listingIds
        self.listingHexIds = listingHexIds
        self.hideClosedDeals = hideClosedDeals

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listingIds = []
                    (_etype135, _size138) = iprot.readListBegin()
                    for _i136 in range(_size138):
                        _elem137 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIds.append(_elem137)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listingHexIds = []
                    (_etype139, _size142) = iprot.readListBegin()
                    for _i140 in range(_size142):
                        _elem141 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingHexIds.append(_elem141)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hideClosedDeals = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetTeamClosedDealsVisibilityRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.listingIds is not None:
            oprot.writeFieldBegin('listingIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.listingIds))
            for _iter143 in self.listingIds:
                oprot.writeString(_iter143.encode('utf-8') if sys.version_info[0] == 2 else _iter143)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingHexIds is not None:
            oprot.writeFieldBegin('listingHexIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.listingHexIds))
            for _iter144 in self.listingHexIds:
                oprot.writeString(_iter144.encode('utf-8') if sys.version_info[0] == 2 else _iter144)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hideClosedDeals is not None:
            oprot.writeFieldBegin('hideClosedDeals', TType.BOOL, 4)
            oprot.writeBool(self.hideClosedDeals)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SetTeamClosedDealsVisibilityResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SetTeamClosedDealsVisibilityResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamProfileRequest(object):
    """
    Attributes:
     - id
     - filters
     - userType
     - userTypeOverrides
     - excludeListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'filters', (gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters, gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters.thrift_spec), None, ),  # 2
        (3, TType.I32, 'userType', None, None, ),  # 3
        (4, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 4
        (5, TType.BOOL, 'excludeListings', None, None, ),  # 5
    )
    def __init__(self, id=None, filters=None, userType=None, userTypeOverrides=None, excludeListings=None, ):
        self.id = id
        self.filters = filters
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.excludeListings = excludeListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.filters = gen.urbancompass.agent_intelligence.models.ttypes.ProfileFilters()
                    self.filters.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype146, _vtype147, _size150) = iprot.readMapBegin()
                    for _i145 in range(_size150):
                        _key148 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val149 = iprot.readI32()
                        self.userTypeOverrides[_key148] = _val149
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.excludeListings = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamProfileRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.filters is not None:
            oprot.writeFieldBegin('filters', TType.STRUCT, 2)
            self.filters.write(oprot)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 3)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter151, _viter152 in self.userTypeOverrides.items():
                oprot.writeString(_kiter151.encode('utf-8') if sys.version_info[0] == 2 else _kiter151)
                oprot.writeI32(_viter152)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.excludeListings is not None:
            oprot.writeFieldBegin('excludeListings', TType.BOOL, 5)
            oprot.writeBool(self.excludeListings)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamProfileResponse(object):
    """
    Attributes:
     - status
     - profile
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'profile', (gen.urbancompass.agent_intelligence.models.ttypes.TeamProfile, gen.urbancompass.agent_intelligence.models.ttypes.TeamProfile.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, profile=None, ):
        self.status = status
        self.profile = profile

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.profile = gen.urbancompass.agent_intelligence.models.ttypes.TeamProfile()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamProfileResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 2)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
