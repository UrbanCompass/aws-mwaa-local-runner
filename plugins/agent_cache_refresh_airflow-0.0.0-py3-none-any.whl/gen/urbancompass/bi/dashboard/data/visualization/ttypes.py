
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.breadcrumbs.ttypes
import gen.urbancompass.bi.dashboard.data.charts.chart.ttypes
import gen.urbancompass.bi.dashboard.data.controls.ttypes
import gen.urbancompass.bi.dashboard.data.parameters.ttypes

from thrift.transport import TTransport


class DataVisualization(object):
    """
    Attributes:
     - id
     - chart
     - control
     - breadcrumbTrail
     - parameterSpecs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'chart', (gen.urbancompass.bi.dashboard.data.charts.chart.ttypes.Chart, gen.urbancompass.bi.dashboard.data.charts.chart.ttypes.Chart.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'control', (gen.urbancompass.bi.dashboard.data.controls.ttypes.Control, gen.urbancompass.bi.dashboard.data.controls.ttypes.Control.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'parameterSpecs', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.parameters.ttypes.ParameterSpec, gen.urbancompass.bi.dashboard.data.parameters.ttypes.ParameterSpec.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'breadcrumbTrail', (gen.urbancompass.bi.dashboard.data.breadcrumbs.ttypes.BreadcrumbTrail, gen.urbancompass.bi.dashboard.data.breadcrumbs.ttypes.BreadcrumbTrail.thrift_spec), None, ),  # 5
    )
    def __init__(self, id=None, chart=None, control=None, parameterSpecs=None, breadcrumbTrail=None, ):
        self.id = id
        self.chart = chart
        self.control = control
        self.parameterSpecs = parameterSpecs
        self.breadcrumbTrail = breadcrumbTrail

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.chart = gen.urbancompass.bi.dashboard.data.charts.chart.ttypes.Chart()
                    self.chart.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.control = gen.urbancompass.bi.dashboard.data.controls.ttypes.Control()
                    self.control.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.parameterSpecs = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.bi.dashboard.data.parameters.ttypes.ParameterSpec()
                        _elem4.read(iprot)
                        self.parameterSpecs.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.breadcrumbTrail = gen.urbancompass.bi.dashboard.data.breadcrumbs.ttypes.BreadcrumbTrail()
                    self.breadcrumbTrail.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DataVisualization')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.chart is not None:
            oprot.writeFieldBegin('chart', TType.STRUCT, 2)
            self.chart.write(oprot)
            oprot.writeFieldEnd()
        if self.control is not None:
            oprot.writeFieldBegin('control', TType.STRUCT, 3)
            self.control.write(oprot)
            oprot.writeFieldEnd()
        if self.parameterSpecs is not None:
            oprot.writeFieldBegin('parameterSpecs', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.parameterSpecs))
            for _iter6 in self.parameterSpecs:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.breadcrumbTrail is not None:
            oprot.writeFieldBegin('breadcrumbTrail', TType.STRUCT, 5)
            self.breadcrumbTrail.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
