# -*- coding: utf-8 -*-
"""
Compass-specific methods for interacting with secrets_manager.

:copyright: (c) 2018 by Urban Compass, Inc.
"""
import json
from uc.aws.clients import secrets_client

_KMS_SECRETS_KEY_ALIAS = "alias/secrets"


class SecretsManager:
    """A class for interacting with aws secrets in a way that is "idiomatic" to Compass.

    Use this class if your program needs to use multiple different secrets clients
    eg for assuming different IAM roles.
    You can use the top level functions otherwise.
    """

    def __init__(self, client=None):
        if client is None:
            client = secrets_client()
        self._client = client

    def get_secret(self, secret_id):
        """
        Retrieve a secret from Secrets Manager
        :throws Exception: if the secret is not found
        :param string secret_id: The fully qualified name of a secret
        :return mixed: empty dict if the secret is not accessible or does not exist, the binary bytes, the
          json-loaded dict, or the raw string
        """
        client = self._client
        response = client.get_secret_value(SecretId=secret_id)
        if not response.get("SecretString"):
            return response["SecretBinary"]
        try:
            return json.loads(response["SecretString"])
        except ValueError:
            pass
        return response["SecretString"]

    def store_secret(self, name, data, description, tags=None):
        """
        Store a secret in Secrets Manager
        :param string name: Name of secret, must start with `compass.`
        :param dict data: Key/value pairs or raw binary bytes
        :param string description: Description of secret
        :param array tags: Tags to add to the secret ex: [{'Key':key, 'Value':value}, {...}]

        :raises Exception: if secret name does not confirm or AWS error occurs
        """
        client = self._client
        if not name.startswith("compass."):
            raise Exception(
                "Secret name should follow the format of `compass.{app/package}.{owner}`."
            )
        if not data:
            raise Exception("Please provide key/value pairs to store as secrets")

        kwargs = {
            "Name": name,
            "Description": description,
            "KmsKeyId": _KMS_SECRETS_KEY_ALIAS,
        }

        if isinstance(data, dict):
            kwargs["SecretString"] = json.dumps(data)
        elif isinstance(data, str):
            kwargs["SecretString"] = data
        else:
            kwargs["SecretBinary"] = data

        if tags is not None:
            kwargs["Tags"] = tags

        return client.create_secret(**kwargs)

    def update_secret(self, name, data, description):
        """
        Update a secret in Secrets Manager
        :param string name: Name of secret, must start with `compass.`
        :param dict data: Key/value pairs or raw binary bytes
        :param string description: Description of secret

        :raises Exception: if secret name does not confirm or AWS error occurs
        """
        client = self._client
        if not name.startswith("compass."):
            raise Exception(
                "Secret name should follow the format of `compass.{app/package}.{owner}`."
            )
        if not data:
            raise Exception("Please provide key/value pairs to store as secrets")

        kwargs = {
            "SecretId": name,
            "Description": description,
        }

        if isinstance(data, dict):
            kwargs["SecretString"] = json.dumps(data)
        elif isinstance(data, str):
            kwargs["SecretString"] = data
        else:
            kwargs["SecretBinary"] = data

        return client.update_secret(**kwargs)


def get_secret(secret_id, assume_role=None):
    """
    Store a secret in Secrets Manager
    :param string name: Name of secret, must start with `compass.`
    :param dict data: Key/value pairs or raw binary bytes
    :param string description: Description of secret
    :param array tags: Tags to add to the secret ex: [{'Key':key, 'Value':value}, {...}]

    :raises Exception: if secret name does not confirm or AWS error occurs
    """
    m = SecretsManager(client=secrets_client(assume_role=assume_role))
    return m.get_secret(secret_id)


def store_secret(name, data, description, tags=None):
    """
    Store a secret in Secrets Manager
    :param string name: Name of secret, must start with `compass.`
    :param dict data: Key/value pairs or raw binary bytes
    :param string description: Description of secret
    :param array tags: Tags to add to the secret ex: [{'Key':key, 'Value':value}, {...}]

    :raises Exception: if secret name does not confirm or AWS error occurs
    """
    return SecretsManager().store_secret(name, data, description, tags)


def update_secret(name, data, description):
    """
    Update a secret in Secrets Manager
    :param string name: Name of secret, must start with `compass.`
    :param dict data: Key/value pairs or raw binary bytes
    :param string description: Description of secret

    :raises Exception: if secret name does not confirm or AWS error occurs
    """
    return SecretsManager().update_secret(name, data, description)
