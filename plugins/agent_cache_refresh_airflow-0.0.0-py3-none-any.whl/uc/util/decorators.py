# -*- coding: utf-8 -*-
"""
Various decorators to add safety/performance/logging around operations

:copyright: (c) 2017 by Urban Compass, Inc.
"""
import functools
import itertools
import logging


def logging_return_or_exception(func):
    """
    Decorator to always log return results or exception of a function

    :param func:
    :return:
    """

    def wrapped(*args, **dargs):
        try:
            results = func(*args, **dargs)
        except:
            logging.exception("%s threw exception" % func.__name__)
            raise
        else:
            logging.info("%s returned %r" % (func.__name__, results))
            return results

    return wrapped


def memoize():
    """Decorator that adds memoization support to a function.

    Uses a dict for persistence.

    Example:
        @memoize()
        def my_cached_func(*args, **kwargs):
          # do something expensive and cache-worthy.
    """
    default_cache = {}

    def decorate(fn):
        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            key = tuple(itertools.chain(args, ((k, v) for k, v in sorted(kwargs.items()))))
            if key not in default_cache:
                default_cache[key] = fn(*args, **kwargs)
            return default_cache[key]

        return wrapped

    return decorate


def with_each(items, func):
    """
    :param items: items to run "with" statement per item
    :param func: partial function to take each item and run an operation
    :return:
    """
    for item in items:
        with item as param:
            func(param)
