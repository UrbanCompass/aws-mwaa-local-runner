
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class DmsObjectAccessLevel(object):
    FULL = 0
    NONE = 1
    NOT_EXIST = 2
    CLOSING = 3
    COLLABORATOR = 4
    STAFF_READ_ONLY = 5
    STAFF_FULL = 6

    _VALUES_TO_NAMES = {
        0: "FULL",
        1: "NONE",
        2: "NOT_EXIST",
        3: "CLOSING",
        4: "COLLABORATOR",
        5: "STAFF_READ_ONLY",
        6: "STAFF_FULL",
    }

    _NAMES_TO_VALUES = {
        "FULL": 0,
        "NONE": 1,
        "NOT_EXIST": 2,
        "CLOSING": 3,
        "COLLABORATOR": 4,
        "STAFF_READ_ONLY": 5,
        "STAFF_FULL": 6,
    }

