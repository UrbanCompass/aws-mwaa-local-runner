
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.grid.ttypes

from thrift.transport import TTransport


class GroupOrientation(object):
    STACK_VERTICAL = 0
    STACK_HORIZONTAL = 1
    CARD_HORIZONTAL = 2

    _VALUES_TO_NAMES = {
        0: "STACK_VERTICAL",
        1: "STACK_HORIZONTAL",
        2: "CARD_HORIZONTAL",
    }

    _NAMES_TO_VALUES = {
        "STACK_VERTICAL": 0,
        "STACK_HORIZONTAL": 1,
        "CARD_HORIZONTAL": 2,
    }


class Group(object):
    """
    Attributes:
     - dataVisualizations
     - orientation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dataVisualizations', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'orientation', None, None, ),  # 2
    )
    def __init__(self, dataVisualizations=None, orientation=None, ):
        self.dataVisualizations = dataVisualizations
        self.orientation = orientation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dataVisualizations = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dataVisualizations.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.orientation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Group')
        if self.dataVisualizations is not None:
            oprot.writeFieldBegin('dataVisualizations', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.dataVisualizations))
            for _iter6 in self.dataVisualizations:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.orientation is not None:
            oprot.writeFieldBegin('orientation', TType.I32, 2)
            oprot.writeI32(self.orientation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Layout(object):
    """
    Attributes:
     - groups
     - grids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'groups', (TType.STRUCT, (Group, Group.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'grids', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.grid.ttypes.Grid, gen.urbancompass.bi.dashboard.data.grid.ttypes.Grid.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, groups=None, grids=None, ):
        self.groups = groups
        self.grids = grids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.groups = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = Group()
                        _elem9.read(iprot)
                        self.groups.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.grids = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = gen.urbancompass.bi.dashboard.data.grid.ttypes.Grid()
                        _elem13.read(iprot)
                        self.grids.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Layout')
        if self.groups is not None:
            oprot.writeFieldBegin('groups', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.groups))
            for _iter15 in self.groups:
                _iter15.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.grids is not None:
            oprot.writeFieldBegin('grids', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.grids))
            for _iter16 in self.grids:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
