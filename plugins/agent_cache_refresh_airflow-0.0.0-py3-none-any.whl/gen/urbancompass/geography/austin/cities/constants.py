
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
AUSTIN = "Austin"
AXTELL = "Axtell"
BARTLETT = "Bartlett"
BASTROP = "Bastrop"
BEEVILLE = "Beeville"
BEE_CAVE = "Bee Cave"
BELTON = "Belton"
BERCLAIR = "Berclair"
BERTRAM = "Bertram"
BLANCO = "Blanco"
BLOOMINGTON = "Bloomington"
BLUFFTON = "Bluffton"
BREMOND = "Bremond"
BRIARCLIFF = "Briarcliff"
BRIGGS = "Briggs"
BRUCEVILLE = "Bruceville"
BUCHANAN_DAM = "Buchanan Dam"
BUCKHOLTS = "Buckholts"
BUDA = "Buda"
BULVERDE = "Bulverde"
BURLINGTON = "Burlington"
BURNET = "Burnet"
CALDWELL = "Caldwell"
CALVERT = "Calvert"
CAMERON = "Cameron"
CANYON_LAKE = "Canyon Lake"
CARLTON = "Carlton"
CASTELL = "Castell"
CEDAR_CREEK = "Cedar Creek"
CEDAR_PARK = "Cedar Park"
CHEROKEE = "Cherokee"
CHILTON = "Chilton"
CHINA_SPRING = "China Spring"
CHRIESMAN = "Chriesman"
CIBOLO = "Cibolo"
CITIES = [
    "Austin",
    "Axtell",
    "Bartlett",
    "Bastrop",
    "Beeville",
    "Bee Cave",
    "Belton",
    "Berclair",
    "Bertram",
    "Blanco",
    "Bloomington",
    "Bluffton",
    "Bremond",
    "Briarcliff",
    "Briggs",
    "Bruceville",
    "Buchanan Dam",
    "Buckholts",
    "Buda",
    "Bulverde",
    "Burlington",
    "Burnet",
    "Caldwell",
    "Calvert",
    "Cameron",
    "Canyon Lake",
    "Carlton",
    "Castell",
    "Cedar Creek",
    "Cedar Park",
    "Cherokee",
    "Chilton",
    "China Spring",
    "Chriesman",
    "Cibolo",
    "Coolidge",
    "Copperas Cove",
    "Cost",
    "Coupland",
    "Crawford",
    "Cuero",
    "Dale",
    "Del Valle",
    "Dime Box",
    "Donie",
    "Doss",
    "Driftwood",
    "Dripping Springs",
    "Ecleto",
    "Eddy",
    "Edna",
    "Elgin",
    "Elkhart",
    "Elm Mott",
    "Evant",
    "Fairfield",
    "Falls City",
    "Fannin",
    "Fentress",
    "Fischer",
    "Florence",
    "Fort Hood",
    "Francitas",
    "Franklin",
    "Frankston",
    "Fredericksburg",
    "Ganado",
    "Garden Ridge",
    "Gatesville",
    "Gause",
    "Georgetown",
    "Giddings",
    "Gillett",
    "Goldthwaite",
    "Goliad",
    "Gonzales",
    "Granger",
    "Granite Shoals",
    "Groesbeck",
    "Hallettsville",
    "Hamilton",
    "Harker Heights",
    "Harper",
    "Harwood",
    "Hearne",
    "Heidenheimer",
    "Hewitt",
    "Hico",
    "Hobson",
    "Holland",
    "Horseshoe Bay",
    "Hutto",
    "Hye",
    "Inez",
    "Jarrell",
    "Johnson City",
    "Jonesboro",
    "Jonestown",
    "Karnes City",
    "Kempner",
    "Kenedy",
    "Killeen",
    "Kingsbury",
    "Kingsland",
    "Kirvin",
    "Kosse",
    "Kyle",
    "Lago Vista",
    "Lakeway",
    "Lampasas",
    "La Salle",
    "La Ward",
    "Leander",
    "Leesville",
    "Lexington",
    "Liberty Hill",
    "Lincoln",
    "Little River-Academy",
    "Llano",
    "Lockhart",
    "Lolita",
    "Lometa",
    "Lorena",
    "Lott",
    "Luling",
    "Lyons",
    "Manchaca",
    "Manor",
    "Marble Falls",
    "Marion",
    "Marlin",
    "Mart",
    "Martindale",
    "Maxwell",
    "McDade",
    "Mcfaddin",
    "McGregor",
    "McQueeney",
    "Mexia",
    "Meyersville",
    "Milano",
    "Mineral",
    "Montalba",
    "Moody",
    "Moulton",
    "Mullin",
    "Mumford",
    "Neches",
    "New Braunfels",
    "Nixon",
    "Nolanville",
    "Nordheim",
    "Normanna",
    "Nursery",
    "Oglesby",
    "Paige",
    "Palestine",
    "Panna Maria",
    "Pawnee",
    "Pettus",
    "Pflugerville",
    "Placedo",
    "Point Comfort",
    "Point Venture",
    "Port Lavaca",
    "Port O'Connor",
    "Pottsville",
    "Prairie Hill",
    "Prairie Lea",
    "Priddy",
    "Purmela",
    "Reagan",
    "Red Rock",
    "Richland Springs",
    "Riesel",
    "Rockdale",
    "Rogers",
    "Rollingwood",
    "Rosanky",
    "Rosebud",
    "Round Mountain",
    "Round Rock",
    "Runge",
    "Salado",
    "San Marcos",
    "San Saba",
    "Satin",
    "Schertz",
    "Schwertner",
    "Seadrift",
    "Seguin",
    "Selma",
    "Shiner",
    "Skidmore",
    "Smiley",
    "Smithville",
    "Somerville",
    "Spicewood",
    "Spring Branch",
    "Staples",
    "Star",
    "Stonewall",
    "Streetman",
    "Sublime",
    "Taylor",
    "Teague",
    "Tehuacana",
    "Telferner",
    "Temple",
    "Tennessee Colony",
    "The Hills",
    "Thorndale",
    "Thornton",
    "Thrall",
    "Tow",
    "Troy",
    "Tuleta",
    "Tynan",
    "Valley Spring",
    "Vanderbilt",
    "Victoria",
    "Waco",
    "Waelder",
    "Weir",
    "West",
    "Westhoff",
    "West Lake Hills",
    "Willow City",
    "Wimberley",
    "Woodway",
    "Wortham",
    "Wrightsboro",
    "Yoakum",
    "Yorktown",
]
COOLIDGE = "Coolidge"
COPPERAS_COVE = "Copperas Cove"
COST = "Cost"
COUPLAND = "Coupland"
CRAWFORD = "Crawford"
CUERO = "Cuero"
DALE = "Dale"
DEL_VALLE = "Del Valle"
DIME_BOX = "Dime Box"
DONIE = "Donie"
DOSS = "Doss"
DRIFTWOOD = "Driftwood"
DRIPPING_SPRINGS = "Dripping Springs"
ECLETO = "Ecleto"
EDDY = "Eddy"
EDNA = "Edna"
ELGIN = "Elgin"
ELKHART = "Elkhart"
ELM_MOTT = "Elm Mott"
EVANT = "Evant"
FAIRFIELD = "Fairfield"
FALLS_CITY = "Falls City"
FANNIN = "Fannin"
FENTRESS = "Fentress"
FISCHER = "Fischer"
FLORENCE = "Florence"
FORT_HOOD = "Fort Hood"
FRANCITAS = "Francitas"
FRANKLIN = "Franklin"
FRANKSTON = "Frankston"
FREDERICKSBURG = "Fredericksburg"
GANADO = "Ganado"
GARDEN_RIDGE = "Garden Ridge"
GATESVILLE = "Gatesville"
GAUSE = "Gause"
GEORGETOWN = "Georgetown"
GIDDINGS = "Giddings"
GILLETT = "Gillett"
GOLDTHWAITE = "Goldthwaite"
GOLIAD = "Goliad"
GONZALES = "Gonzales"
GRANGER = "Granger"
GRANITE_SHOALS = "Granite Shoals"
GROESBECK = "Groesbeck"
HALLETTSVILLE = "Hallettsville"
HAMILTON = "Hamilton"
HARKER_HEIGHTS = "Harker Heights"
HARPER = "Harper"
HARWOOD = "Harwood"
HEARNE = "Hearne"
HEIDENHEIMER = "Heidenheimer"
HEWITT = "Hewitt"
HICO = "Hico"
HOBSON = "Hobson"
HOLLAND = "Holland"
HORSESHOE_BAY = "Horseshoe Bay"
HUTTO = "Hutto"
HYE = "Hye"
INEZ = "Inez"
JARRELL = "Jarrell"
JOHNSON_CITY = "Johnson City"
JONESBORO = "Jonesboro"
JONESTOWN = "Jonestown"
KARNES_CITY = "Karnes City"
KEMPNER = "Kempner"
KENEDY = "Kenedy"
KILLEEN = "Killeen"
KINGSBURY = "Kingsbury"
KINGSLAND = "Kingsland"
KIRVIN = "Kirvin"
KOSSE = "Kosse"
KYLE = "Kyle"
LAGO_VISTA = "Lago Vista"
LAKEWAY = "Lakeway"
LAMPASAS = "Lampasas"
LA_SALLE = "La Salle"
LA_WARD = "La Ward"
LEANDER = "Leander"
LEESVILLE = "Leesville"
LEXINGTON = "Lexington"
LIBERTY_HILL = "Liberty Hill"
LINCOLN = "Lincoln"
LITTLE_RIVER_ACADEMY = "Little River-Academy"
LLANO = "Llano"
LOCKHART = "Lockhart"
LOLITA = "Lolita"
LOMETA = "Lometa"
LORENA = "Lorena"
LOTT = "Lott"
LULING = "Luling"
LYONS = "Lyons"
MANCHACA = "Manchaca"
MANOR = "Manor"
MARBLE_FALLS = "Marble Falls"
MARION = "Marion"
MARLIN = "Marlin"
MART = "Mart"
MARTINDALE = "Martindale"
MAXWELL = "Maxwell"
MCDADE = "McDade"
MCFADDIN = "Mcfaddin"
MCGREGOR = "McGregor"
MCQUEENEY = "McQueeney"
MEXIA = "Mexia"
MEYERSVILLE = "Meyersville"
MILANO = "Milano"
MINERAL = "Mineral"
MONTALBA = "Montalba"
MOODY = "Moody"
MOULTON = "Moulton"
MULLIN = "Mullin"
MUMFORD = "Mumford"
NECHES = "Neches"
NEW_BRAUNFELS = "New Braunfels"
NIXON = "Nixon"
NOLANVILLE = "Nolanville"
NORDHEIM = "Nordheim"
NORMANNA = "Normanna"
NURSERY = "Nursery"
OGLESBY = "Oglesby"
PAIGE = "Paige"
PALESTINE = "Palestine"
PANNA_MARIA = "Panna Maria"
PAWNEE = "Pawnee"
PETTUS = "Pettus"
PFLUGERVILLE = "Pflugerville"
PLACEDO = "Placedo"
POINT_COMFORT = "Point Comfort"
POINT_VENTURE = "Point Venture"
PORT_LAVACA = "Port Lavaca"
PORT_OCONNOR = "Port O'Connor"
POTTSVILLE = "Pottsville"
PRAIRIE_HILL = "Prairie Hill"
PRAIRIE_LEA = "Prairie Lea"
PRIDDY = "Priddy"
PURMELA = "Purmela"
REAGAN = "Reagan"
RED_ROCK = "Red Rock"
RICHLAND_SPRINGS = "Richland Springs"
RIESEL = "Riesel"
ROCKDALE = "Rockdale"
ROGERS = "Rogers"
ROLLINGWOOD = "Rollingwood"
ROSANKY = "Rosanky"
ROSEBUD = "Rosebud"
ROUND_MOUNTAIN = "Round Mountain"
ROUND_ROCK = "Round Rock"
RUNGE = "Runge"
SALADO = "Salado"
SAN_MARCOS = "San Marcos"
SAN_SABA = "San Saba"
SATIN = "Satin"
SCHERTZ = "Schertz"
SCHWERTNER = "Schwertner"
SEADRIFT = "Seadrift"
SEGUIN = "Seguin"
SELMA = "Selma"
SHINER = "Shiner"
SKIDMORE = "Skidmore"
SMILEY = "Smiley"
SMITHVILLE = "Smithville"
SOMERVILLE = "Somerville"
SPICEWOOD = "Spicewood"
SPRING_BRANCH = "Spring Branch"
STAPLES = "Staples"
STAR = "Star"
STONEWALL = "Stonewall"
STREETMAN = "Streetman"
SUBLIME = "Sublime"
TAYLOR = "Taylor"
TEAGUE = "Teague"
TEHUACANA = "Tehuacana"
TELFERNER = "Telferner"
TEMPLE = "Temple"
TENNESSEE_COLONY = "Tennessee Colony"
THE_HILLS = "The Hills"
THORNDALE = "Thorndale"
THORNTON = "Thornton"
THRALL = "Thrall"
TOW = "Tow"
TROY = "Troy"
TULETA = "Tuleta"
TYNAN = "Tynan"
VALLEY_SPRING = "Valley Spring"
VANDERBILT = "Vanderbilt"
VICTORIA = "Victoria"
WACO = "Waco"
WAELDER = "Waelder"
WEIR = "Weir"
WEST = "West"
WESTHOFF = "Westhoff"
WEST_LAKE_HILLS = "West Lake Hills"
WILLOW_CITY = "Willow City"
WIMBERLEY = "Wimberley"
WOODWAY = "Woodway"
WORTHAM = "Wortham"
WRIGHTSBORO = "Wrightsboro"
YOAKUM = "Yoakum"
YORKTOWN = "Yorktown"
