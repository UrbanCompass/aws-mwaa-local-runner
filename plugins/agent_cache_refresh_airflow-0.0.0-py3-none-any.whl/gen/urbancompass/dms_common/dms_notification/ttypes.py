
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.dms_notification_model.ttypes

from thrift.transport import TTransport


class AgentsSharedFolderRecipient(object):
    """
    Attributes:
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsFolderId=None, ):
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentsSharedFolderRecipient')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DMSNotification(object):
    """
    Attributes:
     - dmsFolderId
     - notificationType
     - delayStartedTimestamp
     - source
     - numOfRetry
     - notificationEntityKey
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'notificationType', None, None, ),  # 2
        (3, TType.I64, 'delayStartedTimestamp', None, None, ),  # 3
        (4, TType.STRING, 'source', 'UTF8', None, ),  # 4
        (5, TType.I64, 'numOfRetry', None, None, ),  # 5
        (6, TType.STRING, 'notificationEntityKey', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 7
    )
    def __init__(self, dmsFolderId=None, notificationType=None, delayStartedTimestamp=None, source=None, numOfRetry=None, notificationEntityKey=None, dmsTransactionId=None, ):
        self.dmsFolderId = dmsFolderId
        self.notificationType = notificationType
        self.delayStartedTimestamp = delayStartedTimestamp
        self.source = source
        self.numOfRetry = numOfRetry
        self.notificationEntityKey = notificationEntityKey
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.notificationType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.delayStartedTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.numOfRetry = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.notificationEntityKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DMSNotification')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.notificationType is not None:
            oprot.writeFieldBegin('notificationType', TType.I32, 2)
            oprot.writeI32(self.notificationType)
            oprot.writeFieldEnd()
        if self.delayStartedTimestamp is not None:
            oprot.writeFieldBegin('delayStartedTimestamp', TType.I64, 3)
            oprot.writeI64(self.delayStartedTimestamp)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 4)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        if self.numOfRetry is not None:
            oprot.writeFieldBegin('numOfRetry', TType.I64, 5)
            oprot.writeI64(self.numOfRetry)
            oprot.writeFieldEnd()
        if self.notificationEntityKey is not None:
            oprot.writeFieldBegin('notificationEntityKey', TType.STRING, 6)
            oprot.writeString(self.notificationEntityKey.encode('utf-8') if sys.version_info[0] == 2 else self.notificationEntityKey)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 7)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PlainListRecipient(object):
    """
    Attributes:
     - recipientList
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'recipientList', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, recipientList=None, ):
        self.recipientList = recipientList

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.recipientList = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.recipientList.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PlainListRecipient')
        if self.recipientList is not None:
            oprot.writeFieldBegin('recipientList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.recipientList))
            for _iter6 in self.recipientList:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PrincipleAndManagerRecipient(object):
    """
    Attributes:
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
    )
    def __init__(self, dmsTransactionId=None, ):
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PrincipleAndManagerRecipient')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Recipient(object):
    """
    Attributes:
     - agentsSharedFolderRecipient
     - principleAndManagerRecipient
     - plainListRecipient
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'agentsSharedFolderRecipient', (AgentsSharedFolderRecipient, AgentsSharedFolderRecipient.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'principleAndManagerRecipient', (PrincipleAndManagerRecipient, PrincipleAndManagerRecipient.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'plainListRecipient', (PlainListRecipient, PlainListRecipient.thrift_spec), None, ),  # 3
    )
    def __init__(self, agentsSharedFolderRecipient=None, principleAndManagerRecipient=None, plainListRecipient=None, ):
        self.agentsSharedFolderRecipient = agentsSharedFolderRecipient
        self.principleAndManagerRecipient = principleAndManagerRecipient
        self.plainListRecipient = plainListRecipient

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.agentsSharedFolderRecipient = AgentsSharedFolderRecipient()
                    self.agentsSharedFolderRecipient.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.principleAndManagerRecipient = PrincipleAndManagerRecipient()
                    self.principleAndManagerRecipient.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.plainListRecipient = PlainListRecipient()
                    self.plainListRecipient.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Recipient')
        if self.agentsSharedFolderRecipient is not None:
            oprot.writeFieldBegin('agentsSharedFolderRecipient', TType.STRUCT, 1)
            self.agentsSharedFolderRecipient.write(oprot)
            oprot.writeFieldEnd()
        if self.principleAndManagerRecipient is not None:
            oprot.writeFieldBegin('principleAndManagerRecipient', TType.STRUCT, 2)
            self.principleAndManagerRecipient.write(oprot)
            oprot.writeFieldEnd()
        if self.plainListRecipient is not None:
            oprot.writeFieldBegin('plainListRecipient', TType.STRUCT, 3)
            self.plainListRecipient.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TemplateNotification(object):
    """
    Attributes:
     - externalId
     - template
     - fillInPlaceHolderToContentMap
     - recipients
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'externalId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'template', None, None, ),  # 2
        (3, TType.MAP, 'fillInPlaceHolderToContentMap', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.STRUCT, 'recipients', (Recipient, Recipient.thrift_spec), None, ),  # 4
    )
    def __init__(self, externalId=None, template=None, fillInPlaceHolderToContentMap=None, recipients=None, ):
        self.externalId = externalId
        self.template = template
        self.fillInPlaceHolderToContentMap = fillInPlaceHolderToContentMap
        self.recipients = recipients

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.template = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.fillInPlaceHolderToContentMap = {}
                    (_ktype8, _vtype9, _size12) = iprot.readMapBegin()
                    for _i7 in range(_size12):
                        _key10 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val11 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fillInPlaceHolderToContentMap[_key10] = _val11
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.recipients = Recipient()
                    self.recipients.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TemplateNotification')
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 1)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.template is not None:
            oprot.writeFieldBegin('template', TType.I32, 2)
            oprot.writeI32(self.template)
            oprot.writeFieldEnd()
        if self.fillInPlaceHolderToContentMap is not None:
            oprot.writeFieldBegin('fillInPlaceHolderToContentMap', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.fillInPlaceHolderToContentMap))
            for _kiter13, _viter14 in self.fillInPlaceHolderToContentMap.items():
                oprot.writeString(_kiter13.encode('utf-8') if sys.version_info[0] == 2 else _kiter13)
                oprot.writeString(_viter14.encode('utf-8') if sys.version_info[0] == 2 else _viter14)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.recipients is not None:
            oprot.writeFieldBegin('recipients', TType.STRUCT, 4)
            self.recipients.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
