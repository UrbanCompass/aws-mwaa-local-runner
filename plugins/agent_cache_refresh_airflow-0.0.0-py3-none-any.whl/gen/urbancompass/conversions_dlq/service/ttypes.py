
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.listings_conversion.service.ttypes

from thrift.transport import TTransport


class ErrorMetadata(object):
    """
    Attributes:
     - listingKey
     - listingId
     - sourceFeedName
     - errors
     - exceptionMessage
     - exceptionType
     - thriftCount
     - thriftMessage
     - reprocessData
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingKey', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'sourceFeedName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'errors', 'UTF8', None, ),  # 4
        (5, TType.LIST, 'exceptionMessage', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRING, 'exceptionType', 'UTF8', None, ),  # 6
        (7, TType.I32, 'thriftCount', None, None, ),  # 7
        (8, TType.LIST, 'thriftMessage', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.STRING, 'reprocessData', 'UTF8', None, ),  # 9
    )
    def __init__(self, listingKey=None, listingId=None, sourceFeedName=None, errors=None, exceptionMessage=None, exceptionType=None, thriftCount=None, thriftMessage=None, reprocessData=None, ):
        self.listingKey = listingKey
        self.listingId = listingId
        self.sourceFeedName = sourceFeedName
        self.errors = errors
        self.exceptionMessage = exceptionMessage
        self.exceptionType = exceptionType
        self.thriftCount = thriftCount
        self.thriftMessage = thriftMessage
        self.reprocessData = reprocessData

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.sourceFeedName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.errors = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.exceptionMessage = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.exceptionMessage.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.exceptionType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.thriftCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.thriftMessage = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.thriftMessage.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.reprocessData = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ErrorMetadata')
        if self.listingKey is not None:
            oprot.writeFieldBegin('listingKey', TType.STRING, 1)
            oprot.writeString(self.listingKey.encode('utf-8') if sys.version_info[0] == 2 else self.listingKey)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 2)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.sourceFeedName is not None:
            oprot.writeFieldBegin('sourceFeedName', TType.STRING, 3)
            oprot.writeString(self.sourceFeedName.encode('utf-8') if sys.version_info[0] == 2 else self.sourceFeedName)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.STRING, 4)
            oprot.writeString(self.errors.encode('utf-8') if sys.version_info[0] == 2 else self.errors)
            oprot.writeFieldEnd()
        if self.exceptionMessage is not None:
            oprot.writeFieldBegin('exceptionMessage', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.exceptionMessage))
            for _iter10 in self.exceptionMessage:
                oprot.writeString(_iter10.encode('utf-8') if sys.version_info[0] == 2 else _iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.exceptionType is not None:
            oprot.writeFieldBegin('exceptionType', TType.STRING, 6)
            oprot.writeString(self.exceptionType.encode('utf-8') if sys.version_info[0] == 2 else self.exceptionType)
            oprot.writeFieldEnd()
        if self.thriftCount is not None:
            oprot.writeFieldBegin('thriftCount', TType.I32, 7)
            oprot.writeI32(self.thriftCount)
            oprot.writeFieldEnd()
        if self.thriftMessage is not None:
            oprot.writeFieldBegin('thriftMessage', TType.LIST, 8)
            oprot.writeListBegin(TType.STRING, len(self.thriftMessage))
            for _iter11 in self.thriftMessage:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.reprocessData is not None:
            oprot.writeFieldBegin('reprocessData', TType.STRING, 9)
            oprot.writeString(self.reprocessData.encode('utf-8') if sys.version_info[0] == 2 else self.reprocessData)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReportSourceFeedsRequest(object):
    """
    Attributes:
     - sourceFeeds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'sourceFeeds', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, sourceFeeds=None, ):
        self.sourceFeeds = sourceFeeds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.sourceFeeds = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.sourceFeeds.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReportSourceFeedsRequest')
        if self.sourceFeeds is not None:
            oprot.writeFieldBegin('sourceFeeds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.sourceFeeds))
            for _iter16 in self.sourceFeeds:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReprocessPayload(object):
    """
    Attributes:
     - payloadType
     - traceId
     - metadata
     - tsCreatedAt
     - payloadSchemaId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'payloadType', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'traceId', 'UTF8', None, ),  # 2
        (3, TType.MAP, 'metadata', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.STRING, 'tsCreatedAt', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'payloadSchemaId', 'UTF8', None, ),  # 5
    )
    def __init__(self, payloadType=None, traceId=None, metadata=None, tsCreatedAt=None, payloadSchemaId=None, ):
        self.payloadType = payloadType
        self.traceId = traceId
        self.metadata = metadata
        self.tsCreatedAt = tsCreatedAt
        self.payloadSchemaId = payloadSchemaId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.payloadType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.traceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.metadata = {}
                    (_ktype18, _vtype19, _size22) = iprot.readMapBegin()
                    for _i17 in range(_size22):
                        _key20 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val21 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.metadata[_key20] = _val21
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.tsCreatedAt = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.payloadSchemaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReprocessPayload')
        if self.payloadType is not None:
            oprot.writeFieldBegin('payloadType', TType.STRING, 1)
            oprot.writeString(self.payloadType.encode('utf-8') if sys.version_info[0] == 2 else self.payloadType)
            oprot.writeFieldEnd()
        if self.traceId is not None:
            oprot.writeFieldBegin('traceId', TType.STRING, 2)
            oprot.writeString(self.traceId.encode('utf-8') if sys.version_info[0] == 2 else self.traceId)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.metadata))
            for _kiter23, _viter24 in self.metadata.items():
                oprot.writeString(_kiter23.encode('utf-8') if sys.version_info[0] == 2 else _kiter23)
                oprot.writeString(_viter24.encode('utf-8') if sys.version_info[0] == 2 else _viter24)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.tsCreatedAt is not None:
            oprot.writeFieldBegin('tsCreatedAt', TType.STRING, 4)
            oprot.writeString(self.tsCreatedAt.encode('utf-8') if sys.version_info[0] == 2 else self.tsCreatedAt)
            oprot.writeFieldEnd()
        if self.payloadSchemaId is not None:
            oprot.writeFieldBegin('payloadSchemaId', TType.STRING, 5)
            oprot.writeString(self.payloadSchemaId.encode('utf-8') if sys.version_info[0] == 2 else self.payloadSchemaId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReprocessSourceFeedsRequest(object):
    """
    Attributes:
     - sourceFeeds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'sourceFeeds', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, sourceFeeds=None, ):
        self.sourceFeeds = sourceFeeds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.sourceFeeds = []
                    (_etype25, _size28) = iprot.readListBegin()
                    for _i26 in range(_size28):
                        _elem27 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.sourceFeeds.append(_elem27)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReprocessSourceFeedsRequest')
        if self.sourceFeeds is not None:
            oprot.writeFieldBegin('sourceFeeds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.sourceFeeds))
            for _iter29 in self.sourceFeeds:
                oprot.writeString(_iter29.encode('utf-8') if sys.version_info[0] == 2 else _iter29)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReprocessSourceFeedsResponse(object):
    """
    Attributes:
     - status
     - result
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'result', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, result=None, ):
        self.status = status
        self.result = result

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.result = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReprocessSourceFeedsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.result is not None:
            oprot.writeFieldBegin('result', TType.STRING, 2)
            oprot.writeString(self.result.encode('utf-8') if sys.version_info[0] == 2 else self.result)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StoreListingResponse(object):
    """
    Attributes:
     - status
     - result
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'result', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, result=None, ):
        self.status = status
        self.result = result

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.result = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StoreListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.result is not None:
            oprot.writeFieldBegin('result', TType.STRING, 2)
            oprot.writeString(self.result.encode('utf-8') if sys.version_info[0] == 2 else self.result)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReportSourceFeedsResponse(object):
    """
    Attributes:
     - status
     - result
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'result', (TType.STRING, 'UTF8', TType.LIST, (TType.STRUCT, (ErrorMetadata, ErrorMetadata.thrift_spec), False), False), None, ),  # 2
    )
    def __init__(self, status=None, result=None, ):
        self.status = status
        self.result = result

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.result = {}
                    (_ktype31, _vtype32, _size35) = iprot.readMapBegin()
                    for _i30 in range(_size35):
                        _key33 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val34 = []
                        (_etype36, _size39) = iprot.readListBegin()
                        for _i37 in range(_size39):
                            _elem38 = ErrorMetadata()
                            _elem38.read(iprot)
                            _val34.append(_elem38)
                        iprot.readListEnd()
                        self.result[_key33] = _val34
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReportSourceFeedsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.result is not None:
            oprot.writeFieldBegin('result', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.result))
            for _kiter40, _viter41 in self.result.items():
                oprot.writeString(_kiter40.encode('utf-8') if sys.version_info[0] == 2 else _kiter40)
                oprot.writeListBegin(TType.STRUCT, len(_viter41))
                for _iter42 in _viter41:
                    _iter42.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StoreListingRequest(object):
    """
    Attributes:
     - errors
     - sourceFeedName
     - listingId
     - reprocessData
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'errors', (gen.urbancompass.listings_conversion.service.ttypes.DLQResponse, gen.urbancompass.listings_conversion.service.ttypes.DLQResponse.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'sourceFeedName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'listingId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'reprocessData', (ReprocessPayload, ReprocessPayload.thrift_spec), None, ),  # 4
    )
    def __init__(self, errors=None, sourceFeedName=None, listingId=None, reprocessData=None, ):
        self.errors = errors
        self.sourceFeedName = sourceFeedName
        self.listingId = listingId
        self.reprocessData = reprocessData

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.errors = gen.urbancompass.listings_conversion.service.ttypes.DLQResponse()
                    self.errors.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.sourceFeedName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.reprocessData = ReprocessPayload()
                    self.reprocessData.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StoreListingRequest')
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.STRUCT, 1)
            self.errors.write(oprot)
            oprot.writeFieldEnd()
        if self.sourceFeedName is not None:
            oprot.writeFieldBegin('sourceFeedName', TType.STRING, 2)
            oprot.writeString(self.sourceFeedName.encode('utf-8') if sys.version_info[0] == 2 else self.sourceFeedName)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 3)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.reprocessData is not None:
            oprot.writeFieldBegin('reprocessData', TType.STRUCT, 4)
            self.reprocessData.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
