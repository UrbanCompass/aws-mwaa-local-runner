
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes

from thrift.transport import TTransport


class PieChartStyle(object):
    PIE = 0
    DOUGHNUT = 1

    _VALUES_TO_NAMES = {
        0: "PIE",
        1: "DOUGHNUT",
    }

    _NAMES_TO_VALUES = {
        "PIE": 0,
        "DOUGHNUT": 1,
    }


class PieChartSettings(object):
    """
    Attributes:
     - includeLegend
     - displayPrimaryValuesInLegend
     - displaySecondaryValuesInLegend
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'includeLegend', None, None, ),  # 1
        (2, TType.BOOL, 'displayPrimaryValuesInLegend', None, None, ),  # 2
        (3, TType.BOOL, 'displaySecondaryValuesInLegend', None, None, ),  # 3
    )
    def __init__(self, includeLegend=None, displayPrimaryValuesInLegend=None, displaySecondaryValuesInLegend=None, ):
        self.includeLegend = includeLegend
        self.displayPrimaryValuesInLegend = displayPrimaryValuesInLegend
        self.displaySecondaryValuesInLegend = displaySecondaryValuesInLegend

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.includeLegend = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.displayPrimaryValuesInLegend = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.displaySecondaryValuesInLegend = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PieChartSettings')
        if self.includeLegend is not None:
            oprot.writeFieldBegin('includeLegend', TType.BOOL, 1)
            oprot.writeBool(self.includeLegend)
            oprot.writeFieldEnd()
        if self.displayPrimaryValuesInLegend is not None:
            oprot.writeFieldBegin('displayPrimaryValuesInLegend', TType.BOOL, 2)
            oprot.writeBool(self.displayPrimaryValuesInLegend)
            oprot.writeFieldEnd()
        if self.displaySecondaryValuesInLegend is not None:
            oprot.writeFieldBegin('displaySecondaryValuesInLegend', TType.BOOL, 3)
            oprot.writeBool(self.displaySecondaryValuesInLegend)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PieChart(object):
    """
    Attributes:
     - title
     - style
     - labelSeriesRef
     - primaryValueSeriesRef
     - secondaryValueSeriesRef
     - colorSeriesRef
     - primaryTotalSeriesRef
     - settings
     - description
     - icon
     - titleForReport
     - emptyView
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.I32, 'style', None, None, ),  # 2
        (3, TType.STRUCT, 'labelSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'primaryValueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'secondaryValueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'primaryTotalSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'settings', (PieChartSettings, PieChartSettings.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'colorSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 8
        (9, TType.STRING, 'description', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'icon', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'titleForReport', 'UTF8', None, ),  # 11
        (12, TType.STRUCT, 'emptyView', (gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView, gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView.thrift_spec), None, ),  # 12
    )
    def __init__(self, title=None, style=None, labelSeriesRef=None, primaryValueSeriesRef=None, secondaryValueSeriesRef=None, primaryTotalSeriesRef=None, settings=None, colorSeriesRef=None, description=None, icon=None, titleForReport=None, emptyView=None, ):
        self.title = title
        self.style = style
        self.labelSeriesRef = labelSeriesRef
        self.primaryValueSeriesRef = primaryValueSeriesRef
        self.secondaryValueSeriesRef = secondaryValueSeriesRef
        self.primaryTotalSeriesRef = primaryTotalSeriesRef
        self.settings = settings
        self.colorSeriesRef = colorSeriesRef
        self.description = description
        self.icon = icon
        self.titleForReport = titleForReport
        self.emptyView = emptyView

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.style = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.labelSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.labelSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.primaryValueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.primaryValueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.secondaryValueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.secondaryValueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.primaryTotalSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.primaryTotalSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.settings = PieChartSettings()
                    self.settings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.colorSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.colorSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.icon = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.titleForReport = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.emptyView = gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView()
                    self.emptyView.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PieChart')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.style is not None:
            oprot.writeFieldBegin('style', TType.I32, 2)
            oprot.writeI32(self.style)
            oprot.writeFieldEnd()
        if self.labelSeriesRef is not None:
            oprot.writeFieldBegin('labelSeriesRef', TType.STRUCT, 3)
            self.labelSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.primaryValueSeriesRef is not None:
            oprot.writeFieldBegin('primaryValueSeriesRef', TType.STRUCT, 4)
            self.primaryValueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.secondaryValueSeriesRef is not None:
            oprot.writeFieldBegin('secondaryValueSeriesRef', TType.STRUCT, 5)
            self.secondaryValueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.primaryTotalSeriesRef is not None:
            oprot.writeFieldBegin('primaryTotalSeriesRef', TType.STRUCT, 6)
            self.primaryTotalSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.settings is not None:
            oprot.writeFieldBegin('settings', TType.STRUCT, 7)
            self.settings.write(oprot)
            oprot.writeFieldEnd()
        if self.colorSeriesRef is not None:
            oprot.writeFieldBegin('colorSeriesRef', TType.STRUCT, 8)
            self.colorSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 9)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.icon is not None:
            oprot.writeFieldBegin('icon', TType.STRING, 10)
            oprot.writeString(self.icon.encode('utf-8') if sys.version_info[0] == 2 else self.icon)
            oprot.writeFieldEnd()
        if self.titleForReport is not None:
            oprot.writeFieldBegin('titleForReport', TType.STRING, 11)
            oprot.writeString(self.titleForReport.encode('utf-8') if sys.version_info[0] == 2 else self.titleForReport)
            oprot.writeFieldEnd()
        if self.emptyView is not None:
            oprot.writeFieldBegin('emptyView', TType.STRUCT, 12)
            self.emptyView.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
