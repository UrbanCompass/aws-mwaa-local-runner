
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class Gci(object):
    """
    Attributes:
     - lastTwelveMonths
     - yearToDate
     - termToDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'lastTwelveMonths', None, None, ),  # 1
        (2, TType.DOUBLE, 'yearToDate', None, None, ),  # 2
        (3, TType.DOUBLE, 'termToDate', None, None, ),  # 3
    )
    def __init__(self, lastTwelveMonths=None, yearToDate=None, termToDate=None, ):
        self.lastTwelveMonths = lastTwelveMonths
        self.yearToDate = yearToDate
        self.termToDate = termToDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.lastTwelveMonths = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.yearToDate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.termToDate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Gci')
        if self.lastTwelveMonths is not None:
            oprot.writeFieldBegin('lastTwelveMonths', TType.DOUBLE, 1)
            oprot.writeDouble(self.lastTwelveMonths)
            oprot.writeFieldEnd()
        if self.yearToDate is not None:
            oprot.writeFieldBegin('yearToDate', TType.DOUBLE, 2)
            oprot.writeDouble(self.yearToDate)
            oprot.writeFieldEnd()
        if self.termToDate is not None:
            oprot.writeFieldBegin('termToDate', TType.DOUBLE, 3)
            oprot.writeDouble(self.termToDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GciCriteria(object):
    """
    Attributes:
     - teamId
     - asOfDate
     - startDate
     - amaIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'asOfDate', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'startDate', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'amaIds', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, teamId=None, asOfDate=None, startDate=None, amaIds=None, ):
        self.teamId = teamId
        self.asOfDate = asOfDate
        self.startDate = startDate
        self.amaIds = amaIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.asOfDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.startDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.amaIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.amaIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GciCriteria')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.asOfDate is not None:
            oprot.writeFieldBegin('asOfDate', TType.STRING, 2)
            oprot.writeString(self.asOfDate.encode('utf-8') if sys.version_info[0] == 2 else self.asOfDate)
            oprot.writeFieldEnd()
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.STRING, 3)
            oprot.writeString(self.startDate.encode('utf-8') if sys.version_info[0] == 2 else self.startDate)
            oprot.writeFieldEnd()
        if self.amaIds is not None:
            oprot.writeFieldBegin('amaIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.amaIds))
            for _iter6 in self.amaIds:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
