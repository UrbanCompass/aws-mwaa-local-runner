
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.listing.address.ttypes
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.google.geocoding_result.ttypes
import gen.urbancompass.gis_service.gis_service.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.listing.listing_normalization.ttypes
import gen.urbancompass.property_type.ttypes

from thrift.transport import TTransport


class AsyncAddressNormalizationResult(object):
    CHANGES_MADE = 0
    NO_CHANGES = 1
    INTERNAL_ERROR = 2

    _VALUES_TO_NAMES = {
        0: "CHANGES_MADE",
        1: "NO_CHANGES",
        2: "INTERNAL_ERROR",
    }

    _NAMES_TO_VALUES = {
        "CHANGES_MADE": 0,
        "NO_CHANGES": 1,
        "INTERNAL_ERROR": 2,
    }


class AsyncGeocodingModes(object):
    SAVE_GEOCODING_RESULT = 0
    SAVE_SCHOOL_INFO = 1
    UPDATE_LISTING_FIELDS = 2

    _VALUES_TO_NAMES = {
        0: "SAVE_GEOCODING_RESULT",
        1: "SAVE_SCHOOL_INFO",
        2: "UPDATE_LISTING_FIELDS",
    }

    _NAMES_TO_VALUES = {
        "SAVE_GEOCODING_RESULT": 0,
        "SAVE_SCHOOL_INFO": 1,
        "UPDATE_LISTING_FIELDS": 2,
    }


class AsyncAddressNormalizationRequest(object):
    """
    Attributes:
     - propertyAddress
     - geolocationResult
     - parcelNumber
     - requester
     - kafkaResponseTopic
     - debugMode
     - verbose
     - requestIdentifiers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'propertyAddress', (gen.urbancompass.listing.address.ttypes.PropertyAddress, gen.urbancompass.listing.address.ttypes.PropertyAddress.thrift_spec), None, ),  # 1
        (2, TType.I32, 'geolocationResult', None, None, ),  # 2
        (3, TType.STRING, 'parcelNumber', 'UTF8', None, ),  # 3
        (4, TType.I32, 'requester', None, None, ),  # 4
        (5, TType.STRING, 'kafkaResponseTopic', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'debugMode', None, None, ),  # 6
        (7, TType.BOOL, 'verbose', None, None, ),  # 7
        (8, TType.MAP, 'requestIdentifiers', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 8
    )
    def __init__(self, propertyAddress=None, geolocationResult=None, parcelNumber=None, requester=None, kafkaResponseTopic=None, debugMode=None, verbose=None, requestIdentifiers=None, ):
        self.propertyAddress = propertyAddress
        self.geolocationResult = geolocationResult
        self.parcelNumber = parcelNumber
        self.requester = requester
        self.kafkaResponseTopic = kafkaResponseTopic
        self.debugMode = debugMode
        self.verbose = verbose
        self.requestIdentifiers = requestIdentifiers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.propertyAddress = gen.urbancompass.listing.address.ttypes.PropertyAddress()
                    self.propertyAddress.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.geolocationResult = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.parcelNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.requester = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.kafkaResponseTopic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.debugMode = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.verbose = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.requestIdentifiers = {}
                    (_ktype3, _vtype4, _size7) = iprot.readMapBegin()
                    for _i2 in range(_size7):
                        _key5 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val6 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.requestIdentifiers[_key5] = _val6
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AsyncAddressNormalizationRequest')
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRUCT, 1)
            self.propertyAddress.write(oprot)
            oprot.writeFieldEnd()
        if self.geolocationResult is not None:
            oprot.writeFieldBegin('geolocationResult', TType.I32, 2)
            oprot.writeI32(self.geolocationResult)
            oprot.writeFieldEnd()
        if self.parcelNumber is not None:
            oprot.writeFieldBegin('parcelNumber', TType.STRING, 3)
            oprot.writeString(self.parcelNumber.encode('utf-8') if sys.version_info[0] == 2 else self.parcelNumber)
            oprot.writeFieldEnd()
        if self.requester is not None:
            oprot.writeFieldBegin('requester', TType.I32, 4)
            oprot.writeI32(self.requester)
            oprot.writeFieldEnd()
        if self.kafkaResponseTopic is not None:
            oprot.writeFieldBegin('kafkaResponseTopic', TType.STRING, 5)
            oprot.writeString(self.kafkaResponseTopic.encode('utf-8') if sys.version_info[0] == 2 else self.kafkaResponseTopic)
            oprot.writeFieldEnd()
        if self.debugMode is not None:
            oprot.writeFieldBegin('debugMode', TType.BOOL, 6)
            oprot.writeBool(self.debugMode)
            oprot.writeFieldEnd()
        if self.verbose is not None:
            oprot.writeFieldBegin('verbose', TType.BOOL, 7)
            oprot.writeBool(self.verbose)
            oprot.writeFieldEnd()
        if self.requestIdentifiers is not None:
            oprot.writeFieldBegin('requestIdentifiers', TType.MAP, 8)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.requestIdentifiers))
            for _kiter8, _viter9 in self.requestIdentifiers.items():
                oprot.writeString(_kiter8.encode('utf-8') if sys.version_info[0] == 2 else _kiter8)
                oprot.writeString(_viter9.encode('utf-8') if sys.version_info[0] == 2 else _viter9)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AsyncAddressNormalizationUpdate(object):
    """
    Attributes:
     - oldCompassPropertyId
     - newCompassPropertyId
     - propertyAddress
     - isDebug
     - resultCode
     - errorMsg
     - verbose
     - requestIdentifiers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'oldCompassPropertyId', None, None, ),  # 1
        (2, TType.I64, 'newCompassPropertyId', None, None, ),  # 2
        (3, TType.STRUCT, 'propertyAddress', (gen.urbancompass.listing.address.ttypes.PropertyAddress, gen.urbancompass.listing.address.ttypes.PropertyAddress.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'isDebug', None, None, ),  # 4
        (5, TType.I32, 'resultCode', None, None, ),  # 5
        (6, TType.STRING, 'errorMsg', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'verbose', None, None, ),  # 7
        (8, TType.MAP, 'requestIdentifiers', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 8
    )
    def __init__(self, oldCompassPropertyId=None, newCompassPropertyId=None, propertyAddress=None, isDebug=None, resultCode=None, errorMsg=None, verbose=None, requestIdentifiers=None, ):
        self.oldCompassPropertyId = oldCompassPropertyId
        self.newCompassPropertyId = newCompassPropertyId
        self.propertyAddress = propertyAddress
        self.isDebug = isDebug
        self.resultCode = resultCode
        self.errorMsg = errorMsg
        self.verbose = verbose
        self.requestIdentifiers = requestIdentifiers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.oldCompassPropertyId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.newCompassPropertyId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.propertyAddress = gen.urbancompass.listing.address.ttypes.PropertyAddress()
                    self.propertyAddress.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isDebug = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.resultCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.errorMsg = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.verbose = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.requestIdentifiers = {}
                    (_ktype11, _vtype12, _size15) = iprot.readMapBegin()
                    for _i10 in range(_size15):
                        _key13 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.requestIdentifiers[_key13] = _val14
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AsyncAddressNormalizationUpdate')
        if self.oldCompassPropertyId is not None:
            oprot.writeFieldBegin('oldCompassPropertyId', TType.I64, 1)
            oprot.writeI64(self.oldCompassPropertyId)
            oprot.writeFieldEnd()
        if self.newCompassPropertyId is not None:
            oprot.writeFieldBegin('newCompassPropertyId', TType.I64, 2)
            oprot.writeI64(self.newCompassPropertyId)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRUCT, 3)
            self.propertyAddress.write(oprot)
            oprot.writeFieldEnd()
        if self.isDebug is not None:
            oprot.writeFieldBegin('isDebug', TType.BOOL, 4)
            oprot.writeBool(self.isDebug)
            oprot.writeFieldEnd()
        if self.resultCode is not None:
            oprot.writeFieldBegin('resultCode', TType.I32, 5)
            oprot.writeI32(self.resultCode)
            oprot.writeFieldEnd()
        if self.errorMsg is not None:
            oprot.writeFieldBegin('errorMsg', TType.STRING, 6)
            oprot.writeString(self.errorMsg.encode('utf-8') if sys.version_info[0] == 2 else self.errorMsg)
            oprot.writeFieldEnd()
        if self.verbose is not None:
            oprot.writeFieldBegin('verbose', TType.BOOL, 7)
            oprot.writeBool(self.verbose)
            oprot.writeFieldEnd()
        if self.requestIdentifiers is not None:
            oprot.writeFieldBegin('requestIdentifiers', TType.MAP, 8)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.requestIdentifiers))
            for _kiter16, _viter17 in self.requestIdentifiers.items():
                oprot.writeString(_kiter16.encode('utf-8') if sys.version_info[0] == 2 else _kiter16)
                oprot.writeString(_viter17.encode('utf-8') if sys.version_info[0] == 2 else _viter17)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AsyncStatusResponse(object):
    """
    Attributes:
     - status
     - errorMsg
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'errorMsg', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, errorMsg=None, ):
        self.status = status
        self.errorMsg = errorMsg

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.errorMsg = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AsyncStatusResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.errorMsg is not None:
            oprot.writeFieldBegin('errorMsg', TType.STRING, 2)
            oprot.writeString(self.errorMsg.encode('utf-8') if sys.version_info[0] == 2 else self.errorMsg)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GeocodingRequest(object):
    """
    Attributes:
     - listingId
     - listingIdSHA
     - geoId
     - fullAddress
     - __uc_id_sha__
     - saveToMessier
     - refresh
     - latitude
     - longitude
     - preferGoogle
     - messierListingId
     - listingType
     - unitType
     - unitNumber
     - dontCorrectAddress
     - sourceFeed
     - incrementalUpdate
     - zipCode
     - city
     - state
     - debugMode
     - modes
     - geolocationResult
     - latitudeFallBack
     - longitudeFallBack
     - geocodingFallBackLevel
     - compassPropertyId
     - parcelNumber
     - countyFipsCode
     - requestSource
     - assessorPrimaryParcelNumber
     - rawInputLatitude
     - rawInputLongitude
     - requester
     - kafkaResponseTopic
     - propertyType
     - verbose
     - requestIdentifiers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'geoId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'fullAddress', 'UTF8', None, ),  # 4
        (5, TType.STRING, '__uc_id_sha__', 'UTF8', None, ),  # 5
        (6, TType.I64, 'messierListingId', None, None, ),  # 6
        (7, TType.BOOL, 'saveToMessier', None, None, ),  # 7
        (8, TType.BOOL, 'refresh', None, None, ),  # 8
        (9, TType.DOUBLE, 'latitude', None, None, ),  # 9
        (10, TType.DOUBLE, 'longitude', None, None, ),  # 10
        (11, TType.BOOL, 'preferGoogle', None, None, ),  # 11
        (12, TType.I32, 'listingType', None, None, ),  # 12
        (13, TType.STRING, 'unitType', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'unitNumber', 'UTF8', None, ),  # 14
        (15, TType.BOOL, 'dontCorrectAddress', None, None, ),  # 15
        (16, TType.STRING, 'sourceFeed', 'UTF8', None, ),  # 16
        (17, TType.BOOL, 'incrementalUpdate', None, None, ),  # 17
        (18, TType.STRING, 'zipCode', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'city', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'state', 'UTF8', None, ),  # 20
        (21, TType.BOOL, 'debugMode', None, None, ),  # 21
        (22, TType.LIST, 'modes', (TType.I32, None, False), None, ),  # 22
        (23, TType.I32, 'geolocationResult', None, None, ),  # 23
        (24, TType.DOUBLE, 'latitudeFallBack', None, None, ),  # 24
        (25, TType.DOUBLE, 'longitudeFallBack', None, None, ),  # 25
        (26, TType.I32, 'geocodingFallBackLevel', None, None, ),  # 26
        (27, TType.I64, 'compassPropertyId', None, None, ),  # 27
        (28, TType.STRING, 'parcelNumber', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'countyFipsCode', 'UTF8', None, ),  # 29
        (30, TType.STRING, 'requestSource', 'UTF8', None, ),  # 30
        (31, TType.STRING, 'assessorPrimaryParcelNumber', 'UTF8', None, ),  # 31
        (32, TType.DOUBLE, 'rawInputLatitude', None, None, ),  # 32
        (33, TType.DOUBLE, 'rawInputLongitude', None, None, ),  # 33
        (34, TType.I32, 'requester', None, None, ),  # 34
        (35, TType.STRING, 'kafkaResponseTopic', 'UTF8', None, ),  # 35
        (36, TType.STRUCT, 'propertyType', (gen.urbancompass.property_type.ttypes.PropertyType, gen.urbancompass.property_type.ttypes.PropertyType.thrift_spec), None, ),  # 36
        (37, TType.BOOL, 'verbose', None, None, ),  # 37
        (38, TType.MAP, 'requestIdentifiers', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 38
    )
    def __init__(self, listingId=None, listingIdSHA=None, geoId=None, fullAddress=None, __uc_id_sha__=None, messierListingId=None, saveToMessier=None, refresh=None, latitude=None, longitude=None, preferGoogle=None, listingType=None, unitType=None, unitNumber=None, dontCorrectAddress=None, sourceFeed=None, incrementalUpdate=None, zipCode=None, city=None, state=None, debugMode=None, modes=None, geolocationResult=None, latitudeFallBack=None, longitudeFallBack=None, geocodingFallBackLevel=None, compassPropertyId=None, parcelNumber=None, countyFipsCode=None, requestSource=None, assessorPrimaryParcelNumber=None, rawInputLatitude=None, rawInputLongitude=None, requester=None, kafkaResponseTopic=None, propertyType=None, verbose=None, requestIdentifiers=None, ):
        self.listingId = listingId
        self.listingIdSHA = listingIdSHA
        self.geoId = geoId
        self.fullAddress = fullAddress
        self.__uc_id_sha__ = __uc_id_sha__
        self.messierListingId = messierListingId
        self.saveToMessier = saveToMessier
        self.refresh = refresh
        self.latitude = latitude
        self.longitude = longitude
        self.preferGoogle = preferGoogle
        self.listingType = listingType
        self.unitType = unitType
        self.unitNumber = unitNumber
        self.dontCorrectAddress = dontCorrectAddress
        self.sourceFeed = sourceFeed
        self.incrementalUpdate = incrementalUpdate
        self.zipCode = zipCode
        self.city = city
        self.state = state
        self.debugMode = debugMode
        self.modes = modes
        self.geolocationResult = geolocationResult
        self.latitudeFallBack = latitudeFallBack
        self.longitudeFallBack = longitudeFallBack
        self.geocodingFallBackLevel = geocodingFallBackLevel
        self.compassPropertyId = compassPropertyId
        self.parcelNumber = parcelNumber
        self.countyFipsCode = countyFipsCode
        self.requestSource = requestSource
        self.assessorPrimaryParcelNumber = assessorPrimaryParcelNumber
        self.rawInputLatitude = rawInputLatitude
        self.rawInputLongitude = rawInputLongitude
        self.requester = requester
        self.kafkaResponseTopic = kafkaResponseTopic
        self.propertyType = propertyType
        self.verbose = verbose
        self.requestIdentifiers = requestIdentifiers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.fullAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.__uc_id_sha__ = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.messierListingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.saveToMessier = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.refresh = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.latitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.DOUBLE:
                    self.longitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.preferGoogle = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.unitType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.unitNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.dontCorrectAddress = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.sourceFeed = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.incrementalUpdate = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.BOOL:
                    self.debugMode = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.LIST:
                    self.modes = []
                    (_etype18, _size21) = iprot.readListBegin()
                    for _i19 in range(_size21):
                        _elem20 = iprot.readI32()
                        self.modes.append(_elem20)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I32:
                    self.geolocationResult = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.DOUBLE:
                    self.latitudeFallBack = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.DOUBLE:
                    self.longitudeFallBack = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I32:
                    self.geocodingFallBackLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I64:
                    self.compassPropertyId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.parcelNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.countyFipsCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.requestSource = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.assessorPrimaryParcelNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.DOUBLE:
                    self.rawInputLatitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.DOUBLE:
                    self.rawInputLongitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.I32:
                    self.requester = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.kafkaResponseTopic = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRUCT:
                    self.propertyType = gen.urbancompass.property_type.ttypes.PropertyType()
                    self.propertyType.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.BOOL:
                    self.verbose = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.MAP:
                    self.requestIdentifiers = {}
                    (_ktype23, _vtype24, _size27) = iprot.readMapBegin()
                    for _i22 in range(_size27):
                        _key25 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val26 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.requestIdentifiers[_key25] = _val26
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GeocodingRequest')
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 1)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 2)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 3)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.fullAddress is not None:
            oprot.writeFieldBegin('fullAddress', TType.STRING, 4)
            oprot.writeString(self.fullAddress.encode('utf-8') if sys.version_info[0] == 2 else self.fullAddress)
            oprot.writeFieldEnd()
        if self.__uc_id_sha__ is not None:
            oprot.writeFieldBegin('__uc_id_sha__', TType.STRING, 5)
            oprot.writeString(self.__uc_id_sha__.encode('utf-8') if sys.version_info[0] == 2 else self.__uc_id_sha__)
            oprot.writeFieldEnd()
        if self.messierListingId is not None:
            oprot.writeFieldBegin('messierListingId', TType.I64, 6)
            oprot.writeI64(self.messierListingId)
            oprot.writeFieldEnd()
        if self.saveToMessier is not None:
            oprot.writeFieldBegin('saveToMessier', TType.BOOL, 7)
            oprot.writeBool(self.saveToMessier)
            oprot.writeFieldEnd()
        if self.refresh is not None:
            oprot.writeFieldBegin('refresh', TType.BOOL, 8)
            oprot.writeBool(self.refresh)
            oprot.writeFieldEnd()
        if self.latitude is not None:
            oprot.writeFieldBegin('latitude', TType.DOUBLE, 9)
            oprot.writeDouble(self.latitude)
            oprot.writeFieldEnd()
        if self.longitude is not None:
            oprot.writeFieldBegin('longitude', TType.DOUBLE, 10)
            oprot.writeDouble(self.longitude)
            oprot.writeFieldEnd()
        if self.preferGoogle is not None:
            oprot.writeFieldBegin('preferGoogle', TType.BOOL, 11)
            oprot.writeBool(self.preferGoogle)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 12)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.unitType is not None:
            oprot.writeFieldBegin('unitType', TType.STRING, 13)
            oprot.writeString(self.unitType.encode('utf-8') if sys.version_info[0] == 2 else self.unitType)
            oprot.writeFieldEnd()
        if self.unitNumber is not None:
            oprot.writeFieldBegin('unitNumber', TType.STRING, 14)
            oprot.writeString(self.unitNumber.encode('utf-8') if sys.version_info[0] == 2 else self.unitNumber)
            oprot.writeFieldEnd()
        if self.dontCorrectAddress is not None:
            oprot.writeFieldBegin('dontCorrectAddress', TType.BOOL, 15)
            oprot.writeBool(self.dontCorrectAddress)
            oprot.writeFieldEnd()
        if self.sourceFeed is not None:
            oprot.writeFieldBegin('sourceFeed', TType.STRING, 16)
            oprot.writeString(self.sourceFeed.encode('utf-8') if sys.version_info[0] == 2 else self.sourceFeed)
            oprot.writeFieldEnd()
        if self.incrementalUpdate is not None:
            oprot.writeFieldBegin('incrementalUpdate', TType.BOOL, 17)
            oprot.writeBool(self.incrementalUpdate)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 18)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 19)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 20)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.debugMode is not None:
            oprot.writeFieldBegin('debugMode', TType.BOOL, 21)
            oprot.writeBool(self.debugMode)
            oprot.writeFieldEnd()
        if self.modes is not None:
            oprot.writeFieldBegin('modes', TType.LIST, 22)
            oprot.writeListBegin(TType.I32, len(self.modes))
            for _iter28 in self.modes:
                oprot.writeI32(_iter28)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.geolocationResult is not None:
            oprot.writeFieldBegin('geolocationResult', TType.I32, 23)
            oprot.writeI32(self.geolocationResult)
            oprot.writeFieldEnd()
        if self.latitudeFallBack is not None:
            oprot.writeFieldBegin('latitudeFallBack', TType.DOUBLE, 24)
            oprot.writeDouble(self.latitudeFallBack)
            oprot.writeFieldEnd()
        if self.longitudeFallBack is not None:
            oprot.writeFieldBegin('longitudeFallBack', TType.DOUBLE, 25)
            oprot.writeDouble(self.longitudeFallBack)
            oprot.writeFieldEnd()
        if self.geocodingFallBackLevel is not None:
            oprot.writeFieldBegin('geocodingFallBackLevel', TType.I32, 26)
            oprot.writeI32(self.geocodingFallBackLevel)
            oprot.writeFieldEnd()
        if self.compassPropertyId is not None:
            oprot.writeFieldBegin('compassPropertyId', TType.I64, 27)
            oprot.writeI64(self.compassPropertyId)
            oprot.writeFieldEnd()
        if self.parcelNumber is not None:
            oprot.writeFieldBegin('parcelNumber', TType.STRING, 28)
            oprot.writeString(self.parcelNumber.encode('utf-8') if sys.version_info[0] == 2 else self.parcelNumber)
            oprot.writeFieldEnd()
        if self.countyFipsCode is not None:
            oprot.writeFieldBegin('countyFipsCode', TType.STRING, 29)
            oprot.writeString(self.countyFipsCode.encode('utf-8') if sys.version_info[0] == 2 else self.countyFipsCode)
            oprot.writeFieldEnd()
        if self.requestSource is not None:
            oprot.writeFieldBegin('requestSource', TType.STRING, 30)
            oprot.writeString(self.requestSource.encode('utf-8') if sys.version_info[0] == 2 else self.requestSource)
            oprot.writeFieldEnd()
        if self.assessorPrimaryParcelNumber is not None:
            oprot.writeFieldBegin('assessorPrimaryParcelNumber', TType.STRING, 31)
            oprot.writeString(self.assessorPrimaryParcelNumber.encode('utf-8') if sys.version_info[0] == 2 else self.assessorPrimaryParcelNumber)
            oprot.writeFieldEnd()
        if self.rawInputLatitude is not None:
            oprot.writeFieldBegin('rawInputLatitude', TType.DOUBLE, 32)
            oprot.writeDouble(self.rawInputLatitude)
            oprot.writeFieldEnd()
        if self.rawInputLongitude is not None:
            oprot.writeFieldBegin('rawInputLongitude', TType.DOUBLE, 33)
            oprot.writeDouble(self.rawInputLongitude)
            oprot.writeFieldEnd()
        if self.requester is not None:
            oprot.writeFieldBegin('requester', TType.I32, 34)
            oprot.writeI32(self.requester)
            oprot.writeFieldEnd()
        if self.kafkaResponseTopic is not None:
            oprot.writeFieldBegin('kafkaResponseTopic', TType.STRING, 35)
            oprot.writeString(self.kafkaResponseTopic.encode('utf-8') if sys.version_info[0] == 2 else self.kafkaResponseTopic)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.STRUCT, 36)
            self.propertyType.write(oprot)
            oprot.writeFieldEnd()
        if self.verbose is not None:
            oprot.writeFieldBegin('verbose', TType.BOOL, 37)
            oprot.writeBool(self.verbose)
            oprot.writeFieldEnd()
        if self.requestIdentifiers is not None:
            oprot.writeFieldBegin('requestIdentifiers', TType.MAP, 38)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.requestIdentifiers))
            for _kiter29, _viter30 in self.requestIdentifiers.items():
                oprot.writeString(_kiter29.encode('utf-8') if sys.version_info[0] == 2 else _kiter29)
                oprot.writeString(_viter30.encode('utf-8') if sys.version_info[0] == 2 else _viter30)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GeocodingResponse(object):
    """
    Attributes:
     - _id
     - listingId
     - listingIdSHA
     - geoId
     - fullAddress
     - results
     - lastUpdated
     - __uc_id_sha__
     - messierListingId
     - messierListingIdSHA
     - latLngSourceName
     - neighborhoods
     - county
     - countyFipsCode
     - debugMode
     - geoObject
     - boundaryObjects
     - nbhsId
     - state
     - countyId
     - zipCode
     - stateId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'geoId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'fullAddress', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'results', (TType.STRUCT, (gen.urbancompass.google.geocoding_result.ttypes.Result, gen.urbancompass.google.geocoding_result.ttypes.Result.thrift_spec), False), None, ),  # 6
        (7, TType.I64, 'lastUpdated', None, None, ),  # 7
        (8, TType.STRING, '__uc_id_sha__', 'UTF8', None, ),  # 8
        (9, TType.I64, 'messierListingId', None, None, ),  # 9
        (10, TType.STRING, 'messierListingIdSHA', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'latLngSourceName', 'UTF8', None, ),  # 11
        (12, TType.LIST, 'neighborhoods', (TType.STRING, 'UTF8', False), None, ),  # 12
        (13, TType.STRING, 'county', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'countyFipsCode', 'UTF8', None, ),  # 14
        (15, TType.BOOL, 'debugMode', None, None, ),  # 15
        (16, TType.STRUCT, 'geoObject', (gen.urbancompass.gis_service.gis_service.ttypes.Geography, gen.urbancompass.gis_service.gis_service.ttypes.Geography.thrift_spec), None, ),  # 16
        (17, TType.LIST, 'boundaryObjects', (TType.STRUCT, (gen.urbancompass.gis_service.gis_service.ttypes.PointShapeIntersectsResult, gen.urbancompass.gis_service.gis_service.ttypes.PointShapeIntersectsResult.thrift_spec), False), None, ),  # 17
        (18, TType.LIST, 'nbhsId', (TType.I64, None, False), None, ),  # 18
        (19, TType.STRING, 'state', 'UTF8', None, ),  # 19
        (20, TType.I64, 'countyId', None, None, ),  # 20
        (21, TType.STRING, 'zipCode', 'UTF8', None, ),  # 21
        (22, TType.I64, 'stateId', None, None, ),  # 22
    )
    def __init__(self, _id=None, listingId=None, listingIdSHA=None, geoId=None, fullAddress=None, results=None, lastUpdated=None, __uc_id_sha__=None, messierListingId=None, messierListingIdSHA=None, latLngSourceName=None, neighborhoods=None, county=None, countyFipsCode=None, debugMode=None, geoObject=None, boundaryObjects=None, nbhsId=None, state=None, countyId=None, zipCode=None, stateId=None, ):
        self._id = _id
        self.listingId = listingId
        self.listingIdSHA = listingIdSHA
        self.geoId = geoId
        self.fullAddress = fullAddress
        self.results = results
        self.lastUpdated = lastUpdated
        self.__uc_id_sha__ = __uc_id_sha__
        self.messierListingId = messierListingId
        self.messierListingIdSHA = messierListingIdSHA
        self.latLngSourceName = latLngSourceName
        self.neighborhoods = neighborhoods
        self.county = county
        self.countyFipsCode = countyFipsCode
        self.debugMode = debugMode
        self.geoObject = geoObject
        self.boundaryObjects = boundaryObjects
        self.nbhsId = nbhsId
        self.state = state
        self.countyId = countyId
        self.zipCode = zipCode
        self.stateId = stateId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.fullAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.results = []
                    (_etype31, _size34) = iprot.readListBegin()
                    for _i32 in range(_size34):
                        _elem33 = gen.urbancompass.google.geocoding_result.ttypes.Result()
                        _elem33.read(iprot)
                        self.results.append(_elem33)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastUpdated = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.__uc_id_sha__ = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.messierListingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.messierListingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.latLngSourceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.neighborhoods = []
                    (_etype35, _size38) = iprot.readListBegin()
                    for _i36 in range(_size38):
                        _elem37 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.neighborhoods.append(_elem37)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.county = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.countyFipsCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.debugMode = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.geoObject = gen.urbancompass.gis_service.gis_service.ttypes.Geography()
                    self.geoObject.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.boundaryObjects = []
                    (_etype39, _size42) = iprot.readListBegin()
                    for _i40 in range(_size42):
                        _elem41 = gen.urbancompass.gis_service.gis_service.ttypes.PointShapeIntersectsResult()
                        _elem41.read(iprot)
                        self.boundaryObjects.append(_elem41)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.LIST:
                    self.nbhsId = []
                    (_etype43, _size46) = iprot.readListBegin()
                    for _i44 in range(_size46):
                        _elem45 = iprot.readI64()
                        self.nbhsId.append(_elem45)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I64:
                    self.countyId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.stateId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GeocodingResponse')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 2)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 3)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 4)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.fullAddress is not None:
            oprot.writeFieldBegin('fullAddress', TType.STRING, 5)
            oprot.writeString(self.fullAddress.encode('utf-8') if sys.version_info[0] == 2 else self.fullAddress)
            oprot.writeFieldEnd()
        if self.results is not None:
            oprot.writeFieldBegin('results', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.results))
            for _iter47 in self.results:
                _iter47.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastUpdated is not None:
            oprot.writeFieldBegin('lastUpdated', TType.I64, 7)
            oprot.writeI64(self.lastUpdated)
            oprot.writeFieldEnd()
        if self.__uc_id_sha__ is not None:
            oprot.writeFieldBegin('__uc_id_sha__', TType.STRING, 8)
            oprot.writeString(self.__uc_id_sha__.encode('utf-8') if sys.version_info[0] == 2 else self.__uc_id_sha__)
            oprot.writeFieldEnd()
        if self.messierListingId is not None:
            oprot.writeFieldBegin('messierListingId', TType.I64, 9)
            oprot.writeI64(self.messierListingId)
            oprot.writeFieldEnd()
        if self.messierListingIdSHA is not None:
            oprot.writeFieldBegin('messierListingIdSHA', TType.STRING, 10)
            oprot.writeString(self.messierListingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.messierListingIdSHA)
            oprot.writeFieldEnd()
        if self.latLngSourceName is not None:
            oprot.writeFieldBegin('latLngSourceName', TType.STRING, 11)
            oprot.writeString(self.latLngSourceName.encode('utf-8') if sys.version_info[0] == 2 else self.latLngSourceName)
            oprot.writeFieldEnd()
        if self.neighborhoods is not None:
            oprot.writeFieldBegin('neighborhoods', TType.LIST, 12)
            oprot.writeListBegin(TType.STRING, len(self.neighborhoods))
            for _iter48 in self.neighborhoods:
                oprot.writeString(_iter48.encode('utf-8') if sys.version_info[0] == 2 else _iter48)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.county is not None:
            oprot.writeFieldBegin('county', TType.STRING, 13)
            oprot.writeString(self.county.encode('utf-8') if sys.version_info[0] == 2 else self.county)
            oprot.writeFieldEnd()
        if self.countyFipsCode is not None:
            oprot.writeFieldBegin('countyFipsCode', TType.STRING, 14)
            oprot.writeString(self.countyFipsCode.encode('utf-8') if sys.version_info[0] == 2 else self.countyFipsCode)
            oprot.writeFieldEnd()
        if self.debugMode is not None:
            oprot.writeFieldBegin('debugMode', TType.BOOL, 15)
            oprot.writeBool(self.debugMode)
            oprot.writeFieldEnd()
        if self.geoObject is not None:
            oprot.writeFieldBegin('geoObject', TType.STRUCT, 16)
            self.geoObject.write(oprot)
            oprot.writeFieldEnd()
        if self.boundaryObjects is not None:
            oprot.writeFieldBegin('boundaryObjects', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.boundaryObjects))
            for _iter49 in self.boundaryObjects:
                _iter49.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.nbhsId is not None:
            oprot.writeFieldBegin('nbhsId', TType.LIST, 18)
            oprot.writeListBegin(TType.I64, len(self.nbhsId))
            for _iter50 in self.nbhsId:
                oprot.writeI64(_iter50)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 19)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.countyId is not None:
            oprot.writeFieldBegin('countyId', TType.I64, 20)
            oprot.writeI64(self.countyId)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 21)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.stateId is not None:
            oprot.writeFieldBegin('stateId', TType.I64, 22)
            oprot.writeI64(self.stateId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
