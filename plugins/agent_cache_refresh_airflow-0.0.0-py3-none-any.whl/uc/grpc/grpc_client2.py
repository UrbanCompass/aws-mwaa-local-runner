# -*- coding: utf-8 -*-
"""
Modern grpc-thrift client for compass services.

:copyright: (c) 2016 by Compass, Inc.
"""
import logging
import sys
import types

import six
import grpc
from grpc._cython import cygrpc

from uc.grpc.client.client_stats_interceptor import ClientStatsInterceptor
from uc.grpc.client.client_profile_interceptor import ClientProfileInterceptor
from uc.grpc.client.client_internal_token_interceptor import ClientInternalTokenInterceptor
from uc.grpc.client.client_service_auth_interceptor import ClientServiceAuthInterceptor
from uc.grpc.client.client_timing_stats_interceptor import ClientTimingStatsInterceptor
from uc.grpc.client.client_traceid_interceptor import ClientTraceIdInterceptor
from uc.rpc_common import rpc_error


DEFAULT_MAX_MESSAGE_LENGTH = 100 * 1024 * 1024  # 100MB
DEFAULT_REQUEST_TIMEOUT_SECONDS = 5.0


class GrpcClient2(object):
    """Client for interacting with grpc-thrift compass services.

    This is as yet experimental and not widely used.
    It provides simpler implementation and simpler semantics than GRPCClient.

    Use this as:

      # In thrift
      ...
      service Service extends base.Service {
        SomeThriftMethodResponse someThriftMethod(1: SomeThriftMethodRequest r);
      }

      # In python
      client = GrpcClient2(ServiceStub, 'localhost:12345')

      request = SomeThriftMethodRequest(**kw)
      response = client.someThriftMethod(request)
      # or: response = client.someThriftMethod(request, timeout=non_default_timeout)

    Each thrift-service defined method can be accessed directly on the GrpcClient2.
    In the example above, client has a method someThriftMethod(
        request, timeout=None, metadata=None, credentials=None)
    All the optional parameters are grpc parameters as per grpc.UnaryUnaryMultiCallable.__call__'s
    signature (https://grpc.io/grpc/python/grpc.html#grpc.UnaryUnaryMultiCallable).
    """

    def __init__(
        self,
        cls,
        address,
        timeout_seconds=DEFAULT_REQUEST_TIMEOUT_SECONDS,
        max_message_length=DEFAULT_MAX_MESSAGE_LENGTH,
        enable_rr_load_balancing=True,
        log_threshold_ms=1000,
    ):
        """Create a GrpcClient2 for a given stub class and address.

        :param cls: The grpc stub class that was generated for the desired grpc server.
          This is named <your module>.grpc.<ServiceName>Stub
        :param address: The address of the grpc server that we want to talk to.
        :param timeout_seconds: grpc connection parameter
        :param max_message_length: grpc connection parameter
        :param enable_rr_load_balancing: Enable client side round robin load balancing
        """
        if not isinstance(address, str):
            raise AssertionError("Invalid address %r is not a string" % address)
        # NOTE(ugo): grpc.insecure_channel does not parse out grpc:// as a protocol, so it would
        # error (later, on the first RPC) if an address was in the form grpc://host:port
        if address.startswith("grpc://"):
            address = address[len("grpc://") :]
        options = [
            (cygrpc.ChannelArgKey.max_receive_message_length, max_message_length),
            (cygrpc.ChannelArgKey.max_send_message_length, max_message_length),
            (cygrpc.ChannelArgKey.default_authority, address),
        ]
        if enable_rr_load_balancing:
            options.append(("grpc.lb_policy_name", "round_robin"))
        self._log_threshold_ms = log_threshold_ms
        self.service_name = self._parse_service_name(cls)
        self._cls = cls
        self._address = address  # Used for testing
        self._timeout_seconds = timeout_seconds
        self._raw_grpc_channel = grpc.insecure_channel(address, options)
        self._channel = self._add_interceptors(self._raw_grpc_channel)
        self._channel_is_ready = grpc.channel_ready_future(self._channel)
        self._stub = self._cls(self._channel)
        # Install the stub's public methods. All the stub's public fields are thrift methods.
        for method in self._stub.__dict__:
            if not method.startswith("_"):
                try:
                    self._install_stub_method(method)
                except Exception:
                    # This should only happen in exotic cases where cls is not really a grpc stub. Or if
                    # we have a bug. Let's try to make sure that we have good errors if either happens.
                    logging.error(
                        "Error installing method %r from stub %r on %r", method, self._stub, self
                    )
                    raise

    def wait_until_ready(self, timeout_seconds=30):
        try:
            self._channel_is_ready.result(timeout=timeout_seconds)
        except grpc.FutureTimeoutError:
            connectivity = "unknown"
            connectivity_state = self._raw_grpc_channel._connectivity_state
            if connectivity_state and hasattr(connectivity_state, "connectivity"):
                connectivity = connectivity_state.connectivity
            logging.error(
                "Channel could not established connection after %d secs, with state: %r"
                % (timeout_seconds, connectivity)
            )
            raise

    def interceptors_sequence(self):
        """Provide the sequence of grpc interceptors for the channel. Called in the constructor.

        This is exposed as a public method so that it is easy to ovveride it by subclassing."""
        return [
            ClientTraceIdInterceptor(),
            ClientProfileInterceptor(),
            ClientTimingStatsInterceptor("WARN", self._log_threshold_ms),
            # TODO(ugo): figure out whether we need this:
            ClientStatsInterceptor(),
            ClientInternalTokenInterceptor(),
            ClientServiceAuthInterceptor(),
        ]

    def _add_interceptors(self, channel):
        interceptors = self.interceptors_sequence()
        for interceptor in interceptors:
            channel = grpc.intercept_channel(channel, interceptor)
        return channel

    def _parse_service_name(self, cls):
        if cls.__name__.endswith("Stub"):
            return cls.__name__[: -len("Stub")]
        raise AssertionError(
            "class %r does not look like a grpc stub. The typical name for "
            "the stub to service ServiceName that is in the python module "
            "gen.thrift.urbancompass.a.b.c is "
            "gen.thrift.urbancompass.a.b.c.grpc.ServiceNameStub" % cls.__name__
        )

    def __repr__(self):
        return "%s(%s, %r)" % (self.__class__.__name__, self._cls.__name__, self._address)

    def _install_stub_method(self, method_name):
        """Helper for the constructor to install one method from the stub onto this GrpcClient2."""
        stub_method = getattr(self._stub, method_name)

        def method_with_options(
            self,
            request,
            timeout=None,
            metadata=None,
            credentials=None,
            wait_for_ready=None,
            compression=None,
        ):
            """grpc-thrift method call.

            :param request: The request value for the RPC.
            :param timeout: An optional duration of time in seconds to allow for the RPC.
            :param metadata: Optional metadata to be transmitted to the service-side of the RPC.
            :param credentials: An optional CallCredentials for the RPC.
            :param wait_for_ready: An optional flag to enable wait for ready mechanism (EXPERIMENTAL).
            :param compression: An element of grpc.compression, e.g. grpc.compression.Gzip (EXPERIMENTAL)
            """
            if timeout is None:
                timeout = self._timeout_seconds
            try:
                return stub_method(
                    request, timeout, metadata, credentials, wait_for_ready, compression
                )
            except grpc.RpcError as e:
                six.reraise(
                    rpc_error.RpcError,
                    rpc_error.RpcError(error=e, rpc_client=self),
                    sys.exc_info()[2],
                )

        setattr(self, method_name, types.MethodType(method_with_options, self))
