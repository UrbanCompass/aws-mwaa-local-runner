
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes
import gen.urbancompass.region_compliance_checklist_model.ttypes
import gen.urbancompass.dms_region_config_service.regions.ttypes

from thrift.transport import TTransport


class BatchGetComplianceDocumentChecklistCriteriaRelationRequest(object):
    """
    Attributes:
     - checklistCriteriaIds
     - ids
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'checklistCriteriaIds', (TType.I32, None, False), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
        (3, TType.BOOL, 'includeDeleted', None, None, ),  # 3
    )
    def __init__(self, checklistCriteriaIds=None, ids=None, includeDeleted=None, ):
        self.checklistCriteriaIds = checklistCriteriaIds
        self.ids = ids
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.checklistCriteriaIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readI32()
                        self.checklistCriteriaIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readI32()
                        self.ids.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentChecklistCriteriaRelationRequest')
        if self.checklistCriteriaIds is not None:
            oprot.writeFieldBegin('checklistCriteriaIds', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.checklistCriteriaIds))
            for _iter10 in self.checklistCriteriaIds:
                oprot.writeI32(_iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter11 in self.ids:
                oprot.writeI32(_iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 3)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentChecklistCriteriaRelationResponse(object):
    """
    Attributes:
     - status
     - resultMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'resultMap', (TType.I32, None, TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, resultMap=None, ):
        self.status = status
        self.resultMap = resultMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.resultMap = {}
                    (_ktype13, _vtype14, _size17) = iprot.readMapBegin()
                    for _i12 in range(_size17):
                        _key15 = iprot.readI32()
                        _val16 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation()
                        _val16.read(iprot)
                        self.resultMap[_key15] = _val16
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentChecklistCriteriaRelationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.resultMap is not None:
            oprot.writeFieldBegin('resultMap', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.resultMap))
            for _kiter18, _viter19 in self.resultMap.items():
                oprot.writeI32(_kiter18)
                _viter19.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentChecklistCriteriaRequest(object):
    """
    Attributes:
     - ids
     - checklistIds
     - propertyType
     - listingType
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 1
        (2, TType.LIST, 'checklistIds', (TType.I32, None, False), None, ),  # 2
        (3, TType.I32, 'propertyType', None, None, ),  # 3
        (4, TType.I32, 'listingType', None, None, ),  # 4
        (5, TType.BOOL, 'includeDeleted', None, None, ),  # 5
    )
    def __init__(self, ids=None, checklistIds=None, propertyType=None, listingType=None, includeDeleted=None, ):
        self.ids = ids
        self.checklistIds = checklistIds
        self.propertyType = propertyType
        self.listingType = listingType
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = iprot.readI32()
                        self.ids.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistIds = []
                    (_etype24, _size27) = iprot.readListBegin()
                    for _i25 in range(_size27):
                        _elem26 = iprot.readI32()
                        self.checklistIds.append(_elem26)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentChecklistCriteriaRequest')
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter28 in self.ids:
                oprot.writeI32(_iter28)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.checklistIds is not None:
            oprot.writeFieldBegin('checklistIds', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.checklistIds))
            for _iter29 in self.checklistIds:
                oprot.writeI32(_iter29)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 3)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 4)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 5)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentChecklistCriteriaResponse(object):
    """
    Attributes:
     - status
     - resultMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'resultMap', (TType.I32, None, TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, resultMap=None, ):
        self.status = status
        self.resultMap = resultMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.resultMap = {}
                    (_ktype31, _vtype32, _size35) = iprot.readMapBegin()
                    for _i30 in range(_size35):
                        _key33 = iprot.readI32()
                        _val34 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria()
                        _val34.read(iprot)
                        self.resultMap[_key33] = _val34
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentChecklistCriteriaResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.resultMap is not None:
            oprot.writeFieldBegin('resultMap', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.resultMap))
            for _kiter36, _viter37 in self.resultMap.items():
                oprot.writeI32(_kiter36)
                _viter37.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentChecklistRequest(object):
    """
    Attributes:
     - ids
     - complianceState
     - market
     - version
     - includeDraft
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 1
        (2, TType.STRING, 'complianceState', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'market', 'UTF8', None, ),  # 3
        (4, TType.I32, 'version', None, None, ),  # 4
        (5, TType.BOOL, 'includeDraft', None, None, ),  # 5
        (6, TType.BOOL, 'includeDeleted', None, None, ),  # 6
    )
    def __init__(self, ids=None, complianceState=None, market=None, version=None, includeDraft=None, includeDeleted=None, ):
        self.ids = ids
        self.complianceState = complianceState
        self.market = market
        self.version = version
        self.includeDraft = includeDraft
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype38, _size41) = iprot.readListBegin()
                    for _i39 in range(_size41):
                        _elem40 = iprot.readI32()
                        self.ids.append(_elem40)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.includeDraft = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentChecklistRequest')
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter42 in self.ids:
                oprot.writeI32(_iter42)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 2)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 3)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 4)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.includeDraft is not None:
            oprot.writeFieldBegin('includeDraft', TType.BOOL, 5)
            oprot.writeBool(self.includeDraft)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 6)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentChecklistResponse(object):
    """
    Attributes:
     - status
     - resultMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'resultMap', (TType.I32, None, TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, resultMap=None, ):
        self.status = status
        self.resultMap = resultMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.resultMap = {}
                    (_ktype44, _vtype45, _size48) = iprot.readMapBegin()
                    for _i43 in range(_size48):
                        _key46 = iprot.readI32()
                        _val47 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist()
                        _val47.read(iprot)
                        self.resultMap[_key46] = _val47
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentChecklistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.resultMap is not None:
            oprot.writeFieldBegin('resultMap', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.resultMap))
            for _kiter49, _viter50 in self.resultMap.items():
                oprot.writeI32(_kiter49)
                _viter50.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentRequest(object):
    """
    Attributes:
     - ids
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 1
        (2, TType.BOOL, 'includeDeleted', None, None, ),  # 2
    )
    def __init__(self, ids=None, includeDeleted=None, ):
        self.ids = ids
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype51, _size54) = iprot.readListBegin()
                    for _i52 in range(_size54):
                        _elem53 = iprot.readI32()
                        self.ids.append(_elem53)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentRequest')
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter55 in self.ids:
                oprot.writeI32(_iter55)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 2)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetComplianceDocumentResponse(object):
    """
    Attributes:
     - status
     - resultMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'resultMap', (TType.I32, None, TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, resultMap=None, ):
        self.status = status
        self.resultMap = resultMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.resultMap = {}
                    (_ktype57, _vtype58, _size61) = iprot.readMapBegin()
                    for _i56 in range(_size61):
                        _key59 = iprot.readI32()
                        _val60 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal()
                        _val60.read(iprot)
                        self.resultMap[_key59] = _val60
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetComplianceDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.resultMap is not None:
            oprot.writeFieldBegin('resultMap', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.resultMap))
            for _kiter62, _viter63 in self.resultMap.items():
                oprot.writeI32(_kiter62)
                _viter63.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentChecklistCriteriaRelationRequest(object):
    """
    Attributes:
     - recordsToUpsert
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
    )
    def __init__(self, recordsToUpsert=None, userId=None, ):
        self.recordsToUpsert = recordsToUpsert
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype64, _size67) = iprot.readListBegin()
                    for _i65 in range(_size67):
                        _elem66 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation()
                        _elem66.read(iprot)
                        self.recordsToUpsert.append(_elem66)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentChecklistCriteriaRelationRequest')
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter68 in self.recordsToUpsert:
                _iter68.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentChecklistCriteriaRelationResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype69, _size72) = iprot.readListBegin()
                    for _i70 in range(_size72):
                        _elem71 = iprot.readI32()
                        self.ids.append(_elem71)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentChecklistCriteriaRelationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter73 in self.ids:
                oprot.writeI32(_iter73)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentChecklistCriteriaRequest(object):
    """
    Attributes:
     - recordsToUpsert
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
    )
    def __init__(self, recordsToUpsert=None, userId=None, ):
        self.recordsToUpsert = recordsToUpsert
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype74, _size77) = iprot.readListBegin()
                    for _i75 in range(_size77):
                        _elem76 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria()
                        _elem76.read(iprot)
                        self.recordsToUpsert.append(_elem76)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentChecklistCriteriaRequest')
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter78 in self.recordsToUpsert:
                _iter78.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentChecklistCriteriaResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype79, _size82) = iprot.readListBegin()
                    for _i80 in range(_size82):
                        _elem81 = iprot.readI32()
                        self.ids.append(_elem81)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentChecklistCriteriaResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter83 in self.ids:
                oprot.writeI32(_iter83)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentChecklistRequest(object):
    """
    Attributes:
     - recordsToUpsert
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
    )
    def __init__(self, recordsToUpsert=None, userId=None, ):
        self.recordsToUpsert = recordsToUpsert
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype84, _size87) = iprot.readListBegin()
                    for _i85 in range(_size87):
                        _elem86 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist()
                        _elem86.read(iprot)
                        self.recordsToUpsert.append(_elem86)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentChecklistRequest')
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter88 in self.recordsToUpsert:
                _iter88.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentChecklistResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype89, _size92) = iprot.readListBegin()
                    for _i90 in range(_size92):
                        _elem91 = iprot.readI32()
                        self.ids.append(_elem91)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentChecklistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter93 in self.ids:
                oprot.writeI32(_iter93)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentRequest(object):
    """
    Attributes:
     - recordsToUpsert
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
    )
    def __init__(self, recordsToUpsert=None, userId=None, ):
        self.recordsToUpsert = recordsToUpsert
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype94, _size97) = iprot.readListBegin()
                    for _i95 in range(_size97):
                        _elem96 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal()
                        _elem96.read(iprot)
                        self.recordsToUpsert.append(_elem96)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentRequest')
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter98 in self.recordsToUpsert:
                _iter98.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertComplianceDocumentResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype99, _size102) = iprot.readListBegin()
                    for _i100 in range(_size102):
                        _elem101 = iprot.readI32()
                        self.ids.append(_elem101)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertComplianceDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter103 in self.ids:
                oprot.writeI32(_iter103)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistAdminSettingsInternalRequest(object):
    """
    Attributes:
     - states
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'states', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, states=None, ):
        self.states = states

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.states = []
                    (_etype104, _size107) = iprot.readListBegin()
                    for _i105 in range(_size107):
                        _elem106 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.states.append(_elem106)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistAdminSettingsInternalRequest')
        if self.states is not None:
            oprot.writeFieldBegin('states', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.states))
            for _iter108 in self.states:
                oprot.writeString(_iter108.encode('utf-8') if sys.version_info[0] == 2 else _iter108)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistAdminSettingsInternalResponse(object):
    """
    Attributes:
     - status
     - regionSettingsMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'regionSettingsMap', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSettings, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSettings.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, regionSettingsMap=None, ):
        self.status = status
        self.regionSettingsMap = regionSettingsMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.regionSettingsMap = {}
                    (_ktype110, _vtype111, _size114) = iprot.readMapBegin()
                    for _i109 in range(_size114):
                        _key112 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val113 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSettings()
                        _val113.read(iprot)
                        self.regionSettingsMap[_key112] = _val113
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistAdminSettingsInternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.regionSettingsMap is not None:
            oprot.writeFieldBegin('regionSettingsMap', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.regionSettingsMap))
            for _kiter115, _viter116 in self.regionSettingsMap.items():
                oprot.writeString(_kiter115.encode('utf-8') if sys.version_info[0] == 2 else _kiter115)
                _viter116.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceChecklistDocumentsRequest(object):
    """
    Attributes:
     - complianceState
     - complianceCounty
     - market
     - propertyType
     - listingType
     - sideRepresentation
     - dealPhases
     - isDealReferral
     - version
     - propertyBuiltYear
     - isNewConstruction
     - dealType
     - purposeTypes
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'complianceState', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'complianceCounty', 'UTF8', None, ),  # 2
        (3, TType.I32, 'propertyType', None, None, ),  # 3
        (4, TType.I32, 'listingType', None, None, ),  # 4
        (5, TType.I32, 'sideRepresentation', None, None, ),  # 5
        (6, TType.LIST, 'dealPhases', (TType.I32, None, False), None, ),  # 6
        (7, TType.BOOL, 'isDealReferral', None, None, ),  # 7
        (8, TType.I32, 'version', None, None, ),  # 8
        (9, TType.I32, 'propertyBuiltYear', None, None, ),  # 9
        None,  # 10
        None,  # 11
        (12, TType.STRING, 'market', 'UTF8', None, ),  # 12
        (13, TType.BOOL, 'isNewConstruction', None, None, ),  # 13
        (14, TType.I32, 'dealType', None, None, ),  # 14
        (15, TType.LIST, 'purposeTypes', (TType.I32, None, False), None, ),  # 15
        (16, TType.BOOL, 'includeDeleted', None, None, ),  # 16
    )
    def __init__(self, complianceState=None, complianceCounty=None, propertyType=None, listingType=None, sideRepresentation=None, dealPhases=None, isDealReferral=None, version=None, propertyBuiltYear=None, market=None, isNewConstruction=None, dealType=None, purposeTypes=None, includeDeleted=None, ):
        self.complianceState = complianceState
        self.complianceCounty = complianceCounty
        self.propertyType = propertyType
        self.listingType = listingType
        self.sideRepresentation = sideRepresentation
        self.dealPhases = dealPhases
        self.isDealReferral = isDealReferral
        self.version = version
        self.propertyBuiltYear = propertyBuiltYear
        self.market = market
        self.isNewConstruction = isNewConstruction
        self.dealType = dealType
        self.purposeTypes = purposeTypes
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.complianceCounty = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.sideRepresentation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.dealPhases = []
                    (_etype117, _size120) = iprot.readListBegin()
                    for _i118 in range(_size120):
                        _elem119 = iprot.readI32()
                        self.dealPhases.append(_elem119)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isDealReferral = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.propertyBuiltYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.purposeTypes = []
                    (_etype121, _size124) = iprot.readListBegin()
                    for _i122 in range(_size124):
                        _elem123 = iprot.readI32()
                        self.purposeTypes.append(_elem123)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceChecklistDocumentsRequest')
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 1)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.complianceCounty is not None:
            oprot.writeFieldBegin('complianceCounty', TType.STRING, 2)
            oprot.writeString(self.complianceCounty.encode('utf-8') if sys.version_info[0] == 2 else self.complianceCounty)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 3)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 4)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.sideRepresentation is not None:
            oprot.writeFieldBegin('sideRepresentation', TType.I32, 5)
            oprot.writeI32(self.sideRepresentation)
            oprot.writeFieldEnd()
        if self.dealPhases is not None:
            oprot.writeFieldBegin('dealPhases', TType.LIST, 6)
            oprot.writeListBegin(TType.I32, len(self.dealPhases))
            for _iter125 in self.dealPhases:
                oprot.writeI32(_iter125)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isDealReferral is not None:
            oprot.writeFieldBegin('isDealReferral', TType.BOOL, 7)
            oprot.writeBool(self.isDealReferral)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 8)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.propertyBuiltYear is not None:
            oprot.writeFieldBegin('propertyBuiltYear', TType.I32, 9)
            oprot.writeI32(self.propertyBuiltYear)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 12)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 13)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 14)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.purposeTypes is not None:
            oprot.writeFieldBegin('purposeTypes', TType.LIST, 15)
            oprot.writeListBegin(TType.I32, len(self.purposeTypes))
            for _iter126 in self.purposeTypes:
                oprot.writeI32(_iter126)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 16)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceChecklistDocumentsResponse(object):
    """
    Attributes:
     - status
     - documents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'documents', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument, gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, documents=None, ):
        self.status = status
        self.documents = documents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.documents = []
                    (_etype127, _size130) = iprot.readListBegin()
                    for _i128 in range(_size130):
                        _elem129 = gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument()
                        _elem129.read(iprot)
                        self.documents.append(_elem129)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceChecklistDocumentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.documents is not None:
            oprot.writeFieldBegin('documents', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.documents))
            for _iter131 in self.documents:
                _iter131.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceChecklistRegionMarketsRequest(object):
    """
    Attributes:
     - state
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'state', 'UTF8', None, ),  # 1
    )
    def __init__(self, state=None, ):
        self.state = state

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceChecklistRegionMarketsRequest')
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 1)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceChecklistRegionMarketsResponse(object):
    """
    Attributes:
     - status
     - markets
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'markets', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, markets=None, ):
        self.status = status
        self.markets = markets

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.markets = []
                    (_etype132, _size135) = iprot.readListBegin()
                    for _i133 in range(_size135):
                        _elem134 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket()
                        _elem134.read(iprot)
                        self.markets.append(_elem134)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceChecklistRegionMarketsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.markets is not None:
            oprot.writeFieldBegin('markets', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.markets))
            for _iter136 in self.markets:
                _iter136.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceEmailSupportRequest(object):
    """
    Attributes:
     - complianceState
     - subMarketId
     - ctcServiceType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'complianceState', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'subMarketId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'ctcServiceType', None, None, ),  # 3
    )
    def __init__(self, complianceState=None, subMarketId=None, ctcServiceType=None, ):
        self.complianceState = complianceState
        self.subMarketId = subMarketId
        self.ctcServiceType = ctcServiceType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.subMarketId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceEmailSupportRequest')
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 1)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.subMarketId is not None:
            oprot.writeFieldBegin('subMarketId', TType.STRING, 2)
            oprot.writeString(self.subMarketId.encode('utf-8') if sys.version_info[0] == 2 else self.subMarketId)
            oprot.writeFieldEnd()
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 3)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceEmailSupportResponse(object):
    """
    Attributes:
     - status
     - email
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, email=None, ):
        self.status = status
        self.email = email

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceEmailSupportResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetRegionSpecificPropertyTypesRequest(object):
    """
    Attributes:
     - region
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'region', 'UTF8', None, ),  # 1
    )
    def __init__(self, region=None, ):
        self.region = region

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.region = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetRegionSpecificPropertyTypesRequest')
        if self.region is not None:
            oprot.writeFieldBegin('region', TType.STRING, 1)
            oprot.writeString(self.region.encode('utf-8') if sys.version_info[0] == 2 else self.region)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetRegionSpecificPropertyTypesResponse(object):
    """
    Attributes:
     - status
     - propertyTypes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'propertyTypes', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, propertyTypes=None, ):
        self.status = status
        self.propertyTypes = propertyTypes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype137, _size140) = iprot.readListBegin()
                    for _i138 in range(_size140):
                        _elem139 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType()
                        _elem139.read(iprot)
                        self.propertyTypes.append(_elem139)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetRegionSpecificPropertyTypesResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.propertyTypes))
            for _iter141 in self.propertyTypes:
                _iter141.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetRegionSpecificSettingsRequest(object):
    """
    Attributes:
     - subMarketId
     - sideRepresentation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'subMarketId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'sideRepresentation', None, None, ),  # 2
    )
    def __init__(self, subMarketId=None, sideRepresentation=None, ):
        self.subMarketId = subMarketId
        self.sideRepresentation = sideRepresentation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.subMarketId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.sideRepresentation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetRegionSpecificSettingsRequest')
        if self.subMarketId is not None:
            oprot.writeFieldBegin('subMarketId', TType.STRING, 1)
            oprot.writeString(self.subMarketId.encode('utf-8') if sys.version_info[0] == 2 else self.subMarketId)
            oprot.writeFieldEnd()
        if self.sideRepresentation is not None:
            oprot.writeFieldBegin('sideRepresentation', TType.I32, 2)
            oprot.writeI32(self.sideRepresentation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetRegionSpecificSettingsResponse(object):
    """
    Attributes:
     - status
     - propertyTypes
     - ctcServiceTypes
     - markets
     - propertyTypesMap
     - documentReviewSettings
     - infoUrl
     - isCommissionStatementRequestEnabled
     - disableDualRepWithoutSameAgent
     - commissionStatementRequestInfo
     - regionBasedOptionalFieldsMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'propertyTypes', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'ctcServiceTypes', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificCtcServiceType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificCtcServiceType.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'markets', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket.thrift_spec), False), None, ),  # 4
        (5, TType.MAP, 'propertyTypesMap', (TType.STRING, 'UTF8', TType.LIST, (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType.thrift_spec), False), False), None, ),  # 5
        (6, TType.STRUCT, 'documentReviewSettings', (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionDocumentReviewSettings, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionDocumentReviewSettings.thrift_spec), None, ),  # 6
        (7, TType.STRING, 'infoUrl', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isCommissionStatementRequestEnabled', None, None, ),  # 8
        (9, TType.BOOL, 'disableDualRepWithoutSameAgent', None, None, ),  # 9
        (10, TType.STRUCT, 'commissionStatementRequestInfo', (gen.urbancompass.dms_region_config_service.regions.ttypes.CommissionStatementRequestInfo, gen.urbancompass.dms_region_config_service.regions.ttypes.CommissionStatementRequestInfo.thrift_spec), None, ),  # 10
        (11, TType.MAP, 'regionBasedOptionalFieldsMap', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 11
    )
    def __init__(self, status=None, propertyTypes=None, ctcServiceTypes=None, markets=None, propertyTypesMap=None, documentReviewSettings=None, infoUrl=None, isCommissionStatementRequestEnabled=None, disableDualRepWithoutSameAgent=None, commissionStatementRequestInfo=None, regionBasedOptionalFieldsMap=None, ):
        self.status = status
        self.propertyTypes = propertyTypes
        self.ctcServiceTypes = ctcServiceTypes
        self.markets = markets
        self.propertyTypesMap = propertyTypesMap
        self.documentReviewSettings = documentReviewSettings
        self.infoUrl = infoUrl
        self.isCommissionStatementRequestEnabled = isCommissionStatementRequestEnabled
        self.disableDualRepWithoutSameAgent = disableDualRepWithoutSameAgent
        self.commissionStatementRequestInfo = commissionStatementRequestInfo
        self.regionBasedOptionalFieldsMap = regionBasedOptionalFieldsMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype142, _size145) = iprot.readListBegin()
                    for _i143 in range(_size145):
                        _elem144 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType()
                        _elem144.read(iprot)
                        self.propertyTypes.append(_elem144)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.ctcServiceTypes = []
                    (_etype146, _size149) = iprot.readListBegin()
                    for _i147 in range(_size149):
                        _elem148 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificCtcServiceType()
                        _elem148.read(iprot)
                        self.ctcServiceTypes.append(_elem148)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.markets = []
                    (_etype150, _size153) = iprot.readListBegin()
                    for _i151 in range(_size153):
                        _elem152 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket()
                        _elem152.read(iprot)
                        self.markets.append(_elem152)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.propertyTypesMap = {}
                    (_ktype155, _vtype156, _size159) = iprot.readMapBegin()
                    for _i154 in range(_size159):
                        _key157 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val158 = []
                        (_etype160, _size163) = iprot.readListBegin()
                        for _i161 in range(_size163):
                            _elem162 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType()
                            _elem162.read(iprot)
                            _val158.append(_elem162)
                        iprot.readListEnd()
                        self.propertyTypesMap[_key157] = _val158
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.documentReviewSettings = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionDocumentReviewSettings()
                    self.documentReviewSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.infoUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isCommissionStatementRequestEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.disableDualRepWithoutSameAgent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.commissionStatementRequestInfo = gen.urbancompass.dms_region_config_service.regions.ttypes.CommissionStatementRequestInfo()
                    self.commissionStatementRequestInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.MAP:
                    self.regionBasedOptionalFieldsMap = {}
                    (_ktype165, _vtype166, _size169) = iprot.readMapBegin()
                    for _i164 in range(_size169):
                        _key167 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val168 = []
                        (_etype170, _size173) = iprot.readListBegin()
                        for _i171 in range(_size173):
                            _elem172 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val168.append(_elem172)
                        iprot.readListEnd()
                        self.regionBasedOptionalFieldsMap[_key167] = _val168
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetRegionSpecificSettingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.propertyTypes))
            for _iter174 in self.propertyTypes:
                _iter174.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ctcServiceTypes is not None:
            oprot.writeFieldBegin('ctcServiceTypes', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.ctcServiceTypes))
            for _iter175 in self.ctcServiceTypes:
                _iter175.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.markets is not None:
            oprot.writeFieldBegin('markets', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.markets))
            for _iter176 in self.markets:
                _iter176.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.propertyTypesMap is not None:
            oprot.writeFieldBegin('propertyTypesMap', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.propertyTypesMap))
            for _kiter177, _viter178 in self.propertyTypesMap.items():
                oprot.writeString(_kiter177.encode('utf-8') if sys.version_info[0] == 2 else _kiter177)
                oprot.writeListBegin(TType.STRUCT, len(_viter178))
                for _iter179 in _viter178:
                    _iter179.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.documentReviewSettings is not None:
            oprot.writeFieldBegin('documentReviewSettings', TType.STRUCT, 6)
            self.documentReviewSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.infoUrl is not None:
            oprot.writeFieldBegin('infoUrl', TType.STRING, 7)
            oprot.writeString(self.infoUrl.encode('utf-8') if sys.version_info[0] == 2 else self.infoUrl)
            oprot.writeFieldEnd()
        if self.isCommissionStatementRequestEnabled is not None:
            oprot.writeFieldBegin('isCommissionStatementRequestEnabled', TType.BOOL, 8)
            oprot.writeBool(self.isCommissionStatementRequestEnabled)
            oprot.writeFieldEnd()
        if self.disableDualRepWithoutSameAgent is not None:
            oprot.writeFieldBegin('disableDualRepWithoutSameAgent', TType.BOOL, 9)
            oprot.writeBool(self.disableDualRepWithoutSameAgent)
            oprot.writeFieldEnd()
        if self.commissionStatementRequestInfo is not None:
            oprot.writeFieldBegin('commissionStatementRequestInfo', TType.STRUCT, 10)
            self.commissionStatementRequestInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.regionBasedOptionalFieldsMap is not None:
            oprot.writeFieldBegin('regionBasedOptionalFieldsMap', TType.MAP, 11)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.regionBasedOptionalFieldsMap))
            for _kiter180, _viter181 in self.regionBasedOptionalFieldsMap.items():
                oprot.writeString(_kiter180.encode('utf-8') if sys.version_info[0] == 2 else _kiter180)
                oprot.writeListBegin(TType.STRING, len(_viter181))
                for _iter182 in _viter181:
                    oprot.writeString(_iter182.encode('utf-8') if sys.version_info[0] == 2 else _iter182)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TriggerUploadComplianceChecklistRequest(object):
    """
    Attributes:
     - checklistSourceFileName
     - complianceState
     - version
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'checklistSourceFileName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'complianceState', 'UTF8', None, ),  # 2
        (3, TType.I32, 'version', None, None, ),  # 3
    )
    def __init__(self, checklistSourceFileName=None, complianceState=None, version=None, ):
        self.checklistSourceFileName = checklistSourceFileName
        self.complianceState = complianceState
        self.version = version

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.checklistSourceFileName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TriggerUploadComplianceChecklistRequest')
        if self.checklistSourceFileName is not None:
            oprot.writeFieldBegin('checklistSourceFileName', TType.STRING, 1)
            oprot.writeString(self.checklistSourceFileName.encode('utf-8') if sys.version_info[0] == 2 else self.checklistSourceFileName)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 2)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 3)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TriggerUploadComplianceChecklistResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TriggerUploadComplianceChecklistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
