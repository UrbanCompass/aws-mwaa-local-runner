
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.agent_data_platform.commons.adp_commons.ttypes

from thrift.transport import TTransport


class CommissionCapSplit(object):
    """
    Attributes:
     - preCapSplit
     - postCapSplit
     - capAmount
     - incentiveSplit
     - brokerAccountSplit
     - capSplitTermOptionCode
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'preCapSplit', None, None, ),  # 1
        (2, TType.DOUBLE, 'postCapSplit', None, None, ),  # 2
        (3, TType.DOUBLE, 'capAmount', None, None, ),  # 3
        (4, TType.DOUBLE, 'incentiveSplit', None, None, ),  # 4
        (5, TType.DOUBLE, 'brokerAccountSplit', None, None, ),  # 5
        (6, TType.STRING, 'capSplitTermOptionCode', 'UTF8', None, ),  # 6
    )
    def __init__(self, preCapSplit=None, postCapSplit=None, capAmount=None, incentiveSplit=None, brokerAccountSplit=None, capSplitTermOptionCode=None, ):
        self.preCapSplit = preCapSplit
        self.postCapSplit = postCapSplit
        self.capAmount = capAmount
        self.incentiveSplit = incentiveSplit
        self.brokerAccountSplit = brokerAccountSplit
        self.capSplitTermOptionCode = capSplitTermOptionCode

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.preCapSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.postCapSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.capAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.incentiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.brokerAccountSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.capSplitTermOptionCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionCapSplit')
        if self.preCapSplit is not None:
            oprot.writeFieldBegin('preCapSplit', TType.DOUBLE, 1)
            oprot.writeDouble(self.preCapSplit)
            oprot.writeFieldEnd()
        if self.postCapSplit is not None:
            oprot.writeFieldBegin('postCapSplit', TType.DOUBLE, 2)
            oprot.writeDouble(self.postCapSplit)
            oprot.writeFieldEnd()
        if self.capAmount is not None:
            oprot.writeFieldBegin('capAmount', TType.DOUBLE, 3)
            oprot.writeDouble(self.capAmount)
            oprot.writeFieldEnd()
        if self.incentiveSplit is not None:
            oprot.writeFieldBegin('incentiveSplit', TType.DOUBLE, 4)
            oprot.writeDouble(self.incentiveSplit)
            oprot.writeFieldEnd()
        if self.brokerAccountSplit is not None:
            oprot.writeFieldBegin('brokerAccountSplit', TType.DOUBLE, 5)
            oprot.writeDouble(self.brokerAccountSplit)
            oprot.writeFieldEnd()
        if self.capSplitTermOptionCode is not None:
            oprot.writeFieldBegin('capSplitTermOptionCode', TType.STRING, 6)
            oprot.writeString(self.capSplitTermOptionCode.encode('utf-8') if sys.version_info[0] == 2 else self.capSplitTermOptionCode)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Fee(object):
    """
    Attributes:
     - amount
     - percent
     - cap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'amount', None, None, ),  # 1
        (2, TType.DOUBLE, 'percent', None, None, ),  # 2
        (3, TType.DOUBLE, 'cap', None, None, ),  # 3
    )
    def __init__(self, amount=None, percent=None, cap=None, ):
        self.amount = amount
        self.percent = percent
        self.cap = cap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.cap = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Fee')
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 1)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 2)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.cap is not None:
            oprot.writeFieldBegin('cap', TType.DOUBLE, 3)
            oprot.writeDouble(self.cap)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Split(object):
    """
    Attributes:
     - baseSplit
     - incentiveSplit
     - totalSplit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'baseSplit', None, None, ),  # 1
        (2, TType.DOUBLE, 'incentiveSplit', None, None, ),  # 2
        (3, TType.DOUBLE, 'totalSplit', None, None, ),  # 3
    )
    def __init__(self, baseSplit=None, incentiveSplit=None, totalSplit=None, ):
        self.baseSplit = baseSplit
        self.incentiveSplit = incentiveSplit
        self.totalSplit = totalSplit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.baseSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.incentiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.totalSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Split')
        if self.baseSplit is not None:
            oprot.writeFieldBegin('baseSplit', TType.DOUBLE, 1)
            oprot.writeDouble(self.baseSplit)
            oprot.writeFieldEnd()
        if self.incentiveSplit is not None:
            oprot.writeFieldBegin('incentiveSplit', TType.DOUBLE, 2)
            oprot.writeDouble(self.incentiveSplit)
            oprot.writeFieldEnd()
        if self.totalSplit is not None:
            oprot.writeFieldBegin('totalSplit', TType.DOUBLE, 3)
            oprot.writeDouble(self.totalSplit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StandardSplit(object):
    """
    Attributes:
     - baseSplit
     - incentiveSplit
     - totalSplit
     - splitPolicyApplies
     - baseAgentSplitType
     - brokerAccountSplit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'baseSplit', None, None, ),  # 1
        (2, TType.DOUBLE, 'incentiveSplit', None, None, ),  # 2
        (3, TType.DOUBLE, 'totalSplit', None, None, ),  # 3
        (4, TType.BOOL, 'splitPolicyApplies', None, None, ),  # 4
        (5, TType.STRING, 'baseAgentSplitType', 'UTF8', None, ),  # 5
        (6, TType.DOUBLE, 'brokerAccountSplit', None, None, ),  # 6
    )
    def __init__(self, baseSplit=None, incentiveSplit=None, totalSplit=None, splitPolicyApplies=None, baseAgentSplitType=None, brokerAccountSplit=None, ):
        self.baseSplit = baseSplit
        self.incentiveSplit = incentiveSplit
        self.totalSplit = totalSplit
        self.splitPolicyApplies = splitPolicyApplies
        self.baseAgentSplitType = baseAgentSplitType
        self.brokerAccountSplit = brokerAccountSplit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.baseSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.incentiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.totalSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.splitPolicyApplies = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.baseAgentSplitType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.brokerAccountSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StandardSplit')
        if self.baseSplit is not None:
            oprot.writeFieldBegin('baseSplit', TType.DOUBLE, 1)
            oprot.writeDouble(self.baseSplit)
            oprot.writeFieldEnd()
        if self.incentiveSplit is not None:
            oprot.writeFieldBegin('incentiveSplit', TType.DOUBLE, 2)
            oprot.writeDouble(self.incentiveSplit)
            oprot.writeFieldEnd()
        if self.totalSplit is not None:
            oprot.writeFieldBegin('totalSplit', TType.DOUBLE, 3)
            oprot.writeDouble(self.totalSplit)
            oprot.writeFieldEnd()
        if self.splitPolicyApplies is not None:
            oprot.writeFieldBegin('splitPolicyApplies', TType.BOOL, 4)
            oprot.writeBool(self.splitPolicyApplies)
            oprot.writeFieldEnd()
        if self.baseAgentSplitType is not None:
            oprot.writeFieldBegin('baseAgentSplitType', TType.STRING, 5)
            oprot.writeString(self.baseAgentSplitType.encode('utf-8') if sys.version_info[0] == 2 else self.baseAgentSplitType)
            oprot.writeFieldEnd()
        if self.brokerAccountSplit is not None:
            oprot.writeFieldBegin('brokerAccountSplit', TType.DOUBLE, 6)
            oprot.writeDouble(self.brokerAccountSplit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TermRange(object):
    """
    Attributes:
     - startDate
     - endDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'startDate', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'endDate', 'UTF8', None, ),  # 2
    )
    def __init__(self, startDate=None, endDate=None, ):
        self.startDate = startDate
        self.endDate = endDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.startDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.endDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TermRange')
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.STRING, 1)
            oprot.writeString(self.startDate.encode('utf-8') if sys.version_info[0] == 2 else self.startDate)
            oprot.writeFieldEnd()
        if self.endDate is not None:
            oprot.writeFieldBegin('endDate', TType.STRING, 2)
            oprot.writeString(self.endDate.encode('utf-8') if sys.version_info[0] == 2 else self.endDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionSplit(object):
    """
    Attributes:
     - defaultBaseAgentSplit
     - minimumThreshold
     - maximumThreshold
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'defaultBaseAgentSplit', None, None, ),  # 1
        (2, TType.DOUBLE, 'minimumThreshold', None, None, ),  # 2
        (3, TType.DOUBLE, 'maximumThreshold', None, None, ),  # 3
    )
    def __init__(self, defaultBaseAgentSplit=None, minimumThreshold=None, maximumThreshold=None, ):
        self.defaultBaseAgentSplit = defaultBaseAgentSplit
        self.minimumThreshold = minimumThreshold
        self.maximumThreshold = maximumThreshold

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.defaultBaseAgentSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.minimumThreshold = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.maximumThreshold = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionSplit')
        if self.defaultBaseAgentSplit is not None:
            oprot.writeFieldBegin('defaultBaseAgentSplit', TType.DOUBLE, 1)
            oprot.writeDouble(self.defaultBaseAgentSplit)
            oprot.writeFieldEnd()
        if self.minimumThreshold is not None:
            oprot.writeFieldBegin('minimumThreshold', TType.DOUBLE, 2)
            oprot.writeDouble(self.minimumThreshold)
            oprot.writeFieldEnd()
        if self.maximumThreshold is not None:
            oprot.writeFieldBegin('maximumThreshold', TType.DOUBLE, 3)
            oprot.writeDouble(self.maximumThreshold)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PeriodFee(object):
    """
    Attributes:
     - fee
     - frequency
     - effectiveEndDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'fee', (Fee, Fee.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'frequency', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'effectiveEndDate', 'UTF8', None, ),  # 3
    )
    def __init__(self, fee=None, frequency=None, effectiveEndDate=None, ):
        self.fee = fee
        self.frequency = frequency
        self.effectiveEndDate = effectiveEndDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.fee = Fee()
                    self.fee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.frequency = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.effectiveEndDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PeriodFee')
        if self.fee is not None:
            oprot.writeFieldBegin('fee', TType.STRUCT, 1)
            self.fee.write(oprot)
            oprot.writeFieldEnd()
        if self.frequency is not None:
            oprot.writeFieldBegin('frequency', TType.STRING, 2)
            oprot.writeString(self.frequency.encode('utf-8') if sys.version_info[0] == 2 else self.frequency)
            oprot.writeFieldEnd()
        if self.effectiveEndDate is not None:
            oprot.writeFieldBegin('effectiveEndDate', TType.STRING, 3)
            oprot.writeString(self.effectiveEndDate.encode('utf-8') if sys.version_info[0] == 2 else self.effectiveEndDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionCountIncentiveSplit(object):
    """
    Attributes:
     - allotment
     - maxThreshold
     - split
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'allotment', None, None, ),  # 1
        (2, TType.I32, 'maxThreshold', None, None, ),  # 2
        (3, TType.STRUCT, 'split', (Split, Split.thrift_spec), None, ),  # 3
    )
    def __init__(self, allotment=None, maxThreshold=None, split=None, ):
        self.allotment = allotment
        self.maxThreshold = maxThreshold
        self.split = split

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.allotment = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.maxThreshold = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.split = Split()
                    self.split.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionCountIncentiveSplit')
        if self.allotment is not None:
            oprot.writeFieldBegin('allotment', TType.I32, 1)
            oprot.writeI32(self.allotment)
            oprot.writeFieldEnd()
        if self.maxThreshold is not None:
            oprot.writeFieldBegin('maxThreshold', TType.I32, 2)
            oprot.writeI32(self.maxThreshold)
            oprot.writeFieldEnd()
        if self.split is not None:
            oprot.writeFieldBegin('split', TType.STRUCT, 3)
            self.split.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResourceFee(object):
    """
    Attributes:
     - type
     - periodFee
     - calculationType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'type', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'periodFee', (PeriodFee, PeriodFee.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'calculationType', 'UTF8', None, ),  # 3
    )
    def __init__(self, type=None, periodFee=None, calculationType=None, ):
        self.type = type
        self.periodFee = periodFee
        self.calculationType = calculationType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.periodFee = PeriodFee()
                    self.periodFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.calculationType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResourceFee')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 1)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.periodFee is not None:
            oprot.writeFieldBegin('periodFee', TType.STRUCT, 2)
            self.periodFee.write(oprot)
            oprot.writeFieldEnd()
        if self.calculationType is not None:
            oprot.writeFieldBegin('calculationType', TType.STRING, 3)
            oprot.writeString(self.calculationType.encode('utf-8') if sys.version_info[0] == 2 else self.calculationType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommissionableTerms(object):
    """
    Attributes:
     - contractId
     - policyId
     - ltmGCI
     - validForAutomatedCommissions
     - splitModelType
     - status
     - termRange
     - baseSplitModel
     - transactionCountIncentiveSplit
     - resourceFee
     - transactionSplitModel
     - tcSplitIncentiveType
     - contractExternalId
     - agentRole
     - amaId
     - commissionCapSplit
     - resourceFeeTermRange
     - agentSplitTermRange
     - tciTermRange
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contractId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'policyId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'ltmGCI', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'validForAutomatedCommissions', None, None, ),  # 4
        (5, TType.STRING, 'splitModelType', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'status', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'termRange', (TermRange, TermRange.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'baseSplitModel', (StandardSplit, StandardSplit.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'transactionCountIncentiveSplit', (TransactionCountIncentiveSplit, TransactionCountIncentiveSplit.thrift_spec), None, ),  # 9
        (10, TType.STRUCT, 'resourceFee', (ResourceFee, ResourceFee.thrift_spec), None, ),  # 10
        (11, TType.LIST, 'transactionSplitModel', (TType.STRUCT, (TransactionSplit, TransactionSplit.thrift_spec), False), None, ),  # 11
        (12, TType.STRING, 'tcSplitIncentiveType', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'contractExternalId', 'UTF8', None, ),  # 13
        (14, TType.I32, 'agentRole', None, None, ),  # 14
        (15, TType.STRING, 'amaId', 'UTF8', None, ),  # 15
        (16, TType.STRUCT, 'commissionCapSplit', (CommissionCapSplit, CommissionCapSplit.thrift_spec), None, ),  # 16
        (17, TType.STRUCT, 'resourceFeeTermRange', (TermRange, TermRange.thrift_spec), None, ),  # 17
        (18, TType.STRUCT, 'agentSplitTermRange', (TermRange, TermRange.thrift_spec), None, ),  # 18
        (19, TType.STRUCT, 'tciTermRange', (TermRange, TermRange.thrift_spec), None, ),  # 19
    )
    def __init__(self, contractId=None, policyId=None, ltmGCI=None, validForAutomatedCommissions=None, splitModelType=None, status=None, termRange=None, baseSplitModel=None, transactionCountIncentiveSplit=None, resourceFee=None, transactionSplitModel=None, tcSplitIncentiveType=None, contractExternalId=None, agentRole=None, amaId=None, commissionCapSplit=None, resourceFeeTermRange=None, agentSplitTermRange=None, tciTermRange=None, ):
        self.contractId = contractId
        self.policyId = policyId
        self.ltmGCI = ltmGCI
        self.validForAutomatedCommissions = validForAutomatedCommissions
        self.splitModelType = splitModelType
        self.status = status
        self.termRange = termRange
        self.baseSplitModel = baseSplitModel
        self.transactionCountIncentiveSplit = transactionCountIncentiveSplit
        self.resourceFee = resourceFee
        self.transactionSplitModel = transactionSplitModel
        self.tcSplitIncentiveType = tcSplitIncentiveType
        self.contractExternalId = contractExternalId
        self.agentRole = agentRole
        self.amaId = amaId
        self.commissionCapSplit = commissionCapSplit
        self.resourceFeeTermRange = resourceFeeTermRange
        self.agentSplitTermRange = agentSplitTermRange
        self.tciTermRange = tciTermRange

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contractId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.policyId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.ltmGCI = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.validForAutomatedCommissions = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.splitModelType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.status = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.termRange = TermRange()
                    self.termRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.baseSplitModel = StandardSplit()
                    self.baseSplitModel.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.transactionCountIncentiveSplit = TransactionCountIncentiveSplit()
                    self.transactionCountIncentiveSplit.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.resourceFee = ResourceFee()
                    self.resourceFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.transactionSplitModel = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = TransactionSplit()
                        _elem4.read(iprot)
                        self.transactionSplitModel.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.tcSplitIncentiveType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.contractExternalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.agentRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.commissionCapSplit = CommissionCapSplit()
                    self.commissionCapSplit.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRUCT:
                    self.resourceFeeTermRange = TermRange()
                    self.resourceFeeTermRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRUCT:
                    self.agentSplitTermRange = TermRange()
                    self.agentSplitTermRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRUCT:
                    self.tciTermRange = TermRange()
                    self.tciTermRange.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionableTerms')
        if self.contractId is not None:
            oprot.writeFieldBegin('contractId', TType.STRING, 1)
            oprot.writeString(self.contractId.encode('utf-8') if sys.version_info[0] == 2 else self.contractId)
            oprot.writeFieldEnd()
        if self.policyId is not None:
            oprot.writeFieldBegin('policyId', TType.STRING, 2)
            oprot.writeString(self.policyId.encode('utf-8') if sys.version_info[0] == 2 else self.policyId)
            oprot.writeFieldEnd()
        if self.ltmGCI is not None:
            oprot.writeFieldBegin('ltmGCI', TType.STRING, 3)
            oprot.writeString(self.ltmGCI.encode('utf-8') if sys.version_info[0] == 2 else self.ltmGCI)
            oprot.writeFieldEnd()
        if self.validForAutomatedCommissions is not None:
            oprot.writeFieldBegin('validForAutomatedCommissions', TType.BOOL, 4)
            oprot.writeBool(self.validForAutomatedCommissions)
            oprot.writeFieldEnd()
        if self.splitModelType is not None:
            oprot.writeFieldBegin('splitModelType', TType.STRING, 5)
            oprot.writeString(self.splitModelType.encode('utf-8') if sys.version_info[0] == 2 else self.splitModelType)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRING, 6)
            oprot.writeString(self.status.encode('utf-8') if sys.version_info[0] == 2 else self.status)
            oprot.writeFieldEnd()
        if self.termRange is not None:
            oprot.writeFieldBegin('termRange', TType.STRUCT, 7)
            self.termRange.write(oprot)
            oprot.writeFieldEnd()
        if self.baseSplitModel is not None:
            oprot.writeFieldBegin('baseSplitModel', TType.STRUCT, 8)
            self.baseSplitModel.write(oprot)
            oprot.writeFieldEnd()
        if self.transactionCountIncentiveSplit is not None:
            oprot.writeFieldBegin('transactionCountIncentiveSplit', TType.STRUCT, 9)
            self.transactionCountIncentiveSplit.write(oprot)
            oprot.writeFieldEnd()
        if self.resourceFee is not None:
            oprot.writeFieldBegin('resourceFee', TType.STRUCT, 10)
            self.resourceFee.write(oprot)
            oprot.writeFieldEnd()
        if self.transactionSplitModel is not None:
            oprot.writeFieldBegin('transactionSplitModel', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.transactionSplitModel))
            for _iter6 in self.transactionSplitModel:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.tcSplitIncentiveType is not None:
            oprot.writeFieldBegin('tcSplitIncentiveType', TType.STRING, 12)
            oprot.writeString(self.tcSplitIncentiveType.encode('utf-8') if sys.version_info[0] == 2 else self.tcSplitIncentiveType)
            oprot.writeFieldEnd()
        if self.contractExternalId is not None:
            oprot.writeFieldBegin('contractExternalId', TType.STRING, 13)
            oprot.writeString(self.contractExternalId.encode('utf-8') if sys.version_info[0] == 2 else self.contractExternalId)
            oprot.writeFieldEnd()
        if self.agentRole is not None:
            oprot.writeFieldBegin('agentRole', TType.I32, 14)
            oprot.writeI32(self.agentRole)
            oprot.writeFieldEnd()
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 15)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.commissionCapSplit is not None:
            oprot.writeFieldBegin('commissionCapSplit', TType.STRUCT, 16)
            self.commissionCapSplit.write(oprot)
            oprot.writeFieldEnd()
        if self.resourceFeeTermRange is not None:
            oprot.writeFieldBegin('resourceFeeTermRange', TType.STRUCT, 17)
            self.resourceFeeTermRange.write(oprot)
            oprot.writeFieldEnd()
        if self.agentSplitTermRange is not None:
            oprot.writeFieldBegin('agentSplitTermRange', TType.STRUCT, 18)
            self.agentSplitTermRange.write(oprot)
            oprot.writeFieldEnd()
        if self.tciTermRange is not None:
            oprot.writeFieldBegin('tciTermRange', TType.STRUCT, 19)
            self.tciTermRange.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
