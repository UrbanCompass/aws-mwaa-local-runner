
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
ABINGTON = "Abington"
ACTON = "Acton"
ACUSHNET = "Acushnet"
ALLSTON = "Allston"
AMESBURY = "Amesbury"
ANDOVER = "Andover"
ARLINGTON = "Arlington"
ASHAWAY = "Ashaway"
ASHBURNHAM = "Ashburnham"
ASHBY = "Ashby"
ASHLAND = "Ashland"
ASSONET = "Assonet"
ATHOL = "Athol"
ATTLEBORO = "Attleboro"
ATTLEBORO_FALLS = "Attleboro Falls"
AUBURN = "Auburn"
AUBURNDALE = "Auburndale"
AVON = "Avon"
AYER = "Ayer"
BALDWINVILLE = "Baldwinville"
BARNSTABLE = "Barnstable"
BARRE = "Barre"
BEDFORD = "Bedford"
BELLINGHAM = "Bellingham"
BELMONT = "Belmont"
BERKLEY = "Berkley"
BERLIN = "Berlin"
BEVERLY = "Beverly"
BILLERICA = "Billerica"
BLACKSTONE = "Blackstone"
BLOCK_ISLAND = "Block Island"
BOLTON = "Bolton"
BOSTON = "Boston"
BOURNE = "Bourne"
BOXBORO = "Boxboro"
BOXBOROUGH = "Boxborough"
BOXFORD = "Boxford"
BOYLSTON = "Boylston"
BRADFORD = "Bradford"
BRAINTREE = "Braintree"
BREWSTER = "Brewster"
BRIDGEWATER = "Bridgewater"
BRIGHTON = "Brighton"
BROCKTON = "Brockton"
BROOKFIELD = "Brookfield"
BROOKLINE = "Brookline"
BURLINGTON = "Burlington"
BUZZARDS_BAY = "Buzzards Bay"
BYFIELD = "Byfield"
CAMBRIDGE = "Cambridge"
CANTON = "Canton"
CARLISLE = "Carlisle"
CAROLINA = "Carolina"
CARVER = "Carver"
CATAUMET = "Cataumet"
CENTERVILLE = "Centerville"
CHARLESTOWN = "Charlestown"
CHARLTON = "Charlton"
CHATHAM = "Chatham"
CHELMSFORD = "Chelmsford"
CHELSEA = "Chelsea"
CHERRY_VALLEY = "Cherry Valley"
CHESTNUT_HILL = "Chestnut Hill"
CHILMARK = "Chilmark"
CITIES = [
    "Abington",
    "Acton",
    "Acushnet",
    "Allston",
    "Amesbury",
    "Andover",
    "Arlington",
    "Ashaway",
    "Ashburnham",
    "Ashby",
    "Ashland",
    "Assonet",
    "Athol",
    "Attleboro",
    "Attleboro Falls",
    "Auburn",
    "Auburndale",
    "Avon",
    "Ayer",
    "Baldwinville",
    "Barnstable",
    "Barre",
    "Bedford",
    "Bellingham",
    "Belmont",
    "Berkley",
    "Berlin",
    "Beverly",
    "Billerica",
    "Blackstone",
    "Block Island",
    "Bolton",
    "Boston",
    "Bourne",
    "Boxboro",
    "Boxborough",
    "Boxford",
    "Boylston",
    "Bradford",
    "Braintree",
    "Brewster",
    "Bridgewater",
    "Brighton",
    "Brockton",
    "Brookfield",
    "Brookline",
    "Burlington",
    "Buzzards Bay",
    "Byfield",
    "Cambridge",
    "Canton",
    "Carlisle",
    "Carolina",
    "Carver",
    "Cataumet",
    "Centerville",
    "Charlestown",
    "Charlton",
    "Chatham",
    "Chelmsford",
    "Chelsea",
    "Cherry Valley",
    "Chestnut Hill",
    "Chilmark",
    "Clinton",
    "Cohasset",
    "Concord",
    "Cotuit",
    "Cuttyhunk",
    "Danvers",
    "Dartmouth",
    "Dedham",
    "Dennis",
    "Dennis Port",
    "Devens",
    "Dighton",
    "Dorchester",
    "Dorchester Center",
    "Douglas",
    "Dover",
    "Dracut",
    "Dudley",
    "Dunstable",
    "Duxbury",
    "Eastham",
    "Easton",
    "East Boston",
    "East Bridgewater",
    "East Brookfield",
    "East Falmouth",
    "East Freetown",
    "East Sandwich",
    "East Taunton",
    "East Walpole",
    "East Wareham",
    "East Weymouth",
    "Edgartown",
    "Essex",
    "Everett",
    "Exeter",
    "Fairhaven",
    "Fall River",
    "Falmouth",
    "Fayville",
    "Fiskdale",
    "Fitchburg",
    "Forestdale",
    "Foxboro",
    "Framingham",
    "Franklin",
    "Gardner",
    "Georgetown",
    "Gilbertville",
    "Gloucester",
    "Grafton",
    "Groton",
    "Groveland",
    "Halifax",
    "Hamilton",
    "Hanover",
    "Hanscom AFB",
    "Hanson",
    "Hardwick",
    "Harvard",
    "Harwich",
    "Harwich Port",
    "Hathorne",
    "Haverhill",
    "Hingham",
    "Holbrook",
    "Holden",
    "Holliston",
    "Hopedale",
    "Hope Valley",
    "Hopkinton",
    "Hubbardston",
    "Hudson",
    "Hull",
    "Hyannis",
    "Hyannis Port",
    "Hyde Park",
    "Ipswich",
    "Jamaica Plain",
    "Jamestown",
    "Jefferson",
    "Kenyon",
    "Kingston",
    "Lakeville",
    "Lancaster",
    "Lawrence",
    "Leicester",
    "Leominster",
    "Lexington",
    "Lincoln",
    "Littleton",
    "Little Compton",
    "Lowell",
    "Lunenburg",
    "Lynn",
    "Lynnfield",
    "Malden",
    "Manchester",
    "Manchester-by-the-Sea",
    "Mansfield",
    "Marblehead",
    "Marion",
    "Marlborough",
    "Marshfield",
    "Marstons Mills",
    "Mashpee",
    "Mattapan",
    "Mattapoisett",
    "Maynard",
    "Medfield",
    "Medford",
    "Medway",
    "Melrose",
    "Mendon",
    "Merrimac",
    "Methuen",
    "Middleboro",
    "Middleton",
    "Middletown",
    "Milford",
    "Millbury",
    "Millis",
    "Millville",
    "Milton",
    "Monponsett",
    "Nahant",
    "Nantucket",
    "Narragansett",
    "Natick",
    "Needham",
    "Needham Heights",
    "Newbury",
    "Newburyport",
    "Newport",
    "Newton",
    "Newtonville",
    "Newton Center",
    "Newton Highlands",
    "Newton Lower Falls",
    "Newton Upper Falls",
    "New Bedford",
    "New Braintree",
    "Norfolk",
    "Northborough",
    "Northbridge",
    "North Andover",
    "North Attleboro",
    "North Billerica",
    "North Brookfield",
    "North Chatham",
    "North Chelmsford",
    "North Dartmouth",
    "North Dighton",
    "North Easton",
    "North Falmouth",
    "North Grafton",
    "North Kingstown",
    "North Oxford",
    "North Reading",
    "North Truro",
    "North Weymouth",
    "Norton",
    "Norwell",
    "Norwood",
    "Oakham",
    "Oak Bluffs",
    "Onset",
    "Orleans",
    "Osterville",
    "Oxford",
    "Paxton",
    "Peabody",
    "Pembroke",
    "Pepperell",
    "Petersham",
    "Plainville",
    "Plymouth",
    "Plympton",
    "Pocasset",
    "Portsmouth",
    "Princeton",
    "Provincetown",
    "Quincy",
    "Randolph",
    "Raynham",
    "Reading",
    "Readville",
    "Rehoboth",
    "Revere",
    "Rochdale",
    "Rochester",
    "Rockland",
    "Rockport",
    "Rockville",
    "Roslindale",
    "Rowley",
    "Roxbury",
    "Roxbury Crossing",
    "Royalston",
    "Rutland",
    "Sagamore Beach",
    "Salem",
    "Salisbury",
    "Sandwich",
    "Saugus",
    "Saunderstown",
    "Scituate",
    "Seekonk",
    "Shannock",
    "Sharon",
    "Sherborn",
    "Shirley",
    "Shrewsbury",
    "Siasconset",
    "Slocum",
    "Somerset",
    "Somerville",
    "Southborough",
    "Southbridge",
    "South Barre",
    "South Boston",
    "South Chatham",
    "South Dartmouth",
    "South Dennis",
    "South Easton",
    "South Grafton",
    "South Hamilton",
    "South Walpole",
    "South Wellfleet",
    "South Weymouth",
    "South Yarmouth",
    "Spencer",
    "Sterling",
    "Stoneham",
    "Stoughton",
    "Stow",
    "Sturbridge",
    "Sudbury",
    "Sutton",
    "Swampscott",
    "Swansea",
    "Taunton",
    "Teaticket",
    "Templeton",
    "Tewksbury",
    "Tiverton",
    "Topsfield",
    "Townsend",
    "Truro",
    "Tyngsboro",
    "Upton",
    "Uxbridge",
    "Vineyard Haven",
    "Waban",
    "Wakefield",
    "Walpole",
    "Waltham",
    "Wareham",
    "Warren",
    "Watertown",
    "Wayland",
    "Webster",
    "Wellesley",
    "Wellesley Hills",
    "Wellfleet",
    "Wenham",
    "Westborough",
    "Westerly",
    "Westford",
    "Westminster",
    "Weston",
    "Westport",
    "Westport Point",
    "Westwood",
    "West Barnstable",
    "West Boylston",
    "West Bridgewater",
    "West Brookfield",
    "West Dennis",
    "West Harwich",
    "West Kingston",
    "West Newbury",
    "West Newton",
    "West Roxbury",
    "West Tisbury",
    "West Townsend",
    "West Wareham",
    "West Warren",
    "West Yarmouth",
    "Weymouth",
    "Whitinsville",
    "Whitman",
    "Wilmington",
    "Winchendon",
    "Winchester",
    "Winthrop",
    "Woburn",
    "Woods Hole",
    "Wood River Junction",
    "Worcester",
    "Wrentham",
    "Wyoming",
    "Yarmouth",
    "Yarmouth Port",
]
CLINTON = "Clinton"
COHASSET = "Cohasset"
CONCORD = "Concord"
COTUIT = "Cotuit"
CUTTYHUNK = "Cuttyhunk"
DANVERS = "Danvers"
DARTMOUTH = "Dartmouth"
DEDHAM = "Dedham"
DENNIS = "Dennis"
DENNIS_PORT = "Dennis Port"
DEVENS = "Devens"
DIGHTON = "Dighton"
DORCHESTER = "Dorchester"
DORCHESTER_CENTER = "Dorchester Center"
DOUGLAS = "Douglas"
DOVER = "Dover"
DRACUT = "Dracut"
DUDLEY = "Dudley"
DUNSTABLE = "Dunstable"
DUXBURY = "Duxbury"
EASTHAM = "Eastham"
EASTON = "Easton"
EAST_BOSTON = "East Boston"
EAST_BRIDGEWATER = "East Bridgewater"
EAST_BROOKFIELD = "East Brookfield"
EAST_FALMOUTH = "East Falmouth"
EAST_FREETOWN = "East Freetown"
EAST_SANDWICH = "East Sandwich"
EAST_TAUNTON = "East Taunton"
EAST_WALPOLE = "East Walpole"
EAST_WAREHAM = "East Wareham"
EAST_WEYMOUTH = "East Weymouth"
EDGARTOWN = "Edgartown"
ESSEX = "Essex"
EVERETT = "Everett"
EXETER = "Exeter"
FAIRHAVEN = "Fairhaven"
FALL_RIVER = "Fall River"
FALMOUTH = "Falmouth"
FAYVILLE = "Fayville"
FISKDALE = "Fiskdale"
FITCHBURG = "Fitchburg"
FORESTDALE = "Forestdale"
FOXBORO = "Foxboro"
FRAMINGHAM = "Framingham"
FRANKLIN = "Franklin"
GARDNER = "Gardner"
GEORGETOWN = "Georgetown"
GILBERTVILLE = "Gilbertville"
GLOUCESTER = "Gloucester"
GRAFTON = "Grafton"
GROTON = "Groton"
GROVELAND = "Groveland"
HALIFAX = "Halifax"
HAMILTON = "Hamilton"
HANOVER = "Hanover"
HANSCOM_AFB = "Hanscom AFB"
HANSON = "Hanson"
HARDWICK = "Hardwick"
HARVARD = "Harvard"
HARWICH = "Harwich"
HARWICH_PORT = "Harwich Port"
HATHORNE = "Hathorne"
HAVERHILL = "Haverhill"
HINGHAM = "Hingham"
HOLBROOK = "Holbrook"
HOLDEN = "Holden"
HOLLISTON = "Holliston"
HOPEDALE = "Hopedale"
HOPE_VALLEY = "Hope Valley"
HOPKINTON = "Hopkinton"
HUBBARDSTON = "Hubbardston"
HUDSON = "Hudson"
HULL = "Hull"
HYANNIS = "Hyannis"
HYANNIS_PORT = "Hyannis Port"
HYDE_PARK = "Hyde Park"
IPSWICH = "Ipswich"
JAMAICA_PLAIN = "Jamaica Plain"
JAMESTOWN = "Jamestown"
JEFFERSON = "Jefferson"
KENYON = "Kenyon"
KINGSTON = "Kingston"
LAKEVILLE = "Lakeville"
LANCASTER = "Lancaster"
LAWRENCE = "Lawrence"
LEICESTER = "Leicester"
LEOMINSTER = "Leominster"
LEXINGTON = "Lexington"
LINCOLN = "Lincoln"
LITTLETON = "Littleton"
LITTLE_COMPTON = "Little Compton"
LOWELL = "Lowell"
LUNENBURG = "Lunenburg"
LYNN = "Lynn"
LYNNFIELD = "Lynnfield"
MALDEN = "Malden"
MANCHESTER = "Manchester"
MANCHESTER_BY_THE_SEA = "Manchester-by-the-Sea"
MANSFIELD = "Mansfield"
MARBLEHEAD = "Marblehead"
MARION = "Marion"
MARLBOROUGH = "Marlborough"
MARSHFIELD = "Marshfield"
MARSTONS_MILLS = "Marstons Mills"
MASHPEE = "Mashpee"
MATTAPAN = "Mattapan"
MATTAPOISETT = "Mattapoisett"
MAYNARD = "Maynard"
MEDFIELD = "Medfield"
MEDFORD = "Medford"
MEDWAY = "Medway"
MELROSE = "Melrose"
MENDON = "Mendon"
MERRIMAC = "Merrimac"
METHUEN = "Methuen"
MIDDLEBORO = "Middleboro"
MIDDLETON = "Middleton"
MIDDLETOWN = "Middletown"
MILFORD = "Milford"
MILLBURY = "Millbury"
MILLIS = "Millis"
MILLVILLE = "Millville"
MILTON = "Milton"
MONPONSETT = "Monponsett"
NAHANT = "Nahant"
NANTUCKET = "Nantucket"
NARRAGANSETT = "Narragansett"
NATICK = "Natick"
NEEDHAM = "Needham"
NEEDHAM_HEIGHTS = "Needham Heights"
NEWBURY = "Newbury"
NEWBURYPORT = "Newburyport"
NEWPORT = "Newport"
NEWTON = "Newton"
NEWTONVILLE = "Newtonville"
NEWTON_CENTER = "Newton Center"
NEWTON_HIGHLANDS = "Newton Highlands"
NEWTON_LOWER_FALLS = "Newton Lower Falls"
NEWTON_UPPER_FALLS = "Newton Upper Falls"
NEW_BEDFORD = "New Bedford"
NEW_BRAINTREE = "New Braintree"
NORFOLK = "Norfolk"
NORTHBOROUGH = "Northborough"
NORTHBRIDGE = "Northbridge"
NORTH_ANDOVER = "North Andover"
NORTH_ATTLEBORO = "North Attleboro"
NORTH_BILLERICA = "North Billerica"
NORTH_BROOKFIELD = "North Brookfield"
NORTH_CHATHAM = "North Chatham"
NORTH_CHELMSFORD = "North Chelmsford"
NORTH_DARTMOUTH = "North Dartmouth"
NORTH_DIGHTON = "North Dighton"
NORTH_EASTON = "North Easton"
NORTH_FALMOUTH = "North Falmouth"
NORTH_GRAFTON = "North Grafton"
NORTH_KINGSTOWN = "North Kingstown"
NORTH_OXFORD = "North Oxford"
NORTH_READING = "North Reading"
NORTH_TRURO = "North Truro"
NORTH_WEYMOUTH = "North Weymouth"
NORTON = "Norton"
NORWELL = "Norwell"
NORWOOD = "Norwood"
OAKHAM = "Oakham"
OAK_BLUFFS = "Oak Bluffs"
ONSET = "Onset"
ORLEANS = "Orleans"
OSTERVILLE = "Osterville"
OXFORD = "Oxford"
PAXTON = "Paxton"
PEABODY = "Peabody"
PEMBROKE = "Pembroke"
PEPPERELL = "Pepperell"
PETERSHAM = "Petersham"
PLAINVILLE = "Plainville"
PLYMOUTH = "Plymouth"
PLYMPTON = "Plympton"
POCASSET = "Pocasset"
PORTSMOUTH = "Portsmouth"
PRINCETON = "Princeton"
PROVINCETOWN = "Provincetown"
QUINCY = "Quincy"
RANDOLPH = "Randolph"
RAYNHAM = "Raynham"
READING = "Reading"
READVILLE = "Readville"
REHOBOTH = "Rehoboth"
REVERE = "Revere"
ROCHDALE = "Rochdale"
ROCHESTER = "Rochester"
ROCKLAND = "Rockland"
ROCKPORT = "Rockport"
ROCKVILLE = "Rockville"
ROSLINDALE = "Roslindale"
ROWLEY = "Rowley"
ROXBURY = "Roxbury"
ROXBURY_CROSSING = "Roxbury Crossing"
ROYALSTON = "Royalston"
RUTLAND = "Rutland"
SAGAMORE_BEACH = "Sagamore Beach"
SALEM = "Salem"
SALISBURY = "Salisbury"
SANDWICH = "Sandwich"
SAUGUS = "Saugus"
SAUNDERSTOWN = "Saunderstown"
SCITUATE = "Scituate"
SEEKONK = "Seekonk"
SHANNOCK = "Shannock"
SHARON = "Sharon"
SHERBORN = "Sherborn"
SHIRLEY = "Shirley"
SHREWSBURY = "Shrewsbury"
SIASCONSET = "Siasconset"
SLOCUM = "Slocum"
SOMERSET = "Somerset"
SOMERVILLE = "Somerville"
SOUTHBOROUGH = "Southborough"
SOUTHBRIDGE = "Southbridge"
SOUTH_BARRE = "South Barre"
SOUTH_BOSTON = "South Boston"
SOUTH_CHATHAM = "South Chatham"
SOUTH_DARTMOUTH = "South Dartmouth"
SOUTH_DENNIS = "South Dennis"
SOUTH_EASTON = "South Easton"
SOUTH_GRAFTON = "South Grafton"
SOUTH_HAMILTON = "South Hamilton"
SOUTH_WALPOLE = "South Walpole"
SOUTH_WELLFLEET = "South Wellfleet"
SOUTH_WEYMOUTH = "South Weymouth"
SOUTH_YARMOUTH = "South Yarmouth"
SPENCER = "Spencer"
STERLING = "Sterling"
STONEHAM = "Stoneham"
STOUGHTON = "Stoughton"
STOW = "Stow"
STURBRIDGE = "Sturbridge"
SUDBURY = "Sudbury"
SUTTON = "Sutton"
SWAMPSCOTT = "Swampscott"
SWANSEA = "Swansea"
TAUNTON = "Taunton"
TEATICKET = "Teaticket"
TEMPLETON = "Templeton"
TEWKSBURY = "Tewksbury"
TIVERTON = "Tiverton"
TOPSFIELD = "Topsfield"
TOWNSEND = "Townsend"
TRURO = "Truro"
TYNGSBORO = "Tyngsboro"
UPTON = "Upton"
UXBRIDGE = "Uxbridge"
VINEYARD_HAVEN = "Vineyard Haven"
WABAN = "Waban"
WAKEFIELD = "Wakefield"
WALPOLE = "Walpole"
WALTHAM = "Waltham"
WAREHAM = "Wareham"
WARREN = "Warren"
WATERTOWN = "Watertown"
WAYLAND = "Wayland"
WEBSTER = "Webster"
WELLESLEY = "Wellesley"
WELLESLEY_HILLS = "Wellesley Hills"
WELLFLEET = "Wellfleet"
WENHAM = "Wenham"
WESTBOROUGH = "Westborough"
WESTERLY = "Westerly"
WESTFORD = "Westford"
WESTMINSTER = "Westminster"
WESTON = "Weston"
WESTPORT = "Westport"
WESTPORT_POINT = "Westport Point"
WESTWOOD = "Westwood"
WEST_BARNSTABLE = "West Barnstable"
WEST_BOYLSTON = "West Boylston"
WEST_BRIDGEWATER = "West Bridgewater"
WEST_BROOKFIELD = "West Brookfield"
WEST_DENNIS = "West Dennis"
WEST_HARWICH = "West Harwich"
WEST_KINGSTON = "West Kingston"
WEST_NEWBURY = "West Newbury"
WEST_NEWTON = "West Newton"
WEST_ROXBURY = "West Roxbury"
WEST_TISBURY = "West Tisbury"
WEST_TOWNSEND = "West Townsend"
WEST_WAREHAM = "West Wareham"
WEST_WARREN = "West Warren"
WEST_YARMOUTH = "West Yarmouth"
WEYMOUTH = "Weymouth"
WHITINSVILLE = "Whitinsville"
WHITMAN = "Whitman"
WILMINGTON = "Wilmington"
WINCHENDON = "Winchendon"
WINCHESTER = "Winchester"
WINTHROP = "Winthrop"
WOBURN = "Woburn"
WOODS_HOLE = "Woods Hole"
WOOD_RIVER_JUNCTION = "Wood River Junction"
WORCESTER = "Worcester"
WRENTHAM = "Wrentham"
WYOMING = "Wyoming"
YARMOUTH = "Yarmouth"
YARMOUTH_PORT = "Yarmouth Port"
