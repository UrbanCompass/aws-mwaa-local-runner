
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.permissions.acl.ttypes
import gen.urbancompass.boards.models.ttypes
import gen.urbancompass.comments.service.ttypes
import gen.urbancompass.deals.deals_summary.ttypes
import gen.urbancompass.notification.delivery.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.collections.common.listing_showing.ttypes
import gen.urbancompass.listing_translation.listing_translation_service.ttypes
import gen.urbancompass.notification.notifications.ttypes
import gen.urbancompass.permissions.permissions_ladon.ttypes
import gen.urbancompass.notification.preference.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes
import gen.urbancompass.profile.ttypes
import gen.urbancompass.search.saved_searches.ttypes
import gen.urbancompass.search.saved_searches_api.ttypes
import gen.urbancompass.search.search.ttypes

from thrift.transport import TTransport


class BoardListingStatusFilter(object):
    ACTIVE = 0
    COMING_SOON = 1
    PENDING = 2
    OFF_MARKET = 3
    EXPIRED = 4
    SOLD = 5
    OTHER = 6

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "COMING_SOON",
        2: "PENDING",
        3: "OFF_MARKET",
        4: "EXPIRED",
        5: "SOLD",
        6: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "COMING_SOON": 1,
        "PENDING": 2,
        "OFF_MARKET": 3,
        "EXPIRED": 4,
        "SOLD": 5,
        "OTHER": 6,
    }


class BoardType(object):
    STANDARD = 0
    PUBLIC = 1

    _VALUES_TO_NAMES = {
        0: "STANDARD",
        1: "PUBLIC",
    }

    _NAMES_TO_VALUES = {
        "STANDARD": 0,
        "PUBLIC": 1,
    }


class AcceptInvitationAPIRequest(object):
    """
    Attributes:
     - inviteToken
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'inviteToken', 'UTF8', None, ),  # 1
    )
    def __init__(self, inviteToken=None, ):
        self.inviteToken = inviteToken

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.inviteToken = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AcceptInvitationAPIRequest')
        if self.inviteToken is not None:
            oprot.writeFieldBegin('inviteToken', TType.STRING, 1)
            oprot.writeString(self.inviteToken.encode('utf-8') if sys.version_info[0] == 2 else self.inviteToken)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AcceptInvitationAPIResponse(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AcceptInvitationAPIResponse')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddedByBadge(object):
    """
    Attributes:
     - addedBy
     - addedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'addedBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 1
        (2, TType.I64, 'addedAt', None, None, ),  # 2
    )
    def __init__(self, addedBy=None, addedAt=None, ):
        self.addedBy = addedBy
        self.addedAt = addedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.addedBy = gen.urbancompass.profile.ttypes.Entity()
                    self.addedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.addedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddedByBadge')
        if self.addedBy is not None:
            oprot.writeFieldBegin('addedBy', TType.STRUCT, 1)
            self.addedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.addedAt is not None:
            oprot.writeFieldBegin('addedAt', TType.I64, 2)
            oprot.writeI64(self.addedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ArchiveBoardAPIRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ArchiveBoardAPIRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ArchiveBoardListingsAPIRequest(object):
    """
    Attributes:
     - listingIdSHAs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listingIdSHAs', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, listingIdSHAs=None, ):
        self.listingIdSHAs = listingIdSHAs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listingIdSHAs = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAs.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ArchiveBoardListingsAPIRequest')
        if self.listingIdSHAs is not None:
            oprot.writeFieldBegin('listingIdSHAs', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAs))
            for _iter6 in self.listingIdSHAs:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardAccessToken(object):
    """
    Attributes:
     - boardId
     - personId
     - iat
     - email
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'boardId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
        (3, TType.I64, 'iat', None, None, ),  # 3
        (4, TType.STRING, 'personId', 'UTF8', None, ),  # 4
    )
    def __init__(self, boardId=None, email=None, iat=None, personId=None, ):
        self.boardId = boardId
        self.email = email
        self.iat = iat
        self.personId = personId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.boardId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.iat = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardAccessToken')
        if self.boardId is not None:
            oprot.writeFieldBegin('boardId', TType.STRING, 1)
            oprot.writeString(self.boardId.encode('utf-8') if sys.version_info[0] == 2 else self.boardId)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.iat is not None:
            oprot.writeFieldBegin('iat', TType.I64, 3)
            oprot.writeI64(self.iat)
            oprot.writeFieldEnd()
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 4)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardDraftListing(object):
    """
    Attributes:
     - listingIdSHA
     - listing
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'listing', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'notes', 'UTF8', None, ),  # 3
    )
    def __init__(self, listingIdSHA=None, listing=None, notes=None, ):
        self.listingIdSHA = listingIdSHA
        self.listing = listing
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listing = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardDraftListing')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 2)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 3)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardListingIdPair(object):
    """
    Attributes:
     - boardId
     - listingIdSHA
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'boardId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 2
    )
    def __init__(self, boardId=None, listingIdSHA=None, ):
        self.boardId = boardId
        self.listingIdSHA = listingIdSHA

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.boardId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardListingIdPair')
        if self.boardId is not None:
            oprot.writeFieldBegin('boardId', TType.STRING, 1)
            oprot.writeString(self.boardId.encode('utf-8') if sys.version_info[0] == 2 else self.boardId)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 2)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardListingPriceChange(object):
    """
    Attributes:
     - originalPrice
     - updatedPrice
     - timeCalculated
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'originalPrice', None, None, ),  # 1
        (2, TType.DOUBLE, 'updatedPrice', None, None, ),  # 2
        (3, TType.I64, 'timeCalculated', None, None, ),  # 3
    )
    def __init__(self, originalPrice=None, updatedPrice=None, timeCalculated=None, ):
        self.originalPrice = originalPrice
        self.updatedPrice = updatedPrice
        self.timeCalculated = timeCalculated

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.originalPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.updatedPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.timeCalculated = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardListingPriceChange')
        if self.originalPrice is not None:
            oprot.writeFieldBegin('originalPrice', TType.DOUBLE, 1)
            oprot.writeDouble(self.originalPrice)
            oprot.writeFieldEnd()
        if self.updatedPrice is not None:
            oprot.writeFieldBegin('updatedPrice', TType.DOUBLE, 2)
            oprot.writeDouble(self.updatedPrice)
            oprot.writeFieldEnd()
        if self.timeCalculated is not None:
            oprot.writeFieldBegin('timeCalculated', TType.I64, 3)
            oprot.writeI64(self.timeCalculated)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardMetadataUpdateAPIRequest(object):
    """
    Attributes:
     - name
     - entityIdsToAdd
     - entityIdsToRemove
     - emailAddressesToAdd
     - emailAddressesToRemove
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'entityIdsToAdd', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'entityIdsToRemove', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'emailAddressesToAdd', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'emailAddressesToRemove', (TType.STRING, 'UTF8', False), None, ),  # 5
    )
    def __init__(self, name=None, entityIdsToAdd=None, entityIdsToRemove=None, emailAddressesToAdd=None, emailAddressesToRemove=None, ):
        self.name = name
        self.entityIdsToAdd = entityIdsToAdd
        self.entityIdsToRemove = entityIdsToRemove
        self.emailAddressesToAdd = emailAddressesToAdd
        self.emailAddressesToRemove = emailAddressesToRemove

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.entityIdsToAdd = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.entityIdsToAdd.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.entityIdsToRemove = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.entityIdsToRemove.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.emailAddressesToAdd = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emailAddressesToAdd.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.emailAddressesToRemove = []
                    (_etype19, _size22) = iprot.readListBegin()
                    for _i20 in range(_size22):
                        _elem21 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emailAddressesToRemove.append(_elem21)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardMetadataUpdateAPIRequest')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.entityIdsToAdd is not None:
            oprot.writeFieldBegin('entityIdsToAdd', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.entityIdsToAdd))
            for _iter23 in self.entityIdsToAdd:
                oprot.writeString(_iter23.encode('utf-8') if sys.version_info[0] == 2 else _iter23)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.entityIdsToRemove is not None:
            oprot.writeFieldBegin('entityIdsToRemove', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.entityIdsToRemove))
            for _iter24 in self.entityIdsToRemove:
                oprot.writeString(_iter24.encode('utf-8') if sys.version_info[0] == 2 else _iter24)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.emailAddressesToAdd is not None:
            oprot.writeFieldBegin('emailAddressesToAdd', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.emailAddressesToAdd))
            for _iter25 in self.emailAddressesToAdd:
                oprot.writeString(_iter25.encode('utf-8') if sys.version_info[0] == 2 else _iter25)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.emailAddressesToRemove is not None:
            oprot.writeFieldBegin('emailAddressesToRemove', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.emailAddressesToRemove))
            for _iter26 in self.emailAddressesToRemove:
                oprot.writeString(_iter26.encode('utf-8') if sys.version_info[0] == 2 else _iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateBoardAPIRequest(object):
    """
    Attributes:
     - name
     - entityIdsToAdd
     - listingIdSHAsToAdd
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'entityIdsToAdd', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'listingIdSHAsToAdd', (TType.STRING, 'UTF8', False), None, ),  # 3
    )
    def __init__(self, name=None, entityIdsToAdd=None, listingIdSHAsToAdd=None, ):
        self.name = name
        self.entityIdsToAdd = entityIdsToAdd
        self.listingIdSHAsToAdd = listingIdSHAsToAdd

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.entityIdsToAdd = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.entityIdsToAdd.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listingIdSHAsToAdd = []
                    (_etype31, _size34) = iprot.readListBegin()
                    for _i32 in range(_size34):
                        _elem33 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAsToAdd.append(_elem33)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateBoardAPIRequest')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.entityIdsToAdd is not None:
            oprot.writeFieldBegin('entityIdsToAdd', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.entityIdsToAdd))
            for _iter35 in self.entityIdsToAdd:
                oprot.writeString(_iter35.encode('utf-8') if sys.version_info[0] == 2 else _iter35)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingIdSHAsToAdd is not None:
            oprot.writeFieldBegin('listingIdSHAsToAdd', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAsToAdd))
            for _iter36 in self.listingIdSHAsToAdd:
                oprot.writeString(_iter36.encode('utf-8') if sys.version_info[0] == 2 else _iter36)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteBoardAPIRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteBoardAPIRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteBoardAPIResponse(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteBoardAPIResponse')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FavoriteInfo(object):
    """
    Attributes:
     - userId
     - favoritedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'favoritedAt', None, None, ),  # 2
    )
    def __init__(self, userId=None, favoritedAt=None, ):
        self.userId = userId
        self.favoritedAt = favoritedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.favoritedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FavoriteInfo')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.favoritedAt is not None:
            oprot.writeFieldBegin('favoritedAt', TType.I64, 2)
            oprot.writeI64(self.favoritedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindBoardsAPIRequest(object):
    """
    Attributes:
     - ownerId
     - containingListingIdSHA
     - isArchived
     - sharedToId
     - accessibleToId
     - skip
     - limit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'ownerId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'containingListingIdSHA', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isArchived', None, None, ),  # 3
        (4, TType.STRING, 'sharedToId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'accessibleToId', 'UTF8', None, ),  # 5
        (6, TType.I32, 'skip', None, None, ),  # 6
        (7, TType.I32, 'limit', None, None, ),  # 7
    )
    def __init__(self, ownerId=None, containingListingIdSHA=None, isArchived=None, sharedToId=None, accessibleToId=None, skip=None, limit=None, ):
        self.ownerId = ownerId
        self.containingListingIdSHA = containingListingIdSHA
        self.isArchived = isArchived
        self.sharedToId = sharedToId
        self.accessibleToId = accessibleToId
        self.skip = skip
        self.limit = limit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.ownerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.containingListingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.sharedToId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.accessibleToId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.skip = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindBoardsAPIRequest')
        if self.ownerId is not None:
            oprot.writeFieldBegin('ownerId', TType.STRING, 1)
            oprot.writeString(self.ownerId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerId)
            oprot.writeFieldEnd()
        if self.containingListingIdSHA is not None:
            oprot.writeFieldBegin('containingListingIdSHA', TType.STRING, 2)
            oprot.writeString(self.containingListingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.containingListingIdSHA)
            oprot.writeFieldEnd()
        if self.isArchived is not None:
            oprot.writeFieldBegin('isArchived', TType.BOOL, 3)
            oprot.writeBool(self.isArchived)
            oprot.writeFieldEnd()
        if self.sharedToId is not None:
            oprot.writeFieldBegin('sharedToId', TType.STRING, 4)
            oprot.writeString(self.sharedToId.encode('utf-8') if sys.version_info[0] == 2 else self.sharedToId)
            oprot.writeFieldEnd()
        if self.accessibleToId is not None:
            oprot.writeFieldBegin('accessibleToId', TType.STRING, 5)
            oprot.writeString(self.accessibleToId.encode('utf-8') if sys.version_info[0] == 2 else self.accessibleToId)
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.I32, 6)
            oprot.writeI32(self.skip)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 7)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindBoardsForListingsAPIRequest(object):
    """
    Attributes:
     - listingIdSHAs
     - ownerId
     - sharedToId
     - accessibleToId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listingIdSHAs', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'ownerId', 'UTF8', None, ),  # 2
        None,  # 3
        (4, TType.STRING, 'sharedToId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'accessibleToId', 'UTF8', None, ),  # 5
    )
    def __init__(self, listingIdSHAs=None, ownerId=None, sharedToId=None, accessibleToId=None, ):
        self.listingIdSHAs = listingIdSHAs
        self.ownerId = ownerId
        self.sharedToId = sharedToId
        self.accessibleToId = accessibleToId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listingIdSHAs = []
                    (_etype37, _size40) = iprot.readListBegin()
                    for _i38 in range(_size40):
                        _elem39 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAs.append(_elem39)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.ownerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.sharedToId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.accessibleToId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindBoardsForListingsAPIRequest')
        if self.listingIdSHAs is not None:
            oprot.writeFieldBegin('listingIdSHAs', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAs))
            for _iter41 in self.listingIdSHAs:
                oprot.writeString(_iter41.encode('utf-8') if sys.version_info[0] == 2 else _iter41)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ownerId is not None:
            oprot.writeFieldBegin('ownerId', TType.STRING, 2)
            oprot.writeString(self.ownerId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerId)
            oprot.writeFieldEnd()
        if self.sharedToId is not None:
            oprot.writeFieldBegin('sharedToId', TType.STRING, 4)
            oprot.writeString(self.sharedToId.encode('utf-8') if sys.version_info[0] == 2 else self.sharedToId)
            oprot.writeFieldEnd()
        if self.accessibleToId is not None:
            oprot.writeFieldBegin('accessibleToId', TType.STRING, 5)
            oprot.writeString(self.accessibleToId.encode('utf-8') if sys.version_info[0] == 2 else self.accessibleToId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetBoardAPIRequest(object):
    """
    Attributes:
     - isArchived
     - listingTypes
     - hasComments
     - hasOpenHouse
     - hasTour
     - skip
     - limit
     - sortOrder
     - expandListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isArchived', None, None, ),  # 1
        (2, TType.LIST, 'listingTypes', (TType.I32, None, False), None, ),  # 2
        (3, TType.BOOL, 'hasComments', None, None, ),  # 3
        (4, TType.BOOL, 'hasOpenHouse', None, None, ),  # 4
        (5, TType.BOOL, 'hasTour', None, None, ),  # 5
        (6, TType.I32, 'skip', None, None, ),  # 6
        (7, TType.I32, 'limit', None, None, ),  # 7
        (8, TType.I32, 'sortOrder', None, None, ),  # 8
        (9, TType.BOOL, 'expandListings', None, None, ),  # 9
    )
    def __init__(self, isArchived=None, listingTypes=None, hasComments=None, hasOpenHouse=None, hasTour=None, skip=None, limit=None, sortOrder=None, expandListings=None, ):
        self.isArchived = isArchived
        self.listingTypes = listingTypes
        self.hasComments = hasComments
        self.hasOpenHouse = hasOpenHouse
        self.hasTour = hasTour
        self.skip = skip
        self.limit = limit
        self.sortOrder = sortOrder
        self.expandListings = expandListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listingTypes = []
                    (_etype42, _size45) = iprot.readListBegin()
                    for _i43 in range(_size45):
                        _elem44 = iprot.readI32()
                        self.listingTypes.append(_elem44)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasComments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hasOpenHouse = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.hasTour = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.skip = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.sortOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.expandListings = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetBoardAPIRequest')
        if self.isArchived is not None:
            oprot.writeFieldBegin('isArchived', TType.BOOL, 1)
            oprot.writeBool(self.isArchived)
            oprot.writeFieldEnd()
        if self.listingTypes is not None:
            oprot.writeFieldBegin('listingTypes', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.listingTypes))
            for _iter46 in self.listingTypes:
                oprot.writeI32(_iter46)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hasComments is not None:
            oprot.writeFieldBegin('hasComments', TType.BOOL, 3)
            oprot.writeBool(self.hasComments)
            oprot.writeFieldEnd()
        if self.hasOpenHouse is not None:
            oprot.writeFieldBegin('hasOpenHouse', TType.BOOL, 4)
            oprot.writeBool(self.hasOpenHouse)
            oprot.writeFieldEnd()
        if self.hasTour is not None:
            oprot.writeFieldBegin('hasTour', TType.BOOL, 5)
            oprot.writeBool(self.hasTour)
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.I32, 6)
            oprot.writeI32(self.skip)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 7)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.sortOrder is not None:
            oprot.writeFieldBegin('sortOrder', TType.I32, 8)
            oprot.writeI32(self.sortOrder)
            oprot.writeFieldEnd()
        if self.expandListings is not None:
            oprot.writeFieldBegin('expandListings', TType.BOOL, 9)
            oprot.writeBool(self.expandListings)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetBoardClustersAPIRequest(object):
    """
    Attributes:
     - isArchived
     - listingTypes
     - hasComments
     - hasOpenHouse
     - hasTour
     - searchQuery
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isArchived', None, None, ),  # 1
        (2, TType.LIST, 'listingTypes', (TType.I32, None, False), None, ),  # 2
        (3, TType.BOOL, 'hasComments', None, None, ),  # 3
        (4, TType.BOOL, 'hasOpenHouse', None, None, ),  # 4
        (5, TType.BOOL, 'hasTour', None, None, ),  # 5
        (6, TType.STRUCT, 'searchQuery', (gen.urbancompass.search.search.ttypes.SearchQuery, gen.urbancompass.search.search.ttypes.SearchQuery.thrift_spec), None, ),  # 6
    )
    def __init__(self, isArchived=None, listingTypes=None, hasComments=None, hasOpenHouse=None, hasTour=None, searchQuery=None, ):
        self.isArchived = isArchived
        self.listingTypes = listingTypes
        self.hasComments = hasComments
        self.hasOpenHouse = hasOpenHouse
        self.hasTour = hasTour
        self.searchQuery = searchQuery

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listingTypes = []
                    (_etype47, _size50) = iprot.readListBegin()
                    for _i48 in range(_size50):
                        _elem49 = iprot.readI32()
                        self.listingTypes.append(_elem49)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasComments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hasOpenHouse = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.hasTour = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.searchQuery = gen.urbancompass.search.search.ttypes.SearchQuery()
                    self.searchQuery.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetBoardClustersAPIRequest')
        if self.isArchived is not None:
            oprot.writeFieldBegin('isArchived', TType.BOOL, 1)
            oprot.writeBool(self.isArchived)
            oprot.writeFieldEnd()
        if self.listingTypes is not None:
            oprot.writeFieldBegin('listingTypes', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.listingTypes))
            for _iter51 in self.listingTypes:
                oprot.writeI32(_iter51)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hasComments is not None:
            oprot.writeFieldBegin('hasComments', TType.BOOL, 3)
            oprot.writeBool(self.hasComments)
            oprot.writeFieldEnd()
        if self.hasOpenHouse is not None:
            oprot.writeFieldBegin('hasOpenHouse', TType.BOOL, 4)
            oprot.writeBool(self.hasOpenHouse)
            oprot.writeFieldEnd()
        if self.hasTour is not None:
            oprot.writeFieldBegin('hasTour', TType.BOOL, 5)
            oprot.writeBool(self.hasTour)
            oprot.writeFieldEnd()
        if self.searchQuery is not None:
            oprot.writeFieldBegin('searchQuery', TType.STRUCT, 6)
            self.searchQuery.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetSuggestedCollaboratorsAPIRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetSuggestedCollaboratorsAPIRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetSuggestedCollaboratorsAPIResponse(object):
    """
    Attributes:
     - profiles
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'profiles', (TType.STRUCT, (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, profiles=None, ):
        self.profiles = profiles

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.profiles = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = gen.urbancompass.profile.ttypes.Entity()
                        _elem54.read(iprot)
                        self.profiles.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetSuggestedCollaboratorsAPIResponse')
        if self.profiles is not None:
            oprot.writeFieldBegin('profiles', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.profiles))
            for _iter56 in self.profiles:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Image(object):
    """
    Attributes:
     - url
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'url', 'UTF8', None, ),  # 1
    )
    def __init__(self, url=None, ):
        self.url = url

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Image')
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 1)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingBoard(object):
    """
    Attributes:
     - boardId
     - isArchived
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'boardId', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'isArchived', None, None, ),  # 2
    )
    def __init__(self, boardId=None, isArchived=None, ):
        self.boardId = boardId
        self.isArchived = isArchived

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.boardId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingBoard')
        if self.boardId is not None:
            oprot.writeFieldBegin('boardId', TType.STRING, 1)
            oprot.writeString(self.boardId.encode('utf-8') if sys.version_info[0] == 2 else self.boardId)
            oprot.writeFieldEnd()
        if self.isArchived is not None:
            oprot.writeFieldBegin('isArchived', TType.BOOL, 2)
            oprot.writeBool(self.isArchived)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingComment(object):
    """
    Attributes:
     - listingIdSHA
     - content
     - reviewStage
     - savedSearchIds
     - wantToSee
     - likelyToSell
     - feedListingId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'content', 'UTF8', None, ),  # 2
        (3, TType.I32, 'reviewStage', None, None, ),  # 3
        (4, TType.SET, 'savedSearchIds', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'feedListingId', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'wantToSee', None, None, ),  # 6
        (7, TType.BOOL, 'likelyToSell', None, None, ),  # 7
    )
    def __init__(self, listingIdSHA=None, content=None, reviewStage=None, savedSearchIds=None, feedListingId=None, wantToSee=None, likelyToSell=None, ):
        self.listingIdSHA = listingIdSHA
        self.content = content
        self.reviewStage = reviewStage
        self.savedSearchIds = savedSearchIds
        self.feedListingId = feedListingId
        self.wantToSee = wantToSee
        self.likelyToSell = likelyToSell

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.content = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.reviewStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.SET:
                    self.savedSearchIds = set()
                    (_etype58, _size60) = iprot.readSetBegin()
                    for _i57 in range(_size60):
                        _elem59 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.savedSearchIds.add(_elem59)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.feedListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.wantToSee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.likelyToSell = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingComment')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 2)
            oprot.writeString(self.content.encode('utf-8') if sys.version_info[0] == 2 else self.content)
            oprot.writeFieldEnd()
        if self.reviewStage is not None:
            oprot.writeFieldBegin('reviewStage', TType.I32, 3)
            oprot.writeI32(self.reviewStage)
            oprot.writeFieldEnd()
        if self.savedSearchIds is not None:
            oprot.writeFieldBegin('savedSearchIds', TType.SET, 4)
            oprot.writeSetBegin(TType.STRING, len(self.savedSearchIds))
            for _iter61 in self.savedSearchIds:
                oprot.writeString(_iter61.encode('utf-8') if sys.version_info[0] == 2 else _iter61)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.feedListingId is not None:
            oprot.writeFieldBegin('feedListingId', TType.STRING, 5)
            oprot.writeString(self.feedListingId.encode('utf-8') if sys.version_info[0] == 2 else self.feedListingId)
            oprot.writeFieldEnd()
        if self.wantToSee is not None:
            oprot.writeFieldBegin('wantToSee', TType.BOOL, 6)
            oprot.writeBool(self.wantToSee)
            oprot.writeFieldEnd()
        if self.likelyToSell is not None:
            oprot.writeFieldBegin('likelyToSell', TType.BOOL, 7)
            oprot.writeBool(self.likelyToSell)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingTour(object):
    """
    Attributes:
     - listingIdSHA
     - tourStatus
     - tourDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.I32, 'tourStatus', None, None, ),  # 2
        (3, TType.I64, 'tourDate', None, None, ),  # 3
    )
    def __init__(self, listingIdSHA=None, tourStatus=None, tourDate=None, ):
        self.listingIdSHA = listingIdSHA
        self.tourStatus = tourStatus
        self.tourDate = tourDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.tourStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.tourDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingTour')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.tourStatus is not None:
            oprot.writeFieldBegin('tourStatus', TType.I32, 2)
            oprot.writeI32(self.tourStatus)
            oprot.writeFieldEnd()
        if self.tourDate is not None:
            oprot.writeFieldBegin('tourDate', TType.I64, 3)
            oprot.writeI64(self.tourDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NotInterestedInfo(object):
    """
    Attributes:
     - userId
     - markedNotInterestedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'markedNotInterestedAt', None, None, ),  # 2
    )
    def __init__(self, userId=None, markedNotInterestedAt=None, ):
        self.userId = userId
        self.markedNotInterestedAt = markedNotInterestedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.markedNotInterestedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NotInterestedInfo')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.markedNotInterestedAt is not None:
            oprot.writeFieldBegin('markedNotInterestedAt', TType.I64, 2)
            oprot.writeI64(self.markedNotInterestedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnarchiveBoardAPIRequest(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnarchiveBoardAPIRequest')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnarchiveBoardListingsAPIRequest(object):
    """
    Attributes:
     - listingIdSHAs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listingIdSHAs', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, listingIdSHAs=None, ):
        self.listingIdSHAs = listingIdSHAs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listingIdSHAs = []
                    (_etype62, _size65) = iprot.readListBegin()
                    for _i63 in range(_size65):
                        _elem64 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAs.append(_elem64)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnarchiveBoardListingsAPIRequest')
        if self.listingIdSHAs is not None:
            oprot.writeFieldBegin('listingIdSHAs', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAs))
            for _iter66 in self.listingIdSHAs:
                oprot.writeString(_iter66.encode('utf-8') if sys.version_info[0] == 2 else _iter66)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddListingsAPIRequest(object):
    """
    Attributes:
     - listingIdSHAsToAdd
     - listings
     - note
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listingIdSHAsToAdd', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'listings', (TType.STRUCT, (ListingComment, ListingComment.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'note', 'UTF8', None, ),  # 3
    )
    def __init__(self, listingIdSHAsToAdd=None, listings=None, note=None, ):
        self.listingIdSHAsToAdd = listingIdSHAsToAdd
        self.listings = listings
        self.note = note

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listingIdSHAsToAdd = []
                    (_etype67, _size70) = iprot.readListBegin()
                    for _i68 in range(_size70):
                        _elem69 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIdSHAsToAdd.append(_elem69)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype71, _size74) = iprot.readListBegin()
                    for _i72 in range(_size74):
                        _elem73 = ListingComment()
                        _elem73.read(iprot)
                        self.listings.append(_elem73)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddListingsAPIRequest')
        if self.listingIdSHAsToAdd is not None:
            oprot.writeFieldBegin('listingIdSHAsToAdd', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.listingIdSHAsToAdd))
            for _iter75 in self.listingIdSHAsToAdd:
                oprot.writeString(_iter75.encode('utf-8') if sys.version_info[0] == 2 else _iter75)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter76 in self.listings:
                _iter76.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 3)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Board(object):
    """
    Attributes:
     - id
     - name
     - images
     - isArchived
     - numComments
     - lastCommentedAt
     - numOpenHouses
     - numTours
     - numListings
     - owner
     - permissions
     - boardCollaboratorIds
     - boardPendingInviteeEmails
     - boardPendingInviteeIds
     - parentCollaboratorIds
     - capabilityDescriptor
     - createdAt
     - updatedAt
     - listingAddedAt
     - isJoined
     - comments
     - hasUnreadComments
     - numUnarchivedListings
     - portedCollaborators
     - isPublic
     - description
     - prettyUrl
     - shareableImageUrl
     - prettyUrls
     - isDeleted
     - collaboratorNotificationPreferences
     - numListingsPerReviewStage
     - savedSearches
     - addSavedSearchResults
     - hideLikelyToSell
     - dealSummary
     - dealSummaries
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'images', (TType.STRUCT, (Image, Image.thrift_spec), False), None, ),  # 3
        (4, TType.BOOL, 'isArchived', None, None, ),  # 4
        (5, TType.I32, 'numComments', None, None, ),  # 5
        (6, TType.I32, 'numOpenHouses', None, None, ),  # 6
        (7, TType.I32, 'numTours', None, None, ),  # 7
        (8, TType.I32, 'numListings', None, None, ),  # 8
        (9, TType.STRUCT, 'owner', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 9
        (10, TType.LIST, 'permissions', (TType.STRUCT, (gen.urbancompass.permissions.acl.ttypes.ACLEntry, gen.urbancompass.permissions.acl.ttypes.ACLEntry.thrift_spec), False), None, ),  # 10
        (11, TType.I64, 'createdAt', None, None, ),  # 11
        (12, TType.I64, 'updatedAt', None, None, ),  # 12
        (13, TType.I64, 'listingAddedAt', None, None, ),  # 13
        (14, TType.BOOL, 'isJoined', None, None, ),  # 14
        (15, TType.LIST, 'comments', (TType.STRUCT, (gen.urbancompass.comments.service.ttypes.Comment, gen.urbancompass.comments.service.ttypes.Comment.thrift_spec), False), None, ),  # 15
        (16, TType.BOOL, 'hasUnreadComments', None, None, ),  # 16
        (17, TType.I32, 'numUnarchivedListings', None, None, ),  # 17
        (18, TType.LIST, 'portedCollaborators', (TType.STRUCT, (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), False), None, ),  # 18
        (19, TType.BOOL, 'isPublic', None, None, ),  # 19
        (20, TType.STRING, 'description', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'prettyUrl', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'shareableImageUrl', 'UTF8', None, ),  # 22
        (23, TType.LIST, 'prettyUrls', (TType.STRING, 'UTF8', False), None, ),  # 23
        (24, TType.BOOL, 'isDeleted', None, None, ),  # 24
        (25, TType.MAP, 'collaboratorNotificationPreferences', (TType.I32, None, TType.MAP, (TType.I32, None, TType.I32, None, False), False), None, ),  # 25
        (26, TType.MAP, 'numListingsPerReviewStage', (TType.I32, None, TType.I32, None, False), None, ),  # 26
        (27, TType.LIST, 'savedSearches', (TType.STRUCT, (gen.urbancompass.search.saved_searches_api.ttypes.SavedSearchMetadata, gen.urbancompass.search.saved_searches_api.ttypes.SavedSearchMetadata.thrift_spec), False), None, ),  # 27
        (28, TType.I64, 'lastCommentedAt', None, None, ),  # 28
        (29, TType.STRUCT, 'capabilityDescriptor', (gen.urbancompass.permissions.permissions_ladon.ttypes.CapabilityDescriptor, gen.urbancompass.permissions.permissions_ladon.ttypes.CapabilityDescriptor.thrift_spec), None, ),  # 29
        (30, TType.BOOL, 'addSavedSearchResults', None, None, ),  # 30
        (31, TType.SET, 'boardCollaboratorIds', (TType.STRING, 'UTF8', False), None, ),  # 31
        (32, TType.SET, 'boardPendingInviteeEmails', (TType.STRING, 'UTF8', False), None, ),  # 32
        (33, TType.SET, 'parentCollaboratorIds', (TType.STRING, 'UTF8', False), None, ),  # 33
        (34, TType.SET, 'boardPendingInviteeIds', (TType.STRING, 'UTF8', False), None, ),  # 34
        (35, TType.BOOL, 'hideLikelyToSell', None, None, ),  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.STRUCT, 'dealSummary', (gen.urbancompass.deals.deals_summary.ttypes.DealSummary, gen.urbancompass.deals.deals_summary.ttypes.DealSummary.thrift_spec), None, ),  # 100
        (101, TType.LIST, 'dealSummaries', (TType.STRUCT, (gen.urbancompass.deals.deals_summary.ttypes.DealSummary, gen.urbancompass.deals.deals_summary.ttypes.DealSummary.thrift_spec), False), None, ),  # 101
    )
    def __init__(self, id=None, name=None, images=None, isArchived=None, numComments=None, numOpenHouses=None, numTours=None, numListings=None, owner=None, permissions=None, createdAt=None, updatedAt=None, listingAddedAt=None, isJoined=None, comments=None, hasUnreadComments=None, numUnarchivedListings=None, portedCollaborators=None, isPublic=None, description=None, prettyUrl=None, shareableImageUrl=None, prettyUrls=None, isDeleted=None, collaboratorNotificationPreferences=None, numListingsPerReviewStage=None, savedSearches=None, lastCommentedAt=None, capabilityDescriptor=None, addSavedSearchResults=None, boardCollaboratorIds=None, boardPendingInviteeEmails=None, parentCollaboratorIds=None, boardPendingInviteeIds=None, hideLikelyToSell=None, dealSummary=None, dealSummaries=None, ):
        self.id = id
        self.name = name
        self.images = images
        self.isArchived = isArchived
        self.numComments = numComments
        self.numOpenHouses = numOpenHouses
        self.numTours = numTours
        self.numListings = numListings
        self.owner = owner
        self.permissions = permissions
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.listingAddedAt = listingAddedAt
        self.isJoined = isJoined
        self.comments = comments
        self.hasUnreadComments = hasUnreadComments
        self.numUnarchivedListings = numUnarchivedListings
        self.portedCollaborators = portedCollaborators
        self.isPublic = isPublic
        self.description = description
        self.prettyUrl = prettyUrl
        self.shareableImageUrl = shareableImageUrl
        self.prettyUrls = prettyUrls
        self.isDeleted = isDeleted
        self.collaboratorNotificationPreferences = collaboratorNotificationPreferences
        self.numListingsPerReviewStage = numListingsPerReviewStage
        self.savedSearches = savedSearches
        self.lastCommentedAt = lastCommentedAt
        self.capabilityDescriptor = capabilityDescriptor
        self.addSavedSearchResults = addSavedSearchResults
        self.boardCollaboratorIds = boardCollaboratorIds
        self.boardPendingInviteeEmails = boardPendingInviteeEmails
        self.parentCollaboratorIds = parentCollaboratorIds
        self.boardPendingInviteeIds = boardPendingInviteeIds
        self.hideLikelyToSell = hideLikelyToSell
        self.dealSummary = dealSummary
        self.dealSummaries = dealSummaries

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.images = []
                    (_etype77, _size80) = iprot.readListBegin()
                    for _i78 in range(_size80):
                        _elem79 = Image()
                        _elem79.read(iprot)
                        self.images.append(_elem79)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.numComments = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.numOpenHouses = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.numTours = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.numListings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.owner = gen.urbancompass.profile.ttypes.Entity()
                    self.owner.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.permissions = []
                    (_etype81, _size84) = iprot.readListBegin()
                    for _i82 in range(_size84):
                        _elem83 = gen.urbancompass.permissions.acl.ttypes.ACLEntry()
                        _elem83.read(iprot)
                        self.permissions.append(_elem83)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I64:
                    self.listingAddedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.isJoined = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.comments = []
                    (_etype85, _size88) = iprot.readListBegin()
                    for _i86 in range(_size88):
                        _elem87 = gen.urbancompass.comments.service.ttypes.Comment()
                        _elem87.read(iprot)
                        self.comments.append(_elem87)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.hasUnreadComments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.numUnarchivedListings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.LIST:
                    self.portedCollaborators = []
                    (_etype89, _size92) = iprot.readListBegin()
                    for _i90 in range(_size92):
                        _elem91 = gen.urbancompass.profile.ttypes.Entity()
                        _elem91.read(iprot)
                        self.portedCollaborators.append(_elem91)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.isPublic = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.prettyUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.shareableImageUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.LIST:
                    self.prettyUrls = []
                    (_etype93, _size96) = iprot.readListBegin()
                    for _i94 in range(_size96):
                        _elem95 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.prettyUrls.append(_elem95)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.MAP:
                    self.collaboratorNotificationPreferences = {}
                    (_ktype98, _vtype99, _size102) = iprot.readMapBegin()
                    for _i97 in range(_size102):
                        _key100 = iprot.readI32()
                        _val101 = {}
                        (_ktype104, _vtype105, _size108) = iprot.readMapBegin()
                        for _i103 in range(_size108):
                            _key106 = iprot.readI32()
                            _val107 = iprot.readI32()
                            _val101[_key106] = _val107
                        iprot.readMapEnd()
                        self.collaboratorNotificationPreferences[_key100] = _val101
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.MAP:
                    self.numListingsPerReviewStage = {}
                    (_ktype110, _vtype111, _size114) = iprot.readMapBegin()
                    for _i109 in range(_size114):
                        _key112 = iprot.readI32()
                        _val113 = iprot.readI32()
                        self.numListingsPerReviewStage[_key112] = _val113
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.LIST:
                    self.savedSearches = []
                    (_etype115, _size118) = iprot.readListBegin()
                    for _i116 in range(_size118):
                        _elem117 = gen.urbancompass.search.saved_searches_api.ttypes.SavedSearchMetadata()
                        _elem117.read(iprot)
                        self.savedSearches.append(_elem117)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.I64:
                    self.lastCommentedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRUCT:
                    self.capabilityDescriptor = gen.urbancompass.permissions.permissions_ladon.ttypes.CapabilityDescriptor()
                    self.capabilityDescriptor.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.BOOL:
                    self.addSavedSearchResults = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.SET:
                    self.boardCollaboratorIds = set()
                    (_etype120, _size122) = iprot.readSetBegin()
                    for _i119 in range(_size122):
                        _elem121 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.boardCollaboratorIds.add(_elem121)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.SET:
                    self.boardPendingInviteeEmails = set()
                    (_etype124, _size126) = iprot.readSetBegin()
                    for _i123 in range(_size126):
                        _elem125 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.boardPendingInviteeEmails.add(_elem125)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.SET:
                    self.parentCollaboratorIds = set()
                    (_etype128, _size130) = iprot.readSetBegin()
                    for _i127 in range(_size130):
                        _elem129 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.parentCollaboratorIds.add(_elem129)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.SET:
                    self.boardPendingInviteeIds = set()
                    (_etype132, _size134) = iprot.readSetBegin()
                    for _i131 in range(_size134):
                        _elem133 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.boardPendingInviteeIds.add(_elem133)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.BOOL:
                    self.hideLikelyToSell = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.STRUCT:
                    self.dealSummary = gen.urbancompass.deals.deals_summary.ttypes.DealSummary()
                    self.dealSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 101:
                if ftype == TType.LIST:
                    self.dealSummaries = []
                    (_etype135, _size138) = iprot.readListBegin()
                    for _i136 in range(_size138):
                        _elem137 = gen.urbancompass.deals.deals_summary.ttypes.DealSummary()
                        _elem137.read(iprot)
                        self.dealSummaries.append(_elem137)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Board')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.images is not None:
            oprot.writeFieldBegin('images', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.images))
            for _iter139 in self.images:
                _iter139.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isArchived is not None:
            oprot.writeFieldBegin('isArchived', TType.BOOL, 4)
            oprot.writeBool(self.isArchived)
            oprot.writeFieldEnd()
        if self.numComments is not None:
            oprot.writeFieldBegin('numComments', TType.I32, 5)
            oprot.writeI32(self.numComments)
            oprot.writeFieldEnd()
        if self.numOpenHouses is not None:
            oprot.writeFieldBegin('numOpenHouses', TType.I32, 6)
            oprot.writeI32(self.numOpenHouses)
            oprot.writeFieldEnd()
        if self.numTours is not None:
            oprot.writeFieldBegin('numTours', TType.I32, 7)
            oprot.writeI32(self.numTours)
            oprot.writeFieldEnd()
        if self.numListings is not None:
            oprot.writeFieldBegin('numListings', TType.I32, 8)
            oprot.writeI32(self.numListings)
            oprot.writeFieldEnd()
        if self.owner is not None:
            oprot.writeFieldBegin('owner', TType.STRUCT, 9)
            self.owner.write(oprot)
            oprot.writeFieldEnd()
        if self.permissions is not None:
            oprot.writeFieldBegin('permissions', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.permissions))
            for _iter140 in self.permissions:
                _iter140.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 11)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 12)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.listingAddedAt is not None:
            oprot.writeFieldBegin('listingAddedAt', TType.I64, 13)
            oprot.writeI64(self.listingAddedAt)
            oprot.writeFieldEnd()
        if self.isJoined is not None:
            oprot.writeFieldBegin('isJoined', TType.BOOL, 14)
            oprot.writeBool(self.isJoined)
            oprot.writeFieldEnd()
        if self.comments is not None:
            oprot.writeFieldBegin('comments', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.comments))
            for _iter141 in self.comments:
                _iter141.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hasUnreadComments is not None:
            oprot.writeFieldBegin('hasUnreadComments', TType.BOOL, 16)
            oprot.writeBool(self.hasUnreadComments)
            oprot.writeFieldEnd()
        if self.numUnarchivedListings is not None:
            oprot.writeFieldBegin('numUnarchivedListings', TType.I32, 17)
            oprot.writeI32(self.numUnarchivedListings)
            oprot.writeFieldEnd()
        if self.portedCollaborators is not None:
            oprot.writeFieldBegin('portedCollaborators', TType.LIST, 18)
            oprot.writeListBegin(TType.STRUCT, len(self.portedCollaborators))
            for _iter142 in self.portedCollaborators:
                _iter142.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isPublic is not None:
            oprot.writeFieldBegin('isPublic', TType.BOOL, 19)
            oprot.writeBool(self.isPublic)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 20)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.prettyUrl is not None:
            oprot.writeFieldBegin('prettyUrl', TType.STRING, 21)
            oprot.writeString(self.prettyUrl.encode('utf-8') if sys.version_info[0] == 2 else self.prettyUrl)
            oprot.writeFieldEnd()
        if self.shareableImageUrl is not None:
            oprot.writeFieldBegin('shareableImageUrl', TType.STRING, 22)
            oprot.writeString(self.shareableImageUrl.encode('utf-8') if sys.version_info[0] == 2 else self.shareableImageUrl)
            oprot.writeFieldEnd()
        if self.prettyUrls is not None:
            oprot.writeFieldBegin('prettyUrls', TType.LIST, 23)
            oprot.writeListBegin(TType.STRING, len(self.prettyUrls))
            for _iter143 in self.prettyUrls:
                oprot.writeString(_iter143.encode('utf-8') if sys.version_info[0] == 2 else _iter143)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 24)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.collaboratorNotificationPreferences is not None:
            oprot.writeFieldBegin('collaboratorNotificationPreferences', TType.MAP, 25)
            oprot.writeMapBegin(TType.I32, TType.MAP, len(self.collaboratorNotificationPreferences))
            for _kiter144, _viter145 in self.collaboratorNotificationPreferences.items():
                oprot.writeI32(_kiter144)
                oprot.writeMapBegin(TType.I32, TType.I32, len(_viter145))
                for _kiter146, _viter147 in _viter145.items():
                    oprot.writeI32(_kiter146)
                    oprot.writeI32(_viter147)
                oprot.writeMapEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.numListingsPerReviewStage is not None:
            oprot.writeFieldBegin('numListingsPerReviewStage', TType.MAP, 26)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.numListingsPerReviewStage))
            for _kiter148, _viter149 in self.numListingsPerReviewStage.items():
                oprot.writeI32(_kiter148)
                oprot.writeI32(_viter149)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.savedSearches is not None:
            oprot.writeFieldBegin('savedSearches', TType.LIST, 27)
            oprot.writeListBegin(TType.STRUCT, len(self.savedSearches))
            for _iter150 in self.savedSearches:
                _iter150.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastCommentedAt is not None:
            oprot.writeFieldBegin('lastCommentedAt', TType.I64, 28)
            oprot.writeI64(self.lastCommentedAt)
            oprot.writeFieldEnd()
        if self.capabilityDescriptor is not None:
            oprot.writeFieldBegin('capabilityDescriptor', TType.STRUCT, 29)
            self.capabilityDescriptor.write(oprot)
            oprot.writeFieldEnd()
        if self.addSavedSearchResults is not None:
            oprot.writeFieldBegin('addSavedSearchResults', TType.BOOL, 30)
            oprot.writeBool(self.addSavedSearchResults)
            oprot.writeFieldEnd()
        if self.boardCollaboratorIds is not None:
            oprot.writeFieldBegin('boardCollaboratorIds', TType.SET, 31)
            oprot.writeSetBegin(TType.STRING, len(self.boardCollaboratorIds))
            for _iter151 in self.boardCollaboratorIds:
                oprot.writeString(_iter151.encode('utf-8') if sys.version_info[0] == 2 else _iter151)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.boardPendingInviteeEmails is not None:
            oprot.writeFieldBegin('boardPendingInviteeEmails', TType.SET, 32)
            oprot.writeSetBegin(TType.STRING, len(self.boardPendingInviteeEmails))
            for _iter152 in self.boardPendingInviteeEmails:
                oprot.writeString(_iter152.encode('utf-8') if sys.version_info[0] == 2 else _iter152)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.parentCollaboratorIds is not None:
            oprot.writeFieldBegin('parentCollaboratorIds', TType.SET, 33)
            oprot.writeSetBegin(TType.STRING, len(self.parentCollaboratorIds))
            for _iter153 in self.parentCollaboratorIds:
                oprot.writeString(_iter153.encode('utf-8') if sys.version_info[0] == 2 else _iter153)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.boardPendingInviteeIds is not None:
            oprot.writeFieldBegin('boardPendingInviteeIds', TType.SET, 34)
            oprot.writeSetBegin(TType.STRING, len(self.boardPendingInviteeIds))
            for _iter154 in self.boardPendingInviteeIds:
                oprot.writeString(_iter154.encode('utf-8') if sys.version_info[0] == 2 else _iter154)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.hideLikelyToSell is not None:
            oprot.writeFieldBegin('hideLikelyToSell', TType.BOOL, 35)
            oprot.writeBool(self.hideLikelyToSell)
            oprot.writeFieldEnd()
        if self.dealSummary is not None:
            oprot.writeFieldBegin('dealSummary', TType.STRUCT, 100)
            self.dealSummary.write(oprot)
            oprot.writeFieldEnd()
        if self.dealSummaries is not None:
            oprot.writeFieldBegin('dealSummaries', TType.LIST, 101)
            oprot.writeListBegin(TType.STRUCT, len(self.dealSummaries))
            for _iter155 in self.dealSummaries:
                _iter155.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardDraftMetadata(object):
    """
    Attributes:
     - boardId
     - boardName
     - boardOwner
     - boardExists
     - images
     - numListings
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'boardId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'boardName', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'boardOwner', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'boardExists', None, None, ),  # 4
        (5, TType.LIST, 'images', (TType.STRUCT, (Image, Image.thrift_spec), False), None, ),  # 5
        (6, TType.I32, 'numListings', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
    )
    def __init__(self, boardId=None, boardName=None, boardOwner=None, boardExists=None, images=None, numListings=None, updatedAt=None, ):
        self.boardId = boardId
        self.boardName = boardName
        self.boardOwner = boardOwner
        self.boardExists = boardExists
        self.images = images
        self.numListings = numListings
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.boardId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.boardName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.boardOwner = gen.urbancompass.profile.ttypes.Entity()
                    self.boardOwner.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.boardExists = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.images = []
                    (_etype156, _size159) = iprot.readListBegin()
                    for _i157 in range(_size159):
                        _elem158 = Image()
                        _elem158.read(iprot)
                        self.images.append(_elem158)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.numListings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardDraftMetadata')
        if self.boardId is not None:
            oprot.writeFieldBegin('boardId', TType.STRING, 1)
            oprot.writeString(self.boardId.encode('utf-8') if sys.version_info[0] == 2 else self.boardId)
            oprot.writeFieldEnd()
        if self.boardName is not None:
            oprot.writeFieldBegin('boardName', TType.STRING, 2)
            oprot.writeString(self.boardName.encode('utf-8') if sys.version_info[0] == 2 else self.boardName)
            oprot.writeFieldEnd()
        if self.boardOwner is not None:
            oprot.writeFieldBegin('boardOwner', TType.STRUCT, 3)
            self.boardOwner.write(oprot)
            oprot.writeFieldEnd()
        if self.boardExists is not None:
            oprot.writeFieldBegin('boardExists', TType.BOOL, 4)
            oprot.writeBool(self.boardExists)
            oprot.writeFieldEnd()
        if self.images is not None:
            oprot.writeFieldBegin('images', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.images))
            for _iter160 in self.images:
                _iter160.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.numListings is not None:
            oprot.writeFieldBegin('numListings', TType.I32, 6)
            oprot.writeI32(self.numListings)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardListingBadges(object):
    """
    Attributes:
     - addedByBadge
     - latestPriceChange
     - newListingInReviewStage
     - viewCount
     - clientListingViewCounts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'addedByBadge', (AddedByBadge, AddedByBadge.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'latestPriceChange', (BoardListingPriceChange, BoardListingPriceChange.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'newListingInReviewStage', None, None, ),  # 3
        (4, TType.I32, 'viewCount', None, None, ),  # 4
        (5, TType.MAP, 'clientListingViewCounts', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 5
    )
    def __init__(self, addedByBadge=None, latestPriceChange=None, newListingInReviewStage=None, viewCount=None, clientListingViewCounts=None, ):
        self.addedByBadge = addedByBadge
        self.latestPriceChange = latestPriceChange
        self.newListingInReviewStage = newListingInReviewStage
        self.viewCount = viewCount
        self.clientListingViewCounts = clientListingViewCounts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.addedByBadge = AddedByBadge()
                    self.addedByBadge.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.latestPriceChange = BoardListingPriceChange()
                    self.latestPriceChange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.newListingInReviewStage = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.viewCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.clientListingViewCounts = {}
                    (_ktype162, _vtype163, _size166) = iprot.readMapBegin()
                    for _i161 in range(_size166):
                        _key164 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val165 = iprot.readI32()
                        self.clientListingViewCounts[_key164] = _val165
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardListingBadges')
        if self.addedByBadge is not None:
            oprot.writeFieldBegin('addedByBadge', TType.STRUCT, 1)
            self.addedByBadge.write(oprot)
            oprot.writeFieldEnd()
        if self.latestPriceChange is not None:
            oprot.writeFieldBegin('latestPriceChange', TType.STRUCT, 2)
            self.latestPriceChange.write(oprot)
            oprot.writeFieldEnd()
        if self.newListingInReviewStage is not None:
            oprot.writeFieldBegin('newListingInReviewStage', TType.BOOL, 3)
            oprot.writeBool(self.newListingInReviewStage)
            oprot.writeFieldEnd()
        if self.viewCount is not None:
            oprot.writeFieldBegin('viewCount', TType.I32, 4)
            oprot.writeI32(self.viewCount)
            oprot.writeFieldEnd()
        if self.clientListingViewCounts is not None:
            oprot.writeFieldBegin('clientListingViewCounts', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.clientListingViewCounts))
            for _kiter167, _viter168 in self.clientListingViewCounts.items():
                oprot.writeString(_kiter167.encode('utf-8') if sys.version_info[0] == 2 else _kiter167)
                oprot.writeI32(_viter168)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingBoards(object):
    """
    Attributes:
     - listingIdSHA
     - containingBoards
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'containingBoards', (TType.STRUCT, (ListingBoard, ListingBoard.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, listingIdSHA=None, containingBoards=None, ):
        self.listingIdSHA = listingIdSHA
        self.containingBoards = containingBoards

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.containingBoards = []
                    (_etype169, _size172) = iprot.readListBegin()
                    for _i170 in range(_size172):
                        _elem171 = ListingBoard()
                        _elem171.read(iprot)
                        self.containingBoards.append(_elem171)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingBoards')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.containingBoards is not None:
            oprot.writeFieldBegin('containingBoards', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.containingBoards))
            for _iter173 in self.containingBoards:
                _iter173.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ArchiveBoardAPIResponse(object):
    """
    Attributes:
     - board
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'board', (Board, Board.thrift_spec), None, ),  # 1
    )
    def __init__(self, board=None, ):
        self.board = board

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.board = Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ArchiveBoardAPIResponse')
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 1)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardDraft(object):
    """
    Attributes:
     - boardExists
     - notes
     - listings
     - metadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'boardExists', None, None, ),  # 1
        (2, TType.STRING, 'notes', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'listings', (TType.STRUCT, (BoardDraftListing, BoardDraftListing.thrift_spec), False), None, ),  # 3
        (4, TType.STRUCT, 'metadata', (BoardDraftMetadata, BoardDraftMetadata.thrift_spec), None, ),  # 4
    )
    def __init__(self, boardExists=None, notes=None, listings=None, metadata=None, ):
        self.boardExists = boardExists
        self.notes = notes
        self.listings = listings
        self.metadata = metadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.boardExists = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype174, _size177) = iprot.readListBegin()
                    for _i175 in range(_size177):
                        _elem176 = BoardDraftListing()
                        _elem176.read(iprot)
                        self.listings.append(_elem176)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.metadata = BoardDraftMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardDraft')
        if self.boardExists is not None:
            oprot.writeFieldBegin('boardExists', TType.BOOL, 1)
            oprot.writeBool(self.boardExists)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 2)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter178 in self.listings:
                _iter178.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 4)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardListing(object):
    """
    Attributes:
     - listingIdSHA
     - listing
     - isArchived
     - comments
     - hasUnreadComments
     - numComments
     - numCommentsUnread
     - tourIds
     - addedBy
     - updatedBy
     - createdAt
     - updatedAt
     - boardId
     - reviewStage
     - savedSearchIds
     - feedListingId
     - wantToSee
     - tourStatus
     - tourDate
     - badges
     - favoriteBy
     - notInterestedBy
     - showing
     - canRequestTour
     - likelyToSell
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'listing', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isArchived', None, None, ),  # 3
        (4, TType.LIST, 'comments', (TType.STRUCT, (gen.urbancompass.comments.service.ttypes.Comment, gen.urbancompass.comments.service.ttypes.Comment.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'tourIds', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRUCT, 'addedBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'updatedBy', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.BOOL, 'hasUnreadComments', None, None, ),  # 10
        (11, TType.STRING, 'boardId', 'UTF8', None, ),  # 11
        (12, TType.I32, 'reviewStage', None, None, ),  # 12
        (13, TType.SET, 'savedSearchIds', (TType.STRING, 'UTF8', False), None, ),  # 13
        (14, TType.STRING, 'feedListingId', 'UTF8', None, ),  # 14
        (15, TType.I32, 'numComments', None, None, ),  # 15
        (16, TType.I32, 'numCommentsUnread', None, None, ),  # 16
        (17, TType.BOOL, 'wantToSee', None, None, ),  # 17
        (18, TType.STRUCT, 'badges', (BoardListingBadges, BoardListingBadges.thrift_spec), None, ),  # 18
        (19, TType.I32, 'tourStatus', None, None, ),  # 19
        (20, TType.I64, 'tourDate', None, None, ),  # 20
        (21, TType.LIST, 'favoriteBy', (TType.STRUCT, (FavoriteInfo, FavoriteInfo.thrift_spec), False), None, ),  # 21
        (22, TType.LIST, 'notInterestedBy', (TType.STRUCT, (NotInterestedInfo, NotInterestedInfo.thrift_spec), False), None, ),  # 22
        (23, TType.STRUCT, 'showing', (gen.urbancompass.collections.common.listing_showing.ttypes.ListingShowing, gen.urbancompass.collections.common.listing_showing.ttypes.ListingShowing.thrift_spec), None, ),  # 23
        (24, TType.BOOL, 'canRequestTour', None, None, ),  # 24
        (25, TType.BOOL, 'likelyToSell', None, None, ),  # 25
    )
    def __init__(self, listingIdSHA=None, listing=None, isArchived=None, comments=None, tourIds=None, addedBy=None, updatedBy=None, createdAt=None, updatedAt=None, hasUnreadComments=None, boardId=None, reviewStage=None, savedSearchIds=None, feedListingId=None, numComments=None, numCommentsUnread=None, wantToSee=None, badges=None, tourStatus=None, tourDate=None, favoriteBy=None, notInterestedBy=None, showing=None, canRequestTour=None, likelyToSell=None, ):
        self.listingIdSHA = listingIdSHA
        self.listing = listing
        self.isArchived = isArchived
        self.comments = comments
        self.tourIds = tourIds
        self.addedBy = addedBy
        self.updatedBy = updatedBy
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.hasUnreadComments = hasUnreadComments
        self.boardId = boardId
        self.reviewStage = reviewStage
        self.savedSearchIds = savedSearchIds
        self.feedListingId = feedListingId
        self.numComments = numComments
        self.numCommentsUnread = numCommentsUnread
        self.wantToSee = wantToSee
        self.badges = badges
        self.tourStatus = tourStatus
        self.tourDate = tourDate
        self.favoriteBy = favoriteBy
        self.notInterestedBy = notInterestedBy
        self.showing = showing
        self.canRequestTour = canRequestTour
        self.likelyToSell = likelyToSell

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listing = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isArchived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.comments = []
                    (_etype179, _size182) = iprot.readListBegin()
                    for _i180 in range(_size182):
                        _elem181 = gen.urbancompass.comments.service.ttypes.Comment()
                        _elem181.read(iprot)
                        self.comments.append(_elem181)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.tourIds = []
                    (_etype183, _size186) = iprot.readListBegin()
                    for _i184 in range(_size186):
                        _elem185 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.tourIds.append(_elem185)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.addedBy = gen.urbancompass.profile.ttypes.Entity()
                    self.addedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.updatedBy = gen.urbancompass.profile.ttypes.Entity()
                    self.updatedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.hasUnreadComments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.boardId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.reviewStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.SET:
                    self.savedSearchIds = set()
                    (_etype188, _size190) = iprot.readSetBegin()
                    for _i187 in range(_size190):
                        _elem189 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.savedSearchIds.add(_elem189)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.feedListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.numComments = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.numCommentsUnread = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.wantToSee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRUCT:
                    self.badges = BoardListingBadges()
                    self.badges.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.tourStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I64:
                    self.tourDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.favoriteBy = []
                    (_etype191, _size194) = iprot.readListBegin()
                    for _i192 in range(_size194):
                        _elem193 = FavoriteInfo()
                        _elem193.read(iprot)
                        self.favoriteBy.append(_elem193)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.LIST:
                    self.notInterestedBy = []
                    (_etype195, _size198) = iprot.readListBegin()
                    for _i196 in range(_size198):
                        _elem197 = NotInterestedInfo()
                        _elem197.read(iprot)
                        self.notInterestedBy.append(_elem197)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRUCT:
                    self.showing = gen.urbancompass.collections.common.listing_showing.ttypes.ListingShowing()
                    self.showing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.canRequestTour = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.BOOL:
                    self.likelyToSell = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardListing')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 2)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.isArchived is not None:
            oprot.writeFieldBegin('isArchived', TType.BOOL, 3)
            oprot.writeBool(self.isArchived)
            oprot.writeFieldEnd()
        if self.comments is not None:
            oprot.writeFieldBegin('comments', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.comments))
            for _iter199 in self.comments:
                _iter199.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.tourIds is not None:
            oprot.writeFieldBegin('tourIds', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.tourIds))
            for _iter200 in self.tourIds:
                oprot.writeString(_iter200.encode('utf-8') if sys.version_info[0] == 2 else _iter200)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.addedBy is not None:
            oprot.writeFieldBegin('addedBy', TType.STRUCT, 6)
            self.addedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRUCT, 7)
            self.updatedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.hasUnreadComments is not None:
            oprot.writeFieldBegin('hasUnreadComments', TType.BOOL, 10)
            oprot.writeBool(self.hasUnreadComments)
            oprot.writeFieldEnd()
        if self.boardId is not None:
            oprot.writeFieldBegin('boardId', TType.STRING, 11)
            oprot.writeString(self.boardId.encode('utf-8') if sys.version_info[0] == 2 else self.boardId)
            oprot.writeFieldEnd()
        if self.reviewStage is not None:
            oprot.writeFieldBegin('reviewStage', TType.I32, 12)
            oprot.writeI32(self.reviewStage)
            oprot.writeFieldEnd()
        if self.savedSearchIds is not None:
            oprot.writeFieldBegin('savedSearchIds', TType.SET, 13)
            oprot.writeSetBegin(TType.STRING, len(self.savedSearchIds))
            for _iter201 in self.savedSearchIds:
                oprot.writeString(_iter201.encode('utf-8') if sys.version_info[0] == 2 else _iter201)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.feedListingId is not None:
            oprot.writeFieldBegin('feedListingId', TType.STRING, 14)
            oprot.writeString(self.feedListingId.encode('utf-8') if sys.version_info[0] == 2 else self.feedListingId)
            oprot.writeFieldEnd()
        if self.numComments is not None:
            oprot.writeFieldBegin('numComments', TType.I32, 15)
            oprot.writeI32(self.numComments)
            oprot.writeFieldEnd()
        if self.numCommentsUnread is not None:
            oprot.writeFieldBegin('numCommentsUnread', TType.I32, 16)
            oprot.writeI32(self.numCommentsUnread)
            oprot.writeFieldEnd()
        if self.wantToSee is not None:
            oprot.writeFieldBegin('wantToSee', TType.BOOL, 17)
            oprot.writeBool(self.wantToSee)
            oprot.writeFieldEnd()
        if self.badges is not None:
            oprot.writeFieldBegin('badges', TType.STRUCT, 18)
            self.badges.write(oprot)
            oprot.writeFieldEnd()
        if self.tourStatus is not None:
            oprot.writeFieldBegin('tourStatus', TType.I32, 19)
            oprot.writeI32(self.tourStatus)
            oprot.writeFieldEnd()
        if self.tourDate is not None:
            oprot.writeFieldBegin('tourDate', TType.I64, 20)
            oprot.writeI64(self.tourDate)
            oprot.writeFieldEnd()
        if self.favoriteBy is not None:
            oprot.writeFieldBegin('favoriteBy', TType.LIST, 21)
            oprot.writeListBegin(TType.STRUCT, len(self.favoriteBy))
            for _iter202 in self.favoriteBy:
                _iter202.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notInterestedBy is not None:
            oprot.writeFieldBegin('notInterestedBy', TType.LIST, 22)
            oprot.writeListBegin(TType.STRUCT, len(self.notInterestedBy))
            for _iter203 in self.notInterestedBy:
                _iter203.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.showing is not None:
            oprot.writeFieldBegin('showing', TType.STRUCT, 23)
            self.showing.write(oprot)
            oprot.writeFieldEnd()
        if self.canRequestTour is not None:
            oprot.writeFieldBegin('canRequestTour', TType.BOOL, 24)
            oprot.writeBool(self.canRequestTour)
            oprot.writeFieldEnd()
        if self.likelyToSell is not None:
            oprot.writeFieldBegin('likelyToSell', TType.BOOL, 25)
            oprot.writeBool(self.likelyToSell)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BoardMetadataUpdateAPIResponse(object):
    """
    Attributes:
     - board
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'board', (Board, Board.thrift_spec), None, ),  # 1
    )
    def __init__(self, board=None, ):
        self.board = board

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.board = Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BoardMetadataUpdateAPIResponse')
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 1)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Collaborator(object):
    """
    Attributes:
     - profile
     - boards
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'profile', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'boards', (TType.STRUCT, (Board, Board.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, profile=None, boards=None, ):
        self.profile = profile
        self.boards = boards

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.profile = gen.urbancompass.profile.ttypes.Entity()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.boards = []
                    (_etype204, _size207) = iprot.readListBegin()
                    for _i205 in range(_size207):
                        _elem206 = Board()
                        _elem206.read(iprot)
                        self.boards.append(_elem206)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Collaborator')
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 1)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        if self.boards is not None:
            oprot.writeFieldBegin('boards', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.boards))
            for _iter208 in self.boards:
                _iter208.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindBoardsAPIResponse(object):
    """
    Attributes:
     - boards
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'boards', (TType.STRUCT, (Board, Board.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'totalResults', None, None, ),  # 2
    )
    def __init__(self, boards=None, totalResults=None, ):
        self.boards = boards
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.boards = []
                    (_etype209, _size212) = iprot.readListBegin()
                    for _i210 in range(_size212):
                        _elem211 = Board()
                        _elem211.read(iprot)
                        self.boards.append(_elem211)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindBoardsAPIResponse')
        if self.boards is not None:
            oprot.writeFieldBegin('boards', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.boards))
            for _iter213 in self.boards:
                _iter213.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 2)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindBoardsForListingsAPIResponse(object):
    """
    Attributes:
     - listingBoards
     - boards
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'listingBoards', (TType.STRING, 'UTF8', TType.STRUCT, (ListingBoards, ListingBoards.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'boards', (TType.STRUCT, (Board, Board.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, listingBoards=None, boards=None, ):
        self.listingBoards = listingBoards
        self.boards = boards

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.listingBoards = {}
                    (_ktype215, _vtype216, _size219) = iprot.readMapBegin()
                    for _i214 in range(_size219):
                        _key217 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val218 = ListingBoards()
                        _val218.read(iprot)
                        self.listingBoards[_key217] = _val218
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.boards = []
                    (_etype220, _size223) = iprot.readListBegin()
                    for _i221 in range(_size223):
                        _elem222 = Board()
                        _elem222.read(iprot)
                        self.boards.append(_elem222)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindBoardsForListingsAPIResponse')
        if self.listingBoards is not None:
            oprot.writeFieldBegin('listingBoards', TType.MAP, 1)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.listingBoards))
            for _kiter224, _viter225 in self.listingBoards.items():
                oprot.writeString(_kiter224.encode('utf-8') if sys.version_info[0] == 2 else _kiter224)
                _viter225.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.boards is not None:
            oprot.writeFieldBegin('boards', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.boards))
            for _iter226 in self.boards:
                _iter226.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetBoardClustersAPIResponse(object):
    """
    Attributes:
     - board
     - clusters
     - totalNumResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'board', (Board, Board.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'clusters', (TType.STRUCT, (gen.urbancompass.listing_translation.listing_translation_service.ttypes.TranslationClusterResult, gen.urbancompass.listing_translation.listing_translation_service.ttypes.TranslationClusterResult.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalNumResults', None, None, ),  # 3
    )
    def __init__(self, board=None, clusters=None, totalNumResults=None, ):
        self.board = board
        self.clusters = clusters
        self.totalNumResults = totalNumResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.board = Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.clusters = []
                    (_etype227, _size230) = iprot.readListBegin()
                    for _i228 in range(_size230):
                        _elem229 = gen.urbancompass.listing_translation.listing_translation_service.ttypes.TranslationClusterResult()
                        _elem229.read(iprot)
                        self.clusters.append(_elem229)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalNumResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetBoardClustersAPIResponse')
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 1)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        if self.clusters is not None:
            oprot.writeFieldBegin('clusters', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.clusters))
            for _iter231 in self.clusters:
                _iter231.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalNumResults is not None:
            oprot.writeFieldBegin('totalNumResults', TType.I32, 3)
            oprot.writeI32(self.totalNumResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnarchiveBoardAPIResponse(object):
    """
    Attributes:
     - board
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'board', (Board, Board.thrift_spec), None, ),  # 1
    )
    def __init__(self, board=None, ):
        self.board = board

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.board = Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnarchiveBoardAPIResponse')
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 1)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddListingsAPIResponse(object):
    """
    Attributes:
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listings', (TType.STRUCT, (BoardListing, BoardListing.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, listings=None, ):
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype232, _size235) = iprot.readListBegin()
                    for _i233 in range(_size235):
                        _elem234 = BoardListing()
                        _elem234.read(iprot)
                        self.listings.append(_elem234)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddListingsAPIResponse')
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter236 in self.listings:
                _iter236.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ArchiveBoardListingsAPIResponse(object):
    """
    Attributes:
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listings', (TType.STRUCT, (BoardListing, BoardListing.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, listings=None, ):
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype237, _size240) = iprot.readListBegin()
                    for _i238 in range(_size240):
                        _elem239 = BoardListing()
                        _elem239.read(iprot)
                        self.listings.append(_elem239)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ArchiveBoardListingsAPIResponse')
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter241 in self.listings:
                _iter241.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PaginatedBoardContent(object):
    """
    Attributes:
     - listings
     - totalListings
     - listingsPerStatus
     - numLikelyToSell
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listings', (TType.STRUCT, (BoardListing, BoardListing.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'totalListings', None, None, ),  # 2
        (3, TType.MAP, 'listingsPerStatus', (TType.I32, None, TType.I32, None, False), None, ),  # 3
        (4, TType.I32, 'numLikelyToSell', None, None, ),  # 4
    )
    def __init__(self, listings=None, totalListings=None, listingsPerStatus=None, numLikelyToSell=None, ):
        self.listings = listings
        self.totalListings = totalListings
        self.listingsPerStatus = listingsPerStatus
        self.numLikelyToSell = numLikelyToSell

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype242, _size245) = iprot.readListBegin()
                    for _i243 in range(_size245):
                        _elem244 = BoardListing()
                        _elem244.read(iprot)
                        self.listings.append(_elem244)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.totalListings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.listingsPerStatus = {}
                    (_ktype247, _vtype248, _size251) = iprot.readMapBegin()
                    for _i246 in range(_size251):
                        _key249 = iprot.readI32()
                        _val250 = iprot.readI32()
                        self.listingsPerStatus[_key249] = _val250
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.numLikelyToSell = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PaginatedBoardContent')
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter252 in self.listings:
                _iter252.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalListings is not None:
            oprot.writeFieldBegin('totalListings', TType.I32, 2)
            oprot.writeI32(self.totalListings)
            oprot.writeFieldEnd()
        if self.listingsPerStatus is not None:
            oprot.writeFieldBegin('listingsPerStatus', TType.MAP, 3)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.listingsPerStatus))
            for _kiter253, _viter254 in self.listingsPerStatus.items():
                oprot.writeI32(_kiter253)
                oprot.writeI32(_viter254)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.numLikelyToSell is not None:
            oprot.writeFieldBegin('numLikelyToSell', TType.I32, 4)
            oprot.writeI32(self.numLikelyToSell)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnarchiveBoardListingsAPIResponse(object):
    """
    Attributes:
     - listings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'listings', (TType.STRUCT, (BoardListing, BoardListing.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, listings=None, ):
        self.listings = listings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.listings = []
                    (_etype255, _size258) = iprot.readListBegin()
                    for _i256 in range(_size258):
                        _elem257 = BoardListing()
                        _elem257.read(iprot)
                        self.listings.append(_elem257)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnarchiveBoardListingsAPIResponse')
        if self.listings is not None:
            oprot.writeFieldBegin('listings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.listings))
            for _iter259 in self.listings:
                _iter259.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateBoardAPIResponse(object):
    """
    Attributes:
     - board
     - content
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'board', (Board, Board.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'content', (PaginatedBoardContent, PaginatedBoardContent.thrift_spec), None, ),  # 2
    )
    def __init__(self, board=None, content=None, ):
        self.board = board
        self.content = content

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.board = Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.content = PaginatedBoardContent()
                    self.content.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateBoardAPIResponse')
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 1)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRUCT, 2)
            self.content.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetBoardAPIResponse(object):
    """
    Attributes:
     - board
     - content
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'board', (Board, Board.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'content', (PaginatedBoardContent, PaginatedBoardContent.thrift_spec), None, ),  # 2
    )
    def __init__(self, board=None, content=None, ):
        self.board = board
        self.content = content

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.board = Board()
                    self.board.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.content = PaginatedBoardContent()
                    self.content.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetBoardAPIResponse')
        if self.board is not None:
            oprot.writeFieldBegin('board', TType.STRUCT, 1)
            self.board.write(oprot)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRUCT, 2)
            self.content.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
