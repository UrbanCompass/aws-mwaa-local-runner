
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CALIFORNIA = "ca"
COLORADO = "co"
CONNECTICUT = "ct"
DELAWARE = "de"
FLORIDA = "fl"
HAWAII = "hi"
ILLINOIS = "il"
INDIANA = "in"
KANSAS = "ks"
MAINE = "me"
MARYLAND = "md"
MASSACHUSETTS = "ma"
MINNESOTA = "mn"
MISSOURI = "mo"
NEW_HAMPSHIRE = "nh"
NEW_JERSEY = "nj"
NEW_YORK = "ny"
NORTH_CAROLINA = "nc"
PENNSYLVANIA = "pa"
REGIONS_REQUIRING_MARKET = set((
    "md",
    "ny",
    "nj",
    "pa",
    "mo",
    "ks",
    "ca",
))
REGIONS_WITH_OPTIONAL_FIELDS = set((
    "ny",
))
RHODE_ISLAND = "ri"
SOUTH_CAROLINA = "sc"
VIRGINIA = "va"
WASHINGTON_DC = "dc"
WISCONSIN = "wi"
