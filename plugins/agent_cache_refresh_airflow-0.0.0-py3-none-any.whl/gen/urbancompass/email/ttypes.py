
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class InvitationOrigin(object):
    NEW_LEAD = 0
    CLIENT_INVITATION = 1
    COLLECTIONS_INVITATION = 2
    COLLECTIONS_LANDING_PAGE = 3
    PHOTOGRAPHY_INVITATION = 4

    _VALUES_TO_NAMES = {
        0: "NEW_LEAD",
        1: "CLIENT_INVITATION",
        2: "COLLECTIONS_INVITATION",
        3: "COLLECTIONS_LANDING_PAGE",
        4: "PHOTOGRAPHY_INVITATION",
    }

    _NAMES_TO_VALUES = {
        "NEW_LEAD": 0,
        "CLIENT_INVITATION": 1,
        "COLLECTIONS_INVITATION": 2,
        "COLLECTIONS_LANDING_PAGE": 3,
        "PHOTOGRAPHY_INVITATION": 4,
    }

