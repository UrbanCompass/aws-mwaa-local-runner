# -*- coding: utf-8 -*-
"""
:copyright: (c) 2017 by UrbanCompass, Inc.
"""
from gen.urbancompass.geography.common import constants
import gen.urbancompass.geography.sources.constants as source_constants
import gen.urbancompass.geography.geos.constants as geo_constants

SQ_FEET_PER_ACRE = 43560  # Number of square feet in an acre

MONGO_ID = "_id"
RESO_ID = "__reso_id__"

UC_SOURCE_ID = "__uc_source__"
UC_ID_SHA = "__uc_id_sha__"
INGEST_START_TIME = "__raw_ingest_start_time__"
UC_DISAPPEARED_FROM_FEED = "UC_DISAPPEARED_FROM_FEED"
UC_DISAPPEARED_FROM_FEED_AT = "__uc_disappeared_from_feed_at__"

PIPELINE_SOURCE = "__pipeline_source__"
PIPELINE_SOURCE_MIGRATION = 1
PIPELINE_SOURCE_INCREMENTAL = 2


CONTRIBUTING_DATA_SET_NAME = "mcd_name"
GEO_IDS = "geo_ids"

TIME_SENSITIVE_GEOCODING_QUEUE_NAME = "geocoding"
NON_TIME_SENSITIVE_GEOCODING_QUEUE_NAME = "geocodingNonTimeSensitive"

GEOS_EXCEPT_NYC = list(set(constants.GEO_NORMALIZATION_ENABLED_GEOS) - set([constants.NYC_GEO_ID]))

DATA_SOURCE_INFO = {
    constants.DC_MRIS_VOW_RETS: {CONTRIBUTING_DATA_SET_NAME: "uc", GEO_IDS: [constants.DC_GEO_ID]},
    constants.MIAMI_GFLR_RETS: {
        CONTRIBUTING_DATA_SET_NAME: "uc_gflr",
        GEO_IDS: [constants.MIAMI_GEO_ID],
    },
    constants.MIAMI_RE_V2_RETS: {
        CONTRIBUTING_DATA_SET_NAME: "uc_re_v2",
        GEO_IDS: [constants.MIAMI_GEO_ID],
    },
    constants.BOSTON_MLS_RETS: {
        CONTRIBUTING_DATA_SET_NAME: "uc",
        GEO_IDS: [constants.BOSTON_GEO_ID],
    },
    constants.HREO: {CONTRIBUTING_DATA_SET_NAME: "uc", GEO_IDS: [constants.HAMPTONS_GEO_ID]},
    constants.LA_CLAW: {CONTRIBUTING_DATA_SET_NAME: "uc", GEO_IDS: [constants.LA_GEO_ID]},
    constants.LA_CRMLS: {CONTRIBUTING_DATA_SET_NAME: "uc_crmls", GEO_IDS: [constants.LA_GEO_ID]},
    constants.SANTA_BARBARA_MONTECITO_MLS_RETS: {
        CONTRIBUTING_DATA_SET_NAME: "uc",
        GEO_IDS: [constants.SANTA_BARBARA_MONTECITO_GEO_ID],
    },
    constants.ASPEN_MLS_RETS: {CONTRIBUTING_DATA_SET_NAME: "uc", GEO_IDS: [constants.ASPEN_GEO_ID]},
    constants.SF_SFAR: {CONTRIBUTING_DATA_SET_NAME: "uc", GEO_IDS: [constants.SF_GEO_ID]},
    constants.SF_MLSLISTINGS: {
        CONTRIBUTING_DATA_SET_NAME: "uc_mlslistings",
        GEO_IDS: [constants.SF_GEO_ID],
    },
    constants.SF_BAREIS: {
        CONTRIBUTING_DATA_SET_NAME: "uc_sf_bareis",
        GEO_IDS: [constants.SF_GEO_ID],
    },
    constants.NYC_RLS_DLA: {CONTRIBUTING_DATA_SET_NAME: "uc_rls", GEO_IDS: [constants.NYC_GEO_ID]},
    "nyc_olr_all": {CONTRIBUTING_DATA_SET_NAME: "uc", GEO_IDS: [constants.NYC_GEO_ID]},
    constants.NYC_REAL_PLUS: {CONTRIBUTING_DATA_SET_NAME: "rp", GEO_IDS: [constants.NYC_GEO_ID]},
    "arcgate": {CONTRIBUTING_DATA_SET_NAME: "uc_arcgate", GEO_IDS: [constants.NYC_GEO_ID]},
    "nyc_exclusive": {CONTRIBUTING_DATA_SET_NAME: "uc_exclusive", GEO_IDS: [constants.NYC_GEO_ID]},
    constants.NYC_ACRIS: {CONTRIBUTING_DATA_SET_NAME: "acris", GEO_IDS: [constants.NYC_GEO_ID]},
    constants.REALTYTRAC: {CONTRIBUTING_DATA_SET_NAME: "acris", GEO_IDS: GEOS_EXCEPT_NYC},
    "nyc_nestio": {CONTRIBUTING_DATA_SET_NAME: "uc_nestio", GEO_IDS: [constants.NYC_GEO_ID]},
    constants.PHILADELPHIA_BRIGHT: {
        CONTRIBUTING_DATA_SET_NAME: "uc",
        GEO_IDS: [constants.PHILADELPHIA_GEO_ID],
    },
}

ALL_SOURCE_FEEDS = [
    v for k, v in list(source_constants.__dict__.items()) if not k.startswith("__") and k.isupper()
]

ALL_GEOS = [
    v for k, v in list(geo_constants.__dict__.items()) if not k.startswith("__") and k.isupper()
]

LISTING_RETRIEVED_PER_RUN_METRIC = "ListingRetrievedPerRun"
LISTING_RETRIEVED_PER_QUERY_METRIC = "ListingRetrievedPerQuery"
LISTING_DUPLICATED_OBJECT = "ListingDuplicatedObject"
LISTING_DUPLICATED_BY_QUERY = "ListingDuplicatedByQuery"
LISTING_BY_IMAGE_TYPE = "ListingByImageType"
LISTING_BY_IMAGE_COUNT = "ListingByImageCount"
LISTING_SANITIZED = "ListingSanitized"
LISTING_INVALID_TIMESTAMP = "ListingInvalidTimestamp"
LISTING_KAFKA_DISCARD_OVERSIZED = "ListingKafkaDiscardOversized"
LISTING_KAFKA_SPLIT_OVERSIZED = "ListingKafkaSplitOversized"
LISTING_NEW_LISTING = "ListingNewListing"
LISTING_MODIFIED_LISTING = "ListingModifiedListing"
LISTING_MODIFIED_LISTING_BASED_ON_TIMESTAMP = "ListingModifiedListingBasedOnTimestamp"
LISTING_INGESTION_TOTAL_LATENCY = "ListingIngestionTotalLatency"
LISTING_INGESTION_AVG_LATENCY = "ListingIngestionAvgLatency"
LISTING_TOO_LARGE_TRUNCATED = "ListingTooLargeTruncated"
LISTING_NO_SHA1 = "Listing_No_Sha1"
LISTING_SHA1_SHA2_MATCH = "Listing_Sha1_Sha2_Match"
LISTING_WITHOUT_PRIMARY_KEY = "ListingWithoutPrimaryKey"
LISTING_DEFECTED = "ListingDefected"
LISTING_EXCESSIVE_COUNT = "ListingExcessiveCount"
LISTING_WEB_API_RESULT = "ListingWebApiResult"
LISTING_WEB_API_INVALID_RESULT = "ListingWebApiInvalidResult"
LISTING_DOWNSTREAM_ATTEMPT = "ListingDownstreamAttempt"
LISTING_PROPERTY_WITHOUT_PRIMARY_KEY = "ListingPropertyWithoutPrimaryKey"

RETS_QUERY_RETRY = "RetsProxyQueryRetry"
RETS_QUERY_DURATION = "RetsProxyRecvDuration"
RETS_QUERY_WEBSOCKET_TIMEOUT_RETRY = "RetsProxyRecvWebsocketTimeoutRetry"
RETS_QUERY_WEBSOCKET_TIMEOUT = "RetsProxyRecvWebsocketTimeout"
RETS_PROXY_EXCEPTION = "RetsProxyException"
FEED_FORGE_QUERY_RETRY = "FeedForgeProxyQueryRetry"
FEED_FORGE_DURATION = "FeedForgeDuration"

IMAGE_UPLOAD_PER_RUN_METRIC = "ImageUploadPerRun"

HTTP_LITERAL = "http://"

DEFAULT_STALE_LISTING_CB_THRESHOLD = 20.0

BLUE_MAP_STATUS_CREATED = "created"
BLUE_MAP_STATUS_RUNNING = "running"
BLUE_MAP_STATUS_ERROR = "error"
BLUE_MAP_STATUS_FINISHED = "finished"

BLUE_MAP_RUN_MODE_LEGACY = 0
BLUE_MAP_RUN_MODE_COMPAT = 1
BLUE_MAP_RUN_MODE_ENHANCED = 2

BLUE_MAP_TASK_TYPE_INIT = 0
BLUE_MAP_TASK_TYPE_REGULAR = 1

BLUE_MAP_OFFSET_NOT_STARTED = -1


# change request end time adjusted by 2 seconds
CHANGE_REQUEST_END_TIME_ADJUST_SECONDS = 2

# max allowed size 15M
LISTING_MAX_SIZE = 15 * 1024 * 1024

FIREHOSE_LOG_STRING_MAX = 256

# trestle bulk image download constants
ENV_TO_BUCKET_MAP = {
    "development": "compass-development-media-image-storage",
    "staging": "media-gamma-image-indexer",
    "production": "urbancompass-image-index",
}

S3_IMAGE_JSON_FILE_NAME = "/image_info"
TRESTLE_BULK_DOWNLOAD_DURATION = "TrestleBulkDownloadDuration"
TRESTLE_BULK_DOWNLOAD_ERROR = "TrestleBulkDownloadError"
TRESTLE_IMAGE_INFO_S3_KEY = "TrestleImageInfoS3Key"
TRESTLE_RESPONSE_IMAGE_COUNT = "TrestleResponseImageCount"

MISSED_PROPERTIES = "__missed_properties__"


# these are used in both rets proxy client and server side
RETS_PROXY_COOKIE_TYPE_KEY = "cookie_type"
RETS_PROXY_SESSION_LIMIT_KEY = "session_limit"
RETS_PROXY_BASIC_AUTH_KEY = "basic_auth"

RETS_PROXY_COOKIE_TYPE_COOKIE = "cookie"
RETS_PROXY_COOKIE_TYPE_TRESTLE_TOKEN = "trestle_token"
RETS_PROXY_COOKIE_TYPE_NO_COOKIE = "no_cookie"
RETS_PROXY_SETTING_NOT_INIT = "not_init"

STARGATE = "stargate"
MIRROR = "mirror"
AIRFLOW = "airflow"

FEED_PROXY_DISABLE = 1
FEED_PROXY_DUAL_MODE = 2
FEED_PROXY_ENABLE = 3

TIMEFMT = "%Y-%m-%d %H:%M:%S"
