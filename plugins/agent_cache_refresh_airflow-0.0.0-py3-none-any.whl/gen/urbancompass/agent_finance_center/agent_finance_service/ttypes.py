
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.agent_finance_center.agent_finance.ttypes
import gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes
import gen.urbancompass.common.base.ttypes

from thrift.transport import TTransport


class AccountManualPatchResponse(object):
    """
    Attributes:
     - status
     - accountPatched
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'accountPatched', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AccountPatched, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AccountPatched.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, accountPatched=None, ):
        self.status = status
        self.accountPatched = accountPatched

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.accountPatched = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AccountPatched()
                    self.accountPatched.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.accountPatched is not None:
            oprot.writeFieldBegin('accountPatched', TType.STRUCT, 2)
            self.accountPatched.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddUserAccessRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - role
     - userIdToBeAdded
     - signature
     - emailId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'role', None, None, ),  # 3
        (4, TType.STRING, 'userIdToBeAdded', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'emailId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, role=None, userIdToBeAdded=None, signature=None, emailId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.role = role
        self.userIdToBeAdded = userIdToBeAdded
        self.signature = signature
        self.emailId = emailId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.role = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userIdToBeAdded = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.emailId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddUserAccessRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.I32, 3)
            oprot.writeI32(self.role)
            oprot.writeFieldEnd()
        if self.userIdToBeAdded is not None:
            oprot.writeFieldBegin('userIdToBeAdded', TType.STRING, 4)
            oprot.writeString(self.userIdToBeAdded.encode('utf-8') if sys.version_info[0] == 2 else self.userIdToBeAdded)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.emailId is not None:
            oprot.writeFieldBegin('emailId', TType.STRING, 6)
            oprot.writeString(self.emailId.encode('utf-8') if sys.version_info[0] == 2 else self.emailId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddUserAccessResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddUserAccessResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentRoleManualPatchResponse(object):
    """
    Attributes:
     - status
     - agentRolePatched
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'agentRolePatched', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AgentRolePatched, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AgentRolePatched.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, agentRolePatched=None, ):
        self.status = status
        self.agentRolePatched = agentRolePatched

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.agentRolePatched = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AgentRolePatched()
                    self.agentRolePatched.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentRoleManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.agentRolePatched is not None:
            oprot.writeFieldBegin('agentRolePatched', TType.STRUCT, 2)
            self.agentRolePatched.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckTeamDataAccessRequest(object):
    """
    Attributes:
     - userId
     - signature
     - afcTeamId
     - compassTeamId
     - afcAgentId
     - compassAgentId
     - impersonatorId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 2
        None,  # 3
        (4, TType.STRING, 'afcTeamId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'afcAgentId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'compassAgentId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, signature=None, afcTeamId=None, compassTeamId=None, afcAgentId=None, compassAgentId=None, impersonatorId=None, ):
        self.userId = userId
        self.signature = signature
        self.afcTeamId = afcTeamId
        self.compassTeamId = compassTeamId
        self.afcAgentId = afcAgentId
        self.compassAgentId = compassAgentId
        self.impersonatorId = impersonatorId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.afcTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.afcAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.compassAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckTeamDataAccessRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 2)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.afcTeamId is not None:
            oprot.writeFieldBegin('afcTeamId', TType.STRING, 4)
            oprot.writeString(self.afcTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.afcTeamId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 5)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.afcAgentId is not None:
            oprot.writeFieldBegin('afcAgentId', TType.STRING, 6)
            oprot.writeString(self.afcAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.afcAgentId)
            oprot.writeFieldEnd()
        if self.compassAgentId is not None:
            oprot.writeFieldBegin('compassAgentId', TType.STRING, 7)
            oprot.writeString(self.compassAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.compassAgentId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 8)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckTeamDataAccessResponse(object):
    """
    Attributes:
     - status
     - accessLevel
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'accessLevel', None, None, ),  # 2
    )
    def __init__(self, status=None, accessLevel=None, ):
        self.status = status
        self.accessLevel = accessLevel

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.accessLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckTeamDataAccessResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.accessLevel is not None:
            oprot.writeFieldBegin('accessLevel', TType.I32, 2)
            oprot.writeI32(self.accessLevel)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactManualPatchResponse(object):
    """
    Attributes:
     - status
     - contactPatched
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'contactPatched', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.ContactPatched, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.ContactPatched.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, contactPatched=None, ):
        self.status = status
        self.contactPatched = contactPatched

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.contactPatched = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.ContactPatched()
                    self.contactPatched.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.contactPatched is not None:
            oprot.writeFieldBegin('contactPatched', TType.STRUCT, 2)
            self.contactPatched.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateAccountManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - afcId
     - overrides
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'afcId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'overrides', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AccountOverrides, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AccountOverrides.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, afcId=None, overrides=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.afcId = afcId
        self.overrides = overrides
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.overrides = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AccountOverrides()
                    self.overrides.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateAccountManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 3)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.overrides is not None:
            oprot.writeFieldBegin('overrides', TType.STRUCT, 4)
            self.overrides.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateAgentRoleManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - externalId
     - overrides
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'overrides', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AgentRoleOverrides, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AgentRoleOverrides.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, externalId=None, overrides=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.externalId = externalId
        self.overrides = overrides
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.overrides = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.AgentRoleOverrides()
                    self.overrides.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateAgentRoleManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.overrides is not None:
            oprot.writeFieldBegin('overrides', TType.STRUCT, 4)
            self.overrides.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateContactManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - afcId
     - overrides
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'afcId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'overrides', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.ContactOverrides, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.ContactOverrides.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, afcId=None, overrides=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.afcId = afcId
        self.overrides = overrides
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.overrides = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.ContactOverrides()
                    self.overrides.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateContactManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 3)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.overrides is not None:
            oprot.writeFieldBegin('overrides', TType.STRUCT, 4)
            self.overrides.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDealManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - afcId
     - overrides
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'afcId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'overrides', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.DealOverrides, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.DealOverrides.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, afcId=None, overrides=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.afcId = afcId
        self.overrides = overrides
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.overrides = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.DealOverrides()
                    self.overrides.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDealManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 3)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.overrides is not None:
            oprot.writeFieldBegin('overrides', TType.STRUCT, 4)
            self.overrides.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateEntityManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - afcId
     - overrides
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'afcId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'overrides', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.EntityOverrides, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.EntityOverrides.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, afcId=None, overrides=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.afcId = afcId
        self.overrides = overrides
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.overrides = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.EntityOverrides()
                    self.overrides.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateEntityManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 3)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.overrides is not None:
            oprot.writeFieldBegin('overrides', TType.STRUCT, 4)
            self.overrides.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateTransactionManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - afcId
     - overrides
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'afcId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'overrides', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.TransactionOverrides, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.TransactionOverrides.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, afcId=None, overrides=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.afcId = afcId
        self.overrides = overrides
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.overrides = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.TransactionOverrides()
                    self.overrides.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateTransactionManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 3)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.overrides is not None:
            oprot.writeFieldBegin('overrides', TType.STRUCT, 4)
            self.overrides.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealExistRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - dealExternalId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dealExternalId', 'UTF8', None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, dealExternalId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.dealExternalId = dealExternalId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dealExternalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealExistRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dealExternalId is not None:
            oprot.writeFieldBegin('dealExternalId', TType.STRING, 4)
            oprot.writeString(self.dealExternalId.encode('utf-8') if sys.version_info[0] == 2 else self.dealExternalId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealExistResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealExistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealManualPatchResponse(object):
    """
    Attributes:
     - status
     - dealPatched
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dealPatched', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.DealPatched, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.DealPatched.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dealPatched=None, ):
        self.status = status
        self.dealPatched = dealPatched

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dealPatched = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.DealPatched()
                    self.dealPatched.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dealPatched is not None:
            oprot.writeFieldBegin('dealPatched', TType.STRUCT, 2)
            self.dealPatched.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DebugDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - dealExternalId
     - authorizedUserId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dealExternalId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'authorizedUserId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, dealExternalId=None, authorizedUserId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.dealExternalId = dealExternalId
        self.authorizedUserId = authorizedUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dealExternalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.authorizedUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DebugDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dealExternalId is not None:
            oprot.writeFieldBegin('dealExternalId', TType.STRING, 4)
            oprot.writeString(self.dealExternalId.encode('utf-8') if sys.version_info[0] == 2 else self.dealExternalId)
            oprot.writeFieldEnd()
        if self.authorizedUserId is not None:
            oprot.writeFieldBegin('authorizedUserId', TType.STRING, 5)
            oprot.writeString(self.authorizedUserId.encode('utf-8') if sys.version_info[0] == 2 else self.authorizedUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DebugDealResponse(object):
    """
    Attributes:
     - status
     - deal
     - dealStatus
     - debugMessage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'deal', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal.thrift_spec), None, ),  # 2
        (3, TType.I32, 'dealStatus', None, None, ),  # 3
        (4, TType.STRING, 'debugMessage', 'UTF8', None, ),  # 4
    )
    def __init__(self, status=None, deal=None, dealStatus=None, debugMessage=None, ):
        self.status = status
        self.deal = deal
        self.dealStatus = dealStatus
        self.debugMessage = debugMessage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.deal = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal()
                    self.deal.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.dealStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.debugMessage = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DebugDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.deal is not None:
            oprot.writeFieldBegin('deal', TType.STRUCT, 2)
            self.deal.write(oprot)
            oprot.writeFieldEnd()
        if self.dealStatus is not None:
            oprot.writeFieldBegin('dealStatus', TType.I32, 3)
            oprot.writeI32(self.dealStatus)
            oprot.writeFieldEnd()
        if self.debugMessage is not None:
            oprot.writeFieldBegin('debugMessage', TType.STRING, 4)
            oprot.writeString(self.debugMessage.encode('utf-8') if sys.version_info[0] == 2 else self.debugMessage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteAgentRoleManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - externalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, externalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.externalId = externalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteAgentRoleManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - dealId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dealId', 'UTF8', None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, dealId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.dealId = dealId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dealId is not None:
            oprot.writeFieldBegin('dealId', TType.STRING, 4)
            oprot.writeString(self.dealId.encode('utf-8') if sys.version_info[0] == 2 else self.dealId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDealResponse(object):
    """
    Attributes:
     - status
     - deal
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'deal', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, deal=None, ):
        self.status = status
        self.deal = deal

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.deal = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal()
                    self.deal.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.deal is not None:
            oprot.writeFieldBegin('deal', TType.STRUCT, 2)
            self.deal.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - afcId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'afcId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, afcId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.afcId = afcId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.afcId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.afcId is not None:
            oprot.writeFieldBegin('afcId', TType.STRING, 3)
            oprot.writeString(self.afcId.encode('utf-8') if sys.version_info[0] == 2 else self.afcId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteManualPatchResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntityManualPatchResponse(object):
    """
    Attributes:
     - status
     - entityPatched
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'entityPatched', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.EntityPatched, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.EntityPatched.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, entityPatched=None, ):
        self.status = status
        self.entityPatched = entityPatched

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.entityPatched = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.EntityPatched()
                    self.entityPatched.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntityManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.entityPatched is not None:
            oprot.writeFieldBegin('entityPatched', TType.STRUCT, 2)
            self.entityPatched.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindDealByIdRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - dealId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dealId', 'UTF8', None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, dealId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.dealId = dealId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindDealByIdRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dealId is not None:
            oprot.writeFieldBegin('dealId', TType.STRING, 4)
            oprot.writeString(self.dealId.encode('utf-8') if sys.version_info[0] == 2 else self.dealId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindDealByIdResponse(object):
    """
    Attributes:
     - status
     - deal
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'deal', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, deal=None, ):
        self.status = status
        self.deal = deal

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.deal = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal()
                    self.deal.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindDealByIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.deal is not None:
            oprot.writeFieldBegin('deal', TType.STRUCT, 2)
            self.deal.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAccountManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - externalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, externalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.externalId = externalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAccountManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentRoleManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - externalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, externalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.externalId = externalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentRoleManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllUserDealsRequest(object):
    """
    Attributes:
     - afcUserId
     - userId
     - signature
     - impersonatorId
     - query
     - salesforceId
     - includeTotalCount
     - includeDenormalizedDeals
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'query', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'includeTotalCount', None, None, ),  # 7
        (8, TType.BOOL, 'includeDenormalizedDeals', None, None, ),  # 8
    )
    def __init__(self, afcUserId=None, userId=None, signature=None, impersonatorId=None, query=None, salesforceId=None, includeTotalCount=None, includeDenormalizedDeals=None, ):
        self.afcUserId = afcUserId
        self.userId = userId
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.query = query
        self.salesforceId = salesforceId
        self.includeTotalCount = includeTotalCount
        self.includeDenormalizedDeals = includeDenormalizedDeals

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.query = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query()
                    self.query.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeTotalCount = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.includeDenormalizedDeals = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllUserDealsRequest')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRUCT, 5)
            self.query.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        if self.includeTotalCount is not None:
            oprot.writeFieldBegin('includeTotalCount', TType.BOOL, 7)
            oprot.writeBool(self.includeTotalCount)
            oprot.writeFieldEnd()
        if self.includeDenormalizedDeals is not None:
            oprot.writeFieldBegin('includeDenormalizedDeals', TType.BOOL, 8)
            oprot.writeBool(self.includeDenormalizedDeals)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllUserDealsResponse(object):
    """
    Attributes:
     - status
     - deals
     - denormalizedDeals
     - totalCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'deals', (TType.STRUCT, (gen.urbancompass.agent_finance_center.agent_finance.ttypes.NormalizedDeal, gen.urbancompass.agent_finance_center.agent_finance.ttypes.NormalizedDeal.thrift_spec), False), None, ),  # 2
        (3, TType.I64, 'totalCount', None, None, ),  # 3
        (4, TType.LIST, 'denormalizedDeals', (TType.STRUCT, (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal.thrift_spec), False), None, ),  # 4
    )
    def __init__(self, status=None, deals=None, totalCount=None, denormalizedDeals=None, ):
        self.status = status
        self.deals = deals
        self.totalCount = totalCount
        self.denormalizedDeals = denormalizedDeals

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.deals = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.agent_finance_center.agent_finance.ttypes.NormalizedDeal()
                        _elem4.read(iprot)
                        self.deals.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.totalCount = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.denormalizedDeals = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal()
                        _elem8.read(iprot)
                        self.denormalizedDeals.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllUserDealsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.deals is not None:
            oprot.writeFieldBegin('deals', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.deals))
            for _iter10 in self.deals:
                _iter10.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalCount is not None:
            oprot.writeFieldBegin('totalCount', TType.I64, 3)
            oprot.writeI64(self.totalCount)
            oprot.writeFieldEnd()
        if self.denormalizedDeals is not None:
            oprot.writeFieldBegin('denormalizedDeals', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.denormalizedDeals))
            for _iter11 in self.denormalizedDeals:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetContactManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - externalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, externalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.externalId = externalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetContactManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCurrentUserRequest(object):
    """
    Attributes:
     - userId
     - signature
     - impersonatorId
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 4
    )
    def __init__(self, userId=None, signature=None, impersonatorId=None, salesforceId=None, ):
        self.userId = userId
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCurrentUserRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 2)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 4)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCurrentUserResponse(object):
    """
    Attributes:
     - status
     - user
     - impersonatorId
     - userId
     - isImpersonatorStaff
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'user', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.User, gen.urbancompass.agent_finance_center.agent_finance.ttypes.User.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'isImpersonatorStaff', None, None, ),  # 5
    )
    def __init__(self, status=None, user=None, impersonatorId=None, userId=None, isImpersonatorStaff=None, ):
        self.status = status
        self.user = user
        self.impersonatorId = impersonatorId
        self.userId = userId
        self.isImpersonatorStaff = isImpersonatorStaff

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.user = gen.urbancompass.agent_finance_center.agent_finance.ttypes.User()
                    self.user.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isImpersonatorStaff = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCurrentUserResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.user is not None:
            oprot.writeFieldBegin('user', TType.STRUCT, 2)
            self.user.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.isImpersonatorStaff is not None:
            oprot.writeFieldBegin('isImpersonatorStaff', TType.BOOL, 5)
            oprot.writeBool(self.isImpersonatorStaff)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDealManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - internalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'internalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, internalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.internalId = internalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.internalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDealManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.internalId is not None:
            oprot.writeFieldBegin('internalId', TType.STRING, 3)
            oprot.writeString(self.internalId.encode('utf-8') if sys.version_info[0] == 2 else self.internalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDealNetPaymentRequest(object):
    """
    Attributes:
     - afcUserId
     - afcDealId
     - userId
     - signature
     - impersonatorId
     - salesforceId
     - afcTeamId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'afcDealId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        None,  # 6
        (7, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'afcTeamId', 'UTF8', None, ),  # 8
    )
    def __init__(self, afcUserId=None, afcDealId=None, userId=None, signature=None, impersonatorId=None, salesforceId=None, afcTeamId=None, ):
        self.afcUserId = afcUserId
        self.afcDealId = afcDealId
        self.userId = userId
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId
        self.afcTeamId = afcTeamId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.afcDealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.afcTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDealNetPaymentRequest')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.afcDealId is not None:
            oprot.writeFieldBegin('afcDealId', TType.STRING, 2)
            oprot.writeString(self.afcDealId.encode('utf-8') if sys.version_info[0] == 2 else self.afcDealId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 7)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        if self.afcTeamId is not None:
            oprot.writeFieldBegin('afcTeamId', TType.STRING, 8)
            oprot.writeString(self.afcTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.afcTeamId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDealNetPaymentResponse(object):
    """
    Attributes:
     - status
     - netPayment
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'netPayment', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.NetPayment, gen.urbancompass.agent_finance_center.agent_finance.ttypes.NetPayment.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, netPayment=None, ):
        self.status = status
        self.netPayment = netPayment

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.netPayment = gen.urbancompass.agent_finance_center.agent_finance.ttypes.NetPayment()
                    self.netPayment.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDealNetPaymentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.netPayment is not None:
            oprot.writeFieldBegin('netPayment', TType.STRUCT, 2)
            self.netPayment.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDealsAssociatedAgentsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - afcDealIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'afcDealIds', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, afcDealIds=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.afcDealIds = afcDealIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.afcDealIds = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.afcDealIds.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDealsAssociatedAgentsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.afcDealIds is not None:
            oprot.writeFieldBegin('afcDealIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.afcDealIds))
            for _iter16 in self.afcDealIds:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDealsAssociatedAgentsResponse(object):
    """
    Attributes:
     - status
     - dealsAgentsMappings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'dealsAgentsMappings', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 2
    )
    def __init__(self, status=None, dealsAgentsMappings=None, ):
        self.status = status
        self.dealsAgentsMappings = dealsAgentsMappings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.dealsAgentsMappings = {}
                    (_ktype18, _vtype19, _size22) = iprot.readMapBegin()
                    for _i17 in range(_size22):
                        _key20 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val21 = []
                        (_etype23, _size26) = iprot.readListBegin()
                        for _i24 in range(_size26):
                            _elem25 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val21.append(_elem25)
                        iprot.readListEnd()
                        self.dealsAgentsMappings[_key20] = _val21
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDealsAssociatedAgentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dealsAgentsMappings is not None:
            oprot.writeFieldBegin('dealsAgentsMappings', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.dealsAgentsMappings))
            for _kiter27, _viter28 in self.dealsAgentsMappings.items():
                oprot.writeString(_kiter27.encode('utf-8') if sys.version_info[0] == 2 else _kiter27)
                oprot.writeListBegin(TType.STRING, len(_viter28))
                for _iter29 in _viter28:
                    oprot.writeString(_iter29.encode('utf-8') if sys.version_info[0] == 2 else _iter29)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetEntityManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - externalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'externalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, externalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.externalId = externalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetEntityManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 3)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetFinanceEmailDistroRequest(object):
    """
    Attributes:
     - userId
     - geoId
     - signature
     - impersonatorId
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'geoId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, geoId=None, signature=None, impersonatorId=None, salesforceId=None, ):
        self.userId = userId
        self.geoId = geoId
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetFinanceEmailDistroRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 2)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetFinanceEmailDistroResponse(object):
    """
    Attributes:
     - status
     - emailDistro
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'emailDistro', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, emailDistro=None, ):
        self.status = status
        self.emailDistro = emailDistro

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.emailDistro = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetFinanceEmailDistroResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.emailDistro is not None:
            oprot.writeFieldBegin('emailDistro', TType.STRING, 2)
            oprot.writeString(self.emailDistro.encode('utf-8') if sys.version_info[0] == 2 else self.emailDistro)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImpersonationsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImpersonationsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImpersonationsResponse(object):
    """
    Attributes:
     - status
     - all
     - selected
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'all', (TType.STRUCT, (gen.urbancompass.agent_finance_center.agent_finance.ttypes.User, gen.urbancompass.agent_finance_center.agent_finance.ttypes.User.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'selected', (TType.STRUCT, (gen.urbancompass.agent_finance_center.agent_finance.ttypes.User, gen.urbancompass.agent_finance_center.agent_finance.ttypes.User.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, all=None, selected=None, ):
        self.status = status
        self.all = all
        self.selected = selected

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.all = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = gen.urbancompass.agent_finance_center.agent_finance.ttypes.User()
                        _elem32.read(iprot)
                        self.all.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.selected = []
                    (_etype34, _size37) = iprot.readListBegin()
                    for _i35 in range(_size37):
                        _elem36 = gen.urbancompass.agent_finance_center.agent_finance.ttypes.User()
                        _elem36.read(iprot)
                        self.selected.append(_elem36)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImpersonationsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.all is not None:
            oprot.writeFieldBegin('all', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.all))
            for _iter38 in self.all:
                _iter38.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.selected is not None:
            oprot.writeFieldBegin('selected', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.selected))
            for _iter39 in self.selected:
                _iter39.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetMostRecentAfcUpdateTimeRequest(object):
    """
    Attributes:
     - table
     - userId
     - impersonatorId
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'table', None, None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
    )
    def __init__(self, table=None, userId=None, impersonatorId=None, signature=None, ):
        self.table = table
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.table = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetMostRecentAfcUpdateTimeRequest')
        if self.table is not None:
            oprot.writeFieldBegin('table', TType.I32, 1)
            oprot.writeI32(self.table)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetMostRecentAfcUpdateTimeResponse(object):
    """
    Attributes:
     - status
     - timestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I64, 'timestamp', None, None, ),  # 2
    )
    def __init__(self, status=None, timestamp=None, ):
        self.status = status
        self.timestamp = timestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetMostRecentAfcUpdateTimeResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 2)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetNumberOfObjectsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - type
     - signature
     - salesforceId
     - objectType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'type', None, None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
        (6, TType.I32, 'objectType', None, None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, type=None, signature=None, salesforceId=None, objectType=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.type = type
        self.signature = signature
        self.salesforceId = salesforceId
        self.objectType = objectType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.objectType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetNumberOfObjectsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 3)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        if self.objectType is not None:
            oprot.writeFieldBegin('objectType', TType.I32, 6)
            oprot.writeI32(self.objectType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetNumberOfObjectsResponse(object):
    """
    Attributes:
     - status
     - count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'count', None, None, ),  # 2
    )
    def __init__(self, status=None, count=None, ):
        self.status = status
        self.count = count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetNumberOfObjectsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 2)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamRequest(object):
    """
    Attributes:
     - afcTeamId
     - userId
     - signature
     - impersonatorId
     - salesforceId
     - compassTeamId
     - includeMembers
     - includeHistoricalMembers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcTeamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'includeMembers', None, None, ),  # 7
        (8, TType.BOOL, 'includeHistoricalMembers', None, None, ),  # 8
    )
    def __init__(self, afcTeamId=None, userId=None, signature=None, impersonatorId=None, salesforceId=None, compassTeamId=None, includeMembers=None, includeHistoricalMembers=None, ):
        self.afcTeamId = afcTeamId
        self.userId = userId
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId
        self.compassTeamId = compassTeamId
        self.includeMembers = includeMembers
        self.includeHistoricalMembers = includeHistoricalMembers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeMembers = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.includeHistoricalMembers = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamRequest')
        if self.afcTeamId is not None:
            oprot.writeFieldBegin('afcTeamId', TType.STRING, 1)
            oprot.writeString(self.afcTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.afcTeamId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 6)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.includeMembers is not None:
            oprot.writeFieldBegin('includeMembers', TType.BOOL, 7)
            oprot.writeBool(self.includeMembers)
            oprot.writeFieldEnd()
        if self.includeHistoricalMembers is not None:
            oprot.writeFieldBegin('includeHistoricalMembers', TType.BOOL, 8)
            oprot.writeBool(self.includeHistoricalMembers)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamResponse(object):
    """
    Attributes:
     - status
     - team
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'team', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Team, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Team.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, team=None, ):
        self.status = status
        self.team = team

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.team = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Team()
                    self.team.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRUCT, 2)
            self.team.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamSummaryRequest(object):
    """
    Attributes:
     - afcTeamId
     - userId
     - query
     - signature
     - impersonatorId
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcTeamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'query', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, afcTeamId=None, userId=None, query=None, signature=None, impersonatorId=None, salesforceId=None, ):
        self.afcTeamId = afcTeamId
        self.userId = userId
        self.query = query
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.query = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query()
                    self.query.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamSummaryRequest')
        if self.afcTeamId is not None:
            oprot.writeFieldBegin('afcTeamId', TType.STRING, 1)
            oprot.writeString(self.afcTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.afcTeamId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRUCT, 3)
            self.query.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamSummaryResponse(object):
    """
    Attributes:
     - status
     - teamSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'teamSummary', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.TeamSummary, gen.urbancompass.agent_finance_center.agent_finance.ttypes.TeamSummary.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, teamSummary=None, ):
        self.status = status
        self.teamSummary = teamSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.teamSummary = gen.urbancompass.agent_finance_center.agent_finance.ttypes.TeamSummary()
                    self.teamSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamSummaryResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.teamSummary is not None:
            oprot.writeFieldBegin('teamSummary', TType.STRUCT, 2)
            self.teamSummary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTransactionManualPatchRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - internalId
     - signature
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'internalId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, internalId=None, signature=None, salesforceId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.internalId = internalId
        self.signature = signature
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.internalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTransactionManualPatchRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.internalId is not None:
            oprot.writeFieldBegin('internalId', TType.STRING, 3)
            oprot.writeString(self.internalId.encode('utf-8') if sys.version_info[0] == 2 else self.internalId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserDealsAggregatedSummaryRequest(object):
    """
    Attributes:
     - afcUserId
     - userId
     - query
     - signature
     - impersonatorId
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'query', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, afcUserId=None, userId=None, query=None, signature=None, impersonatorId=None, salesforceId=None, ):
        self.afcUserId = afcUserId
        self.userId = userId
        self.query = query
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.query = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query()
                    self.query.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserDealsAggregatedSummaryRequest')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRUCT, 3)
            self.query.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserDealsAggregatedSummaryResponse(object):
    """
    Attributes:
     - status
     - summary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'summary', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.DealsAggregatedSummary, gen.urbancompass.agent_finance_center.agent_finance.ttypes.DealsAggregatedSummary.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, summary=None, ):
        self.status = status
        self.summary = summary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.summary = gen.urbancompass.agent_finance_center.agent_finance.ttypes.DealsAggregatedSummary()
                    self.summary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserDealsAggregatedSummaryResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.summary is not None:
            oprot.writeFieldBegin('summary', TType.STRUCT, 2)
            self.summary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserDealsSummaryRequest(object):
    """
    Attributes:
     - afcUserId
     - userId
     - query
     - signature
     - impersonatorId
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'query', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 6
    )
    def __init__(self, afcUserId=None, userId=None, query=None, signature=None, impersonatorId=None, salesforceId=None, ):
        self.afcUserId = afcUserId
        self.userId = userId
        self.query = query
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.query = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Query()
                    self.query.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserDealsSummaryRequest')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRUCT, 3)
            self.query.write(oprot)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 4)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 6)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserDealsSummaryResponse(object):
    """
    Attributes:
     - status
     - dealsSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dealsSummary', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.DealsSummary, gen.urbancompass.agent_finance_center.agent_finance.ttypes.DealsSummary.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dealsSummary=None, ):
        self.status = status
        self.dealsSummary = dealsSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dealsSummary = gen.urbancompass.agent_finance_center.agent_finance.ttypes.DealsSummary()
                    self.dealsSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserDealsSummaryResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dealsSummary is not None:
            oprot.writeFieldBegin('dealsSummary', TType.STRUCT, 2)
            self.dealsSummary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserRequest(object):
    """
    Attributes:
     - afcUserId
     - userId
     - signature
     - impersonatorId
     - salesforceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'afcUserId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'salesforceId', 'UTF8', None, ),  # 5
    )
    def __init__(self, afcUserId=None, userId=None, signature=None, impersonatorId=None, salesforceId=None, ):
        self.afcUserId = afcUserId
        self.userId = userId
        self.signature = signature
        self.impersonatorId = impersonatorId
        self.salesforceId = salesforceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.afcUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.salesforceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserRequest')
        if self.afcUserId is not None:
            oprot.writeFieldBegin('afcUserId', TType.STRING, 1)
            oprot.writeString(self.afcUserId.encode('utf-8') if sys.version_info[0] == 2 else self.afcUserId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.salesforceId is not None:
            oprot.writeFieldBegin('salesforceId', TType.STRING, 5)
            oprot.writeString(self.salesforceId.encode('utf-8') if sys.version_info[0] == 2 else self.salesforceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserResponse(object):
    """
    Attributes:
     - status
     - user
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'user', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.User, gen.urbancompass.agent_finance_center.agent_finance.ttypes.User.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, user=None, ):
        self.status = status
        self.user = user

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.user = gen.urbancompass.agent_finance_center.agent_finance.ttypes.User()
                    self.user.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.user is not None:
            oprot.writeFieldBegin('user', TType.STRUCT, 2)
            self.user.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReingestDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - externalId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'externalId', 'UTF8', None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, externalId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.externalId = externalId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReingestDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 4)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReingestDealResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReingestDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReingestEntityRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - externalId
     - entityType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'externalId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'entityType', None, None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, externalId=None, entityType=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.externalId = externalId
        self.entityType = entityType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.entityType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReingestEntityRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 4)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.entityType is not None:
            oprot.writeFieldBegin('entityType', TType.I32, 5)
            oprot.writeI32(self.entityType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReingestEntityResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReingestEntityResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReingestTransactionRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - externalId
     - transactionType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'externalId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'transactionType', None, None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, externalId=None, transactionType=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.externalId = externalId
        self.transactionType = transactionType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.transactionType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReingestTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 4)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.transactionType is not None:
            oprot.writeFieldBegin('transactionType', TType.I32, 5)
            oprot.writeI32(self.transactionType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReingestTransactionResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReingestTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - deal
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'deal', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal.thrift_spec), None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, deal=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.deal = deal

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.deal = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Deal()
                    self.deal.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.deal is not None:
            oprot.writeFieldBegin('deal', TType.STRUCT, 4)
            self.deal.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveDealResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveImpersonationsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
     - allowedUsers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'allowedUsers', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, allowedUsers=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature
        self.allowedUsers = allowedUsers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.allowedUsers = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.allowedUsers.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveImpersonationsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.allowedUsers is not None:
            oprot.writeFieldBegin('allowedUsers', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.allowedUsers))
            for _iter44 in self.allowedUsers:
                oprot.writeString(_iter44.encode('utf-8') if sys.version_info[0] == 2 else _iter44)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SaveImpersonationsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SaveImpersonationsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionManualPatchResponse(object):
    """
    Attributes:
     - status
     - transactionPatched
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'transactionPatched', (gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.TransactionPatched, gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.TransactionPatched.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, transactionPatched=None, ):
        self.status = status
        self.transactionPatched = transactionPatched

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.transactionPatched = gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes.TransactionPatched()
                    self.transactionPatched.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionManualPatchResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.transactionPatched is not None:
            oprot.writeFieldBegin('transactionPatched', TType.STRUCT, 2)
            self.transactionPatched.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class VerifyImpersonationRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 3
    )
    def __init__(self, userId=None, impersonatorId=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('VerifyImpersonationRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 3)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class VerifyImpersonationResponse(object):
    """
    Attributes:
     - status
     - impersonationValid
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'impersonationValid', None, None, ),  # 2
    )
    def __init__(self, status=None, impersonationValid=None, ):
        self.status = status
        self.impersonationValid = impersonationValid

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.impersonationValid = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('VerifyImpersonationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.impersonationValid is not None:
            oprot.writeFieldBegin('impersonationValid', TType.BOOL, 2)
            oprot.writeBool(self.impersonationValid)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
