"""
:copyright: Copyright 2013 Urban Compass Inc. All rights reserved
"""
import json

from thrift.TSerialization import serialize

from uc.json_thrift.TJSONProtocol import TSimpleJSONProtocolFactory
from uc.json_thrift.jsondict_to_thrift import jsondict_to_thrift
from uc.json_thrift import validate_thrift


def thrift_to_json(thrift_object):
    return serialize(thrift_object, protocol_factory=TSimpleJSONProtocolFactory())


def thrift_to_dict(thrift_object):
    return json.loads(thrift_to_json(thrift_object))


def json_to_thrift(serialized_json, thrift_object, string_case=None):
    """Deserialize the serialized json on thrift_object.

    :param serialized_json: the input json string.
    :param thrift_object: the thrift object to read into the value.
      Notice that thrift_object will be modified in place and *NOT* cleared.
    :param string_case: the string case expected in the input dict.
      Acceptable values are:
        None - expect the same case of the field name
        SNAKE_CASE - expect the field names to be snake_cased, so a field named anInt
          will be {"an_int": 1} in the jsondict.
    """
    json_dict = json.loads(serialized_json)
    return jsondict_to_thrift(json_dict, thrift_object, string_case=string_case)


validate_thrift_object = validate_thrift.validate_thrift_object
