
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.responsive.ttypes

from thrift.transport import TTransport


class BorderStyle(object):
    FULL = 0
    SEPARATOR = 1
    HIDDEN = 2

    _VALUES_TO_NAMES = {
        0: "FULL",
        1: "SEPARATOR",
        2: "HIDDEN",
    }

    _NAMES_TO_VALUES = {
        "FULL": 0,
        "SEPARATOR": 1,
        "HIDDEN": 2,
    }


class CardLayoutType(object):
    HORIZONTAL = 0
    VERTICAL = 1
    CAROUSEL = 2
    GRID = 3
    TAB = 4

    _VALUES_TO_NAMES = {
        0: "HORIZONTAL",
        1: "VERTICAL",
        2: "CAROUSEL",
        3: "GRID",
        4: "TAB",
    }

    _NAMES_TO_VALUES = {
        "HORIZONTAL": 0,
        "VERTICAL": 1,
        "CAROUSEL": 2,
        "GRID": 3,
        "TAB": 4,
    }


class Border(object):
    """
    Attributes:
     - top
     - right
     - bottom
     - left
     - all
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'top', None, None, ),  # 1
        (2, TType.I32, 'right', None, None, ),  # 2
        (3, TType.I32, 'bottom', None, None, ),  # 3
        (4, TType.I32, 'left', None, None, ),  # 4
        (5, TType.I32, 'all', None, None, ),  # 5
    )
    def __init__(self, top=None, right=None, bottom=None, left=None, all=None, ):
        self.top = top
        self.right = right
        self.bottom = bottom
        self.left = left
        self.all = all

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.top = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.right = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.bottom = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.left = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.all = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Border')
        if self.top is not None:
            oprot.writeFieldBegin('top', TType.I32, 1)
            oprot.writeI32(self.top)
            oprot.writeFieldEnd()
        if self.right is not None:
            oprot.writeFieldBegin('right', TType.I32, 2)
            oprot.writeI32(self.right)
            oprot.writeFieldEnd()
        if self.bottom is not None:
            oprot.writeFieldBegin('bottom', TType.I32, 3)
            oprot.writeI32(self.bottom)
            oprot.writeFieldEnd()
        if self.left is not None:
            oprot.writeFieldBegin('left', TType.I32, 4)
            oprot.writeI32(self.left)
            oprot.writeFieldEnd()
        if self.all is not None:
            oprot.writeFieldBegin('all', TType.I32, 5)
            oprot.writeI32(self.all)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CardGridLayout(object):
    """
    Attributes:
     - numColumn
     - numRow
     - gridColumnGap
     - gridRowGap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'numColumn', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'numRow', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'gridColumnGap', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'gridRowGap', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 4
    )
    def __init__(self, numColumn=None, numRow=None, gridColumnGap=None, gridRowGap=None, ):
        self.numColumn = numColumn
        self.numRow = numRow
        self.gridColumnGap = gridColumnGap
        self.gridRowGap = gridRowGap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.numColumn = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.numColumn.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.numRow = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.numRow.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.gridColumnGap = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.gridColumnGap.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.gridRowGap = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.gridRowGap.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CardGridLayout')
        if self.numColumn is not None:
            oprot.writeFieldBegin('numColumn', TType.STRUCT, 1)
            self.numColumn.write(oprot)
            oprot.writeFieldEnd()
        if self.numRow is not None:
            oprot.writeFieldBegin('numRow', TType.STRUCT, 2)
            self.numRow.write(oprot)
            oprot.writeFieldEnd()
        if self.gridColumnGap is not None:
            oprot.writeFieldBegin('gridColumnGap', TType.STRUCT, 3)
            self.gridColumnGap.write(oprot)
            oprot.writeFieldEnd()
        if self.gridRowGap is not None:
            oprot.writeFieldBegin('gridRowGap', TType.STRUCT, 4)
            self.gridRowGap.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CardItem(object):
    """
    Attributes:
     - dataVisualizationId
     - columnSpan
     - rowSpan
     - bodyWidth
     - isEmpty
     - title
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dataVisualizationId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'columnSpan', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'rowSpan', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'bodyWidth', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 4
        (5, TType.BOOL, 'isEmpty', None, None, ),  # 5
        (6, TType.STRING, 'title', 'UTF8', None, ),  # 6
    )
    def __init__(self, dataVisualizationId=None, columnSpan=None, rowSpan=None, bodyWidth=None, isEmpty=None, title=None, ):
        self.dataVisualizationId = dataVisualizationId
        self.columnSpan = columnSpan
        self.rowSpan = rowSpan
        self.bodyWidth = bodyWidth
        self.isEmpty = isEmpty
        self.title = title

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dataVisualizationId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.columnSpan = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.columnSpan.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.rowSpan = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.rowSpan.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.bodyWidth = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.bodyWidth.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isEmpty = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CardItem')
        if self.dataVisualizationId is not None:
            oprot.writeFieldBegin('dataVisualizationId', TType.STRING, 1)
            oprot.writeString(self.dataVisualizationId.encode('utf-8') if sys.version_info[0] == 2 else self.dataVisualizationId)
            oprot.writeFieldEnd()
        if self.columnSpan is not None:
            oprot.writeFieldBegin('columnSpan', TType.STRUCT, 2)
            self.columnSpan.write(oprot)
            oprot.writeFieldEnd()
        if self.rowSpan is not None:
            oprot.writeFieldBegin('rowSpan', TType.STRUCT, 3)
            self.rowSpan.write(oprot)
            oprot.writeFieldEnd()
        if self.bodyWidth is not None:
            oprot.writeFieldBegin('bodyWidth', TType.STRUCT, 4)
            self.bodyWidth.write(oprot)
            oprot.writeFieldEnd()
        if self.isEmpty is not None:
            oprot.writeFieldBegin('isEmpty', TType.BOOL, 5)
            oprot.writeBool(self.isEmpty)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 6)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponsiveStateCardLayoutTypeSet(object):
    """
    Attributes:
     - lg
     - md
     - sm
     - xs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'lg', None, None, ),  # 1
        (2, TType.I32, 'md', None, None, ),  # 2
        (3, TType.I32, 'sm', None, None, ),  # 3
        (4, TType.I32, 'xs', None, None, ),  # 4
    )
    def __init__(self, lg=None, md=None, sm=None, xs=None, ):
        self.lg = lg
        self.md = md
        self.sm = sm
        self.xs = xs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.lg = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.md = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sm = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.xs = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponsiveStateCardLayoutTypeSet')
        if self.lg is not None:
            oprot.writeFieldBegin('lg', TType.I32, 1)
            oprot.writeI32(self.lg)
            oprot.writeFieldEnd()
        if self.md is not None:
            oprot.writeFieldBegin('md', TType.I32, 2)
            oprot.writeI32(self.md)
            oprot.writeFieldEnd()
        if self.sm is not None:
            oprot.writeFieldBegin('sm', TType.I32, 3)
            oprot.writeI32(self.sm)
            oprot.writeFieldEnd()
        if self.xs is not None:
            oprot.writeFieldBegin('xs', TType.I32, 4)
            oprot.writeI32(self.xs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponsiveStatePadding(object):
    """
    Attributes:
     - lg
     - md
     - sm
     - xs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'lg', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'md', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'sm', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'xs', 'UTF8', None, ),  # 4
    )
    def __init__(self, lg=None, md=None, sm=None, xs=None, ):
        self.lg = lg
        self.md = md
        self.sm = sm
        self.xs = xs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.lg = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.md = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.sm = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.xs = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponsiveStatePadding')
        if self.lg is not None:
            oprot.writeFieldBegin('lg', TType.STRING, 1)
            oprot.writeString(self.lg.encode('utf-8') if sys.version_info[0] == 2 else self.lg)
            oprot.writeFieldEnd()
        if self.md is not None:
            oprot.writeFieldBegin('md', TType.STRING, 2)
            oprot.writeString(self.md.encode('utf-8') if sys.version_info[0] == 2 else self.md)
            oprot.writeFieldEnd()
        if self.sm is not None:
            oprot.writeFieldBegin('sm', TType.STRING, 3)
            oprot.writeString(self.sm.encode('utf-8') if sys.version_info[0] == 2 else self.sm)
            oprot.writeFieldEnd()
        if self.xs is not None:
            oprot.writeFieldBegin('xs', TType.STRING, 4)
            oprot.writeString(self.xs.encode('utf-8') if sys.version_info[0] == 2 else self.xs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponsiveStateBorder(object):
    """
    Attributes:
     - lg
     - md
     - sm
     - xs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'lg', (Border, Border.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'md', (Border, Border.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'sm', (Border, Border.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'xs', (Border, Border.thrift_spec), None, ),  # 4
    )
    def __init__(self, lg=None, md=None, sm=None, xs=None, ):
        self.lg = lg
        self.md = md
        self.sm = sm
        self.xs = xs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.lg = Border()
                    self.lg.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.md = Border()
                    self.md.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.sm = Border()
                    self.sm.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.xs = Border()
                    self.xs.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponsiveStateBorder')
        if self.lg is not None:
            oprot.writeFieldBegin('lg', TType.STRUCT, 1)
            self.lg.write(oprot)
            oprot.writeFieldEnd()
        if self.md is not None:
            oprot.writeFieldBegin('md', TType.STRUCT, 2)
            self.md.write(oprot)
            oprot.writeFieldEnd()
        if self.sm is not None:
            oprot.writeFieldBegin('sm', TType.STRUCT, 3)
            self.sm.write(oprot)
            oprot.writeFieldEnd()
        if self.xs is not None:
            oprot.writeFieldBegin('xs', TType.STRUCT, 4)
            self.xs.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Card(object):
    """
    Attributes:
     - items
     - layoutType
     - columnSpan
     - rowSpan
     - itemGap
     - cardGridLayout
     - isEmpty
     - title
     - border
     - padding
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'items', (TType.STRUCT, (CardItem, CardItem.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'layoutType', (ResponsiveStateCardLayoutTypeSet, ResponsiveStateCardLayoutTypeSet.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'columnSpan', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'rowSpan', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'itemGap', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'cardGridLayout', (CardGridLayout, CardGridLayout.thrift_spec), None, ),  # 6
        (7, TType.BOOL, 'isEmpty', None, None, ),  # 7
        (8, TType.STRING, 'title', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'border', (ResponsiveStateBorder, ResponsiveStateBorder.thrift_spec), None, ),  # 9
        (10, TType.STRUCT, 'padding', (ResponsiveStatePadding, ResponsiveStatePadding.thrift_spec), None, ),  # 10
    )
    def __init__(self, items=None, layoutType=None, columnSpan=None, rowSpan=None, itemGap=None, cardGridLayout=None, isEmpty=None, title=None, border=None, padding=None, ):
        self.items = items
        self.layoutType = layoutType
        self.columnSpan = columnSpan
        self.rowSpan = rowSpan
        self.itemGap = itemGap
        self.cardGridLayout = cardGridLayout
        self.isEmpty = isEmpty
        self.title = title
        self.border = border
        self.padding = padding

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.items = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = CardItem()
                        _elem4.read(iprot)
                        self.items.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.layoutType = ResponsiveStateCardLayoutTypeSet()
                    self.layoutType.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.columnSpan = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.columnSpan.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.rowSpan = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.rowSpan.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.itemGap = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.itemGap.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.cardGridLayout = CardGridLayout()
                    self.cardGridLayout.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isEmpty = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.border = ResponsiveStateBorder()
                    self.border.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.padding = ResponsiveStatePadding()
                    self.padding.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Card')
        if self.items is not None:
            oprot.writeFieldBegin('items', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.items))
            for _iter6 in self.items:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.layoutType is not None:
            oprot.writeFieldBegin('layoutType', TType.STRUCT, 2)
            self.layoutType.write(oprot)
            oprot.writeFieldEnd()
        if self.columnSpan is not None:
            oprot.writeFieldBegin('columnSpan', TType.STRUCT, 3)
            self.columnSpan.write(oprot)
            oprot.writeFieldEnd()
        if self.rowSpan is not None:
            oprot.writeFieldBegin('rowSpan', TType.STRUCT, 4)
            self.rowSpan.write(oprot)
            oprot.writeFieldEnd()
        if self.itemGap is not None:
            oprot.writeFieldBegin('itemGap', TType.STRUCT, 5)
            self.itemGap.write(oprot)
            oprot.writeFieldEnd()
        if self.cardGridLayout is not None:
            oprot.writeFieldBegin('cardGridLayout', TType.STRUCT, 6)
            self.cardGridLayout.write(oprot)
            oprot.writeFieldEnd()
        if self.isEmpty is not None:
            oprot.writeFieldBegin('isEmpty', TType.BOOL, 7)
            oprot.writeBool(self.isEmpty)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 8)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.border is not None:
            oprot.writeFieldBegin('border', TType.STRUCT, 9)
            self.border.write(oprot)
            oprot.writeFieldEnd()
        if self.padding is not None:
            oprot.writeFieldBegin('padding', TType.STRUCT, 10)
            self.padding.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Grid(object):
    """
    Attributes:
     - cards
     - rowHeight
     - width
     - height
     - margin
     - numColumn
     - numRow
     - gridColumnGap
     - gridRowGap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'cards', (TType.STRUCT, (Card, Card.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'rowHeight', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'width', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'height', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'margin', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'numColumn', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'numRow', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'gridColumnGap', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'gridRowGap', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet.thrift_spec), None, ),  # 9
    )
    def __init__(self, cards=None, rowHeight=None, width=None, height=None, margin=None, numColumn=None, numRow=None, gridColumnGap=None, gridRowGap=None, ):
        self.cards = cards
        self.rowHeight = rowHeight
        self.width = width
        self.height = height
        self.margin = margin
        self.numColumn = numColumn
        self.numRow = numRow
        self.gridColumnGap = gridColumnGap
        self.gridRowGap = gridRowGap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.cards = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = Card()
                        _elem9.read(iprot)
                        self.cards.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.rowHeight = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.rowHeight.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.width = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.width.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.height = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.height.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.margin = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.margin.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.numColumn = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.numColumn.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.numRow = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.numRow.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.gridColumnGap = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.gridColumnGap.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.gridRowGap = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateStringValueSet()
                    self.gridRowGap.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Grid')
        if self.cards is not None:
            oprot.writeFieldBegin('cards', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.cards))
            for _iter11 in self.cards:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.rowHeight is not None:
            oprot.writeFieldBegin('rowHeight', TType.STRUCT, 2)
            self.rowHeight.write(oprot)
            oprot.writeFieldEnd()
        if self.width is not None:
            oprot.writeFieldBegin('width', TType.STRUCT, 3)
            self.width.write(oprot)
            oprot.writeFieldEnd()
        if self.height is not None:
            oprot.writeFieldBegin('height', TType.STRUCT, 4)
            self.height.write(oprot)
            oprot.writeFieldEnd()
        if self.margin is not None:
            oprot.writeFieldBegin('margin', TType.STRUCT, 5)
            self.margin.write(oprot)
            oprot.writeFieldEnd()
        if self.numColumn is not None:
            oprot.writeFieldBegin('numColumn', TType.STRUCT, 6)
            self.numColumn.write(oprot)
            oprot.writeFieldEnd()
        if self.numRow is not None:
            oprot.writeFieldBegin('numRow', TType.STRUCT, 7)
            self.numRow.write(oprot)
            oprot.writeFieldEnd()
        if self.gridColumnGap is not None:
            oprot.writeFieldBegin('gridColumnGap', TType.STRUCT, 8)
            self.gridColumnGap.write(oprot)
            oprot.writeFieldEnd()
        if self.gridRowGap is not None:
            oprot.writeFieldBegin('gridRowGap', TType.STRUCT, 9)
            self.gridRowGap.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
