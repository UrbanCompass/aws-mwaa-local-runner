import gen.urbancompass.customerprofile.ttypes as customer_ttypes
import gen.urbancompass.listing.listing.ttypes as listing_ttypes
import gen.urbancompass.profile.ttypes as profile_ttypes
import gen.urbancompass.user.agent_profile.ttypes as legacy_agent_ttypes
import gen.urbancompass.user.user.ttypes as legacy_user_ttypes


def from_legacy(agent_profile, user_id, email):
    """
    Convert a legacy agent profile object (a user object) to an Entity type. Since user id and
    email do not exist on the legacy profile, they must be provided separately.
    :param agent_profile: the thrift representation of the user object
    :type agent_profile: gen.urbancompass.user.agent_profile.ttypes.AgentProfile
    :param user_id: the user id of the agent
    :type user_id: basestring
    :param email: the email address of the agent
    :type email: basestring
    :return: a converted Entity
    :rtype: gen.urbancompass.profile.ttypes.Entity
    """
    return profile_ttypes.Entity(
        _id=user_id,
        firstName=agent_profile.first_name,
        lastName=agent_profile.last_name,
        displayName=agent_profile.first_name + " " + agent_profile.last_name,
        email=email,
        phone=agent_profile.phone,
        imagePath=agent_profile.image_path,
        agentProfile=profile_ttypes.AgentProfile(
            title=agent_profile.title,
            type=profile_ttypes.AgentProfileType.INDIVIDUAL,
            urlName=agent_profile.url_safe_name,
            externalId=agent_profile.external_id,
            profilePages=[
                profile_ttypes.AgentDisplayProfile(
                    geography=agent_profile.geography,
                    about=agent_profile.about,
                    aboutForPrint=agent_profile.about_for_print,
                    officePhone=agent_profile.office_phone,
                    isPublic=agent_profile.is_public,
                    revenue=agent_profile.revenue,
                    awards=agent_profile.awards,
                    press=agent_profile.press,
                    otherMedia=agent_profile.other_media,
                    specialties=agent_profile.specialties,
                    education=agent_profile.education,
                    charity=agent_profile.charity,
                    featuredProjects=[
                        profile_ttypes.AgentProfileFeaturedProject(
                            title=fp.title,
                            description=fp.description,
                            image=profile_ttypes.Image(
                                url=fp.picture.url,
                                altText=fp.picture.alt_text,
                                clickUrl=fp.picture.click_url,
                            )
                            if fp.picture is not None
                            else None,
                        )
                        for fp in agent_profile.featured_projects or []
                    ],
                    closedDeals=[
                        profile_ttypes.ClosedDeal(
                            listingIdSHA=cd.listingIdSHA,
                            hidePrice=cd.hidePrice,
                            disableLink=cd.disableLink,
                            priceOverride=cd.priceOverride,
                            inlineListing=listing_ttypes.Listing(
                                listingIdSHA=cd.listingIdSHA,
                                bedrooms=cd.inlineListing.bedrooms,
                                bathrooms=cd.inlineListing.bathrooms,
                                address=cd.inlineListing.address,
                                neighborhoods=cd.inlineListing.neighborhoods,
                                listingType=cd.inlineListing.listingType,
                                images=cd.inlineListing.images,
                            )
                            if cd.inlineListing is not None
                            else None,
                        )
                        for cd in agent_profile.closed_deal_info or []
                    ],
                    profileImage=profile_ttypes.Image(url=agent_profile.image_path),
                    displayPhone=agent_profile.phone,
                    displayEmail=email,
                    isActive=agent_profile.currently_at_uc,
                )
            ],
            leadsRoutingInformation=[
                profile_ttypes.LeadsRoutingCriteria(
                    geography=agent_profile.geography,
                    leadsEnabled=agent_profile.leads_enabled,
                    leadsRentalMin=agent_profile.leads_rental_min,
                    leadsRentalMax=agent_profile.leads_rental_max,
                    qualifiedNeighborhoods=agent_profile.qualified_neighborhoods,
                )
            ],
            individualProfile=profile_ttypes.IndividualAgent(teamEntityIds=[]),
        ),
    )


def to_legacy(entity, geography=None):
    """
    Convert an Entity to a legacy agent profile object. Note that this conversion may lose data: the
    legacy profile does not support agent teams or multiple agent profile pages.
    :param entity: an Entity profile type
    :type entity: gen.urbancompass.profile.ttypes.Entity
    :param geography: geography of the agent profile. If provided, will use only the profile page
        for the specified geography, if it exists.
    :type geography: basestring
    :return: a converted agent profile, or None if there is no such profile
    :rtype: gen.urbancompass.user.agent_profile.ttypes.AgentProfile
    """
    if entity is None or entity.agentProfile is None:
        return None
    agent_profile = entity.agentProfile
    # this is an arbitrary choice of the first profile
    all_profile_pages = [
        p
        for p in agent_profile.profilePages or []
        if (geography is None or p.geography == geography)
    ]
    if not all_profile_pages:
        return None
    profile_page = agent_profile.profilePages[0]

    all_leads_info = [
        l
        for l in agent_profile.leadsRoutingInformation or []
        if l.geography == profile_page.geography
    ]
    if not all_leads_info:
        leads_routing_info = profile_ttypes.LeadsRoutingCriteria()
    else:
        leads_routing_info = all_leads_info[0]

    return legacy_agent_ttypes.AgentProfile(
        url_safe_name=agent_profile.urlName,
        is_public=profile_page.isPublic,
        first_name=entity.firstName,
        last_name=entity.lastName,
        title=agent_profile.title,
        image_path=entity.imagePath,
        phone=entity.phone,
        office_phone=profile_page.officePhone,
        about=profile_page.about,
        revenue=profile_page.revenue,
        awards=profile_page.awards,
        press=profile_page.press,
        other_media=profile_page.otherMedia,
        specialties=profile_page.specialties,
        education=profile_page.education,
        charity=profile_page.charity,
        featured_projects=[
            legacy_agent_ttypes.AgentProfileFeaturedProjects(
                title=fp.title,
                description=fp.description,
                picture=legacy_agent_ttypes.AgentProfileImage(
                    url=fp.image.url, alt_text=fp.image.altText, click_url=fp.image.clickUrl
                )
                if fp.image is not None
                else None,
            )
            for fp in profile_page.featuredProjects or []
        ],
        closed_deal_info=[
            legacy_agent_ttypes.ClosedDealInfo(
                listingIdSHA=cd.listingIdSHA,
                hidePrice=cd.hidePrice,
                disableLink=cd.disableLink,
                priceOverride=cd.priceOverride,
                inlineListing=legacy_agent_ttypes.InlineListing(
                    bedrooms=cd.inlineListing.bedrooms,
                    bathrooms=cd.inlineListing.bathrooms,
                    address=cd.inlineListing.address,
                    neighborhoods=cd.inlineListing.neighborhoods,
                    listingType=cd.inlineListing.listingType,
                    images=cd.inlineListing.images,
                )
                if cd.inlineListing is not None
                else None,
            )
            for cd in profile_page.closedDeals or []
        ],
        qualified_neighborhoods=leads_routing_info.qualifiedNeighborhoods,
        currently_at_uc=profile_page.isActive,
        geography=profile_page.geography,
        external_id=agent_profile.externalId,
        about_for_print=profile_page.aboutForPrint,
        leads_enabled=leads_routing_info.leadsEnabled,
        leads_rental_min=leads_routing_info.leadsRentalMin,
        leads_rental_max=leads_routing_info.leadsRentalMax,
    )


def to_legacy_user(entity, geography=None, prefer_display_email=False):
    """
    Convert an Entity to a legacy agent profile object wrapped by a Thrift user. This user
    does not necessarily have to exist, nor does it contain the complete set of data that might
    exist for a user.  If the user is needed, clients must query it separately.
    :param entity: an Entity profile type
    :type entity: gen.urbancompass.profile.ttypes.Entity
    :param geography: geography of the agent profile. If provided, will use only the profile page
        for the specified geography, if it exists.
    :type geography: basestring
    :param prefer_display_email: whether we should use the displayEmail, if present.
    :return: a converted agent profile, or None if there is no such profile
    :rtype: gen.urbancompass.user.user.ttype.User
    """
    legacy_profile = to_legacy(entity, geography)

    if not legacy_profile:
        return None

    user = legacy_user_ttypes.User()
    user.agent_profile = legacy_profile
    user.id = entity._id
    user.email = entity.email
    if prefer_display_email:
        display_email = next(
            (
                p.displayEmail
                for p in entity.agentProfile.profilePages
                if p.displayEmail and (geography is None or p.geography == geography)
            ),
            None,
        )
        if display_email:
            user.email = display_email
    return user


def to_lead_profile(customer):
    """
    Convert a CustomerProfile object to an Entity object.
    :param customer_profile: a CustomerProfile object
    :type customer_profile: gen.urbancompass.customer_profile.ttypes.CustomerProfile
    :return: a converted LeadProfile object
    :rtype: gen.urbancompass.profile.ttypes.LeadProfile
    """
    return profile_ttypes.LeadProfile(
        customerInterestType=customer.customerInterestType,
        customerNotes=customer.customerNotes,
        preferredContactMethod=customer.preferredContactMethod,
        geographyPreferences=profile_ttypes.GeographyPreferences(
            selectedGeoId=customer.geographyPreferences.geographyAbbrev
        )
        if (customer.geographyPreferences is not None)
        else None,
        budget=customer.budget,
        phase=customer.phase,
        invitedBy=customer.invitedBy,
    )


def to_customer(entity):
    """
    Convert an Entity object to a CustomerProfile object.
    :param entity: an Entity object
    :type entity: gen.urbancompass.profile.ttypes.Entity
    :return: a converted CustomerProfile object
    :rtype: gen.urbancompass.customerprofile.ttypes.CustomerProfile
    """
    customer = customer_ttypes.CustomerProfile(
        userId=entity._id,
        firstName=entity.firstName,
        lastName=entity.lastName,
        email=entity.email,
        phoneNumber=entity.phone,
    )

    if entity.leadProfile is not None:
        customer.createdAt = entity.leadProfile.createdAt
        customer.updatedAt = entity.leadProfile.updatedAt
        customer.customerNotes = entity.leadProfile.customerNotes
        customer.emailPreferences = entity.leadProfile.emailPreferences
        customer.geographyPreferences = (
            customer_ttypes.GeographyPreferences(
                geographyAbbrev=entity.leadProfile.geographyPreferences.selectedGeoId
            )
            if (entity.leadProfile.geographyPreferences is not None)
            else None
        )
        customer.preferredContactMethod = entity.leadProfile.preferredContactMethod
        customer.customerInterestType = entity.leadProfile.customerInterestType
        customer.budget = entity.leadProfile.budget
        customer.phase = entity.leadProfile.phase
        customer.invitedBy = entity.leadProfile.invitedBy
        customer.channel = entity.leadProfile.customerChannel

    return customer


def to_agent_dict(entity):
    """
    Convert an Entity object to a dict with keys from the CustomerProfile object.
    :param entity: an Entity object
    :type entity: gen.urbancompass.profile.ttypes.Entity
    :return: a dict that looks like a CustomerProfile object
    :rtype: dict
    """
    return {
        "_id": entity._id,
        "userId": entity._id,
        "firstName": entity.firstName,
        "lastName": entity.lastName,
        "email": entity.email,
        "phoneNumber": entity.phone or "",
    }
