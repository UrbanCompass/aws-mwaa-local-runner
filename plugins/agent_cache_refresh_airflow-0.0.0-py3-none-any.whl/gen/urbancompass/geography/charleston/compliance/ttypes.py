
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class COMPLIANCE_TYPES(object):
    BASE = 0
    NO_ADDRESS_FOR_LOGGED_OUT_USER = 1
    HIDE_CONTACT_INFO_FOR_USERS = 2
    HIDE_HISTORY_FOR_LOGGED_OUT_USER = 3
    HIDE_HISTORY_FOR_LOGGED_IN_USER = 4
    CHARLESTON_HHIMLS_MLS_LOGO = 5

    _VALUES_TO_NAMES = {
        0: "BASE",
        1: "NO_ADDRESS_FOR_LOGGED_OUT_USER",
        2: "HIDE_CONTACT_INFO_FOR_USERS",
        3: "HIDE_HISTORY_FOR_LOGGED_OUT_USER",
        4: "HIDE_HISTORY_FOR_LOGGED_IN_USER",
        5: "CHARLESTON_HHIMLS_MLS_LOGO",
    }

    _NAMES_TO_VALUES = {
        "BASE": 0,
        "NO_ADDRESS_FOR_LOGGED_OUT_USER": 1,
        "HIDE_CONTACT_INFO_FOR_USERS": 2,
        "HIDE_HISTORY_FOR_LOGGED_OUT_USER": 3,
        "HIDE_HISTORY_FOR_LOGGED_IN_USER": 4,
        "CHARLESTON_HHIMLS_MLS_LOGO": 5,
    }

