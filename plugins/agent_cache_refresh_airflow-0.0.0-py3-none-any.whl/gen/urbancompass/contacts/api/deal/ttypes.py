
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals.constants.ttypes

from thrift.transport import TTransport


class MinimalDeal(object):
    """
    Attributes:
     - id
     - name
     - type
     - status
     - disposition
     - timeline
     - price
     - opportunityStageId
     - opportunityStageName
     - opportunityStageUpdateTime
     - opportunityStatus
     - transactionPhase
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I32, 'type', None, None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.I32, 'disposition', None, None, ),  # 5
        (6, TType.I64, 'timeline', None, None, ),  # 6
        (7, TType.DOUBLE, 'price', None, None, ),  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.STRING, 'opportunityStageId', 'UTF8', None, ),  # 100
        (101, TType.STRING, 'opportunityStageName', 'UTF8', None, ),  # 101
        (102, TType.I64, 'opportunityStageUpdateTime', None, None, ),  # 102
        (103, TType.I32, 'opportunityStatus', None, None, ),  # 103
        (104, TType.I32, 'transactionPhase', None, None, ),  # 104
    )
    def __init__(self, id=None, name=None, type=None, status=None, disposition=None, timeline=None, price=None, opportunityStageId=None, opportunityStageName=None, opportunityStageUpdateTime=None, opportunityStatus=None, transactionPhase=None, ):
        self.id = id
        self.name = name
        self.type = type
        self.status = status
        self.disposition = disposition
        self.timeline = timeline
        self.price = price
        self.opportunityStageId = opportunityStageId
        self.opportunityStageName = opportunityStageName
        self.opportunityStageUpdateTime = opportunityStageUpdateTime
        self.opportunityStatus = opportunityStatus
        self.transactionPhase = transactionPhase

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.disposition = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.timeline = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.price = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.STRING:
                    self.opportunityStageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 101:
                if ftype == TType.STRING:
                    self.opportunityStageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 102:
                if ftype == TType.I64:
                    self.opportunityStageUpdateTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 103:
                if ftype == TType.I32:
                    self.opportunityStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 104:
                if ftype == TType.I32:
                    self.transactionPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MinimalDeal')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 3)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.disposition is not None:
            oprot.writeFieldBegin('disposition', TType.I32, 5)
            oprot.writeI32(self.disposition)
            oprot.writeFieldEnd()
        if self.timeline is not None:
            oprot.writeFieldBegin('timeline', TType.I64, 6)
            oprot.writeI64(self.timeline)
            oprot.writeFieldEnd()
        if self.price is not None:
            oprot.writeFieldBegin('price', TType.DOUBLE, 7)
            oprot.writeDouble(self.price)
            oprot.writeFieldEnd()
        if self.opportunityStageId is not None:
            oprot.writeFieldBegin('opportunityStageId', TType.STRING, 100)
            oprot.writeString(self.opportunityStageId.encode('utf-8') if sys.version_info[0] == 2 else self.opportunityStageId)
            oprot.writeFieldEnd()
        if self.opportunityStageName is not None:
            oprot.writeFieldBegin('opportunityStageName', TType.STRING, 101)
            oprot.writeString(self.opportunityStageName.encode('utf-8') if sys.version_info[0] == 2 else self.opportunityStageName)
            oprot.writeFieldEnd()
        if self.opportunityStageUpdateTime is not None:
            oprot.writeFieldBegin('opportunityStageUpdateTime', TType.I64, 102)
            oprot.writeI64(self.opportunityStageUpdateTime)
            oprot.writeFieldEnd()
        if self.opportunityStatus is not None:
            oprot.writeFieldBegin('opportunityStatus', TType.I32, 103)
            oprot.writeI32(self.opportunityStatus)
            oprot.writeFieldEnd()
        if self.transactionPhase is not None:
            oprot.writeFieldBegin('transactionPhase', TType.I32, 104)
            oprot.writeI32(self.transactionPhase)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
