
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
FRESNO_COUNTY_NEIGHBORHOODS_FOR_CUSTOMER_SEARCH = [
]
HIGHER_LEVEL_NEIGHBORHOODS = [
]
KERN_COUNTY_NEIGHBORHOODS_FOR_CUSTOMER_SEARCH = [
]
KINGS_COUNTY_NEIGHBORHOODS_FOR_CUSTOMER_SEARCH = [
]
MADERA_COUNTY_NEIGHBORHOODS_FOR_CUSTOMER_SEARCH = [
]
NEIGHBORHOODS = [
]
TULARE_COUNTY_NEIGHBORHOODS_FOR_CUSTOMER_SEARCH = [
]
