# -*- coding: utf-8 -*-
"""
boto 3.X module that exports credentialed access to aws clients.

:copyright: (c) 2016 by Urban Compass, Inc.
"""

import logging

import boto3


# Lets disable non-critical boto3 logging.
logging.getLogger("boto3").setLevel(logging.CRITICAL)


# Let's cache all connections that don't have any passwords or roles or any arguments
# So we're not creating a dozen blank ones of these
_CACHED_CONNECTIONS = {}


DEFAULT_REGION = "us-east-1"


# boto 3.X
def client(
    client_type,
    aws_access_key_id=None,
    aws_secret_access_key=None,
    region_name=DEFAULT_REGION,
    use_iam_role=None,
    assume_role=None,
):
    """
    Create a Boto3 AWS client that uses the provided access keys to connect to the service

    This function uses caching to avoid making dozens of connections to the same service

    :param client_type: The type of connection to make (s3, ec2, events, etc)
    :param aws_access_key_id: The access key to use to connect
    :param aws_secret_access_key: The secret key to use to connect
    :param region_name: The name of the default AWS region for this client.
      The three above default to boto's default - which means to use the AWS_PROFILE if one is set,
      or the roles attached to the machine if any is provided.
    :param use_iam_role: IGNORED - kept for backwards compatibility.
    :param assume_role: ARN of AWS IAM role to assume via which to access resources.
    """
    user_credentials = {}
    if aws_access_key_id and aws_secret_access_key:
        user_credentials = {
            "aws_access_key_id": aws_access_key_id,
            "aws_secret_access_key": aws_secret_access_key,
        }

    cache_key = (
        client_type,
        user_credentials.get("aws_access_key_id", ""),
        user_credentials.get("aws_secret_access_key", ""),
        region_name,
    )

    # If this base connection already exists, return that base connection
    if cache_key in _CACHED_CONNECTIONS:
        return _CACHED_CONNECTIONS[cache_key]

    if assume_role and client_type == "secretsmanager":
        from uc.aws.assume_role import assume_role_session

        logging.info("Use assume role for Secrets Manager client: {}".format(assume_role))
        session = assume_role_session(assume_role, session_name="uc-aws-client-sessions")
        return session.client("secretsmanager")

    boto_client = boto3.client(client_type, region_name=region_name, **user_credentials)
    _CACHED_CONNECTIONS[cache_key] = boto_client
    return boto_client


# Note(ugo): the (deprecated) uc.fab.aws.client module monkey-patches client at import time.
# Since we want to test the one in this module, we keep one more reference to the original one
# in this module.
_uc_aws_client_for_test = client


def emr_client():
    return client("emr", None, None, use_iam_role=True)


def ec2_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("ec2", aws_access_key_id, aws_secret_access_key)


def elb_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("elb", aws_access_key_id, aws_secret_access_key)


def elasticache_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("elasticache", aws_access_key_id, aws_secret_access_key)


# cannot use the name lambda so renamed to lambda_client
def lambda_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("lambda", aws_access_key_id, aws_secret_access_key)


def events_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("events", aws_access_key_id, aws_secret_access_key)


def sns_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("sns", aws_access_key_id, aws_secret_access_key)


def rds_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("rds", aws_access_key_id, aws_secret_access_key)


def elastic_search_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("es", aws_access_key_id, aws_secret_access_key)


def cloudwatch_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("cloudwatch", aws_access_key_id, aws_secret_access_key)


def s3_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("s3", aws_access_key_id, aws_secret_access_key)


def athena_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("athena", aws_access_key_id, aws_secret_access_key)


def glue_client(aws_access_key_id=None, aws_secret_access_key=None):
    return client("glue", aws_access_key_id, aws_secret_access_key)


def secrets_client(assume_role=None):
    return client("secretsmanager", None, None, use_iam_role=True, assume_role=assume_role)


def iam_client():
    return client("iam", None, None, use_iam_role=True)


def org_client():
    return client("organizations", None, None, use_iam_role=True)


def sts_client():
    return client("sts", None, None, use_iam_role=True)


def cloudformation_client():
    return client("cloudformation", None, None, use_iam_role=True)


def route53_client():
    return client("route53", None, None, use_iam_role=True)


def cloudwatch_logs_client():
    return client("logs", None, None, use_iam_role=True)


def kafka_client():
    return client("kafka")
