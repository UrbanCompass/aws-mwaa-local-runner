
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
CITY_CLUSTER_ZOOM = 12
DEFAULT_CENTER_LATITUDE = 30.312
DEFAULT_CENTER_LONGITUDE = -81.658
DEFAULT_ZOOM = 11
FULL_DISPLAY_NAME = "Albany"
GEO_ID = "albany"
MAX_ZOOM = 18
MIN_ZOOM = 10
NEIGHBORHOOD_CLUSTER_ZOOM = 13
# else
SHORT_DISPLAY_NAME = "Albany"
# else
