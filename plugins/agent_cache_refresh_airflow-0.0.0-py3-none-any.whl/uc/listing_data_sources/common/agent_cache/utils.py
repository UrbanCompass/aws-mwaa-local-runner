import logging

from uc import json_thrift
from uc.profile.legacy_converter import to_legacy_user
from uc.listings_conversion.utilities.stats import conversionStatsD
from uc.listings_conversion.utilities.constants import INCREMENT_AMT

from gen.urbancompass.profile.service.ttypes import AgentProfileQuery
from gen.urbancompass.profile.service.ttypes import FindEntityProfilesRequest
from gen.urbancompass.people.service.ttypes import GetAgentsMlsMembershipsRequest
from gen.urbancompass.user.user.ttypes import User

statsd = conversionStatsD("agent_cache_manager").statsd


def get_refresh_func(profile_client, people_client, agent_cache_manager, cached_entities_dict):
    """
    Get refresh refresh function
    :param profile_client: obj, profile service GRPC client
    :param people_client: obj, people service GRPC client
    :param agent_cache_manager: obj, agent cache manager
    :param cached_entities_dict: dict of sets, existing entity_ids in dynamoDB seperated by geo_id
    :return: func, refresh function
    """

    def refresh_agents_by_geo(geo_id):
        """
        :param geo_id: str, geo location id
        :return: None
        """
        entities = get_entities(profile_client, geo_id)
        if entities == -1:
            statsd.count("entityService.failure.count", INCREMENT_AMT, tags={"geo_id": geo_id})
            return

        updated_count = 0
        people_service_set = set()

        for entity in entities:
            entity_id = entity._id

            # we delete all instances of this agent from the cache
            # because we do not know if this data is stale or not
            agent_cache_manager.delete(entity_id)

            try:
                people_service_set.add(entity_id)
                memberships = get_memberships(people_client, entity_id)
                if memberships == -1:
                    # problem fetching an agent's membership
                    statsd.count(
                        "membershipService.failure.count", INCREMENT_AMT, tags={"geo_id": geo_id}
                    )
                    memberships = {}
                memberships = sanitize_memberships(memberships)
                update_tables(agent_cache_manager, entity, memberships, geo_id)
                updated_count += 1
            except Exception:
                logging.exception(
                    "Not able to update agent data, entity._id: {}, geo_id: {}".format(
                        entity_id, geo_id
                    )
                )

        logging.info(
            "{}: Fetched {}, Updated {} agents".format(geo_id, len(entities), updated_count)
        )

        # Remove inactive agents
        # These agents are no longer a Compass Agent
        deleted_count = 0
        inactive_agents = cached_entities_dict.get(geo_id, set()) - people_service_set
        for agent_id in inactive_agents:
            deleted_count = agent_cache_manager.delete(agent_id)

        logging.info("Removed {} agents".format(deleted_count))

        datadog_tags = {"geo_id": geo_id}
        statsd.gauge("agent_cache_number_of_refreshed_agents", updated_count, tags=datadog_tags)
        statsd.gauge("agent_cache_number_of_deleted_agents", deleted_count, tags=datadog_tags)

    return refresh_agents_by_geo


class AgentIdTypes:
    LICENSE = 0
    MEMBERSHIP = 1
    ENTITY_ID = 2


def format_table_key(key, geo=None):
    if geo:
        delimiter = "_"
        return key + delimiter + geo
    return key


def format_agent_team_id(mls_id, source_feed_name):
    """For now, we assume the team id's format is "team_A00001_sf_rebaries\" """
    return "team_" + mls_id + "_" + source_feed_name


def update_tables(agent_cache_manager, entity, memberships, geo_id):
    entity_id = entity._id
    if entity.agentProfile.licenses:
        for license in entity.agentProfile.licenses:
            license_key = format_table_key(license.licenseNumber, license.stateCode)
            try:
                agent_cache_manager.update(
                    license_key, entity_id, AgentIdTypes.LICENSE, entity, geo_id
                )
            except Exception as e:
                statsd.count("license.update.failure.count", INCREMENT_AMT, tags={"geo_id": geo_id})
                raise e

    for membership in memberships:
        membership_key = format_table_key(
            membership["mlsMembershipId"], membership["mlsSourceFeed"]
        )
        try:
            agent_cache_manager.update(
                membership_key, entity_id, AgentIdTypes.MEMBERSHIP, entity, geo_id
            )
        except Exception as e:
            statsd.count("membership.update.failure.count", INCREMENT_AMT, tags={"geo_id": geo_id})
            raise e

    if entity.agentProfile.externalId:
        try:
            agent_cache_manager.update(
                entity.agentProfile.externalId, entity_id, AgentIdTypes.ENTITY_ID, entity, geo_id
            )
        except Exception as e:
            statsd.count("external_id.update.failure.count", INCREMENT_AMT, tags={"geo_id": geo_id})
            raise e


def get_entities(profile_client, geo_id):
    with profile_client as client:
        request = FindEntityProfilesRequest(
            agentProfileQuery=AgentProfileQuery(
                includeClosedDeals=False, isPublic=True, geography=geo_id
            )
        )
        response = client.findEntityProfiles(request)
        if response.status.code != 200:
            logging.exception(
                "Not able to fetch data from " "entity profile service: {}".format(response.status)
            )
            return -1
    return response.entities


def get_memberships(people_client, entity_id):
    with people_client as client:
        request = GetAgentsMlsMembershipsRequest(personId=entity_id)
        response = client.getPersonMlsMemberships(request)
        if response.status.code != 200:
            logging.exception(
                "Not able to fetch memberships from " "people service: {}".format(response.status)
            )
            return -1
    return response.memberships


def sanitize_memberships(memberships):
    # memberships will equal None if no memberships exist
    memberships_list = []
    if memberships:
        for member in memberships:
            member_dict = {
                "mlsSourceFeed": member.mlsSourceFeed,
                "mlsMembershipId": member.mlsMembershipId,
            }
            memberships_list.append(member_dict)
    return memberships_list


def to_converter_compatible_object(person_object):
    agent = to_legacy_user(person_object)

    # 'public' is a reserved word in Thrift, therefore this must be mapped to is_public
    is_public = getattr(agent.agent_profile, "public", None)
    agent_dict = json_thrift.thrift_to_dict(agent)
    if is_public is not None:
        del agent_dict["agent_profile"]["public"]
    if "channel" in agent_dict:
        agent_dict["channel"] = agent_dict["channel"].value

    res = json_thrift.jsondict_to_thrift(agent_dict, User())
    setattr(res, "startDate", person_object.agentProfile.startDateTime)
    if is_public is not None:
        res.agent_profile.is_public = is_public
    return res
