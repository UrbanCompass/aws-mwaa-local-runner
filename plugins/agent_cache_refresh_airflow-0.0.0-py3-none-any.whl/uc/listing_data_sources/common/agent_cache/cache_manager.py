# -*- coding: utf-8 -*-
"""
Refresh agent cache that is used by streaming pipeline.

:copyright: (c) 2019 by Urban Compass, Inc.
"""
import logging
import time
import boto3
from boto3.dynamodb.conditions import Key

from types import SimpleNamespace
from uc.base import app
from multiprocessing.dummy import Pool

from gen.urbancompass.listings_conversion.service.ttypes import AgentJoinKeyType
from gen.urbancompass.people.service.grpc import PeopleServiceStub
from gen.urbancompass.profile.constants import Entity
from gen.urbancompass.profile.service.grpc import ProfileServiceStub

from uc import json_thrift
from uc.grpc.grpc_client2 import GrpcClient2
from uc.listing_data_sources.common import utils
from uc.listings_conversion.utilities.constants import INCREMENT_AMT
from uc.listings_conversion.utilities.stats import conversionStatsD
from uc.listing_data_sources.common.agent_cache.utils import (
    get_refresh_func,
    format_table_key,
    to_converter_compatible_object,
    format_agent_team_id,
    AgentIdTypes,
)

from gen.urbancompass.geography.geos import constants


statsd = conversionStatsD("agent_cache_manager").statsd

DEFAULT_REGION = "us-east-1"

# we exclude seattle because seattle only sends us mls_memberships
# therefore, we don't want seattle to trigger our
# joining logic for licenses
EXCLUDE_FROM_LICENSE_MATCH = ["seattle_nwmls"]


class RefreshAgentCache(object):
    def __init__(self, app_options, options):
        self.app_options = app_options
        self.options = options

    def get_profile_entity_client(self):
        return GrpcClient2(
            ProfileServiceStub, self.options.entity_profile_service_hostport[len("grpc://"):]
        )

    def get_people_service_client(self):
        return GrpcClient2(
            PeopleServiceStub, self.options.people_service_hostport[len("grpc://"):]
        )

    def main(self):
        start_time = time.time()

        logging.info("app_options: ")
        logging.info(self.app_options)

        logging.info("options: ")
        logging.info(self.options)

        # factory = utils.get_rpc_client_factory(self.app_options)
        profile_client = self.get_profile_entity_client()
        people_client = self.get_people_service_client()

        num_processes = int(self.options.num_processes)
        agent_cache_manager = AgentCacheManager.get_instance(self.options.agent_cache_table_name)

        pool = Pool(num_processes)
        geo_ids = [getattr(constants, key) for key in dir(constants) if key.endswith("_GEO_ID")]

        cached_entities_dict = {}
        cached_entities = agent_cache_manager.list()
        statsd.count("dynamo.object.count", len(cached_entities))

        for entity in cached_entities:
            geo_id = entity.get("geo_id", None)
            if geo_id:
                entity_id = entity["entity_id"]
                if not cached_entities_dict.get(geo_id):
                    cached_entities_dict[geo_id] = {entity_id}
                else:
                    cached_entities_dict[geo_id].add(entity_id)
        with statsd.timed("refresh_agent_cache.duration"):
            # we use geo_id as a means to run concurrently, but we don't actually use the value of geo_id
            pool.map(
                get_refresh_func(
                    profile_client, people_client, agent_cache_manager, cached_entities_dict
                ),
                geo_ids,
            )
        logging.info("--- %s seconds ---" % (time.time() - start_time))


class AgentCacheManager(object):
    """
    A class that interacts with agent cache in DynamoDB.
    We implemented it as a singleton because we want to to avoid
    `Can't pickle thread.lock object` caused by boto3.resource()
    """

    __instances = {}

    @staticmethod
    def get_instance(table_name):
        logging.info("Table_name is : {}".format(table_name))
        if table_name not in AgentCacheManager.__instances:
            AgentCacheManager(table_name)
        return AgentCacheManager.__instances[table_name]

    def __init__(self, table_name):
        if table_name in AgentCacheManager.__instances:
            raise Exception("This class is a singleton")
        else:
            self.table = boto3.resource("dynamodb", region_name=DEFAULT_REGION).Table(table_name)
            AgentCacheManager.__instances[table_name] = self

    def update(self, agent_id, entity_id, key_type, entity_object, geo_id):
        """
        Update agent data in cache or create a new entry if it doesn't exist
        :param agent_id: str, an agent id (can be license, membership, or external id)
        :param entity_id: str obj, an agent's user_id (how they are represented in PeopleService)
        :param key_type: str, denotes whether agent_id is a license, membership, or external_id
        :param entity_object: thrift obj, an entity object
        :param geo_id: str, a geo_id that corresponds to the sharding of how we query PeopleService
        :return: None
        """
        self.table.update_item(
            Key={"agent_id": agent_id},
            UpdateExpression="SET entity_id = :entity_id, key_type = :key_type, "
            "agent_json = :agent_json, geo_id = :geo_id",
            ExpressionAttributeValues={
                ":entity_id": entity_id,
                ":key_type": key_type,
                ":agent_json": json_thrift.thrift_to_json(entity_object),
                ":geo_id": geo_id,
            },
        )

    def get(self, mris_id, geo=None):
        """
        Get agent data in cache or return None if it doesn't exist
        :param mris_id: str, an agent id (can be license, membership, or external id)
        :param geo: str obj, an stateCode (license) or source_feed_name (Membership)
        :return: An agent in agent cache, or None if not exists
        """
        agent_id = format_table_key(mris_id, geo)
        result = self.table.get_item(Key={"agent_id": agent_id})
        return result["Item"] if "Item" in result else None

    def list(self):
        """
        List all agent entity objects filtered by geo id
        :return: A list of entity_ids or [] if key not exists
        """
        response = self.table.scan(ProjectionExpression="entity_id, geo_id")
        data = response["Items"]
        while "LastEvaluatedKey" in response:
            response = self.table.scan(
                ProjectionExpression="entity_id, geo_id",
                ExclusiveStartKey=response["LastEvaluatedKey"],
            )
            data = data + response["Items"]
        return data

    def delete(self, entity_id):
        """
        Delete an agent entity object by entity_id
        :param entity_id: str, an agent user id
        :return: int: count of total deletions
        """
        result = self.table.query(
            ProjectionExpression="agent_id",
            IndexName="entity_id-index",
            KeyConditionExpression=Key("entity_id").eq(entity_id),
        )
        deleted_count = 0
        if "Items" in result:
            for item in result["Items"]:
                if item and item.get("agent_id"):
                    response = self.table.delete_item(Key={"agent_id": item["agent_id"]})
                    if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
                        deleted_count += 1
        return deleted_count

    def get_entity(self, entity_id):
        """
        Retrieve agent entity object by entity id
        :param entity_id: str, an agent user id
        :return: An entity object or None if key not exists
        """
        result = self.table.query(
            IndexName="entity_id-index", KeyConditionExpression=Key("entity_id").eq(entity_id)
        )
        if "Items" in result and len(result["Items"]) > 0:
            agent_json = result["Items"][0].get("agent_json")
        else:
            agent_json = None
        if agent_json:
            return json_thrift.json_to_thrift(agent_json, Entity())

    def get_matching_license(self, agent_id, state_code):
        license = self.get(agent_id, state_code)
        if license and license.get("key_type") == AgentJoinKeyType.LICENSE:
            return license.get("entity_id")
        return None

    def get_matching_membership(self, agent_id, source_feed_name):
        membership = self.get(agent_id, source_feed_name)
        if membership and membership.get("key_type") == AgentJoinKeyType.MEMBERSHIP:
            return membership.get("entity_id")
        return None

    def get_matching_external_id(self, agent_id, geo_id):
        external_id = self.get(agent_id)
        if (
            external_id
            and external_id.get("geo_id") == geo_id
            and external_id.get("key_type") == AgentJoinKeyType.EXTERNAL
        ):
            return external_id.get("entity_id")
        return None

    def get_agent_entity_id(self, identifier, suffix, key_type, geo_id=None):
        agent_info = self.get(identifier, suffix)
        if (
            agent_info
            and agent_info.get("key_type") == key_type
            and (not geo_id or agent_info.get("geo_id") == geo_id)
        ):
            return agent_info.get("entity_id")
        return None

    def get_matching_entity_id_by_license_number(self, license, listing, source_feed_name):
        """
        :param license: str, a license number that we get from raw_listings
        :param listing: obj, a listing object
        :param source_feed_name: str, e.g. atlanta_fmls
        :return: entity_id: str, a uuid that corresponds to an agent
        """
        if not license:
            return None

        state_code = listing.state
        if state_code:
            entity_id = self.get_agent_entity_id(license, state_code, AgentJoinKeyType.LICENSE)
            if entity_id:
                logging.info(
                    "Matched License Key on Agent Cache: {}".format(
                        format_table_key(license, state_code)
                    )
                )
                statsd.count(
                    "matched_license.count",
                    INCREMENT_AMT,
                    tags={"source_feed_name": source_feed_name},
                )
                return entity_id

        logging.info("No license match on Agent Cache. License #:{}".format(license))
        statsd.count(
            "no_match.count",
            INCREMENT_AMT,
            tags={"source_feed_name": source_feed_name, "match_by": "license"},
        )

        return None

    def get_matching_entity_id_by_mls_id(self, mls_id, source_feed_name):
        """
        :param mls_id: str, an agent_id that we get from raw_listings
        :param source_feed_name: str, e.g. atlanta_fmls
        :return: entity_id: str, a uuid that corresponds to an agent
        """
        if not mls_id:
            return None

        if source_feed_name:
            entity_id = self.get_agent_entity_id(
                mls_id, source_feed_name, AgentJoinKeyType.MEMBERSHIP
            )
            if entity_id:
                logging.info(
                    "Matched Membership Key on Non Compass Agent Cache: {}".format(
                        format_table_key(mls_id, source_feed_name)
                    )
                )
                statsd.count(
                    "matched_membership.count",
                    INCREMENT_AMT,
                    tags={"source_feed_name": source_feed_name},
                )
                return entity_id

        logging.info("No MlsId match on Agent Cache. MlsId:{}".format(mls_id))
        statsd.count(
            "no_match.count",
            INCREMENT_AMT,
            tags={"source_feed_name": source_feed_name, "match_by": "mlsId"},
        )

        return None

    def get_matching_entity_id_by_external_id(self, external_id, geo_id, source_feed_name):
        """
        :param external_id: str, external id
        :param geo_id: str, geo id
        :param source_feed_name: str, e.g. atlanta_fmls
        :return: entity_id: str, a uuid that corresponds to an agent
        """
        if not external_id or not geo_id:
            return None

        entity_id = self.get_agent_entity_id(external_id, None, AgentJoinKeyType.EXTERNAL, geo_id)
        if entity_id:
            logging.info(
                "Matched ExternalId on Agent Cache: {}".format(format_table_key(external_id))
            )
            statsd.count(
                "matched_externalId.count",
                INCREMENT_AMT,
                tags={
                    "source_feed_name": source_feed_name,
                },
            )
            return entity_id
        logging.info(
            "No email match on Agent Cache. ExternalId:{}, Geo:{}".format(external_id, geo_id)
        )
        statsd.count(
            "no_match.count",
            INCREMENT_AMT,
            tags={"source_feed_name": source_feed_name, "match_by": "externalId"},
        )

        return None

    def get_matching_team_mls_id_to_entity_id(self, mls_id, source_feed_name):
        if source_feed_name:
            agent_id = format_agent_team_id(mls_id, source_feed_name)

            matched_agent_object = self.get(agent_id)
            if (
                matched_agent_object
                and matched_agent_object.get("key_type") == AgentIdTypes.ENTITY_ID
            ):
                entity_id = matched_agent_object.get("entity_id")
                if entity_id:
                    logging.info("Matched agent team MLS id in Agent Cache: {}".format(agent_id))
                    statsd.count(
                        "matched_agent_team_MLS.count",
                        INCREMENT_AMT,
                        tags={"source_feed_name": source_feed_name},
                    )
                    return entity_id

        logging.info("agent team mls id no match: {}".format(agent_id))
        statsd.count(
            "no_match_agent_team_MLS.count",
            INCREMENT_AMT,
            tags={"source_feed_name": source_feed_name},
        )

        return None

    def get_matching_mris_id_to_entity_id(self, mris_id, listing, geo_id, source_feed_name):
        """
        Because a raw_listing provides agents and their mris_id (agent_id), we
        don't know if this mris_id corresponds to a license match, a membership match, or
        an external_id match with our respective people_cache. We do a best guess here
        based off license, then membership, then external_id in that order.
        :param mris_id: str, an agent_id that we get from raw_listings
        :param listing: obj, a listing object
        :param geo_id: str, e.g. atlanta
        :param source_feed_name: str, e.g. atlanta_fmls
        :return: entity_id: str, a uuid that corresponds to an agent
        """
        state_code = listing.state
        if state_code and source_feed_name not in EXCLUDE_FROM_LICENSE_MATCH:
            entity_id = self.get_matching_license(mris_id, state_code)
            logging.info(
                "Matched License Key on Agent Cache: {}".format(
                    format_table_key(mris_id, state_code)
                )
            )
            statsd.count(
                "matched_license.count", INCREMENT_AMT, tags={"source_feed_name": source_feed_name}
            )
            if entity_id:
                return entity_id

        if source_feed_name:
            entity_id = self.get_matching_membership(mris_id, source_feed_name)
            if entity_id:
                logging.info(
                    "Matched Membership Key on Agent Cache: {}".format(
                        format_table_key(mris_id, source_feed_name)
                    )
                )
                statsd.count(
                    "matched_membership.count",
                    INCREMENT_AMT,
                    tags={"source_feed_name": source_feed_name},
                )
                return entity_id

        entity_id = self.get_matching_external_id(mris_id, geo_id)
        if entity_id:
            # Under ideal conditions no agents should match based on external ID.
            # Currently we log both agent and team matches as a warning,
            # to maintain an easily accessible audit log in DataDog.
            logging.warn("Matched ExternalId on Agent Cache: {}".format(mris_id))
            statsd.count(
                "matched_externalId.count",
                INCREMENT_AMT,
                tags={
                    "source_feed_name": source_feed_name,
                },
            )
            return entity_id

        logging.info("No match on Agent Cache: {}".format(mris_id))
        statsd.count(
            "no_match.count",
            INCREMENT_AMT,
            tags={
                "source_feed_name": source_feed_name,
            },
        )
        return None

    def get_agent_json(self, mris_id, listing, source_feed_name):
        state_code = listing.state

        license = self.get(mris_id, state_code)
        if license:
            return license.get("agent_json")

        membership = self.get(mris_id, source_feed_name)
        if membership:
            return membership.get("agent_json")

        external_id = self.get(mris_id)
        if external_id:
            return external_id.get("agent_json")
        return None

    def get_user_object_by_mris_id(self, mris_id, listing, source_feed_name):
        """
        Retrieve agent as a user object by mris id
        :param mris_id: str, an agent external id
        :param listing: obj, a listing obj
        :param source_feed_name: str, source_feed_name
        :return: An user object or None if key not exists
        """
        agent_json = self.get_agent_json(mris_id, listing, source_feed_name)
        if agent_json:
            agent_json = to_converter_compatible_object(
                json_thrift.json_to_thrift(agent_json, Entity())
            )
            statsd.count("get_user_object.success", INCREMENT_AMT)
            return agent_json
        statsd.count("get_user_object.fail", INCREMENT_AMT)
        return None

    def get_team_profile(self, entity_id):
        entity = self.get_entity(entity_id)
        if entity and entity.agentProfile and entity.agentProfile.teamProfile:
            return entity.agentProfile.teamProfile
        return None


def run_agent_cache_refresh_job(
    num_processes=8,
    agent_cache_table_name="development-agent-cache",
    people_service_hostport="grpc://peopleserver.grpc.dev.na.compass.com:31337",
    entity_profile_service_hostport="grpc://peopleserver.grpc.gamma.na.compass.com:80",
):
    args = {
        "num_processes": num_processes,
        "agent_cache_table_name": agent_cache_table_name,
        "people_service_hostport": people_service_hostport,
        "entity_profile_service_hostport": entity_profile_service_hostport,
    }

    job_options = SimpleNamespace(**args)

    app.run(lambda options, args: RefreshAgentCache(options, job_options).main())
