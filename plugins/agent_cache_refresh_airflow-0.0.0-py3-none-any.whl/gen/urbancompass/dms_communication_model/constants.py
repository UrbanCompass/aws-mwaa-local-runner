
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
DEFAULT_VERB = "updated"
DIFF_IGNORE_KEYS = set((
    "createdAt",
    "createdBy",
    "updatedAt",
    "updatedBy",
    "submittedByAgentMasterDataId",
    "submittedById",
    "submittedByName",
    "submittedAt",
))
ENRICH_FOLDER_FIELD_TO_PRETTY_FIELD_NAME_MAP = {
    0: "Staff Group",
}
KEY_FORMAT_MAP = {
    "propertyType": 5,
    "isNewConstruction": 2,
    "usedConcierge": 2,
    "commissionRate": 4,
    "currentSubStage": 7,
    "yearlyRent": 3,
    "contractGrossAmount": 3,
    "useDefaultAgentSplitPercent": 2,
}
PRETTY_FIELD_NAME_MAP = {
    "currentSubStage": "Document Review Stage",
    "staffGroupId": "Staff Group",
}
RESOURCE_TYPE_NAME_MAP = {
    0: "Document",
    1: "Commission",
    2: "Checklist Item",
    3: "Listing",
    4: "Offer",
    5: "Deal",
    6: "Packet",
    7: "Manual Log Entry",
    8: "Notification",
    9: "Agent",
}
SHORT_LOG_VERBS = {
    0: "added",
    1: "amended",
    2: "removed",
    16: "withdrew",
    17: "cancelled",
    5: "uploaded",
    9: "approved",
    8: "commented",
    10: "rejected",
    13: "unapproved",
    14: "unrejected",
    11: "shared",
    12: "unshared",
    15: "split",
    18: "sent",
    19: "drafted",
}
