
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class ResponsiveStateBoolValueSet(object):
    """
    Attributes:
     - lg
     - md
     - sm
     - xs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'lg', None, None, ),  # 1
        (2, TType.BOOL, 'md', None, None, ),  # 2
        (3, TType.BOOL, 'sm', None, None, ),  # 3
        (4, TType.BOOL, 'xs', None, None, ),  # 4
    )
    def __init__(self, lg=None, md=None, sm=None, xs=None, ):
        self.lg = lg
        self.md = md
        self.sm = sm
        self.xs = xs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.lg = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.md = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.sm = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.xs = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponsiveStateBoolValueSet')
        if self.lg is not None:
            oprot.writeFieldBegin('lg', TType.BOOL, 1)
            oprot.writeBool(self.lg)
            oprot.writeFieldEnd()
        if self.md is not None:
            oprot.writeFieldBegin('md', TType.BOOL, 2)
            oprot.writeBool(self.md)
            oprot.writeFieldEnd()
        if self.sm is not None:
            oprot.writeFieldBegin('sm', TType.BOOL, 3)
            oprot.writeBool(self.sm)
            oprot.writeFieldEnd()
        if self.xs is not None:
            oprot.writeFieldBegin('xs', TType.BOOL, 4)
            oprot.writeBool(self.xs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponsiveStateIntegerValueSet(object):
    """
    Attributes:
     - lg
     - md
     - sm
     - xs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I16, 'lg', None, None, ),  # 1
        (2, TType.I16, 'md', None, None, ),  # 2
        (3, TType.I16, 'sm', None, None, ),  # 3
        (4, TType.I16, 'xs', None, None, ),  # 4
    )
    def __init__(self, lg=None, md=None, sm=None, xs=None, ):
        self.lg = lg
        self.md = md
        self.sm = sm
        self.xs = xs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I16:
                    self.lg = iprot.readI16()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I16:
                    self.md = iprot.readI16()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I16:
                    self.sm = iprot.readI16()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I16:
                    self.xs = iprot.readI16()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponsiveStateIntegerValueSet')
        if self.lg is not None:
            oprot.writeFieldBegin('lg', TType.I16, 1)
            oprot.writeI16(self.lg)
            oprot.writeFieldEnd()
        if self.md is not None:
            oprot.writeFieldBegin('md', TType.I16, 2)
            oprot.writeI16(self.md)
            oprot.writeFieldEnd()
        if self.sm is not None:
            oprot.writeFieldBegin('sm', TType.I16, 3)
            oprot.writeI16(self.sm)
            oprot.writeFieldEnd()
        if self.xs is not None:
            oprot.writeFieldBegin('xs', TType.I16, 4)
            oprot.writeI16(self.xs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponsiveStateStringValueSet(object):
    """
    Attributes:
     - lg
     - md
     - sm
     - xs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'lg', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'md', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'sm', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'xs', 'UTF8', None, ),  # 4
    )
    def __init__(self, lg=None, md=None, sm=None, xs=None, ):
        self.lg = lg
        self.md = md
        self.sm = sm
        self.xs = xs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.lg = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.md = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.sm = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.xs = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponsiveStateStringValueSet')
        if self.lg is not None:
            oprot.writeFieldBegin('lg', TType.STRING, 1)
            oprot.writeString(self.lg.encode('utf-8') if sys.version_info[0] == 2 else self.lg)
            oprot.writeFieldEnd()
        if self.md is not None:
            oprot.writeFieldBegin('md', TType.STRING, 2)
            oprot.writeString(self.md.encode('utf-8') if sys.version_info[0] == 2 else self.md)
            oprot.writeFieldEnd()
        if self.sm is not None:
            oprot.writeFieldBegin('sm', TType.STRING, 3)
            oprot.writeString(self.sm.encode('utf-8') if sys.version_info[0] == 2 else self.sm)
            oprot.writeFieldEnd()
        if self.xs is not None:
            oprot.writeFieldBegin('xs', TType.STRING, 4)
            oprot.writeString(self.xs.encode('utf-8') if sys.version_info[0] == 2 else self.xs)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
