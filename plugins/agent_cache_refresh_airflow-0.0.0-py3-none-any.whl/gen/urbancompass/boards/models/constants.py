
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
LISTING_ADDED_BY_UNRESOLVED_ENTITY = "unresolvedEntity"
VALID_INITIAL_REVIEW_STAGES = [
    0,
    2,
    1,
]
