
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class CustomFieldType(object):
    BOOLEAN = 0
    DATE = 1
    DECIMAL = 2
    DROPDOWN = 3
    TEXTAREA = 4
    TEXTFIELD = 5

    _VALUES_TO_NAMES = {
        0: "BOOLEAN",
        1: "DATE",
        2: "DECIMAL",
        3: "DROPDOWN",
        4: "TEXTAREA",
        5: "TEXTFIELD",
    }

    _NAMES_TO_VALUES = {
        "BOOLEAN": 0,
        "DATE": 1,
        "DECIMAL": 2,
        "DROPDOWN": 3,
        "TEXTAREA": 4,
        "TEXTFIELD": 5,
    }


class GetCustomFieldsOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3
    NAME_ASC = 4
    NAME_DESC = 5
    ID_ASC = 6
    ID_DESC = 7

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
        4: "NAME_ASC",
        5: "NAME_DESC",
        6: "ID_ASC",
        7: "ID_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
        "NAME_ASC": 4,
        "NAME_DESC": 5,
        "ID_ASC": 6,
        "ID_DESC": 7,
    }


class CustomField(object):
    """
    Attributes:
     - id
     - createdAt
     - updatedAt
     - defaultValue
     - dropdownOptions
     - name
     - type
     - createdByCrmUserId
     - friendlyType
     - usageCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.STRING, 'defaultValue', 'UTF8', None, ),  # 4
        (5, TType.LIST, 'dropdownOptions', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRING, 'name', 'UTF8', None, ),  # 6
        (7, TType.I32, 'type', None, None, ),  # 7
        (8, TType.STRING, 'createdByCrmUserId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'friendlyType', 'UTF8', None, ),  # 9
        (10, TType.I32, 'usageCount', None, None, ),  # 10
    )
    def __init__(self, id=None, createdAt=None, updatedAt=None, defaultValue=None, dropdownOptions=None, name=None, type=None, createdByCrmUserId=None, friendlyType=None, usageCount=None, ):
        self.id = id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.defaultValue = defaultValue
        self.dropdownOptions = dropdownOptions
        self.name = name
        self.type = type
        self.createdByCrmUserId = createdByCrmUserId
        self.friendlyType = friendlyType
        self.usageCount = usageCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.defaultValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dropdownOptions = []
                    (_etype129, _size132) = iprot.readListBegin()
                    for _i130 in range(_size132):
                        _elem131 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dropdownOptions.append(_elem131)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.createdByCrmUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.friendlyType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.usageCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CustomField')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.defaultValue is not None:
            oprot.writeFieldBegin('defaultValue', TType.STRING, 4)
            oprot.writeString(self.defaultValue.encode('utf-8') if sys.version_info[0] == 2 else self.defaultValue)
            oprot.writeFieldEnd()
        if self.dropdownOptions is not None:
            oprot.writeFieldBegin('dropdownOptions', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.dropdownOptions))
            for _iter144 in self.dropdownOptions:
                oprot.writeString(_iter144.encode('utf-8') if sys.version_info[0] == 2 else _iter144)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 6)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 7)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.createdByCrmUserId is not None:
            oprot.writeFieldBegin('createdByCrmUserId', TType.STRING, 8)
            oprot.writeString(self.createdByCrmUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByCrmUserId)
            oprot.writeFieldEnd()
        if self.friendlyType is not None:
            oprot.writeFieldBegin('friendlyType', TType.STRING, 9)
            oprot.writeString(self.friendlyType.encode('utf-8') if sys.version_info[0] == 2 else self.friendlyType)
            oprot.writeFieldEnd()
        if self.usageCount is not None:
            oprot.writeFieldBegin('usageCount', TType.I32, 10)
            oprot.writeI32(self.usageCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CustomFieldValue(object):
    """
    Attributes:
     - id
     - fieldId
     - name
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'fieldId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'name', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'value', 'UTF8', None, ),  # 4
    )
    def __init__(self, id=None, fieldId=None, name=None, value=None, ):
        self.id = id
        self.fieldId = fieldId
        self.name = name
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.fieldId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CustomFieldValue')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.fieldId is not None:
            oprot.writeFieldBegin('fieldId', TType.STRING, 2)
            oprot.writeString(self.fieldId.encode('utf-8') if sys.version_info[0] == 2 else self.fieldId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 3)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 4)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
