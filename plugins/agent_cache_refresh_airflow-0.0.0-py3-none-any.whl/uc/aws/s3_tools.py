# -*- coding: utf-8 -*-
"""
Tools for interacting with s3 in a Urban Compass structured way.

:copyright: (c) 2013 by Urban Compass, Inc.
"""

# TODO (Brian): Let's put this someplace more sensible than uc/ ...

from contextlib import contextmanager
import functools
from glob import fnmatch
import logging
import math
from multiprocessing.dummy import Pool

import itertools
import os
import tempfile
import threading
import traceback
import weakref

import boto
import boto3
from botocore.exceptions import ClientError

from filechunkio import FileChunkIO
from datetime import datetime

_DEFAULT_AWS_S3_HOST = "s3.amazonaws.com"


def _progress(x, y):
    logging.info("Progress %s/%s", x, y)
    return


def _log_on_error(f):
    """Decorator that logs to error if there is an error."""

    @functools.wraps(f)
    def g(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception:
            logging.error("Error in call to %s(*%.1000r, **%.1000r)", f.__name__, args, kwargs)
            raise

    return g


class _S3ConnectorBase(object):
    """Shared implementation of some *S3Connector methods."""

    @classmethod
    def split(cls, s3name, prefix="s3://"):
        """extract from an s3 name the bucket, key names.

        i.e. .split("s3://a/b/c/d") == ["a", "b/c/d"]
        """
        if not s3name.startswith(prefix):
            raise AssertionError("%r does not start with prefix %r" % (s3name, prefix))
        splits = s3name[len(prefix) :].split("/", 1)
        return splits[0], splits[1] if len(splits) > 1 else ""

    @contextmanager
    def temp_copy_of_s3_file(self, s3name, tmp_prefix="tmp", dir=None):
        """A contextmanager that creates a local copy of an s3 file and then deletes it.

        Notice that modifications to the local copy are not propagated back to s3.
        Use as:
          with conn.temp_copy_of_s3_file(s3name) as fname:
            # do stuff with fname
          # now fname has been deleted.
        """
        with tempfile.NamedTemporaryFile(
            suffix=os.path.basename(s3name), prefix=tmp_prefix, dir=dir
        ) as tmpfile:
            localname = tmpfile.name
            logging.info("s3_tools creating temp file for download %s", localname)
            self.download(s3name, localname)
            try:
                yield localname
            except:
                logging.exception("Caught exception")
                raise
            logging.info("Deleting %s", localname)

    @contextmanager
    def temp_file_destined_to_s3(self, s3name, tmp_prefix="tmp", multipart_upload=False, dir=None):
        """A contextmanager that creates a local file name, and on __exit__ copies that file to s3.

        Notice that this will overwrite the file in s3name (if any).
        Use as:
          with conn.temp_file_destined_to_s3(s3name) as fname:
            # put stuff inside fname
          # now fname has been deleted and if there was no exception its content was copied to s3.
        """
        with tempfile.NamedTemporaryFile(
            suffix=os.path.basename(s3name), prefix=tmp_prefix, dir=dir
        ) as tmpfile:
            localname = tmpfile.name
            logging.info("s3_tools creating temp file for upload %s", localname)
            try:
                yield localname
            except:
                logging.exception("Caught exception")
                raise
            self.upload(s3name, localname, multipart_upload=multipart_upload)
            logging.info("Deleting %s", localname)


class S3Connector(_S3ConnectorBase):
    """DEPRECATED - use Boto3S3Connector instead; A class for connecting to s3."""

    def __init__(self, access_key=None, secret_key=None, encrypt=False):
        print(
            "WARNING - your code uses the deprecated S3Connector class - you should migrate it to use "
            "ONLY Boto3S3Connector. This is how S3Connector was imported:"
        )
        traceback.print_stack()

        self._access_key = access_key
        self._secret_key = secret_key
        self._encrypt = encrypt
        self._s3_connection = None

    def s3(self):
        if not self._s3_connection:
            self._s3_connection = boto.connect_s3(
                self._access_key, self._secret_key, host="s3.amazonaws.com"
            )
        return self._s3_connection

    @_log_on_error
    def get_s3_bucket(self, bucket):
        conn = self.s3()
        bucket = conn.get_bucket(bucket)
        return bucket

    @_log_on_error
    def get_s3_key(self, s3name):
        """Get the s3 key for a s3 "url"."""
        bucket_name, key_name = self.split(s3name)
        bucket = self.get_s3_bucket(bucket_name)
        key = boto.s3.key.Key(bucket=bucket, name=key_name)
        return key

    @_log_on_error
    def load_s3_key(self, s3name):
        """Load the s3 key with metadata for a s3 "url"."""
        key = self.get_s3_key(s3name)
        key.open()
        key.close(fast=True)
        return key

    @_log_on_error
    def list(self, s3prefix, file_pattern=None):
        """List s3 files with a given prefix.

        :param s3prefix: prefix of the S3 path; must be plain text.
        :param file_pattern: string pattern of the requested file names (file basename containing no
                             directory; Can contain wildcards *, ?, as per fnmatch.
        """
        conn = self.s3()
        bucket_name, prefix = self.split(s3prefix)
        bucket = conn.get_bucket(bucket_name)
        res = (
            "s3://%s/%s" % (bucket_name, i.name) for i in bucket.list(prefix=prefix, delimiter="/")
        )

        if not file_pattern:
            return res
        return [v for v in res if fnmatch.fnmatch(os.path.basename(v.rstrip("/")), file_pattern)]

    @_log_on_error
    def list_all_files(self, s3prefix, file_pattern=None):
        """Recursively list s3 files with a given prefix.

        E.g. list_all_files('s3://urbancompass-development/property_type_test', '*_realtytrac-*.csv')
        :param s3prefix: prefix of the S3 path; must be plain text.
        :param file_pattern: string pattern of the requested file names (file basename containing no
                             directory; Can contain wildcards *, ?, as per fnmatch.
        NOTE: This operation is EXPENSIVE if the s3prefix matches a lot of files, since file_pattern
              is only applied locally.
        """
        bucket_name, prefix = self.split(s3prefix)
        bucket = self.get_s3_bucket(bucket_name)
        return (
            "s3://%s/%s" % (bucket_name, i.name)
            for i in bucket.list(prefix=prefix)
            if (not file_pattern or fnmatch.fnmatch(os.path.basename(i.name), file_pattern))
        )

    @_log_on_error
    def exists(self, s3name):
        """Returns True if a given s3 file exists."""
        return self.get_s3_key(s3name).exists()

    @_log_on_error
    def get_file_size(self, s3name):
        """Returns the size of the given file in bytes"""
        key = self.get_s3_key(s3name)
        key.open()
        res = key.size
        key.close(fast=True)
        return res

    @_log_on_error
    def get_last_modified(self, s3name):
        """Returns the last modified datetime of the given file"""
        key = self.get_s3_key(s3name)
        key.open()
        res = key.last_modified
        key.close(fast=True)
        return res

    @_log_on_error
    def get_last_updated_s3_file(self, dir):
        """
        Returns the last updated file in a s3 directory. If the directory is empty, None is returned.
        """
        s3_files = []
        s3_files += self.list(dir)
        if len(s3_files) > 0:
            s3_files.sort(
                key=(
                    lambda s3_file: datetime.strptime(
                        self.get_last_modified(s3_file), "%a, %d %b %Y %H:%M:%S %Z"
                    )
                ),
                reverse=True,
            )
            return s3_files[0]
        return None

    @_log_on_error
    def upload(self, s3name, fp, num_cb=20, multipart_upload=False):
        """Upload an s3 file from a file object."""
        key = self.get_s3_key(s3name)
        logging.info("Uploading to %s" % s3name)
        if isinstance(fp, str):
            if multipart_upload:
                self.multipart_upload(fp, key.name, key.bucket.name, raise_on_error=True)
            else:
                key.set_contents_from_filename(
                    fp, cb=_progress, num_cb=num_cb, encrypt_key=self._encrypt
                )
        else:
            key.set_contents_from_file(fp, cb=_progress, num_cb=num_cb, encrypt_key=self._encrypt)
        logging.info("Uploading to %s - complete" % s3name)
        return

    @_log_on_error
    def download(self, s3name, fp):
        """Download an s3 file to a file object."""
        key = self.get_s3_key(s3name)
        logging.info("Downloading from %s" % s3name)
        if isinstance(fp, str):
            key.get_contents_to_filename(fp, cb=_progress, num_cb=20)
        else:
            key.get_contents_to_file(fp, cb=_progress, num_cb=20)
        logging.info("Downloading from %s - complete" % s3name)
        return

    @_log_on_error
    def copy(self, src_s3name, dst_s3name):
        """Copy a file within s3."""
        srcBucketName, srcKeyName = self.split(src_s3name)
        dstBucketName, dstKeyName = self.split(dst_s3name)
        bucket = self.s3().get_bucket(dstBucketName)
        logging.info("Copying from %s to %s" % (src_s3name, dst_s3name))
        bucket.copy_key(dstKeyName, srcBucketName, srcKeyName)
        logging.info("Copying from %s to %s - complete" % (src_s3name, dst_s3name))
        return

    @_log_on_error
    def delete(self, s3name):
        """Delete a file in s3."""
        key = self.get_s3_key(s3name)
        logging.info("Deleting %s" % s3name)
        key.delete()
        logging.info("Deleting %s - complete" % s3name)
        return

    def _upload_part(
        self,
        bucket_name,
        multipart_id,
        part_num,
        source_path,
        offset,
        chunk_bytes,
        amount_of_retries=10,
    ):
        """
        Uploads a part with retries.
        """

        def _upload(retries_left=amount_of_retries):
            try:
                logging.info("Start uploading part #%d ..." % part_num)
                bucket = self.get_s3_bucket(bucket_name)
                mp_id = None
                for mp in bucket.list_multipart_uploads(upload_id_marker=multipart_id):
                    if mp.id == multipart_id:
                        with FileChunkIO(source_path, "r", offset=offset, bytes=chunk_bytes) as fp:
                            mp.upload_part_from_file(fp=fp, part_num=part_num)
                            mp_id = mp.id
                        break
                if mp_id is None:
                    raise RuntimeError(
                        "Trying to upload part of unknown multipart upload %r" % multipart_id
                    )
            except Exception as exc:
                logging.warn("Upload failed", exc_info=True)
                if retries_left:
                    _upload(retries_left=retries_left - 1)
                else:
                    logging.info("... Failed uploading part #%d" % part_num)
                    raise exc
            else:
                logging.info("... Uploaded part #%d" % part_num)

        _upload()

    @_log_on_error
    def multipart_upload(
        self, source, key, bucket_name, parallel_processes=4, max_attempts=5, raise_on_error=False
    ):
        """Uploads a file to s3."""
        for retries_left in reversed(list(range(max_attempts))):
            logging.info("Uploading to s3://{}/{}".format(bucket_name, key))
            bucket = self.get_s3_bucket(bucket_name)
            # TODO Set additional headers?
            headers = {"Content-Type": "application/octet-stream"}
            multi_part_upload = bucket.initiate_multipart_upload(
                key_name=key, headers=headers, encrypt_key=True
            )
            try:
                source_size = os.stat(source).st_size

                # Max size of 50MB
                bytes_per_chunk = max(int(math.sqrt(52428800) * math.sqrt(source_size)), 52428800)
                chunk_amount = int(math.ceil(source_size / float(bytes_per_chunk)))

                # Work around for https://bugs.python.org/issue10015
                #
                # The bug would prevent us from using multipart_upload in threads other than main because it
                # uses multiprocessing.dummy.Pool
                current_thread = threading.current_thread()
                if not hasattr(current_thread, "_children"):
                    current_thread._children = weakref.WeakKeyDictionary()

                # On last retry let's do everything syncronized and raise exception if necessary
                use_pool = retries_left > 0 or not raise_on_error

                if use_pool:
                    pool = Pool(processes=parallel_processes)
                for i in range(chunk_amount):
                    offset = i * bytes_per_chunk
                    remaining_bytes = source_size - offset
                    chunk_bytes = min([bytes_per_chunk, remaining_bytes])
                    part_num = i + 1
                    args = [
                        bucket_name,
                        multi_part_upload.id,
                        part_num,
                        source,
                        offset,
                        chunk_bytes,
                    ]
                    # On last retry let's do everything syncronized and raise exception if necessary
                    if use_pool:
                        pool.apply_async(self._upload_part, args)
                    else:
                        self._upload_part(*args)
                if use_pool:
                    pool.close()
                    pool.join()
            except:
                multi_part_upload.cancel_upload()
                raise

            if len(multi_part_upload.get_all_parts()) == chunk_amount:
                try:
                    multi_part_upload.complete_upload()
                    logging.warn("Uploading to s3://{}/{} completed.".format(bucket_name, key))
                    return True
                except boto.exception.S3ResponseError as e:
                    multi_part_upload.cancel_upload()
                    logging.warn(
                        'Uploading to s3://{}/{} threw "{}:{}-{}". Will retry {} more times.'.format(
                            bucket_name, key, e.__class__, e.status, e.reason, retries_left
                        )
                    )
                    if raise_on_error:
                        raise
            else:
                num_uploaded_chunks = len(multi_part_upload.get_all_parts())
                multi_part_upload.cancel_upload()
                logging.warn(
                    "Uploading to s3://{}/{} failed. Will retry {} more times.".format(
                        bucket_name, key, retries_left
                    )
                )
                if retries_left == 0 and raise_on_error:
                    raise RuntimeError("Upload faied %d!=%d" % (num_uploaded_chunks, chunk_amount))

        logging.warn(
            "Uploading to s3://{}/{} failed {} times. Will not retry.".format(
                bucket_name, key, max_attempts
            )
        )

        return False

    @_log_on_error
    def multipart_upload_to_dir(self, source, dir, *args, **dargs):
        key = os.path.join(dir, os.path.basename(source))
        return self.multipart_upload(source, key, *args, **dargs)

    @_log_on_error
    def upload_dir_multiplart(
        self, source_dir, target_bucket, target_prefix, filename_filter=None, *args, **kwargs
    ):
        def relpath(directory):
            return os.path.relpath(directory, source_dir)

        def paths(directory, filename):
            return os.path.join(directory, filename), os.path.join(relpath(directory), filename)

        filenames = list(
            itertools.chain.from_iterable(
                [paths(directory, filename) for filename in files]
                for directory, _, files in os.walk(source_dir)
            )
        )
        filenames = [x for x in filenames if os.path.isfile(x[0])]
        if filename_filter:
            filenames = [x for x in filenames if filename_filter(x[0])]
        for abs_name, rel_name in filenames:
            self.multipart_upload(
                abs_name, os.path.join(target_prefix, rel_name), target_bucket, *args, **kwargs
            )


class Boto3S3Connector(_S3ConnectorBase):
    """Similar to S3Connector, but implemented in terms of boto3.

    This class implements an high-level API to s3.
    It allows interaction with s3 in terms of s3 names (i.e. s3://bucketname/key/name)
    rather than the more awkward bucket/key pairs.

    Its API is roughly equivalent (but not identical) to S3Connector. Since this is based on the
    more-modern boto3, new code should consider using this rather than S3Connector.
    Disclaimer - at the time of writing, this is essentially less battle tested (especially in prod
    environments) than S3Connector.
    """

    default_encryption_method = "AES256"

    def __init__(self, access_key=None, secret_key=None, encrypt=False, assume_role_session=None):
        self._access_key = access_key
        self._secret_key = secret_key
        self._s3_client = None
        self._s3_resource = None
        self._assume_role_session = assume_role_session

        if encrypt:
            self._encryption_method = self.default_encryption_method
        else:
            self._encryption_method = None

    def s3(self):
        """
        Boto3 has separate concepts of client() and resource(), instead of a single
        connection function/object,deprecate s3().
        """
        print(
            "WARNING - your code uses the deprecated S3Connector.s3() function."
            "Please call either Boto3S3Connector.s3_client() or Boto3S3Connector.s3_resource() instead"
            "This is how S3Connector.s3() was called:"
        )
        traceback.print_stack()

        if self._assume_role_session:
            return self._assume_role_session.client("s3")

        return boto3.client("s3")

    def s3_client(self):
        """The boto3 s3 client."""
        if self._assume_role_session:
            logging.info("s3_tools.s3_client() use assume role")
        else:
            logging.info("s3_tools.s3_client() no assume role")
        if not self._s3_client:
            if self._assume_role_session:
                logging.info("Get S3 client from assume role session")
                self._s3_client = self._assume_role_session.client("s3")
            else:
                self._s3_client = boto3.client(
                    service_name="s3",
                    aws_access_key_id=self._access_key,
                    aws_secret_access_key=self._secret_key,
                )
        return self._s3_client

    def s3_resource(self):
        """The boto3 s3 resource."""
        if not self._s3_resource:
            if self._assume_role_session:
                logging.info("Get S3 resource from assume role session")
                self._s3_resource = self._assume_role_session.resource("s3")
            else:
                logging.info("Get S3 resource with no assume role")
                self._s3_resource = boto3.resource(
                    service_name="s3",
                    aws_access_key_id=self._access_key,
                    aws_secret_access_key=self._secret_key,
                )
        return self._s3_resource

    @_log_on_error
    def get_s3_bucket(self, bucket_name):
        bucket = self.s3_resource().Bucket(bucket_name)

        bucket.load()
        return bucket

    @_log_on_error
    def get_s3_key(self, s3name):
        """Get the s3 key object for a s3 "url"."""
        bucket_name, key_name = self.split(s3name)
        key = self.s3_resource().Object(bucket_name, key_name)

        key.load()
        return key

    @_log_on_error
    def load_s3_key(self, s3name):
        """Load the s3 key with metadata for a s3 "url" as a dict."""
        bucket, key = self.split(s3name)
        return self.s3_client().get_object(Bucket=bucket, Key=key)

    @_log_on_error
    def list(self, s3prefix, file_pattern=None):
        """List s3 files with a given prefix.

        :param s3prefix: prefix of the S3 path; must be plain text.
        :param file_pattern: string pattern of the requested file names (file basename containing no
                             directory; Can contain wildcards *, ?, as per fnmatch.
        """
        objects = []
        bucket_name, prefix = self.split(s3prefix)
        paginator = self.s3_client().get_paginator("list_objects")
        operation_parameters = {"Bucket": bucket_name, "Prefix": prefix, "Delimiter": "/"}
        page_iterator = paginator.paginate(**operation_parameters)
        for page in page_iterator:
            objects.extend(page.get("Contents", []))

        files = ["s3://{}/{}".format(bucket_name, file["Key"]) for file in objects]

        if not file_pattern:
            return files
        return [v for v in files if fnmatch.fnmatch(os.path.basename(v.rstrip("/")), file_pattern)]

    @_log_on_error
    def list_folders(self, s3prefix, file_pattern=None):
        """
        List s3 folders/prefixes within a given prefix. Works like list() for files but different keys

        :param s3prefix: prefix of the S3 path; must be plain text.
        :param file_pattern: string pattern of the requested folder names (file basename containing no
                             directory; Can contain wildcards *, ?, as per fnmatch.
        """
        bucket_name, prefix = self.split(s3prefix)
        resp = self.s3_client().list_objects(Bucket=bucket_name, Prefix=prefix, Delimiter="/")
        files = [
            "s3://{}/{}".format(bucket_name, file["Prefix"])
            for file in resp.get("CommonPrefixes", [])
        ]

        if not file_pattern:
            return files
        return [
            v.rstrip("/")
            for v in files
            if fnmatch.fnmatch(os.path.basename(v.rstrip("/")), file_pattern)
        ]

    @_log_on_error
    def list_folders_v2(self, s3prefix, file_pattern=None):
        """
        List s3 folders/prefixes within a given prefix. Works like list() for files but different keys.
        This behaves like list_folders() but it will use the v2 endpoint and pagination to fetch more
        than 1000 folders, if that many exist.

        :param s3prefix: prefix of the S3 path; must be plain text.
        :param file_pattern: string pattern of the requested folder names (file basename containing no
                             directory; Can contain wildcards *, ?, as per fnmatch.
        """
        bucket_name, prefix = self.split(s3prefix)
        kwargs = {"Bucket": bucket_name, "Prefix": prefix, "Delimiter": "/"}
        files = []

        paginator = self.s3_client().get_paginator("list_objects_v2")
        page_iterator = paginator.paginate(**kwargs)
        for page in page_iterator:
            if "CommonPrefixes" in page:
                files += [
                    "s3://{}/{}".format(bucket_name, file["Prefix"])
                    for file in page.get("CommonPrefixes", [])
                ]

        if not file_pattern:
            return files
        return [
            v.rstrip("/")
            for v in files
            if fnmatch.fnmatch(os.path.basename(v.rstrip("/")), file_pattern)
        ]

    @_log_on_error
    def list_all_files(self, s3prefix, file_pattern=None):
        """Recursively list s3 files with a given prefix.

        E.g. list_all_files('s3://urbancompass-development/property_type_test', '*_realtytrac-*.csv')
        :param s3prefix: prefix of the S3 path; must be plain text.
        :param file_pattern: string pattern of the requested file names (file basename containing no
                             directory; Can contain wildcards *, ?, as per fnmatch.
        NOTE: This operation is EXPENSIVE if the s3prefix matches a lot of files, since file_pattern
              is only applied locally.
        """
        bucket_name, prefix = self.split(s3prefix)
        send_request = True
        continuation_token = None
        files = []
        while send_request:
            kwargs = {"Bucket": bucket_name, "Prefix": prefix}
            if continuation_token:
                kwargs["ContinuationToken"] = continuation_token
            resp = self.s3_client().list_objects_v2(**kwargs)

            # Membership test to prevent crashing on no results
            if "Contents" in resp:
                files += [
                    "s3://{}/{}".format(bucket_name, file["Key"])
                    for file in resp["Contents"]
                    if ("Key" in file)
                    and (
                        not file_pattern
                        or fnmatch.fnmatch(os.path.basename(file["Key"]), file_pattern)
                    )
                ]

            if "NextContinuationToken" in resp:
                continuation_token = resp["NextContinuationToken"]
            else:
                send_request = False

        return files

    @_log_on_error
    def exists(self, s3name):
        """Returns True if a given s3 file exists."""
        try:
            self.load_s3_key(s3name)
            return True
        except self.s3_client().exceptions.NoSuchKey:
            return False

    @_log_on_error
    def get_file_size(self, s3name):
        """Returns the size of the given file in bytes"""
        o = self.load_s3_key(s3name)
        return o["ContentLength"]

    @_log_on_error
    def get_last_modified(self, s3name):
        """Returns the last modified datetime of the given file"""
        o = self.load_s3_key(s3name)
        return o["LastModified"]

    @_log_on_error
    def get_last_updated_s3_file(self, dir):
        """
        Returns the last updated file in a s3 directory. If the directory is empty, None is returned.
        """
        s3_files = []
        s3_files += self.list(dir)
        if len(s3_files) > 0:
            s3_files.sort(key=(lambda s3_file: self.get_last_modified(s3_file)), reverse=True)
            return s3_files[0]
        return None

    @_log_on_error
    def upload(self, s3name, fp, num_cb=-1, multipart_upload=False, verbose=True):
        """Upload an s3 file from a file or file object."""
        b, k = self.split(s3name)
        if isinstance(fp, str):
            if verbose:
                logging.info("Uploading {} to {}".format(fp, s3name))
            if multipart_upload:
                self.multipart_upload(fp, k, b, raise_on_error=True)
            else:
                self.s3_client().upload_file(Filename=fp, Bucket=b, Key=k)
            if verbose:
                logging.info("Uploading {} to {} - complete".format(fp, s3name))
        else:
            if verbose:
                logging.info("Uploading to {}".format(s3name))
            self.s3_client().upload_fileobj(Fileobj=fp, Bucket=b, Key=k)
            if verbose:
                logging.info("Uploading to {} - complete".format(s3name))
        # TODO(ugo): support Callback=_progress, Config=transfer_config for progress report,
        # multipart uploads and multithreading
        return

    @_log_on_error
    def download(self, s3name, fp):
        """Download an s3 file to a file or file object."""
        b, k = self.split(s3name)
        logging.info("Downloading from {}".format(s3name))
        if isinstance(fp, str):
            self.s3_client().download_file(Bucket=b, Key=k, Filename=fp)
        else:
            self.s3_client().download_fileobj(Bucket=b, Key=k, Fileobj=fp)
        logging.info("Downloading from {} - complete".format(s3name))
        return

    @_log_on_error
    def copy(self, src_s3name, dst_s3name):
        """Copy a file within s3."""
        src_bucket, src_key = self.split(src_s3name)
        dst_bucket, dst_key = self.split(dst_s3name)
        logging.info("Copying from {} to {}".format(src_s3name, dst_s3name))
        self.s3_client().copy_object(
            CopySource={"Bucket": src_bucket, "Key": src_key}, Bucket=dst_bucket, Key=dst_key
        )
        logging.info("Copying from {} to {} - complete".format(src_s3name, dst_s3name))
        return

    @_log_on_error
    def delete(self, s3name):
        """Delete a file in s3."""
        b, k = self.split(s3name)
        logging.info("Deleting {}".format(s3name))
        self.s3_client().delete_object(Bucket=b, Key=k)
        logging.info("Deleting {} - complete".format(s3name))
        return

    def _get_multipart_uploads(self, bucket_name, multipart_id):
        multipart_uploads = []
        is_truncated = True
        next_key_marker = None
        while is_truncated:
            optional_args = {}
            if next_key_marker:
                optional_args["NextKeyMarker"] = next_key_marker
            resp = self.s3_client().list_multipart_uploads(
                Bucket=bucket_name, UploadIdMarker=multipart_id, **optional_args
            )
            multipart_uploads += resp["Uploads"]

            if resp["IsTruncated"]:
                next_key_marker = resp["NextKeyMarker"]
            else:
                is_truncated = False

        return multipart_uploads

    def _upload_part(
        self,
        bucket_name,
        multipart_id,
        part_num,
        source_path,
        offset,
        chunk_bytes,
        amount_of_retries=10,
    ):
        """
        Uploads a part with retries.
        """

        def _upload(retries_left=amount_of_retries):
            logging.info("Start uploading part #{} ...".format(part_num))

            try:
                mp_id = None
                for mp in self._get_multipart_uploads(bucket_name, multipart_id):
                    if mp["UploadId"] == multipart_id:
                        with FileChunkIO(source_path, "r", offset=offset, bytes=chunk_bytes) as fp:
                            self.s3_client().upload_part(
                                Bucket=bucket_name,
                                Key=mp["Key"],
                                Body=fp,
                                PartNumber=part_num,
                                UploadId=mp["UploadId"],
                            )
                            mp_id = mp["UploadId"]
                        break
                if mp_id is None:
                    raise RuntimeError(
                        "Trying to upload part of unknown multipart upload {}".format(multipart_id)
                    )
            except Exception as exc:
                logging.warn("Upload failed", exc_info=True)
                if retries_left:
                    _upload(retries_left=retries_left - 1)
                else:
                    logging.info("... Failed uploading part #{}".format(part_num))
                    raise exc
            else:
                logging.info("... Uploaded part #{}".format(part_num))

        _upload()

    @_log_on_error
    def multipart_upload(
        self, source, key, bucket_name, parallel_processes=4, max_attempts=5, raise_on_error=False
    ):
        """Uploads a file to s3."""
        for retries_left in reversed(list(range(max_attempts))):
            logging.info("Uploading to s3://{}/{}".format(bucket_name, key))
            s3_obj = self.s3_resource().Object(bucket_name, key)
            # TODO Set additional headers?
            kwargs = {}
            if self._encryption_method:
                kwargs["ServerSideEncryption"] = self._encryption_method
            multi_part_upload = s3_obj.initiate_multipart_upload(
                ContentType="application/octet-stream", **kwargs
            )
            try:
                source_size = os.stat(source).st_size

                # Max size of 50MB
                bytes_per_chunk = max(int(math.sqrt(52428800) * math.sqrt(source_size)), 52428800)
                chunk_amount = int(math.ceil(source_size / float(bytes_per_chunk)))

                # Work around for https://bugs.python.org/issue10015
                #
                # The bug would prevent us from using multipart_upload in threads other than main because it
                # uses multiprocessing.dummy.Pool
                current_thread = threading.current_thread()
                if not hasattr(current_thread, "_children"):
                    current_thread._children = weakref.WeakKeyDictionary()

                # On last retry let's do everything syncronized and raise exception if necessary
                use_pool = retries_left > 0 or not raise_on_error

                if use_pool:
                    pool = Pool(processes=parallel_processes)
                for i in range(chunk_amount):
                    offset = i * bytes_per_chunk
                    remaining_bytes = source_size - offset
                    chunk_bytes = min([bytes_per_chunk, remaining_bytes])
                    part_num = i + 1
                    args = [
                        bucket_name,
                        multi_part_upload.id,
                        part_num,
                        source,
                        offset,
                        chunk_bytes,
                    ]
                    # On last retry let's do everything syncronized and raise exception if necessary
                    if use_pool:
                        pool.apply_async(self._upload_part, args)
                    else:
                        self._upload_part(*args)
                if use_pool:
                    pool.close()
                    pool.join()
            except:
                multi_part_upload.abort(RequestPayer="requester")
                raise

            multipart_upload_parts = [
                {"ETag": part.e_tag, "PartNumber": part.part_number}
                for part in multi_part_upload.parts.all()
            ]
            if len(multipart_upload_parts) == chunk_amount:
                logging.info("Completing Upload.{}".format(multipart_upload_parts))
                try:
                    multi_part_upload.complete(
                        MultipartUpload={"Parts": multipart_upload_parts}, RequestPayer="requester"
                    )
                    logging.info("Uploading to s3://{}/{} completed.".format(bucket_name, key))
                    return True
                except ClientError as e:
                    multi_part_upload.abort(RequestPayer="requester")
                    logging.warn(
                        'Uploading to s3://{}/{} threw "{}:{}". Will retry {} more times.'.format(
                            bucket_name,
                            key,
                            e.__class__,
                            e.response["Error"]["Code"],
                            e.response["Error"]["Message"],
                            retries_left,
                        )
                    )
                    if raise_on_error:
                        raise
            else:
                num_uploaded_chunks = len(multipart_upload_parts)
                multi_part_upload.abort(RequestPayer="requester")
                logging.warn(
                    "Uploading to s3://{}/{} failed. Will retry {} more times.".format(
                        bucket_name, key, retries_left
                    )
                )
                if retries_left == 0 and raise_on_error:
                    raise RuntimeError(
                        "Upload faied {} != {}".format(num_uploaded_chunks, chunk_amount)
                    )

        logging.warn(
            "Uploading to s3://{}/{} failed {} times. Will not retry.".format(
                bucket_name, key, max_attempts
            )
        )

        return False

    @_log_on_error
    def multipart_upload_to_dir(self, source, dir, *args, **dargs):
        key = os.path.join(dir, os.path.basename(source))
        return self.multipart_upload(source, key, *args, **dargs)

    @_log_on_error
    def upload_dir_multiplart(
        self, source_dir, target_bucket, target_prefix, filename_filter=None, *args, **kwargs
    ):
        def relpath(directory):
            return os.path.relpath(directory, source_dir)

        def paths(directory, filename):
            return os.path.join(directory, filename), os.path.join(relpath(directory), filename)

        filenames = list(
            itertools.chain.from_iterable(
                [paths(directory, filename) for filename in files]
                for directory, _, files in os.walk(source_dir)
            )
        )
        filenames = [fn for fn in filenames if os.path.isfile(fn[0])]
        if filename_filter:
            filenames = [fn for fn in filenames if filename_filter(fn[0])]
        for abs_name, rel_name in filenames:
            self.multipart_upload(
                abs_name, os.path.join(target_prefix, rel_name), target_bucket, *args, **kwargs
            )
