
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.contacts.api.contact.ttypes

from thrift.transport import TTransport


class GiftOrderStatus(object):
    ORDERED = 0
    SHIPPED = 1
    DELIVERED = 2
    ADDRESS = 3

    _VALUES_TO_NAMES = {
        0: "ORDERED",
        1: "SHIPPED",
        2: "DELIVERED",
        3: "ADDRESS",
    }

    _NAMES_TO_VALUES = {
        "ORDERED": 0,
        "SHIPPED": 1,
        "DELIVERED": 2,
        "ADDRESS": 3,
    }


class ContactUpdate(object):
    """
    Attributes:
     - id
     - address
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'address', (gen.urbancompass.contacts.api.contact.ttypes.ContactAddress, gen.urbancompass.contacts.api.contact.ttypes.ContactAddress.thrift_spec), None, ),  # 2
    )
    def __init__(self, id=None, address=None, ):
        self.id = id
        self.address = address

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.address = gen.urbancompass.contacts.api.contact.ttypes.ContactAddress()
                    self.address.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactUpdate')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRUCT, 2)
            self.address.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GiftOrder(object):
    """
    Attributes:
     - productName
     - contactIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'productName', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'contactIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, productName=None, contactIds=None, ):
        self.productName = productName
        self.contactIds = contactIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.productName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.contactIds = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.contactIds.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GiftOrder')
        if self.productName is not None:
            oprot.writeFieldBegin('productName', TType.STRING, 1)
            oprot.writeString(self.productName.encode('utf-8') if sys.version_info[0] == 2 else self.productName)
            oprot.writeFieldEnd()
        if self.contactIds is not None:
            oprot.writeFieldBegin('contactIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.contactIds))
            for _iter31 in self.contactIds:
                oprot.writeString(_iter31.encode('utf-8') if sys.version_info[0] == 2 else _iter31)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GiftOrderWebhookPayload(object):
    """
    Attributes:
     - personId
     - orderId
     - status
     - gifts
     - jwt
     - contactUpdates
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'orderId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'status', None, None, ),  # 3
        (4, TType.MAP, 'gifts', (TType.STRING, 'UTF8', TType.STRUCT, (GiftOrder, GiftOrder.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'jwt', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'contactUpdates', (TType.STRUCT, (ContactUpdate, ContactUpdate.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, personId=None, orderId=None, status=None, gifts=None, jwt=None, contactUpdates=None, ):
        self.personId = personId
        self.orderId = orderId
        self.status = status
        self.gifts = gifts
        self.jwt = jwt
        self.contactUpdates = contactUpdates

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.orderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.gifts = {}
                    (_ktype87, _vtype88, _size91) = iprot.readMapBegin()
                    for _i86 in range(_size91):
                        _key89 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val90 = GiftOrder()
                        _val90.read(iprot)
                        self.gifts[_key89] = _val90
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.jwt = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.contactUpdates = []
                    (_etype92, _size95) = iprot.readListBegin()
                    for _i93 in range(_size95):
                        _elem94 = ContactUpdate()
                        _elem94.read(iprot)
                        self.contactUpdates.append(_elem94)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GiftOrderWebhookPayload')
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 1)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.orderId is not None:
            oprot.writeFieldBegin('orderId', TType.STRING, 2)
            oprot.writeString(self.orderId.encode('utf-8') if sys.version_info[0] == 2 else self.orderId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 3)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.gifts is not None:
            oprot.writeFieldBegin('gifts', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.gifts))
            for _kiter121, _viter122 in self.gifts.items():
                oprot.writeString(_kiter121.encode('utf-8') if sys.version_info[0] == 2 else _kiter121)
                _viter122.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.jwt is not None:
            oprot.writeFieldBegin('jwt', TType.STRING, 5)
            oprot.writeString(self.jwt.encode('utf-8') if sys.version_info[0] == 2 else self.jwt)
            oprot.writeFieldEnd()
        if self.contactUpdates is not None:
            oprot.writeFieldBegin('contactUpdates', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.contactUpdates))
            for _iter125 in self.contactUpdates:
                _iter125.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
