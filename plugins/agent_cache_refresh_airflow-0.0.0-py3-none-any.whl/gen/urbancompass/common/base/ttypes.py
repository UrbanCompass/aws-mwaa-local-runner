
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class BinaryContentType(object):
    APPLICATION_MAPBOX_VECTOR_TILE = 0
    IMAGE_GIF = 1
    APPLICATION_PDF = 2
    IMAGE_JPEG = 3
    IMAGE_WEBP = 4
    IMAGE_PNG = 5
    TEXT_CSV = 6
    APPLICATION_XML = 7
    TEXT_TAB_SEPARATED_VALUES = 8
    TEXT_HTML = 9

    _VALUES_TO_NAMES = {
        0: "APPLICATION_MAPBOX_VECTOR_TILE",
        1: "IMAGE_GIF",
        2: "APPLICATION_PDF",
        3: "IMAGE_JPEG",
        4: "IMAGE_WEBP",
        5: "IMAGE_PNG",
        6: "TEXT_CSV",
        7: "APPLICATION_XML",
        8: "TEXT_TAB_SEPARATED_VALUES",
        9: "TEXT_HTML",
    }

    _NAMES_TO_VALUES = {
        "APPLICATION_MAPBOX_VECTOR_TILE": 0,
        "IMAGE_GIF": 1,
        "APPLICATION_PDF": 2,
        "IMAGE_JPEG": 3,
        "IMAGE_WEBP": 4,
        "IMAGE_PNG": 5,
        "TEXT_CSV": 6,
        "APPLICATION_XML": 7,
        "TEXT_TAB_SEPARATED_VALUES": 8,
        "TEXT_HTML": 9,
    }


class SameSite(object):
    UNSET = 0
    DEFAULT_MODE = 1
    LAX_MODE = 2
    STRICT_MODE = 3
    NONE_MODE = 4

    _VALUES_TO_NAMES = {
        0: "UNSET",
        1: "DEFAULT_MODE",
        2: "LAX_MODE",
        3: "STRICT_MODE",
        4: "NONE_MODE",
    }

    _NAMES_TO_VALUES = {
        "UNSET": 0,
        "DEFAULT_MODE": 1,
        "LAX_MODE": 2,
        "STRICT_MODE": 3,
        "NONE_MODE": 4,
    }


class ServiceStatus(object):
    ERROR = 0
    STARTING = 1
    OK = 2
    STOPPING = 3
    STOPPED = 4
    UNREACHABLE = 5

    _VALUES_TO_NAMES = {
        0: "ERROR",
        1: "STARTING",
        2: "OK",
        3: "STOPPING",
        4: "STOPPED",
        5: "UNREACHABLE",
    }

    _NAMES_TO_VALUES = {
        "ERROR": 0,
        "STARTING": 1,
        "OK": 2,
        "STOPPING": 3,
        "STOPPED": 4,
        "UNREACHABLE": 5,
    }


class ClientProfile(object):
    """
    Attributes:
     - appName
     - source
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'appName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'source', 'UTF8', None, ),  # 2
    )
    def __init__(self, appName=None, source=None, ):
        self.appName = appName
        self.source = source

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.appName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClientProfile')
        if self.appName is not None:
            oprot.writeFieldBegin('appName', TType.STRING, 1)
            oprot.writeString(self.appName.encode('utf-8') if sys.version_info[0] == 2 else self.appName)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 2)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Cookie(object):
    """
    Attributes:
     - name
     - value
     - path
     - domain
     - expires
     - rawExpires
     - maxAge
     - secure
     - httpOnly
     - sameSite
     - raw
     - unparsed
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'path', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'domain', 'UTF8', None, ),  # 4
        (5, TType.I64, 'expires', None, None, ),  # 5
        (6, TType.STRING, 'rawExpires', 'UTF8', None, ),  # 6
        (7, TType.I64, 'maxAge', None, None, ),  # 7
        (8, TType.BOOL, 'secure', None, None, ),  # 8
        (9, TType.BOOL, 'httpOnly', None, None, ),  # 9
        (10, TType.I32, 'sameSite', None, None, ),  # 10
        (11, TType.STRING, 'raw', 'UTF8', None, ),  # 11
        (12, TType.LIST, 'unparsed', (TType.STRING, 'UTF8', False), None, ),  # 12
    )
    def __init__(self, name=None, value=None, path=None, domain=None, expires=None, rawExpires=None, maxAge=None, secure=None, httpOnly=None, sameSite=None, raw=None, unparsed=None, ):
        self.name = name
        self.value = value
        self.path = path
        self.domain = domain
        self.expires = expires
        self.rawExpires = rawExpires
        self.maxAge = maxAge
        self.secure = secure
        self.httpOnly = httpOnly
        self.sameSite = sameSite
        self.raw = raw
        self.unparsed = unparsed

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.path = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.domain = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.expires = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.rawExpires = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.maxAge = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.secure = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.httpOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.sameSite = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.raw = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.unparsed = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.unparsed.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Cookie')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        if self.path is not None:
            oprot.writeFieldBegin('path', TType.STRING, 3)
            oprot.writeString(self.path.encode('utf-8') if sys.version_info[0] == 2 else self.path)
            oprot.writeFieldEnd()
        if self.domain is not None:
            oprot.writeFieldBegin('domain', TType.STRING, 4)
            oprot.writeString(self.domain.encode('utf-8') if sys.version_info[0] == 2 else self.domain)
            oprot.writeFieldEnd()
        if self.expires is not None:
            oprot.writeFieldBegin('expires', TType.I64, 5)
            oprot.writeI64(self.expires)
            oprot.writeFieldEnd()
        if self.rawExpires is not None:
            oprot.writeFieldBegin('rawExpires', TType.STRING, 6)
            oprot.writeString(self.rawExpires.encode('utf-8') if sys.version_info[0] == 2 else self.rawExpires)
            oprot.writeFieldEnd()
        if self.maxAge is not None:
            oprot.writeFieldBegin('maxAge', TType.I64, 7)
            oprot.writeI64(self.maxAge)
            oprot.writeFieldEnd()
        if self.secure is not None:
            oprot.writeFieldBegin('secure', TType.BOOL, 8)
            oprot.writeBool(self.secure)
            oprot.writeFieldEnd()
        if self.httpOnly is not None:
            oprot.writeFieldBegin('httpOnly', TType.BOOL, 9)
            oprot.writeBool(self.httpOnly)
            oprot.writeFieldEnd()
        if self.sameSite is not None:
            oprot.writeFieldBegin('sameSite', TType.I32, 10)
            oprot.writeI32(self.sameSite)
            oprot.writeFieldEnd()
        if self.raw is not None:
            oprot.writeFieldBegin('raw', TType.STRING, 11)
            oprot.writeString(self.raw.encode('utf-8') if sys.version_info[0] == 2 else self.raw)
            oprot.writeFieldEnd()
        if self.unparsed is not None:
            oprot.writeFieldBegin('unparsed', TType.LIST, 12)
            oprot.writeListBegin(TType.STRING, len(self.unparsed))
            for _iter6 in self.unparsed:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EchoRequest(object):
    """
    Attributes:
     - payload
     - delayMillis
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'payload', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I64, 'delayMillis', None, None, ),  # 2
    )
    def __init__(self, payload=None, delayMillis=None, ):
        self.payload = payload
        self.delayMillis = delayMillis

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.payload = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.payload.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.delayMillis = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EchoRequest')
        if self.payload is not None:
            oprot.writeFieldBegin('payload', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.payload))
            for _iter11 in self.payload:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.delayMillis is not None:
            oprot.writeFieldBegin('delayMillis', TType.I64, 2)
            oprot.writeI64(self.delayMillis)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExportedVariable(object):
    """
    Attributes:
     - name
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
    )
    def __init__(self, name=None, value=None, ):
        self.name = name
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExportedVariable')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponseStatus(object):
    """
    Attributes:
     - code
     - error
     - errorType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'code', None, None, ),  # 1
        (2, TType.STRING, 'error', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'errorType', 'UTF8', None, ),  # 3
    )
    def __init__(self, code=None, error=None, errorType=None, ):
        self.code = code
        self.error = error
        self.errorType = errorType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.errorType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponseStatus')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 1)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 2)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.errorType is not None:
            oprot.writeFieldBegin('errorType', TType.STRING, 3)
            oprot.writeString(self.errorType.encode('utf-8') if sys.version_info[0] == 2 else self.errorType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponseStatusAlternative(object):
    """
    Attributes:
     - code
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'code', None, None, ),  # 1
        (2, TType.STRING, 'error', 'UTF8', None, ),  # 2
    )
    def __init__(self, code=None, error=None, ):
        self.code = code
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponseStatusAlternative')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 1)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 2)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ServiceHealth(object):
    """
    Attributes:
     - name
     - host
     - status
     - statusDetails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.I32, 'status', None, None, ),  # 2
        (3, TType.STRING, 'statusDetails', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'host', 'UTF8', None, ),  # 4
    )
    def __init__(self, name=None, status=None, statusDetails=None, host=None, ):
        self.name = name
        self.status = status
        self.statusDetails = statusDetails
        self.host = host

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.statusDetails = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.host = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ServiceHealth')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 2)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.statusDetails is not None:
            oprot.writeFieldBegin('statusDetails', TType.STRING, 3)
            oprot.writeString(self.statusDetails.encode('utf-8') if sys.version_info[0] == 2 else self.statusDetails)
            oprot.writeFieldEnd()
        if self.host is not None:
            oprot.writeFieldBegin('host', TType.STRING, 4)
            oprot.writeString(self.host.encode('utf-8') if sys.version_info[0] == 2 else self.host)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BinaryResponse(object):
    """
    Attributes:
     - status
     - data
     - contentType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (ResponseStatus, ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'data', 'BINARY', None, ),  # 2
        (3, TType.I32, 'contentType', None, None, ),  # 3
    )
    def __init__(self, status=None, data=None, contentType=None, ):
        self.status = status
        self.data = data
        self.contentType = contentType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.data = iprot.readBinary()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.contentType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BinaryResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 2)
            oprot.writeBinary(self.data)
            oprot.writeFieldEnd()
        if self.contentType is not None:
            oprot.writeFieldBegin('contentType', TType.I32, 3)
            oprot.writeI32(self.contentType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EchoResponse(object):
    """
    Attributes:
     - request
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'request', (EchoRequest, EchoRequest.thrift_spec), None, ),  # 1
    )
    def __init__(self, request=None, ):
        self.request = request

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.request = EchoRequest()
                    self.request.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EchoResponse')
        if self.request is not None:
            oprot.writeFieldBegin('request', TType.STRUCT, 1)
            self.request.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExportedVars(object):
    """
    Attributes:
     - vars
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'vars', (TType.STRUCT, (ExportedVariable, ExportedVariable.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, vars=None, ):
        self.vars = vars

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.vars = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = ExportedVariable()
                        _elem14.read(iprot)
                        self.vars.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExportedVars')
        if self.vars is not None:
            oprot.writeFieldBegin('vars', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.vars))
            for _iter16 in self.vars:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SystemHealth(object):
    """
    Attributes:
     - serviceName
     - overallStatus
     - subsystemsStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'serviceName', 'UTF8', None, ),  # 1
        (2, TType.I32, 'overallStatus', None, None, ),  # 2
        (3, TType.LIST, 'subsystemsStatus', (TType.STRUCT, (ServiceHealth, ServiceHealth.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, serviceName=None, overallStatus=None, subsystemsStatus=None, ):
        self.serviceName = serviceName
        self.overallStatus = overallStatus
        self.subsystemsStatus = subsystemsStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.overallStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.subsystemsStatus = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = ServiceHealth()
                        _elem19.read(iprot)
                        self.subsystemsStatus.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SystemHealth')
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 1)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.overallStatus is not None:
            oprot.writeFieldBegin('overallStatus', TType.I32, 2)
            oprot.writeI32(self.overallStatus)
            oprot.writeFieldEnd()
        if self.subsystemsStatus is not None:
            oprot.writeFieldBegin('subsystemsStatus', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.subsystemsStatus))
            for _iter21 in self.subsystemsStatus:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
