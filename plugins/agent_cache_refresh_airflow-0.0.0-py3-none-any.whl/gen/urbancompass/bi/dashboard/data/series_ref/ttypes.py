
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.charts.tooltip_settings.ttypes
import gen.urbancompass.bi.dashboard.data.value_formats.ttypes

from thrift.transport import TTransport


class SeriesRef(object):
    """
    Attributes:
     - dfId
     - seriesId
     - dfName
     - displayName
     - displayFormat
     - tooltipSettings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dfId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'seriesId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dfName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'displayName', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'displayFormat', (gen.urbancompass.bi.dashboard.data.value_formats.ttypes.ValueFormat, gen.urbancompass.bi.dashboard.data.value_formats.ttypes.ValueFormat.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'tooltipSettings', (gen.urbancompass.bi.dashboard.data.charts.tooltip_settings.ttypes.TooltipSettings, gen.urbancompass.bi.dashboard.data.charts.tooltip_settings.ttypes.TooltipSettings.thrift_spec), None, ),  # 6
    )
    def __init__(self, dfId=None, seriesId=None, dfName=None, displayName=None, displayFormat=None, tooltipSettings=None, ):
        self.dfId = dfId
        self.seriesId = seriesId
        self.dfName = dfName
        self.displayName = displayName
        self.displayFormat = displayFormat
        self.tooltipSettings = tooltipSettings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dfId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.seriesId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dfName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.displayFormat = gen.urbancompass.bi.dashboard.data.value_formats.ttypes.ValueFormat()
                    self.displayFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.tooltipSettings = gen.urbancompass.bi.dashboard.data.charts.tooltip_settings.ttypes.TooltipSettings()
                    self.tooltipSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SeriesRef')
        if self.dfId is not None:
            oprot.writeFieldBegin('dfId', TType.STRING, 1)
            oprot.writeString(self.dfId.encode('utf-8') if sys.version_info[0] == 2 else self.dfId)
            oprot.writeFieldEnd()
        if self.seriesId is not None:
            oprot.writeFieldBegin('seriesId', TType.STRING, 2)
            oprot.writeString(self.seriesId.encode('utf-8') if sys.version_info[0] == 2 else self.seriesId)
            oprot.writeFieldEnd()
        if self.dfName is not None:
            oprot.writeFieldBegin('dfName', TType.STRING, 3)
            oprot.writeString(self.dfName.encode('utf-8') if sys.version_info[0] == 2 else self.dfName)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 4)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.displayFormat is not None:
            oprot.writeFieldBegin('displayFormat', TType.STRUCT, 5)
            self.displayFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.tooltipSettings is not None:
            oprot.writeFieldBegin('tooltipSettings', TType.STRUCT, 6)
            self.tooltipSettings.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
