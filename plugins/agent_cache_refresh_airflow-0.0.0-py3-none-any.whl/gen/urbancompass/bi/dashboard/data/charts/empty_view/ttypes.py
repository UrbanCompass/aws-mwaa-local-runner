
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.analytics.ttypes
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes

from thrift.transport import TTransport


class EmptyViewAlign(object):
    LEFT = 0
    RIGHT = 1
    CENTER = 2

    _VALUES_TO_NAMES = {
        0: "LEFT",
        1: "RIGHT",
        2: "CENTER",
    }

    _NAMES_TO_VALUES = {
        "LEFT": 0,
        "RIGHT": 1,
        "CENTER": 2,
    }


class EmptyViewButton(object):
    """
    Attributes:
     - text
     - textSeriesRef
     - link
     - linkSeriesRef
     - analyticsInformation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'text', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'textSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'link', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'linkSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'analyticsInformation', (gen.urbancompass.bi.dashboard.data.analytics.ttypes.AnalyticsInformation, gen.urbancompass.bi.dashboard.data.analytics.ttypes.AnalyticsInformation.thrift_spec), None, ),  # 5
    )
    def __init__(self, text=None, textSeriesRef=None, link=None, linkSeriesRef=None, analyticsInformation=None, ):
        self.text = text
        self.textSeriesRef = textSeriesRef
        self.link = link
        self.linkSeriesRef = linkSeriesRef
        self.analyticsInformation = analyticsInformation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.text = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.textSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.textSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.link = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.linkSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.linkSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.analyticsInformation = gen.urbancompass.bi.dashboard.data.analytics.ttypes.AnalyticsInformation()
                    self.analyticsInformation.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EmptyViewButton')
        if self.text is not None:
            oprot.writeFieldBegin('text', TType.STRING, 1)
            oprot.writeString(self.text.encode('utf-8') if sys.version_info[0] == 2 else self.text)
            oprot.writeFieldEnd()
        if self.textSeriesRef is not None:
            oprot.writeFieldBegin('textSeriesRef', TType.STRUCT, 2)
            self.textSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.link is not None:
            oprot.writeFieldBegin('link', TType.STRING, 3)
            oprot.writeString(self.link.encode('utf-8') if sys.version_info[0] == 2 else self.link)
            oprot.writeFieldEnd()
        if self.linkSeriesRef is not None:
            oprot.writeFieldBegin('linkSeriesRef', TType.STRUCT, 4)
            self.linkSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.analyticsInformation is not None:
            oprot.writeFieldBegin('analyticsInformation', TType.STRUCT, 5)
            self.analyticsInformation.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EmptyView(object):
    """
    Attributes:
     - title
     - titleSeriesRef
     - text
     - textSeriesRef
     - button
     - align
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'titleSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'text', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'textSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'button', (EmptyViewButton, EmptyViewButton.thrift_spec), None, ),  # 5
        (6, TType.I32, 'align', None, None, ),  # 6
    )
    def __init__(self, title=None, titleSeriesRef=None, text=None, textSeriesRef=None, button=None, align=None, ):
        self.title = title
        self.titleSeriesRef = titleSeriesRef
        self.text = text
        self.textSeriesRef = textSeriesRef
        self.button = button
        self.align = align

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.titleSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.titleSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.text = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.textSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.textSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.button = EmptyViewButton()
                    self.button.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.align = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EmptyView')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.titleSeriesRef is not None:
            oprot.writeFieldBegin('titleSeriesRef', TType.STRUCT, 2)
            self.titleSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.text is not None:
            oprot.writeFieldBegin('text', TType.STRING, 3)
            oprot.writeString(self.text.encode('utf-8') if sys.version_info[0] == 2 else self.text)
            oprot.writeFieldEnd()
        if self.textSeriesRef is not None:
            oprot.writeFieldBegin('textSeriesRef', TType.STRUCT, 4)
            self.textSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.button is not None:
            oprot.writeFieldBegin('button', TType.STRUCT, 5)
            self.button.write(oprot)
            oprot.writeFieldEnd()
        if self.align is not None:
            oprot.writeFieldBegin('align', TType.I32, 6)
            oprot.writeI32(self.align)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
