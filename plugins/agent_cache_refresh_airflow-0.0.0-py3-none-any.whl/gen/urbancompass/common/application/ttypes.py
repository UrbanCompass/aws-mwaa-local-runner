
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class ResourceType(object):
    COLLECTION = 0
    DEAL = 1
    DOCUMENT = 2
    LISTING = 3
    OPEN_HOUSE_CHECK_IN = 4
    SAVED_SEARCH = 5
    PERSON = 6
    CODELABS_TODOS = 7
    FEED = 8
    REFERENCE_TODOS = 9
    TOURSHEET = 10
    CONTACT = 11
    CONTACT_EMAIL_TEMPLATE = 12
    ASSET_LIBRARY_FOLDER = 13
    ASSET_LIBRARY_ASSET = 14
    CIS_RECOMMENDATION = 15
    PROPERTY = 16
    LIKELIHOOD_TO_SELL = 17
    BUILDING = 18
    CONTACT_EMAIL_MESSAGE = 19
    MARKETING_CENTER_COLLATERAL = 20
    TASK = 21
    APP_CONTACTS = 22
    COMPARATIVE_MARKET_ANALYSIS = 23
    APP_DEAL_CLOSER = 24
    LISTING_FOLDER = 25
    MEDIA_SECURE_DOCUMENT = 26
    MEDIA_SECURE_DOCUMENT_DMS = 27
    ABW_DMS_FOLDER = 28
    LEAD_ALLOCATION = 29
    SERVICE_BACKEND = 30
    SERVICE_FRONTEND = 31
    FILE_STORAGE = 32
    MARKETING_PLAN = 33
    DIGITAL_AD = 34
    VIDEO_STUDIO_ASSET = 35
    GLIDE_TRANSACTION = 36
    LISTING_EDITOR = 37
    PHOTO_INGESTION_PROJECT = 38
    ASSET_LIBRARY_COLLECTION = 39
    WORK_ORDER_DEFINITION = 40
    WORK_ORDER_INSTANCE = 41

    _VALUES_TO_NAMES = {
        0: "COLLECTION",
        1: "DEAL",
        2: "DOCUMENT",
        3: "LISTING",
        4: "OPEN_HOUSE_CHECK_IN",
        5: "SAVED_SEARCH",
        6: "PERSON",
        7: "CODELABS_TODOS",
        8: "FEED",
        9: "REFERENCE_TODOS",
        10: "TOURSHEET",
        11: "CONTACT",
        12: "CONTACT_EMAIL_TEMPLATE",
        13: "ASSET_LIBRARY_FOLDER",
        14: "ASSET_LIBRARY_ASSET",
        15: "CIS_RECOMMENDATION",
        16: "PROPERTY",
        17: "LIKELIHOOD_TO_SELL",
        18: "BUILDING",
        19: "CONTACT_EMAIL_MESSAGE",
        20: "MARKETING_CENTER_COLLATERAL",
        21: "TASK",
        22: "APP_CONTACTS",
        23: "COMPARATIVE_MARKET_ANALYSIS",
        24: "APP_DEAL_CLOSER",
        25: "LISTING_FOLDER",
        26: "MEDIA_SECURE_DOCUMENT",
        27: "MEDIA_SECURE_DOCUMENT_DMS",
        28: "ABW_DMS_FOLDER",
        29: "LEAD_ALLOCATION",
        30: "SERVICE_BACKEND",
        31: "SERVICE_FRONTEND",
        32: "FILE_STORAGE",
        33: "MARKETING_PLAN",
        34: "DIGITAL_AD",
        35: "VIDEO_STUDIO_ASSET",
        36: "GLIDE_TRANSACTION",
        37: "LISTING_EDITOR",
        38: "PHOTO_INGESTION_PROJECT",
        39: "ASSET_LIBRARY_COLLECTION",
        40: "WORK_ORDER_DEFINITION",
        41: "WORK_ORDER_INSTANCE",
    }

    _NAMES_TO_VALUES = {
        "COLLECTION": 0,
        "DEAL": 1,
        "DOCUMENT": 2,
        "LISTING": 3,
        "OPEN_HOUSE_CHECK_IN": 4,
        "SAVED_SEARCH": 5,
        "PERSON": 6,
        "CODELABS_TODOS": 7,
        "FEED": 8,
        "REFERENCE_TODOS": 9,
        "TOURSHEET": 10,
        "CONTACT": 11,
        "CONTACT_EMAIL_TEMPLATE": 12,
        "ASSET_LIBRARY_FOLDER": 13,
        "ASSET_LIBRARY_ASSET": 14,
        "CIS_RECOMMENDATION": 15,
        "PROPERTY": 16,
        "LIKELIHOOD_TO_SELL": 17,
        "BUILDING": 18,
        "CONTACT_EMAIL_MESSAGE": 19,
        "MARKETING_CENTER_COLLATERAL": 20,
        "TASK": 21,
        "APP_CONTACTS": 22,
        "COMPARATIVE_MARKET_ANALYSIS": 23,
        "APP_DEAL_CLOSER": 24,
        "LISTING_FOLDER": 25,
        "MEDIA_SECURE_DOCUMENT": 26,
        "MEDIA_SECURE_DOCUMENT_DMS": 27,
        "ABW_DMS_FOLDER": 28,
        "LEAD_ALLOCATION": 29,
        "SERVICE_BACKEND": 30,
        "SERVICE_FRONTEND": 31,
        "FILE_STORAGE": 32,
        "MARKETING_PLAN": 33,
        "DIGITAL_AD": 34,
        "VIDEO_STUDIO_ASSET": 35,
        "GLIDE_TRANSACTION": 36,
        "LISTING_EDITOR": 37,
        "PHOTO_INGESTION_PROJECT": 38,
        "ASSET_LIBRARY_COLLECTION": 39,
        "WORK_ORDER_DEFINITION": 40,
        "WORK_ORDER_INSTANCE": 41,
    }


class ServiceType(object):
    COMPASS = 0
    FEED = 1
    API_V3 = 2

    _VALUES_TO_NAMES = {
        0: "COMPASS",
        1: "FEED",
        2: "API_V3",
    }

    _NAMES_TO_VALUES = {
        "COMPASS": 0,
        "FEED": 1,
        "API_V3": 2,
    }


class BulkResult(object):
    """
    Attributes:
     - ids
     - notFoundIds
     - forbiddenIds
     - failedIds
     - failureMessages
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'ids', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'notFoundIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'forbiddenIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'failedIds', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'failureMessages', (TType.STRING, 'UTF8', False), None, ),  # 5
    )
    def __init__(self, ids=None, notFoundIds=None, forbiddenIds=None, failedIds=None, failureMessages=None, ):
        self.ids = ids
        self.notFoundIds = notFoundIds
        self.forbiddenIds = forbiddenIds
        self.failedIds = failedIds
        self.failureMessages = failureMessages

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.ids.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.notFoundIds = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.notFoundIds.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.forbiddenIds = []
                    (_etype10, _size13) = iprot.readListBegin()
                    for _i11 in range(_size13):
                        _elem12 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.forbiddenIds.append(_elem12)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.failedIds = []
                    (_etype14, _size17) = iprot.readListBegin()
                    for _i15 in range(_size17):
                        _elem16 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.failedIds.append(_elem16)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.failureMessages = []
                    (_etype18, _size21) = iprot.readListBegin()
                    for _i19 in range(_size21):
                        _elem20 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.failureMessages.append(_elem20)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BulkResult')
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.ids))
            for _iter22 in self.ids:
                oprot.writeString(_iter22.encode('utf-8') if sys.version_info[0] == 2 else _iter22)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notFoundIds is not None:
            oprot.writeFieldBegin('notFoundIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.notFoundIds))
            for _iter23 in self.notFoundIds:
                oprot.writeString(_iter23.encode('utf-8') if sys.version_info[0] == 2 else _iter23)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.forbiddenIds is not None:
            oprot.writeFieldBegin('forbiddenIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.forbiddenIds))
            for _iter24 in self.forbiddenIds:
                oprot.writeString(_iter24.encode('utf-8') if sys.version_info[0] == 2 else _iter24)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.failedIds is not None:
            oprot.writeFieldBegin('failedIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.failedIds))
            for _iter25 in self.failedIds:
                oprot.writeString(_iter25.encode('utf-8') if sys.version_info[0] == 2 else _iter25)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.failureMessages is not None:
            oprot.writeFieldBegin('failureMessages', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.failureMessages))
            for _iter26 in self.failureMessages:
                oprot.writeString(_iter26.encode('utf-8') if sys.version_info[0] == 2 else _iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Pagination(object):
    """
    Attributes:
     - skip
     - limit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'skip', None, None, ),  # 1
        (2, TType.I32, 'limit', None, None, ),  # 2
    )
    def __init__(self, skip=None, limit=None, ):
        self.skip = skip
        self.limit = limit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.skip = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Pagination')
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.I32, 1)
            oprot.writeI32(self.skip)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 2)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PaginationWithToken(object):
    """
    Attributes:
     - token
     - limit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'token', 'UTF8', None, ),  # 1
        (2, TType.I32, 'limit', None, None, ),  # 2
    )
    def __init__(self, token=None, limit=None, ):
        self.token = token
        self.limit = limit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PaginationWithToken')
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 1)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 2)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResourceRef(object):
    """
    Attributes:
     - resourceType
     - resourceId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'resourceType', None, None, ),  # 1
        (2, TType.STRING, 'resourceId', 'UTF8', None, ),  # 2
    )
    def __init__(self, resourceType=None, resourceId=None, ):
        self.resourceType = resourceType
        self.resourceId = resourceId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.resourceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.resourceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResourceRef')
        if self.resourceType is not None:
            oprot.writeFieldBegin('resourceType', TType.I32, 1)
            oprot.writeI32(self.resourceType)
            oprot.writeFieldEnd()
        if self.resourceId is not None:
            oprot.writeFieldBegin('resourceId', TType.STRING, 2)
            oprot.writeString(self.resourceId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EnrichError(object):
    """
    Attributes:
     - id
     - enrichOption
     - resourceRef
     - errorCode
     - errorMessage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'enrichOption', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'resourceRef', (ResourceRef, ResourceRef.thrift_spec), None, ),  # 3
        (4, TType.I32, 'errorCode', None, None, ),  # 4
        (5, TType.STRING, 'errorMessage', 'UTF8', None, ),  # 5
    )
    def __init__(self, id=None, enrichOption=None, resourceRef=None, errorCode=None, errorMessage=None, ):
        self.id = id
        self.enrichOption = enrichOption
        self.resourceRef = resourceRef
        self.errorCode = errorCode
        self.errorMessage = errorMessage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.enrichOption = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.resourceRef = ResourceRef()
                    self.resourceRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.errorCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.errorMessage = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichError')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.enrichOption is not None:
            oprot.writeFieldBegin('enrichOption', TType.STRING, 2)
            oprot.writeString(self.enrichOption.encode('utf-8') if sys.version_info[0] == 2 else self.enrichOption)
            oprot.writeFieldEnd()
        if self.resourceRef is not None:
            oprot.writeFieldBegin('resourceRef', TType.STRUCT, 3)
            self.resourceRef.write(oprot)
            oprot.writeFieldEnd()
        if self.errorCode is not None:
            oprot.writeFieldBegin('errorCode', TType.I32, 4)
            oprot.writeI32(self.errorCode)
            oprot.writeFieldEnd()
        if self.errorMessage is not None:
            oprot.writeFieldBegin('errorMessage', TType.STRING, 5)
            oprot.writeString(self.errorMessage.encode('utf-8') if sys.version_info[0] == 2 else self.errorMessage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
