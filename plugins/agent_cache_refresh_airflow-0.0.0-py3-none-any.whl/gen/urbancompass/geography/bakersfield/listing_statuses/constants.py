
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
AVAILABLE_RENTAL_STATUSES = [
    5,
    1,
    0,
]
AVAILABLE_SALE_STATUSES = [
    9,
    2,
]
LISTING_STATUSES = {
    12: "Withdrawn",
    10: "Sold",
    11: "Temporarily Off Market",
    4: "Expired",
    2: "Contingent",
    8: "Pending",
    0: "Active",
    14: "Coming Soon",
    3: "Pending",
    1: "Pending",
    5: "Rented",
}
OFF_MARKET_RENTAL_STATUSES = [
    4,
    2,
    6,
    3,
]
OFF_MARKET_SALE_STATUSES = [
    8,
    10,
    6,
    7,
]
RENTAL_STATUSES = {
    6: "Withdrawn",
    3: "Expired",
    4: "Rented",
    5: "Active",
    1: "Pending",
    0: "Pending",
    2: "Temporarily Off Market",
    7: "Coming Soon",
}
SALE_STATUSES = {
    10: "Withdrawn",
    8: "Sold",
    6: "Temporarily Off Market",
    7: "Expired",
    2: "Contingent",
    3: "Pending",
    9: "Active",
    12: "Coming Soon",
}
