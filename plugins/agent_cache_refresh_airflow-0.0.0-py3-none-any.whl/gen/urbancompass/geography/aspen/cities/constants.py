
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
ALMONT = "Almont"
ASPEN = "Aspen"
AVON = "Avon"
BASALT = "Basalt"
BATTLEMENT_MESA = "Battlement Mesa"
BOND = "Bond"
BURNS = "Burns"
CARBONDALE = "Carbondale"
CITIES = [
    "Almont",
    "Aspen",
    "Avon",
    "Basalt",
    "Battlement Mesa",
    "Bond",
    "Burns",
    "Carbondale",
    "Clark",
    "Crested Butte",
    "Eagle",
    "Edwards",
    "El Jebel",
    "Glenwood Springs",
    "Gunnison",
    "Gypsum",
    "Hayden",
    "Marble",
    "McCoy",
    "Meeker",
    "Meredith",
    "Minturn",
    "New Castle",
    "Oak Creek",
    "Ohio City",
    "Parachute",
    "Parlin",
    "Phippsburg",
    "Pitkin",
    "Powderhorn",
    "Rangely",
    "Redstone",
    "Red Cliff",
    "Rifle",
    "Silt",
    "Snowmass",
    "Snowmass Village",
    "Somerset",
    "Steamboat Springs",
    "Toponas",
    "Vail",
    "Wolcott",
    "Woody Creek",
    "Yampa",
]
CLARK = "Clark"
CRESTED_BUTTE = "Crested Butte"
EAGLE = "Eagle"
EDWARDS = "Edwards"
EL_JEBEL = "El Jebel"
GLENWOOD_SPRINGS = "Glenwood Springs"
GUNNISON = "Gunnison"
GYPSUM = "Gypsum"
HAYDEN = "Hayden"
MARBLE = "Marble"
MCCOY = "McCoy"
MEEKER = "Meeker"
MEREDITH = "Meredith"
MINTURN = "Minturn"
NEW_CASTLE = "New Castle"
OAK_CREEK = "Oak Creek"
OHIO_CITY = "Ohio City"
PARACHUTE = "Parachute"
PARLIN = "Parlin"
PHIPPSBURG = "Phippsburg"
PITKIN = "Pitkin"
POWDERHORN = "Powderhorn"
RANGELY = "Rangely"
REDSTONE = "Redstone"
RED_CLIFF = "Red Cliff"
RIFLE = "Rifle"
SILT = "Silt"
SNOWMASS = "Snowmass"
SNOWMASS_VILLAGE = "Snowmass Village"
SOMERSET = "Somerset"
STEAMBOAT_SPRINGS = "Steamboat Springs"
TOPONAS = "Toponas"
VAIL = "Vail"
WOLCOTT = "Wolcott"
WOODY_CREEK = "Woody Creek"
YAMPA = "Yampa"
