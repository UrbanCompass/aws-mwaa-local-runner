# -*- coding: utf-8 -*-
"""
:copyright: (c) 2016 by UrbanCompass, Inc.

Compass specific helpers related with the logging library.

- logging initialization,
- special logging helpers.
"""
import logging
import time
import re
import threading
import uuid

from uc.base.uc_logging.dd_logs import cfg_docker_dd_json_logger

current_thread = threading.local()


def new_trace_id():
    """Generate a new trace id for the current thread."""
    current_thread.trace_id = str(uuid.uuid1())


def set_trace_id(val):
    """Set the trace id for the current thread.

    :param val: The desired trace_id. This will be subject to str() to ensure that trace ids are
      strings.  Use set_trace_id(None) to unset.
    """
    if val is not None:
        val = str(val)
    current_thread.trace_id = val


def get_trace_id():
    """Get the trace id for the current thread, or None if no trace id is set."""
    return getattr(current_thread, "trace_id", None)


def get_internal_token():
    return getattr(current_thread, "internal_auth_token", None)


def set_internal_token(val):
    if val is not None:
        val = str(val)
    current_thread.internal_auth_token = val


class _TraceIdFilter(object):
    """A logging filter that injects record.trace_id_string ."""

    def filter(self, record):
        trace_id = get_trace_id()
        if trace_id:
            record.trace_id_string = "tid:%s " % trace_id
        else:
            record.trace_id_string = ""
        return True


# The list of all plausible log_level inputs to init_logging.
ACCEPTABLE_LOG_LEVELS = [v for v in logging._nameToLevel if str(v) == v]


def _cfg_basic_logger(log_level="INFO", max_message_length=None):
    DATE_FMT = "%Y%m%d %H:%M:%S"
    max_message_length = max_message_length or 10000
    max_message_len_str = ".%ds" % max_message_length

    FORMAT = (
        "%(levelname).1s"  # A single char for the log level ('I', 'W', 'E')
        "%(asctime)s "  # timestamp printed according to DATE_FMT
        "thread[%(threadName)s] "  # the name of the current thread
        "%(filename)s:%(lineno)d "  # the name, line number of the log statement
        "%(trace_id_string)s"  # the trace_id as a (possibly empty) string, injected by _TraceIdFilter
        "%(message)"
        + max_message_len_str  # the log message, limited to 10000 characters for sanity.
    )

    logging.basicConfig(format=FORMAT, datefmt=DATE_FMT, level=log_level)

    trace_id_filter = _TraceIdFilter()
    for handler in logging.root.handlers:
        handler.addFilter(trace_id_filter)


def add_args(parser):
    """Add logging specific arguments to an argparse.ArgumentParser."""
    parser.add_argument(
        "--silence_libraries",
        action="store_true",
        help="Turn off log messages from 3rd party libraries.",
    )
    parser.add_argument(
        "--log_level",
        default="INFO",
        choices=ACCEPTABLE_LOG_LEVELS,
        help="logging messages with severity lower than this will "
        "not be printed. (default: %(default)r)",
    )
    parser.add_argument(
        "--log_dd_json",
        action="store_true",
        help="Log to stdout/err in json w/ Datadog-specific attributes",
    )


def init_from_args(opts, max_message_length=None):
    return init(
        log_level=opts.log_level,
        silence_libraries=opts.silence_libraries,
        max_message_length=max_message_length,
        log_dd_json=opts.log_dd_json,
    )


def init(log_level="INFO", silence_libraries=False, max_message_length=None, log_dd_json=False):
    """
    Initialize logging so that it is pretty and compact.
    :param log_level:  only emit log messages of this level or higher.
    :param silence_libraries:  squelches logging from libraries.  Use True to squelch logging from all
        libraries, a re string to only affect libraries that are matched by that re.
    :param max_message_length: The override of the default maximum message length
    (currently 10000)
    :param log_dd_json: log to stdout/err in json with Datadog-specific attributes
    """

    # Drop all and any logging handlers, otherwise basicConfig will do nothing.
    old_logging_handlers = logging.root.handlers
    logging.root.handlers = []

    if log_dd_json:
        cfg_docker_dd_json_logger(level=log_level)
        logging.info("Logging in Datadog JSON to stdout/err")
    else:
        _cfg_basic_logger(log_level=log_level, max_message_length=max_message_length)

    if silence_libraries:
        non_urbancompass_filter = _NonUrbanCodeLoggingFilter(
            log_level="WARNING", silence_libraries=silence_libraries
        )
        for handler in logging.root.handlers:
            handler.addFilter(non_urbancompass_filter)

    if old_logging_handlers:
        # This will happen if any call to logging.{info,error,warning} is issued before init_logging.
        # In our normal app lifespan this typically happens if:
        # - some library logs at import time,
        # - some of our code logs at import time
        # and the side effect is that the error/warning logs emitted before init_logging come out
        # misformatted, and info logs don't come out at all.
        # These are only info logs, so they should not be critical, and we have no great way to avoid
        # those issues, especially because of the external libraries.  So we just log a message.
        logging.warn("Logging handlers initialized prior to init_logging were dropped.")


class _NonUrbanCodeLoggingFilter(object):
    """A simple logging filter that will silence all library code messages below specified threshold.

    Increases the log level of any python file that matches the following:

    - dist-packages and site-packages: System installed libraries (hopefully we're not running these
      in prod anyway!)

    - .pex/install: These are where libraries are executed from when running from a pex.
    """

    paths_to_quiet = re.compile(r"((dist|site)-packages|\.pex/install/|\.deps/)")

    def __init__(self, log_level="WARNING", silence_libraries=True):
        """
        :param log_level:  suppress only log messages with a level lower than this.
        :param silence_libraries:  this can be True, or a string that will be used as one more regular
            expression to select libraries that should be silenced.
        """
        # This uses an undocumented feature of getLevelName... if you give it a level name, it returns
        # you the numeric representation.
        self._log_level = logging.getLevelName(log_level)
        try:
            self._extra_re = re.compile(silence_libraries)
        except TypeError:
            self._extra_re = None

    def filter(self, record):
        """Is the specified record to be logged? Returns zero for no, nonzero for yes."""
        if record.levelno < self._log_level and self.paths_to_quiet.search(record.pathname):
            if self._extra_re is None or self._extra_re.search(record.pathname):
                return 0
        return 1


class LogEveryT(object):
    """A special "logger" like class for rate-limited logging.

    Use i.e. as:
      logger = LogEveryT(delta_sec=10)  # only write an info message every 10 sec.
      while long_lasting_tight_loop_is_active:
        progress = do_work()
        logger.info('This message only prints every 10 seconds! Progress = %r',
                    progress)

    Currently this only supports info-logging since arguably error and warning logging
    should not be rate limited.
    """

    def __init__(self, delta_sec):
        """Create a special logger that rate-limits calls to .info.

        :param delta_sec: only write logging.info statements once every delta_sec.
        """
        self._next_t = time.time() + delta_sec
        self._delta_sec = delta_sec

    def info(self, msg, *args):
        """Same as logging.info, but will actually write only once every delta_sec."""
        t = time.time()
        if t >= self._next_t:
            logging.info(msg, *args)
            self._next_t = t + self._delta_sec
