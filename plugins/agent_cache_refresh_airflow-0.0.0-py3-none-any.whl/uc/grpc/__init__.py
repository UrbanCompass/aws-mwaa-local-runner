# -*- coding: utf-8 -*-
"""
GRPC support functions.

:copyright: (c) 2016 by Urban Compass, Inc.
"""

DEFAULT_MAX_MESSAGE_LENGTH = 100 * 1024 * 1024  # 100MB
DEFAULT_REQUEST_TIMEOUT = 120
DEFAULT_PER_CALL_CHANNEL_TIMEOUT = 2
