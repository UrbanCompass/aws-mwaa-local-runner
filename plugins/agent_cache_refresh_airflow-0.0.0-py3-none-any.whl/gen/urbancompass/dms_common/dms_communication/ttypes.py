
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class DiffElementFormat(object):
    STRING = 0
    DATE = 1
    BOOL = 2
    CURRENCY = 3
    PERCENT = 4
    PROPERTY_TYPE = 5
    DMS_LISTING_TRANSACTION_STAGE = 6
    DMS_LISTING_TRANSACTION_SUBSTAGE = 7

    _VALUES_TO_NAMES = {
        0: "STRING",
        1: "DATE",
        2: "BOOL",
        3: "CURRENCY",
        4: "PERCENT",
        5: "PROPERTY_TYPE",
        6: "DMS_LISTING_TRANSACTION_STAGE",
        7: "DMS_LISTING_TRANSACTION_SUBSTAGE",
    }

    _NAMES_TO_VALUES = {
        "STRING": 0,
        "DATE": 1,
        "BOOL": 2,
        "CURRENCY": 3,
        "PERCENT": 4,
        "PROPERTY_TYPE": 5,
        "DMS_LISTING_TRANSACTION_STAGE": 6,
        "DMS_LISTING_TRANSACTION_SUBSTAGE": 7,
    }


class ResourceStatus(object):
    CREATED = 0
    UPDATED = 1
    DELETED = 2
    REQUIRED = 3
    IF_APPLICABLE = 4
    UPLOADED = 5
    READY_FOR_REVIEW = 6
    IN_REVIEW = 7
    COMMENTED = 8
    APPROVED = 9
    REJECTED = 10
    SHARED = 11
    UNSHARED = 12
    UNAPPROVED = 13
    UNREJECTED = 14
    SPLIT = 15
    WITHDRAWN = 16
    CANCELLED = 17
    SENT = 18
    DRAFTED = 19

    _VALUES_TO_NAMES = {
        0: "CREATED",
        1: "UPDATED",
        2: "DELETED",
        3: "REQUIRED",
        4: "IF_APPLICABLE",
        5: "UPLOADED",
        6: "READY_FOR_REVIEW",
        7: "IN_REVIEW",
        8: "COMMENTED",
        9: "APPROVED",
        10: "REJECTED",
        11: "SHARED",
        12: "UNSHARED",
        13: "UNAPPROVED",
        14: "UNREJECTED",
        15: "SPLIT",
        16: "WITHDRAWN",
        17: "CANCELLED",
        18: "SENT",
        19: "DRAFTED",
    }

    _NAMES_TO_VALUES = {
        "CREATED": 0,
        "UPDATED": 1,
        "DELETED": 2,
        "REQUIRED": 3,
        "IF_APPLICABLE": 4,
        "UPLOADED": 5,
        "READY_FOR_REVIEW": 6,
        "IN_REVIEW": 7,
        "COMMENTED": 8,
        "APPROVED": 9,
        "REJECTED": 10,
        "SHARED": 11,
        "UNSHARED": 12,
        "UNAPPROVED": 13,
        "UNREJECTED": 14,
        "SPLIT": 15,
        "WITHDRAWN": 16,
        "CANCELLED": 17,
        "SENT": 18,
        "DRAFTED": 19,
    }


class ResourceType(object):
    DOCUMENT = 0
    COMMISSION = 1
    CHECKLIST_ITEM = 2
    LISTING = 3
    OFFER = 4
    FOLDER = 5
    PACKET = 6
    MANUAL_ENTRY = 7
    NOTIFICATION = 8
    AGENT = 9

    _VALUES_TO_NAMES = {
        0: "DOCUMENT",
        1: "COMMISSION",
        2: "CHECKLIST_ITEM",
        3: "LISTING",
        4: "OFFER",
        5: "FOLDER",
        6: "PACKET",
        7: "MANUAL_ENTRY",
        8: "NOTIFICATION",
        9: "AGENT",
    }

    _NAMES_TO_VALUES = {
        "DOCUMENT": 0,
        "COMMISSION": 1,
        "CHECKLIST_ITEM": 2,
        "LISTING": 3,
        "OFFER": 4,
        "FOLDER": 5,
        "PACKET": 6,
        "MANUAL_ENTRY": 7,
        "NOTIFICATION": 8,
        "AGENT": 9,
    }


class DiffElement(object):
    """
    Attributes:
     - field
     - prettyFieldName
     - prevValue
     - newValue
     - format
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'field', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'prettyFieldName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'prevValue', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'newValue', 'UTF8', None, ),  # 4
        (5, TType.I32, 'format', None, None, ),  # 5
    )
    def __init__(self, field=None, prettyFieldName=None, prevValue=None, newValue=None, format=None, ):
        self.field = field
        self.prettyFieldName = prettyFieldName
        self.prevValue = prevValue
        self.newValue = newValue
        self.format = format

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.field = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.prettyFieldName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.prevValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.newValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.format = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DiffElement')
        if self.field is not None:
            oprot.writeFieldBegin('field', TType.STRING, 1)
            oprot.writeString(self.field.encode('utf-8') if sys.version_info[0] == 2 else self.field)
            oprot.writeFieldEnd()
        if self.prettyFieldName is not None:
            oprot.writeFieldBegin('prettyFieldName', TType.STRING, 2)
            oprot.writeString(self.prettyFieldName.encode('utf-8') if sys.version_info[0] == 2 else self.prettyFieldName)
            oprot.writeFieldEnd()
        if self.prevValue is not None:
            oprot.writeFieldBegin('prevValue', TType.STRING, 3)
            oprot.writeString(self.prevValue.encode('utf-8') if sys.version_info[0] == 2 else self.prevValue)
            oprot.writeFieldEnd()
        if self.newValue is not None:
            oprot.writeFieldBegin('newValue', TType.STRING, 4)
            oprot.writeString(self.newValue.encode('utf-8') if sys.version_info[0] == 2 else self.newValue)
            oprot.writeFieldEnd()
        if self.format is not None:
            oprot.writeFieldBegin('format', TType.I32, 5)
            oprot.writeI32(self.format)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
