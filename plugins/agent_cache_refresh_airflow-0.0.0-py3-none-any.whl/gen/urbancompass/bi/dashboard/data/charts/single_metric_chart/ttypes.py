
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes

from thrift.transport import TTransport


class SingleMetricChart(object):
    """
    Attributes:
     - title
     - titleDescription
     - valueSeriesRef
     - comparisonValueSeriesRef
     - description
     - icon
     - titleForReport
     - emptyView
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'titleDescription', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'valueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'comparisonValueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'description', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'icon', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'titleForReport', 'UTF8', None, ),  # 7
        (8, TType.STRUCT, 'emptyView', (gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView, gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView.thrift_spec), None, ),  # 8
    )
    def __init__(self, title=None, titleDescription=None, valueSeriesRef=None, comparisonValueSeriesRef=None, description=None, icon=None, titleForReport=None, emptyView=None, ):
        self.title = title
        self.titleDescription = titleDescription
        self.valueSeriesRef = valueSeriesRef
        self.comparisonValueSeriesRef = comparisonValueSeriesRef
        self.description = description
        self.icon = icon
        self.titleForReport = titleForReport
        self.emptyView = emptyView

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.titleDescription = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.valueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.valueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.comparisonValueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.comparisonValueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.icon = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.titleForReport = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.emptyView = gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView()
                    self.emptyView.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SingleMetricChart')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.titleDescription is not None:
            oprot.writeFieldBegin('titleDescription', TType.STRING, 2)
            oprot.writeString(self.titleDescription.encode('utf-8') if sys.version_info[0] == 2 else self.titleDescription)
            oprot.writeFieldEnd()
        if self.valueSeriesRef is not None:
            oprot.writeFieldBegin('valueSeriesRef', TType.STRUCT, 3)
            self.valueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.comparisonValueSeriesRef is not None:
            oprot.writeFieldBegin('comparisonValueSeriesRef', TType.STRUCT, 4)
            self.comparisonValueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 5)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.icon is not None:
            oprot.writeFieldBegin('icon', TType.STRING, 6)
            oprot.writeString(self.icon.encode('utf-8') if sys.version_info[0] == 2 else self.icon)
            oprot.writeFieldEnd()
        if self.titleForReport is not None:
            oprot.writeFieldBegin('titleForReport', TType.STRING, 7)
            oprot.writeString(self.titleForReport.encode('utf-8') if sys.version_info[0] == 2 else self.titleForReport)
            oprot.writeFieldEnd()
        if self.emptyView is not None:
            oprot.writeFieldBegin('emptyView', TType.STRUCT, 8)
            self.emptyView.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
