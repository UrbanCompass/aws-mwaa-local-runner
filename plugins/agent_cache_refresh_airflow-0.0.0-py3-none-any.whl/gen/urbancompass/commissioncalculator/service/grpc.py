# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.agent_data_platform.commissionable_terms.model.comm_terms.ttypes as comm_terms
import gen.urbancompass.deals_platform.common.netsuite_model.ttypes as netsuite_model
import uc.grpc.codec as _grpc_codec



class CommissioncalculatorServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.calculateCommission = channel.unary_unary(
        '/CommissioncalculatorService/calculateCommission',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CalculateCommissionResponse),
        )
    self.calculateCommissionPreview = channel.unary_unary(
        '/CommissioncalculatorService/calculateCommissionPreview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CalculateCommissionPreviewResponse),
        )
    self.healthCheck = channel.unary_unary(
        '/CommissioncalculatorService/healthCheck',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(HealthCheckResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class CommissioncalculatorServiceServicer(BaseServiceServicer):
  """
    The CommissioncalculatorService Service definition
  """

  def calculateCommission(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def calculateCommissionPreview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def healthCheck(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_CommissioncalculatorServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'calculateCommission': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.calculateCommission(req),
          request_deserializer=_grpc_codec.deserializer(CalculateCommissionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionPreview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.calculateCommissionPreview(req),
          request_deserializer=_grpc_codec.deserializer(CalculateCommissionPreviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'healthCheck': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.healthCheck(req),
          request_deserializer=_grpc_codec.deserializer(HealthCheckRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'CommissioncalculatorService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_CommissioncalculatorServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'calculateCommission': grpc.unary_unary_rpc_method_handler(
          servicer.calculateCommission,
          request_deserializer=_grpc_codec.deserializer(CalculateCommissionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionPreview': grpc.unary_unary_rpc_method_handler(
          servicer.calculateCommissionPreview,
          request_deserializer=_grpc_codec.deserializer(CalculateCommissionPreviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'healthCheck': grpc.unary_unary_rpc_method_handler(
          servicer.healthCheck,
          request_deserializer=_grpc_codec.deserializer(HealthCheckRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'CommissioncalculatorService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

