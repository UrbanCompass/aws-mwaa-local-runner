
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class CustomizedFormatter(object):
    MINUTE_SECOND_TIME_FORMATTER = 0
    DETAIL_LINK_FORMATTER = 1

    _VALUES_TO_NAMES = {
        0: "MINUTE_SECOND_TIME_FORMATTER",
        1: "DETAIL_LINK_FORMATTER",
    }

    _NAMES_TO_VALUES = {
        "MINUTE_SECOND_TIME_FORMATTER": 0,
        "DETAIL_LINK_FORMATTER": 1,
    }


class DateDisplayStyle(object):
    YEAR = 0
    MONTH = 1
    WEEK = 2
    DAY = 3

    _VALUES_TO_NAMES = {
        0: "YEAR",
        1: "MONTH",
        2: "WEEK",
        3: "DAY",
    }

    _NAMES_TO_VALUES = {
        "YEAR": 0,
        "MONTH": 1,
        "WEEK": 2,
        "DAY": 3,
    }


class NumberDisplayStyle(object):
    NUMBER = 0
    PERCENTAGE = 1

    _VALUES_TO_NAMES = {
        0: "NUMBER",
        1: "PERCENTAGE",
    }

    _NAMES_TO_VALUES = {
        "NUMBER": 0,
        "PERCENTAGE": 1,
    }


class DateFormat(object):
    """
    Attributes:
     - displayStyle
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'displayStyle', None, None, ),  # 1
    )
    def __init__(self, displayStyle=None, ):
        self.displayStyle = displayStyle

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.displayStyle = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DateFormat')
        if self.displayStyle is not None:
            oprot.writeFieldBegin('displayStyle', TType.I32, 1)
            oprot.writeI32(self.displayStyle)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DoNotDisplayFormat(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DoNotDisplayFormat')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MoneyFormat(object):
    """
    Attributes:
     - displayPrecision
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'displayPrecision', None, None, ),  # 1
    )
    def __init__(self, displayPrecision=None, ):
        self.displayPrecision = displayPrecision

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.displayPrecision = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MoneyFormat')
        if self.displayPrecision is not None:
            oprot.writeFieldBegin('displayPrecision', TType.I32, 1)
            oprot.writeI32(self.displayPrecision)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NumberFormat(object):
    """
    Attributes:
     - displayPrecision
     - displayStyle
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'displayPrecision', None, None, ),  # 1
        (2, TType.I32, 'displayStyle', None, None, ),  # 2
    )
    def __init__(self, displayPrecision=None, displayStyle=None, ):
        self.displayPrecision = displayPrecision
        self.displayStyle = displayStyle

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.displayPrecision = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.displayStyle = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NumberFormat')
        if self.displayPrecision is not None:
            oprot.writeFieldBegin('displayPrecision', TType.I32, 1)
            oprot.writeI32(self.displayPrecision)
            oprot.writeFieldEnd()
        if self.displayStyle is not None:
            oprot.writeFieldBegin('displayStyle', TType.I32, 2)
            oprot.writeI32(self.displayStyle)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StringFormat(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StringFormat')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ValueFormat(object):
    """
    Attributes:
     - dateFormat
     - numberFormat
     - stringFormat
     - doNotDisplayFormat
     - customizedFormatter
     - moneyFormat
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dateFormat', (DateFormat, DateFormat.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'numberFormat', (NumberFormat, NumberFormat.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'stringFormat', (StringFormat, StringFormat.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'doNotDisplayFormat', (DoNotDisplayFormat, DoNotDisplayFormat.thrift_spec), None, ),  # 4
        (5, TType.I32, 'customizedFormatter', None, None, ),  # 5
        (6, TType.STRUCT, 'moneyFormat', (MoneyFormat, MoneyFormat.thrift_spec), None, ),  # 6
    )
    def __init__(self, dateFormat=None, numberFormat=None, stringFormat=None, doNotDisplayFormat=None, customizedFormatter=None, moneyFormat=None, ):
        self.dateFormat = dateFormat
        self.numberFormat = numberFormat
        self.stringFormat = stringFormat
        self.doNotDisplayFormat = doNotDisplayFormat
        self.customizedFormatter = customizedFormatter
        self.moneyFormat = moneyFormat

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dateFormat = DateFormat()
                    self.dateFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.numberFormat = NumberFormat()
                    self.numberFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.stringFormat = StringFormat()
                    self.stringFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.doNotDisplayFormat = DoNotDisplayFormat()
                    self.doNotDisplayFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.customizedFormatter = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.moneyFormat = MoneyFormat()
                    self.moneyFormat.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ValueFormat')
        if self.dateFormat is not None:
            oprot.writeFieldBegin('dateFormat', TType.STRUCT, 1)
            self.dateFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.numberFormat is not None:
            oprot.writeFieldBegin('numberFormat', TType.STRUCT, 2)
            self.numberFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.stringFormat is not None:
            oprot.writeFieldBegin('stringFormat', TType.STRUCT, 3)
            self.stringFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.doNotDisplayFormat is not None:
            oprot.writeFieldBegin('doNotDisplayFormat', TType.STRUCT, 4)
            self.doNotDisplayFormat.write(oprot)
            oprot.writeFieldEnd()
        if self.customizedFormatter is not None:
            oprot.writeFieldBegin('customizedFormatter', TType.I32, 5)
            oprot.writeI32(self.customizedFormatter)
            oprot.writeFieldEnd()
        if self.moneyFormat is not None:
            oprot.writeFieldBegin('moneyFormat', TType.STRUCT, 6)
            self.moneyFormat.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
