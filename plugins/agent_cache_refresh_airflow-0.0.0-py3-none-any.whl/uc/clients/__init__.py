# -*- coding: utf-8 -*-
"""
This module provides methods for configuring thrift clients via command line options.

Use add_args to register necessary configuration arguments, then create a thrift client
factory with the resulting parsed args.

    import base.app
    from uc import clients

    def main(options, args):
      factory = clients.GrpcClientFactory(options)

    if __name__ == '__main__':
      clients.add_args(base.app.parser)
      base.app.run(main)

:copyright: (c) 2021 by Urban Compass, Inc.
"""

from uc.clients.factory import add_args, GrpcClientFactory
