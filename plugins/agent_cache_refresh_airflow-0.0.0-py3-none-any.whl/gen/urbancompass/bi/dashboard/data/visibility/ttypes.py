
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.responsive.ttypes

from thrift.transport import TTransport


class AppVersionVisibility(object):
    """
    Attributes:
     - minVersion
     - maxVersion
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'minVersion', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'maxVersion', 'UTF8', None, ),  # 2
    )
    def __init__(self, minVersion=None, maxVersion=None, ):
        self.minVersion = minVersion
        self.maxVersion = maxVersion

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.minVersion = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.maxVersion = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AppVersionVisibility')
        if self.minVersion is not None:
            oprot.writeFieldBegin('minVersion', TType.STRING, 1)
            oprot.writeString(self.minVersion.encode('utf-8') if sys.version_info[0] == 2 else self.minVersion)
            oprot.writeFieldEnd()
        if self.maxVersion is not None:
            oprot.writeFieldBegin('maxVersion', TType.STRING, 2)
            oprot.writeString(self.maxVersion.encode('utf-8') if sys.version_info[0] == 2 else self.maxVersion)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MobileDisplaySettings(object):
    """
    Attributes:
    """

    thrift_spec = (
    )

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MobileDisplaySettings')
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class WebDisplaySettings(object):
    """
    Attributes:
     - visible
     - width
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'visible', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateBoolValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateBoolValueSet.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'width', (gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet, gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet.thrift_spec), None, ),  # 2
    )
    def __init__(self, visible=None, width=None, ):
        self.visible = visible
        self.width = width

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.visible = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateBoolValueSet()
                    self.visible.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.width = gen.urbancompass.bi.dashboard.data.responsive.ttypes.ResponsiveStateIntegerValueSet()
                    self.width.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('WebDisplaySettings')
        if self.visible is not None:
            oprot.writeFieldBegin('visible', TType.STRUCT, 1)
            self.visible.write(oprot)
            oprot.writeFieldEnd()
        if self.width is not None:
            oprot.writeFieldBegin('width', TType.STRUCT, 2)
            self.width.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FrontendDisplaySettings(object):
    """
    Attributes:
     - web
     - mobile
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'web', (WebDisplaySettings, WebDisplaySettings.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'mobile', (MobileDisplaySettings, MobileDisplaySettings.thrift_spec), None, ),  # 2
    )
    def __init__(self, web=None, mobile=None, ):
        self.web = web
        self.mobile = mobile

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.web = WebDisplaySettings()
                    self.web.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.mobile = MobileDisplaySettings()
                    self.mobile.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FrontendDisplaySettings')
        if self.web is not None:
            oprot.writeFieldBegin('web', TType.STRUCT, 1)
            self.web.write(oprot)
            oprot.writeFieldEnd()
        if self.mobile is not None:
            oprot.writeFieldBegin('mobile', TType.STRUCT, 2)
            self.mobile.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class VersionVisibility(object):
    """
    Attributes:
     - mobile
     - web
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'mobile', (AppVersionVisibility, AppVersionVisibility.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'web', (AppVersionVisibility, AppVersionVisibility.thrift_spec), None, ),  # 2
    )
    def __init__(self, mobile=None, web=None, ):
        self.mobile = mobile
        self.web = web

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.mobile = AppVersionVisibility()
                    self.mobile.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.web = AppVersionVisibility()
                    self.web.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('VersionVisibility')
        if self.mobile is not None:
            oprot.writeFieldBegin('mobile', TType.STRUCT, 1)
            self.mobile.write(oprot)
            oprot.writeFieldEnd()
        if self.web is not None:
            oprot.writeFieldBegin('web', TType.STRUCT, 2)
            self.web.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class VisibilitySettings(object):
    """
    Attributes:
     - hideOnEmptyData
     - hideControlReference
     - hideOnMobileApp
     - hideOnWebApp
     - hideOnWebAppMobileState
     - displayOnEmptyDashboard
     - versionBasedVisibility
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'hideOnEmptyData', None, None, ),  # 1
        (2, TType.STRUCT, 'hideControlReference', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'hideOnMobileApp', None, None, ),  # 3
        (4, TType.BOOL, 'hideOnWebApp', None, None, ),  # 4
        (5, TType.BOOL, 'hideOnWebAppMobileState', None, None, ),  # 5
        (6, TType.BOOL, 'displayOnEmptyDashboard', None, None, ),  # 6
        (7, TType.STRUCT, 'versionBasedVisibility', (VersionVisibility, VersionVisibility.thrift_spec), None, ),  # 7
    )
    def __init__(self, hideOnEmptyData=None, hideControlReference=None, hideOnMobileApp=None, hideOnWebApp=None, hideOnWebAppMobileState=None, displayOnEmptyDashboard=None, versionBasedVisibility=None, ):
        self.hideOnEmptyData = hideOnEmptyData
        self.hideControlReference = hideControlReference
        self.hideOnMobileApp = hideOnMobileApp
        self.hideOnWebApp = hideOnWebApp
        self.hideOnWebAppMobileState = hideOnWebAppMobileState
        self.displayOnEmptyDashboard = displayOnEmptyDashboard
        self.versionBasedVisibility = versionBasedVisibility

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.hideOnEmptyData = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.hideControlReference = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.hideControlReference.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hideOnMobileApp = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.hideOnWebApp = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.hideOnWebAppMobileState = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.displayOnEmptyDashboard = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.versionBasedVisibility = VersionVisibility()
                    self.versionBasedVisibility.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('VisibilitySettings')
        if self.hideOnEmptyData is not None:
            oprot.writeFieldBegin('hideOnEmptyData', TType.BOOL, 1)
            oprot.writeBool(self.hideOnEmptyData)
            oprot.writeFieldEnd()
        if self.hideControlReference is not None:
            oprot.writeFieldBegin('hideControlReference', TType.STRUCT, 2)
            self.hideControlReference.write(oprot)
            oprot.writeFieldEnd()
        if self.hideOnMobileApp is not None:
            oprot.writeFieldBegin('hideOnMobileApp', TType.BOOL, 3)
            oprot.writeBool(self.hideOnMobileApp)
            oprot.writeFieldEnd()
        if self.hideOnWebApp is not None:
            oprot.writeFieldBegin('hideOnWebApp', TType.BOOL, 4)
            oprot.writeBool(self.hideOnWebApp)
            oprot.writeFieldEnd()
        if self.hideOnWebAppMobileState is not None:
            oprot.writeFieldBegin('hideOnWebAppMobileState', TType.BOOL, 5)
            oprot.writeBool(self.hideOnWebAppMobileState)
            oprot.writeFieldEnd()
        if self.displayOnEmptyDashboard is not None:
            oprot.writeFieldBegin('displayOnEmptyDashboard', TType.BOOL, 6)
            oprot.writeBool(self.displayOnEmptyDashboard)
            oprot.writeFieldEnd()
        if self.versionBasedVisibility is not None:
            oprot.writeFieldBegin('versionBasedVisibility', TType.STRUCT, 7)
            self.versionBasedVisibility.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
