# -*- coding: utf-8 -*-
"""
Please do not use classes in this file directly, rather instantiate them using
base.monitoring.annotations

This is legacy code. Annotations are known as Events in Datadog.

:copyright: (c) 2016 by UrbanCompass, Inc.
"""

import logging
import time


class Annotation(object):
    """
    An annotation is a Librato-specific type of measurement, similar to a Timer.

    On creation, it starts a local timer.

    It provides a stop() function that can only be used once. This 'closes' the annotation and
    submits it's data via all reporters
    """

    def __init__(self, name, reporters):
        if reporters is None:
            raise ValueError("Reporters must be a list of reporters, not None")
        self._name = name
        self._start_time = time.time()
        self._reporters = reporters
        self.closed = False

    def stop(self):
        if self.closed:
            raise AssertionError("Annotation {} has already been stopped".format(self._name))
        self.closed = True
        for r in self._reporters:
            r.closed = True
            r.report_annotation()


class AnnotationReporter(object):
    """Base class for reporting Annotations"""

    def report_annotation(self):
        """Send an annotation event"""
        pass


class LoggingAnnotationReporter(AnnotationReporter):
    """Logs annotation data to logging.info"""

    def __init__(self, name, log_level="INFO"):
        self._name = name
        self._start_time = time.time()
        self._end_time = None
        self._log_level = logging.getLevelName(log_level)

    def report_annotation(self):
        self._end_time = time.time()
        delta = self._end_time - self._start_time
        logging.log(self._log_level, "{} started at {}".format(self._name, self._start_time))
        logging.log(self._log_level, "{} finished at {}".format(self._name, self._end_time))
        logging.log(self._log_level, "{} lasted for {} seconds".format(self._name, delta))
