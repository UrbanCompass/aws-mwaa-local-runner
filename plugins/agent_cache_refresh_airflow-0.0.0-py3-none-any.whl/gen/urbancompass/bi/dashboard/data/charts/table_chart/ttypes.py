
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.analytics.ttypes
import gen.urbancompass.bi.dashboard.data.charts.chart_settings.ttypes
import gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes
import gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes
import gen.urbancompass.bi.dashboard.data.visibility.ttypes
import gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes

from thrift.transport import TTransport


class SortDirection(object):
    ASC = 0
    DESC = 1

    _VALUES_TO_NAMES = {
        0: "ASC",
        1: "DESC",
    }

    _NAMES_TO_VALUES = {
        "ASC": 0,
        "DESC": 1,
    }


class NumberColumn(object):
    """
    Attributes:
     - valueSeriesRef
     - secondaryTextSeriesRef
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'valueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'secondaryTextSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
    )
    def __init__(self, valueSeriesRef=None, secondaryTextSeriesRef=None, ):
        self.valueSeriesRef = valueSeriesRef
        self.secondaryTextSeriesRef = secondaryTextSeriesRef

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.valueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.valueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.secondaryTextSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.secondaryTextSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NumberColumn')
        if self.valueSeriesRef is not None:
            oprot.writeFieldBegin('valueSeriesRef', TType.STRUCT, 1)
            self.valueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.secondaryTextSeriesRef is not None:
            oprot.writeFieldBegin('secondaryTextSeriesRef', TType.STRUCT, 2)
            self.secondaryTextSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PlotColumn(object):
    """
    Attributes:
     - xyChartItem
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'xyChartItem', (gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes.XYChartItem, gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes.XYChartItem.thrift_spec), None, ),  # 1
    )
    def __init__(self, xyChartItem=None, ):
        self.xyChartItem = xyChartItem

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.xyChartItem = gen.urbancompass.bi.dashboard.data.charts.xy_chart.ttypes.XYChartItem()
                    self.xyChartItem.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PlotColumn')
        if self.xyChartItem is not None:
            oprot.writeFieldBegin('xyChartItem', TType.STRUCT, 1)
            self.xyChartItem.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StringColumn(object):
    """
    Attributes:
     - valueSeriesRef
     - secondaryTextSeriesRef
     - analyticsInformation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'valueSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'secondaryTextSeriesRef', (gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef, gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'analyticsInformation', (gen.urbancompass.bi.dashboard.data.analytics.ttypes.AnalyticsInformation, gen.urbancompass.bi.dashboard.data.analytics.ttypes.AnalyticsInformation.thrift_spec), None, ),  # 3
    )
    def __init__(self, valueSeriesRef=None, secondaryTextSeriesRef=None, analyticsInformation=None, ):
        self.valueSeriesRef = valueSeriesRef
        self.secondaryTextSeriesRef = secondaryTextSeriesRef
        self.analyticsInformation = analyticsInformation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.valueSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.valueSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.secondaryTextSeriesRef = gen.urbancompass.bi.dashboard.data.drilldownable_series_ref.ttypes.DrilldownableSeriesRef()
                    self.secondaryTextSeriesRef.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.analyticsInformation = gen.urbancompass.bi.dashboard.data.analytics.ttypes.AnalyticsInformation()
                    self.analyticsInformation.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StringColumn')
        if self.valueSeriesRef is not None:
            oprot.writeFieldBegin('valueSeriesRef', TType.STRUCT, 1)
            self.valueSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.secondaryTextSeriesRef is not None:
            oprot.writeFieldBegin('secondaryTextSeriesRef', TType.STRUCT, 2)
            self.secondaryTextSeriesRef.write(oprot)
            oprot.writeFieldEnd()
        if self.analyticsInformation is not None:
            oprot.writeFieldBegin('analyticsInformation', TType.STRUCT, 3)
            self.analyticsInformation.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TableColumnHeader(object):
    """
    Attributes:
     - text
     - displaySettings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'text', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'displaySettings', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings.thrift_spec), None, ),  # 2
    )
    def __init__(self, text=None, displaySettings=None, ):
        self.text = text
        self.displaySettings = displaySettings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.text = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.displaySettings = gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings()
                    self.displaySettings.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TableColumnHeader')
        if self.text is not None:
            oprot.writeFieldBegin('text', TType.STRING, 1)
            oprot.writeString(self.text.encode('utf-8') if sys.version_info[0] == 2 else self.text)
            oprot.writeFieldEnd()
        if self.displaySettings is not None:
            oprot.writeFieldBegin('displaySettings', TType.STRUCT, 2)
            self.displaySettings.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TableSortBy(object):
    """
    Attributes:
     - columnName
     - direction
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'columnName', 'UTF8', None, ),  # 1
        (2, TType.I32, 'direction', None, None, ),  # 2
    )
    def __init__(self, columnName=None, direction=None, ):
        self.columnName = columnName
        self.direction = direction

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.columnName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.direction = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TableSortBy')
        if self.columnName is not None:
            oprot.writeFieldBegin('columnName', TType.STRING, 1)
            oprot.writeString(self.columnName.encode('utf-8') if sys.version_info[0] == 2 else self.columnName)
            oprot.writeFieldEnd()
        if self.direction is not None:
            oprot.writeFieldBegin('direction', TType.I32, 2)
            oprot.writeI32(self.direction)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TableColumnType(object):
    """
    Attributes:
     - numberColumn
     - stringColumn
     - plotColumn
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'numberColumn', (NumberColumn, NumberColumn.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'stringColumn', (StringColumn, StringColumn.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'plotColumn', (PlotColumn, PlotColumn.thrift_spec), None, ),  # 3
    )
    def __init__(self, numberColumn=None, stringColumn=None, plotColumn=None, ):
        self.numberColumn = numberColumn
        self.stringColumn = stringColumn
        self.plotColumn = plotColumn

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.numberColumn = NumberColumn()
                    self.numberColumn.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.stringColumn = StringColumn()
                    self.stringColumn.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.plotColumn = PlotColumn()
                    self.plotColumn.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TableColumnType')
        if self.numberColumn is not None:
            oprot.writeFieldBegin('numberColumn', TType.STRUCT, 1)
            self.numberColumn.write(oprot)
            oprot.writeFieldEnd()
        if self.stringColumn is not None:
            oprot.writeFieldBegin('stringColumn', TType.STRUCT, 2)
            self.stringColumn.write(oprot)
            oprot.writeFieldEnd()
        if self.plotColumn is not None:
            oprot.writeFieldBegin('plotColumn', TType.STRUCT, 3)
            self.plotColumn.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TableColumn(object):
    """
    Attributes:
     - name
     - column
     - visibility
     - header
     - displaySettings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'column', (TableColumnType, TableColumnType.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'visibility', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'header', (TableColumnHeader, TableColumnHeader.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'displaySettings', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings.thrift_spec), None, ),  # 5
    )
    def __init__(self, name=None, column=None, visibility=None, header=None, displaySettings=None, ):
        self.name = name
        self.column = column
        self.visibility = visibility
        self.header = header
        self.displaySettings = displaySettings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.column = TableColumnType()
                    self.column.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.visibility = gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings()
                    self.visibility.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.header = TableColumnHeader()
                    self.header.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.displaySettings = gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings()
                    self.displaySettings.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TableColumn')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.column is not None:
            oprot.writeFieldBegin('column', TType.STRUCT, 2)
            self.column.write(oprot)
            oprot.writeFieldEnd()
        if self.visibility is not None:
            oprot.writeFieldBegin('visibility', TType.STRUCT, 3)
            self.visibility.write(oprot)
            oprot.writeFieldEnd()
        if self.header is not None:
            oprot.writeFieldBegin('header', TType.STRUCT, 4)
            self.header.write(oprot)
            oprot.writeFieldEnd()
        if self.displaySettings is not None:
            oprot.writeFieldBegin('displaySettings', TType.STRUCT, 5)
            self.displaySettings.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TableChart(object):
    """
    Attributes:
     - title
     - columns
     - headerRowDisplay
     - sortBy
     - description
     - icon
     - titleForReport
     - emptyView
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'columns', (TType.STRUCT, (TableColumn, TableColumn.thrift_spec), False), None, ),  # 2
        (3, TType.STRUCT, 'headerRowDisplay', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'sortBy', (TableSortBy, TableSortBy.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'description', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'icon', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'titleForReport', 'UTF8', None, ),  # 7
        (8, TType.STRUCT, 'emptyView', (gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView, gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView.thrift_spec), None, ),  # 8
    )
    def __init__(self, title=None, columns=None, headerRowDisplay=None, sortBy=None, description=None, icon=None, titleForReport=None, emptyView=None, ):
        self.title = title
        self.columns = columns
        self.headerRowDisplay = headerRowDisplay
        self.sortBy = sortBy
        self.description = description
        self.icon = icon
        self.titleForReport = titleForReport
        self.emptyView = emptyView

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.columns = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = TableColumn()
                        _elem4.read(iprot)
                        self.columns.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.headerRowDisplay = gen.urbancompass.bi.dashboard.data.visibility.ttypes.FrontendDisplaySettings()
                    self.headerRowDisplay.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.sortBy = TableSortBy()
                    self.sortBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.icon = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.titleForReport = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.emptyView = gen.urbancompass.bi.dashboard.data.charts.empty_view.ttypes.EmptyView()
                    self.emptyView.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TableChart')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.columns is not None:
            oprot.writeFieldBegin('columns', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.columns))
            for _iter6 in self.columns:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.headerRowDisplay is not None:
            oprot.writeFieldBegin('headerRowDisplay', TType.STRUCT, 3)
            self.headerRowDisplay.write(oprot)
            oprot.writeFieldEnd()
        if self.sortBy is not None:
            oprot.writeFieldBegin('sortBy', TType.STRUCT, 4)
            self.sortBy.write(oprot)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 5)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.icon is not None:
            oprot.writeFieldBegin('icon', TType.STRING, 6)
            oprot.writeString(self.icon.encode('utf-8') if sys.version_info[0] == 2 else self.icon)
            oprot.writeFieldEnd()
        if self.titleForReport is not None:
            oprot.writeFieldBegin('titleForReport', TType.STRING, 7)
            oprot.writeString(self.titleForReport.encode('utf-8') if sys.version_info[0] == 2 else self.titleForReport)
            oprot.writeFieldEnd()
        if self.emptyView is not None:
            oprot.writeFieldBegin('emptyView', TType.STRUCT, 8)
            self.emptyView.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
