# -*- coding: utf-8 -*-
"""
:copyright: (c) 2017 by Urban Compass, Inc.
"""


class RpcError(Exception):
    def __init__(self, *args, **kwargs):
        """Create an RpcError.

        :param *args: Exception constuctor parameters.
        :param **kwargs: Some kwargs are consumed by the RpcError:
          rpc_client: The rpc client that originated this exception.
          All other kwargs are passed to the exception constructor.
        """
        self._rpc_client = kwargs.pop("rpc_client", None)
        if kwargs:
            args_list = list(args)
            args_list.append(kwargs)
            args = tuple(args_list)
        super(RpcError, self).__init__(*args)

    def __str__(self):
        if self._rpc_client is None:
            return super(RpcError, self).__str__()
        else:
            return "<%s, %r>" % (super(RpcError, self).__str__(), self._rpc_client)

    def __repr__(self):
        if self._rpc_client is None:
            return super(RpcError, self).__repr__()
        else:
            return "%s:<%s, %r>" % (
                self.__class__.__name__,
                super(RpcError, self).__str__(),
                self._rpc_client,
            )
