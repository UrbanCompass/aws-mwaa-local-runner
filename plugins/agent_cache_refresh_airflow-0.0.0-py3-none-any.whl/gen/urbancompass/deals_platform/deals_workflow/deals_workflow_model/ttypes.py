
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals_platform.common.auth.ttypes
import gen.urbancompass.commissioncalculator.service.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.cash_management.funds.funds_model.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.deals_platform.common.netsuite_model.ttypes

from thrift.transport import TTransport


class CdaStatus(object):
    PENDING_CS_REVIEW = 0
    PENDING_AGENT_REVIEW = 1
    APPROVED_FOR_TITLE = 2
    SENT_TO_TITLE = 3
    EDIT_REQUESTED = 4

    _VALUES_TO_NAMES = {
        0: "PENDING_CS_REVIEW",
        1: "PENDING_AGENT_REVIEW",
        2: "APPROVED_FOR_TITLE",
        3: "SENT_TO_TITLE",
        4: "EDIT_REQUESTED",
    }

    _NAMES_TO_VALUES = {
        "PENDING_CS_REVIEW": 0,
        "PENDING_AGENT_REVIEW": 1,
        "APPROVED_FOR_TITLE": 2,
        "SENT_TO_TITLE": 3,
        "EDIT_REQUESTED": 4,
    }


class DealAccessLevel(object):
    TESTING = 0
    READ_ONLY = 1
    READ_WRITE = 2
    HYBRID = 3

    _VALUES_TO_NAMES = {
        0: "TESTING",
        1: "READ_ONLY",
        2: "READ_WRITE",
        3: "HYBRID",
    }

    _NAMES_TO_VALUES = {
        "TESTING": 0,
        "READ_ONLY": 1,
        "READ_WRITE": 2,
        "HYBRID": 3,
    }


class DealPaymentStatus(object):
    APPROVED_FOR_PAYMENT = 0
    ERROR = 1
    PARTIALLY_PAID = 2
    PAID = 3
    ON_HOLD = 4

    _VALUES_TO_NAMES = {
        0: "APPROVED_FOR_PAYMENT",
        1: "ERROR",
        2: "PARTIALLY_PAID",
        3: "PAID",
        4: "ON_HOLD",
    }

    _NAMES_TO_VALUES = {
        "APPROVED_FOR_PAYMENT": 0,
        "ERROR": 1,
        "PARTIALLY_PAID": 2,
        "PAID": 3,
        "ON_HOLD": 4,
    }


class DealStatus(object):
    OPEN = 0
    NEEDS_FINAL_REVIEW = 1
    NEEDS_CS_REVIEW = 2
    IN_FINAL_REVIEW = 3
    IN_CS_REVIEW = 4
    SENT_TO_GL = 5
    GL_POSTED = 6
    VOID = 7
    PAID = 8
    POST_TO_GL_FAILED = 9
    GL_POSTED_WITH_AR_BALANCES = 10
    GL_POSTED_WITH_OUT_AR_BALANCES = 11
    IN_POST_TRANSACTION_EDIT = 12
    DRAFT = 13
    NEEDS_MANAGER_APPROVAL = 14
    WITHDRAWN = 15

    _VALUES_TO_NAMES = {
        0: "OPEN",
        1: "NEEDS_FINAL_REVIEW",
        2: "NEEDS_CS_REVIEW",
        3: "IN_FINAL_REVIEW",
        4: "IN_CS_REVIEW",
        5: "SENT_TO_GL",
        6: "GL_POSTED",
        7: "VOID",
        8: "PAID",
        9: "POST_TO_GL_FAILED",
        10: "GL_POSTED_WITH_AR_BALANCES",
        11: "GL_POSTED_WITH_OUT_AR_BALANCES",
        12: "IN_POST_TRANSACTION_EDIT",
        13: "DRAFT",
        14: "NEEDS_MANAGER_APPROVAL",
        15: "WITHDRAWN",
    }

    _NAMES_TO_VALUES = {
        "OPEN": 0,
        "NEEDS_FINAL_REVIEW": 1,
        "NEEDS_CS_REVIEW": 2,
        "IN_FINAL_REVIEW": 3,
        "IN_CS_REVIEW": 4,
        "SENT_TO_GL": 5,
        "GL_POSTED": 6,
        "VOID": 7,
        "PAID": 8,
        "POST_TO_GL_FAILED": 9,
        "GL_POSTED_WITH_AR_BALANCES": 10,
        "GL_POSTED_WITH_OUT_AR_BALANCES": 11,
        "IN_POST_TRANSACTION_EDIT": 12,
        "DRAFT": 13,
        "NEEDS_MANAGER_APPROVAL": 14,
        "WITHDRAWN": 15,
    }


class DealType(object):
    PRIMARY_DEAL = 0
    INTERNAL_REFERRAL = 1
    INCOMING_EXTERNAL_REFERRAL = 2
    OUTGOING_EXTERNAL_REFERRAL = 3

    _VALUES_TO_NAMES = {
        0: "PRIMARY_DEAL",
        1: "INTERNAL_REFERRAL",
        2: "INCOMING_EXTERNAL_REFERRAL",
        3: "OUTGOING_EXTERNAL_REFERRAL",
    }

    _NAMES_TO_VALUES = {
        "PRIMARY_DEAL": 0,
        "INTERNAL_REFERRAL": 1,
        "INCOMING_EXTERNAL_REFERRAL": 2,
        "OUTGOING_EXTERNAL_REFERRAL": 3,
    }


class FeeName(object):
    OTHER = 0
    ADMIN_FEE = 1
    APPROVED_BROKER_FEE_CONCESSION = 2
    UNAPPROVED_BROKER_FEE_CONCESSION = 3
    CONTRACT_TO_CLOSE_FEE = 4
    FLAT_FEE_COLLECTED_FROM_CLIENT = 5
    FLAT_FEE_PAID_TO_AGENT = 6
    FLAT_FEE_PAID_BY_AGENT = 7
    PASS_THROUGH_COLLECTING_FROM_AGENT = 8
    PASS_THROUGH_TO_AGENT = 9
    PASS_THROUGH_TO_ONE_AGENT = 10
    PASS_THROUGH_TO_THIRD_PARTY = 11
    WIRE_FEE_PAID_BY_COMPASS = 12
    WIRE_FEE_PAID_BY_AGENT = 13
    INTERNAL_REFERRAL = 14
    EXTERNAL_REFERRAL = 15
    HAMPTONS_LISTING_FEE = 16
    CONVEYANCE_FEE_PAID_BY_COMPASS = 17
    CONVEYANCE_FEE_PAID_TO_AGENT = 18
    NJ_MLS_FEE = 19
    RESOURCE_FEE = 20
    CONTRACT_TO_CLOSE_FEE_PAID_BY_CLIENT = 21
    CONVEYANCE_FEE_PAID_BY_CLIENT = 22
    CONVEYANCE_FEE_PAID_BY_AGENT = 23
    PERSONAL_TRANSACTION_FEE = 24
    CONTRACT_TO_CLOSE_COMPLIANCE_PLUS = 25
    CONTRACT_TO_CLOSE_FULL_SERVICE = 26
    COOP_FEE_COLLECTED_FROM_CLIENT = 27
    COOP_FEE_COLLECTED_FROM_AGENT = 28
    COMPASS_LISTING_FEE_COLLECTED_FROM_CLIENT = 29
    COMPASS_LISTING_FEE_COLLECTED_FROM_AGENT = 30
    GENERAL_EXCISE_TAX_COLLECTED_BY_CLIENT = 31
    COOP_FEE_PAID_TO_THIRD_PARTY = 32
    SCRIVENER_FEE = 33

    _VALUES_TO_NAMES = {
        0: "OTHER",
        1: "ADMIN_FEE",
        2: "APPROVED_BROKER_FEE_CONCESSION",
        3: "UNAPPROVED_BROKER_FEE_CONCESSION",
        4: "CONTRACT_TO_CLOSE_FEE",
        5: "FLAT_FEE_COLLECTED_FROM_CLIENT",
        6: "FLAT_FEE_PAID_TO_AGENT",
        7: "FLAT_FEE_PAID_BY_AGENT",
        8: "PASS_THROUGH_COLLECTING_FROM_AGENT",
        9: "PASS_THROUGH_TO_AGENT",
        10: "PASS_THROUGH_TO_ONE_AGENT",
        11: "PASS_THROUGH_TO_THIRD_PARTY",
        12: "WIRE_FEE_PAID_BY_COMPASS",
        13: "WIRE_FEE_PAID_BY_AGENT",
        14: "INTERNAL_REFERRAL",
        15: "EXTERNAL_REFERRAL",
        16: "HAMPTONS_LISTING_FEE",
        17: "CONVEYANCE_FEE_PAID_BY_COMPASS",
        18: "CONVEYANCE_FEE_PAID_TO_AGENT",
        19: "NJ_MLS_FEE",
        20: "RESOURCE_FEE",
        21: "CONTRACT_TO_CLOSE_FEE_PAID_BY_CLIENT",
        22: "CONVEYANCE_FEE_PAID_BY_CLIENT",
        23: "CONVEYANCE_FEE_PAID_BY_AGENT",
        24: "PERSONAL_TRANSACTION_FEE",
        25: "CONTRACT_TO_CLOSE_COMPLIANCE_PLUS",
        26: "CONTRACT_TO_CLOSE_FULL_SERVICE",
        27: "COOP_FEE_COLLECTED_FROM_CLIENT",
        28: "COOP_FEE_COLLECTED_FROM_AGENT",
        29: "COMPASS_LISTING_FEE_COLLECTED_FROM_CLIENT",
        30: "COMPASS_LISTING_FEE_COLLECTED_FROM_AGENT",
        31: "GENERAL_EXCISE_TAX_COLLECTED_BY_CLIENT",
        32: "COOP_FEE_PAID_TO_THIRD_PARTY",
        33: "SCRIVENER_FEE",
    }

    _NAMES_TO_VALUES = {
        "OTHER": 0,
        "ADMIN_FEE": 1,
        "APPROVED_BROKER_FEE_CONCESSION": 2,
        "UNAPPROVED_BROKER_FEE_CONCESSION": 3,
        "CONTRACT_TO_CLOSE_FEE": 4,
        "FLAT_FEE_COLLECTED_FROM_CLIENT": 5,
        "FLAT_FEE_PAID_TO_AGENT": 6,
        "FLAT_FEE_PAID_BY_AGENT": 7,
        "PASS_THROUGH_COLLECTING_FROM_AGENT": 8,
        "PASS_THROUGH_TO_AGENT": 9,
        "PASS_THROUGH_TO_ONE_AGENT": 10,
        "PASS_THROUGH_TO_THIRD_PARTY": 11,
        "WIRE_FEE_PAID_BY_COMPASS": 12,
        "WIRE_FEE_PAID_BY_AGENT": 13,
        "INTERNAL_REFERRAL": 14,
        "EXTERNAL_REFERRAL": 15,
        "HAMPTONS_LISTING_FEE": 16,
        "CONVEYANCE_FEE_PAID_BY_COMPASS": 17,
        "CONVEYANCE_FEE_PAID_TO_AGENT": 18,
        "NJ_MLS_FEE": 19,
        "RESOURCE_FEE": 20,
        "CONTRACT_TO_CLOSE_FEE_PAID_BY_CLIENT": 21,
        "CONVEYANCE_FEE_PAID_BY_CLIENT": 22,
        "CONVEYANCE_FEE_PAID_BY_AGENT": 23,
        "PERSONAL_TRANSACTION_FEE": 24,
        "CONTRACT_TO_CLOSE_COMPLIANCE_PLUS": 25,
        "CONTRACT_TO_CLOSE_FULL_SERVICE": 26,
        "COOP_FEE_COLLECTED_FROM_CLIENT": 27,
        "COOP_FEE_COLLECTED_FROM_AGENT": 28,
        "COMPASS_LISTING_FEE_COLLECTED_FROM_CLIENT": 29,
        "COMPASS_LISTING_FEE_COLLECTED_FROM_AGENT": 30,
        "GENERAL_EXCISE_TAX_COLLECTED_BY_CLIENT": 31,
        "COOP_FEE_PAID_TO_THIRD_PARTY": 32,
        "SCRIVENER_FEE": 33,
    }


class HoldReason(object):
    OTHERS = 0
    DOCS_ISSUE = 1
    FUNDS_ISSUE = 2
    AGENT_CONTRACT_ISSUE = 3
    PENDING_AGENT = 4
    PENDING_SM = 5
    PENDING_PRODUCT_SUPPORT = 6
    REJECTED_BY_CS = 7
    RENTAL_COMMUNITY = 8
    LEAD_PAINT_FORM_MISSING = 9
    W9_INCOMPLETE = 10
    MISSING_REFERRAL_W9_AGREEMENT = 11
    CO_BROKE_W9 = 12
    PASS_THROUGH_INFORMATION = 13

    _VALUES_TO_NAMES = {
        0: "OTHERS",
        1: "DOCS_ISSUE",
        2: "FUNDS_ISSUE",
        3: "AGENT_CONTRACT_ISSUE",
        4: "PENDING_AGENT",
        5: "PENDING_SM",
        6: "PENDING_PRODUCT_SUPPORT",
        7: "REJECTED_BY_CS",
        8: "RENTAL_COMMUNITY",
        9: "LEAD_PAINT_FORM_MISSING",
        10: "W9_INCOMPLETE",
        11: "MISSING_REFERRAL_W9_AGREEMENT",
        12: "CO_BROKE_W9",
        13: "PASS_THROUGH_INFORMATION",
    }

    _NAMES_TO_VALUES = {
        "OTHERS": 0,
        "DOCS_ISSUE": 1,
        "FUNDS_ISSUE": 2,
        "AGENT_CONTRACT_ISSUE": 3,
        "PENDING_AGENT": 4,
        "PENDING_SM": 5,
        "PENDING_PRODUCT_SUPPORT": 6,
        "REJECTED_BY_CS": 7,
        "RENTAL_COMMUNITY": 8,
        "LEAD_PAINT_FORM_MISSING": 9,
        "W9_INCOMPLETE": 10,
        "MISSING_REFERRAL_W9_AGREEMENT": 11,
        "CO_BROKE_W9": 12,
        "PASS_THROUGH_INFORMATION": 13,
    }


class NoteType(object):
    CDA = 0
    DEAL = 1

    _VALUES_TO_NAMES = {
        0: "CDA",
        1: "DEAL",
    }

    _NAMES_TO_VALUES = {
        "CDA": 0,
        "DEAL": 1,
    }


class SplitOverrideReason(object):
    OTHER = 0
    LEAD_EXCEPTION = 1
    SPLIT_EXCEPTION = 2
    INCREASED_SPLIT_PER_ICA = 3
    PERSONAL_TRANSACTION = 4
    TEAM_WITH_COMPASS_EMPLOYEE = 5
    SALES_MANAGER_REFERRAL = 6
    AGENT_REPRESENT_COMPASS_EMPLOYEE = 7

    _VALUES_TO_NAMES = {
        0: "OTHER",
        1: "LEAD_EXCEPTION",
        2: "SPLIT_EXCEPTION",
        3: "INCREASED_SPLIT_PER_ICA",
        4: "PERSONAL_TRANSACTION",
        5: "TEAM_WITH_COMPASS_EMPLOYEE",
        6: "SALES_MANAGER_REFERRAL",
        7: "AGENT_REPRESENT_COMPASS_EMPLOYEE",
    }

    _NAMES_TO_VALUES = {
        "OTHER": 0,
        "LEAD_EXCEPTION": 1,
        "SPLIT_EXCEPTION": 2,
        "INCREASED_SPLIT_PER_ICA": 3,
        "PERSONAL_TRANSACTION": 4,
        "TEAM_WITH_COMPASS_EMPLOYEE": 5,
        "SALES_MANAGER_REFERRAL": 6,
        "AGENT_REPRESENT_COMPASS_EMPLOYEE": 7,
    }


class VoidReason(object):
    OTHERS = 0
    DEAL_FELL_OUT_OF_CONTRACT = 1
    DEAL_IS_INVALID = 2
    PRIMARY_VOIDED = 3
    REMOVED_FROM_PRIMARY = 4
    DUPLICATE_DEALS_PAID = 5
    DEAL_RECEIVE_NO_BROKER_FEE = 6

    _VALUES_TO_NAMES = {
        0: "OTHERS",
        1: "DEAL_FELL_OUT_OF_CONTRACT",
        2: "DEAL_IS_INVALID",
        3: "PRIMARY_VOIDED",
        4: "REMOVED_FROM_PRIMARY",
        5: "DUPLICATE_DEALS_PAID",
        6: "DEAL_RECEIVE_NO_BROKER_FEE",
    }

    _NAMES_TO_VALUES = {
        "OTHERS": 0,
        "DEAL_FELL_OUT_OF_CONTRACT": 1,
        "DEAL_IS_INVALID": 2,
        "PRIMARY_VOIDED": 3,
        "REMOVED_FROM_PRIMARY": 4,
        "DUPLICATE_DEALS_PAID": 5,
        "DEAL_RECEIVE_NO_BROKER_FEE": 6,
    }


class AgentAmaInfo(object):
    """
    Attributes:
     - agentName
     - teamName
     - sensitivity
     - officeName
     - market
     - subMarket
     - nsOfficeLocation
     - nsSubMarketSubsidiary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'agentName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'teamName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'sensitivity', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'officeName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'market', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'subMarket', 'UTF8', None, ),  # 6
        (7, TType.I32, 'nsOfficeLocation', None, None, ),  # 7
        (8, TType.I32, 'nsSubMarketSubsidiary', None, None, ),  # 8
    )
    def __init__(self, agentName=None, teamName=None, sensitivity=None, officeName=None, market=None, subMarket=None, nsOfficeLocation=None, nsSubMarketSubsidiary=None, ):
        self.agentName = agentName
        self.teamName = teamName
        self.sensitivity = sensitivity
        self.officeName = officeName
        self.market = market
        self.subMarket = subMarket
        self.nsOfficeLocation = nsOfficeLocation
        self.nsSubMarketSubsidiary = nsSubMarketSubsidiary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.teamName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.sensitivity = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.officeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.subMarket = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.nsOfficeLocation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.nsSubMarketSubsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentAmaInfo')
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 1)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.teamName is not None:
            oprot.writeFieldBegin('teamName', TType.STRING, 2)
            oprot.writeString(self.teamName.encode('utf-8') if sys.version_info[0] == 2 else self.teamName)
            oprot.writeFieldEnd()
        if self.sensitivity is not None:
            oprot.writeFieldBegin('sensitivity', TType.STRING, 3)
            oprot.writeString(self.sensitivity.encode('utf-8') if sys.version_info[0] == 2 else self.sensitivity)
            oprot.writeFieldEnd()
        if self.officeName is not None:
            oprot.writeFieldBegin('officeName', TType.STRING, 4)
            oprot.writeString(self.officeName.encode('utf-8') if sys.version_info[0] == 2 else self.officeName)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 5)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.subMarket is not None:
            oprot.writeFieldBegin('subMarket', TType.STRING, 6)
            oprot.writeString(self.subMarket.encode('utf-8') if sys.version_info[0] == 2 else self.subMarket)
            oprot.writeFieldEnd()
        if self.nsOfficeLocation is not None:
            oprot.writeFieldBegin('nsOfficeLocation', TType.I32, 7)
            oprot.writeI32(self.nsOfficeLocation)
            oprot.writeFieldEnd()
        if self.nsSubMarketSubsidiary is not None:
            oprot.writeFieldBegin('nsSubMarketSubsidiary', TType.I32, 8)
            oprot.writeI32(self.nsSubMarketSubsidiary)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EntityPaymentSummary(object):
    """
    Attributes:
     - dmsTransactionId
     - entityId
     - totalInvoice
     - totalCredited
     - totalPaid
     - status
     - updateTimestamp
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'entityId', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'totalInvoice', None, None, ),  # 3
        (4, TType.DOUBLE, 'totalCredited', None, None, ),  # 4
        (5, TType.DOUBLE, 'totalPaid', None, None, ),  # 5
        (6, TType.I32, 'status', None, None, ),  # 6
        (7, TType.I64, 'updateTimestamp', None, None, ),  # 7
    )
    def __init__(self, dmsTransactionId=None, entityId=None, totalInvoice=None, totalCredited=None, totalPaid=None, status=None, updateTimestamp=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.entityId = entityId
        self.totalInvoice = totalInvoice
        self.totalCredited = totalCredited
        self.totalPaid = totalPaid
        self.status = status
        self.updateTimestamp = updateTimestamp

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.entityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.totalInvoice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.totalCredited = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.totalPaid = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updateTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EntityPaymentSummary')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.entityId is not None:
            oprot.writeFieldBegin('entityId', TType.STRING, 2)
            oprot.writeString(self.entityId.encode('utf-8') if sys.version_info[0] == 2 else self.entityId)
            oprot.writeFieldEnd()
        if self.totalInvoice is not None:
            oprot.writeFieldBegin('totalInvoice', TType.DOUBLE, 3)
            oprot.writeDouble(self.totalInvoice)
            oprot.writeFieldEnd()
        if self.totalCredited is not None:
            oprot.writeFieldBegin('totalCredited', TType.DOUBLE, 4)
            oprot.writeDouble(self.totalCredited)
            oprot.writeFieldEnd()
        if self.totalPaid is not None:
            oprot.writeFieldBegin('totalPaid', TType.DOUBLE, 5)
            oprot.writeDouble(self.totalPaid)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 6)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.updateTimestamp is not None:
            oprot.writeFieldBegin('updateTimestamp', TType.I64, 7)
            oprot.writeI64(self.updateTimestamp)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EscrowCompanyLocation(object):
    """
    Attributes:
     - street
     - city
     - state
     - zipCode
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'street', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'city', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'zipCode', 'UTF8', None, ),  # 4
    )
    def __init__(self, street=None, city=None, state=None, zipCode=None, ):
        self.street = street
        self.city = city
        self.state = state
        self.zipCode = zipCode

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.street = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EscrowCompanyLocation')
        if self.street is not None:
            oprot.writeFieldBegin('street', TType.STRING, 1)
            oprot.writeString(self.street.encode('utf-8') if sys.version_info[0] == 2 else self.street)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 2)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 4)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExternalIds(object):
    """
    Attributes:
     - businessTrackerFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'businessTrackerFolderId', 'UTF8', None, ),  # 1
    )
    def __init__(self, businessTrackerFolderId=None, ):
        self.businessTrackerFolderId = businessTrackerFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.businessTrackerFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExternalIds')
        if self.businessTrackerFolderId is not None:
            oprot.writeFieldBegin('businessTrackerFolderId', TType.STRING, 1)
            oprot.writeString(self.businessTrackerFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.businessTrackerFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class HawaiiTaxFee(object):
    """
    Attributes:
     - generalExciseTaxFeeApplicable
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'generalExciseTaxFeeApplicable', None, None, ),  # 1
    )
    def __init__(self, generalExciseTaxFeeApplicable=None, ):
        self.generalExciseTaxFeeApplicable = generalExciseTaxFeeApplicable

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.generalExciseTaxFeeApplicable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('HawaiiTaxFee')
        if self.generalExciseTaxFeeApplicable is not None:
            oprot.writeFieldBegin('generalExciseTaxFeeApplicable', TType.BOOL, 1)
            oprot.writeBool(self.generalExciseTaxFeeApplicable)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PercentOrAmount(object):
    """
    Attributes:
     - percent
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percent', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, percent=None, amount=None, ):
        self.percent = percent
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PercentOrAmount')
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 1)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PersonInfo(object):
    """
    Attributes:
     - displayName
     - email
     - firstName
     - lastName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'displayName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'firstName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'lastName', 'UTF8', None, ),  # 4
    )
    def __init__(self, displayName=None, email=None, firstName=None, lastName=None, ):
        self.displayName = displayName
        self.email = email
        self.firstName = firstName
        self.lastName = lastName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PersonInfo')
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 1)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 3)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 4)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralAccounting(object):
    """
    Attributes:
     - invoices
     - vendorBills
     - agentPayoutSummaries
     - dealGci
     - accountingError
     - referralType
     - accountingSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'invoices', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.Invoice, gen.urbancompass.commissioncalculator.service.ttypes.Invoice.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'vendorBills', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.VendorBill, gen.urbancompass.commissioncalculator.service.ttypes.VendorBill.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'agentPayoutSummaries', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.AgentPayoutSummary, gen.urbancompass.commissioncalculator.service.ttypes.AgentPayoutSummary.thrift_spec), False), None, ),  # 3
        (4, TType.DOUBLE, 'dealGci', None, None, ),  # 4
        (5, TType.STRUCT, 'accountingError', (gen.urbancompass.commissioncalculator.service.ttypes.AreError, gen.urbancompass.commissioncalculator.service.ttypes.AreError.thrift_spec), None, ),  # 5
        (6, TType.I32, 'referralType', None, None, ),  # 6
        (7, TType.STRUCT, 'accountingSummary', (gen.urbancompass.commissioncalculator.service.ttypes.AccountingSummary, gen.urbancompass.commissioncalculator.service.ttypes.AccountingSummary.thrift_spec), None, ),  # 7
    )
    def __init__(self, invoices=None, vendorBills=None, agentPayoutSummaries=None, dealGci=None, accountingError=None, referralType=None, accountingSummary=None, ):
        self.invoices = invoices
        self.vendorBills = vendorBills
        self.agentPayoutSummaries = agentPayoutSummaries
        self.dealGci = dealGci
        self.accountingError = accountingError
        self.referralType = referralType
        self.accountingSummary = accountingSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.invoices = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.commissioncalculator.service.ttypes.Invoice()
                        _elem4.read(iprot)
                        self.invoices.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.vendorBills = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = gen.urbancompass.commissioncalculator.service.ttypes.VendorBill()
                        _elem8.read(iprot)
                        self.vendorBills.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.agentPayoutSummaries = []
                    (_etype10, _size13) = iprot.readListBegin()
                    for _i11 in range(_size13):
                        _elem12 = gen.urbancompass.commissioncalculator.service.ttypes.AgentPayoutSummary()
                        _elem12.read(iprot)
                        self.agentPayoutSummaries.append(_elem12)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.dealGci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.accountingError = gen.urbancompass.commissioncalculator.service.ttypes.AreError()
                    self.accountingError.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.accountingSummary = gen.urbancompass.commissioncalculator.service.ttypes.AccountingSummary()
                    self.accountingSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralAccounting')
        if self.invoices is not None:
            oprot.writeFieldBegin('invoices', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.invoices))
            for _iter14 in self.invoices:
                _iter14.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.vendorBills is not None:
            oprot.writeFieldBegin('vendorBills', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.vendorBills))
            for _iter15 in self.vendorBills:
                _iter15.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentPayoutSummaries is not None:
            oprot.writeFieldBegin('agentPayoutSummaries', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.agentPayoutSummaries))
            for _iter16 in self.agentPayoutSummaries:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dealGci is not None:
            oprot.writeFieldBegin('dealGci', TType.DOUBLE, 4)
            oprot.writeDouble(self.dealGci)
            oprot.writeFieldEnd()
        if self.accountingError is not None:
            oprot.writeFieldBegin('accountingError', TType.STRUCT, 5)
            self.accountingError.write(oprot)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 6)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        if self.accountingSummary is not None:
            oprot.writeFieldBegin('accountingSummary', TType.STRUCT, 7)
            self.accountingSummary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralCommission(object):
    """
    Attributes:
     - agentCommissions
     - agentFees
     - input
     - calculationError
     - referralType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'agentCommissions', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.AgentCommission, gen.urbancompass.commissioncalculator.service.ttypes.AgentCommission.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'agentFees', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.AgentFee, gen.urbancompass.commissioncalculator.service.ttypes.AgentFee.thrift_spec), False), None, ),  # 2
        (3, TType.STRUCT, 'input', (gen.urbancompass.commissioncalculator.service.ttypes.CalculateCommissionInput, gen.urbancompass.commissioncalculator.service.ttypes.CalculateCommissionInput.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'calculationError', (gen.urbancompass.commissioncalculator.service.ttypes.CceError, gen.urbancompass.commissioncalculator.service.ttypes.CceError.thrift_spec), None, ),  # 4
        (5, TType.I32, 'referralType', None, None, ),  # 5
    )
    def __init__(self, agentCommissions=None, agentFees=None, input=None, calculationError=None, referralType=None, ):
        self.agentCommissions = agentCommissions
        self.agentFees = agentFees
        self.input = input
        self.calculationError = calculationError
        self.referralType = referralType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.agentCommissions = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = gen.urbancompass.commissioncalculator.service.ttypes.AgentCommission()
                        _elem19.read(iprot)
                        self.agentCommissions.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.agentFees = []
                    (_etype21, _size24) = iprot.readListBegin()
                    for _i22 in range(_size24):
                        _elem23 = gen.urbancompass.commissioncalculator.service.ttypes.AgentFee()
                        _elem23.read(iprot)
                        self.agentFees.append(_elem23)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.input = gen.urbancompass.commissioncalculator.service.ttypes.CalculateCommissionInput()
                    self.input.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.calculationError = gen.urbancompass.commissioncalculator.service.ttypes.CceError()
                    self.calculationError.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralCommission')
        if self.agentCommissions is not None:
            oprot.writeFieldBegin('agentCommissions', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.agentCommissions))
            for _iter25 in self.agentCommissions:
                _iter25.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentFees is not None:
            oprot.writeFieldBegin('agentFees', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.agentFees))
            for _iter26 in self.agentFees:
                _iter26.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.input is not None:
            oprot.writeFieldBegin('input', TType.STRUCT, 3)
            self.input.write(oprot)
            oprot.writeFieldEnd()
        if self.calculationError is not None:
            oprot.writeFieldBegin('calculationError', TType.STRUCT, 4)
            self.calculationError.write(oprot)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 5)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SplitOverride(object):
    """
    Attributes:
     - baseSplit
     - incentiveSplit
     - reason
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'baseSplit', None, None, ),  # 1
        (2, TType.DOUBLE, 'incentiveSplit', None, None, ),  # 2
        (3, TType.I32, 'reason', None, None, ),  # 3
    )
    def __init__(self, baseSplit=None, incentiveSplit=None, reason=None, ):
        self.baseSplit = baseSplit
        self.incentiveSplit = incentiveSplit
        self.reason = reason

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.baseSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.incentiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.reason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SplitOverride')
        if self.baseSplit is not None:
            oprot.writeFieldBegin('baseSplit', TType.DOUBLE, 1)
            oprot.writeDouble(self.baseSplit)
            oprot.writeFieldEnd()
        if self.incentiveSplit is not None:
            oprot.writeFieldBegin('incentiveSplit', TType.DOUBLE, 2)
            oprot.writeDouble(self.incentiveSplit)
            oprot.writeFieldEnd()
        if self.reason is not None:
            oprot.writeFieldBegin('reason', TType.I32, 3)
            oprot.writeI32(self.reason)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamAmaInfo(object):
    """
    Attributes:
     - amaCompassTeamId
     - teamName
     - sensitivity
     - officeName
     - market
     - subMarket
     - nsOfficeLocation
     - nsSubMarketSubsidiary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'amaCompassTeamId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'teamName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'sensitivity', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'officeName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'market', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'subMarket', 'UTF8', None, ),  # 6
        (7, TType.I32, 'nsOfficeLocation', None, None, ),  # 7
        (8, TType.I32, 'nsSubMarketSubsidiary', None, None, ),  # 8
    )
    def __init__(self, amaCompassTeamId=None, teamName=None, sensitivity=None, officeName=None, market=None, subMarket=None, nsOfficeLocation=None, nsSubMarketSubsidiary=None, ):
        self.amaCompassTeamId = amaCompassTeamId
        self.teamName = teamName
        self.sensitivity = sensitivity
        self.officeName = officeName
        self.market = market
        self.subMarket = subMarket
        self.nsOfficeLocation = nsOfficeLocation
        self.nsSubMarketSubsidiary = nsSubMarketSubsidiary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.amaCompassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.teamName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.sensitivity = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.officeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.subMarket = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.nsOfficeLocation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.nsSubMarketSubsidiary = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamAmaInfo')
        if self.amaCompassTeamId is not None:
            oprot.writeFieldBegin('amaCompassTeamId', TType.STRING, 1)
            oprot.writeString(self.amaCompassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.amaCompassTeamId)
            oprot.writeFieldEnd()
        if self.teamName is not None:
            oprot.writeFieldBegin('teamName', TType.STRING, 2)
            oprot.writeString(self.teamName.encode('utf-8') if sys.version_info[0] == 2 else self.teamName)
            oprot.writeFieldEnd()
        if self.sensitivity is not None:
            oprot.writeFieldBegin('sensitivity', TType.STRING, 3)
            oprot.writeString(self.sensitivity.encode('utf-8') if sys.version_info[0] == 2 else self.sensitivity)
            oprot.writeFieldEnd()
        if self.officeName is not None:
            oprot.writeFieldBegin('officeName', TType.STRING, 4)
            oprot.writeString(self.officeName.encode('utf-8') if sys.version_info[0] == 2 else self.officeName)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 5)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.subMarket is not None:
            oprot.writeFieldBegin('subMarket', TType.STRING, 6)
            oprot.writeString(self.subMarket.encode('utf-8') if sys.version_info[0] == 2 else self.subMarket)
            oprot.writeFieldEnd()
        if self.nsOfficeLocation is not None:
            oprot.writeFieldBegin('nsOfficeLocation', TType.I32, 7)
            oprot.writeI32(self.nsOfficeLocation)
            oprot.writeFieldEnd()
        if self.nsSubMarketSubsidiary is not None:
            oprot.writeFieldBegin('nsSubMarketSubsidiary', TType.I32, 8)
            oprot.writeI32(self.nsSubMarketSubsidiary)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionAmount(object):
    """
    Attributes:
     - transactionId
     - appliedAmount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'transactionId', None, None, ),  # 1
        (2, TType.DOUBLE, 'appliedAmount', None, None, ),  # 2
    )
    def __init__(self, transactionId=None, appliedAmount=None, ):
        self.transactionId = transactionId
        self.appliedAmount = appliedAmount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.transactionId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.appliedAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionAmount')
        if self.transactionId is not None:
            oprot.writeFieldBegin('transactionId', TType.I64, 1)
            oprot.writeI64(self.transactionId)
            oprot.writeFieldEnd()
        if self.appliedAmount is not None:
            oprot.writeFieldBegin('appliedAmount', TType.DOUBLE, 2)
            oprot.writeDouble(self.appliedAmount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AccountingInfo(object):
    """
    Attributes:
     - calculatedAt
     - invoices
     - vendorBills
     - effectiveSplit
     - dealGci
     - agentPayoutSummaries
     - referralAccounting
     - accountingError
     - accountingSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'calculatedAt', None, None, ),  # 1
        (2, TType.LIST, 'invoices', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.Invoice, gen.urbancompass.commissioncalculator.service.ttypes.Invoice.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'vendorBills', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.VendorBill, gen.urbancompass.commissioncalculator.service.ttypes.VendorBill.thrift_spec), False), None, ),  # 3
        (4, TType.DOUBLE, 'effectiveSplit', None, None, ),  # 4
        (5, TType.DOUBLE, 'dealGci', None, None, ),  # 5
        (6, TType.LIST, 'agentPayoutSummaries', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.AgentPayoutSummary, gen.urbancompass.commissioncalculator.service.ttypes.AgentPayoutSummary.thrift_spec), False), None, ),  # 6
        (7, TType.STRUCT, 'accountingError', (gen.urbancompass.commissioncalculator.service.ttypes.AreError, gen.urbancompass.commissioncalculator.service.ttypes.AreError.thrift_spec), None, ),  # 7
        (8, TType.LIST, 'referralAccounting', (TType.STRUCT, (ReferralAccounting, ReferralAccounting.thrift_spec), False), None, ),  # 8
        (9, TType.STRUCT, 'accountingSummary', (gen.urbancompass.commissioncalculator.service.ttypes.AccountingSummary, gen.urbancompass.commissioncalculator.service.ttypes.AccountingSummary.thrift_spec), None, ),  # 9
    )
    def __init__(self, calculatedAt=None, invoices=None, vendorBills=None, effectiveSplit=None, dealGci=None, agentPayoutSummaries=None, accountingError=None, referralAccounting=None, accountingSummary=None, ):
        self.calculatedAt = calculatedAt
        self.invoices = invoices
        self.vendorBills = vendorBills
        self.effectiveSplit = effectiveSplit
        self.dealGci = dealGci
        self.agentPayoutSummaries = agentPayoutSummaries
        self.accountingError = accountingError
        self.referralAccounting = referralAccounting
        self.accountingSummary = accountingSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.calculatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.invoices = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = gen.urbancompass.commissioncalculator.service.ttypes.Invoice()
                        _elem29.read(iprot)
                        self.invoices.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.vendorBills = []
                    (_etype31, _size34) = iprot.readListBegin()
                    for _i32 in range(_size34):
                        _elem33 = gen.urbancompass.commissioncalculator.service.ttypes.VendorBill()
                        _elem33.read(iprot)
                        self.vendorBills.append(_elem33)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.effectiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.dealGci = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.agentPayoutSummaries = []
                    (_etype35, _size38) = iprot.readListBegin()
                    for _i36 in range(_size38):
                        _elem37 = gen.urbancompass.commissioncalculator.service.ttypes.AgentPayoutSummary()
                        _elem37.read(iprot)
                        self.agentPayoutSummaries.append(_elem37)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.accountingError = gen.urbancompass.commissioncalculator.service.ttypes.AreError()
                    self.accountingError.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.referralAccounting = []
                    (_etype39, _size42) = iprot.readListBegin()
                    for _i40 in range(_size42):
                        _elem41 = ReferralAccounting()
                        _elem41.read(iprot)
                        self.referralAccounting.append(_elem41)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.accountingSummary = gen.urbancompass.commissioncalculator.service.ttypes.AccountingSummary()
                    self.accountingSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AccountingInfo')
        if self.calculatedAt is not None:
            oprot.writeFieldBegin('calculatedAt', TType.I64, 1)
            oprot.writeI64(self.calculatedAt)
            oprot.writeFieldEnd()
        if self.invoices is not None:
            oprot.writeFieldBegin('invoices', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.invoices))
            for _iter43 in self.invoices:
                _iter43.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.vendorBills is not None:
            oprot.writeFieldBegin('vendorBills', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.vendorBills))
            for _iter44 in self.vendorBills:
                _iter44.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.effectiveSplit is not None:
            oprot.writeFieldBegin('effectiveSplit', TType.DOUBLE, 4)
            oprot.writeDouble(self.effectiveSplit)
            oprot.writeFieldEnd()
        if self.dealGci is not None:
            oprot.writeFieldBegin('dealGci', TType.DOUBLE, 5)
            oprot.writeDouble(self.dealGci)
            oprot.writeFieldEnd()
        if self.agentPayoutSummaries is not None:
            oprot.writeFieldBegin('agentPayoutSummaries', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.agentPayoutSummaries))
            for _iter45 in self.agentPayoutSummaries:
                _iter45.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.accountingError is not None:
            oprot.writeFieldBegin('accountingError', TType.STRUCT, 7)
            self.accountingError.write(oprot)
            oprot.writeFieldEnd()
        if self.referralAccounting is not None:
            oprot.writeFieldBegin('referralAccounting', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.referralAccounting))
            for _iter46 in self.referralAccounting:
                _iter46.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.accountingSummary is not None:
            oprot.writeFieldBegin('accountingSummary', TType.STRUCT, 9)
            self.accountingSummary.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Agent(object):
    """
    Attributes:
     - userId
     - teamId
     - info
     - amaId
     - amaCompassTeamId
     - agentAmaInfo
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'teamId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'info', (PersonInfo, PersonInfo.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'amaId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'amaCompassTeamId', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'agentAmaInfo', (AgentAmaInfo, AgentAmaInfo.thrift_spec), None, ),  # 6
        (7, TType.STRING, 'status', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, teamId=None, info=None, amaId=None, amaCompassTeamId=None, agentAmaInfo=None, status=None, ):
        self.userId = userId
        self.teamId = teamId
        self.info = info
        self.amaId = amaId
        self.amaCompassTeamId = amaCompassTeamId
        self.agentAmaInfo = agentAmaInfo
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.info = PersonInfo()
                    self.info.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.amaCompassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.agentAmaInfo = AgentAmaInfo()
                    self.agentAmaInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.status = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Agent')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 2)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.info is not None:
            oprot.writeFieldBegin('info', TType.STRUCT, 3)
            self.info.write(oprot)
            oprot.writeFieldEnd()
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 4)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.amaCompassTeamId is not None:
            oprot.writeFieldBegin('amaCompassTeamId', TType.STRING, 5)
            oprot.writeString(self.amaCompassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.amaCompassTeamId)
            oprot.writeFieldEnd()
        if self.agentAmaInfo is not None:
            oprot.writeFieldBegin('agentAmaInfo', TType.STRUCT, 6)
            self.agentAmaInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRING, 7)
            oprot.writeString(self.status.encode('utf-8') if sys.version_info[0] == 2 else self.status)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AppliedTransactionAmount(object):
    """
    Attributes:
     - amaId
     - transactions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'amaId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'transactions', (TType.STRUCT, (TransactionAmount, TransactionAmount.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, amaId=None, transactions=None, ):
        self.amaId = amaId
        self.transactions = transactions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.amaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.transactions = []
                    (_etype47, _size50) = iprot.readListBegin()
                    for _i48 in range(_size50):
                        _elem49 = TransactionAmount()
                        _elem49.read(iprot)
                        self.transactions.append(_elem49)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AppliedTransactionAmount')
        if self.amaId is not None:
            oprot.writeFieldBegin('amaId', TType.STRING, 1)
            oprot.writeString(self.amaId.encode('utf-8') if sys.version_info[0] == 2 else self.amaId)
            oprot.writeFieldEnd()
        if self.transactions is not None:
            oprot.writeFieldBegin('transactions', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.transactions))
            for _iter51 in self.transactions:
                _iter51.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AuthRecord(object):
    """
    Attributes:
     - userId
     - timeMs
     - info
     - roles
     - groups
     - impersonatorId
     - impersonatorInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'timeMs', None, None, ),  # 2
        (3, TType.STRUCT, 'info', (PersonInfo, PersonInfo.thrift_spec), None, ),  # 3
        (4, TType.SET, 'roles', (TType.STRUCT, (gen.urbancompass.deals_platform.common.auth.ttypes.Role, gen.urbancompass.deals_platform.common.auth.ttypes.Role.thrift_spec), False), None, ),  # 4
        (5, TType.SET, 'groups', (TType.STRUCT, (gen.urbancompass.deals_platform.common.auth.ttypes.Group, gen.urbancompass.deals_platform.common.auth.ttypes.Group.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'impersonatorInfo', (PersonInfo, PersonInfo.thrift_spec), None, ),  # 7
    )
    def __init__(self, userId=None, timeMs=None, info=None, roles=None, groups=None, impersonatorId=None, impersonatorInfo=None, ):
        self.userId = userId
        self.timeMs = timeMs
        self.info = info
        self.roles = roles
        self.groups = groups
        self.impersonatorId = impersonatorId
        self.impersonatorInfo = impersonatorInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.timeMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.info = PersonInfo()
                    self.info.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.SET:
                    self.roles = set()
                    (_etype53, _size55) = iprot.readSetBegin()
                    for _i52 in range(_size55):
                        _elem54 = gen.urbancompass.deals_platform.common.auth.ttypes.Role()
                        _elem54.read(iprot)
                        self.roles.add(_elem54)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.SET:
                    self.groups = set()
                    (_etype57, _size59) = iprot.readSetBegin()
                    for _i56 in range(_size59):
                        _elem58 = gen.urbancompass.deals_platform.common.auth.ttypes.Group()
                        _elem58.read(iprot)
                        self.groups.add(_elem58)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.impersonatorInfo = PersonInfo()
                    self.impersonatorInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AuthRecord')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.timeMs is not None:
            oprot.writeFieldBegin('timeMs', TType.I64, 2)
            oprot.writeI64(self.timeMs)
            oprot.writeFieldEnd()
        if self.info is not None:
            oprot.writeFieldBegin('info', TType.STRUCT, 3)
            self.info.write(oprot)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.SET, 4)
            oprot.writeSetBegin(TType.STRUCT, len(self.roles))
            for _iter60 in self.roles:
                _iter60.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.groups is not None:
            oprot.writeFieldBegin('groups', TType.SET, 5)
            oprot.writeSetBegin(TType.STRUCT, len(self.groups))
            for _iter61 in self.groups:
                _iter61.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.impersonatorInfo is not None:
            oprot.writeFieldBegin('impersonatorInfo', TType.STRUCT, 7)
            self.impersonatorInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommissionInfo(object):
    """
    Attributes:
     - calculatedAt
     - revenue
     - agentCommissions
     - agentFees
     - entities
     - input
     - effectiveSplit
     - referralCommission
     - calculationError
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'calculatedAt', None, None, ),  # 1
        (2, TType.DOUBLE, 'revenue', None, None, ),  # 2
        (3, TType.LIST, 'agentCommissions', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.AgentCommission, gen.urbancompass.commissioncalculator.service.ttypes.AgentCommission.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'agentFees', (TType.STRUCT, (gen.urbancompass.commissioncalculator.service.ttypes.AgentFee, gen.urbancompass.commissioncalculator.service.ttypes.AgentFee.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'entities', (gen.urbancompass.commissioncalculator.service.ttypes.EntityGroupsWrapper, gen.urbancompass.commissioncalculator.service.ttypes.EntityGroupsWrapper.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'input', (gen.urbancompass.commissioncalculator.service.ttypes.CalculateCommissionInput, gen.urbancompass.commissioncalculator.service.ttypes.CalculateCommissionInput.thrift_spec), None, ),  # 6
        (7, TType.DOUBLE, 'effectiveSplit', None, None, ),  # 7
        (8, TType.STRUCT, 'calculationError', (gen.urbancompass.commissioncalculator.service.ttypes.CceError, gen.urbancompass.commissioncalculator.service.ttypes.CceError.thrift_spec), None, ),  # 8
        (9, TType.LIST, 'referralCommission', (TType.STRUCT, (ReferralCommission, ReferralCommission.thrift_spec), False), None, ),  # 9
    )
    def __init__(self, calculatedAt=None, revenue=None, agentCommissions=None, agentFees=None, entities=None, input=None, effectiveSplit=None, calculationError=None, referralCommission=None, ):
        self.calculatedAt = calculatedAt
        self.revenue = revenue
        self.agentCommissions = agentCommissions
        self.agentFees = agentFees
        self.entities = entities
        self.input = input
        self.effectiveSplit = effectiveSplit
        self.calculationError = calculationError
        self.referralCommission = referralCommission

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.calculatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.revenue = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.agentCommissions = []
                    (_etype62, _size65) = iprot.readListBegin()
                    for _i63 in range(_size65):
                        _elem64 = gen.urbancompass.commissioncalculator.service.ttypes.AgentCommission()
                        _elem64.read(iprot)
                        self.agentCommissions.append(_elem64)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.agentFees = []
                    (_etype66, _size69) = iprot.readListBegin()
                    for _i67 in range(_size69):
                        _elem68 = gen.urbancompass.commissioncalculator.service.ttypes.AgentFee()
                        _elem68.read(iprot)
                        self.agentFees.append(_elem68)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.entities = gen.urbancompass.commissioncalculator.service.ttypes.EntityGroupsWrapper()
                    self.entities.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.input = gen.urbancompass.commissioncalculator.service.ttypes.CalculateCommissionInput()
                    self.input.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.effectiveSplit = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.calculationError = gen.urbancompass.commissioncalculator.service.ttypes.CceError()
                    self.calculationError.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.referralCommission = []
                    (_etype70, _size73) = iprot.readListBegin()
                    for _i71 in range(_size73):
                        _elem72 = ReferralCommission()
                        _elem72.read(iprot)
                        self.referralCommission.append(_elem72)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionInfo')
        if self.calculatedAt is not None:
            oprot.writeFieldBegin('calculatedAt', TType.I64, 1)
            oprot.writeI64(self.calculatedAt)
            oprot.writeFieldEnd()
        if self.revenue is not None:
            oprot.writeFieldBegin('revenue', TType.DOUBLE, 2)
            oprot.writeDouble(self.revenue)
            oprot.writeFieldEnd()
        if self.agentCommissions is not None:
            oprot.writeFieldBegin('agentCommissions', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.agentCommissions))
            for _iter74 in self.agentCommissions:
                _iter74.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentFees is not None:
            oprot.writeFieldBegin('agentFees', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.agentFees))
            for _iter75 in self.agentFees:
                _iter75.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.entities is not None:
            oprot.writeFieldBegin('entities', TType.STRUCT, 5)
            self.entities.write(oprot)
            oprot.writeFieldEnd()
        if self.input is not None:
            oprot.writeFieldBegin('input', TType.STRUCT, 6)
            self.input.write(oprot)
            oprot.writeFieldEnd()
        if self.effectiveSplit is not None:
            oprot.writeFieldBegin('effectiveSplit', TType.DOUBLE, 7)
            oprot.writeDouble(self.effectiveSplit)
            oprot.writeFieldEnd()
        if self.calculationError is not None:
            oprot.writeFieldBegin('calculationError', TType.STRUCT, 8)
            self.calculationError.write(oprot)
            oprot.writeFieldEnd()
        if self.referralCommission is not None:
            oprot.writeFieldBegin('referralCommission', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.referralCommission))
            for _iter76 in self.referralCommission:
                _iter76.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPaymentSummary(object):
    """
    Attributes:
     - agentPaymentSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'agentPaymentSummary', (TType.STRUCT, (EntityPaymentSummary, EntityPaymentSummary.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, agentPaymentSummary=None, ):
        self.agentPaymentSummary = agentPaymentSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.agentPaymentSummary = []
                    (_etype77, _size80) = iprot.readListBegin()
                    for _i78 in range(_size80):
                        _elem79 = EntityPaymentSummary()
                        _elem79.read(iprot)
                        self.agentPaymentSummary.append(_elem79)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPaymentSummary')
        if self.agentPaymentSummary is not None:
            oprot.writeFieldBegin('agentPaymentSummary', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.agentPaymentSummary))
            for _iter81 in self.agentPaymentSummary:
                _iter81.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EscrowTitle(object):
    """
    Attributes:
     - company
     - number
     - officer
     - email
     - phoneNumber
     - location
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'company', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'number', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'officer', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'phoneNumber', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'location', (EscrowCompanyLocation, EscrowCompanyLocation.thrift_spec), None, ),  # 6
    )
    def __init__(self, company=None, number=None, officer=None, email=None, phoneNumber=None, location=None, ):
        self.company = company
        self.number = number
        self.officer = officer
        self.email = email
        self.phoneNumber = phoneNumber
        self.location = location

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.number = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.officer = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.phoneNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.location = EscrowCompanyLocation()
                    self.location.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EscrowTitle')
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 1)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.number is not None:
            oprot.writeFieldBegin('number', TType.STRING, 2)
            oprot.writeString(self.number.encode('utf-8') if sys.version_info[0] == 2 else self.number)
            oprot.writeFieldEnd()
        if self.officer is not None:
            oprot.writeFieldBegin('officer', TType.STRING, 3)
            oprot.writeString(self.officer.encode('utf-8') if sys.version_info[0] == 2 else self.officer)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phoneNumber is not None:
            oprot.writeFieldBegin('phoneNumber', TType.STRING, 5)
            oprot.writeString(self.phoneNumber.encode('utf-8') if sys.version_info[0] == 2 else self.phoneNumber)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.STRUCT, 6)
            self.location.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RegionFeeConfig(object):
    """
    Attributes:
     - hawaiiTaxFee
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'hawaiiTaxFee', (HawaiiTaxFee, HawaiiTaxFee.thrift_spec), None, ),  # 1
    )
    def __init__(self, hawaiiTaxFee=None, ):
        self.hawaiiTaxFee = hawaiiTaxFee

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.hawaiiTaxFee = HawaiiTaxFee()
                    self.hawaiiTaxFee.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RegionFeeConfig')
        if self.hawaiiTaxFee is not None:
            oprot.writeFieldBegin('hawaiiTaxFee', TType.STRUCT, 1)
            self.hawaiiTaxFee.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Allocation(object):
    """
    Attributes:
     - agent
     - commissionPercent
     - feePercent
     - splitOverride
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'agent', (Agent, Agent.thrift_spec), None, ),  # 1
        (2, TType.DOUBLE, 'commissionPercent', None, None, ),  # 2
        (3, TType.DOUBLE, 'feePercent', None, None, ),  # 3
        (4, TType.STRUCT, 'splitOverride', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 4
    )
    def __init__(self, agent=None, commissionPercent=None, feePercent=None, splitOverride=None, ):
        self.agent = agent
        self.commissionPercent = commissionPercent
        self.feePercent = feePercent
        self.splitOverride = splitOverride

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.agent = Agent()
                    self.agent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.commissionPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.feePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.splitOverride = SplitOverride()
                    self.splitOverride.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Allocation')
        if self.agent is not None:
            oprot.writeFieldBegin('agent', TType.STRUCT, 1)
            self.agent.write(oprot)
            oprot.writeFieldEnd()
        if self.commissionPercent is not None:
            oprot.writeFieldBegin('commissionPercent', TType.DOUBLE, 2)
            oprot.writeDouble(self.commissionPercent)
            oprot.writeFieldEnd()
        if self.feePercent is not None:
            oprot.writeFieldBegin('feePercent', TType.DOUBLE, 3)
            oprot.writeDouble(self.feePercent)
            oprot.writeFieldEnd()
        if self.splitOverride is not None:
            oprot.writeFieldBegin('splitOverride', TType.STRUCT, 4)
            self.splitOverride.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Contract(object):
    """
    Attributes:
     - contractGrossAmount
     - closeDate
     - brokerFee
     - isCompassLead
     - ownerPaysBrokerFee
     - sideRepresented
     - dealAgent
     - ownerPaysEntity
     - referralBrokerFee
     - linkedDmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'contractGrossAmount', None, None, ),  # 1
        (2, TType.STRING, 'closeDate', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'brokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'isCompassLead', None, None, ),  # 4
        (5, TType.BOOL, 'ownerPaysBrokerFee', None, None, ),  # 5
        (6, TType.I32, 'sideRepresented', None, None, ),  # 6
        (7, TType.STRUCT, 'dealAgent', (Agent, Agent.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'ownerPaysEntity', (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'referralBrokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 9
        (10, TType.STRING, 'linkedDmsTransactionId', 'UTF8', None, ),  # 10
    )
    def __init__(self, contractGrossAmount=None, closeDate=None, brokerFee=None, isCompassLead=None, ownerPaysBrokerFee=None, sideRepresented=None, dealAgent=None, ownerPaysEntity=None, referralBrokerFee=None, linkedDmsTransactionId=None, ):
        self.contractGrossAmount = contractGrossAmount
        self.closeDate = closeDate
        self.brokerFee = brokerFee
        self.isCompassLead = isCompassLead
        self.ownerPaysBrokerFee = ownerPaysBrokerFee
        self.sideRepresented = sideRepresented
        self.dealAgent = dealAgent
        self.ownerPaysEntity = ownerPaysEntity
        self.referralBrokerFee = referralBrokerFee
        self.linkedDmsTransactionId = linkedDmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.contractGrossAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.brokerFee = PercentOrAmount()
                    self.brokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.ownerPaysBrokerFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.dealAgent = Agent()
                    self.dealAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.ownerPaysEntity = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity()
                    self.ownerPaysEntity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.referralBrokerFee = PercentOrAmount()
                    self.referralBrokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.linkedDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Contract')
        if self.contractGrossAmount is not None:
            oprot.writeFieldBegin('contractGrossAmount', TType.DOUBLE, 1)
            oprot.writeDouble(self.contractGrossAmount)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 2)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.brokerFee is not None:
            oprot.writeFieldBegin('brokerFee', TType.STRUCT, 3)
            self.brokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 4)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.ownerPaysBrokerFee is not None:
            oprot.writeFieldBegin('ownerPaysBrokerFee', TType.BOOL, 5)
            oprot.writeBool(self.ownerPaysBrokerFee)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 6)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.dealAgent is not None:
            oprot.writeFieldBegin('dealAgent', TType.STRUCT, 7)
            self.dealAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.ownerPaysEntity is not None:
            oprot.writeFieldBegin('ownerPaysEntity', TType.STRUCT, 8)
            self.ownerPaysEntity.write(oprot)
            oprot.writeFieldEnd()
        if self.referralBrokerFee is not None:
            oprot.writeFieldBegin('referralBrokerFee', TType.STRUCT, 9)
            self.referralBrokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.linkedDmsTransactionId is not None:
            oprot.writeFieldBegin('linkedDmsTransactionId', TType.STRING, 10)
            oprot.writeString(self.linkedDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.linkedDmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContractOverrideFields(object):
    """
    Attributes:
     - contractGrossAmount
     - closeDate
     - brokerFee
     - isCompassLead
     - ownerPaysBrokerFee
     - ownerPaysEntity
     - dealAgent
     - referralBrokerFee
     - sideRepresented
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'contractGrossAmount', None, None, ),  # 1
        (2, TType.STRING, 'closeDate', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'brokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'isCompassLead', None, None, ),  # 4
        (5, TType.BOOL, 'ownerPaysBrokerFee', None, None, ),  # 5
        (6, TType.STRUCT, 'ownerPaysEntity', (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'dealAgent', (Agent, Agent.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'referralBrokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 8
        (9, TType.I32, 'sideRepresented', None, None, ),  # 9
    )
    def __init__(self, contractGrossAmount=None, closeDate=None, brokerFee=None, isCompassLead=None, ownerPaysBrokerFee=None, ownerPaysEntity=None, dealAgent=None, referralBrokerFee=None, sideRepresented=None, ):
        self.contractGrossAmount = contractGrossAmount
        self.closeDate = closeDate
        self.brokerFee = brokerFee
        self.isCompassLead = isCompassLead
        self.ownerPaysBrokerFee = ownerPaysBrokerFee
        self.ownerPaysEntity = ownerPaysEntity
        self.dealAgent = dealAgent
        self.referralBrokerFee = referralBrokerFee
        self.sideRepresented = sideRepresented

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.contractGrossAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.brokerFee = PercentOrAmount()
                    self.brokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.ownerPaysBrokerFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.ownerPaysEntity = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity()
                    self.ownerPaysEntity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.dealAgent = Agent()
                    self.dealAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.referralBrokerFee = PercentOrAmount()
                    self.referralBrokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContractOverrideFields')
        if self.contractGrossAmount is not None:
            oprot.writeFieldBegin('contractGrossAmount', TType.DOUBLE, 1)
            oprot.writeDouble(self.contractGrossAmount)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 2)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.brokerFee is not None:
            oprot.writeFieldBegin('brokerFee', TType.STRUCT, 3)
            self.brokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 4)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.ownerPaysBrokerFee is not None:
            oprot.writeFieldBegin('ownerPaysBrokerFee', TType.BOOL, 5)
            oprot.writeBool(self.ownerPaysBrokerFee)
            oprot.writeFieldEnd()
        if self.ownerPaysEntity is not None:
            oprot.writeFieldBegin('ownerPaysEntity', TType.STRUCT, 6)
            self.ownerPaysEntity.write(oprot)
            oprot.writeFieldEnd()
        if self.dealAgent is not None:
            oprot.writeFieldBegin('dealAgent', TType.STRUCT, 7)
            self.dealAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.referralBrokerFee is not None:
            oprot.writeFieldBegin('referralBrokerFee', TType.STRUCT, 8)
            self.referralBrokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 9)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealCalculationResult(object):
    """
    Attributes:
     - dealCommission
     - dealAccounting
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dealCommission', (CommissionInfo, CommissionInfo.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dealAccounting', (AccountingInfo, AccountingInfo.thrift_spec), None, ),  # 2
    )
    def __init__(self, dealCommission=None, dealAccounting=None, ):
        self.dealCommission = dealCommission
        self.dealAccounting = dealAccounting

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dealCommission = CommissionInfo()
                    self.dealCommission.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dealAccounting = AccountingInfo()
                    self.dealAccounting.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealCalculationResult')
        if self.dealCommission is not None:
            oprot.writeFieldBegin('dealCommission', TType.STRUCT, 1)
            self.dealCommission.write(oprot)
            oprot.writeFieldEnd()
        if self.dealAccounting is not None:
            oprot.writeFieldBegin('dealAccounting', TType.STRUCT, 2)
            self.dealAccounting.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealPayment(object):
    """
    Attributes:
     - appliedTransactions
     - paymentOnHoldEntityIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'appliedTransactions', (TType.STRUCT, (AppliedTransactionAmount, AppliedTransactionAmount.thrift_spec), False), None, ),  # 1
        (2, TType.SET, 'paymentOnHoldEntityIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, appliedTransactions=None, paymentOnHoldEntityIds=None, ):
        self.appliedTransactions = appliedTransactions
        self.paymentOnHoldEntityIds = paymentOnHoldEntityIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.appliedTransactions = []
                    (_etype82, _size85) = iprot.readListBegin()
                    for _i83 in range(_size85):
                        _elem84 = AppliedTransactionAmount()
                        _elem84.read(iprot)
                        self.appliedTransactions.append(_elem84)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.SET:
                    self.paymentOnHoldEntityIds = set()
                    (_etype87, _size89) = iprot.readSetBegin()
                    for _i86 in range(_size89):
                        _elem88 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.paymentOnHoldEntityIds.add(_elem88)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealPayment')
        if self.appliedTransactions is not None:
            oprot.writeFieldBegin('appliedTransactions', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.appliedTransactions))
            for _iter90 in self.appliedTransactions:
                _iter90.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.paymentOnHoldEntityIds is not None:
            oprot.writeFieldBegin('paymentOnHoldEntityIds', TType.SET, 2)
            oprot.writeSetBegin(TType.STRING, len(self.paymentOnHoldEntityIds))
            for _iter91 in self.paymentOnHoldEntityIds:
                oprot.writeString(_iter91.encode('utf-8') if sys.version_info[0] == 2 else _iter91)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class HoldTag(object):
    """
    Attributes:
     - holdReason
     - creation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'holdReason', None, None, ),  # 1
        (2, TType.STRUCT, 'creation', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 2
    )
    def __init__(self, holdReason=None, creation=None, ):
        self.holdReason = holdReason
        self.creation = creation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.holdReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.creation = AuthRecord()
                    self.creation.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('HoldTag')
        if self.holdReason is not None:
            oprot.writeFieldBegin('holdReason', TType.I32, 1)
            oprot.writeI32(self.holdReason)
            oprot.writeFieldEnd()
        if self.creation is not None:
            oprot.writeFieldBegin('creation', TType.STRUCT, 2)
            self.creation.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Listing(object):
    """
    Attributes:
     - address
     - city
     - state
     - zipCode
     - listingType
     - propertyType
     - listingPropertyType
     - listingIdSHA
     - offMarketListing
     - regionFeeConfig
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'address', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'city', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'zipCode', 'UTF8', None, ),  # 4
        (5, TType.I32, 'listingType', None, None, ),  # 5
        (6, TType.I32, 'propertyType', None, None, ),  # 6
        (7, TType.STRING, 'listingPropertyType', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'offMarketListing', None, None, ),  # 9
        (10, TType.STRUCT, 'regionFeeConfig', (RegionFeeConfig, RegionFeeConfig.thrift_spec), None, ),  # 10
    )
    def __init__(self, address=None, city=None, state=None, zipCode=None, listingType=None, propertyType=None, listingPropertyType=None, listingIdSHA=None, offMarketListing=None, regionFeeConfig=None, ):
        self.address = address
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.listingType = listingType
        self.propertyType = propertyType
        self.listingPropertyType = listingPropertyType
        self.listingIdSHA = listingIdSHA
        self.offMarketListing = offMarketListing
        self.regionFeeConfig = regionFeeConfig

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.listingPropertyType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.offMarketListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.regionFeeConfig = RegionFeeConfig()
                    self.regionFeeConfig.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Listing')
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 1)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 2)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 4)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 5)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 6)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingPropertyType is not None:
            oprot.writeFieldBegin('listingPropertyType', TType.STRING, 7)
            oprot.writeString(self.listingPropertyType.encode('utf-8') if sys.version_info[0] == 2 else self.listingPropertyType)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 8)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.offMarketListing is not None:
            oprot.writeFieldBegin('offMarketListing', TType.BOOL, 9)
            oprot.writeBool(self.offMarketListing)
            oprot.writeFieldEnd()
        if self.regionFeeConfig is not None:
            oprot.writeFieldBegin('regionFeeConfig', TType.STRUCT, 10)
            self.regionFeeConfig.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingOverrideFields(object):
    """
    Attributes:
     - address
     - city
     - state
     - zipCode
     - listingType
     - propertyType
     - listingIdSHA
     - offMarketListing
     - regionFeeConfig
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'address', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'city', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'zipCode', 'UTF8', None, ),  # 4
        (5, TType.I32, 'listingType', None, None, ),  # 5
        (6, TType.I32, 'propertyType', None, None, ),  # 6
        (7, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'offMarketListing', None, None, ),  # 8
        (9, TType.STRUCT, 'regionFeeConfig', (RegionFeeConfig, RegionFeeConfig.thrift_spec), None, ),  # 9
    )
    def __init__(self, address=None, city=None, state=None, zipCode=None, listingType=None, propertyType=None, listingIdSHA=None, offMarketListing=None, regionFeeConfig=None, ):
        self.address = address
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.listingType = listingType
        self.propertyType = propertyType
        self.listingIdSHA = listingIdSHA
        self.offMarketListing = offMarketListing
        self.regionFeeConfig = regionFeeConfig

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.offMarketListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.regionFeeConfig = RegionFeeConfig()
                    self.regionFeeConfig.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingOverrideFields')
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 1)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 2)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 4)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 5)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 6)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 7)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.offMarketListing is not None:
            oprot.writeFieldBegin('offMarketListing', TType.BOOL, 8)
            oprot.writeBool(self.offMarketListing)
            oprot.writeFieldEnd()
        if self.regionFeeConfig is not None:
            oprot.writeFieldBegin('regionFeeConfig', TType.STRUCT, 9)
            self.regionFeeConfig.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Note(object):
    """
    Attributes:
     - noteId
     - dmsTransactionId
     - dealVersion
     - creation
     - modification
     - data
     - noteType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'noteId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'dealVersion', None, None, ),  # 3
        (4, TType.STRUCT, 'creation', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'modification', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'data', 'UTF8', None, ),  # 6
        (7, TType.I32, 'noteType', None, None, ),  # 7
    )
    def __init__(self, noteId=None, dmsTransactionId=None, dealVersion=None, creation=None, modification=None, data=None, noteType=None, ):
        self.noteId = noteId
        self.dmsTransactionId = dmsTransactionId
        self.dealVersion = dealVersion
        self.creation = creation
        self.modification = modification
        self.data = data
        self.noteType = noteType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.noteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.dealVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.creation = AuthRecord()
                    self.creation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.modification = AuthRecord()
                    self.modification.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.data = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.noteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Note')
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.STRING, 1)
            oprot.writeString(self.noteId.encode('utf-8') if sys.version_info[0] == 2 else self.noteId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dealVersion is not None:
            oprot.writeFieldBegin('dealVersion', TType.I32, 3)
            oprot.writeI32(self.dealVersion)
            oprot.writeFieldEnd()
        if self.creation is not None:
            oprot.writeFieldBegin('creation', TType.STRUCT, 4)
            self.creation.write(oprot)
            oprot.writeFieldEnd()
        if self.modification is not None:
            oprot.writeFieldBegin('modification', TType.STRUCT, 5)
            self.modification.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 6)
            oprot.writeString(self.data.encode('utf-8') if sys.version_info[0] == 2 else self.data)
            oprot.writeFieldEnd()
        if self.noteType is not None:
            oprot.writeFieldBegin('noteType', TType.I32, 7)
            oprot.writeI32(self.noteType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Referral(object):
    """
    Attributes:
     - referralDmsTransactionID
     - referralBrokerFee
     - referralDealType
     - referralEntity
     - notes
     - referralDealAgent
     - paidAtTable
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'referralDmsTransactionID', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'referralBrokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 2
        (3, TType.I32, 'referralDealType', None, None, ),  # 3
        (4, TType.STRUCT, 'referralEntity', (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'notes', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'referralDealAgent', (Agent, Agent.thrift_spec), None, ),  # 6
        (7, TType.BOOL, 'paidAtTable', None, None, ),  # 7
    )
    def __init__(self, referralDmsTransactionID=None, referralBrokerFee=None, referralDealType=None, referralEntity=None, notes=None, referralDealAgent=None, paidAtTable=None, ):
        self.referralDmsTransactionID = referralDmsTransactionID
        self.referralBrokerFee = referralBrokerFee
        self.referralDealType = referralDealType
        self.referralEntity = referralEntity
        self.notes = notes
        self.referralDealAgent = referralDealAgent
        self.paidAtTable = paidAtTable

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.referralDmsTransactionID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.referralBrokerFee = PercentOrAmount()
                    self.referralBrokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.referralDealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.referralEntity = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity()
                    self.referralEntity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.referralDealAgent = Agent()
                    self.referralDealAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.paidAtTable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Referral')
        if self.referralDmsTransactionID is not None:
            oprot.writeFieldBegin('referralDmsTransactionID', TType.STRING, 1)
            oprot.writeString(self.referralDmsTransactionID.encode('utf-8') if sys.version_info[0] == 2 else self.referralDmsTransactionID)
            oprot.writeFieldEnd()
        if self.referralBrokerFee is not None:
            oprot.writeFieldBegin('referralBrokerFee', TType.STRUCT, 2)
            self.referralBrokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.referralDealType is not None:
            oprot.writeFieldBegin('referralDealType', TType.I32, 3)
            oprot.writeI32(self.referralDealType)
            oprot.writeFieldEnd()
        if self.referralEntity is not None:
            oprot.writeFieldBegin('referralEntity', TType.STRUCT, 4)
            self.referralEntity.write(oprot)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 5)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.referralDealAgent is not None:
            oprot.writeFieldBegin('referralDealAgent', TType.STRUCT, 6)
            self.referralDealAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.paidAtTable is not None:
            oprot.writeFieldBegin('paidAtTable', TType.BOOL, 7)
            oprot.writeBool(self.paidAtTable)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Team(object):
    """
    Attributes:
     - teamAmaInfo
     - teamMembers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'teamAmaInfo', (TeamAmaInfo, TeamAmaInfo.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'teamMembers', (TType.STRUCT, (Agent, Agent.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, teamAmaInfo=None, teamMembers=None, ):
        self.teamAmaInfo = teamAmaInfo
        self.teamMembers = teamMembers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.teamAmaInfo = TeamAmaInfo()
                    self.teamAmaInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.teamMembers = []
                    (_etype92, _size95) = iprot.readListBegin()
                    for _i93 in range(_size95):
                        _elem94 = Agent()
                        _elem94.read(iprot)
                        self.teamMembers.append(_elem94)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Team')
        if self.teamAmaInfo is not None:
            oprot.writeFieldBegin('teamAmaInfo', TType.STRUCT, 1)
            self.teamAmaInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.teamMembers is not None:
            oprot.writeFieldBegin('teamMembers', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.teamMembers))
            for _iter96 in self.teamMembers:
                _iter96.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Fee(object):
    """
    Attributes:
     - payToEntityId
     - typeId
     - feeCalculationType
     - amount
     - percent
     - commissionImpacting
     - name
     - notes
     - allocations
     - payToEntity
     - payToAgent
     - waived
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'payToEntityId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'typeId', None, None, ),  # 2
        (3, TType.STRING, 'feeCalculationType', 'UTF8', None, ),  # 3
        (4, TType.DOUBLE, 'amount', None, None, ),  # 4
        (5, TType.DOUBLE, 'percent', None, None, ),  # 5
        (6, TType.BOOL, 'commissionImpacting', None, None, ),  # 6
        (7, TType.I32, 'name', None, None, ),  # 7
        (8, TType.STRING, 'notes', 'UTF8', None, ),  # 8
        (9, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 9
        (10, TType.STRUCT, 'payToEntity', (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity.thrift_spec), None, ),  # 10
        (11, TType.STRUCT, 'payToAgent', (Agent, Agent.thrift_spec), None, ),  # 11
        (12, TType.BOOL, 'waived', None, None, ),  # 12
    )
    def __init__(self, payToEntityId=None, typeId=None, feeCalculationType=None, amount=None, percent=None, commissionImpacting=None, name=None, notes=None, allocations=None, payToEntity=None, payToAgent=None, waived=None, ):
        self.payToEntityId = payToEntityId
        self.typeId = typeId
        self.feeCalculationType = feeCalculationType
        self.amount = amount
        self.percent = percent
        self.commissionImpacting = commissionImpacting
        self.name = name
        self.notes = notes
        self.allocations = allocations
        self.payToEntity = payToEntity
        self.payToAgent = payToAgent
        self.waived = waived

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.payToEntityId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.typeId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.feeCalculationType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.commissionImpacting = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.name = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype97, _size100) = iprot.readListBegin()
                    for _i98 in range(_size100):
                        _elem99 = Allocation()
                        _elem99.read(iprot)
                        self.allocations.append(_elem99)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.payToEntity = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity()
                    self.payToEntity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.payToAgent = Agent()
                    self.payToAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.waived = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Fee')
        if self.payToEntityId is not None:
            oprot.writeFieldBegin('payToEntityId', TType.STRING, 1)
            oprot.writeString(self.payToEntityId.encode('utf-8') if sys.version_info[0] == 2 else self.payToEntityId)
            oprot.writeFieldEnd()
        if self.typeId is not None:
            oprot.writeFieldBegin('typeId', TType.I32, 2)
            oprot.writeI32(self.typeId)
            oprot.writeFieldEnd()
        if self.feeCalculationType is not None:
            oprot.writeFieldBegin('feeCalculationType', TType.STRING, 3)
            oprot.writeString(self.feeCalculationType.encode('utf-8') if sys.version_info[0] == 2 else self.feeCalculationType)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 4)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 5)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.commissionImpacting is not None:
            oprot.writeFieldBegin('commissionImpacting', TType.BOOL, 6)
            oprot.writeBool(self.commissionImpacting)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.I32, 7)
            oprot.writeI32(self.name)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 8)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter101 in self.allocations:
                _iter101.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.payToEntity is not None:
            oprot.writeFieldBegin('payToEntity', TType.STRUCT, 10)
            self.payToEntity.write(oprot)
            oprot.writeFieldEnd()
        if self.payToAgent is not None:
            oprot.writeFieldBegin('payToAgent', TType.STRUCT, 11)
            self.payToAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.waived is not None:
            oprot.writeFieldBegin('waived', TType.BOOL, 12)
            oprot.writeBool(self.waived)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommissionSplit(object):
    """
    Attributes:
     - allocations
     - fees
     - splitOverride
     - isTciApplied
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 2
        (3, TType.STRUCT, 'splitOverride', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'isTciApplied', None, None, ),  # 4
    )
    def __init__(self, allocations=None, fees=None, splitOverride=None, isTciApplied=None, ):
        self.allocations = allocations
        self.fees = fees
        self.splitOverride = splitOverride
        self.isTciApplied = isTciApplied

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype102, _size105) = iprot.readListBegin()
                    for _i103 in range(_size105):
                        _elem104 = Allocation()
                        _elem104.read(iprot)
                        self.allocations.append(_elem104)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype106, _size109) = iprot.readListBegin()
                    for _i107 in range(_size109):
                        _elem108 = Fee()
                        _elem108.read(iprot)
                        self.fees.append(_elem108)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.splitOverride = SplitOverride()
                    self.splitOverride.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isTciApplied = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionSplit')
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter110 in self.allocations:
                _iter110.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter111 in self.fees:
                _iter111.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.splitOverride is not None:
            oprot.writeFieldBegin('splitOverride', TType.STRUCT, 3)
            self.splitOverride.write(oprot)
            oprot.writeFieldEnd()
        if self.isTciApplied is not None:
            oprot.writeFieldBegin('isTciApplied', TType.BOOL, 4)
            oprot.writeBool(self.isTciApplied)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealSubmitterNotes(object):
    """
    Attributes:
     - note
     - splitOverrideRequestedByAgent
     - passThroughFeeRequestedByAgent
     - notesForPrincipal
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'note', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'splitOverrideRequestedByAgent', (SplitOverride, SplitOverride.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'passThroughFeeRequestedByAgent', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 3
        (4, TType.STRING, 'notesForPrincipal', 'UTF8', None, ),  # 4
    )
    def __init__(self, note=None, splitOverrideRequestedByAgent=None, passThroughFeeRequestedByAgent=None, notesForPrincipal=None, ):
        self.note = note
        self.splitOverrideRequestedByAgent = splitOverrideRequestedByAgent
        self.passThroughFeeRequestedByAgent = passThroughFeeRequestedByAgent
        self.notesForPrincipal = notesForPrincipal

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.splitOverrideRequestedByAgent = SplitOverride()
                    self.splitOverrideRequestedByAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.passThroughFeeRequestedByAgent = []
                    (_etype112, _size115) = iprot.readListBegin()
                    for _i113 in range(_size115):
                        _elem114 = Fee()
                        _elem114.read(iprot)
                        self.passThroughFeeRequestedByAgent.append(_elem114)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.notesForPrincipal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealSubmitterNotes')
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 1)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.splitOverrideRequestedByAgent is not None:
            oprot.writeFieldBegin('splitOverrideRequestedByAgent', TType.STRUCT, 2)
            self.splitOverrideRequestedByAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.passThroughFeeRequestedByAgent is not None:
            oprot.writeFieldBegin('passThroughFeeRequestedByAgent', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.passThroughFeeRequestedByAgent))
            for _iter116 in self.passThroughFeeRequestedByAgent:
                _iter116.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notesForPrincipal is not None:
            oprot.writeFieldBegin('notesForPrincipal', TType.STRING, 4)
            oprot.writeString(self.notesForPrincipal.encode('utf-8') if sys.version_info[0] == 2 else self.notesForPrincipal)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealOverrideFields(object):
    """
    Attributes:
     - listing
     - contract
     - commissionSplit
     - dealPayment
     - referrals
     - primaryDmsTransactionId
     - primaryNetsuiteId
     - holdTags
     - nonGCIRecording
     - dealType
     - cdaStatus
     - escrowTitle
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'listing', (ListingOverrideFields, ListingOverrideFields.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'contract', (ContractOverrideFields, ContractOverrideFields.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'commissionSplit', (CommissionSplit, CommissionSplit.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'dealPayment', (DealPayment, DealPayment.thrift_spec), None, ),  # 4
        (5, TType.LIST, 'referrals', (TType.STRUCT, (Referral, Referral.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'primaryDmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'primaryNetsuiteId', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'holdTags', (TType.STRUCT, (HoldTag, HoldTag.thrift_spec), False), None, ),  # 8
        (9, TType.BOOL, 'nonGCIRecording', None, None, ),  # 9
        (10, TType.I32, 'dealType', None, None, ),  # 10
        (11, TType.I32, 'cdaStatus', None, None, ),  # 11
        (12, TType.STRUCT, 'escrowTitle', (EscrowTitle, EscrowTitle.thrift_spec), None, ),  # 12
    )
    def __init__(self, listing=None, contract=None, commissionSplit=None, dealPayment=None, referrals=None, primaryDmsTransactionId=None, primaryNetsuiteId=None, holdTags=None, nonGCIRecording=None, dealType=None, cdaStatus=None, escrowTitle=None, ):
        self.listing = listing
        self.contract = contract
        self.commissionSplit = commissionSplit
        self.dealPayment = dealPayment
        self.referrals = referrals
        self.primaryDmsTransactionId = primaryDmsTransactionId
        self.primaryNetsuiteId = primaryNetsuiteId
        self.holdTags = holdTags
        self.nonGCIRecording = nonGCIRecording
        self.dealType = dealType
        self.cdaStatus = cdaStatus
        self.escrowTitle = escrowTitle

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.listing = ListingOverrideFields()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.contract = ContractOverrideFields()
                    self.contract.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.commissionSplit = CommissionSplit()
                    self.commissionSplit.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.dealPayment = DealPayment()
                    self.dealPayment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.referrals = []
                    (_etype117, _size120) = iprot.readListBegin()
                    for _i118 in range(_size120):
                        _elem119 = Referral()
                        _elem119.read(iprot)
                        self.referrals.append(_elem119)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.primaryDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.primaryNetsuiteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.holdTags = []
                    (_etype121, _size124) = iprot.readListBegin()
                    for _i122 in range(_size124):
                        _elem123 = HoldTag()
                        _elem123.read(iprot)
                        self.holdTags.append(_elem123)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.nonGCIRecording = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.cdaStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.escrowTitle = EscrowTitle()
                    self.escrowTitle.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealOverrideFields')
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 1)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.contract is not None:
            oprot.writeFieldBegin('contract', TType.STRUCT, 2)
            self.contract.write(oprot)
            oprot.writeFieldEnd()
        if self.commissionSplit is not None:
            oprot.writeFieldBegin('commissionSplit', TType.STRUCT, 3)
            self.commissionSplit.write(oprot)
            oprot.writeFieldEnd()
        if self.dealPayment is not None:
            oprot.writeFieldBegin('dealPayment', TType.STRUCT, 4)
            self.dealPayment.write(oprot)
            oprot.writeFieldEnd()
        if self.referrals is not None:
            oprot.writeFieldBegin('referrals', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.referrals))
            for _iter125 in self.referrals:
                _iter125.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.primaryDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.primaryDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsTransactionId)
            oprot.writeFieldEnd()
        if self.primaryNetsuiteId is not None:
            oprot.writeFieldBegin('primaryNetsuiteId', TType.STRING, 7)
            oprot.writeString(self.primaryNetsuiteId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryNetsuiteId)
            oprot.writeFieldEnd()
        if self.holdTags is not None:
            oprot.writeFieldBegin('holdTags', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.holdTags))
            for _iter126 in self.holdTags:
                _iter126.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.nonGCIRecording is not None:
            oprot.writeFieldBegin('nonGCIRecording', TType.BOOL, 9)
            oprot.writeBool(self.nonGCIRecording)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 10)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.cdaStatus is not None:
            oprot.writeFieldBegin('cdaStatus', TType.I32, 11)
            oprot.writeI32(self.cdaStatus)
            oprot.writeFieldEnd()
        if self.escrowTitle is not None:
            oprot.writeFieldBegin('escrowTitle', TType.STRUCT, 12)
            self.escrowTitle.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealSubmitter(object):
    """
    Attributes:
     - submittedBy
     - timeMs
     - submitterNotes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'submittedBy', (Agent, Agent.thrift_spec), None, ),  # 1
        (2, TType.I64, 'timeMs', None, None, ),  # 2
        (3, TType.STRUCT, 'submitterNotes', (DealSubmitterNotes, DealSubmitterNotes.thrift_spec), None, ),  # 3
    )
    def __init__(self, submittedBy=None, timeMs=None, submitterNotes=None, ):
        self.submittedBy = submittedBy
        self.timeMs = timeMs
        self.submitterNotes = submitterNotes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.submittedBy = Agent()
                    self.submittedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.timeMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.submitterNotes = DealSubmitterNotes()
                    self.submitterNotes.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealSubmitter')
        if self.submittedBy is not None:
            oprot.writeFieldBegin('submittedBy', TType.STRUCT, 1)
            self.submittedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.timeMs is not None:
            oprot.writeFieldBegin('timeMs', TType.I64, 2)
            oprot.writeI64(self.timeMs)
            oprot.writeFieldEnd()
        if self.submitterNotes is not None:
            oprot.writeFieldBegin('submitterNotes', TType.STRUCT, 3)
            self.submitterNotes.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Deal(object):
    """
    Attributes:
     - dmsTransactionId
     - version
     - contract
     - listing
     - submitter
     - status
     - creation
     - lastModification
     - claimedBy
     - commissionSplit
     - primaryDmsTransactionId
     - dealType
     - referrals
     - dealPayment
     - voidReason
     - approvedBy
     - rejectReason
     - rejectedBy
     - accessLevel
     - primaryNetsuiteId
     - holdTags
     - errorDetails
     - nonGCIRecording
     - externalIds
     - cdaStatus
     - escrowTitle
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'version', None, None, ),  # 2
        (3, TType.STRUCT, 'contract', (Contract, Contract.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'listing', (Listing, Listing.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'submitter', (DealSubmitter, DealSubmitter.thrift_spec), None, ),  # 5
        (6, TType.I32, 'status', None, None, ),  # 6
        (7, TType.STRUCT, 'creation', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'lastModification', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'claimedBy', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 9
        (10, TType.STRUCT, 'commissionSplit', (CommissionSplit, CommissionSplit.thrift_spec), None, ),  # 10
        (11, TType.STRING, 'primaryDmsTransactionId', 'UTF8', None, ),  # 11
        (12, TType.I32, 'dealType', None, None, ),  # 12
        (13, TType.LIST, 'referrals', (TType.STRUCT, (Referral, Referral.thrift_spec), False), None, ),  # 13
        (14, TType.STRUCT, 'dealPayment', (DealPayment, DealPayment.thrift_spec), None, ),  # 14
        (15, TType.I32, 'voidReason', None, None, ),  # 15
        (16, TType.STRUCT, 'approvedBy', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 16
        (17, TType.STRING, 'rejectReason', 'UTF8', None, ),  # 17
        (18, TType.STRUCT, 'rejectedBy', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 18
        (19, TType.I32, 'accessLevel', None, None, ),  # 19
        (20, TType.STRING, 'primaryNetsuiteId', 'UTF8', None, ),  # 20
        (21, TType.LIST, 'holdTags', (TType.STRUCT, (HoldTag, HoldTag.thrift_spec), False), None, ),  # 21
        (22, TType.STRING, 'errorDetails', 'UTF8', None, ),  # 22
        (23, TType.BOOL, 'nonGCIRecording', None, None, ),  # 23
        (24, TType.STRUCT, 'externalIds', (ExternalIds, ExternalIds.thrift_spec), None, ),  # 24
        (25, TType.I32, 'cdaStatus', None, None, ),  # 25
        (26, TType.STRUCT, 'escrowTitle', (EscrowTitle, EscrowTitle.thrift_spec), None, ),  # 26
    )
    def __init__(self, dmsTransactionId=None, version=None, contract=None, listing=None, submitter=None, status=None, creation=None, lastModification=None, claimedBy=None, commissionSplit=None, primaryDmsTransactionId=None, dealType=None, referrals=None, dealPayment=None, voidReason=None, approvedBy=None, rejectReason=None, rejectedBy=None, accessLevel=None, primaryNetsuiteId=None, holdTags=None, errorDetails=None, nonGCIRecording=None, externalIds=None, cdaStatus=None, escrowTitle=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.version = version
        self.contract = contract
        self.listing = listing
        self.submitter = submitter
        self.status = status
        self.creation = creation
        self.lastModification = lastModification
        self.claimedBy = claimedBy
        self.commissionSplit = commissionSplit
        self.primaryDmsTransactionId = primaryDmsTransactionId
        self.dealType = dealType
        self.referrals = referrals
        self.dealPayment = dealPayment
        self.voidReason = voidReason
        self.approvedBy = approvedBy
        self.rejectReason = rejectReason
        self.rejectedBy = rejectedBy
        self.accessLevel = accessLevel
        self.primaryNetsuiteId = primaryNetsuiteId
        self.holdTags = holdTags
        self.errorDetails = errorDetails
        self.nonGCIRecording = nonGCIRecording
        self.externalIds = externalIds
        self.cdaStatus = cdaStatus
        self.escrowTitle = escrowTitle

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.contract = Contract()
                    self.contract.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.listing = Listing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.submitter = DealSubmitter()
                    self.submitter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.creation = AuthRecord()
                    self.creation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.lastModification = AuthRecord()
                    self.lastModification.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.claimedBy = AuthRecord()
                    self.claimedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.commissionSplit = CommissionSplit()
                    self.commissionSplit.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.primaryDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.referrals = []
                    (_etype127, _size130) = iprot.readListBegin()
                    for _i128 in range(_size130):
                        _elem129 = Referral()
                        _elem129.read(iprot)
                        self.referrals.append(_elem129)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.dealPayment = DealPayment()
                    self.dealPayment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.voidReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.approvedBy = AuthRecord()
                    self.approvedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.rejectReason = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRUCT:
                    self.rejectedBy = AuthRecord()
                    self.rejectedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.accessLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.primaryNetsuiteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.holdTags = []
                    (_etype131, _size134) = iprot.readListBegin()
                    for _i132 in range(_size134):
                        _elem133 = HoldTag()
                        _elem133.read(iprot)
                        self.holdTags.append(_elem133)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.errorDetails = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.nonGCIRecording = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.externalIds = ExternalIds()
                    self.externalIds.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.cdaStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRUCT:
                    self.escrowTitle = EscrowTitle()
                    self.escrowTitle.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Deal')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 2)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.contract is not None:
            oprot.writeFieldBegin('contract', TType.STRUCT, 3)
            self.contract.write(oprot)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 4)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        if self.submitter is not None:
            oprot.writeFieldBegin('submitter', TType.STRUCT, 5)
            self.submitter.write(oprot)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 6)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.creation is not None:
            oprot.writeFieldBegin('creation', TType.STRUCT, 7)
            self.creation.write(oprot)
            oprot.writeFieldEnd()
        if self.lastModification is not None:
            oprot.writeFieldBegin('lastModification', TType.STRUCT, 8)
            self.lastModification.write(oprot)
            oprot.writeFieldEnd()
        if self.claimedBy is not None:
            oprot.writeFieldBegin('claimedBy', TType.STRUCT, 9)
            self.claimedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.commissionSplit is not None:
            oprot.writeFieldBegin('commissionSplit', TType.STRUCT, 10)
            self.commissionSplit.write(oprot)
            oprot.writeFieldEnd()
        if self.primaryDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDmsTransactionId', TType.STRING, 11)
            oprot.writeString(self.primaryDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsTransactionId)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 12)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.referrals is not None:
            oprot.writeFieldBegin('referrals', TType.LIST, 13)
            oprot.writeListBegin(TType.STRUCT, len(self.referrals))
            for _iter135 in self.referrals:
                _iter135.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dealPayment is not None:
            oprot.writeFieldBegin('dealPayment', TType.STRUCT, 14)
            self.dealPayment.write(oprot)
            oprot.writeFieldEnd()
        if self.voidReason is not None:
            oprot.writeFieldBegin('voidReason', TType.I32, 15)
            oprot.writeI32(self.voidReason)
            oprot.writeFieldEnd()
        if self.approvedBy is not None:
            oprot.writeFieldBegin('approvedBy', TType.STRUCT, 16)
            self.approvedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.rejectReason is not None:
            oprot.writeFieldBegin('rejectReason', TType.STRING, 17)
            oprot.writeString(self.rejectReason.encode('utf-8') if sys.version_info[0] == 2 else self.rejectReason)
            oprot.writeFieldEnd()
        if self.rejectedBy is not None:
            oprot.writeFieldBegin('rejectedBy', TType.STRUCT, 18)
            self.rejectedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.accessLevel is not None:
            oprot.writeFieldBegin('accessLevel', TType.I32, 19)
            oprot.writeI32(self.accessLevel)
            oprot.writeFieldEnd()
        if self.primaryNetsuiteId is not None:
            oprot.writeFieldBegin('primaryNetsuiteId', TType.STRING, 20)
            oprot.writeString(self.primaryNetsuiteId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryNetsuiteId)
            oprot.writeFieldEnd()
        if self.holdTags is not None:
            oprot.writeFieldBegin('holdTags', TType.LIST, 21)
            oprot.writeListBegin(TType.STRUCT, len(self.holdTags))
            for _iter136 in self.holdTags:
                _iter136.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.errorDetails is not None:
            oprot.writeFieldBegin('errorDetails', TType.STRING, 22)
            oprot.writeString(self.errorDetails.encode('utf-8') if sys.version_info[0] == 2 else self.errorDetails)
            oprot.writeFieldEnd()
        if self.nonGCIRecording is not None:
            oprot.writeFieldBegin('nonGCIRecording', TType.BOOL, 23)
            oprot.writeBool(self.nonGCIRecording)
            oprot.writeFieldEnd()
        if self.externalIds is not None:
            oprot.writeFieldBegin('externalIds', TType.STRUCT, 24)
            self.externalIds.write(oprot)
            oprot.writeFieldEnd()
        if self.cdaStatus is not None:
            oprot.writeFieldBegin('cdaStatus', TType.I32, 25)
            oprot.writeI32(self.cdaStatus)
            oprot.writeFieldEnd()
        if self.escrowTitle is not None:
            oprot.writeFieldBegin('escrowTitle', TType.STRUCT, 26)
            self.escrowTitle.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealOverride(object):
    """
    Attributes:
     - dmsTransactionId
     - dealVersion
     - dealOverrideFields
     - creation
     - amendmentReason
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'dealVersion', None, None, ),  # 2
        (3, TType.STRUCT, 'dealOverrideFields', (DealOverrideFields, DealOverrideFields.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'creation', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'amendmentReason', 'UTF8', None, ),  # 5
    )
    def __init__(self, dmsTransactionId=None, dealVersion=None, dealOverrideFields=None, creation=None, amendmentReason=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.dealVersion = dealVersion
        self.dealOverrideFields = dealOverrideFields
        self.creation = creation
        self.amendmentReason = amendmentReason

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dealVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dealOverrideFields = DealOverrideFields()
                    self.dealOverrideFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.creation = AuthRecord()
                    self.creation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.amendmentReason = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealOverride')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dealVersion is not None:
            oprot.writeFieldBegin('dealVersion', TType.I32, 2)
            oprot.writeI32(self.dealVersion)
            oprot.writeFieldEnd()
        if self.dealOverrideFields is not None:
            oprot.writeFieldBegin('dealOverrideFields', TType.STRUCT, 3)
            self.dealOverrideFields.write(oprot)
            oprot.writeFieldEnd()
        if self.creation is not None:
            oprot.writeFieldBegin('creation', TType.STRUCT, 4)
            self.creation.write(oprot)
            oprot.writeFieldEnd()
        if self.amendmentReason is not None:
            oprot.writeFieldBegin('amendmentReason', TType.STRING, 5)
            oprot.writeString(self.amendmentReason.encode('utf-8') if sys.version_info[0] == 2 else self.amendmentReason)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealOverview(object):
    """
    Attributes:
     - dmsTransactionId
     - status
     - accessLevel
     - submitter
     - claimedBy
     - approvedBy
     - listing
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'status', None, None, ),  # 2
        (3, TType.I32, 'accessLevel', None, None, ),  # 3
        (4, TType.STRUCT, 'submitter', (DealSubmitter, DealSubmitter.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'claimedBy', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'approvedBy', (AuthRecord, AuthRecord.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'listing', (Listing, Listing.thrift_spec), None, ),  # 7
    )
    def __init__(self, dmsTransactionId=None, status=None, accessLevel=None, submitter=None, claimedBy=None, approvedBy=None, listing=None, ):
        self.dmsTransactionId = dmsTransactionId
        self.status = status
        self.accessLevel = accessLevel
        self.submitter = submitter
        self.claimedBy = claimedBy
        self.approvedBy = approvedBy
        self.listing = listing

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.accessLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.submitter = DealSubmitter()
                    self.submitter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.claimedBy = AuthRecord()
                    self.claimedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.approvedBy = AuthRecord()
                    self.approvedBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.listing = Listing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealOverview')
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 1)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 2)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.accessLevel is not None:
            oprot.writeFieldBegin('accessLevel', TType.I32, 3)
            oprot.writeI32(self.accessLevel)
            oprot.writeFieldEnd()
        if self.submitter is not None:
            oprot.writeFieldBegin('submitter', TType.STRUCT, 4)
            self.submitter.write(oprot)
            oprot.writeFieldEnd()
        if self.claimedBy is not None:
            oprot.writeFieldBegin('claimedBy', TType.STRUCT, 5)
            self.claimedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.approvedBy is not None:
            oprot.writeFieldBegin('approvedBy', TType.STRUCT, 6)
            self.approvedBy.write(oprot)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 7)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EnrichedDeal(object):
    """
    Attributes:
     - deal
     - calculationResult
     - override
     - agents
     - users
     - netsuiteEntities
     - dealPaymentSummary
     - funds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'deal', (Deal, Deal.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'calculationResult', (DealCalculationResult, DealCalculationResult.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'override', (DealOverride, DealOverride.thrift_spec), None, ),  # 3
        (4, TType.MAP, 'agents', (TType.STRING, 'UTF8', TType.STRUCT, (AgentAmaInfo, AgentAmaInfo.thrift_spec), False), None, ),  # 4
        (5, TType.MAP, 'users', (TType.STRING, 'UTF8', TType.STRUCT, (PersonInfo, PersonInfo.thrift_spec), False), None, ),  # 5
        (6, TType.MAP, 'netsuiteEntities', (TType.I32, None, TType.STRUCT, (gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity, gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity.thrift_spec), False), None, ),  # 6
        (7, TType.STRUCT, 'dealPaymentSummary', (DealPaymentSummary, DealPaymentSummary.thrift_spec), None, ),  # 7
        (8, TType.MAP, 'funds', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.cash_management.funds.funds_model.ttypes.Fund, gen.urbancompass.cash_management.funds.funds_model.ttypes.Fund.thrift_spec), False), None, ),  # 8
    )
    def __init__(self, deal=None, calculationResult=None, override=None, agents=None, users=None, netsuiteEntities=None, dealPaymentSummary=None, funds=None, ):
        self.deal = deal
        self.calculationResult = calculationResult
        self.override = override
        self.agents = agents
        self.users = users
        self.netsuiteEntities = netsuiteEntities
        self.dealPaymentSummary = dealPaymentSummary
        self.funds = funds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.deal = Deal()
                    self.deal.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.calculationResult = DealCalculationResult()
                    self.calculationResult.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.override = DealOverride()
                    self.override.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.agents = {}
                    (_ktype138, _vtype139, _size142) = iprot.readMapBegin()
                    for _i137 in range(_size142):
                        _key140 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val141 = AgentAmaInfo()
                        _val141.read(iprot)
                        self.agents[_key140] = _val141
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.users = {}
                    (_ktype144, _vtype145, _size148) = iprot.readMapBegin()
                    for _i143 in range(_size148):
                        _key146 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val147 = PersonInfo()
                        _val147.read(iprot)
                        self.users[_key146] = _val147
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.MAP:
                    self.netsuiteEntities = {}
                    (_ktype150, _vtype151, _size154) = iprot.readMapBegin()
                    for _i149 in range(_size154):
                        _key152 = iprot.readI32()
                        _val153 = gen.urbancompass.deals_platform.common.netsuite_model.ttypes.NetSuiteEntity()
                        _val153.read(iprot)
                        self.netsuiteEntities[_key152] = _val153
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.dealPaymentSummary = DealPaymentSummary()
                    self.dealPaymentSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.funds = {}
                    (_ktype156, _vtype157, _size160) = iprot.readMapBegin()
                    for _i155 in range(_size160):
                        _key158 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val159 = gen.urbancompass.cash_management.funds.funds_model.ttypes.Fund()
                        _val159.read(iprot)
                        self.funds[_key158] = _val159
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EnrichedDeal')
        if self.deal is not None:
            oprot.writeFieldBegin('deal', TType.STRUCT, 1)
            self.deal.write(oprot)
            oprot.writeFieldEnd()
        if self.calculationResult is not None:
            oprot.writeFieldBegin('calculationResult', TType.STRUCT, 2)
            self.calculationResult.write(oprot)
            oprot.writeFieldEnd()
        if self.override is not None:
            oprot.writeFieldBegin('override', TType.STRUCT, 3)
            self.override.write(oprot)
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.agents))
            for _kiter161, _viter162 in self.agents.items():
                oprot.writeString(_kiter161.encode('utf-8') if sys.version_info[0] == 2 else _kiter161)
                _viter162.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.users is not None:
            oprot.writeFieldBegin('users', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.users))
            for _kiter163, _viter164 in self.users.items():
                oprot.writeString(_kiter163.encode('utf-8') if sys.version_info[0] == 2 else _kiter163)
                _viter164.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.netsuiteEntities is not None:
            oprot.writeFieldBegin('netsuiteEntities', TType.MAP, 6)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.netsuiteEntities))
            for _kiter165, _viter166 in self.netsuiteEntities.items():
                oprot.writeI32(_kiter165)
                _viter166.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.dealPaymentSummary is not None:
            oprot.writeFieldBegin('dealPaymentSummary', TType.STRUCT, 7)
            self.dealPaymentSummary.write(oprot)
            oprot.writeFieldEnd()
        if self.funds is not None:
            oprot.writeFieldBegin('funds', TType.MAP, 8)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.funds))
            for _kiter167, _viter168 in self.funds.items():
                oprot.writeString(_kiter167.encode('utf-8') if sys.version_info[0] == 2 else _kiter167)
                _viter168.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
