
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
AHWAHNEE = "Ahwahnee"
ALPAUGH = "Alpaugh"
ARMONA = "Armona"
ARVIN = "Arvin"
AUBERRY = "Auberry"
AVENAL = "Avenal"
BADGER = "Badger"
BAKERSFIELD = "Bakersfield"
BASS_LAKE = "Bass Lake"
BIG_CREEK = "Big Creek"
BIOLA = "Biola"
BODFISH = "Bodfish"
BORON = "Boron"
BUTTONWILLOW = "Buttonwillow"
CALIENTE = "Caliente"
CALIFORNIA_CITY = "California City"
CALIFORNIA_HOT_SPRINGS = "California Hot Springs"
CAMP_NELSON = "Camp Nelson"
CANTIL = "Cantil"
CANTUA_CREEK = "Cantua Creek"
CARUTHERS = "Caruthers"
CHOWCHILLA = "Chowchilla"
CITIES = [
    "Ahwahnee",
    "Alpaugh",
    "Armona",
    "Arvin",
    "Auberry",
    "Avenal",
    "Badger",
    "Bakersfield",
    "Bass Lake",
    "Big Creek",
    "Biola",
    "Bodfish",
    "Boron",
    "Buttonwillow",
    "Caliente",
    "California City",
    "California Hot Springs",
    "Camp Nelson",
    "Cantil",
    "Cantua Creek",
    "Caruthers",
    "Chowchilla",
    "Clovis",
    "Coalinga",
    "Coarsegold",
    "Corcoran",
    "Cutler",
    "Delano",
    "Del Rey",
    "Dinuba",
    "Ducor",
    "Dunlap",
    "Earlimart",
    "Edwards",
    "Exeter",
    "Farmersville",
    "Fellows",
    "Firebaugh",
    "Five Points",
    "Fowler",
    "Frazier Park",
    "Fresno",
    "Friant",
    "Glennville",
    "Goshen",
    "Hanford",
    "Helm",
    "Hume",
    "Huron",
    "Inyokern",
    "Ivanhoe",
    "Johannesburg",
    "Keene",
    "Kerman",
    "Kernville",
    "Kettleman City",
    "Kingsburg",
    "Kings Canyon National Pk",
    "Lakeshore",
    "Lake Isabella",
    "Lamont",
    "Laton",
    "Lebec",
    "Lemon Cove",
    "Lemoore",
    "Lindsay",
    "Lost Hills",
    "Madera",
    "Maricopa",
    "McFarland",
    "McKittrick",
    "Mendota",
    "Miramonte",
    "Mojave",
    "Mono Hot Springs",
    "Mountain Mesa",
    "North Edwards",
    "North Fork",
    "Oakhurst",
    "O'Neals",
    "Onyx",
    "Orange Cove",
    "Orosi",
    "Parlier",
    "Pine Mountain Club",
    "Pixley",
    "Porterville",
    "Posey",
    "Prather",
    "Raisin City",
    "Randsburg",
    "Raymond",
    "Reedley",
    "Richgrove",
    "Ridgecrest",
    "Riverdale",
    "Rosamond",
    "Sanger",
    "San Joaquin",
    "Selma",
    "Sequoia National Park",
    "Shafter",
    "Shaver Lake",
    "Springville",
    "Squaw Valley",
    "Stratford",
    "Strathmore",
    "Taft",
    "Tehachapi",
    "Terra Bella",
    "Three Rivers",
    "Tipton",
    "Tollhouse",
    "Tranquillity",
    "Traver",
    "Tulare",
    "Tupman",
    "Visalia",
    "Wasco",
    "Weldon",
    "Wishon",
    "Wofford Heights",
    "Woodlake",
    "Woody",
]
CLOVIS = "Clovis"
COALINGA = "Coalinga"
COARSEGOLD = "Coarsegold"
CORCORAN = "Corcoran"
CUTLER = "Cutler"
DELANO = "Delano"
DEL_REY = "Del Rey"
DINUBA = "Dinuba"
DUCOR = "Ducor"
DUNLAP = "Dunlap"
EARLIMART = "Earlimart"
EDWARDS = "Edwards"
EXETER = "Exeter"
FARMERSVILLE = "Farmersville"
FELLOWS = "Fellows"
FIREBAUGH = "Firebaugh"
FIVE_POINTS = "Five Points"
FOWLER = "Fowler"
FRAZIER_PARK = "Frazier Park"
FRESNO = "Fresno"
FRIANT = "Friant"
GLENNVILLE = "Glennville"
GOSHEN = "Goshen"
HANFORD = "Hanford"
HELM = "Helm"
HUME = "Hume"
HURON = "Huron"
INYOKERN = "Inyokern"
IVANHOE = "Ivanhoe"
JOHANNESBURG = "Johannesburg"
KEENE = "Keene"
KERMAN = "Kerman"
KERNVILLE = "Kernville"
KETTLEMAN_CITY = "Kettleman City"
KINGSBURG = "Kingsburg"
KINGS_CANYON_NATIONAL_PK = "Kings Canyon National Pk"
LAKESHORE = "Lakeshore"
LAKE_ISABELLA = "Lake Isabella"
LAMONT = "Lamont"
LATON = "Laton"
LEBEC = "Lebec"
LEMON_COVE = "Lemon Cove"
LEMOORE = "Lemoore"
LINDSAY = "Lindsay"
LOST_HILLS = "Lost Hills"
MADERA = "Madera"
MARICOPA = "Maricopa"
MCFARLAND = "McFarland"
MCKITTRICK = "McKittrick"
MENDOTA = "Mendota"
MIRAMONTE = "Miramonte"
MOJAVE = "Mojave"
MONO_HOT_SPRINGS = "Mono Hot Springs"
MOUNTAIN_MESA = "Mountain Mesa"
NORTH_EDWARDS = "North Edwards"
NORTH_FORK = "North Fork"
OAKHURST = "Oakhurst"
ONEALS = "O'Neals"
ONYX = "Onyx"
ORANGE_COVE = "Orange Cove"
OROSI = "Orosi"
PARLIER = "Parlier"
PINE_MOUNTAIN_CLUB = "Pine Mountain Club"
PIXLEY = "Pixley"
PORTERVILLE = "Porterville"
POSEY = "Posey"
PRATHER = "Prather"
RAISIN_CITY = "Raisin City"
RANDSBURG = "Randsburg"
RAYMOND = "Raymond"
REEDLEY = "Reedley"
RICHGROVE = "Richgrove"
RIDGECREST = "Ridgecrest"
RIVERDALE = "Riverdale"
ROSAMOND = "Rosamond"
SANGER = "Sanger"
SAN_JOAQUIN = "San Joaquin"
SELMA = "Selma"
SEQUOIA_NATIONAL_PARK = "Sequoia National Park"
SHAFTER = "Shafter"
SHAVER_LAKE = "Shaver Lake"
SPRINGVILLE = "Springville"
SQUAW_VALLEY = "Squaw Valley"
STRATFORD = "Stratford"
STRATHMORE = "Strathmore"
TAFT = "Taft"
TEHACHAPI = "Tehachapi"
TERRA_BELLA = "Terra Bella"
THREE_RIVERS = "Three Rivers"
TIPTON = "Tipton"
TOLLHOUSE = "Tollhouse"
TRANQUILLITY = "Tranquillity"
TRAVER = "Traver"
TULARE = "Tulare"
TUPMAN = "Tupman"
VISALIA = "Visalia"
WASCO = "Wasco"
WELDON = "Weldon"
WISHON = "Wishon"
WOFFORD_HEIGHTS = "Wofford Heights"
WOODLAKE = "Woodlake"
WOODY = "Woody"
