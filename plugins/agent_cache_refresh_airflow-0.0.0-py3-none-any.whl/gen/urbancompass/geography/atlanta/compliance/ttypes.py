
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class COMPLIANCE_TYPES(object):
    BASE = 0
    HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER = 1
    NO_ADDRESS_FOR_LOGGED_OUT_USER = 2
    DISPLAY_GAMLS_LOGO = 3
    DISPLAY_FMLS_LOGO = 4
    HIDE_PHOTOS = 5
    REQUIRED_LOGIN = 6
    DISPLAY_PRIMARY_PHOTO = 7
    ATLANTA_NEGBOR_MLS_LOGO = 8

    _VALUES_TO_NAMES = {
        0: "BASE",
        1: "HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER",
        2: "NO_ADDRESS_FOR_LOGGED_OUT_USER",
        3: "DISPLAY_GAMLS_LOGO",
        4: "DISPLAY_FMLS_LOGO",
        5: "HIDE_PHOTOS",
        6: "REQUIRED_LOGIN",
        7: "DISPLAY_PRIMARY_PHOTO",
        8: "ATLANTA_NEGBOR_MLS_LOGO",
    }

    _NAMES_TO_VALUES = {
        "BASE": 0,
        "HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER": 1,
        "NO_ADDRESS_FOR_LOGGED_OUT_USER": 2,
        "DISPLAY_GAMLS_LOGO": 3,
        "DISPLAY_FMLS_LOGO": 4,
        "HIDE_PHOTOS": 5,
        "REQUIRED_LOGIN": 6,
        "DISPLAY_PRIMARY_PHOTO": 7,
        "ATLANTA_NEGBOR_MLS_LOGO": 8,
    }

