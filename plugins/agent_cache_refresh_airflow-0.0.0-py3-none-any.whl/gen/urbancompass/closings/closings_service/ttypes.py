
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.listing.listing.ttypes

from thrift.transport import TTransport


class AgentSplitOverrideReason(object):
    LEAD_EXCEPTION = 0
    SPLIT_EXCEPTION = 1
    INCREASED_SPLIT_PER_ICA = 2
    PERSONAL_TRANSACTION = 3
    TEAM_WITH_COMPASS_EMPLOYEE = 4
    SALES_MANAGER_REFERRAL = 5
    AGENT_REPRESENT_COMPASS_EMPLOYEE = 6
    OTHER = 9999

    _VALUES_TO_NAMES = {
        0: "LEAD_EXCEPTION",
        1: "SPLIT_EXCEPTION",
        2: "INCREASED_SPLIT_PER_ICA",
        3: "PERSONAL_TRANSACTION",
        4: "TEAM_WITH_COMPASS_EMPLOYEE",
        5: "SALES_MANAGER_REFERRAL",
        6: "AGENT_REPRESENT_COMPASS_EMPLOYEE",
        9999: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "LEAD_EXCEPTION": 0,
        "SPLIT_EXCEPTION": 1,
        "INCREASED_SPLIT_PER_ICA": 2,
        "PERSONAL_TRANSACTION": 3,
        "TEAM_WITH_COMPASS_EMPLOYEE": 4,
        "SALES_MANAGER_REFERRAL": 5,
        "AGENT_REPRESENT_COMPASS_EMPLOYEE": 6,
        "OTHER": 9999,
    }


class AllocationFeeType(object):
    OFF_THE_NET = 0
    OFF_THE_GROSS = 1

    _VALUES_TO_NAMES = {
        0: "OFF_THE_NET",
        1: "OFF_THE_GROSS",
    }

    _NAMES_TO_VALUES = {
        "OFF_THE_NET": 0,
        "OFF_THE_GROSS": 1,
    }


class CdaType(object):
    PAYEE_ONLY = 0
    PRINCIPAL_ONLY = 1
    BOTH = 2

    _VALUES_TO_NAMES = {
        0: "PAYEE_ONLY",
        1: "PRINCIPAL_ONLY",
        2: "BOTH",
    }

    _NAMES_TO_VALUES = {
        "PAYEE_ONLY": 0,
        "PRINCIPAL_ONLY": 1,
        "BOTH": 2,
    }


class FeeType(object):
    REFERRAL = 0
    BROKER_CONCESSION = 1
    LISTING = 2
    TRANSACTION = 23

    _VALUES_TO_NAMES = {
        0: "REFERRAL",
        1: "BROKER_CONCESSION",
        2: "LISTING",
        23: "TRANSACTION",
    }

    _NAMES_TO_VALUES = {
        "REFERRAL": 0,
        "BROKER_CONCESSION": 1,
        "LISTING": 2,
        "TRANSACTION": 23,
    }


class FrontendVersion(object):
    V_1_5 = 0
    V_2_0 = 1
    V_DMS = 2

    _VALUES_TO_NAMES = {
        0: "V_1_5",
        1: "V_2_0",
        2: "V_DMS",
    }

    _NAMES_TO_VALUES = {
        "V_1_5": 0,
        "V_2_0": 1,
        "V_DMS": 2,
    }


class ListingType(object):
    RENTAL = 0
    BUILDING = 1
    SALE = 2
    SHORT_TERM_RENTAL = 3

    _VALUES_TO_NAMES = {
        0: "RENTAL",
        1: "BUILDING",
        2: "SALE",
        3: "SHORT_TERM_RENTAL",
    }

    _NAMES_TO_VALUES = {
        "RENTAL": 0,
        "BUILDING": 1,
        "SALE": 2,
        "SHORT_TERM_RENTAL": 3,
    }


class PropertyType(object):
    COMMERCIAL_RENTAL = 0
    RESIDENTIAL = 1
    CO_OP = 2
    CONDO = 3
    HOUSE_SINGLE_FAMILY = 4
    MULTI_FAMILY = 5
    ROWHOUSE_TOWNHOUSE = 6
    COMMERCIAL_SALE = 7
    LAND = 8
    MOBILE_HOME = 9
    CONDOP = 10
    MIXED_USE = 11
    NON_RESIDENTIAL = 12
    OTHER = 13

    _VALUES_TO_NAMES = {
        0: "COMMERCIAL_RENTAL",
        1: "RESIDENTIAL",
        2: "CO_OP",
        3: "CONDO",
        4: "HOUSE_SINGLE_FAMILY",
        5: "MULTI_FAMILY",
        6: "ROWHOUSE_TOWNHOUSE",
        7: "COMMERCIAL_SALE",
        8: "LAND",
        9: "MOBILE_HOME",
        10: "CONDOP",
        11: "MIXED_USE",
        12: "NON_RESIDENTIAL",
        13: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "COMMERCIAL_RENTAL": 0,
        "RESIDENTIAL": 1,
        "CO_OP": 2,
        "CONDO": 3,
        "HOUSE_SINGLE_FAMILY": 4,
        "MULTI_FAMILY": 5,
        "ROWHOUSE_TOWNHOUSE": 6,
        "COMMERCIAL_SALE": 7,
        "LAND": 8,
        "MOBILE_HOME": 9,
        "CONDOP": 10,
        "MIXED_USE": 11,
        "NON_RESIDENTIAL": 12,
        "OTHER": 13,
    }


class Status(object):
    DRAFT = 0
    SUBMITTED = 1
    DELETED_DRAFT = 2
    IN_REVIEW = 3
    IN_CONTRACT = 4

    _VALUES_TO_NAMES = {
        0: "DRAFT",
        1: "SUBMITTED",
        2: "DELETED_DRAFT",
        3: "IN_REVIEW",
        4: "IN_CONTRACT",
    }

    _NAMES_TO_VALUES = {
        "DRAFT": 0,
        "SUBMITTED": 1,
        "DELETED_DRAFT": 2,
        "IN_REVIEW": 3,
        "IN_CONTRACT": 4,
    }


class SubFeeType(object):
    INTERNAL_REFERRAL = 0
    EXTERNAL_REFERRAL = 1
    SELLER_CREDIT = 2
    BUYER_CREDIT = 3

    _VALUES_TO_NAMES = {
        0: "INTERNAL_REFERRAL",
        1: "EXTERNAL_REFERRAL",
        2: "SELLER_CREDIT",
        3: "BUYER_CREDIT",
    }

    _NAMES_TO_VALUES = {
        "INTERNAL_REFERRAL": 0,
        "EXTERNAL_REFERRAL": 1,
        "SELLER_CREDIT": 2,
        "BUYER_CREDIT": 3,
    }


class BatchGetClosingsForDmsRequest(object):
    """
    Attributes:
     - closingIds
     - userId
     - compassTeamId
     - dmsTransactionIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'closingIds', (TType.I32, None, False), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'dmsTransactionIds', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, closingIds=None, userId=None, compassTeamId=None, dmsTransactionIds=None, ):
        self.closingIds = closingIds
        self.userId = userId
        self.compassTeamId = compassTeamId
        self.dmsTransactionIds = dmsTransactionIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.closingIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readI32()
                        self.closingIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsTransactionIds = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsTransactionIds.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetClosingsForDmsRequest')
        if self.closingIds is not None:
            oprot.writeFieldBegin('closingIds', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.closingIds))
            for _iter10 in self.closingIds:
                oprot.writeI32(_iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 3)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.dmsTransactionIds is not None:
            oprot.writeFieldBegin('dmsTransactionIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.dmsTransactionIds))
            for _iter11 in self.dmsTransactionIds:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckClosingsUnderReviewRequest(object):
    """
    Attributes:
     - apiKey
     - numOfDays
     - state
     - threshold
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'apiKey', 'UTF8', None, ),  # 1
        (2, TType.I32, 'numOfDays', None, None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.I32, 'threshold', None, None, ),  # 4
    )
    def __init__(self, apiKey=None, numOfDays=None, state=None, threshold=None, ):
        self.apiKey = apiKey
        self.numOfDays = numOfDays
        self.state = state
        self.threshold = threshold

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.apiKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.numOfDays = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.threshold = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckClosingsUnderReviewRequest')
        if self.apiKey is not None:
            oprot.writeFieldBegin('apiKey', TType.STRING, 1)
            oprot.writeString(self.apiKey.encode('utf-8') if sys.version_info[0] == 2 else self.apiKey)
            oprot.writeFieldEnd()
        if self.numOfDays is not None:
            oprot.writeFieldBegin('numOfDays', TType.I32, 2)
            oprot.writeI32(self.numOfDays)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.threshold is not None:
            oprot.writeFieldBegin('threshold', TType.I32, 4)
            oprot.writeI32(self.threshold)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckClosingsUnderReviewResponse(object):
    """
    Attributes:
     - code
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'code', None, None, ),  # 1
        (2, TType.STRING, 'error', 'UTF8', None, ),  # 2
    )
    def __init__(self, code=None, error=None, ):
        self.code = code
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckClosingsUnderReviewResponse')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 1)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 2)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckWithNetsuiteRequest(object):
    """
    Attributes:
     - apiKey
     - closingId
     - submittedAt
     - isUpdatingStatus
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'apiKey', 'UTF8', None, ),  # 1
        (2, TType.I32, 'closingId', None, None, ),  # 2
        (3, TType.I64, 'submittedAt', None, None, ),  # 3
        (4, TType.BOOL, 'isUpdatingStatus', None, None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
    )
    def __init__(self, apiKey=None, closingId=None, submittedAt=None, isUpdatingStatus=None, dmsTransactionId=None, ):
        self.apiKey = apiKey
        self.closingId = closingId
        self.submittedAt = submittedAt
        self.isUpdatingStatus = isUpdatingStatus
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.apiKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.closingId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.submittedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isUpdatingStatus = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckWithNetsuiteRequest')
        if self.apiKey is not None:
            oprot.writeFieldBegin('apiKey', TType.STRING, 1)
            oprot.writeString(self.apiKey.encode('utf-8') if sys.version_info[0] == 2 else self.apiKey)
            oprot.writeFieldEnd()
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.I32, 2)
            oprot.writeI32(self.closingId)
            oprot.writeFieldEnd()
        if self.submittedAt is not None:
            oprot.writeFieldBegin('submittedAt', TType.I64, 3)
            oprot.writeI64(self.submittedAt)
            oprot.writeFieldEnd()
        if self.isUpdatingStatus is not None:
            oprot.writeFieldBegin('isUpdatingStatus', TType.BOOL, 4)
            oprot.writeBool(self.isUpdatingStatus)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckWithNetsuiteResponse(object):
    """
    Attributes:
     - code
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'code', None, None, ),  # 1
        (2, TType.STRING, 'error', 'UTF8', None, ),  # 2
    )
    def __init__(self, code=None, error=None, ):
        self.code = code
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckWithNetsuiteResponse')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 1)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 2)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosingLookup(object):
    """
    Attributes:
     - closingId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
    )
    def __init__(self, closingId=None, dmsTransactionId=None, ):
        self.closingId = closingId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosingLookup')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CounterParty(object):
    """
    Attributes:
     - name
     - email
     - brokerageName
     - personId
     - contactId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'brokerageName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'personId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'contactId', 'UTF8', None, ),  # 5
    )
    def __init__(self, name=None, email=None, brokerageName=None, personId=None, contactId=None, ):
        self.name = name
        self.email = email
        self.brokerageName = brokerageName
        self.personId = personId
        self.contactId = contactId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.brokerageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CounterParty')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.brokerageName is not None:
            oprot.writeFieldBegin('brokerageName', TType.STRING, 3)
            oprot.writeString(self.brokerageName.encode('utf-8') if sys.version_info[0] == 2 else self.brokerageName)
            oprot.writeFieldEnd()
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 4)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 5)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FeeConfig(object):
    """
    Attributes:
     - attachmentLabel
     - attachmentRequired
     - calcType
     - feeType
     - hasBrokerageInfo
     - name
     - percentageEnabled
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'attachmentLabel', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'attachmentRequired', None, None, ),  # 2
        (3, TType.STRING, 'calcType', 'UTF8', None, ),  # 3
        (4, TType.I32, 'feeType', None, None, ),  # 4
        (5, TType.BOOL, 'hasBrokerageInfo', None, None, ),  # 5
        (6, TType.STRING, 'name', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'percentageEnabled', None, None, ),  # 7
    )
    def __init__(self, attachmentLabel=None, attachmentRequired=None, calcType=None, feeType=None, hasBrokerageInfo=None, name=None, percentageEnabled=None, ):
        self.attachmentLabel = attachmentLabel
        self.attachmentRequired = attachmentRequired
        self.calcType = calcType
        self.feeType = feeType
        self.hasBrokerageInfo = hasBrokerageInfo
        self.name = name
        self.percentageEnabled = percentageEnabled

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.attachmentLabel = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.attachmentRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.calcType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.feeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.hasBrokerageInfo = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.percentageEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FeeConfig')
        if self.attachmentLabel is not None:
            oprot.writeFieldBegin('attachmentLabel', TType.STRING, 1)
            oprot.writeString(self.attachmentLabel.encode('utf-8') if sys.version_info[0] == 2 else self.attachmentLabel)
            oprot.writeFieldEnd()
        if self.attachmentRequired is not None:
            oprot.writeFieldBegin('attachmentRequired', TType.BOOL, 2)
            oprot.writeBool(self.attachmentRequired)
            oprot.writeFieldEnd()
        if self.calcType is not None:
            oprot.writeFieldBegin('calcType', TType.STRING, 3)
            oprot.writeString(self.calcType.encode('utf-8') if sys.version_info[0] == 2 else self.calcType)
            oprot.writeFieldEnd()
        if self.feeType is not None:
            oprot.writeFieldBegin('feeType', TType.I32, 4)
            oprot.writeI32(self.feeType)
            oprot.writeFieldEnd()
        if self.hasBrokerageInfo is not None:
            oprot.writeFieldBegin('hasBrokerageInfo', TType.BOOL, 5)
            oprot.writeBool(self.hasBrokerageInfo)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 6)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.percentageEnabled is not None:
            oprot.writeFieldBegin('percentageEnabled', TType.BOOL, 7)
            oprot.writeBool(self.percentageEnabled)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class File(object):
    """
    Attributes:
     - role
     - filename
     - content
     - path
     - url
     - md5sum
     - mimeType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'role', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'filename', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'content', 'BINARY', None, ),  # 3
        (4, TType.STRING, 'path', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'url', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'md5sum', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'mimeType', 'UTF8', None, ),  # 7
    )
    def __init__(self, role=None, filename=None, content=None, path=None, url=None, md5sum=None, mimeType=None, ):
        self.role = role
        self.filename = filename
        self.content = content
        self.path = path
        self.url = url
        self.md5sum = md5sum
        self.mimeType = mimeType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.filename = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.content = iprot.readBinary()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.path = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.md5sum = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.mimeType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('File')
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.STRING, 1)
            oprot.writeString(self.role.encode('utf-8') if sys.version_info[0] == 2 else self.role)
            oprot.writeFieldEnd()
        if self.filename is not None:
            oprot.writeFieldBegin('filename', TType.STRING, 2)
            oprot.writeString(self.filename.encode('utf-8') if sys.version_info[0] == 2 else self.filename)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 3)
            oprot.writeBinary(self.content)
            oprot.writeFieldEnd()
        if self.path is not None:
            oprot.writeFieldBegin('path', TType.STRING, 4)
            oprot.writeString(self.path.encode('utf-8') if sys.version_info[0] == 2 else self.path)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 5)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.md5sum is not None:
            oprot.writeFieldBegin('md5sum', TType.STRING, 6)
            oprot.writeString(self.md5sum.encode('utf-8') if sys.version_info[0] == 2 else self.md5sum)
            oprot.writeFieldEnd()
        if self.mimeType is not None:
            oprot.writeFieldBegin('mimeType', TType.STRING, 7)
            oprot.writeString(self.mimeType.encode('utf-8') if sys.version_info[0] == 2 else self.mimeType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Geo(object):
    """
    Attributes:
     - level
     - name
     - geoMasterId
     - regionName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'level', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'geoMasterId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'regionName', 'UTF8', None, ),  # 4
    )
    def __init__(self, level=None, name=None, geoMasterId=None, regionName=None, ):
        self.level = level
        self.name = name
        self.geoMasterId = geoMasterId
        self.regionName = regionName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.level = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.geoMasterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.regionName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Geo')
        if self.level is not None:
            oprot.writeFieldBegin('level', TType.STRING, 1)
            oprot.writeString(self.level.encode('utf-8') if sys.version_info[0] == 2 else self.level)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.geoMasterId is not None:
            oprot.writeFieldBegin('geoMasterId', TType.STRING, 3)
            oprot.writeString(self.geoMasterId.encode('utf-8') if sys.version_info[0] == 2 else self.geoMasterId)
            oprot.writeFieldEnd()
        if self.regionName is not None:
            oprot.writeFieldBegin('regionName', TType.STRING, 4)
            oprot.writeString(self.regionName.encode('utf-8') if sys.version_info[0] == 2 else self.regionName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentSplitRequest(object):
    """
    Attributes:
     - status
     - closeDate
     - teamId
     - compassTeamId
     - frontEndVersion
     - userId
     - impersonatorId
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'closeDate', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'teamId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'frontEndVersion', None, None, ),  # 5
        (6, TType.STRING, 'userId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, status=None, closeDate=None, teamId=None, compassTeamId=None, frontEndVersion=None, userId=None, impersonatorId=None, headers=None, ):
        self.status = status
        self.closeDate = closeDate
        self.teamId = teamId
        self.compassTeamId = compassTeamId
        self.frontEndVersion = frontEndVersion
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype13, _vtype14, _size17) = iprot.readMapBegin()
                    for _i12 in range(_size17):
                        _key15 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val16 = []
                        (_etype18, _size21) = iprot.readListBegin()
                        for _i19 in range(_size21):
                            _elem20 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val16.append(_elem20)
                        iprot.readListEnd()
                        self.headers[_key15] = _val16
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentSplitRequest')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 2)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 3)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 4)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 5)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 6)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 7)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter22, _viter23 in self.headers.items():
                oprot.writeString(_kiter22.encode('utf-8') if sys.version_info[0] == 2 else _kiter22)
                oprot.writeListBegin(TType.STRING, len(_viter23))
                for _iter24 in _viter23:
                    oprot.writeString(_iter24.encode('utf-8') if sys.version_info[0] == 2 else _iter24)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentSplitResponse(object):
    """
    Attributes:
     - agentSplitPercent
     - code
     - errors
     - error
     - isBlended
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'agentSplitPercent', None, None, ),  # 1
        (2, TType.I32, 'code', None, None, ),  # 2
        (3, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.STRING, 'error', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'isBlended', None, None, ),  # 5
    )
    def __init__(self, agentSplitPercent=None, code=None, errors=None, error=None, isBlended=None, ):
        self.agentSplitPercent = agentSplitPercent
        self.code = code
        self.errors = errors
        self.error = error
        self.isBlended = isBlended

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.agentSplitPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype26, _vtype27, _size30) = iprot.readMapBegin()
                    for _i25 in range(_size30):
                        _key28 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val29 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key28] = _val29
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isBlended = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentSplitResponse')
        if self.agentSplitPercent is not None:
            oprot.writeFieldBegin('agentSplitPercent', TType.DOUBLE, 1)
            oprot.writeDouble(self.agentSplitPercent)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 2)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter31, _viter32 in self.errors.items():
                oprot.writeString(_kiter31.encode('utf-8') if sys.version_info[0] == 2 else _kiter31)
                oprot.writeString(_viter32.encode('utf-8') if sys.version_info[0] == 2 else _viter32)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 4)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.isBlended is not None:
            oprot.writeFieldBegin('isBlended', TType.BOOL, 5)
            oprot.writeBool(self.isBlended)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetClosingForDmsRequest(object):
    """
    Attributes:
     - closingId
     - userId
     - compassTeamId
     - apiKey
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'apiKey', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
    )
    def __init__(self, closingId=None, userId=None, compassTeamId=None, apiKey=None, dmsTransactionId=None, ):
        self.closingId = closingId
        self.userId = userId
        self.compassTeamId = compassTeamId
        self.apiKey = apiKey
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.apiKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetClosingForDmsRequest')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 3)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.apiKey is not None:
            oprot.writeFieldBegin('apiKey', TType.STRING, 4)
            oprot.writeString(self.apiKey.encode('utf-8') if sys.version_info[0] == 2 else self.apiKey)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetClosingRequest(object):
    """
    Attributes:
     - closingId
     - userId
     - impersonatorId
     - dmsTransactionId
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, closingId=None, userId=None, impersonatorId=None, dmsTransactionId=None, headers=None, ):
        self.closingId = closingId
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.dmsTransactionId = dmsTransactionId
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype34, _vtype35, _size38) = iprot.readMapBegin()
                    for _i33 in range(_size38):
                        _key36 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val37 = []
                        (_etype39, _size42) = iprot.readListBegin()
                        for _i40 in range(_size42):
                            _elem41 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val37.append(_elem41)
                        iprot.readListEnd()
                        self.headers[_key36] = _val37
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetClosingRequest')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 4)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter43, _viter44 in self.headers.items():
                oprot.writeString(_kiter43.encode('utf-8') if sys.version_info[0] == 2 else _kiter43)
                oprot.writeListBegin(TType.STRING, len(_viter44))
                for _iter45 in _viter44:
                    oprot.writeString(_iter45.encode('utf-8') if sys.version_info[0] == 2 else _iter45)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserRequest(object):
    """
    Attributes:
     - frontEndVersion
     - userIdJustForTestingToDelete
     - apiKeyJustForTestingToDelete
     - userId
     - impersonatorId
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'frontEndVersion', None, None, ),  # 1
        (2, TType.STRING, 'userIdJustForTestingToDelete', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'apiKeyJustForTestingToDelete', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, frontEndVersion=None, userIdJustForTestingToDelete=None, apiKeyJustForTestingToDelete=None, userId=None, impersonatorId=None, headers=None, ):
        self.frontEndVersion = frontEndVersion
        self.userIdJustForTestingToDelete = userIdJustForTestingToDelete
        self.apiKeyJustForTestingToDelete = apiKeyJustForTestingToDelete
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userIdJustForTestingToDelete = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.apiKeyJustForTestingToDelete = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype47, _vtype48, _size51) = iprot.readMapBegin()
                    for _i46 in range(_size51):
                        _key49 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val50 = []
                        (_etype52, _size55) = iprot.readListBegin()
                        for _i53 in range(_size55):
                            _elem54 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val50.append(_elem54)
                        iprot.readListEnd()
                        self.headers[_key49] = _val50
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserRequest')
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 1)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.userIdJustForTestingToDelete is not None:
            oprot.writeFieldBegin('userIdJustForTestingToDelete', TType.STRING, 2)
            oprot.writeString(self.userIdJustForTestingToDelete.encode('utf-8') if sys.version_info[0] == 2 else self.userIdJustForTestingToDelete)
            oprot.writeFieldEnd()
        if self.apiKeyJustForTestingToDelete is not None:
            oprot.writeFieldBegin('apiKeyJustForTestingToDelete', TType.STRING, 3)
            oprot.writeString(self.apiKeyJustForTestingToDelete.encode('utf-8') if sys.version_info[0] == 2 else self.apiKeyJustForTestingToDelete)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter56, _viter57 in self.headers.items():
                oprot.writeString(_kiter56.encode('utf-8') if sys.version_info[0] == 2 else _kiter56)
                oprot.writeListBegin(TType.STRING, len(_viter57))
                for _iter58 in _viter57:
                    oprot.writeString(_iter58.encode('utf-8') if sys.version_info[0] == 2 else _iter58)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListClosingsRequest(object):
    """
    Attributes:
     - userId
     - teamId
     - role
     - frontEndVersion
     - compassTeamId
     - impersonatorId
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'teamId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'role', 'UTF8', None, ),  # 3
        (4, TType.I32, 'frontEndVersion', None, None, ),  # 4
        (5, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, userId=None, teamId=None, role=None, frontEndVersion=None, compassTeamId=None, impersonatorId=None, headers=None, ):
        self.userId = userId
        self.teamId = teamId
        self.role = role
        self.frontEndVersion = frontEndVersion
        self.compassTeamId = compassTeamId
        self.impersonatorId = impersonatorId
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype60, _vtype61, _size64) = iprot.readMapBegin()
                    for _i59 in range(_size64):
                        _key62 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val63 = []
                        (_etype65, _size68) = iprot.readListBegin()
                        for _i66 in range(_size68):
                            _elem67 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val63.append(_elem67)
                        iprot.readListEnd()
                        self.headers[_key62] = _val63
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListClosingsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 2)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.STRING, 3)
            oprot.writeString(self.role.encode('utf-8') if sys.version_info[0] == 2 else self.role)
            oprot.writeFieldEnd()
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 4)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 5)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter69, _viter70 in self.headers.items():
                oprot.writeString(_kiter69.encode('utf-8') if sys.version_info[0] == 2 else _kiter69)
                oprot.writeListBegin(TType.STRING, len(_viter70))
                for _iter71 in _viter70:
                    oprot.writeString(_iter71.encode('utf-8') if sys.version_info[0] == 2 else _iter71)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListInContractClosingsRequest(object):
    """
    Attributes:
     - apiKey
     - updatedAtAfter
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'apiKey', 'UTF8', None, ),  # 1
        (2, TType.I64, 'updatedAtAfter', None, None, ),  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, apiKey=None, updatedAtAfter=None, headers=None, ):
        self.apiKey = apiKey
        self.updatedAtAfter = updatedAtAfter
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.apiKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.updatedAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype73, _vtype74, _size77) = iprot.readMapBegin()
                    for _i72 in range(_size77):
                        _key75 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val76 = []
                        (_etype78, _size81) = iprot.readListBegin()
                        for _i79 in range(_size81):
                            _elem80 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val76.append(_elem80)
                        iprot.readListEnd()
                        self.headers[_key75] = _val76
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListInContractClosingsRequest')
        if self.apiKey is not None:
            oprot.writeFieldBegin('apiKey', TType.STRING, 1)
            oprot.writeString(self.apiKey.encode('utf-8') if sys.version_info[0] == 2 else self.apiKey)
            oprot.writeFieldEnd()
        if self.updatedAtAfter is not None:
            oprot.writeFieldBegin('updatedAtAfter', TType.I64, 2)
            oprot.writeI64(self.updatedAtAfter)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter82, _viter83 in self.headers.items():
                oprot.writeString(_kiter82.encode('utf-8') if sys.version_info[0] == 2 else _kiter82)
                oprot.writeListBegin(TType.STRING, len(_viter83))
                for _iter84 in _viter83:
                    oprot.writeString(_iter84.encode('utf-8') if sys.version_info[0] == 2 else _iter84)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        if self.apiKey is None:
            raise TProtocolException(message='Required field apiKey is unset!')
        if self.updatedAtAfter is None:
            raise TProtocolException(message='Required field updatedAtAfter is unset!')
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListSubmittedClosingsRequest(object):
    """
    Attributes:
     - apiKey
     - submittedAtAfter
     - closingIDs
     - includeNetsuiteFound
     - onlyNotSubmittedToCallidus
     - onlyNetsuiteSubmittedNoVendorBills
     - onlyHasUnpaidVendorBills
     - netsuiteNotCheckedSince
     - skipFileGeneration
     - withUnpaidVendorBillsOrEmptyDateAgentPaid
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'apiKey', 'UTF8', None, ),  # 1
        (2, TType.I64, 'submittedAtAfter', None, None, ),  # 2
        (3, TType.LIST, 'closingIDs', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.BOOL, 'includeNetsuiteFound', None, None, ),  # 4
        (5, TType.BOOL, 'onlyNotSubmittedToCallidus', None, None, ),  # 5
        (6, TType.BOOL, 'onlyNetsuiteSubmittedNoVendorBills', None, None, ),  # 6
        (7, TType.BOOL, 'onlyHasUnpaidVendorBills', None, None, ),  # 7
        (8, TType.I64, 'netsuiteNotCheckedSince', None, None, ),  # 8
        (9, TType.BOOL, 'skipFileGeneration', None, None, ),  # 9
        (10, TType.BOOL, 'withUnpaidVendorBillsOrEmptyDateAgentPaid', None, None, ),  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, apiKey=None, submittedAtAfter=None, closingIDs=None, includeNetsuiteFound=None, onlyNotSubmittedToCallidus=None, onlyNetsuiteSubmittedNoVendorBills=None, onlyHasUnpaidVendorBills=None, netsuiteNotCheckedSince=None, skipFileGeneration=None, withUnpaidVendorBillsOrEmptyDateAgentPaid=None, headers=None, ):
        self.apiKey = apiKey
        self.submittedAtAfter = submittedAtAfter
        self.closingIDs = closingIDs
        self.includeNetsuiteFound = includeNetsuiteFound
        self.onlyNotSubmittedToCallidus = onlyNotSubmittedToCallidus
        self.onlyNetsuiteSubmittedNoVendorBills = onlyNetsuiteSubmittedNoVendorBills
        self.onlyHasUnpaidVendorBills = onlyHasUnpaidVendorBills
        self.netsuiteNotCheckedSince = netsuiteNotCheckedSince
        self.skipFileGeneration = skipFileGeneration
        self.withUnpaidVendorBillsOrEmptyDateAgentPaid = withUnpaidVendorBillsOrEmptyDateAgentPaid
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.apiKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.submittedAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.closingIDs = []
                    (_etype85, _size88) = iprot.readListBegin()
                    for _i86 in range(_size88):
                        _elem87 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.closingIDs.append(_elem87)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.includeNetsuiteFound = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.onlyNotSubmittedToCallidus = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.onlyNetsuiteSubmittedNoVendorBills = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.onlyHasUnpaidVendorBills = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.netsuiteNotCheckedSince = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.skipFileGeneration = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.withUnpaidVendorBillsOrEmptyDateAgentPaid = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype90, _vtype91, _size94) = iprot.readMapBegin()
                    for _i89 in range(_size94):
                        _key92 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val93 = []
                        (_etype95, _size98) = iprot.readListBegin()
                        for _i96 in range(_size98):
                            _elem97 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val93.append(_elem97)
                        iprot.readListEnd()
                        self.headers[_key92] = _val93
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListSubmittedClosingsRequest')
        if self.apiKey is not None:
            oprot.writeFieldBegin('apiKey', TType.STRING, 1)
            oprot.writeString(self.apiKey.encode('utf-8') if sys.version_info[0] == 2 else self.apiKey)
            oprot.writeFieldEnd()
        if self.submittedAtAfter is not None:
            oprot.writeFieldBegin('submittedAtAfter', TType.I64, 2)
            oprot.writeI64(self.submittedAtAfter)
            oprot.writeFieldEnd()
        if self.closingIDs is not None:
            oprot.writeFieldBegin('closingIDs', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.closingIDs))
            for _iter99 in self.closingIDs:
                oprot.writeString(_iter99.encode('utf-8') if sys.version_info[0] == 2 else _iter99)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeNetsuiteFound is not None:
            oprot.writeFieldBegin('includeNetsuiteFound', TType.BOOL, 4)
            oprot.writeBool(self.includeNetsuiteFound)
            oprot.writeFieldEnd()
        if self.onlyNotSubmittedToCallidus is not None:
            oprot.writeFieldBegin('onlyNotSubmittedToCallidus', TType.BOOL, 5)
            oprot.writeBool(self.onlyNotSubmittedToCallidus)
            oprot.writeFieldEnd()
        if self.onlyNetsuiteSubmittedNoVendorBills is not None:
            oprot.writeFieldBegin('onlyNetsuiteSubmittedNoVendorBills', TType.BOOL, 6)
            oprot.writeBool(self.onlyNetsuiteSubmittedNoVendorBills)
            oprot.writeFieldEnd()
        if self.onlyHasUnpaidVendorBills is not None:
            oprot.writeFieldBegin('onlyHasUnpaidVendorBills', TType.BOOL, 7)
            oprot.writeBool(self.onlyHasUnpaidVendorBills)
            oprot.writeFieldEnd()
        if self.netsuiteNotCheckedSince is not None:
            oprot.writeFieldBegin('netsuiteNotCheckedSince', TType.I64, 8)
            oprot.writeI64(self.netsuiteNotCheckedSince)
            oprot.writeFieldEnd()
        if self.skipFileGeneration is not None:
            oprot.writeFieldBegin('skipFileGeneration', TType.BOOL, 9)
            oprot.writeBool(self.skipFileGeneration)
            oprot.writeFieldEnd()
        if self.withUnpaidVendorBillsOrEmptyDateAgentPaid is not None:
            oprot.writeFieldBegin('withUnpaidVendorBillsOrEmptyDateAgentPaid', TType.BOOL, 10)
            oprot.writeBool(self.withUnpaidVendorBillsOrEmptyDateAgentPaid)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter100, _viter101 in self.headers.items():
                oprot.writeString(_kiter100.encode('utf-8') if sys.version_info[0] == 2 else _kiter100)
                oprot.writeListBegin(TType.STRING, len(_viter101))
                for _iter102 in _viter101:
                    oprot.writeString(_iter102.encode('utf-8') if sys.version_info[0] == 2 else _iter102)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        if self.apiKey is None:
            raise TProtocolException(message='Required field apiKey is unset!')
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListTeamMembersRequest(object):
    """
    Attributes:
     - headers
    """

    thrift_spec = (
        None,  # 0
        None,  # 1
        None,  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, headers=None, ):
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype104, _vtype105, _size108) = iprot.readMapBegin()
                    for _i103 in range(_size108):
                        _key106 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val107 = []
                        (_etype109, _size112) = iprot.readListBegin()
                        for _i110 in range(_size112):
                            _elem111 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val107.append(_elem111)
                        iprot.readListEnd()
                        self.headers[_key106] = _val107
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListTeamMembersRequest')
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter113, _viter114 in self.headers.items():
                oprot.writeString(_kiter113.encode('utf-8') if sys.version_info[0] == 2 else _kiter113)
                oprot.writeListBegin(TType.STRING, len(_viter114))
                for _iter115 in _viter114:
                    oprot.writeString(_iter115.encode('utf-8') if sys.version_info[0] == 2 else _iter115)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ManuallyCreateDealViaDwsRequest(object):
    """
    Attributes:
     - closingId
     - userId
     - impersonatorId
     - dmsTransactionId
     - ignoreErrorsFetchingTransactionSubStage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'ignoreErrorsFetchingTransactionSubStage', None, None, ),  # 5
    )
    def __init__(self, closingId=None, userId=None, impersonatorId=None, dmsTransactionId=None, ignoreErrorsFetchingTransactionSubStage=None, ):
        self.closingId = closingId
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.dmsTransactionId = dmsTransactionId
        self.ignoreErrorsFetchingTransactionSubStage = ignoreErrorsFetchingTransactionSubStage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.ignoreErrorsFetchingTransactionSubStage = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ManuallyCreateDealViaDwsRequest')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 4)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.ignoreErrorsFetchingTransactionSubStage is not None:
            oprot.writeFieldBegin('ignoreErrorsFetchingTransactionSubStage', TType.BOOL, 5)
            oprot.writeBool(self.ignoreErrorsFetchingTransactionSubStage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ManuallyCreateDealViaDwsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ManuallyCreateDealViaDwsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PassThroughFee(object):
    """
    Attributes:
     - id
     - amount
     - name
     - recipient
     - payFrom
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
        (3, TType.STRING, 'name', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'recipient', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'payFrom', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'notes', 'UTF8', None, ),  # 6
    )
    def __init__(self, id=None, amount=None, name=None, recipient=None, payFrom=None, notes=None, ):
        self.id = id
        self.amount = amount
        self.name = name
        self.recipient = recipient
        self.payFrom = payFrom
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.recipient = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.payFrom = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PassThroughFee')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 3)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.recipient is not None:
            oprot.writeFieldBegin('recipient', TType.STRING, 4)
            oprot.writeString(self.recipient.encode('utf-8') if sys.version_info[0] == 2 else self.recipient)
            oprot.writeFieldEnd()
        if self.payFrom is not None:
            oprot.writeFieldBegin('payFrom', TType.STRING, 5)
            oprot.writeString(self.payFrom.encode('utf-8') if sys.version_info[0] == 2 else self.payFrom)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 6)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PassThroughFeeOption(object):
    """
    Attributes:
     - label
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'label', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'value', None, None, ),  # 2
    )
    def __init__(self, label=None, value=None, ):
        self.label = label
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.value = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PassThroughFeeOption')
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 1)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.DOUBLE, 2)
            oprot.writeDouble(self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PercentOrAmount(object):
    """
    Attributes:
     - percent
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percent', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, percent=None, amount=None, ):
        self.percent = percent
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PercentOrAmount')
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 1)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Profile(object):
    """
    Attributes:
     - firstName
     - lastName
     - email
     - CompassSeparationDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'firstName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'lastName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        (7, TType.STRING, 'CompassSeparationDate', 'UTF8', None, ),  # 7
    )
    def __init__(self, firstName=None, lastName=None, email=None, CompassSeparationDate=None, ):
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.CompassSeparationDate = CompassSeparationDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.CompassSeparationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Profile')
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 1)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 2)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.CompassSeparationDate is not None:
            oprot.writeFieldBegin('CompassSeparationDate', TType.STRING, 7)
            oprot.writeString(self.CompassSeparationDate.encode('utf-8') if sys.version_info[0] == 2 else self.CompassSeparationDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResendFailedNotificationRequest(object):
    """
    Attributes:
     - closingId
     - compassTeamId
     - userId
     - impersonatorId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
    )
    def __init__(self, closingId=None, compassTeamId=None, userId=None, impersonatorId=None, dmsTransactionId=None, ):
        self.closingId = closingId
        self.compassTeamId = compassTeamId
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResendFailedNotificationRequest')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 2)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 4)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResendFailedNotificationResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResendFailedNotificationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResubmitSubmittedClosingRequest(object):
    """
    Attributes:
     - apiKey
     - closingId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'apiKey', 'UTF8', None, ),  # 1
        (2, TType.I32, 'closingId', None, None, ),  # 2
        (3, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 3
    )
    def __init__(self, apiKey=None, closingId=None, dmsTransactionId=None, ):
        self.apiKey = apiKey
        self.closingId = closingId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.apiKey = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.closingId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResubmitSubmittedClosingRequest')
        if self.apiKey is not None:
            oprot.writeFieldBegin('apiKey', TType.STRING, 1)
            oprot.writeString(self.apiKey.encode('utf-8') if sys.version_info[0] == 2 else self.apiKey)
            oprot.writeFieldEnd()
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.I32, 2)
            oprot.writeI32(self.closingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 3)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResubmitSubmittedClosingResponse(object):
    """
    Attributes:
     - code
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'code', None, None, ),  # 1
        (2, TType.STRING, 'error', 'UTF8', None, ),  # 2
    )
    def __init__(self, code=None, error=None, ):
        self.code = code
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResubmitSubmittedClosingResponse')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 1)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 2)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamAccount(object):
    """
    Attributes:
     - agentMasterDataId
     - name
     - compassPlatformId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'compassPlatformId', 'UTF8', None, ),  # 3
    )
    def __init__(self, agentMasterDataId=None, name=None, compassPlatformId=None, ):
        self.agentMasterDataId = agentMasterDataId
        self.name = name
        self.compassPlatformId = compassPlatformId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.compassPlatformId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamAccount')
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 1)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.compassPlatformId is not None:
            oprot.writeFieldBegin('compassPlatformId', TType.STRING, 3)
            oprot.writeString(self.compassPlatformId.encode('utf-8') if sys.version_info[0] == 2 else self.compassPlatformId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamRole(object):
    """
    Attributes:
     - agentMasterDataId
     - isPrimaryTeam
     - role
     - separationDate
     - status
     - joinDate
     - isActive
     - grant
     - overrideRole
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'isPrimaryTeam', None, None, ),  # 2
        (3, TType.STRING, 'role', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'separationDate', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'status', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'joinDate', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'isActive', None, None, ),  # 7
        (8, TType.STRING, 'grant', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'overrideRole', None, None, ),  # 9
    )
    def __init__(self, agentMasterDataId=None, isPrimaryTeam=None, role=None, separationDate=None, status=None, joinDate=None, isActive=None, grant=None, overrideRole=None, ):
        self.agentMasterDataId = agentMasterDataId
        self.isPrimaryTeam = isPrimaryTeam
        self.role = role
        self.separationDate = separationDate
        self.status = status
        self.joinDate = joinDate
        self.isActive = isActive
        self.grant = grant
        self.overrideRole = overrideRole

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isPrimaryTeam = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.separationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.status = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.joinDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isActive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.grant = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.overrideRole = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamRole')
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 1)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.isPrimaryTeam is not None:
            oprot.writeFieldBegin('isPrimaryTeam', TType.BOOL, 2)
            oprot.writeBool(self.isPrimaryTeam)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.STRING, 3)
            oprot.writeString(self.role.encode('utf-8') if sys.version_info[0] == 2 else self.role)
            oprot.writeFieldEnd()
        if self.separationDate is not None:
            oprot.writeFieldBegin('separationDate', TType.STRING, 4)
            oprot.writeString(self.separationDate.encode('utf-8') if sys.version_info[0] == 2 else self.separationDate)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRING, 5)
            oprot.writeString(self.status.encode('utf-8') if sys.version_info[0] == 2 else self.status)
            oprot.writeFieldEnd()
        if self.joinDate is not None:
            oprot.writeFieldBegin('joinDate', TType.STRING, 6)
            oprot.writeString(self.joinDate.encode('utf-8') if sys.version_info[0] == 2 else self.joinDate)
            oprot.writeFieldEnd()
        if self.isActive is not None:
            oprot.writeFieldBegin('isActive', TType.BOOL, 7)
            oprot.writeBool(self.isActive)
            oprot.writeFieldEnd()
        if self.grant is not None:
            oprot.writeFieldBegin('grant', TType.STRING, 8)
            oprot.writeString(self.grant.encode('utf-8') if sys.version_info[0] == 2 else self.grant)
            oprot.writeFieldEnd()
        if self.overrideRole is not None:
            oprot.writeFieldBegin('overrideRole', TType.BOOL, 9)
            oprot.writeBool(self.overrideRole)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ValidateOneFieldResponse(object):
    """
    Attributes:
     - code
     - errors
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'code', None, None, ),  # 1
        (2, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'error', 'UTF8', None, ),  # 3
    )
    def __init__(self, code=None, errors=None, error=None, ):
        self.code = code
        self.errors = errors
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype117, _vtype118, _size121) = iprot.readMapBegin()
                    for _i116 in range(_size121):
                        _key119 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val120 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key119] = _val120
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ValidateOneFieldResponse')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 1)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter122, _viter123 in self.errors.items():
                oprot.writeString(_kiter122.encode('utf-8') if sys.version_info[0] == 2 else _kiter122)
                oprot.writeString(_viter123.encode('utf-8') if sys.version_info[0] == 2 else _viter123)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 3)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Allocation(object):
    """
    Attributes:
     - allocationId
     - agentMasterDataId
     - agentName
     - percentOrAmount
     - agentSplitOverridePercent
     - agentSplitOverrideNotes
     - agentSplitOverrideReason
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'allocationId', None, None, ),  # 1
        (2, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'agentName', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'percentOrAmount', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 4
        (5, TType.DOUBLE, 'agentSplitOverridePercent', None, None, ),  # 5
        (6, TType.STRING, 'agentSplitOverrideNotes', 'UTF8', None, ),  # 6
        (7, TType.I32, 'agentSplitOverrideReason', None, None, ),  # 7
    )
    def __init__(self, allocationId=None, agentMasterDataId=None, agentName=None, percentOrAmount=None, agentSplitOverridePercent=None, agentSplitOverrideNotes=None, agentSplitOverrideReason=None, ):
        self.allocationId = allocationId
        self.agentMasterDataId = agentMasterDataId
        self.agentName = agentName
        self.percentOrAmount = percentOrAmount
        self.agentSplitOverridePercent = agentSplitOverridePercent
        self.agentSplitOverrideNotes = agentSplitOverrideNotes
        self.agentSplitOverrideReason = agentSplitOverrideReason

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.allocationId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.percentOrAmount = PercentOrAmount()
                    self.percentOrAmount.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.agentSplitOverridePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.agentSplitOverrideNotes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.agentSplitOverrideReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Allocation')
        if self.allocationId is not None:
            oprot.writeFieldBegin('allocationId', TType.I64, 1)
            oprot.writeI64(self.allocationId)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 2)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 3)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.percentOrAmount is not None:
            oprot.writeFieldBegin('percentOrAmount', TType.STRUCT, 4)
            self.percentOrAmount.write(oprot)
            oprot.writeFieldEnd()
        if self.agentSplitOverridePercent is not None:
            oprot.writeFieldBegin('agentSplitOverridePercent', TType.DOUBLE, 5)
            oprot.writeDouble(self.agentSplitOverridePercent)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideNotes is not None:
            oprot.writeFieldBegin('agentSplitOverrideNotes', TType.STRING, 6)
            oprot.writeString(self.agentSplitOverrideNotes.encode('utf-8') if sys.version_info[0] == 2 else self.agentSplitOverrideNotes)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideReason is not None:
            oprot.writeFieldBegin('agentSplitOverrideReason', TType.I32, 7)
            oprot.writeI32(self.agentSplitOverrideReason)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Fee(object):
    """
    Attributes:
     - feeId
     - percentOrAmount
     - feeType
     - counterParty
     - file
     - calcType
     - files
     - subFeeType
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'feeId', None, None, ),  # 1
        (2, TType.STRUCT, 'percentOrAmount', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 2
        (3, TType.I32, 'feeType', None, None, ),  # 3
        (4, TType.STRUCT, 'counterParty', (CounterParty, CounterParty.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'file', (File, File.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'calcType', 'UTF8', None, ),  # 6
        (7, TType.LIST, 'files', (TType.STRUCT, (File, File.thrift_spec), False), None, ),  # 7
        (8, TType.I32, 'subFeeType', None, None, ),  # 8
        (9, TType.STRING, 'notes', 'UTF8', None, ),  # 9
    )
    def __init__(self, feeId=None, percentOrAmount=None, feeType=None, counterParty=None, file=None, calcType=None, files=None, subFeeType=None, notes=None, ):
        self.feeId = feeId
        self.percentOrAmount = percentOrAmount
        self.feeType = feeType
        self.counterParty = counterParty
        self.file = file
        self.calcType = calcType
        self.files = files
        self.subFeeType = subFeeType
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.feeId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.percentOrAmount = PercentOrAmount()
                    self.percentOrAmount.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.feeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.counterParty = CounterParty()
                    self.counterParty.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.file = File()
                    self.file.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.calcType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.files = []
                    (_etype124, _size127) = iprot.readListBegin()
                    for _i125 in range(_size127):
                        _elem126 = File()
                        _elem126.read(iprot)
                        self.files.append(_elem126)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.subFeeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Fee')
        if self.feeId is not None:
            oprot.writeFieldBegin('feeId', TType.I64, 1)
            oprot.writeI64(self.feeId)
            oprot.writeFieldEnd()
        if self.percentOrAmount is not None:
            oprot.writeFieldBegin('percentOrAmount', TType.STRUCT, 2)
            self.percentOrAmount.write(oprot)
            oprot.writeFieldEnd()
        if self.feeType is not None:
            oprot.writeFieldBegin('feeType', TType.I32, 3)
            oprot.writeI32(self.feeType)
            oprot.writeFieldEnd()
        if self.counterParty is not None:
            oprot.writeFieldBegin('counterParty', TType.STRUCT, 4)
            self.counterParty.write(oprot)
            oprot.writeFieldEnd()
        if self.file is not None:
            oprot.writeFieldBegin('file', TType.STRUCT, 5)
            self.file.write(oprot)
            oprot.writeFieldEnd()
        if self.calcType is not None:
            oprot.writeFieldBegin('calcType', TType.STRING, 6)
            oprot.writeString(self.calcType.encode('utf-8') if sys.version_info[0] == 2 else self.calcType)
            oprot.writeFieldEnd()
        if self.files is not None:
            oprot.writeFieldBegin('files', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.files))
            for _iter128 in self.files:
                _iter128.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.subFeeType is not None:
            oprot.writeFieldBegin('subFeeType', TType.I32, 8)
            oprot.writeI32(self.subFeeType)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 9)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterSubmittedClosingsRequest(object):
    """
    Attributes:
     - closingIds
     - lookupCriteria
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'closingIds', (TType.I32, None, False), None, ),  # 1
        (2, TType.LIST, 'lookupCriteria', (TType.STRUCT, (ClosingLookup, ClosingLookup.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, closingIds=None, lookupCriteria=None, ):
        self.closingIds = closingIds
        self.lookupCriteria = lookupCriteria

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.closingIds = []
                    (_etype129, _size132) = iprot.readListBegin()
                    for _i130 in range(_size132):
                        _elem131 = iprot.readI32()
                        self.closingIds.append(_elem131)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.lookupCriteria = []
                    (_etype133, _size136) = iprot.readListBegin()
                    for _i134 in range(_size136):
                        _elem135 = ClosingLookup()
                        _elem135.read(iprot)
                        self.lookupCriteria.append(_elem135)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterSubmittedClosingsRequest')
        if self.closingIds is not None:
            oprot.writeFieldBegin('closingIds', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.closingIds))
            for _iter137 in self.closingIds:
                oprot.writeI32(_iter137)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lookupCriteria is not None:
            oprot.writeFieldBegin('lookupCriteria', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.lookupCriteria))
            for _iter138 in self.lookupCriteria:
                _iter138.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PassThroughFeeConfig(object):
    """
    Attributes:
     - name
     - defaultAmount
     - options
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.DOUBLE, 'defaultAmount', None, None, ),  # 2
        (3, TType.LIST, 'options', (TType.STRUCT, (PassThroughFeeOption, PassThroughFeeOption.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, name=None, defaultAmount=None, options=None, ):
        self.name = name
        self.defaultAmount = defaultAmount
        self.options = options

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.defaultAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.options = []
                    (_etype139, _size142) = iprot.readListBegin()
                    for _i140 in range(_size142):
                        _elem141 = PassThroughFeeOption()
                        _elem141.read(iprot)
                        self.options.append(_elem141)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PassThroughFeeConfig')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.defaultAmount is not None:
            oprot.writeFieldBegin('defaultAmount', TType.DOUBLE, 2)
            oprot.writeDouble(self.defaultAmount)
            oprot.writeFieldEnd()
        if self.options is not None:
            oprot.writeFieldBegin('options', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.options))
            for _iter143 in self.options:
                _iter143.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamMember(object):
    """
    Attributes:
     - firstName
     - lastName
     - agentMasterDataId
     - teamRole
     - profile
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'firstName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'lastName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'teamRole', (TeamRole, TeamRole.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'profile', (Profile, Profile.thrift_spec), None, ),  # 5
    )
    def __init__(self, firstName=None, lastName=None, agentMasterDataId=None, teamRole=None, profile=None, ):
        self.firstName = firstName
        self.lastName = lastName
        self.agentMasterDataId = agentMasterDataId
        self.teamRole = teamRole
        self.profile = profile

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.teamRole = TeamRole()
                    self.teamRole.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.profile = Profile()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamMember')
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 1)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 2)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 3)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.teamRole is not None:
            oprot.writeFieldBegin('teamRole', TType.STRUCT, 4)
            self.teamRole.write(oprot)
            oprot.writeFieldEnd()
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 5)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        if self.firstName is None:
            raise TProtocolException(message='Required field firstName is unset!')
        if self.lastName is None:
            raise TProtocolException(message='Required field lastName is unset!')
        if self.agentMasterDataId is None:
            raise TProtocolException(message='Required field agentMasterDataId is unset!')
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class User(object):
    """
    Attributes:
     - compassPlatformID
     - agentName
     - agentMasterDataId
     - profile
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'compassPlatformID', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'agentName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'profile', (Profile, Profile.thrift_spec), None, ),  # 4
    )
    def __init__(self, compassPlatformID=None, agentName=None, agentMasterDataId=None, profile=None, ):
        self.compassPlatformID = compassPlatformID
        self.agentName = agentName
        self.agentMasterDataId = agentMasterDataId
        self.profile = profile

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.compassPlatformID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.profile = Profile()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('User')
        if self.compassPlatformID is not None:
            oprot.writeFieldBegin('compassPlatformID', TType.STRING, 1)
            oprot.writeString(self.compassPlatformID.encode('utf-8') if sys.version_info[0] == 2 else self.compassPlatformID)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 2)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 3)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 4)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Account(object):
    """
    Attributes:
     - user
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'user', (User, User.thrift_spec), None, ),  # 1
    )
    def __init__(self, user=None, ):
        self.user = user

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.user = User()
                    self.user.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Account')
        if self.user is not None:
            oprot.writeFieldBegin('user', TType.STRUCT, 1)
            self.user.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Closing(object):
    """
    Attributes:
     - closingId
     - createdAt
     - updatedAt
     - contractGrossAmount
     - closeDate
     - address
     - sideRepresented
     - listingType
     - status
     - brokerFee
     - isCompassLead
     - propertyType
     - fees
     - offMarketListing
     - allocations
     - notes
     - withExternalBroker
     - externalBrokerageName
     - externalBrokerName
     - externalBrokerEmail
     - submittedAt
     - userId
     - agentName
     - listingIdSHA
     - files
     - agentSplitOverridePercent
     - agentSplitOverrideNotes
     - agentSplitOverrideReason
     - agentMasterDataId
     - zipCode
     - teamId
     - submittedById
     - submittedByName
     - submittedByAgentMasterDataId
     - notesForPrincipal
     - city
     - state
     - url
     - passThroughFees
     - ownerPaysBrokerFee
     - cdaType
     - netsuiteId
     - netsuiteStatus
     - netsuiteLastCheckedAt
     - GrossCommissionIncome
     - NetCommissionIncome
     - NetCommissionRemainingPercent
     - NetCommissionRemainingAmount
     - frontEndVersion
     - agentSplitAmount
     - compassTeamId
     - netsuiteOverallStatus
     - netsuiteOverallLastCheckedAt
     - vendorBillLastCheckedAt
     - dateAgentPaid
     - dmsTransactionId
     - btId
     - useDefaultAgentSplitPercent
     - notReadyForCSReview
     - allocationFeeType
     - commissionRemainingPercent
     - commissionRemainingAmount
     - linkedDmsTransactionId
     - dealType
     - referredAgent
     - shouldAddGeneralExciseTax
     - escrowTitle
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.DOUBLE, 'contractGrossAmount', None, None, ),  # 4
        (5, TType.STRING, 'closeDate', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'address', 'UTF8', None, ),  # 6
        None,  # 7
        None,  # 8
        (9, TType.STRING, 'sideRepresented', 'UTF8', None, ),  # 9
        (10, TType.I32, 'listingType', None, None, ),  # 10
        (11, TType.I32, 'status', None, None, ),  # 11
        (12, TType.STRUCT, 'brokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 12
        (13, TType.BOOL, 'isCompassLead', None, None, ),  # 13
        None,  # 14
        None,  # 15
        (16, TType.I32, 'propertyType', None, None, ),  # 16
        (17, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 17
        (18, TType.BOOL, 'offMarketListing', None, None, ),  # 18
        None,  # 19
        (20, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 20
        (21, TType.STRING, 'notes', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'withExternalBroker', None, None, ),  # 22
        (23, TType.STRING, 'externalBrokerageName', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'externalBrokerName', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'externalBrokerEmail', 'UTF8', None, ),  # 25
        (26, TType.I64, 'submittedAt', None, None, ),  # 26
        (27, TType.STRING, 'userId', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'agentName', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 29
        (30, TType.LIST, 'files', (TType.STRUCT, (File, File.thrift_spec), False), None, ),  # 30
        (31, TType.DOUBLE, 'agentSplitOverridePercent', None, None, ),  # 31
        (32, TType.STRING, 'agentSplitOverrideNotes', 'UTF8', None, ),  # 32
        (33, TType.I32, 'agentSplitOverrideReason', None, None, ),  # 33
        (34, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'zipCode', 'UTF8', None, ),  # 35
        (36, TType.STRING, 'teamId', 'UTF8', None, ),  # 36
        (37, TType.STRING, 'submittedById', 'UTF8', None, ),  # 37
        (38, TType.STRING, 'submittedByName', 'UTF8', None, ),  # 38
        (39, TType.STRING, 'submittedByAgentMasterDataId', 'UTF8', None, ),  # 39
        (40, TType.STRING, 'notesForPrincipal', 'UTF8', None, ),  # 40
        (41, TType.STRING, 'city', 'UTF8', None, ),  # 41
        (42, TType.STRING, 'state', 'UTF8', None, ),  # 42
        (43, TType.STRING, 'url', 'UTF8', None, ),  # 43
        (44, TType.LIST, 'passThroughFees', (TType.STRUCT, (PassThroughFee, PassThroughFee.thrift_spec), False), None, ),  # 44
        (45, TType.BOOL, 'ownerPaysBrokerFee', None, None, ),  # 45
        (46, TType.I32, 'cdaType', None, None, ),  # 46
        (47, TType.STRING, 'netsuiteId', 'UTF8', None, ),  # 47
        (48, TType.STRING, 'netsuiteStatus', 'UTF8', None, ),  # 48
        (49, TType.I64, 'netsuiteLastCheckedAt', None, None, ),  # 49
        (50, TType.DOUBLE, 'GrossCommissionIncome', None, None, ),  # 50
        (51, TType.DOUBLE, 'NetCommissionIncome', None, None, ),  # 51
        (52, TType.DOUBLE, 'NetCommissionRemainingPercent', None, None, ),  # 52
        (53, TType.DOUBLE, 'NetCommissionRemainingAmount', None, None, ),  # 53
        (54, TType.I32, 'frontEndVersion', None, None, ),  # 54
        (55, TType.DOUBLE, 'agentSplitAmount', None, None, ),  # 55
        (56, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 56
        (57, TType.STRING, 'netsuiteOverallStatus', 'UTF8', None, ),  # 57
        (58, TType.I64, 'netsuiteOverallLastCheckedAt', None, None, ),  # 58
        (59, TType.I64, 'vendorBillLastCheckedAt', None, None, ),  # 59
        (60, TType.I64, 'dateAgentPaid', None, None, ),  # 60
        (61, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 61
        (62, TType.STRING, 'btId', 'UTF8', None, ),  # 62
        (63, TType.BOOL, 'useDefaultAgentSplitPercent', None, None, ),  # 63
        (64, TType.BOOL, 'notReadyForCSReview', None, None, ),  # 64
        (65, TType.I32, 'allocationFeeType', None, None, ),  # 65
        (66, TType.DOUBLE, 'commissionRemainingPercent', None, None, ),  # 66
        (67, TType.DOUBLE, 'commissionRemainingAmount', None, None, ),  # 67
        (68, TType.STRING, 'linkedDmsTransactionId', 'UTF8', None, ),  # 68
        (69, TType.I32, 'dealType', None, None, ),  # 69
        (70, TType.STRUCT, 'referredAgent', (CounterParty, CounterParty.thrift_spec), None, ),  # 70
        (71, TType.BOOL, 'shouldAddGeneralExciseTax', None, None, ),  # 71
        (72, TType.STRUCT, 'escrowTitle', (gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes.EscrowTitle, gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes.EscrowTitle.thrift_spec), None, ),  # 72
    )
    def __init__(self, closingId=None, createdAt=None, updatedAt=None, contractGrossAmount=None, closeDate=None, address=None, sideRepresented=None, listingType=None, status=None, brokerFee=None, isCompassLead=None, propertyType=None, fees=None, offMarketListing=None, allocations=None, notes=None, withExternalBroker=None, externalBrokerageName=None, externalBrokerName=None, externalBrokerEmail=None, submittedAt=None, userId=None, agentName=None, listingIdSHA=None, files=None, agentSplitOverridePercent=None, agentSplitOverrideNotes=None, agentSplitOverrideReason=None, agentMasterDataId=None, zipCode=None, teamId=None, submittedById=None, submittedByName=None, submittedByAgentMasterDataId=None, notesForPrincipal=None, city=None, state=None, url=None, passThroughFees=None, ownerPaysBrokerFee=None, cdaType=None, netsuiteId=None, netsuiteStatus=None, netsuiteLastCheckedAt=None, GrossCommissionIncome=None, NetCommissionIncome=None, NetCommissionRemainingPercent=None, NetCommissionRemainingAmount=None, frontEndVersion=None, agentSplitAmount=None, compassTeamId=None, netsuiteOverallStatus=None, netsuiteOverallLastCheckedAt=None, vendorBillLastCheckedAt=None, dateAgentPaid=None, dmsTransactionId=None, btId=None, useDefaultAgentSplitPercent=None, notReadyForCSReview=None, allocationFeeType=None, commissionRemainingPercent=None, commissionRemainingAmount=None, linkedDmsTransactionId=None, dealType=None, referredAgent=None, shouldAddGeneralExciseTax=None, escrowTitle=None, ):
        self.closingId = closingId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.contractGrossAmount = contractGrossAmount
        self.closeDate = closeDate
        self.address = address
        self.sideRepresented = sideRepresented
        self.listingType = listingType
        self.status = status
        self.brokerFee = brokerFee
        self.isCompassLead = isCompassLead
        self.propertyType = propertyType
        self.fees = fees
        self.offMarketListing = offMarketListing
        self.allocations = allocations
        self.notes = notes
        self.withExternalBroker = withExternalBroker
        self.externalBrokerageName = externalBrokerageName
        self.externalBrokerName = externalBrokerName
        self.externalBrokerEmail = externalBrokerEmail
        self.submittedAt = submittedAt
        self.userId = userId
        self.agentName = agentName
        self.listingIdSHA = listingIdSHA
        self.files = files
        self.agentSplitOverridePercent = agentSplitOverridePercent
        self.agentSplitOverrideNotes = agentSplitOverrideNotes
        self.agentSplitOverrideReason = agentSplitOverrideReason
        self.agentMasterDataId = agentMasterDataId
        self.zipCode = zipCode
        self.teamId = teamId
        self.submittedById = submittedById
        self.submittedByName = submittedByName
        self.submittedByAgentMasterDataId = submittedByAgentMasterDataId
        self.notesForPrincipal = notesForPrincipal
        self.city = city
        self.state = state
        self.url = url
        self.passThroughFees = passThroughFees
        self.ownerPaysBrokerFee = ownerPaysBrokerFee
        self.cdaType = cdaType
        self.netsuiteId = netsuiteId
        self.netsuiteStatus = netsuiteStatus
        self.netsuiteLastCheckedAt = netsuiteLastCheckedAt
        self.GrossCommissionIncome = GrossCommissionIncome
        self.NetCommissionIncome = NetCommissionIncome
        self.NetCommissionRemainingPercent = NetCommissionRemainingPercent
        self.NetCommissionRemainingAmount = NetCommissionRemainingAmount
        self.frontEndVersion = frontEndVersion
        self.agentSplitAmount = agentSplitAmount
        self.compassTeamId = compassTeamId
        self.netsuiteOverallStatus = netsuiteOverallStatus
        self.netsuiteOverallLastCheckedAt = netsuiteOverallLastCheckedAt
        self.vendorBillLastCheckedAt = vendorBillLastCheckedAt
        self.dateAgentPaid = dateAgentPaid
        self.dmsTransactionId = dmsTransactionId
        self.btId = btId
        self.useDefaultAgentSplitPercent = useDefaultAgentSplitPercent
        self.notReadyForCSReview = notReadyForCSReview
        self.allocationFeeType = allocationFeeType
        self.commissionRemainingPercent = commissionRemainingPercent
        self.commissionRemainingAmount = commissionRemainingAmount
        self.linkedDmsTransactionId = linkedDmsTransactionId
        self.dealType = dealType
        self.referredAgent = referredAgent
        self.shouldAddGeneralExciseTax = shouldAddGeneralExciseTax
        self.escrowTitle = escrowTitle

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.contractGrossAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.sideRepresented = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.brokerFee = PercentOrAmount()
                    self.brokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype144, _size147) = iprot.readListBegin()
                    for _i145 in range(_size147):
                        _elem146 = Fee()
                        _elem146.read(iprot)
                        self.fees.append(_elem146)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.offMarketListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype148, _size151) = iprot.readListBegin()
                    for _i149 in range(_size151):
                        _elem150 = Allocation()
                        _elem150.read(iprot)
                        self.allocations.append(_elem150)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.withExternalBroker = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.externalBrokerageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.externalBrokerName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.externalBrokerEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I64:
                    self.submittedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.LIST:
                    self.files = []
                    (_etype152, _size155) = iprot.readListBegin()
                    for _i153 in range(_size155):
                        _elem154 = File()
                        _elem154.read(iprot)
                        self.files.append(_elem154)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.DOUBLE:
                    self.agentSplitOverridePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.agentSplitOverrideNotes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I32:
                    self.agentSplitOverrideReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.STRING:
                    self.submittedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRING:
                    self.submittedByName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.STRING:
                    self.submittedByAgentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.notesForPrincipal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.LIST:
                    self.passThroughFees = []
                    (_etype156, _size159) = iprot.readListBegin()
                    for _i157 in range(_size159):
                        _elem158 = PassThroughFee()
                        _elem158.read(iprot)
                        self.passThroughFees.append(_elem158)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.BOOL:
                    self.ownerPaysBrokerFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.I32:
                    self.cdaType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.STRING:
                    self.netsuiteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.STRING:
                    self.netsuiteStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.I64:
                    self.netsuiteLastCheckedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.DOUBLE:
                    self.GrossCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.DOUBLE:
                    self.NetCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.DOUBLE:
                    self.agentSplitAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.STRING:
                    self.netsuiteOverallStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.I64:
                    self.netsuiteOverallLastCheckedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.I64:
                    self.vendorBillLastCheckedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.I64:
                    self.dateAgentPaid = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 62:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 63:
                if ftype == TType.BOOL:
                    self.useDefaultAgentSplitPercent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 64:
                if ftype == TType.BOOL:
                    self.notReadyForCSReview = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 65:
                if ftype == TType.I32:
                    self.allocationFeeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 66:
                if ftype == TType.DOUBLE:
                    self.commissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 67:
                if ftype == TType.DOUBLE:
                    self.commissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 68:
                if ftype == TType.STRING:
                    self.linkedDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 69:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 70:
                if ftype == TType.STRUCT:
                    self.referredAgent = CounterParty()
                    self.referredAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 71:
                if ftype == TType.BOOL:
                    self.shouldAddGeneralExciseTax = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 72:
                if ftype == TType.STRUCT:
                    self.escrowTitle = gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes.EscrowTitle()
                    self.escrowTitle.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Closing')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.contractGrossAmount is not None:
            oprot.writeFieldBegin('contractGrossAmount', TType.DOUBLE, 4)
            oprot.writeDouble(self.contractGrossAmount)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 5)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 6)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.STRING, 9)
            oprot.writeString(self.sideRepresented.encode('utf-8') if sys.version_info[0] == 2 else self.sideRepresented)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 10)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 11)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.brokerFee is not None:
            oprot.writeFieldBegin('brokerFee', TType.STRUCT, 12)
            self.brokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 13)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 16)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter160 in self.fees:
                _iter160.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.offMarketListing is not None:
            oprot.writeFieldBegin('offMarketListing', TType.BOOL, 18)
            oprot.writeBool(self.offMarketListing)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter161 in self.allocations:
                _iter161.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 21)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.withExternalBroker is not None:
            oprot.writeFieldBegin('withExternalBroker', TType.BOOL, 22)
            oprot.writeBool(self.withExternalBroker)
            oprot.writeFieldEnd()
        if self.externalBrokerageName is not None:
            oprot.writeFieldBegin('externalBrokerageName', TType.STRING, 23)
            oprot.writeString(self.externalBrokerageName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerageName)
            oprot.writeFieldEnd()
        if self.externalBrokerName is not None:
            oprot.writeFieldBegin('externalBrokerName', TType.STRING, 24)
            oprot.writeString(self.externalBrokerName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerName)
            oprot.writeFieldEnd()
        if self.externalBrokerEmail is not None:
            oprot.writeFieldBegin('externalBrokerEmail', TType.STRING, 25)
            oprot.writeString(self.externalBrokerEmail.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerEmail)
            oprot.writeFieldEnd()
        if self.submittedAt is not None:
            oprot.writeFieldBegin('submittedAt', TType.I64, 26)
            oprot.writeI64(self.submittedAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 27)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 28)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 29)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.files is not None:
            oprot.writeFieldBegin('files', TType.LIST, 30)
            oprot.writeListBegin(TType.STRUCT, len(self.files))
            for _iter162 in self.files:
                _iter162.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentSplitOverridePercent is not None:
            oprot.writeFieldBegin('agentSplitOverridePercent', TType.DOUBLE, 31)
            oprot.writeDouble(self.agentSplitOverridePercent)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideNotes is not None:
            oprot.writeFieldBegin('agentSplitOverrideNotes', TType.STRING, 32)
            oprot.writeString(self.agentSplitOverrideNotes.encode('utf-8') if sys.version_info[0] == 2 else self.agentSplitOverrideNotes)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideReason is not None:
            oprot.writeFieldBegin('agentSplitOverrideReason', TType.I32, 33)
            oprot.writeI32(self.agentSplitOverrideReason)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 34)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 35)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 36)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.submittedById is not None:
            oprot.writeFieldBegin('submittedById', TType.STRING, 37)
            oprot.writeString(self.submittedById.encode('utf-8') if sys.version_info[0] == 2 else self.submittedById)
            oprot.writeFieldEnd()
        if self.submittedByName is not None:
            oprot.writeFieldBegin('submittedByName', TType.STRING, 38)
            oprot.writeString(self.submittedByName.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByName)
            oprot.writeFieldEnd()
        if self.submittedByAgentMasterDataId is not None:
            oprot.writeFieldBegin('submittedByAgentMasterDataId', TType.STRING, 39)
            oprot.writeString(self.submittedByAgentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByAgentMasterDataId)
            oprot.writeFieldEnd()
        if self.notesForPrincipal is not None:
            oprot.writeFieldBegin('notesForPrincipal', TType.STRING, 40)
            oprot.writeString(self.notesForPrincipal.encode('utf-8') if sys.version_info[0] == 2 else self.notesForPrincipal)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 41)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 42)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 43)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.passThroughFees is not None:
            oprot.writeFieldBegin('passThroughFees', TType.LIST, 44)
            oprot.writeListBegin(TType.STRUCT, len(self.passThroughFees))
            for _iter163 in self.passThroughFees:
                _iter163.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ownerPaysBrokerFee is not None:
            oprot.writeFieldBegin('ownerPaysBrokerFee', TType.BOOL, 45)
            oprot.writeBool(self.ownerPaysBrokerFee)
            oprot.writeFieldEnd()
        if self.cdaType is not None:
            oprot.writeFieldBegin('cdaType', TType.I32, 46)
            oprot.writeI32(self.cdaType)
            oprot.writeFieldEnd()
        if self.netsuiteId is not None:
            oprot.writeFieldBegin('netsuiteId', TType.STRING, 47)
            oprot.writeString(self.netsuiteId.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteId)
            oprot.writeFieldEnd()
        if self.netsuiteStatus is not None:
            oprot.writeFieldBegin('netsuiteStatus', TType.STRING, 48)
            oprot.writeString(self.netsuiteStatus.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteStatus)
            oprot.writeFieldEnd()
        if self.netsuiteLastCheckedAt is not None:
            oprot.writeFieldBegin('netsuiteLastCheckedAt', TType.I64, 49)
            oprot.writeI64(self.netsuiteLastCheckedAt)
            oprot.writeFieldEnd()
        if self.GrossCommissionIncome is not None:
            oprot.writeFieldBegin('GrossCommissionIncome', TType.DOUBLE, 50)
            oprot.writeDouble(self.GrossCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionIncome is not None:
            oprot.writeFieldBegin('NetCommissionIncome', TType.DOUBLE, 51)
            oprot.writeDouble(self.NetCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingPercent is not None:
            oprot.writeFieldBegin('NetCommissionRemainingPercent', TType.DOUBLE, 52)
            oprot.writeDouble(self.NetCommissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingAmount is not None:
            oprot.writeFieldBegin('NetCommissionRemainingAmount', TType.DOUBLE, 53)
            oprot.writeDouble(self.NetCommissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 54)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.agentSplitAmount is not None:
            oprot.writeFieldBegin('agentSplitAmount', TType.DOUBLE, 55)
            oprot.writeDouble(self.agentSplitAmount)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 56)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.netsuiteOverallStatus is not None:
            oprot.writeFieldBegin('netsuiteOverallStatus', TType.STRING, 57)
            oprot.writeString(self.netsuiteOverallStatus.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteOverallStatus)
            oprot.writeFieldEnd()
        if self.netsuiteOverallLastCheckedAt is not None:
            oprot.writeFieldBegin('netsuiteOverallLastCheckedAt', TType.I64, 58)
            oprot.writeI64(self.netsuiteOverallLastCheckedAt)
            oprot.writeFieldEnd()
        if self.vendorBillLastCheckedAt is not None:
            oprot.writeFieldBegin('vendorBillLastCheckedAt', TType.I64, 59)
            oprot.writeI64(self.vendorBillLastCheckedAt)
            oprot.writeFieldEnd()
        if self.dateAgentPaid is not None:
            oprot.writeFieldBegin('dateAgentPaid', TType.I64, 60)
            oprot.writeI64(self.dateAgentPaid)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 61)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 62)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        if self.useDefaultAgentSplitPercent is not None:
            oprot.writeFieldBegin('useDefaultAgentSplitPercent', TType.BOOL, 63)
            oprot.writeBool(self.useDefaultAgentSplitPercent)
            oprot.writeFieldEnd()
        if self.notReadyForCSReview is not None:
            oprot.writeFieldBegin('notReadyForCSReview', TType.BOOL, 64)
            oprot.writeBool(self.notReadyForCSReview)
            oprot.writeFieldEnd()
        if self.allocationFeeType is not None:
            oprot.writeFieldBegin('allocationFeeType', TType.I32, 65)
            oprot.writeI32(self.allocationFeeType)
            oprot.writeFieldEnd()
        if self.commissionRemainingPercent is not None:
            oprot.writeFieldBegin('commissionRemainingPercent', TType.DOUBLE, 66)
            oprot.writeDouble(self.commissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.commissionRemainingAmount is not None:
            oprot.writeFieldBegin('commissionRemainingAmount', TType.DOUBLE, 67)
            oprot.writeDouble(self.commissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.linkedDmsTransactionId is not None:
            oprot.writeFieldBegin('linkedDmsTransactionId', TType.STRING, 68)
            oprot.writeString(self.linkedDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.linkedDmsTransactionId)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 69)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.referredAgent is not None:
            oprot.writeFieldBegin('referredAgent', TType.STRUCT, 70)
            self.referredAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.shouldAddGeneralExciseTax is not None:
            oprot.writeFieldBegin('shouldAddGeneralExciseTax', TType.BOOL, 71)
            oprot.writeBool(self.shouldAddGeneralExciseTax)
            oprot.writeFieldEnd()
        if self.escrowTitle is not None:
            oprot.writeFieldBegin('escrowTitle', TType.STRUCT, 72)
            self.escrowTitle.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosingRequest(object):
    """
    Attributes:
     - closingId
     - createdAt
     - updatedAt
     - contractGrossAmount
     - closeDate
     - address
     - sideRepresented
     - listingType
     - status
     - brokerFee
     - isCompassLead
     - propertyType
     - fees
     - offMarketListing
     - allocations
     - notes
     - withExternalBroker
     - externalBrokerageName
     - externalBrokerName
     - externalBrokerEmail
     - listingIdSHA
     - files
     - agentName
     - agentSplitOverridePercent
     - agentSplitOverrideNotes
     - agentSplitOverrideReason
     - zipCode
     - teamId
     - submittedById
     - submittedByName
     - submittedByAgentMasterDataId
     - notesForPrincipal
     - city
     - state
     - passThroughFees
     - ownerPaysBrokerFee
     - cdaType
     - GrossCommissionIncome
     - NetCommissionIncome
     - NetCommissionRemainingPercent
     - NetCommissionRemainingAmount
     - frontEndVersion
     - runFullValidation
     - role
     - compassTeamId
     - email
     - userId
     - impersonatorId
     - agentMasterDataId
     - dmsTransactionId
     - btId
     - notReadyForCSReview
     - allocationFeeType
     - commissionRemainingPercent
     - commissionRemainingAmount
     - dealListingId
     - linkedDmsTransactionId
     - dealType
     - referredAgent
     - shouldAddGeneralExciseTax
     - escrowTitle
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.DOUBLE, 'contractGrossAmount', None, None, ),  # 4
        (5, TType.STRING, 'closeDate', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'address', 'UTF8', None, ),  # 6
        None,  # 7
        None,  # 8
        (9, TType.STRING, 'sideRepresented', 'UTF8', None, ),  # 9
        (10, TType.I32, 'listingType', None, None, ),  # 10
        (11, TType.I32, 'status', None, None, ),  # 11
        (12, TType.STRUCT, 'brokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 12
        (13, TType.BOOL, 'isCompassLead', None, None, ),  # 13
        None,  # 14
        None,  # 15
        (16, TType.I32, 'propertyType', None, None, ),  # 16
        (17, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 17
        (18, TType.BOOL, 'offMarketListing', None, None, ),  # 18
        None,  # 19
        (20, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 20
        (21, TType.STRING, 'notes', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'withExternalBroker', None, None, ),  # 22
        (23, TType.STRING, 'externalBrokerageName', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'externalBrokerName', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'externalBrokerEmail', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 26
        (27, TType.LIST, 'files', (TType.STRUCT, (File, File.thrift_spec), False), None, ),  # 27
        (28, TType.STRING, 'agentName', 'UTF8', None, ),  # 28
        (29, TType.DOUBLE, 'agentSplitOverridePercent', None, None, ),  # 29
        (30, TType.STRING, 'agentSplitOverrideNotes', 'UTF8', None, ),  # 30
        (31, TType.I32, 'agentSplitOverrideReason', None, None, ),  # 31
        (32, TType.STRING, 'zipCode', 'UTF8', None, ),  # 32
        (33, TType.STRING, 'teamId', 'UTF8', None, ),  # 33
        (34, TType.STRING, 'submittedById', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'submittedByName', 'UTF8', None, ),  # 35
        (36, TType.STRING, 'submittedByAgentMasterDataId', 'UTF8', None, ),  # 36
        (37, TType.STRING, 'notesForPrincipal', 'UTF8', None, ),  # 37
        (38, TType.STRING, 'city', 'UTF8', None, ),  # 38
        (39, TType.STRING, 'state', 'UTF8', None, ),  # 39
        (40, TType.LIST, 'passThroughFees', (TType.STRUCT, (PassThroughFee, PassThroughFee.thrift_spec), False), None, ),  # 40
        (41, TType.BOOL, 'ownerPaysBrokerFee', None, None, ),  # 41
        (42, TType.I32, 'cdaType', None, None, ),  # 42
        (43, TType.DOUBLE, 'GrossCommissionIncome', None, None, ),  # 43
        (44, TType.DOUBLE, 'NetCommissionIncome', None, None, ),  # 44
        (45, TType.DOUBLE, 'NetCommissionRemainingPercent', None, None, ),  # 45
        (46, TType.DOUBLE, 'NetCommissionRemainingAmount', None, None, ),  # 46
        (47, TType.I32, 'frontEndVersion', None, None, ),  # 47
        (48, TType.BOOL, 'runFullValidation', None, None, ),  # 48
        (49, TType.STRING, 'role', 'UTF8', None, ),  # 49
        (50, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 50
        (51, TType.STRING, 'email', 'UTF8', None, ),  # 51
        (52, TType.STRING, 'userId', 'UTF8', None, ),  # 52
        (53, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 53
        (54, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 54
        (55, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 55
        (56, TType.STRING, 'btId', 'UTF8', None, ),  # 56
        (57, TType.BOOL, 'notReadyForCSReview', None, None, ),  # 57
        (58, TType.I32, 'allocationFeeType', None, None, ),  # 58
        (59, TType.DOUBLE, 'commissionRemainingPercent', None, None, ),  # 59
        (60, TType.DOUBLE, 'commissionRemainingAmount', None, None, ),  # 60
        (61, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 61
        (62, TType.STRING, 'linkedDmsTransactionId', 'UTF8', None, ),  # 62
        (63, TType.I32, 'dealType', None, None, ),  # 63
        (64, TType.STRUCT, 'referredAgent', (CounterParty, CounterParty.thrift_spec), None, ),  # 64
        (65, TType.BOOL, 'shouldAddGeneralExciseTax', None, None, ),  # 65
        (66, TType.STRUCT, 'escrowTitle', (gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes.EscrowTitle, gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes.EscrowTitle.thrift_spec), None, ),  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, closingId=None, createdAt=None, updatedAt=None, contractGrossAmount=None, closeDate=None, address=None, sideRepresented=None, listingType=None, status=None, brokerFee=None, isCompassLead=None, propertyType=None, fees=None, offMarketListing=None, allocations=None, notes=None, withExternalBroker=None, externalBrokerageName=None, externalBrokerName=None, externalBrokerEmail=None, listingIdSHA=None, files=None, agentName=None, agentSplitOverridePercent=None, agentSplitOverrideNotes=None, agentSplitOverrideReason=None, zipCode=None, teamId=None, submittedById=None, submittedByName=None, submittedByAgentMasterDataId=None, notesForPrincipal=None, city=None, state=None, passThroughFees=None, ownerPaysBrokerFee=None, cdaType=None, GrossCommissionIncome=None, NetCommissionIncome=None, NetCommissionRemainingPercent=None, NetCommissionRemainingAmount=None, frontEndVersion=None, runFullValidation=None, role=None, compassTeamId=None, email=None, userId=None, impersonatorId=None, agentMasterDataId=None, dmsTransactionId=None, btId=None, notReadyForCSReview=None, allocationFeeType=None, commissionRemainingPercent=None, commissionRemainingAmount=None, dealListingId=None, linkedDmsTransactionId=None, dealType=None, referredAgent=None, shouldAddGeneralExciseTax=None, escrowTitle=None, headers=None, ):
        self.closingId = closingId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.contractGrossAmount = contractGrossAmount
        self.closeDate = closeDate
        self.address = address
        self.sideRepresented = sideRepresented
        self.listingType = listingType
        self.status = status
        self.brokerFee = brokerFee
        self.isCompassLead = isCompassLead
        self.propertyType = propertyType
        self.fees = fees
        self.offMarketListing = offMarketListing
        self.allocations = allocations
        self.notes = notes
        self.withExternalBroker = withExternalBroker
        self.externalBrokerageName = externalBrokerageName
        self.externalBrokerName = externalBrokerName
        self.externalBrokerEmail = externalBrokerEmail
        self.listingIdSHA = listingIdSHA
        self.files = files
        self.agentName = agentName
        self.agentSplitOverridePercent = agentSplitOverridePercent
        self.agentSplitOverrideNotes = agentSplitOverrideNotes
        self.agentSplitOverrideReason = agentSplitOverrideReason
        self.zipCode = zipCode
        self.teamId = teamId
        self.submittedById = submittedById
        self.submittedByName = submittedByName
        self.submittedByAgentMasterDataId = submittedByAgentMasterDataId
        self.notesForPrincipal = notesForPrincipal
        self.city = city
        self.state = state
        self.passThroughFees = passThroughFees
        self.ownerPaysBrokerFee = ownerPaysBrokerFee
        self.cdaType = cdaType
        self.GrossCommissionIncome = GrossCommissionIncome
        self.NetCommissionIncome = NetCommissionIncome
        self.NetCommissionRemainingPercent = NetCommissionRemainingPercent
        self.NetCommissionRemainingAmount = NetCommissionRemainingAmount
        self.frontEndVersion = frontEndVersion
        self.runFullValidation = runFullValidation
        self.role = role
        self.compassTeamId = compassTeamId
        self.email = email
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.agentMasterDataId = agentMasterDataId
        self.dmsTransactionId = dmsTransactionId
        self.btId = btId
        self.notReadyForCSReview = notReadyForCSReview
        self.allocationFeeType = allocationFeeType
        self.commissionRemainingPercent = commissionRemainingPercent
        self.commissionRemainingAmount = commissionRemainingAmount
        self.dealListingId = dealListingId
        self.linkedDmsTransactionId = linkedDmsTransactionId
        self.dealType = dealType
        self.referredAgent = referredAgent
        self.shouldAddGeneralExciseTax = shouldAddGeneralExciseTax
        self.escrowTitle = escrowTitle
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.contractGrossAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.sideRepresented = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.brokerFee = PercentOrAmount()
                    self.brokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype164, _size167) = iprot.readListBegin()
                    for _i165 in range(_size167):
                        _elem166 = Fee()
                        _elem166.read(iprot)
                        self.fees.append(_elem166)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.offMarketListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype168, _size171) = iprot.readListBegin()
                    for _i169 in range(_size171):
                        _elem170 = Allocation()
                        _elem170.read(iprot)
                        self.allocations.append(_elem170)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.withExternalBroker = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.externalBrokerageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.externalBrokerName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.externalBrokerEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.LIST:
                    self.files = []
                    (_etype172, _size175) = iprot.readListBegin()
                    for _i173 in range(_size175):
                        _elem174 = File()
                        _elem174.read(iprot)
                        self.files.append(_elem174)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.DOUBLE:
                    self.agentSplitOverridePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.agentSplitOverrideNotes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.I32:
                    self.agentSplitOverrideReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.submittedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.submittedByName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.submittedByAgentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.STRING:
                    self.notesForPrincipal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.LIST:
                    self.passThroughFees = []
                    (_etype176, _size179) = iprot.readListBegin()
                    for _i177 in range(_size179):
                        _elem178 = PassThroughFee()
                        _elem178.read(iprot)
                        self.passThroughFees.append(_elem178)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.BOOL:
                    self.ownerPaysBrokerFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.I32:
                    self.cdaType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.DOUBLE:
                    self.GrossCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.DOUBLE:
                    self.NetCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.BOOL:
                    self.runFullValidation = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.STRING:
                    self.role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.BOOL:
                    self.notReadyForCSReview = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.I32:
                    self.allocationFeeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.DOUBLE:
                    self.commissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.DOUBLE:
                    self.commissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 62:
                if ftype == TType.STRING:
                    self.linkedDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 63:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 64:
                if ftype == TType.STRUCT:
                    self.referredAgent = CounterParty()
                    self.referredAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 65:
                if ftype == TType.BOOL:
                    self.shouldAddGeneralExciseTax = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 66:
                if ftype == TType.STRUCT:
                    self.escrowTitle = gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes.EscrowTitle()
                    self.escrowTitle.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype181, _vtype182, _size185) = iprot.readMapBegin()
                    for _i180 in range(_size185):
                        _key183 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val184 = []
                        (_etype186, _size189) = iprot.readListBegin()
                        for _i187 in range(_size189):
                            _elem188 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val184.append(_elem188)
                        iprot.readListEnd()
                        self.headers[_key183] = _val184
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosingRequest')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.contractGrossAmount is not None:
            oprot.writeFieldBegin('contractGrossAmount', TType.DOUBLE, 4)
            oprot.writeDouble(self.contractGrossAmount)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 5)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 6)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.STRING, 9)
            oprot.writeString(self.sideRepresented.encode('utf-8') if sys.version_info[0] == 2 else self.sideRepresented)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 10)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 11)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.brokerFee is not None:
            oprot.writeFieldBegin('brokerFee', TType.STRUCT, 12)
            self.brokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 13)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 16)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter190 in self.fees:
                _iter190.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.offMarketListing is not None:
            oprot.writeFieldBegin('offMarketListing', TType.BOOL, 18)
            oprot.writeBool(self.offMarketListing)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter191 in self.allocations:
                _iter191.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 21)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.withExternalBroker is not None:
            oprot.writeFieldBegin('withExternalBroker', TType.BOOL, 22)
            oprot.writeBool(self.withExternalBroker)
            oprot.writeFieldEnd()
        if self.externalBrokerageName is not None:
            oprot.writeFieldBegin('externalBrokerageName', TType.STRING, 23)
            oprot.writeString(self.externalBrokerageName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerageName)
            oprot.writeFieldEnd()
        if self.externalBrokerName is not None:
            oprot.writeFieldBegin('externalBrokerName', TType.STRING, 24)
            oprot.writeString(self.externalBrokerName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerName)
            oprot.writeFieldEnd()
        if self.externalBrokerEmail is not None:
            oprot.writeFieldBegin('externalBrokerEmail', TType.STRING, 25)
            oprot.writeString(self.externalBrokerEmail.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerEmail)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 26)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.files is not None:
            oprot.writeFieldBegin('files', TType.LIST, 27)
            oprot.writeListBegin(TType.STRUCT, len(self.files))
            for _iter192 in self.files:
                _iter192.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 28)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.agentSplitOverridePercent is not None:
            oprot.writeFieldBegin('agentSplitOverridePercent', TType.DOUBLE, 29)
            oprot.writeDouble(self.agentSplitOverridePercent)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideNotes is not None:
            oprot.writeFieldBegin('agentSplitOverrideNotes', TType.STRING, 30)
            oprot.writeString(self.agentSplitOverrideNotes.encode('utf-8') if sys.version_info[0] == 2 else self.agentSplitOverrideNotes)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideReason is not None:
            oprot.writeFieldBegin('agentSplitOverrideReason', TType.I32, 31)
            oprot.writeI32(self.agentSplitOverrideReason)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 32)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 33)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.submittedById is not None:
            oprot.writeFieldBegin('submittedById', TType.STRING, 34)
            oprot.writeString(self.submittedById.encode('utf-8') if sys.version_info[0] == 2 else self.submittedById)
            oprot.writeFieldEnd()
        if self.submittedByName is not None:
            oprot.writeFieldBegin('submittedByName', TType.STRING, 35)
            oprot.writeString(self.submittedByName.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByName)
            oprot.writeFieldEnd()
        if self.submittedByAgentMasterDataId is not None:
            oprot.writeFieldBegin('submittedByAgentMasterDataId', TType.STRING, 36)
            oprot.writeString(self.submittedByAgentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByAgentMasterDataId)
            oprot.writeFieldEnd()
        if self.notesForPrincipal is not None:
            oprot.writeFieldBegin('notesForPrincipal', TType.STRING, 37)
            oprot.writeString(self.notesForPrincipal.encode('utf-8') if sys.version_info[0] == 2 else self.notesForPrincipal)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 38)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 39)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.passThroughFees is not None:
            oprot.writeFieldBegin('passThroughFees', TType.LIST, 40)
            oprot.writeListBegin(TType.STRUCT, len(self.passThroughFees))
            for _iter193 in self.passThroughFees:
                _iter193.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ownerPaysBrokerFee is not None:
            oprot.writeFieldBegin('ownerPaysBrokerFee', TType.BOOL, 41)
            oprot.writeBool(self.ownerPaysBrokerFee)
            oprot.writeFieldEnd()
        if self.cdaType is not None:
            oprot.writeFieldBegin('cdaType', TType.I32, 42)
            oprot.writeI32(self.cdaType)
            oprot.writeFieldEnd()
        if self.GrossCommissionIncome is not None:
            oprot.writeFieldBegin('GrossCommissionIncome', TType.DOUBLE, 43)
            oprot.writeDouble(self.GrossCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionIncome is not None:
            oprot.writeFieldBegin('NetCommissionIncome', TType.DOUBLE, 44)
            oprot.writeDouble(self.NetCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingPercent is not None:
            oprot.writeFieldBegin('NetCommissionRemainingPercent', TType.DOUBLE, 45)
            oprot.writeDouble(self.NetCommissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingAmount is not None:
            oprot.writeFieldBegin('NetCommissionRemainingAmount', TType.DOUBLE, 46)
            oprot.writeDouble(self.NetCommissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 47)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.runFullValidation is not None:
            oprot.writeFieldBegin('runFullValidation', TType.BOOL, 48)
            oprot.writeBool(self.runFullValidation)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.STRING, 49)
            oprot.writeString(self.role.encode('utf-8') if sys.version_info[0] == 2 else self.role)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 50)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 51)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 52)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 53)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 54)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 55)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 56)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        if self.notReadyForCSReview is not None:
            oprot.writeFieldBegin('notReadyForCSReview', TType.BOOL, 57)
            oprot.writeBool(self.notReadyForCSReview)
            oprot.writeFieldEnd()
        if self.allocationFeeType is not None:
            oprot.writeFieldBegin('allocationFeeType', TType.I32, 58)
            oprot.writeI32(self.allocationFeeType)
            oprot.writeFieldEnd()
        if self.commissionRemainingPercent is not None:
            oprot.writeFieldBegin('commissionRemainingPercent', TType.DOUBLE, 59)
            oprot.writeDouble(self.commissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.commissionRemainingAmount is not None:
            oprot.writeFieldBegin('commissionRemainingAmount', TType.DOUBLE, 60)
            oprot.writeDouble(self.commissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 61)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.linkedDmsTransactionId is not None:
            oprot.writeFieldBegin('linkedDmsTransactionId', TType.STRING, 62)
            oprot.writeString(self.linkedDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.linkedDmsTransactionId)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 63)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.referredAgent is not None:
            oprot.writeFieldBegin('referredAgent', TType.STRUCT, 64)
            self.referredAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.shouldAddGeneralExciseTax is not None:
            oprot.writeFieldBegin('shouldAddGeneralExciseTax', TType.BOOL, 65)
            oprot.writeBool(self.shouldAddGeneralExciseTax)
            oprot.writeFieldEnd()
        if self.escrowTitle is not None:
            oprot.writeFieldBegin('escrowTitle', TType.STRUCT, 66)
            self.escrowTitle.write(oprot)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter194, _viter195 in self.headers.items():
                oprot.writeString(_kiter194.encode('utf-8') if sys.version_info[0] == 2 else _kiter194)
                oprot.writeListBegin(TType.STRING, len(_viter195))
                for _iter196 in _viter195:
                    oprot.writeString(_iter196.encode('utf-8') if sys.version_info[0] == 2 else _iter196)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListTeamMembersResponse(object):
    """
    Attributes:
     - status
     - teamMembers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'teamMembers', (TType.STRUCT, (TeamMember, TeamMember.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, teamMembers=None, ):
        self.status = status
        self.teamMembers = teamMembers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.teamMembers = []
                    (_etype197, _size200) = iprot.readListBegin()
                    for _i198 in range(_size200):
                        _elem199 = TeamMember()
                        _elem199.read(iprot)
                        self.teamMembers.append(_elem199)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListTeamMembersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.teamMembers is not None:
            oprot.writeFieldBegin('teamMembers', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.teamMembers))
            for _iter201 in self.teamMembers:
                _iter201.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Team(object):
    """
    Attributes:
     - teamRole
     - teamMembers
     - account
     - geo
     - requireDocuments
     - enabled
     - feeConfigs
     - showCdaQuestions
     - passThroughFeeConfigs
     - showListingFee
     - documentsRequired
     - financeEmail
     - optionalDocuments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'teamRole', (TeamRole, TeamRole.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'teamMembers', (TType.STRUCT, (TeamMember, TeamMember.thrift_spec), False), None, ),  # 2
        (3, TType.STRUCT, 'account', (TeamAccount, TeamAccount.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'geo', (Geo, Geo.thrift_spec), None, ),  # 4
        (5, TType.BOOL, 'requireDocuments', None, None, ),  # 5
        (6, TType.BOOL, 'enabled', None, None, ),  # 6
        (7, TType.LIST, 'feeConfigs', (TType.STRUCT, (FeeConfig, FeeConfig.thrift_spec), False), None, ),  # 7
        (8, TType.BOOL, 'showCdaQuestions', None, None, ),  # 8
        (9, TType.LIST, 'passThroughFeeConfigs', (TType.STRUCT, (PassThroughFeeConfig, PassThroughFeeConfig.thrift_spec), False), None, ),  # 9
        (10, TType.BOOL, 'showListingFee', None, None, ),  # 10
        (11, TType.LIST, 'documentsRequired', (TType.STRING, 'UTF8', False), None, ),  # 11
        (12, TType.STRING, 'financeEmail', 'UTF8', None, ),  # 12
        (13, TType.LIST, 'optionalDocuments', (TType.STRING, 'UTF8', False), None, ),  # 13
    )
    def __init__(self, teamRole=None, teamMembers=None, account=None, geo=None, requireDocuments=None, enabled=None, feeConfigs=None, showCdaQuestions=None, passThroughFeeConfigs=None, showListingFee=None, documentsRequired=None, financeEmail=None, optionalDocuments=None, ):
        self.teamRole = teamRole
        self.teamMembers = teamMembers
        self.account = account
        self.geo = geo
        self.requireDocuments = requireDocuments
        self.enabled = enabled
        self.feeConfigs = feeConfigs
        self.showCdaQuestions = showCdaQuestions
        self.passThroughFeeConfigs = passThroughFeeConfigs
        self.showListingFee = showListingFee
        self.documentsRequired = documentsRequired
        self.financeEmail = financeEmail
        self.optionalDocuments = optionalDocuments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.teamRole = TeamRole()
                    self.teamRole.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.teamMembers = []
                    (_etype202, _size205) = iprot.readListBegin()
                    for _i203 in range(_size205):
                        _elem204 = TeamMember()
                        _elem204.read(iprot)
                        self.teamMembers.append(_elem204)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.account = TeamAccount()
                    self.account.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.geo = Geo()
                    self.geo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.requireDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.enabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.feeConfigs = []
                    (_etype206, _size209) = iprot.readListBegin()
                    for _i207 in range(_size209):
                        _elem208 = FeeConfig()
                        _elem208.read(iprot)
                        self.feeConfigs.append(_elem208)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.showCdaQuestions = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.passThroughFeeConfigs = []
                    (_etype210, _size213) = iprot.readListBegin()
                    for _i211 in range(_size213):
                        _elem212 = PassThroughFeeConfig()
                        _elem212.read(iprot)
                        self.passThroughFeeConfigs.append(_elem212)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.showListingFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.documentsRequired = []
                    (_etype214, _size217) = iprot.readListBegin()
                    for _i215 in range(_size217):
                        _elem216 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.documentsRequired.append(_elem216)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.financeEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.optionalDocuments = []
                    (_etype218, _size221) = iprot.readListBegin()
                    for _i219 in range(_size221):
                        _elem220 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.optionalDocuments.append(_elem220)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Team')
        if self.teamRole is not None:
            oprot.writeFieldBegin('teamRole', TType.STRUCT, 1)
            self.teamRole.write(oprot)
            oprot.writeFieldEnd()
        if self.teamMembers is not None:
            oprot.writeFieldBegin('teamMembers', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.teamMembers))
            for _iter222 in self.teamMembers:
                _iter222.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.account is not None:
            oprot.writeFieldBegin('account', TType.STRUCT, 3)
            self.account.write(oprot)
            oprot.writeFieldEnd()
        if self.geo is not None:
            oprot.writeFieldBegin('geo', TType.STRUCT, 4)
            self.geo.write(oprot)
            oprot.writeFieldEnd()
        if self.requireDocuments is not None:
            oprot.writeFieldBegin('requireDocuments', TType.BOOL, 5)
            oprot.writeBool(self.requireDocuments)
            oprot.writeFieldEnd()
        if self.enabled is not None:
            oprot.writeFieldBegin('enabled', TType.BOOL, 6)
            oprot.writeBool(self.enabled)
            oprot.writeFieldEnd()
        if self.feeConfigs is not None:
            oprot.writeFieldBegin('feeConfigs', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.feeConfigs))
            for _iter223 in self.feeConfigs:
                _iter223.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.showCdaQuestions is not None:
            oprot.writeFieldBegin('showCdaQuestions', TType.BOOL, 8)
            oprot.writeBool(self.showCdaQuestions)
            oprot.writeFieldEnd()
        if self.passThroughFeeConfigs is not None:
            oprot.writeFieldBegin('passThroughFeeConfigs', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.passThroughFeeConfigs))
            for _iter224 in self.passThroughFeeConfigs:
                _iter224.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.showListingFee is not None:
            oprot.writeFieldBegin('showListingFee', TType.BOOL, 10)
            oprot.writeBool(self.showListingFee)
            oprot.writeFieldEnd()
        if self.documentsRequired is not None:
            oprot.writeFieldBegin('documentsRequired', TType.LIST, 11)
            oprot.writeListBegin(TType.STRING, len(self.documentsRequired))
            for _iter225 in self.documentsRequired:
                oprot.writeString(_iter225.encode('utf-8') if sys.version_info[0] == 2 else _iter225)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.financeEmail is not None:
            oprot.writeFieldBegin('financeEmail', TType.STRING, 12)
            oprot.writeString(self.financeEmail.encode('utf-8') if sys.version_info[0] == 2 else self.financeEmail)
            oprot.writeFieldEnd()
        if self.optionalDocuments is not None:
            oprot.writeFieldBegin('optionalDocuments', TType.LIST, 13)
            oprot.writeListBegin(TType.STRING, len(self.optionalDocuments))
            for _iter226 in self.optionalDocuments:
                oprot.writeString(_iter226.encode('utf-8') if sys.version_info[0] == 2 else _iter226)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ValidateOneFieldRequest(object):
    """
    Attributes:
     - closingId
     - createdAt
     - updatedAt
     - contractGrossAmount
     - closeDate
     - address
     - sideRepresented
     - listingType
     - status
     - brokerFee
     - isCompassLead
     - propertyType
     - fees
     - offMarketListing
     - allocations
     - notes
     - withExternalBroker
     - externalBrokerageName
     - externalBrokerName
     - externalBrokerEmail
     - submittedAt
     - userId
     - agentName
     - listingIdSHA
     - files
     - agentSplitOverridePercent
     - agentSplitOverrideNotes
     - agentSplitOverrideReason
     - agentMasterDataId
     - zipCode
     - teamId
     - submittedById
     - submittedByName
     - submittedByAgentMasterDataId
     - notesForPrincipal
     - city
     - state
     - url
     - passThroughFees
     - ownerPaysBrokerFee
     - cdaType
     - netsuiteId
     - netsuiteStatus
     - netsuiteLastCheckedAt
     - fieldName
     - role
     - requireDocuments
     - GrossCommissionIncome
     - NetCommissionIncome
     - NetCommissionRemainingPercent
     - NetCommissionRemainingAmount
     - frontEndVersion
     - agentSplitAmount
     - compassTeamId
     - documentsRequired
     - email
     - impersonatorId
     - commissionRemainingPercent
     - commissionRemainingAmount
     - dmsTransactionId
     - headers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'closingId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.DOUBLE, 'contractGrossAmount', None, None, ),  # 4
        (5, TType.STRING, 'closeDate', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'address', 'UTF8', None, ),  # 6
        None,  # 7
        None,  # 8
        (9, TType.STRING, 'sideRepresented', 'UTF8', None, ),  # 9
        (10, TType.I32, 'listingType', None, None, ),  # 10
        (11, TType.I32, 'status', None, None, ),  # 11
        (12, TType.STRUCT, 'brokerFee', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 12
        (13, TType.BOOL, 'isCompassLead', None, None, ),  # 13
        None,  # 14
        None,  # 15
        (16, TType.I32, 'propertyType', None, None, ),  # 16
        (17, TType.LIST, 'fees', (TType.STRUCT, (Fee, Fee.thrift_spec), False), None, ),  # 17
        (18, TType.BOOL, 'offMarketListing', None, None, ),  # 18
        None,  # 19
        (20, TType.LIST, 'allocations', (TType.STRUCT, (Allocation, Allocation.thrift_spec), False), None, ),  # 20
        (21, TType.STRING, 'notes', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'withExternalBroker', None, None, ),  # 22
        (23, TType.STRING, 'externalBrokerageName', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'externalBrokerName', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'externalBrokerEmail', 'UTF8', None, ),  # 25
        (26, TType.I64, 'submittedAt', None, None, ),  # 26
        (27, TType.STRING, 'userId', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'agentName', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 29
        (30, TType.LIST, 'files', (TType.STRUCT, (File, File.thrift_spec), False), None, ),  # 30
        (31, TType.DOUBLE, 'agentSplitOverridePercent', None, None, ),  # 31
        (32, TType.STRING, 'agentSplitOverrideNotes', 'UTF8', None, ),  # 32
        (33, TType.I32, 'agentSplitOverrideReason', None, None, ),  # 33
        (34, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'zipCode', 'UTF8', None, ),  # 35
        (36, TType.STRING, 'teamId', 'UTF8', None, ),  # 36
        (37, TType.STRING, 'submittedById', 'UTF8', None, ),  # 37
        (38, TType.STRING, 'submittedByName', 'UTF8', None, ),  # 38
        (39, TType.STRING, 'submittedByAgentMasterDataId', 'UTF8', None, ),  # 39
        (40, TType.STRING, 'notesForPrincipal', 'UTF8', None, ),  # 40
        (41, TType.STRING, 'city', 'UTF8', None, ),  # 41
        (42, TType.STRING, 'state', 'UTF8', None, ),  # 42
        (43, TType.STRING, 'url', 'UTF8', None, ),  # 43
        (44, TType.LIST, 'passThroughFees', (TType.STRUCT, (PassThroughFee, PassThroughFee.thrift_spec), False), None, ),  # 44
        (45, TType.BOOL, 'ownerPaysBrokerFee', None, None, ),  # 45
        (46, TType.I32, 'cdaType', None, None, ),  # 46
        (47, TType.STRING, 'netsuiteId', 'UTF8', None, ),  # 47
        (48, TType.STRING, 'netsuiteStatus', 'UTF8', None, ),  # 48
        (49, TType.I64, 'netsuiteLastCheckedAt', None, None, ),  # 49
        (50, TType.STRING, 'fieldName', 'UTF8', None, ),  # 50
        (51, TType.STRING, 'role', 'UTF8', None, ),  # 51
        (52, TType.BOOL, 'requireDocuments', None, None, ),  # 52
        (53, TType.DOUBLE, 'GrossCommissionIncome', None, None, ),  # 53
        (54, TType.DOUBLE, 'NetCommissionIncome', None, None, ),  # 54
        (55, TType.DOUBLE, 'NetCommissionRemainingPercent', None, None, ),  # 55
        (56, TType.DOUBLE, 'NetCommissionRemainingAmount', None, None, ),  # 56
        (57, TType.I32, 'frontEndVersion', None, None, ),  # 57
        (58, TType.DOUBLE, 'agentSplitAmount', None, None, ),  # 58
        (59, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 59
        (60, TType.LIST, 'documentsRequired', (TType.STRING, 'UTF8', False), None, ),  # 60
        (61, TType.STRING, 'email', 'UTF8', None, ),  # 61
        (62, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 62
        (63, TType.DOUBLE, 'commissionRemainingPercent', None, None, ),  # 63
        (64, TType.DOUBLE, 'commissionRemainingAmount', None, None, ),  # 64
        (65, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.MAP, 'headers', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 100
    )
    def __init__(self, closingId=None, createdAt=None, updatedAt=None, contractGrossAmount=None, closeDate=None, address=None, sideRepresented=None, listingType=None, status=None, brokerFee=None, isCompassLead=None, propertyType=None, fees=None, offMarketListing=None, allocations=None, notes=None, withExternalBroker=None, externalBrokerageName=None, externalBrokerName=None, externalBrokerEmail=None, submittedAt=None, userId=None, agentName=None, listingIdSHA=None, files=None, agentSplitOverridePercent=None, agentSplitOverrideNotes=None, agentSplitOverrideReason=None, agentMasterDataId=None, zipCode=None, teamId=None, submittedById=None, submittedByName=None, submittedByAgentMasterDataId=None, notesForPrincipal=None, city=None, state=None, url=None, passThroughFees=None, ownerPaysBrokerFee=None, cdaType=None, netsuiteId=None, netsuiteStatus=None, netsuiteLastCheckedAt=None, fieldName=None, role=None, requireDocuments=None, GrossCommissionIncome=None, NetCommissionIncome=None, NetCommissionRemainingPercent=None, NetCommissionRemainingAmount=None, frontEndVersion=None, agentSplitAmount=None, compassTeamId=None, documentsRequired=None, email=None, impersonatorId=None, commissionRemainingPercent=None, commissionRemainingAmount=None, dmsTransactionId=None, headers=None, ):
        self.closingId = closingId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.contractGrossAmount = contractGrossAmount
        self.closeDate = closeDate
        self.address = address
        self.sideRepresented = sideRepresented
        self.listingType = listingType
        self.status = status
        self.brokerFee = brokerFee
        self.isCompassLead = isCompassLead
        self.propertyType = propertyType
        self.fees = fees
        self.offMarketListing = offMarketListing
        self.allocations = allocations
        self.notes = notes
        self.withExternalBroker = withExternalBroker
        self.externalBrokerageName = externalBrokerageName
        self.externalBrokerName = externalBrokerName
        self.externalBrokerEmail = externalBrokerEmail
        self.submittedAt = submittedAt
        self.userId = userId
        self.agentName = agentName
        self.listingIdSHA = listingIdSHA
        self.files = files
        self.agentSplitOverridePercent = agentSplitOverridePercent
        self.agentSplitOverrideNotes = agentSplitOverrideNotes
        self.agentSplitOverrideReason = agentSplitOverrideReason
        self.agentMasterDataId = agentMasterDataId
        self.zipCode = zipCode
        self.teamId = teamId
        self.submittedById = submittedById
        self.submittedByName = submittedByName
        self.submittedByAgentMasterDataId = submittedByAgentMasterDataId
        self.notesForPrincipal = notesForPrincipal
        self.city = city
        self.state = state
        self.url = url
        self.passThroughFees = passThroughFees
        self.ownerPaysBrokerFee = ownerPaysBrokerFee
        self.cdaType = cdaType
        self.netsuiteId = netsuiteId
        self.netsuiteStatus = netsuiteStatus
        self.netsuiteLastCheckedAt = netsuiteLastCheckedAt
        self.fieldName = fieldName
        self.role = role
        self.requireDocuments = requireDocuments
        self.GrossCommissionIncome = GrossCommissionIncome
        self.NetCommissionIncome = NetCommissionIncome
        self.NetCommissionRemainingPercent = NetCommissionRemainingPercent
        self.NetCommissionRemainingAmount = NetCommissionRemainingAmount
        self.frontEndVersion = frontEndVersion
        self.agentSplitAmount = agentSplitAmount
        self.compassTeamId = compassTeamId
        self.documentsRequired = documentsRequired
        self.email = email
        self.impersonatorId = impersonatorId
        self.commissionRemainingPercent = commissionRemainingPercent
        self.commissionRemainingAmount = commissionRemainingAmount
        self.dmsTransactionId = dmsTransactionId
        self.headers = headers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.closingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.contractGrossAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.sideRepresented = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.brokerFee = PercentOrAmount()
                    self.brokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype227, _size230) = iprot.readListBegin()
                    for _i228 in range(_size230):
                        _elem229 = Fee()
                        _elem229.read(iprot)
                        self.fees.append(_elem229)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.offMarketListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype231, _size234) = iprot.readListBegin()
                    for _i232 in range(_size234):
                        _elem233 = Allocation()
                        _elem233.read(iprot)
                        self.allocations.append(_elem233)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.withExternalBroker = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.externalBrokerageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.externalBrokerName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.externalBrokerEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I64:
                    self.submittedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.LIST:
                    self.files = []
                    (_etype235, _size238) = iprot.readListBegin()
                    for _i236 in range(_size238):
                        _elem237 = File()
                        _elem237.read(iprot)
                        self.files.append(_elem237)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.DOUBLE:
                    self.agentSplitOverridePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.agentSplitOverrideNotes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I32:
                    self.agentSplitOverrideReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.STRING:
                    self.submittedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRING:
                    self.submittedByName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.STRING:
                    self.submittedByAgentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.notesForPrincipal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.LIST:
                    self.passThroughFees = []
                    (_etype239, _size242) = iprot.readListBegin()
                    for _i240 in range(_size242):
                        _elem241 = PassThroughFee()
                        _elem241.read(iprot)
                        self.passThroughFees.append(_elem241)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.BOOL:
                    self.ownerPaysBrokerFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.I32:
                    self.cdaType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.STRING:
                    self.netsuiteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.STRING:
                    self.netsuiteStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.I64:
                    self.netsuiteLastCheckedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.STRING:
                    self.fieldName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.STRING:
                    self.role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.BOOL:
                    self.requireDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.DOUBLE:
                    self.GrossCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.DOUBLE:
                    self.NetCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.DOUBLE:
                    self.agentSplitAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.LIST:
                    self.documentsRequired = []
                    (_etype243, _size246) = iprot.readListBegin()
                    for _i244 in range(_size246):
                        _elem245 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.documentsRequired.append(_elem245)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 62:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 63:
                if ftype == TType.DOUBLE:
                    self.commissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 64:
                if ftype == TType.DOUBLE:
                    self.commissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 65:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.MAP:
                    self.headers = {}
                    (_ktype248, _vtype249, _size252) = iprot.readMapBegin()
                    for _i247 in range(_size252):
                        _key250 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val251 = []
                        (_etype253, _size256) = iprot.readListBegin()
                        for _i254 in range(_size256):
                            _elem255 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val251.append(_elem255)
                        iprot.readListEnd()
                        self.headers[_key250] = _val251
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ValidateOneFieldRequest')
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.STRING, 1)
            oprot.writeString(self.closingId.encode('utf-8') if sys.version_info[0] == 2 else self.closingId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.contractGrossAmount is not None:
            oprot.writeFieldBegin('contractGrossAmount', TType.DOUBLE, 4)
            oprot.writeDouble(self.contractGrossAmount)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 5)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 6)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.STRING, 9)
            oprot.writeString(self.sideRepresented.encode('utf-8') if sys.version_info[0] == 2 else self.sideRepresented)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 10)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 11)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.brokerFee is not None:
            oprot.writeFieldBegin('brokerFee', TType.STRUCT, 12)
            self.brokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 13)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 16)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter257 in self.fees:
                _iter257.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.offMarketListing is not None:
            oprot.writeFieldBegin('offMarketListing', TType.BOOL, 18)
            oprot.writeBool(self.offMarketListing)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter258 in self.allocations:
                _iter258.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 21)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.withExternalBroker is not None:
            oprot.writeFieldBegin('withExternalBroker', TType.BOOL, 22)
            oprot.writeBool(self.withExternalBroker)
            oprot.writeFieldEnd()
        if self.externalBrokerageName is not None:
            oprot.writeFieldBegin('externalBrokerageName', TType.STRING, 23)
            oprot.writeString(self.externalBrokerageName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerageName)
            oprot.writeFieldEnd()
        if self.externalBrokerName is not None:
            oprot.writeFieldBegin('externalBrokerName', TType.STRING, 24)
            oprot.writeString(self.externalBrokerName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerName)
            oprot.writeFieldEnd()
        if self.externalBrokerEmail is not None:
            oprot.writeFieldBegin('externalBrokerEmail', TType.STRING, 25)
            oprot.writeString(self.externalBrokerEmail.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerEmail)
            oprot.writeFieldEnd()
        if self.submittedAt is not None:
            oprot.writeFieldBegin('submittedAt', TType.I64, 26)
            oprot.writeI64(self.submittedAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 27)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 28)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 29)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.files is not None:
            oprot.writeFieldBegin('files', TType.LIST, 30)
            oprot.writeListBegin(TType.STRUCT, len(self.files))
            for _iter259 in self.files:
                _iter259.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentSplitOverridePercent is not None:
            oprot.writeFieldBegin('agentSplitOverridePercent', TType.DOUBLE, 31)
            oprot.writeDouble(self.agentSplitOverridePercent)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideNotes is not None:
            oprot.writeFieldBegin('agentSplitOverrideNotes', TType.STRING, 32)
            oprot.writeString(self.agentSplitOverrideNotes.encode('utf-8') if sys.version_info[0] == 2 else self.agentSplitOverrideNotes)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideReason is not None:
            oprot.writeFieldBegin('agentSplitOverrideReason', TType.I32, 33)
            oprot.writeI32(self.agentSplitOverrideReason)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 34)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 35)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 36)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.submittedById is not None:
            oprot.writeFieldBegin('submittedById', TType.STRING, 37)
            oprot.writeString(self.submittedById.encode('utf-8') if sys.version_info[0] == 2 else self.submittedById)
            oprot.writeFieldEnd()
        if self.submittedByName is not None:
            oprot.writeFieldBegin('submittedByName', TType.STRING, 38)
            oprot.writeString(self.submittedByName.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByName)
            oprot.writeFieldEnd()
        if self.submittedByAgentMasterDataId is not None:
            oprot.writeFieldBegin('submittedByAgentMasterDataId', TType.STRING, 39)
            oprot.writeString(self.submittedByAgentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByAgentMasterDataId)
            oprot.writeFieldEnd()
        if self.notesForPrincipal is not None:
            oprot.writeFieldBegin('notesForPrincipal', TType.STRING, 40)
            oprot.writeString(self.notesForPrincipal.encode('utf-8') if sys.version_info[0] == 2 else self.notesForPrincipal)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 41)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 42)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 43)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.passThroughFees is not None:
            oprot.writeFieldBegin('passThroughFees', TType.LIST, 44)
            oprot.writeListBegin(TType.STRUCT, len(self.passThroughFees))
            for _iter260 in self.passThroughFees:
                _iter260.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ownerPaysBrokerFee is not None:
            oprot.writeFieldBegin('ownerPaysBrokerFee', TType.BOOL, 45)
            oprot.writeBool(self.ownerPaysBrokerFee)
            oprot.writeFieldEnd()
        if self.cdaType is not None:
            oprot.writeFieldBegin('cdaType', TType.I32, 46)
            oprot.writeI32(self.cdaType)
            oprot.writeFieldEnd()
        if self.netsuiteId is not None:
            oprot.writeFieldBegin('netsuiteId', TType.STRING, 47)
            oprot.writeString(self.netsuiteId.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteId)
            oprot.writeFieldEnd()
        if self.netsuiteStatus is not None:
            oprot.writeFieldBegin('netsuiteStatus', TType.STRING, 48)
            oprot.writeString(self.netsuiteStatus.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteStatus)
            oprot.writeFieldEnd()
        if self.netsuiteLastCheckedAt is not None:
            oprot.writeFieldBegin('netsuiteLastCheckedAt', TType.I64, 49)
            oprot.writeI64(self.netsuiteLastCheckedAt)
            oprot.writeFieldEnd()
        if self.fieldName is not None:
            oprot.writeFieldBegin('fieldName', TType.STRING, 50)
            oprot.writeString(self.fieldName.encode('utf-8') if sys.version_info[0] == 2 else self.fieldName)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.STRING, 51)
            oprot.writeString(self.role.encode('utf-8') if sys.version_info[0] == 2 else self.role)
            oprot.writeFieldEnd()
        if self.requireDocuments is not None:
            oprot.writeFieldBegin('requireDocuments', TType.BOOL, 52)
            oprot.writeBool(self.requireDocuments)
            oprot.writeFieldEnd()
        if self.GrossCommissionIncome is not None:
            oprot.writeFieldBegin('GrossCommissionIncome', TType.DOUBLE, 53)
            oprot.writeDouble(self.GrossCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionIncome is not None:
            oprot.writeFieldBegin('NetCommissionIncome', TType.DOUBLE, 54)
            oprot.writeDouble(self.NetCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingPercent is not None:
            oprot.writeFieldBegin('NetCommissionRemainingPercent', TType.DOUBLE, 55)
            oprot.writeDouble(self.NetCommissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingAmount is not None:
            oprot.writeFieldBegin('NetCommissionRemainingAmount', TType.DOUBLE, 56)
            oprot.writeDouble(self.NetCommissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 57)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.agentSplitAmount is not None:
            oprot.writeFieldBegin('agentSplitAmount', TType.DOUBLE, 58)
            oprot.writeDouble(self.agentSplitAmount)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 59)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.documentsRequired is not None:
            oprot.writeFieldBegin('documentsRequired', TType.LIST, 60)
            oprot.writeListBegin(TType.STRING, len(self.documentsRequired))
            for _iter261 in self.documentsRequired:
                oprot.writeString(_iter261.encode('utf-8') if sys.version_info[0] == 2 else _iter261)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 61)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 62)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.commissionRemainingPercent is not None:
            oprot.writeFieldBegin('commissionRemainingPercent', TType.DOUBLE, 63)
            oprot.writeDouble(self.commissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.commissionRemainingAmount is not None:
            oprot.writeFieldBegin('commissionRemainingAmount', TType.DOUBLE, 64)
            oprot.writeDouble(self.commissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 65)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.headers is not None:
            oprot.writeFieldBegin('headers', TType.MAP, 100)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.headers))
            for _kiter262, _viter263 in self.headers.items():
                oprot.writeString(_kiter262.encode('utf-8') if sys.version_info[0] == 2 else _kiter262)
                oprot.writeListBegin(TType.STRING, len(_viter263))
                for _iter264 in _viter263:
                    oprot.writeString(_iter264.encode('utf-8') if sys.version_info[0] == 2 else _iter264)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetClosingsForDmsResponse(object):
    """
    Attributes:
     - status
     - closings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'closings', (TType.STRUCT, (Closing, Closing.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, closings=None, ):
        self.status = status
        self.closings = closings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.closings = []
                    (_etype265, _size268) = iprot.readListBegin()
                    for _i266 in range(_size268):
                        _elem267 = Closing()
                        _elem267.read(iprot)
                        self.closings.append(_elem267)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetClosingsForDmsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closings is not None:
            oprot.writeFieldBegin('closings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.closings))
            for _iter269 in self.closings:
                _iter269.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosingListResponse(object):
    """
    Attributes:
     - status
     - closings
     - code
     - errors
     - error
     - closingIDsNotFound
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'closings', (TType.STRUCT, (Closing, Closing.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'code', None, None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'error', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'closingIDsNotFound', (TType.STRING, 'UTF8', False), None, ),  # 6
    )
    def __init__(self, status=None, closings=None, code=None, errors=None, error=None, closingIDsNotFound=None, ):
        self.status = status
        self.closings = closings
        self.code = code
        self.errors = errors
        self.error = error
        self.closingIDsNotFound = closingIDsNotFound

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.closings = []
                    (_etype270, _size273) = iprot.readListBegin()
                    for _i271 in range(_size273):
                        _elem272 = Closing()
                        _elem272.read(iprot)
                        self.closings.append(_elem272)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype275, _vtype276, _size279) = iprot.readMapBegin()
                    for _i274 in range(_size279):
                        _key277 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val278 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key277] = _val278
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.closingIDsNotFound = []
                    (_etype280, _size283) = iprot.readListBegin()
                    for _i281 in range(_size283):
                        _elem282 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.closingIDsNotFound.append(_elem282)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosingListResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closings is not None:
            oprot.writeFieldBegin('closings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.closings))
            for _iter284 in self.closings:
                _iter284.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 3)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter285, _viter286 in self.errors.items():
                oprot.writeString(_kiter285.encode('utf-8') if sys.version_info[0] == 2 else _kiter285)
                oprot.writeString(_viter286.encode('utf-8') if sys.version_info[0] == 2 else _viter286)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 5)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.closingIDsNotFound is not None:
            oprot.writeFieldBegin('closingIDsNotFound', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.closingIDsNotFound))
            for _iter287 in self.closingIDsNotFound:
                oprot.writeString(_iter287.encode('utf-8') if sys.version_info[0] == 2 else _iter287)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateClosingResponse(object):
    """
    Attributes:
     - status
     - closing
     - code
     - errors
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'closing', (Closing, Closing.thrift_spec), None, ),  # 2
        (3, TType.I32, 'code', None, None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'error', 'UTF8', None, ),  # 5
    )
    def __init__(self, status=None, closing=None, code=None, errors=None, error=None, ):
        self.status = status
        self.closing = closing
        self.code = code
        self.errors = errors
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.closing = Closing()
                    self.closing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype289, _vtype290, _size293) = iprot.readMapBegin()
                    for _i288 in range(_size293):
                        _key291 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val292 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key291] = _val292
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateClosingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closing is not None:
            oprot.writeFieldBegin('closing', TType.STRUCT, 2)
            self.closing.write(oprot)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 3)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter294, _viter295 in self.errors.items():
                oprot.writeString(_kiter294.encode('utf-8') if sys.version_info[0] == 2 else _kiter294)
                oprot.writeString(_viter295.encode('utf-8') if sys.version_info[0] == 2 else _viter295)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 5)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterSubmittedClosingsResponse(object):
    """
    Attributes:
     - status
     - closingIds
     - closings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'closingIds', (TType.I32, None, False), None, ),  # 2
        (3, TType.LIST, 'closings', (TType.STRUCT, (Closing, Closing.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, closingIds=None, closings=None, ):
        self.status = status
        self.closingIds = closingIds
        self.closings = closings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.closingIds = []
                    (_etype296, _size299) = iprot.readListBegin()
                    for _i297 in range(_size299):
                        _elem298 = iprot.readI32()
                        self.closingIds.append(_elem298)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.closings = []
                    (_etype300, _size303) = iprot.readListBegin()
                    for _i301 in range(_size303):
                        _elem302 = Closing()
                        _elem302.read(iprot)
                        self.closings.append(_elem302)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterSubmittedClosingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closingIds is not None:
            oprot.writeFieldBegin('closingIds', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.closingIds))
            for _iter304 in self.closingIds:
                oprot.writeI32(_iter304)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.closings is not None:
            oprot.writeFieldBegin('closings', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.closings))
            for _iter305 in self.closings:
                _iter305.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetClosingResponse(object):
    """
    Attributes:
     - status
     - closing
     - code
     - errors
     - error
     - isFetchedFromDWS
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'closing', (Closing, Closing.thrift_spec), None, ),  # 2
        (3, TType.I32, 'code', None, None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'error', 'UTF8', None, ),  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.BOOL, 'isFetchedFromDWS', None, None, ),  # 100
    )
    def __init__(self, status=None, closing=None, code=None, errors=None, error=None, isFetchedFromDWS=None, ):
        self.status = status
        self.closing = closing
        self.code = code
        self.errors = errors
        self.error = error
        self.isFetchedFromDWS = isFetchedFromDWS

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.closing = Closing()
                    self.closing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype307, _vtype308, _size311) = iprot.readMapBegin()
                    for _i306 in range(_size311):
                        _key309 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val310 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key309] = _val310
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.BOOL:
                    self.isFetchedFromDWS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetClosingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closing is not None:
            oprot.writeFieldBegin('closing', TType.STRUCT, 2)
            self.closing.write(oprot)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 3)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter312, _viter313 in self.errors.items():
                oprot.writeString(_kiter312.encode('utf-8') if sys.version_info[0] == 2 else _kiter312)
                oprot.writeString(_viter313.encode('utf-8') if sys.version_info[0] == 2 else _viter313)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 5)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.isFetchedFromDWS is not None:
            oprot.writeFieldBegin('isFetchedFromDWS', TType.BOOL, 100)
            oprot.writeBool(self.isFetchedFromDWS)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserResponse(object):
    """
    Attributes:
     - status
     - account
     - teams
     - code
     - errors
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'account', (Account, Account.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'teams', (TType.STRUCT, (Team, Team.thrift_spec), False), None, ),  # 3
        (4, TType.I32, 'code', None, None, ),  # 4
        (5, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRING, 'error', 'UTF8', None, ),  # 6
    )
    def __init__(self, status=None, account=None, teams=None, code=None, errors=None, error=None, ):
        self.status = status
        self.account = account
        self.teams = teams
        self.code = code
        self.errors = errors
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.account = Account()
                    self.account.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.teams = []
                    (_etype314, _size317) = iprot.readListBegin()
                    for _i315 in range(_size317):
                        _elem316 = Team()
                        _elem316.read(iprot)
                        self.teams.append(_elem316)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype319, _vtype320, _size323) = iprot.readMapBegin()
                    for _i318 in range(_size323):
                        _key321 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val322 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key321] = _val322
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.account is not None:
            oprot.writeFieldBegin('account', TType.STRUCT, 2)
            self.account.write(oprot)
            oprot.writeFieldEnd()
        if self.teams is not None:
            oprot.writeFieldBegin('teams', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.teams))
            for _iter324 in self.teams:
                _iter324.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 4)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter325, _viter326 in self.errors.items():
                oprot.writeString(_kiter325.encode('utf-8') if sys.version_info[0] == 2 else _kiter325)
                oprot.writeString(_viter326.encode('utf-8') if sys.version_info[0] == 2 else _viter326)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 6)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateClosingResponse(object):
    """
    Attributes:
     - status
     - closing
     - code
     - errors
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'closing', (Closing, Closing.thrift_spec), None, ),  # 2
        (3, TType.I32, 'code', None, None, ),  # 3
        (4, TType.MAP, 'errors', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRING, 'error', 'UTF8', None, ),  # 5
    )
    def __init__(self, status=None, closing=None, code=None, errors=None, error=None, ):
        self.status = status
        self.closing = closing
        self.code = code
        self.errors = errors
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.closing = Closing()
                    self.closing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.code = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.errors = {}
                    (_ktype328, _vtype329, _size332) = iprot.readMapBegin()
                    for _i327 in range(_size332):
                        _key330 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val331 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.errors[_key330] = _val331
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateClosingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.closing is not None:
            oprot.writeFieldBegin('closing', TType.STRUCT, 2)
            self.closing.write(oprot)
            oprot.writeFieldEnd()
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.I32, 3)
            oprot.writeI32(self.code)
            oprot.writeFieldEnd()
        if self.errors is not None:
            oprot.writeFieldBegin('errors', TType.MAP, 4)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.errors))
            for _kiter333, _viter334 in self.errors.items():
                oprot.writeString(_kiter333.encode('utf-8') if sys.version_info[0] == 2 else _kiter333)
                oprot.writeString(_viter334.encode('utf-8') if sys.version_info[0] == 2 else _viter334)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 5)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
