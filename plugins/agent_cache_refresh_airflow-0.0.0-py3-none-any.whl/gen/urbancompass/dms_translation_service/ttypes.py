
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.agent_finance_center.agent_finance.ttypes
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.closings.closings_service.ttypes
import gen.urbancompass.contacts.api.contact.ttypes
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_document.ttypes
import gen.urbancompass.dms_common.dms_folder.ttypes
import gen.urbancompass.dms_common.dms_glide.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.dms_region_config_service.ttypes
import gen.urbancompass.dms_state_model.ttypes
import gen.urbancompass.dms_state_service.ttypes
import gen.urbancompass.dms_translation_model.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.listing.listing_compliance.ttypes
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes
import gen.urbancompass.region_compliance_checklist_model.ttypes
import gen.urbancompass.dms_region_config_service.regions.ttypes

from thrift.transport import TTransport


class AddChecklistItemNoteRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - itemId
     - note
     - checklistItemNoteRole
     - checklistItemNoteType
     - stage
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - noteCreatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.I32, 'itemId', None, None, ),  # 5
        (6, TType.STRING, 'note', 'UTF8', None, ),  # 6
        (7, TType.I32, 'checklistItemNoteRole', None, None, ),  # 7
        (8, TType.I32, 'checklistItemNoteType', None, None, ),  # 8
        (9, TType.I32, 'stage', None, None, ),  # 9
        (10, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 12
        (13, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 13
        (14, TType.I64, 'noteCreatedAt', None, None, ),  # 14
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, itemId=None, note=None, checklistItemNoteRole=None, checklistItemNoteType=None, stage=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, signature=None, noteCreatedAt=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.itemId = itemId
        self.note = note
        self.checklistItemNoteRole = checklistItemNoteRole
        self.checklistItemNoteType = checklistItemNoteType
        self.stage = stage
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.signature = signature
        self.noteCreatedAt = noteCreatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.checklistItemNoteRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.checklistItemNoteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.noteCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddChecklistItemNoteRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 5)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 6)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.checklistItemNoteRole is not None:
            oprot.writeFieldBegin('checklistItemNoteRole', TType.I32, 7)
            oprot.writeI32(self.checklistItemNoteRole)
            oprot.writeFieldEnd()
        if self.checklistItemNoteType is not None:
            oprot.writeFieldBegin('checklistItemNoteType', TType.I32, 8)
            oprot.writeI32(self.checklistItemNoteType)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 9)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 10)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 11)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 12)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 13)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.noteCreatedAt is not None:
            oprot.writeFieldBegin('noteCreatedAt', TType.I64, 14)
            oprot.writeI64(self.noteCreatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddChecklistItemNoteResponse(object):
    """
    Attributes:
     - status
     - noteId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I64, 'noteId', None, None, ),  # 2
    )
    def __init__(self, status=None, noteId=None, ):
        self.status = status
        self.noteId = noteId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.noteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddChecklistItemNoteResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.I64, 2)
            oprot.writeI64(self.noteId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddCustomChecklistItemRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - checklistType
     - itemName
     - description
     - isRequired
     - stage
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'checklistType', None, None, ),  # 2
        (3, TType.STRING, 'itemName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'description', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'isRequired', None, None, ),  # 5
        (6, TType.I32, 'stage', None, None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'serviceName', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'token', 'UTF8', None, ),  # 12
        (13, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 13
    )
    def __init__(self, userId=None, checklistType=None, itemName=None, description=None, isRequired=None, stage=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.userId = userId
        self.checklistType = checklistType
        self.itemName = itemName
        self.description = description
        self.isRequired = isRequired
        self.stage = stage
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.itemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddCustomChecklistItemRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 2)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.itemName is not None:
            oprot.writeFieldBegin('itemName', TType.STRING, 3)
            oprot.writeString(self.itemName.encode('utf-8') if sys.version_info[0] == 2 else self.itemName)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 4)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 5)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 6)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 8)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 9)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 10)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 11)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 12)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 13)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddCustomChecklistItemResponse(object):
    """
    Attributes:
     - status
     - itemId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
    )
    def __init__(self, status=None, itemId=None, ):
        self.status = status
        self.itemId = itemId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddCustomChecklistItemResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSListingRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - team
     - dealListingId
     - propertyType
     - listingType
     - propertyAddress
     - unit
     - city
     - state
     - zipcode
     - listPrice
     - yearBuilt
     - usedConcierge
     - mediaUrl
     - expirationDate
     - yearlyRent
     - market
     - isNewConstruction
     - listDate
     - dmsAgents
     - listingId
     - mlsId
     - doNotCallLDFS
     - commissionRate
     - otherSideCommissionRate
     - submitStatus
     - isFullServiceRental
     - isHousingVoucher
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'team', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'propertyType', None, None, ),  # 9
        (10, TType.I32, 'listingType', None, None, ),  # 10
        (11, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'unit', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'city', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'state', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'zipcode', 'UTF8', None, ),  # 15
        (16, TType.DOUBLE, 'listPrice', None, None, ),  # 16
        (17, TType.I32, 'yearBuilt', None, None, ),  # 17
        None,  # 18
        (19, TType.BOOL, 'usedConcierge', None, None, ),  # 19
        (20, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'expirationDate', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'listingId', 'UTF8', None, ),  # 22
        (23, TType.DOUBLE, 'yearlyRent', None, None, ),  # 23
        (24, TType.STRING, 'market', 'UTF8', None, ),  # 24
        (25, TType.BOOL, 'isNewConstruction', None, None, ),  # 25
        (26, TType.STRING, 'listDate', 'UTF8', None, ),  # 26
        (27, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 27
        (28, TType.STRING, 'mlsId', 'UTF8', None, ),  # 28
        (29, TType.BOOL, 'doNotCallLDFS', None, None, ),  # 29
        (30, TType.STRUCT, 'commissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 30
        (31, TType.STRUCT, 'otherSideCommissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 31
        (32, TType.I32, 'submitStatus', None, None, ),  # 32
        (33, TType.BOOL, 'isFullServiceRental', None, None, ),  # 33
        (34, TType.BOOL, 'isHousingVoucher', None, None, ),  # 34
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, team=None, dealListingId=None, propertyType=None, listingType=None, propertyAddress=None, unit=None, city=None, state=None, zipcode=None, listPrice=None, yearBuilt=None, usedConcierge=None, mediaUrl=None, expirationDate=None, listingId=None, yearlyRent=None, market=None, isNewConstruction=None, listDate=None, dmsAgents=None, mlsId=None, doNotCallLDFS=None, commissionRate=None, otherSideCommissionRate=None, submitStatus=None, isFullServiceRental=None, isHousingVoucher=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.team = team
        self.dealListingId = dealListingId
        self.propertyType = propertyType
        self.listingType = listingType
        self.propertyAddress = propertyAddress
        self.unit = unit
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.yearBuilt = yearBuilt
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.expirationDate = expirationDate
        self.listingId = listingId
        self.yearlyRent = yearlyRent
        self.market = market
        self.isNewConstruction = isNewConstruction
        self.listDate = listDate
        self.dmsAgents = dmsAgents
        self.mlsId = mlsId
        self.doNotCallLDFS = doNotCallLDFS
        self.commissionRate = commissionRate
        self.otherSideCommissionRate = otherSideCommissionRate
        self.submitStatus = submitStatus
        self.isFullServiceRental = isFullServiceRental
        self.isHousingVoucher = isHousingVoucher

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.expirationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.DOUBLE:
                    self.yearlyRent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.listDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem4.read(iprot)
                        self.dmsAgents.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.BOOL:
                    self.doNotCallLDFS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.commissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.commissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRUCT:
                    self.otherSideCommissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.otherSideCommissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.BOOL:
                    self.isFullServiceRental = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.BOOL:
                    self.isHousingVoucher = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 7)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 8)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 9)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 10)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 11)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 12)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 13)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 14)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 15)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 16)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 17)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 19)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 20)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.STRING, 21)
            oprot.writeString(self.expirationDate.encode('utf-8') if sys.version_info[0] == 2 else self.expirationDate)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 22)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.yearlyRent is not None:
            oprot.writeFieldBegin('yearlyRent', TType.DOUBLE, 23)
            oprot.writeDouble(self.yearlyRent)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 24)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 25)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.STRING, 26)
            oprot.writeString(self.listDate.encode('utf-8') if sys.version_info[0] == 2 else self.listDate)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 27)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter6 in self.dmsAgents:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 28)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.doNotCallLDFS is not None:
            oprot.writeFieldBegin('doNotCallLDFS', TType.BOOL, 29)
            oprot.writeBool(self.doNotCallLDFS)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.STRUCT, 30)
            self.commissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.STRUCT, 31)
            self.otherSideCommissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 32)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        if self.isFullServiceRental is not None:
            oprot.writeFieldBegin('isFullServiceRental', TType.BOOL, 33)
            oprot.writeBool(self.isFullServiceRental)
            oprot.writeFieldEnd()
        if self.isHousingVoucher is not None:
            oprot.writeFieldBegin('isHousingVoucher', TType.BOOL, 34)
            oprot.writeBool(self.isHousingVoucher)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSListingResponse(object):
    """
    Attributes:
     - status
     - dmsListingId
     - expiresIn
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'expiresIn', None, None, ),  # 3
    )
    def __init__(self, status=None, dmsListingId=None, expiresIn=None, ):
        self.status = status
        self.dmsListingId = dmsListingId
        self.expiresIn = expiresIn

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 3)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSOfferRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsOffer
     - team
     - contactsToAdd
     - dmsAgents
     - shouldCreateDualRepDmsFolder
     - dualRepAgent
     - userType
     - userTypeOverrides
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'dmsOffer', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 7
        None,  # 8
        (9, TType.STRING, 'team', 'UTF8', None, ),  # 9
        (10, TType.LIST, 'contactsToAdd', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 10
        (11, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 11
        (12, TType.BOOL, 'shouldCreateDualRepDmsFolder', None, None, ),  # 12
        (13, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), None, ),  # 13
        (14, TType.I32, 'userType', None, None, ),  # 14
        (15, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 15
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, dmsOffer=None, team=None, contactsToAdd=None, dmsAgents=None, shouldCreateDualRepDmsFolder=None, dualRepAgent=None, userType=None, userTypeOverrides=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.dmsOffer = dmsOffer
        self.team = team
        self.contactsToAdd = contactsToAdd
        self.dmsAgents = dmsAgents
        self.shouldCreateDualRepDmsFolder = shouldCreateDualRepDmsFolder
        self.dualRepAgent = dualRepAgent
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.dmsOffer = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.dmsOffer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.contactsToAdd = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem9.read(iprot)
                        self.contactsToAdd.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem13.read(iprot)
                        self.dmsAgents.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.shouldCreateDualRepDmsFolder = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype16, _vtype17, _size20) = iprot.readMapBegin()
                    for _i15 in range(_size20):
                        _key18 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val19 = iprot.readI32()
                        self.userTypeOverrides[_key18] = _val19
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSOfferRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsOffer is not None:
            oprot.writeFieldBegin('dmsOffer', TType.STRUCT, 7)
            self.dmsOffer.write(oprot)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 9)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.contactsToAdd is not None:
            oprot.writeFieldBegin('contactsToAdd', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.contactsToAdd))
            for _iter21 in self.contactsToAdd:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter22 in self.dmsAgents:
                _iter22.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.shouldCreateDualRepDmsFolder is not None:
            oprot.writeFieldBegin('shouldCreateDualRepDmsFolder', TType.BOOL, 12)
            oprot.writeBool(self.shouldCreateDualRepDmsFolder)
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 13)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 14)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 15)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter23, _viter24 in self.userTypeOverrides.items():
                oprot.writeString(_kiter23.encode('utf-8') if sys.version_info[0] == 2 else _kiter23)
                oprot.writeI32(_viter24)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSOfferResponse(object):
    """
    Attributes:
     - status
     - dmsOffer
     - isDmsOfferComplete
     - isDmsOfferSubmitted
     - expiresIn
     - dmsContacts
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
     - dmsAgents
     - dualRepAgent
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsOffer', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 3
        (4, TType.I32, 'expiresIn', None, None, ),  # 4
        (5, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isDmsOfferSubmitted', None, None, ),  # 8
        (9, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 9
        (10, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), None, ),  # 10
    )
    def __init__(self, status=None, dmsOffer=None, isDmsOfferComplete=None, expiresIn=None, dmsContacts=None, otherSideDualRepFolderBtId=None, otherSideDualRepDmsFolderId=None, isDmsOfferSubmitted=None, dmsAgents=None, dualRepAgent=None, ):
        self.status = status
        self.dmsOffer = dmsOffer
        self.isDmsOfferComplete = isDmsOfferComplete
        self.expiresIn = expiresIn
        self.dmsContacts = dmsContacts
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.isDmsOfferSubmitted = isDmsOfferSubmitted
        self.dmsAgents = dmsAgents
        self.dualRepAgent = dualRepAgent

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsOffer = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.dmsOffer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype25, _size28) = iprot.readListBegin()
                    for _i26 in range(_size28):
                        _elem27 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem27.read(iprot)
                        self.dmsContacts.append(_elem27)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDmsOfferSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype29, _size32) = iprot.readListBegin()
                    for _i30 in range(_size32):
                        _elem31 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem31.read(iprot)
                        self.dmsAgents.append(_elem31)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSOfferResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsOffer is not None:
            oprot.writeFieldBegin('dmsOffer', TType.STRUCT, 2)
            self.dmsOffer.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 3)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 4)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter33 in self.dmsContacts:
                _iter33.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 6)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 7)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.isDmsOfferSubmitted is not None:
            oprot.writeFieldBegin('isDmsOfferSubmitted', TType.BOOL, 8)
            oprot.writeBool(self.isDmsOfferSubmitted)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter34 in self.dmsAgents:
                _iter34.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 10)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSTransactionRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsListingId
     - dmsFolderId
     - team
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'team', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsListingId=None, team=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsListingId = dmsListingId
        self.team = team
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 6)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 7)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 8)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddDMSTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsTransactionId=None, ):
        self.status = status
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddManualDMSFolderActivityLogEntryRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - entry
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'entry', (gen.urbancompass.dms_translation_model.ttypes.ManualActivityLogEntry, gen.urbancompass.dms_translation_model.ttypes.ManualActivityLogEntry.thrift_spec), None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, entry=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.entry = entry

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.entry = gen.urbancompass.dms_translation_model.ttypes.ManualActivityLogEntry()
                    self.entry.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddManualDMSFolderActivityLogEntryRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.entry is not None:
            oprot.writeFieldBegin('entry', TType.STRUCT, 7)
            self.entry.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddManualDMSFolderActivityLogEntryResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddManualDMSFolderActivityLogEntryResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddReferralDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - sideRepresented
     - ownerUserId
     - ownerTeamId
     - referralFee
     - dealType
     - primaryDmsTransactionId
     - additionalFields
     - accessLevel
     - primaryDealFromSplit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.I32, 'sideRepresented', None, None, ),  # 6
        (7, TType.STRING, 'ownerUserId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'ownerTeamId', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'referralFee', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 9
        (10, TType.I32, 'dealType', None, None, ),  # 10
        (11, TType.STRING, 'primaryDmsTransactionId', 'UTF8', None, ),  # 11
        (12, TType.STRUCT, 'additionalFields', (gen.urbancompass.dms_translation_model.ttypes.AdditionalReferralDealFields, gen.urbancompass.dms_translation_model.ttypes.AdditionalReferralDealFields.thrift_spec), None, ),  # 12
        (13, TType.I32, 'accessLevel', None, None, ),  # 13
        (14, TType.BOOL, 'primaryDealFromSplit', None, None, ),  # 14
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, sideRepresented=None, ownerUserId=None, ownerTeamId=None, referralFee=None, dealType=None, primaryDmsTransactionId=None, additionalFields=None, accessLevel=None, primaryDealFromSplit=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.sideRepresented = sideRepresented
        self.ownerUserId = ownerUserId
        self.ownerTeamId = ownerTeamId
        self.referralFee = referralFee
        self.dealType = dealType
        self.primaryDmsTransactionId = primaryDmsTransactionId
        self.additionalFields = additionalFields
        self.accessLevel = accessLevel
        self.primaryDealFromSplit = primaryDealFromSplit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.ownerUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.ownerTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.referralFee = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.referralFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.primaryDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.additionalFields = gen.urbancompass.dms_translation_model.ttypes.AdditionalReferralDealFields()
                    self.additionalFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.accessLevel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.primaryDealFromSplit = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddReferralDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 6)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.ownerUserId is not None:
            oprot.writeFieldBegin('ownerUserId', TType.STRING, 7)
            oprot.writeString(self.ownerUserId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerUserId)
            oprot.writeFieldEnd()
        if self.ownerTeamId is not None:
            oprot.writeFieldBegin('ownerTeamId', TType.STRING, 8)
            oprot.writeString(self.ownerTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerTeamId)
            oprot.writeFieldEnd()
        if self.referralFee is not None:
            oprot.writeFieldBegin('referralFee', TType.STRUCT, 9)
            self.referralFee.write(oprot)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 10)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.primaryDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDmsTransactionId', TType.STRING, 11)
            oprot.writeString(self.primaryDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsTransactionId)
            oprot.writeFieldEnd()
        if self.additionalFields is not None:
            oprot.writeFieldBegin('additionalFields', TType.STRUCT, 12)
            self.additionalFields.write(oprot)
            oprot.writeFieldEnd()
        if self.accessLevel is not None:
            oprot.writeFieldBegin('accessLevel', TType.I32, 13)
            oprot.writeI32(self.accessLevel)
            oprot.writeFieldEnd()
        if self.primaryDealFromSplit is not None:
            oprot.writeFieldBegin('primaryDealFromSplit', TType.BOOL, 14)
            oprot.writeBool(self.primaryDealFromSplit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddReferralDealResponse(object):
    """
    Attributes:
     - status
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsTransactionId=None, ):
        self.status = status
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddReferralDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddUsersToGroupsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - userEmails
     - groupIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'userEmails', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.LIST, 'groupIds', (TType.STRING, 'UTF8', False), None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, userEmails=None, groupIds=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.userEmails = userEmails
        self.groupIds = groupIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.userEmails = []
                    (_etype35, _size38) = iprot.readListBegin()
                    for _i36 in range(_size38):
                        _elem37 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userEmails.append(_elem37)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.groupIds = []
                    (_etype39, _size42) = iprot.readListBegin()
                    for _i40 in range(_size42):
                        _elem41 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.groupIds.append(_elem41)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddUsersToGroupsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.userEmails is not None:
            oprot.writeFieldBegin('userEmails', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.userEmails))
            for _iter43 in self.userEmails:
                oprot.writeString(_iter43.encode('utf-8') if sys.version_info[0] == 2 else _iter43)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.groupIds is not None:
            oprot.writeFieldBegin('groupIds', TType.LIST, 7)
            oprot.writeListBegin(TType.STRING, len(self.groupIds))
            for _iter44 in self.groupIds:
                oprot.writeString(_iter44.encode('utf-8') if sys.version_info[0] == 2 else _iter44)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        if self.userEmails is None:
            raise TProtocolException(message='Required field userEmails is unset!')
        if self.groupIds is None:
            raise TProtocolException(message='Required field groupIds is unset!')
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AddUsersToGroupsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AddUsersToGroupsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchAddAdminComplianceDocumentInternalRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - recordsToUpsert
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocument, gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocument.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, recordsToUpsert=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.recordsToUpsert = recordsToUpsert

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype45, _size48) = iprot.readListBegin()
                    for _i46 in range(_size48):
                        _elem47 = gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocument()
                        _elem47.read(iprot)
                        self.recordsToUpsert.append(_elem47)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchAddAdminComplianceDocumentInternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter49 in self.recordsToUpsert:
                _iter49.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchAddAdminComplianceDocumentInternalResponse(object):
    """
    Attributes:
     - status
     - idPairsCreated
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'idPairsCreated', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocumentIdPair, gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocumentIdPair.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, idPairsCreated=None, ):
        self.status = status
        self.idPairsCreated = idPairsCreated

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.idPairsCreated = []
                    (_etype50, _size53) = iprot.readListBegin()
                    for _i51 in range(_size53):
                        _elem52 = gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocumentIdPair()
                        _elem52.read(iprot)
                        self.idPairsCreated.append(_elem52)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchAddAdminComplianceDocumentInternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.idPairsCreated is not None:
            oprot.writeFieldBegin('idPairsCreated', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.idPairsCreated))
            for _iter54 in self.idPairsCreated:
                _iter54.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetAdminComplianceChecklistGroupsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - version
     - checklistIds
     - complianceState
     - market
     - includeDraftChecklists
     - includeDeletedChecklists
     - checklistCriteriaIds
     - propertyType
     - listingType
     - includeDeletedChecklistCriteria
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.I32, 'version', None, None, ),  # 6
        (7, TType.LIST, 'checklistIds', (TType.I32, None, False), None, ),  # 7
        (8, TType.STRING, 'complianceState', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'market', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'includeDraftChecklists', None, None, ),  # 10
        (11, TType.BOOL, 'includeDeletedChecklists', None, None, ),  # 11
        (12, TType.LIST, 'checklistCriteriaIds', (TType.I32, None, False), None, ),  # 12
        (13, TType.I32, 'propertyType', None, None, ),  # 13
        (14, TType.I32, 'listingType', None, None, ),  # 14
        (15, TType.BOOL, 'includeDeletedChecklistCriteria', None, None, ),  # 15
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, version=None, checklistIds=None, complianceState=None, market=None, includeDraftChecklists=None, includeDeletedChecklists=None, checklistCriteriaIds=None, propertyType=None, listingType=None, includeDeletedChecklistCriteria=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.version = version
        self.checklistIds = checklistIds
        self.complianceState = complianceState
        self.market = market
        self.includeDraftChecklists = includeDraftChecklists
        self.includeDeletedChecklists = includeDeletedChecklists
        self.checklistCriteriaIds = checklistCriteriaIds
        self.propertyType = propertyType
        self.listingType = listingType
        self.includeDeletedChecklistCriteria = includeDeletedChecklistCriteria

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.checklistIds = []
                    (_etype55, _size58) = iprot.readListBegin()
                    for _i56 in range(_size58):
                        _elem57 = iprot.readI32()
                        self.checklistIds.append(_elem57)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.includeDraftChecklists = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.includeDeletedChecklists = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.checklistCriteriaIds = []
                    (_etype59, _size62) = iprot.readListBegin()
                    for _i60 in range(_size62):
                        _elem61 = iprot.readI32()
                        self.checklistCriteriaIds.append(_elem61)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.includeDeletedChecklistCriteria = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetAdminComplianceChecklistGroupsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 6)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.checklistIds is not None:
            oprot.writeFieldBegin('checklistIds', TType.LIST, 7)
            oprot.writeListBegin(TType.I32, len(self.checklistIds))
            for _iter63 in self.checklistIds:
                oprot.writeI32(_iter63)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 8)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 9)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.includeDraftChecklists is not None:
            oprot.writeFieldBegin('includeDraftChecklists', TType.BOOL, 10)
            oprot.writeBool(self.includeDraftChecklists)
            oprot.writeFieldEnd()
        if self.includeDeletedChecklists is not None:
            oprot.writeFieldBegin('includeDeletedChecklists', TType.BOOL, 11)
            oprot.writeBool(self.includeDeletedChecklists)
            oprot.writeFieldEnd()
        if self.checklistCriteriaIds is not None:
            oprot.writeFieldBegin('checklistCriteriaIds', TType.LIST, 12)
            oprot.writeListBegin(TType.I32, len(self.checklistCriteriaIds))
            for _iter64 in self.checklistCriteriaIds:
                oprot.writeI32(_iter64)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 13)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 14)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.includeDeletedChecklistCriteria is not None:
            oprot.writeFieldBegin('includeDeletedChecklistCriteria', TType.BOOL, 15)
            oprot.writeBool(self.includeDeletedChecklistCriteria)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetAdminComplianceChecklistGroupsResponse(object):
    """
    Attributes:
     - status
     - checklistGroups
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklistGroups', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistGroup, gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistGroup.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, checklistGroups=None, ):
        self.status = status
        self.checklistGroups = checklistGroups

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistGroups = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistGroup()
                        _elem67.read(iprot)
                        self.checklistGroups.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetAdminComplianceChecklistGroupsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistGroups is not None:
            oprot.writeFieldBegin('checklistGroups', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklistGroups))
            for _iter69 in self.checklistGroups:
                _iter69.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetDMSFoldersOverviewExtRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderIds=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderIds = dmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype70, _size73) = iprot.readListBegin()
                    for _i71 in range(_size73):
                        _elem72 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem72)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetDMSFoldersOverviewExtRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter74 in self.dmsFolderIds:
                oprot.writeString(_iter74.encode('utf-8') if sys.version_info[0] == 2 else _iter74)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetDMSSpecificListingPageInfoRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderIds=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderIds = dmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype75, _size78) = iprot.readListBegin()
                    for _i76 in range(_size78):
                        _elem77 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem77)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetDMSSpecificListingPageInfoRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter79 in self.dmsFolderIds:
                oprot.writeString(_iter79.encode('utf-8') if sys.version_info[0] == 2 else _iter79)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceChecklistCriteriaRelationRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - recordsToUpsert
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, recordsToUpsert=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.recordsToUpsert = recordsToUpsert

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype80, _size83) = iprot.readListBegin()
                    for _i81 in range(_size83):
                        _elem82 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation()
                        _elem82.read(iprot)
                        self.recordsToUpsert.append(_elem82)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceChecklistCriteriaRelationRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter84 in self.recordsToUpsert:
                _iter84.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceChecklistCriteriaRelationResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype85, _size88) = iprot.readListBegin()
                    for _i86 in range(_size88):
                        _elem87 = iprot.readI32()
                        self.ids.append(_elem87)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceChecklistCriteriaRelationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter89 in self.ids:
                oprot.writeI32(_iter89)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceChecklistCriteriaRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - recordsToUpsert
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, recordsToUpsert=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.recordsToUpsert = recordsToUpsert

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype90, _size93) = iprot.readListBegin()
                    for _i91 in range(_size93):
                        _elem92 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria()
                        _elem92.read(iprot)
                        self.recordsToUpsert.append(_elem92)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceChecklistCriteriaRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter94 in self.recordsToUpsert:
                _iter94.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceChecklistCriteriaResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype95, _size98) = iprot.readListBegin()
                    for _i96 in range(_size98):
                        _elem97 = iprot.readI32()
                        self.ids.append(_elem97)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceChecklistCriteriaResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter99 in self.ids:
                oprot.writeI32(_iter99)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceChecklistRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - recordsToUpsert
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, recordsToUpsert=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.recordsToUpsert = recordsToUpsert

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype100, _size103) = iprot.readListBegin()
                    for _i101 in range(_size103):
                        _elem102 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist()
                        _elem102.read(iprot)
                        self.recordsToUpsert.append(_elem102)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceChecklistRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter104 in self.recordsToUpsert:
                _iter104.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceChecklistResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype105, _size108) = iprot.readListBegin()
                    for _i106 in range(_size108):
                        _elem107 = iprot.readI32()
                        self.ids.append(_elem107)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceChecklistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter109 in self.ids:
                oprot.writeI32(_iter109)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceDocumentInternalRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - recordsToUpsert
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'recordsToUpsert', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, recordsToUpsert=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.recordsToUpsert = recordsToUpsert

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.recordsToUpsert = []
                    (_etype110, _size113) = iprot.readListBegin()
                    for _i111 in range(_size113):
                        _elem112 = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal()
                        _elem112.read(iprot)
                        self.recordsToUpsert.append(_elem112)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceDocumentInternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.recordsToUpsert is not None:
            oprot.writeFieldBegin('recordsToUpsert', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.recordsToUpsert))
            for _iter114 in self.recordsToUpsert:
                _iter114.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchUpsertAdminComplianceDocumentInternalResponse(object):
    """
    Attributes:
     - status
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'ids', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, status=None, ids=None, ):
        self.status = status
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype115, _size118) = iprot.readListBegin()
                    for _i116 in range(_size118):
                        _elem117 = iprot.readI32()
                        self.ids.append(_elem117)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchUpsertAdminComplianceDocumentInternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.ids))
            for _iter119 in self.ids:
                oprot.writeI32(_iter119)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckDMSAccessRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - teamId
     - useADP
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'teamId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'useADP', None, None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, teamId=None, useADP=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.teamId = teamId
        self.useADP = useADP

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.useADP = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckDMSAccessRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 6)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.useADP is not None:
            oprot.writeFieldBegin('useADP', TType.BOOL, 7)
            oprot.writeBool(self.useADP)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CheckDMSAccessResponse(object):
    """
    Attributes:
     - status
     - hasDmsAccess
     - hasDmsAccessUnimpersonated
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'hasDmsAccess', None, None, ),  # 2
        (3, TType.BOOL, 'hasDmsAccessUnimpersonated', None, None, ),  # 3
    )
    def __init__(self, status=None, hasDmsAccess=None, hasDmsAccessUnimpersonated=None, ):
        self.status = status
        self.hasDmsAccess = hasDmsAccess
        self.hasDmsAccessUnimpersonated = hasDmsAccessUnimpersonated

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.hasDmsAccess = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasDmsAccessUnimpersonated = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CheckDMSAccessResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.hasDmsAccess is not None:
            oprot.writeFieldBegin('hasDmsAccess', TType.BOOL, 2)
            oprot.writeBool(self.hasDmsAccess)
            oprot.writeFieldEnd()
        if self.hasDmsAccessUnimpersonated is not None:
            oprot.writeFieldBegin('hasDmsAccessUnimpersonated', TType.BOOL, 3)
            oprot.writeBool(self.hasDmsAccessUnimpersonated)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClaimDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClaimDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClaimDealResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClaimDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommissionsAndAllocationsCalculationRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - dmsFolderId
     - closingRequest
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'closingRequest', (gen.urbancompass.closings.closings_service.ttypes.ClosingRequest, gen.urbancompass.closings.closings_service.ttypes.ClosingRequest.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'serviceName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'token', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, dmsFolderId=None, closingRequest=None, serviceName=None, token=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.dmsFolderId = dmsFolderId
        self.closingRequest = closingRequest
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.closingRequest = gen.urbancompass.closings.closings_service.ttypes.ClosingRequest()
                    self.closingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommissionsAndAllocationsCalculationRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 3)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.closingRequest is not None:
            oprot.writeFieldBegin('closingRequest', TType.STRUCT, 4)
            self.closingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 5)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 6)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 7)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ConvertDocumentToPdfRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - data
     - mimeType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'data', 'BINARY', None, ),  # 6
        (7, TType.STRING, 'mimeType', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, data=None, mimeType=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.data = data
        self.mimeType = mimeType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.data = iprot.readBinary()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.mimeType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ConvertDocumentToPdfRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 6)
            oprot.writeBinary(self.data)
            oprot.writeFieldEnd()
        if self.mimeType is not None:
            oprot.writeFieldBegin('mimeType', TType.STRING, 7)
            oprot.writeString(self.mimeType.encode('utf-8') if sys.version_info[0] == 2 else self.mimeType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ConvertDocumentToPdfResponse(object):
    """
    Attributes:
     - status
     - documentBytes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'documentBytes', 'BINARY', None, ),  # 2
    )
    def __init__(self, status=None, documentBytes=None, ):
        self.status = status
        self.documentBytes = documentBytes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentBytes = iprot.readBinary()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ConvertDocumentToPdfResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.documentBytes is not None:
            oprot.writeFieldBegin('documentBytes', TType.STRING, 2)
            oprot.writeBinary(self.documentBytes)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateClosingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - impersonatorId
     - closingRequest
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'closingRequest', (gen.urbancompass.closings.closings_service.ttypes.ClosingRequest, gen.urbancompass.closings.closings_service.ttypes.ClosingRequest.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'serviceName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'token', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 7
    )
    def __init__(self, dmsFolderId=None, userId=None, impersonatorId=None, closingRequest=None, serviceName=None, token=None, signature=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.closingRequest = closingRequest
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.closingRequest = gen.urbancompass.closings.closings_service.ttypes.ClosingRequest()
                    self.closingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateClosingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.closingRequest is not None:
            oprot.writeFieldBegin('closingRequest', TType.STRUCT, 4)
            self.closingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 5)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 6)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 7)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - team
     - dealListingId
     - name
     - sideRepresented
     - listingId
     - ownerUserId
     - isForReferralDeal
     - dealType
     - referredBy
     - referredTo
     - referralDetail
     - originatedFrom
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'team', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'name', 'UTF8', None, ),  # 8
        (9, TType.I32, 'sideRepresented', None, None, ),  # 9
        (10, TType.STRING, 'listingId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'ownerUserId', 'UTF8', None, ),  # 11
        (12, TType.BOOL, 'isForReferralDeal', None, None, ),  # 12
        (13, TType.I32, 'dealType', None, None, ),  # 13
        (14, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 14
        (15, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 15
        (16, TType.STRUCT, 'referralDetail', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail.thrift_spec), None, ),  # 16
        (17, TType.I32, 'originatedFrom', None, None, ),  # 17
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, team=None, dealListingId=None, name=None, sideRepresented=None, listingId=None, ownerUserId=None, isForReferralDeal=None, dealType=None, referredBy=None, referredTo=None, referralDetail=None, originatedFrom=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.team = team
        self.dealListingId = dealListingId
        self.name = name
        self.sideRepresented = sideRepresented
        self.listingId = listingId
        self.ownerUserId = ownerUserId
        self.isForReferralDeal = isForReferralDeal
        self.dealType = dealType
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.referralDetail = referralDetail
        self.originatedFrom = originatedFrom

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.ownerUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isForReferralDeal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.referralDetail = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail()
                    self.referralDetail.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.originatedFrom = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 6)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 7)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 8)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 9)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 10)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.ownerUserId is not None:
            oprot.writeFieldBegin('ownerUserId', TType.STRING, 11)
            oprot.writeString(self.ownerUserId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerUserId)
            oprot.writeFieldEnd()
        if self.isForReferralDeal is not None:
            oprot.writeFieldBegin('isForReferralDeal', TType.BOOL, 12)
            oprot.writeBool(self.isForReferralDeal)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 13)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 14)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 15)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.referralDetail is not None:
            oprot.writeFieldBegin('referralDetail', TType.STRUCT, 16)
            self.referralDetail.write(oprot)
            oprot.writeFieldEnd()
        if self.originatedFrom is not None:
            oprot.writeFieldBegin('originatedFrom', TType.I32, 17)
            oprot.writeI32(self.originatedFrom)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDMSFolderResponse(object):
    """
    Attributes:
     - status
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderId=None, ):
        self.status = status
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSFolderResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSListingRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsListingId
     - dmsFolderId
     - reasonForWithdrawal
     - doNotCallLDFS
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'reasonForWithdrawal', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'doNotCallLDFS', None, None, ),  # 9
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsListingId=None, dmsFolderId=None, reasonForWithdrawal=None, doNotCallLDFS=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId
        self.reasonForWithdrawal = reasonForWithdrawal
        self.doNotCallLDFS = doNotCallLDFS

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.reasonForWithdrawal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.doNotCallLDFS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 6)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.reasonForWithdrawal is not None:
            oprot.writeFieldBegin('reasonForWithdrawal', TType.STRING, 8)
            oprot.writeString(self.reasonForWithdrawal.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForWithdrawal)
            oprot.writeFieldEnd()
        if self.doNotCallLDFS is not None:
            oprot.writeFieldBegin('doNotCallLDFS', TType.BOOL, 9)
            oprot.writeBool(self.doNotCallLDFS)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSListingResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSOfferRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - reasonForCancellation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'reasonForCancellation', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, reasonForCancellation=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.reasonForCancellation = reasonForCancellation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.reasonForCancellation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSOfferRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.reasonForCancellation is not None:
            oprot.writeFieldBegin('reasonForCancellation', TType.STRING, 7)
            oprot.writeString(self.reasonForCancellation.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForCancellation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSOfferResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSOfferResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSTransactionRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsTransactionId
     - dmsFolderId
     - reasonForCancellation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'reasonForCancellation', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsTransactionId=None, dmsFolderId=None, reasonForCancellation=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsTransactionId = dmsTransactionId
        self.dmsFolderId = dmsFolderId
        self.reasonForCancellation = reasonForCancellation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.reasonForCancellation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.reasonForCancellation is not None:
            oprot.writeFieldBegin('reasonForCancellation', TType.STRING, 8)
            oprot.writeString(self.reasonForCancellation.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForCancellation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDMSTransactionResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsSyncExternalRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsListingExtSyncPayload
     - dmsTransactionExtSyncPayload
     - deleteOffer
     - reasonForCancellation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'dmsListingExtSyncPayload', (gen.urbancompass.dms_translation_model.ttypes.DmsListingExtSyncPayload, gen.urbancompass.dms_translation_model.ttypes.DmsListingExtSyncPayload.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'dmsTransactionExtSyncPayload', (gen.urbancompass.dms_translation_model.ttypes.DmsTransactionExtSyncPayload, gen.urbancompass.dms_translation_model.ttypes.DmsTransactionExtSyncPayload.thrift_spec), None, ),  # 8
        (9, TType.BOOL, 'deleteOffer', None, None, ),  # 9
        (10, TType.STRING, 'reasonForCancellation', 'UTF8', None, ),  # 10
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, dmsListingExtSyncPayload=None, dmsTransactionExtSyncPayload=None, deleteOffer=None, reasonForCancellation=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.dmsListingExtSyncPayload = dmsListingExtSyncPayload
        self.dmsTransactionExtSyncPayload = dmsTransactionExtSyncPayload
        self.deleteOffer = deleteOffer
        self.reasonForCancellation = reasonForCancellation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.dmsListingExtSyncPayload = gen.urbancompass.dms_translation_model.ttypes.DmsListingExtSyncPayload()
                    self.dmsListingExtSyncPayload.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.dmsTransactionExtSyncPayload = gen.urbancompass.dms_translation_model.ttypes.DmsTransactionExtSyncPayload()
                    self.dmsTransactionExtSyncPayload.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.deleteOffer = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.reasonForCancellation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsSyncExternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingExtSyncPayload is not None:
            oprot.writeFieldBegin('dmsListingExtSyncPayload', TType.STRUCT, 7)
            self.dmsListingExtSyncPayload.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionExtSyncPayload is not None:
            oprot.writeFieldBegin('dmsTransactionExtSyncPayload', TType.STRUCT, 8)
            self.dmsTransactionExtSyncPayload.write(oprot)
            oprot.writeFieldEnd()
        if self.deleteOffer is not None:
            oprot.writeFieldBegin('deleteOffer', TType.BOOL, 9)
            oprot.writeBool(self.deleteOffer)
            oprot.writeFieldEnd()
        if self.reasonForCancellation is not None:
            oprot.writeFieldBegin('reasonForCancellation', TType.STRING, 10)
            oprot.writeString(self.reasonForCancellation.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForCancellation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsSyncExternalResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsSyncExternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EditDocumentChecklistItemsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - documentId
     - dmsFolderId
     - checklistItemIds
     - stage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'documentId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'checklistItemIds', (TType.I32, None, False), None, ),  # 8
        (9, TType.I32, 'stage', None, None, ),  # 9
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, documentId=None, dmsFolderId=None, checklistItemIds=None, stage=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.documentId = documentId
        self.dmsFolderId = dmsFolderId
        self.checklistItemIds = checklistItemIds
        self.stage = stage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.checklistItemIds = []
                    (_etype120, _size123) = iprot.readListBegin()
                    for _i121 in range(_size123):
                        _elem122 = iprot.readI32()
                        self.checklistItemIds.append(_elem122)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EditDocumentChecklistItemsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 6)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistItemIds is not None:
            oprot.writeFieldBegin('checklistItemIds', TType.LIST, 8)
            oprot.writeListBegin(TType.I32, len(self.checklistItemIds))
            for _iter124 in self.checklistItemIds:
                oprot.writeI32(_iter124)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 9)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EditDocumentChecklistItemsResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EditDocumentChecklistItemsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersByAddressRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dealListingFolderIdToDmsFolderId
     - addressQuery
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.MAP, 'dealListingFolderIdToDmsFolderId', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.STRING, 'addressQuery', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dealListingFolderIdToDmsFolderId=None, addressQuery=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dealListingFolderIdToDmsFolderId = dealListingFolderIdToDmsFolderId
        self.addressQuery = addressQuery

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.MAP:
                    self.dealListingFolderIdToDmsFolderId = {}
                    (_ktype126, _vtype127, _size130) = iprot.readMapBegin()
                    for _i125 in range(_size130):
                        _key128 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val129 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dealListingFolderIdToDmsFolderId[_key128] = _val129
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.addressQuery = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersByAddressRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dealListingFolderIdToDmsFolderId is not None:
            oprot.writeFieldBegin('dealListingFolderIdToDmsFolderId', TType.MAP, 6)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.dealListingFolderIdToDmsFolderId))
            for _kiter131, _viter132 in self.dealListingFolderIdToDmsFolderId.items():
                oprot.writeString(_kiter131.encode('utf-8') if sys.version_info[0] == 2 else _kiter131)
                oprot.writeString(_viter132.encode('utf-8') if sys.version_info[0] == 2 else _viter132)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.addressQuery is not None:
            oprot.writeFieldBegin('addressQuery', TType.STRING, 7)
            oprot.writeString(self.addressQuery.encode('utf-8') if sys.version_info[0] == 2 else self.addressQuery)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersByAddressResponse(object):
    """
    Attributes:
     - status
     - dealListingFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dealListingFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dealListingFolderIds=None, ):
        self.status = status
        self.dealListingFolderIds = dealListingFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dealListingFolderIds = []
                    (_etype133, _size136) = iprot.readListBegin()
                    for _i134 in range(_size136):
                        _elem135 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dealListingFolderIds.append(_elem135)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersByAddressResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dealListingFolderIds is not None:
            oprot.writeFieldBegin('dealListingFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dealListingFolderIds))
            for _iter137 in self.dealListingFolderIds:
                oprot.writeString(_iter137.encode('utf-8') if sys.version_info[0] == 2 else _iter137)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dealListingFolderIdToDmsFolderId
     - filterQuery
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.MAP, 'dealListingFolderIdToDmsFolderId', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.STRUCT, 'filterQuery', (gen.urbancompass.dms_common.dms_deal.ttypes.DealQuery, gen.urbancompass.dms_common.dms_deal.ttypes.DealQuery.thrift_spec), None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dealListingFolderIdToDmsFolderId=None, filterQuery=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dealListingFolderIdToDmsFolderId = dealListingFolderIdToDmsFolderId
        self.filterQuery = filterQuery

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.MAP:
                    self.dealListingFolderIdToDmsFolderId = {}
                    (_ktype139, _vtype140, _size143) = iprot.readMapBegin()
                    for _i138 in range(_size143):
                        _key141 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val142 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dealListingFolderIdToDmsFolderId[_key141] = _val142
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.filterQuery = gen.urbancompass.dms_common.dms_deal.ttypes.DealQuery()
                    self.filterQuery.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dealListingFolderIdToDmsFolderId is not None:
            oprot.writeFieldBegin('dealListingFolderIdToDmsFolderId', TType.MAP, 6)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.dealListingFolderIdToDmsFolderId))
            for _kiter144, _viter145 in self.dealListingFolderIdToDmsFolderId.items():
                oprot.writeString(_kiter144.encode('utf-8') if sys.version_info[0] == 2 else _kiter144)
                oprot.writeString(_viter145.encode('utf-8') if sys.version_info[0] == 2 else _viter145)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.filterQuery is not None:
            oprot.writeFieldBegin('filterQuery', TType.STRUCT, 7)
            self.filterQuery.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilterDMSFoldersResponse(object):
    """
    Attributes:
     - status
     - dealListingFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dealListingFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dealListingFolderIds=None, ):
        self.status = status
        self.dealListingFolderIds = dealListingFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dealListingFolderIds = []
                    (_etype146, _size149) = iprot.readListBegin()
                    for _i147 in range(_size149):
                        _elem148 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dealListingFolderIds.append(_elem148)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilterDMSFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dealListingFolderIds is not None:
            oprot.writeFieldBegin('dealListingFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dealListingFolderIds))
            for _iter150 in self.dealListingFolderIds:
                oprot.writeString(_iter150.encode('utf-8') if sys.version_info[0] == 2 else _iter150)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetActivityLogsForFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetActivityLogsForFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAdminComplianceChecklistDocumentsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - checklistCriteriaId
     - includeDeletedRelations
     - includeDeletedDocuments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.I32, 'checklistCriteriaId', None, None, ),  # 6
        (7, TType.BOOL, 'includeDeletedRelations', None, None, ),  # 7
        (8, TType.BOOL, 'includeDeletedDocuments', None, None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, checklistCriteriaId=None, includeDeletedRelations=None, includeDeletedDocuments=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.checklistCriteriaId = checklistCriteriaId
        self.includeDeletedRelations = includeDeletedRelations
        self.includeDeletedDocuments = includeDeletedDocuments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.checklistCriteriaId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeDeletedRelations = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.includeDeletedDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAdminComplianceChecklistDocumentsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistCriteriaId is not None:
            oprot.writeFieldBegin('checklistCriteriaId', TType.I32, 6)
            oprot.writeI32(self.checklistCriteriaId)
            oprot.writeFieldEnd()
        if self.includeDeletedRelations is not None:
            oprot.writeFieldBegin('includeDeletedRelations', TType.BOOL, 7)
            oprot.writeBool(self.includeDeletedRelations)
            oprot.writeFieldEnd()
        if self.includeDeletedDocuments is not None:
            oprot.writeFieldBegin('includeDeletedDocuments', TType.BOOL, 8)
            oprot.writeBool(self.includeDeletedDocuments)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAdminComplianceChecklistDocumentsResponse(object):
    """
    Attributes:
     - status
     - checklistDocuments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklistDocuments', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocument, gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocument.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, checklistDocuments=None, ):
        self.status = status
        self.checklistDocuments = checklistDocuments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistDocuments = []
                    (_etype151, _size154) = iprot.readListBegin()
                    for _i152 in range(_size154):
                        _elem153 = gen.urbancompass.dms_translation_model.ttypes.AdminComplianceChecklistDocument()
                        _elem153.read(iprot)
                        self.checklistDocuments.append(_elem153)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAdminComplianceChecklistDocumentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistDocuments is not None:
            oprot.writeFieldBegin('checklistDocuments', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklistDocuments))
            for _iter155 in self.checklistDocuments:
                _iter155.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentSplitRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - closeDate
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'closeDate', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, closeDate=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.closeDate = closeDate
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentSplitRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 6)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentsInfoByTeamIdRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - teamId
     - dmsListingId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'teamId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, teamId=None, dmsListingId=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.teamId = teamId
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentsInfoByTeamIdRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 6)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 7)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 8)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAgentsInfoByTeamIdResponse(object):
    """
    Attributes:
     - status
     - agentsInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'agentsInfo', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.AgentInfo, gen.urbancompass.dms_translation_model.ttypes.AgentInfo.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, agentsInfo=None, ):
        self.status = status
        self.agentsInfo = agentsInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.agentsInfo = []
                    (_etype156, _size159) = iprot.readListBegin()
                    for _i157 in range(_size159):
                        _elem158 = gen.urbancompass.dms_translation_model.ttypes.AgentInfo()
                        _elem158.read(iprot)
                        self.agentsInfo.append(_elem158)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAgentsInfoByTeamIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.agentsInfo is not None:
            oprot.writeFieldBegin('agentsInfo', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.agentsInfo))
            for _iter160 in self.agentsInfo:
                _iter160.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllDocumentUploadsByDmsFolderIdRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllDocumentUploadsByDmsFolderIdRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllDocumentUploadsByDmsFolderIdResponse(object):
    """
    Attributes:
     - status
     - entries
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'entries', (TType.STRUCT, (gen.urbancompass.dms_document.ttypes.AllUploadsEntry, gen.urbancompass.dms_document.ttypes.AllUploadsEntry.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, entries=None, ):
        self.status = status
        self.entries = entries

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.entries = []
                    (_etype161, _size164) = iprot.readListBegin()
                    for _i162 in range(_size164):
                        _elem163 = gen.urbancompass.dms_document.ttypes.AllUploadsEntry()
                        _elem163.read(iprot)
                        self.entries.append(_elem163)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllDocumentUploadsByDmsFolderIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.entries is not None:
            oprot.writeFieldBegin('entries', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.entries))
            for _iter165 in self.entries:
                _iter165.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllSubStageRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllSubStageRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAllSubStageResponse(object):
    """
    Attributes:
     - status
     - subStageForDisplay
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'subStageForDisplay', (TType.I32, None, TType.BOOL, None, False), None, ),  # 2
    )
    def __init__(self, status=None, subStageForDisplay=None, ):
        self.status = status
        self.subStageForDisplay = subStageForDisplay

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.subStageForDisplay = {}
                    (_ktype167, _vtype168, _size171) = iprot.readMapBegin()
                    for _i166 in range(_size171):
                        _key169 = iprot.readI32()
                        _val170 = iprot.readBool()
                        self.subStageForDisplay[_key169] = _val170
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAllSubStageResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.subStageForDisplay is not None:
            oprot.writeFieldBegin('subStageForDisplay', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.BOOL, len(self.subStageForDisplay))
            for _kiter172, _viter173 in self.subStageForDisplay.items():
                oprot.writeI32(_kiter172)
                oprot.writeBool(_viter173)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCancelledDMSOffersRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCancelledDMSOffersRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCancelledDMSOffersResponse(object):
    """
    Attributes:
     - status
     - cancelledOffers
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'cancelledOffers', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.CancelledDMSOffer, gen.urbancompass.dms_translation_model.ttypes.CancelledDMSOffer.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, cancelledOffers=None, ):
        self.status = status
        self.cancelledOffers = cancelledOffers

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.cancelledOffers = []
                    (_etype174, _size177) = iprot.readListBegin()
                    for _i175 in range(_size177):
                        _elem176 = gen.urbancompass.dms_translation_model.ttypes.CancelledDMSOffer()
                        _elem176.read(iprot)
                        self.cancelledOffers.append(_elem176)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCancelledDMSOffersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.cancelledOffers is not None:
            oprot.writeFieldBegin('cancelledOffers', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.cancelledOffers))
            for _iter178 in self.cancelledOffers:
                _iter178.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistAdminSettingsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - states
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'states', (TType.STRING, 'UTF8', False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, states=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.states = states

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.states = []
                    (_etype179, _size182) = iprot.readListBegin()
                    for _i180 in range(_size182):
                        _elem181 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.states.append(_elem181)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistAdminSettingsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.states is not None:
            oprot.writeFieldBegin('states', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.states))
            for _iter183 in self.states:
                oprot.writeString(_iter183.encode('utf-8') if sys.version_info[0] == 2 else _iter183)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistAdminSettingsResponse(object):
    """
    Attributes:
     - status
     - regionSettingsMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'regionSettingsMap', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSettings, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSettings.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, regionSettingsMap=None, ):
        self.status = status
        self.regionSettingsMap = regionSettingsMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.regionSettingsMap = {}
                    (_ktype185, _vtype186, _size189) = iprot.readMapBegin()
                    for _i184 in range(_size189):
                        _key187 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val188 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSettings()
                        _val188.read(iprot)
                        self.regionSettingsMap[_key187] = _val188
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistAdminSettingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.regionSettingsMap is not None:
            oprot.writeFieldBegin('regionSettingsMap', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.regionSettingsMap))
            for _kiter190, _viter191 in self.regionSettingsMap.items():
                oprot.writeString(_kiter190.encode('utf-8') if sys.version_info[0] == 2 else _kiter190)
                _viter191.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistDebugRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - checklistType
     - sideRepresented
     - propertyType
     - listingType
     - propertyBuiltYear
     - state
     - market
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.I32, 'checklistType', None, None, ),  # 6
        (7, TType.I32, 'sideRepresented', None, None, ),  # 7
        (8, TType.I32, 'propertyType', None, None, ),  # 8
        (9, TType.I32, 'listingType', None, None, ),  # 9
        (10, TType.I32, 'propertyBuiltYear', None, None, ),  # 10
        (11, TType.STRING, 'state', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'market', 'UTF8', None, ),  # 12
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, checklistType=None, sideRepresented=None, propertyType=None, listingType=None, propertyBuiltYear=None, state=None, market=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.checklistType = checklistType
        self.sideRepresented = sideRepresented
        self.propertyType = propertyType
        self.listingType = listingType
        self.propertyBuiltYear = propertyBuiltYear
        self.state = state
        self.market = market

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.propertyBuiltYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 6)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 7)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 8)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 9)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyBuiltYear is not None:
            oprot.writeFieldBegin('propertyBuiltYear', TType.I32, 10)
            oprot.writeI32(self.propertyBuiltYear)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 11)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 12)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistDebugResponse(object):
    """
    Attributes:
     - status
     - checklists
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'checklists', (gen.urbancompass.dms_translation_model.ttypes.DmsChecklists, gen.urbancompass.dms_translation_model.ttypes.DmsChecklists.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, checklists=None, ):
        self.status = status
        self.checklists = checklists

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.checklists = gen.urbancompass.dms_translation_model.ttypes.DmsChecklists()
                    self.checklists.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklists is not None:
            oprot.writeFieldBegin('checklists', TType.STRUCT, 2)
            self.checklists.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistItemRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - checklistItemId
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - stage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.I32, 'checklistItemId', None, None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'stage', None, None, ),  # 9
        (10, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 10
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, checklistItemId=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, stage=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.checklistItemId = checklistItemId
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.stage = stage
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistItemRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 5)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 7)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 8)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 9)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 10)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistItemResponse(object):
    """
    Attributes:
     - status
     - checklistItem
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'checklistItem', (gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem, gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'notes', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItemNote, gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItemNote.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, checklistItem=None, notes=None, ):
        self.status = status
        self.checklistItem = checklistItem
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.checklistItem = gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem()
                    self.checklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.notes = []
                    (_etype192, _size195) = iprot.readListBegin()
                    for _i193 in range(_size195):
                        _elem194 = gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItemNote()
                        _elem194.read(iprot)
                        self.notes.append(_elem194)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistItemResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItem is not None:
            oprot.writeFieldBegin('checklistItem', TType.STRUCT, 2)
            self.checklistItem.write(oprot)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.notes))
            for _iter196 in self.notes:
                _iter196.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsTransactionId
     - checklistType
     - stage
     - includeListingInfo
     - isStaff
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'checklistType', None, None, ),  # 7
        (8, TType.I32, 'stage', None, None, ),  # 8
        (9, TType.BOOL, 'includeListingInfo', None, None, ),  # 9
        (10, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 10
        (11, TType.BOOL, 'isStaff', None, None, ),  # 11
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, checklistType=None, stage=None, includeListingInfo=None, dmsTransactionId=None, isStaff=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.checklistType = checklistType
        self.stage = stage
        self.includeListingInfo = includeListingInfo
        self.dmsTransactionId = dmsTransactionId
        self.isStaff = isStaff

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.includeListingInfo = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.isStaff = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 7)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 8)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.includeListingInfo is not None:
            oprot.writeFieldBegin('includeListingInfo', TType.BOOL, 9)
            oprot.writeBool(self.includeListingInfo)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 10)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.isStaff is not None:
            oprot.writeFieldBegin('isStaff', TType.BOOL, 11)
            oprot.writeBool(self.isStaff)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetChecklistResponse(object):
    """
    Attributes:
     - status
     - checklists
     - propertyType
     - state
     - market
     - city
     - sideRepresented
     - isDmsListingComplete
     - isDmsListingSubmitted
     - isDmsOfferComplete
     - isSubmittedToCommission
     - isDmsOfferSubmitted
     - team
     - isAllComplianceSatisfied
     - zipcode
     - propertyAddress
     - unit
     - listingType
     - ctcServiceType
     - dualRepSide
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
     - otherSideDualRepDmsTransactionId
     - complianceSupportEmail
     - numberOfUnresolvedComments
     - issueTypeToCountMapping
     - documentTypeToUnresolvedCommentsCountMapping
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'propertyType', None, None, ),  # 2
        (3, TType.STRUCT, 'checklists', (gen.urbancompass.dms_translation_model.ttypes.DmsChecklists, gen.urbancompass.dms_translation_model.ttypes.DmsChecklists.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'state', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'city', 'UTF8', None, ),  # 5
        (6, TType.I32, 'sideRepresented', None, None, ),  # 6
        (7, TType.BOOL, 'isDmsListingComplete', None, None, ),  # 7
        (8, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 8
        (9, TType.STRING, 'team', 'UTF8', None, ),  # 9
        (10, TType.BOOL, 'isAllComplianceSatisfied', None, None, ),  # 10
        (11, TType.STRING, 'zipcode', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'unit', 'UTF8', None, ),  # 13
        (14, TType.I32, 'listingType', None, None, ),  # 14
        (15, TType.I32, 'ctcServiceType', None, None, ),  # 15
        (16, TType.I32, 'dualRepSide', None, None, ),  # 16
        (17, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'market', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'otherSideDualRepDmsTransactionId', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'complianceSupportEmail', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'isDmsListingSubmitted', None, None, ),  # 22
        (23, TType.BOOL, 'isDmsOfferSubmitted', None, None, ),  # 23
        (24, TType.BOOL, 'isSubmittedToCommission', None, None, ),  # 24
        (25, TType.I32, 'numberOfUnresolvedComments', None, None, ),  # 25
        (26, TType.MAP, 'issueTypeToCountMapping', (TType.I32, None, TType.I32, None, False), None, ),  # 26
        (27, TType.MAP, 'documentTypeToUnresolvedCommentsCountMapping', (TType.I32, None, TType.I32, None, False), None, ),  # 27
    )
    def __init__(self, status=None, propertyType=None, checklists=None, state=None, city=None, sideRepresented=None, isDmsListingComplete=None, isDmsOfferComplete=None, team=None, isAllComplianceSatisfied=None, zipcode=None, propertyAddress=None, unit=None, listingType=None, ctcServiceType=None, dualRepSide=None, otherSideDualRepFolderBtId=None, market=None, otherSideDualRepDmsFolderId=None, otherSideDualRepDmsTransactionId=None, complianceSupportEmail=None, isDmsListingSubmitted=None, isDmsOfferSubmitted=None, isSubmittedToCommission=None, numberOfUnresolvedComments=None, issueTypeToCountMapping=None, documentTypeToUnresolvedCommentsCountMapping=None, ):
        self.status = status
        self.propertyType = propertyType
        self.checklists = checklists
        self.state = state
        self.city = city
        self.sideRepresented = sideRepresented
        self.isDmsListingComplete = isDmsListingComplete
        self.isDmsOfferComplete = isDmsOfferComplete
        self.team = team
        self.isAllComplianceSatisfied = isAllComplianceSatisfied
        self.zipcode = zipcode
        self.propertyAddress = propertyAddress
        self.unit = unit
        self.listingType = listingType
        self.ctcServiceType = ctcServiceType
        self.dualRepSide = dualRepSide
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.market = market
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.otherSideDualRepDmsTransactionId = otherSideDualRepDmsTransactionId
        self.complianceSupportEmail = complianceSupportEmail
        self.isDmsListingSubmitted = isDmsListingSubmitted
        self.isDmsOfferSubmitted = isDmsOfferSubmitted
        self.isSubmittedToCommission = isSubmittedToCommission
        self.numberOfUnresolvedComments = numberOfUnresolvedComments
        self.issueTypeToCountMapping = issueTypeToCountMapping
        self.documentTypeToUnresolvedCommentsCountMapping = documentTypeToUnresolvedCommentsCountMapping

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.checklists = gen.urbancompass.dms_translation_model.ttypes.DmsChecklists()
                    self.checklists.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isDmsListingComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isAllComplianceSatisfied = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.complianceSupportEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.isDmsListingSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.isDmsOfferSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.isSubmittedToCommission = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.numberOfUnresolvedComments = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.MAP:
                    self.issueTypeToCountMapping = {}
                    (_ktype198, _vtype199, _size202) = iprot.readMapBegin()
                    for _i197 in range(_size202):
                        _key200 = iprot.readI32()
                        _val201 = iprot.readI32()
                        self.issueTypeToCountMapping[_key200] = _val201
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.MAP:
                    self.documentTypeToUnresolvedCommentsCountMapping = {}
                    (_ktype204, _vtype205, _size208) = iprot.readMapBegin()
                    for _i203 in range(_size208):
                        _key206 = iprot.readI32()
                        _val207 = iprot.readI32()
                        self.documentTypeToUnresolvedCommentsCountMapping[_key206] = _val207
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetChecklistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 2)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.checklists is not None:
            oprot.writeFieldBegin('checklists', TType.STRUCT, 3)
            self.checklists.write(oprot)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 4)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 5)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 6)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.isDmsListingComplete is not None:
            oprot.writeFieldBegin('isDmsListingComplete', TType.BOOL, 7)
            oprot.writeBool(self.isDmsListingComplete)
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 8)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 9)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.isAllComplianceSatisfied is not None:
            oprot.writeFieldBegin('isAllComplianceSatisfied', TType.BOOL, 10)
            oprot.writeBool(self.isAllComplianceSatisfied)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 11)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 12)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 13)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 14)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 15)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 16)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 17)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 18)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 19)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsTransactionId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsTransactionId', TType.STRING, 20)
            oprot.writeString(self.otherSideDualRepDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsTransactionId)
            oprot.writeFieldEnd()
        if self.complianceSupportEmail is not None:
            oprot.writeFieldBegin('complianceSupportEmail', TType.STRING, 21)
            oprot.writeString(self.complianceSupportEmail.encode('utf-8') if sys.version_info[0] == 2 else self.complianceSupportEmail)
            oprot.writeFieldEnd()
        if self.isDmsListingSubmitted is not None:
            oprot.writeFieldBegin('isDmsListingSubmitted', TType.BOOL, 22)
            oprot.writeBool(self.isDmsListingSubmitted)
            oprot.writeFieldEnd()
        if self.isDmsOfferSubmitted is not None:
            oprot.writeFieldBegin('isDmsOfferSubmitted', TType.BOOL, 23)
            oprot.writeBool(self.isDmsOfferSubmitted)
            oprot.writeFieldEnd()
        if self.isSubmittedToCommission is not None:
            oprot.writeFieldBegin('isSubmittedToCommission', TType.BOOL, 24)
            oprot.writeBool(self.isSubmittedToCommission)
            oprot.writeFieldEnd()
        if self.numberOfUnresolvedComments is not None:
            oprot.writeFieldBegin('numberOfUnresolvedComments', TType.I32, 25)
            oprot.writeI32(self.numberOfUnresolvedComments)
            oprot.writeFieldEnd()
        if self.issueTypeToCountMapping is not None:
            oprot.writeFieldBegin('issueTypeToCountMapping', TType.MAP, 26)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.issueTypeToCountMapping))
            for _kiter209, _viter210 in self.issueTypeToCountMapping.items():
                oprot.writeI32(_kiter209)
                oprot.writeI32(_viter210)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.documentTypeToUnresolvedCommentsCountMapping is not None:
            oprot.writeFieldBegin('documentTypeToUnresolvedCommentsCountMapping', TType.MAP, 27)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.documentTypeToUnresolvedCommentsCountMapping))
            for _kiter211, _viter212 in self.documentTypeToUnresolvedCommentsCountMapping.items():
                oprot.writeI32(_kiter211)
                oprot.writeI32(_viter212)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetClosingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'serviceName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'token', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 6
    )
    def __init__(self, dmsFolderId=None, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetClosingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 4)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 5)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 6)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceChecklistItemsExternalRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - complianceState
     - market
     - propertyType
     - listingType
     - sideRepresentation
     - dealPhases
     - propertyBuiltYear
     - isNewConstruction
     - dealType
     - purposeTypes
     - version
     - includeDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'complianceState', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'market', 'UTF8', None, ),  # 7
        (8, TType.I32, 'propertyType', None, None, ),  # 8
        (9, TType.I32, 'listingType', None, None, ),  # 9
        (10, TType.I32, 'sideRepresentation', None, None, ),  # 10
        (11, TType.LIST, 'dealPhases', (TType.I32, None, False), None, ),  # 11
        (12, TType.I32, 'propertyBuiltYear', None, None, ),  # 12
        (13, TType.BOOL, 'isNewConstruction', None, None, ),  # 13
        (14, TType.I32, 'dealType', None, None, ),  # 14
        (15, TType.LIST, 'purposeTypes', (TType.I32, None, False), None, ),  # 15
        (16, TType.I32, 'version', None, None, ),  # 16
        (17, TType.BOOL, 'includeDeleted', None, None, ),  # 17
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, complianceState=None, market=None, propertyType=None, listingType=None, sideRepresentation=None, dealPhases=None, propertyBuiltYear=None, isNewConstruction=None, dealType=None, purposeTypes=None, version=None, includeDeleted=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.complianceState = complianceState
        self.market = market
        self.propertyType = propertyType
        self.listingType = listingType
        self.sideRepresentation = sideRepresentation
        self.dealPhases = dealPhases
        self.propertyBuiltYear = propertyBuiltYear
        self.isNewConstruction = isNewConstruction
        self.dealType = dealType
        self.purposeTypes = purposeTypes
        self.version = version
        self.includeDeleted = includeDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.sideRepresentation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.dealPhases = []
                    (_etype213, _size216) = iprot.readListBegin()
                    for _i214 in range(_size216):
                        _elem215 = iprot.readI32()
                        self.dealPhases.append(_elem215)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.propertyBuiltYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.purposeTypes = []
                    (_etype217, _size220) = iprot.readListBegin()
                    for _i218 in range(_size220):
                        _elem219 = iprot.readI32()
                        self.purposeTypes.append(_elem219)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.includeDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceChecklistItemsExternalRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 6)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 7)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 8)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 9)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.sideRepresentation is not None:
            oprot.writeFieldBegin('sideRepresentation', TType.I32, 10)
            oprot.writeI32(self.sideRepresentation)
            oprot.writeFieldEnd()
        if self.dealPhases is not None:
            oprot.writeFieldBegin('dealPhases', TType.LIST, 11)
            oprot.writeListBegin(TType.I32, len(self.dealPhases))
            for _iter221 in self.dealPhases:
                oprot.writeI32(_iter221)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.propertyBuiltYear is not None:
            oprot.writeFieldBegin('propertyBuiltYear', TType.I32, 12)
            oprot.writeI32(self.propertyBuiltYear)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 13)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 14)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.purposeTypes is not None:
            oprot.writeFieldBegin('purposeTypes', TType.LIST, 15)
            oprot.writeListBegin(TType.I32, len(self.purposeTypes))
            for _iter222 in self.purposeTypes:
                oprot.writeI32(_iter222)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 16)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.includeDeleted is not None:
            oprot.writeFieldBegin('includeDeleted', TType.BOOL, 17)
            oprot.writeBool(self.includeDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetComplianceChecklistItemsExternalResponse(object):
    """
    Attributes:
     - status
     - checklistItems
     - referralChecklistItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklistItems', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument, gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'referralChecklistItems', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument, gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, checklistItems=None, referralChecklistItems=None, ):
        self.status = status
        self.checklistItems = checklistItems
        self.referralChecklistItems = referralChecklistItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistItems = []
                    (_etype223, _size226) = iprot.readListBegin()
                    for _i224 in range(_size226):
                        _elem225 = gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument()
                        _elem225.read(iprot)
                        self.checklistItems.append(_elem225)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.referralChecklistItems = []
                    (_etype227, _size230) = iprot.readListBegin()
                    for _i228 in range(_size230):
                        _elem229 = gen.urbancompass.region_compliance_checklist_model.ttypes.ComplianceDocument()
                        _elem229.read(iprot)
                        self.referralChecklistItems.append(_elem229)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetComplianceChecklistItemsExternalResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItems is not None:
            oprot.writeFieldBegin('checklistItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklistItems))
            for _iter231 in self.checklistItems:
                _iter231.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.referralChecklistItems is not None:
            oprot.writeFieldBegin('referralChecklistItems', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.referralChecklistItems))
            for _iter232 in self.referralChecklistItems:
                _iter232.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSClosingRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSClosingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSClosingResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSClosingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderChecklistItemsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsTransactionId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderChecklistItemsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderChecklistItemsResponse(object):
    """
    Attributes:
     - status
     - checklistItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'checklistItems', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem, gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, checklistItems=None, ):
        self.status = status
        self.checklistItems = checklistItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.checklistItems = []
                    (_etype233, _size236) = iprot.readListBegin()
                    for _i234 in range(_size236):
                        _elem235 = gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem()
                        _elem235.read(iprot)
                        self.checklistItems.append(_elem235)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderChecklistItemsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistItems is not None:
            oprot.writeFieldBegin('checklistItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.checklistItems))
            for _iter237 in self.checklistItems:
                _iter237.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderOverviewRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderOverviewRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderOverviewResponse(object):
    """
    Attributes:
     - status
     - dmsFolder
     - dmsListing
     - dmsTransactionId
     - dmsFolderChecklist
     - team
     - currentStage
     - currentSubStage
     - createdByDisplayName
     - teamDisplayName
     - dualRepSide
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
     - referredBy
     - referredTo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt, gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_translation_model.ttypes.DmsListingExt, gen.urbancompass.dms_translation_model.ttypes.DmsListingExt.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 4
        (5, TType.LIST, 'dmsFolderChecklist', (TType.STRUCT, (gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem, gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'team', 'UTF8', None, ),  # 6
        (7, TType.I32, 'currentStage', None, None, ),  # 7
        (8, TType.I32, 'currentSubStage', None, None, ),  # 8
        (9, TType.STRING, 'createdByDisplayName', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'teamDisplayName', 'UTF8', None, ),  # 10
        (11, TType.I32, 'dualRepSide', None, None, ),  # 11
        (12, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 13
        (14, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 14
        (15, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 15
    )
    def __init__(self, status=None, dmsFolder=None, dmsListing=None, dmsTransactionId=None, dmsFolderChecklist=None, team=None, currentStage=None, currentSubStage=None, createdByDisplayName=None, teamDisplayName=None, dualRepSide=None, otherSideDualRepFolderBtId=None, otherSideDualRepDmsFolderId=None, referredBy=None, referredTo=None, ):
        self.status = status
        self.dmsFolder = dmsFolder
        self.dmsListing = dmsListing
        self.dmsTransactionId = dmsTransactionId
        self.dmsFolderChecklist = dmsFolderChecklist
        self.team = team
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.createdByDisplayName = createdByDisplayName
        self.teamDisplayName = teamDisplayName
        self.dualRepSide = dualRepSide
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.referredBy = referredBy
        self.referredTo = referredTo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_translation_model.ttypes.DmsListingExt()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dmsFolderChecklist = []
                    (_etype238, _size241) = iprot.readListBegin()
                    for _i239 in range(_size241):
                        _elem240 = gen.urbancompass.dms_state_model.ttypes.DmsFolderChecklistItem()
                        _elem240.read(iprot)
                        self.dmsFolderChecklist.append(_elem240)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.createdByDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.teamDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderOverviewResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 2)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 3)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 4)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsFolderChecklist is not None:
            oprot.writeFieldBegin('dmsFolderChecklist', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsFolderChecklist))
            for _iter242 in self.dmsFolderChecklist:
                _iter242.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 6)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 7)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 8)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.createdByDisplayName is not None:
            oprot.writeFieldBegin('createdByDisplayName', TType.STRING, 9)
            oprot.writeString(self.createdByDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.createdByDisplayName)
            oprot.writeFieldEnd()
        if self.teamDisplayName is not None:
            oprot.writeFieldBegin('teamDisplayName', TType.STRING, 10)
            oprot.writeString(self.teamDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.teamDisplayName)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 11)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 12)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 13)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 14)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 15)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderResponse(object):
    """
    Attributes:
     - status
     - dmsFolder
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsFolder', (gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt, gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolder=None, ):
        self.status = status
        self.dmsFolder = dmsFolder

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsFolder = gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt()
                    self.dmsFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolder is not None:
            oprot.writeFieldBegin('dmsFolder', TType.STRUCT, 2)
            self.dmsFolder.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderSettingsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, dmsTransactionId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderSettingsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 7)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFolderSettingsResponse(object):
    """
    Attributes:
     - status
     - propertyTypes
     - ctcServiceTypes
     - markets
     - propertyTypesMap
     - regionDocumentReviewSettings
     - ctcInfoUrl
     - isCommissionStatementRequestEnabled
     - disableDualRepWithoutSameAgent
     - commissionStatementRequestInfo
     - regionBasedOptionalFieldsMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'propertyTypes', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'ctcServiceTypes', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificCtcServiceType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificCtcServiceType.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'markets', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket.thrift_spec), False), None, ),  # 4
        (5, TType.MAP, 'propertyTypesMap', (TType.STRING, 'UTF8', TType.LIST, (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType.thrift_spec), False), False), None, ),  # 5
        (6, TType.STRUCT, 'regionDocumentReviewSettings', (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionDocumentReviewSettings, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionDocumentReviewSettings.thrift_spec), None, ),  # 6
        (7, TType.STRING, 'ctcInfoUrl', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isCommissionStatementRequestEnabled', None, None, ),  # 8
        (9, TType.BOOL, 'disableDualRepWithoutSameAgent', None, None, ),  # 9
        (10, TType.STRUCT, 'commissionStatementRequestInfo', (gen.urbancompass.dms_region_config_service.regions.ttypes.CommissionStatementRequestInfo, gen.urbancompass.dms_region_config_service.regions.ttypes.CommissionStatementRequestInfo.thrift_spec), None, ),  # 10
        (11, TType.MAP, 'regionBasedOptionalFieldsMap', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 11
    )
    def __init__(self, status=None, propertyTypes=None, ctcServiceTypes=None, markets=None, propertyTypesMap=None, regionDocumentReviewSettings=None, ctcInfoUrl=None, isCommissionStatementRequestEnabled=None, disableDualRepWithoutSameAgent=None, commissionStatementRequestInfo=None, regionBasedOptionalFieldsMap=None, ):
        self.status = status
        self.propertyTypes = propertyTypes
        self.ctcServiceTypes = ctcServiceTypes
        self.markets = markets
        self.propertyTypesMap = propertyTypesMap
        self.regionDocumentReviewSettings = regionDocumentReviewSettings
        self.ctcInfoUrl = ctcInfoUrl
        self.isCommissionStatementRequestEnabled = isCommissionStatementRequestEnabled
        self.disableDualRepWithoutSameAgent = disableDualRepWithoutSameAgent
        self.commissionStatementRequestInfo = commissionStatementRequestInfo
        self.regionBasedOptionalFieldsMap = regionBasedOptionalFieldsMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype243, _size246) = iprot.readListBegin()
                    for _i244 in range(_size246):
                        _elem245 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType()
                        _elem245.read(iprot)
                        self.propertyTypes.append(_elem245)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.ctcServiceTypes = []
                    (_etype247, _size250) = iprot.readListBegin()
                    for _i248 in range(_size250):
                        _elem249 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificCtcServiceType()
                        _elem249.read(iprot)
                        self.ctcServiceTypes.append(_elem249)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.markets = []
                    (_etype251, _size254) = iprot.readListBegin()
                    for _i252 in range(_size254):
                        _elem253 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionChecklistMarket()
                        _elem253.read(iprot)
                        self.markets.append(_elem253)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.propertyTypesMap = {}
                    (_ktype256, _vtype257, _size260) = iprot.readMapBegin()
                    for _i255 in range(_size260):
                        _key258 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val259 = []
                        (_etype261, _size264) = iprot.readListBegin()
                        for _i262 in range(_size264):
                            _elem263 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType()
                            _elem263.read(iprot)
                            _val259.append(_elem263)
                        iprot.readListEnd()
                        self.propertyTypesMap[_key258] = _val259
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.regionDocumentReviewSettings = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionDocumentReviewSettings()
                    self.regionDocumentReviewSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.ctcInfoUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isCommissionStatementRequestEnabled = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.disableDualRepWithoutSameAgent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.commissionStatementRequestInfo = gen.urbancompass.dms_region_config_service.regions.ttypes.CommissionStatementRequestInfo()
                    self.commissionStatementRequestInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.MAP:
                    self.regionBasedOptionalFieldsMap = {}
                    (_ktype266, _vtype267, _size270) = iprot.readMapBegin()
                    for _i265 in range(_size270):
                        _key268 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val269 = []
                        (_etype271, _size274) = iprot.readListBegin()
                        for _i272 in range(_size274):
                            _elem273 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val269.append(_elem273)
                        iprot.readListEnd()
                        self.regionBasedOptionalFieldsMap[_key268] = _val269
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFolderSettingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.propertyTypes))
            for _iter275 in self.propertyTypes:
                _iter275.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ctcServiceTypes is not None:
            oprot.writeFieldBegin('ctcServiceTypes', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.ctcServiceTypes))
            for _iter276 in self.ctcServiceTypes:
                _iter276.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.markets is not None:
            oprot.writeFieldBegin('markets', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.markets))
            for _iter277 in self.markets:
                _iter277.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.propertyTypesMap is not None:
            oprot.writeFieldBegin('propertyTypesMap', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.propertyTypesMap))
            for _kiter278, _viter279 in self.propertyTypesMap.items():
                oprot.writeString(_kiter278.encode('utf-8') if sys.version_info[0] == 2 else _kiter278)
                oprot.writeListBegin(TType.STRUCT, len(_viter279))
                for _iter280 in _viter279:
                    _iter280.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.regionDocumentReviewSettings is not None:
            oprot.writeFieldBegin('regionDocumentReviewSettings', TType.STRUCT, 6)
            self.regionDocumentReviewSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.ctcInfoUrl is not None:
            oprot.writeFieldBegin('ctcInfoUrl', TType.STRING, 7)
            oprot.writeString(self.ctcInfoUrl.encode('utf-8') if sys.version_info[0] == 2 else self.ctcInfoUrl)
            oprot.writeFieldEnd()
        if self.isCommissionStatementRequestEnabled is not None:
            oprot.writeFieldBegin('isCommissionStatementRequestEnabled', TType.BOOL, 8)
            oprot.writeBool(self.isCommissionStatementRequestEnabled)
            oprot.writeFieldEnd()
        if self.disableDualRepWithoutSameAgent is not None:
            oprot.writeFieldBegin('disableDualRepWithoutSameAgent', TType.BOOL, 9)
            oprot.writeBool(self.disableDualRepWithoutSameAgent)
            oprot.writeFieldEnd()
        if self.commissionStatementRequestInfo is not None:
            oprot.writeFieldBegin('commissionStatementRequestInfo', TType.STRUCT, 10)
            self.commissionStatementRequestInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.regionBasedOptionalFieldsMap is not None:
            oprot.writeFieldBegin('regionBasedOptionalFieldsMap', TType.MAP, 11)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.regionBasedOptionalFieldsMap))
            for _kiter281, _viter282 in self.regionBasedOptionalFieldsMap.items():
                oprot.writeString(_kiter281.encode('utf-8') if sys.version_info[0] == 2 else _kiter281)
                oprot.writeListBegin(TType.STRING, len(_viter282))
                for _iter283 in _viter282:
                    oprot.writeString(_iter283.encode('utf-8') if sys.version_info[0] == 2 else _iter283)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTByIdDebugRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - btId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'btId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, btId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.btId = btId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTByIdDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 6)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTByIdDebugResponse(object):
    """
    Attributes:
     - status
     - dmsFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolders', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTByIdDebug, gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTByIdDebug.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolders=None, ):
        self.status = status
        self.dmsFolders = dmsFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolders = []
                    (_etype284, _size287) = iprot.readListBegin()
                    for _i285 in range(_size287):
                        _elem286 = gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTByIdDebug()
                        _elem286.read(iprot)
                        self.dmsFolders.append(_elem286)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTByIdDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolders is not None:
            oprot.writeFieldBegin('dmsFolders', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsFolders))
            for _iter288 in self.dmsFolders:
                _iter288.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTDebugRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderIds=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderIds = dmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype289, _size292) = iprot.readListBegin()
                    for _i290 in range(_size292):
                        _elem291 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem291)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter293 in self.dmsFolderIds:
                oprot.writeString(_iter293.encode('utf-8') if sys.version_info[0] == 2 else _iter293)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSFoldersForBTDebugResponse(object):
    """
    Attributes:
     - status
     - userId
     - dmsFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'dmsFolders', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTDebug, gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTDebug.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, userId=None, dmsFolders=None, ):
        self.status = status
        self.userId = userId
        self.dmsFolders = dmsFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.dmsFolders = []
                    (_etype294, _size297) = iprot.readListBegin()
                    for _i295 in range(_size297):
                        _elem296 = gen.urbancompass.dms_translation_model.ttypes.DmsFolderForBTDebug()
                        _elem296.read(iprot)
                        self.dmsFolders.append(_elem296)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSFoldersForBTDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.dmsFolders is not None:
            oprot.writeFieldBegin('dmsFolders', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsFolders))
            for _iter298 in self.dmsFolders:
                _iter298.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSListingRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsListingId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsListingId=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 6)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSListingResponse(object):
    """
    Attributes:
     - status
     - dmsListing
     - isDmsListingComplete
     - isDmsListingSubmitted
     - sideRepresented
     - doesDmsListingExist
     - team
     - originalValueOfPatchedFields
     - patchedFields
     - isDmsOfferComplete
     - isDmsOfferSubmitted
     - dmsAgents
     - disableWithdrawDmsListing
     - referredBy
     - referredTo
     - referralType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsListing', (gen.urbancompass.dms_translation_model.ttypes.DmsListingExt, gen.urbancompass.dms_translation_model.ttypes.DmsListingExt.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isDmsListingComplete', None, None, ),  # 3
        (4, TType.I32, 'sideRepresented', None, None, ),  # 4
        (5, TType.BOOL, 'doesDmsListingExist', None, None, ),  # 5
        (6, TType.STRING, 'team', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'originalValueOfPatchedFields', (gen.urbancompass.dms_translation_model.ttypes.DmsListingExt, gen.urbancompass.dms_translation_model.ttypes.DmsListingExt.thrift_spec), None, ),  # 7
        (8, TType.LIST, 'patchedFields', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 9
        (10, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 10
        (11, TType.BOOL, 'disableWithdrawDmsListing', None, None, ),  # 11
        (12, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 12
        (13, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 13
        (14, TType.BOOL, 'isDmsListingSubmitted', None, None, ),  # 14
        (15, TType.BOOL, 'isDmsOfferSubmitted', None, None, ),  # 15
        (16, TType.I32, 'referralType', None, None, ),  # 16
    )
    def __init__(self, status=None, dmsListing=None, isDmsListingComplete=None, sideRepresented=None, doesDmsListingExist=None, team=None, originalValueOfPatchedFields=None, patchedFields=None, isDmsOfferComplete=None, dmsAgents=None, disableWithdrawDmsListing=None, referredBy=None, referredTo=None, isDmsListingSubmitted=None, isDmsOfferSubmitted=None, referralType=None, ):
        self.status = status
        self.dmsListing = dmsListing
        self.isDmsListingComplete = isDmsListingComplete
        self.sideRepresented = sideRepresented
        self.doesDmsListingExist = doesDmsListingExist
        self.team = team
        self.originalValueOfPatchedFields = originalValueOfPatchedFields
        self.patchedFields = patchedFields
        self.isDmsOfferComplete = isDmsOfferComplete
        self.dmsAgents = dmsAgents
        self.disableWithdrawDmsListing = disableWithdrawDmsListing
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.isDmsListingSubmitted = isDmsListingSubmitted
        self.isDmsOfferSubmitted = isDmsOfferSubmitted
        self.referralType = referralType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsListing = gen.urbancompass.dms_translation_model.ttypes.DmsListingExt()
                    self.dmsListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDmsListingComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.doesDmsListingExist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.originalValueOfPatchedFields = gen.urbancompass.dms_translation_model.ttypes.DmsListingExt()
                    self.originalValueOfPatchedFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.patchedFields = []
                    (_etype299, _size302) = iprot.readListBegin()
                    for _i300 in range(_size302):
                        _elem301 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.patchedFields.append(_elem301)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype303, _size306) = iprot.readListBegin()
                    for _i304 in range(_size306):
                        _elem305 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem305.read(iprot)
                        self.dmsAgents.append(_elem305)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.disableWithdrawDmsListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.isDmsListingSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.isDmsOfferSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListing is not None:
            oprot.writeFieldBegin('dmsListing', TType.STRUCT, 2)
            self.dmsListing.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsListingComplete is not None:
            oprot.writeFieldBegin('isDmsListingComplete', TType.BOOL, 3)
            oprot.writeBool(self.isDmsListingComplete)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 4)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.doesDmsListingExist is not None:
            oprot.writeFieldBegin('doesDmsListingExist', TType.BOOL, 5)
            oprot.writeBool(self.doesDmsListingExist)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 6)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.originalValueOfPatchedFields is not None:
            oprot.writeFieldBegin('originalValueOfPatchedFields', TType.STRUCT, 7)
            self.originalValueOfPatchedFields.write(oprot)
            oprot.writeFieldEnd()
        if self.patchedFields is not None:
            oprot.writeFieldBegin('patchedFields', TType.LIST, 8)
            oprot.writeListBegin(TType.STRING, len(self.patchedFields))
            for _iter307 in self.patchedFields:
                oprot.writeString(_iter307.encode('utf-8') if sys.version_info[0] == 2 else _iter307)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 9)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter308 in self.dmsAgents:
                _iter308.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.disableWithdrawDmsListing is not None:
            oprot.writeFieldBegin('disableWithdrawDmsListing', TType.BOOL, 11)
            oprot.writeBool(self.disableWithdrawDmsListing)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 12)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 13)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsListingSubmitted is not None:
            oprot.writeFieldBegin('isDmsListingSubmitted', TType.BOOL, 14)
            oprot.writeBool(self.isDmsListingSubmitted)
            oprot.writeFieldEnd()
        if self.isDmsOfferSubmitted is not None:
            oprot.writeFieldBegin('isDmsOfferSubmitted', TType.BOOL, 15)
            oprot.writeBool(self.isDmsOfferSubmitted)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 16)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSOfferRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSOfferRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSOfferResponse(object):
    """
    Attributes:
     - status
     - dmsOffer
     - isDmsOfferComplete
     - isDmsOfferSubmitted
     - sideRepresented
     - isDmsListingComplete
     - isDmsListingSubmitted
     - doesDmsListingExist
     - doesDmsOfferExist
     - team
     - originalValueOfPatchedFields
     - fieldsPatched
     - dmsContacts
     - dlfsContacts
     - dmsAgents
     - dualRepAgent
     - dualRepSide
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
     - disableCancelDmsOffer
     - referredBy
     - referredTo
     - referralType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsOffer', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 3
        (4, TType.I32, 'sideRepresented', None, None, ),  # 4
        (5, TType.BOOL, 'isDmsListingComplete', None, None, ),  # 5
        (6, TType.BOOL, 'doesDmsListingExist', None, None, ),  # 6
        (7, TType.BOOL, 'doesDmsOfferExist', None, None, ),  # 7
        (8, TType.STRING, 'team', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'originalValueOfPatchedFields', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 9
        (10, TType.LIST, 'fieldsPatched', (TType.STRING, 'UTF8', False), None, ),  # 10
        (11, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 11
        (12, TType.LIST, 'dlfsContacts', (TType.STRUCT, (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), False), None, ),  # 12
        (13, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 13
        (14, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), None, ),  # 14
        (15, TType.I32, 'dualRepSide', None, None, ),  # 15
        (16, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 17
        (18, TType.BOOL, 'disableCancelDmsOffer', None, None, ),  # 18
        (19, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 19
        (20, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 20
        (21, TType.BOOL, 'isDmsListingSubmitted', None, None, ),  # 21
        (22, TType.BOOL, 'isDmsOfferSubmitted', None, None, ),  # 22
        (23, TType.I32, 'referralType', None, None, ),  # 23
    )
    def __init__(self, status=None, dmsOffer=None, isDmsOfferComplete=None, sideRepresented=None, isDmsListingComplete=None, doesDmsListingExist=None, doesDmsOfferExist=None, team=None, originalValueOfPatchedFields=None, fieldsPatched=None, dmsContacts=None, dlfsContacts=None, dmsAgents=None, dualRepAgent=None, dualRepSide=None, otherSideDualRepFolderBtId=None, otherSideDualRepDmsFolderId=None, disableCancelDmsOffer=None, referredBy=None, referredTo=None, isDmsListingSubmitted=None, isDmsOfferSubmitted=None, referralType=None, ):
        self.status = status
        self.dmsOffer = dmsOffer
        self.isDmsOfferComplete = isDmsOfferComplete
        self.sideRepresented = sideRepresented
        self.isDmsListingComplete = isDmsListingComplete
        self.doesDmsListingExist = doesDmsListingExist
        self.doesDmsOfferExist = doesDmsOfferExist
        self.team = team
        self.originalValueOfPatchedFields = originalValueOfPatchedFields
        self.fieldsPatched = fieldsPatched
        self.dmsContacts = dmsContacts
        self.dlfsContacts = dlfsContacts
        self.dmsAgents = dmsAgents
        self.dualRepAgent = dualRepAgent
        self.dualRepSide = dualRepSide
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.disableCancelDmsOffer = disableCancelDmsOffer
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.isDmsListingSubmitted = isDmsListingSubmitted
        self.isDmsOfferSubmitted = isDmsOfferSubmitted
        self.referralType = referralType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsOffer = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.dmsOffer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isDmsListingComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.doesDmsListingExist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.doesDmsOfferExist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.originalValueOfPatchedFields = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.originalValueOfPatchedFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.fieldsPatched = []
                    (_etype309, _size312) = iprot.readListBegin()
                    for _i310 in range(_size312):
                        _elem311 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fieldsPatched.append(_elem311)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype313, _size316) = iprot.readListBegin()
                    for _i314 in range(_size316):
                        _elem315 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem315.read(iprot)
                        self.dmsContacts.append(_elem315)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.dlfsContacts = []
                    (_etype317, _size320) = iprot.readListBegin()
                    for _i318 in range(_size320):
                        _elem319 = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                        _elem319.read(iprot)
                        self.dlfsContacts.append(_elem319)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype321, _size324) = iprot.readListBegin()
                    for _i322 in range(_size324):
                        _elem323 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem323.read(iprot)
                        self.dmsAgents.append(_elem323)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.disableCancelDmsOffer = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.BOOL:
                    self.isDmsListingSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.isDmsOfferSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSOfferResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsOffer is not None:
            oprot.writeFieldBegin('dmsOffer', TType.STRUCT, 2)
            self.dmsOffer.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 3)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 4)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.isDmsListingComplete is not None:
            oprot.writeFieldBegin('isDmsListingComplete', TType.BOOL, 5)
            oprot.writeBool(self.isDmsListingComplete)
            oprot.writeFieldEnd()
        if self.doesDmsListingExist is not None:
            oprot.writeFieldBegin('doesDmsListingExist', TType.BOOL, 6)
            oprot.writeBool(self.doesDmsListingExist)
            oprot.writeFieldEnd()
        if self.doesDmsOfferExist is not None:
            oprot.writeFieldBegin('doesDmsOfferExist', TType.BOOL, 7)
            oprot.writeBool(self.doesDmsOfferExist)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 8)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.originalValueOfPatchedFields is not None:
            oprot.writeFieldBegin('originalValueOfPatchedFields', TType.STRUCT, 9)
            self.originalValueOfPatchedFields.write(oprot)
            oprot.writeFieldEnd()
        if self.fieldsPatched is not None:
            oprot.writeFieldBegin('fieldsPatched', TType.LIST, 10)
            oprot.writeListBegin(TType.STRING, len(self.fieldsPatched))
            for _iter325 in self.fieldsPatched:
                oprot.writeString(_iter325.encode('utf-8') if sys.version_info[0] == 2 else _iter325)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter326 in self.dmsContacts:
                _iter326.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dlfsContacts is not None:
            oprot.writeFieldBegin('dlfsContacts', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.dlfsContacts))
            for _iter327 in self.dlfsContacts:
                _iter327.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 13)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter328 in self.dmsAgents:
                _iter328.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 14)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 15)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 16)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 17)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.disableCancelDmsOffer is not None:
            oprot.writeFieldBegin('disableCancelDmsOffer', TType.BOOL, 18)
            oprot.writeBool(self.disableCancelDmsOffer)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 19)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 20)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsListingSubmitted is not None:
            oprot.writeFieldBegin('isDmsListingSubmitted', TType.BOOL, 21)
            oprot.writeBool(self.isDmsListingSubmitted)
            oprot.writeFieldEnd()
        if self.isDmsOfferSubmitted is not None:
            oprot.writeFieldBegin('isDmsOfferSubmitted', TType.BOOL, 22)
            oprot.writeBool(self.isDmsOfferSubmitted)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 23)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSSpecificListingPageInfoRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSSpecificListingPageInfoRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSSpecificListingPageInfoResponse(object):
    """
    Attributes:
     - status
     - dealSpecificListingInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dealSpecificListingInfo', (gen.urbancompass.dms_translation_model.ttypes.DmsSpecificListingPageInfo, gen.urbancompass.dms_translation_model.ttypes.DmsSpecificListingPageInfo.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dealSpecificListingInfo=None, ):
        self.status = status
        self.dealSpecificListingInfo = dealSpecificListingInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dealSpecificListingInfo = gen.urbancompass.dms_translation_model.ttypes.DmsSpecificListingPageInfo()
                    self.dealSpecificListingInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSSpecificListingPageInfoResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dealSpecificListingInfo is not None:
            oprot.writeFieldBegin('dealSpecificListingInfo', TType.STRUCT, 2)
            self.dealSpecificListingInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSTransactionRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsTransactionId
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsTransactionId=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsTransactionId = dmsTransactionId
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSTransactionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDMSTransactionResponse(object):
    """
    Attributes:
     - status
     - dmsTransaction
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsTransaction', (gen.urbancompass.dms_translation_model.ttypes.DmsTransactionExt, gen.urbancompass.dms_translation_model.ttypes.DmsTransactionExt.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dmsTransaction=None, ):
        self.status = status
        self.dmsTransaction = dmsTransaction

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsTransaction = gen.urbancompass.dms_translation_model.ttypes.DmsTransactionExt()
                    self.dmsTransaction.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDMSTransactionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransaction is not None:
            oprot.writeFieldBegin('dmsTransaction', TType.STRUCT, 2)
            self.dmsTransaction.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDRSEnrichedFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDRSEnrichedFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDRSEnrichedFolderResponse(object):
    """
    Attributes:
     - status
     - drsEnrichedFolder
     - allowedGroups
     - dmsListingId
     - dmsTransactionId
     - isDmsListingDeleted
     - isDmsTransactionDeleted
     - dualRepSide
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'drsEnrichedFolder', (gen.urbancompass.dms_translation_model.ttypes.DrsEnrichedFolder, gen.urbancompass.dms_translation_model.ttypes.DrsEnrichedFolder.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'allowedGroups', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DrsGroup, gen.urbancompass.dms_translation_model.ttypes.DrsGroup.thrift_spec), False), None, ),  # 3
        (4, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'isDmsListingDeleted', None, None, ),  # 6
        (7, TType.BOOL, 'isDmsTransactionDeleted', None, None, ),  # 7
        (8, TType.I32, 'dualRepSide', None, None, ),  # 8
        (9, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 10
    )
    def __init__(self, status=None, drsEnrichedFolder=None, allowedGroups=None, dmsListingId=None, dmsTransactionId=None, isDmsListingDeleted=None, isDmsTransactionDeleted=None, dualRepSide=None, otherSideDualRepFolderBtId=None, otherSideDualRepDmsFolderId=None, ):
        self.status = status
        self.drsEnrichedFolder = drsEnrichedFolder
        self.allowedGroups = allowedGroups
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.isDmsListingDeleted = isDmsListingDeleted
        self.isDmsTransactionDeleted = isDmsTransactionDeleted
        self.dualRepSide = dualRepSide
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.drsEnrichedFolder = gen.urbancompass.dms_translation_model.ttypes.DrsEnrichedFolder()
                    self.drsEnrichedFolder.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.allowedGroups = []
                    (_etype329, _size332) = iprot.readListBegin()
                    for _i330 in range(_size332):
                        _elem331 = gen.urbancompass.dms_translation_model.ttypes.DrsGroup()
                        _elem331.read(iprot)
                        self.allowedGroups.append(_elem331)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isDmsListingDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isDmsTransactionDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.dualRepSide = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDRSEnrichedFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.drsEnrichedFolder is not None:
            oprot.writeFieldBegin('drsEnrichedFolder', TType.STRUCT, 2)
            self.drsEnrichedFolder.write(oprot)
            oprot.writeFieldEnd()
        if self.allowedGroups is not None:
            oprot.writeFieldBegin('allowedGroups', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.allowedGroups))
            for _iter333 in self.allowedGroups:
                _iter333.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 4)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 5)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.isDmsListingDeleted is not None:
            oprot.writeFieldBegin('isDmsListingDeleted', TType.BOOL, 6)
            oprot.writeBool(self.isDmsListingDeleted)
            oprot.writeFieldEnd()
        if self.isDmsTransactionDeleted is not None:
            oprot.writeFieldBegin('isDmsTransactionDeleted', TType.BOOL, 7)
            oprot.writeBool(self.isDmsTransactionDeleted)
            oprot.writeFieldEnd()
        if self.dualRepSide is not None:
            oprot.writeFieldBegin('dualRepSide', TType.I32, 8)
            oprot.writeI32(self.dualRepSide)
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 9)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 10)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDRSFoldersRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - skip
     - limit
     - includeTotalCount
     - groupIds
     - teamIds
     - agent
     - propertyAddress
     - stage
     - subStages
     - hasPendingDocuments
     - hasUnresolvedNotes
     - reviewStatus
     - ctcServiceTypes
     - folderTransactionTypes
     - excludeReferralDeals
     - textQuery
     - team
     - folderSortingRequest
     - lightWeight
     - followOptimization
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'groupIds', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.I32, 'skip', None, None, ),  # 7
        (8, TType.I32, 'limit', None, None, ),  # 8
        (9, TType.STRING, 'team', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'agent', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 11
        None,  # 12
        (13, TType.I32, 'stage', None, None, ),  # 13
        (14, TType.BOOL, 'hasPendingDocuments', None, None, ),  # 14
        (15, TType.I32, 'reviewStatus', None, None, ),  # 15
        (16, TType.STRUCT, 'folderSortingRequest', (gen.urbancompass.dms_common.dms_folder.ttypes.FolderSortingRequest, gen.urbancompass.dms_common.dms_folder.ttypes.FolderSortingRequest.thrift_spec), None, ),  # 16
        (17, TType.STRING, 'textQuery', 'UTF8', None, ),  # 17
        (18, TType.LIST, 'subStages', (TType.I32, None, False), None, ),  # 18
        (19, TType.BOOL, 'includeTotalCount', None, None, ),  # 19
        (20, TType.LIST, 'ctcServiceTypes', (TType.I32, None, False), None, ),  # 20
        (21, TType.BOOL, 'lightWeight', None, None, ),  # 21
        (22, TType.BOOL, 'followOptimization', None, None, ),  # 22
        (23, TType.LIST, 'teamIds', (TType.STRING, 'UTF8', False), None, ),  # 23
        (24, TType.BOOL, 'hasUnresolvedNotes', None, None, ),  # 24
        (25, TType.LIST, 'folderTransactionTypes', (TType.I32, None, False), None, ),  # 25
        (26, TType.BOOL, 'excludeReferralDeals', None, None, ),  # 26
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, groupIds=None, skip=None, limit=None, team=None, agent=None, propertyAddress=None, stage=None, hasPendingDocuments=None, reviewStatus=None, folderSortingRequest=None, textQuery=None, subStages=None, includeTotalCount=None, ctcServiceTypes=None, lightWeight=None, followOptimization=None, teamIds=None, hasUnresolvedNotes=None, folderTransactionTypes=None, excludeReferralDeals=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.groupIds = groupIds
        self.skip = skip
        self.limit = limit
        self.team = team
        self.agent = agent
        self.propertyAddress = propertyAddress
        self.stage = stage
        self.hasPendingDocuments = hasPendingDocuments
        self.reviewStatus = reviewStatus
        self.folderSortingRequest = folderSortingRequest
        self.textQuery = textQuery
        self.subStages = subStages
        self.includeTotalCount = includeTotalCount
        self.ctcServiceTypes = ctcServiceTypes
        self.lightWeight = lightWeight
        self.followOptimization = followOptimization
        self.teamIds = teamIds
        self.hasUnresolvedNotes = hasUnresolvedNotes
        self.folderTransactionTypes = folderTransactionTypes
        self.excludeReferralDeals = excludeReferralDeals

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.groupIds = []
                    (_etype334, _size337) = iprot.readListBegin()
                    for _i335 in range(_size337):
                        _elem336 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.groupIds.append(_elem336)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.skip = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.agent = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.hasPendingDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.reviewStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.folderSortingRequest = gen.urbancompass.dms_common.dms_folder.ttypes.FolderSortingRequest()
                    self.folderSortingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.textQuery = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.LIST:
                    self.subStages = []
                    (_etype338, _size341) = iprot.readListBegin()
                    for _i339 in range(_size341):
                        _elem340 = iprot.readI32()
                        self.subStages.append(_elem340)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.includeTotalCount = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.ctcServiceTypes = []
                    (_etype342, _size345) = iprot.readListBegin()
                    for _i343 in range(_size345):
                        _elem344 = iprot.readI32()
                        self.ctcServiceTypes.append(_elem344)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.BOOL:
                    self.lightWeight = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.followOptimization = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.LIST:
                    self.teamIds = []
                    (_etype346, _size349) = iprot.readListBegin()
                    for _i347 in range(_size349):
                        _elem348 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.teamIds.append(_elem348)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.hasUnresolvedNotes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.LIST:
                    self.folderTransactionTypes = []
                    (_etype350, _size353) = iprot.readListBegin()
                    for _i351 in range(_size353):
                        _elem352 = iprot.readI32()
                        self.folderTransactionTypes.append(_elem352)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.BOOL:
                    self.excludeReferralDeals = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDRSFoldersRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.groupIds is not None:
            oprot.writeFieldBegin('groupIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.groupIds))
            for _iter354 in self.groupIds:
                oprot.writeString(_iter354.encode('utf-8') if sys.version_info[0] == 2 else _iter354)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.I32, 7)
            oprot.writeI32(self.skip)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 8)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 9)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.agent is not None:
            oprot.writeFieldBegin('agent', TType.STRING, 10)
            oprot.writeString(self.agent.encode('utf-8') if sys.version_info[0] == 2 else self.agent)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 11)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 13)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.hasPendingDocuments is not None:
            oprot.writeFieldBegin('hasPendingDocuments', TType.BOOL, 14)
            oprot.writeBool(self.hasPendingDocuments)
            oprot.writeFieldEnd()
        if self.reviewStatus is not None:
            oprot.writeFieldBegin('reviewStatus', TType.I32, 15)
            oprot.writeI32(self.reviewStatus)
            oprot.writeFieldEnd()
        if self.folderSortingRequest is not None:
            oprot.writeFieldBegin('folderSortingRequest', TType.STRUCT, 16)
            self.folderSortingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.textQuery is not None:
            oprot.writeFieldBegin('textQuery', TType.STRING, 17)
            oprot.writeString(self.textQuery.encode('utf-8') if sys.version_info[0] == 2 else self.textQuery)
            oprot.writeFieldEnd()
        if self.subStages is not None:
            oprot.writeFieldBegin('subStages', TType.LIST, 18)
            oprot.writeListBegin(TType.I32, len(self.subStages))
            for _iter355 in self.subStages:
                oprot.writeI32(_iter355)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeTotalCount is not None:
            oprot.writeFieldBegin('includeTotalCount', TType.BOOL, 19)
            oprot.writeBool(self.includeTotalCount)
            oprot.writeFieldEnd()
        if self.ctcServiceTypes is not None:
            oprot.writeFieldBegin('ctcServiceTypes', TType.LIST, 20)
            oprot.writeListBegin(TType.I32, len(self.ctcServiceTypes))
            for _iter356 in self.ctcServiceTypes:
                oprot.writeI32(_iter356)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lightWeight is not None:
            oprot.writeFieldBegin('lightWeight', TType.BOOL, 21)
            oprot.writeBool(self.lightWeight)
            oprot.writeFieldEnd()
        if self.followOptimization is not None:
            oprot.writeFieldBegin('followOptimization', TType.BOOL, 22)
            oprot.writeBool(self.followOptimization)
            oprot.writeFieldEnd()
        if self.teamIds is not None:
            oprot.writeFieldBegin('teamIds', TType.LIST, 23)
            oprot.writeListBegin(TType.STRING, len(self.teamIds))
            for _iter357 in self.teamIds:
                oprot.writeString(_iter357.encode('utf-8') if sys.version_info[0] == 2 else _iter357)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hasUnresolvedNotes is not None:
            oprot.writeFieldBegin('hasUnresolvedNotes', TType.BOOL, 24)
            oprot.writeBool(self.hasUnresolvedNotes)
            oprot.writeFieldEnd()
        if self.folderTransactionTypes is not None:
            oprot.writeFieldBegin('folderTransactionTypes', TType.LIST, 25)
            oprot.writeListBegin(TType.I32, len(self.folderTransactionTypes))
            for _iter358 in self.folderTransactionTypes:
                oprot.writeI32(_iter358)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.excludeReferralDeals is not None:
            oprot.writeFieldBegin('excludeReferralDeals', TType.BOOL, 26)
            oprot.writeBool(self.excludeReferralDeals)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDRSFoldersResponse(object):
    """
    Attributes:
     - status
     - folders
     - totalCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'folders', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DrsEnrichedFolder, gen.urbancompass.dms_translation_model.ttypes.DrsEnrichedFolder.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalCount', None, None, ),  # 3
    )
    def __init__(self, status=None, folders=None, totalCount=None, ):
        self.status = status
        self.folders = folders
        self.totalCount = totalCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.folders = []
                    (_etype359, _size362) = iprot.readListBegin()
                    for _i360 in range(_size362):
                        _elem361 = gen.urbancompass.dms_translation_model.ttypes.DrsEnrichedFolder()
                        _elem361.read(iprot)
                        self.folders.append(_elem361)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDRSFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.folders is not None:
            oprot.writeFieldBegin('folders', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.folders))
            for _iter363 in self.folders:
                _iter363.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalCount is not None:
            oprot.writeFieldBegin('totalCount', TType.I32, 3)
            oprot.writeI32(self.totalCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDRSGroupsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - includeTeamDetails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.BOOL, 'includeTeamDetails', None, None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, includeTeamDetails=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.includeTeamDetails = includeTeamDetails

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.includeTeamDetails = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDRSGroupsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.includeTeamDetails is not None:
            oprot.writeFieldBegin('includeTeamDetails', TType.BOOL, 6)
            oprot.writeBool(self.includeTeamDetails)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDRSGroupsResponse(object):
    """
    Attributes:
     - status
     - allowedGroups
     - allowedTeams
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'allowedGroups', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DrsGroup, gen.urbancompass.dms_translation_model.ttypes.DrsGroup.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'allowedTeams', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DrsTeam, gen.urbancompass.dms_translation_model.ttypes.DrsTeam.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, allowedGroups=None, allowedTeams=None, ):
        self.status = status
        self.allowedGroups = allowedGroups
        self.allowedTeams = allowedTeams

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.allowedGroups = []
                    (_etype364, _size367) = iprot.readListBegin()
                    for _i365 in range(_size367):
                        _elem366 = gen.urbancompass.dms_translation_model.ttypes.DrsGroup()
                        _elem366.read(iprot)
                        self.allowedGroups.append(_elem366)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.allowedTeams = []
                    (_etype368, _size371) = iprot.readListBegin()
                    for _i369 in range(_size371):
                        _elem370 = gen.urbancompass.dms_translation_model.ttypes.DrsTeam()
                        _elem370.read(iprot)
                        self.allowedTeams.append(_elem370)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDRSGroupsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.allowedGroups is not None:
            oprot.writeFieldBegin('allowedGroups', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.allowedGroups))
            for _iter372 in self.allowedGroups:
                _iter372.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.allowedTeams is not None:
            oprot.writeFieldBegin('allowedTeams', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.allowedTeams))
            for _iter373 in self.allowedTeams:
                _iter373.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsSyncDetailsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsSyncDetailsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsSyncDetailsResponse(object):
    """
    Attributes:
     - status
     - dmsDetails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'dmsDetails', (gen.urbancompass.dms_translation_model.ttypes.DmsFolderDetailsForGlideSync, gen.urbancompass.dms_translation_model.ttypes.DmsFolderDetailsForGlideSync.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, dmsDetails=None, ):
        self.status = status
        self.dmsDetails = dmsDetails

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.dmsDetails = gen.urbancompass.dms_translation_model.ttypes.DmsFolderDetailsForGlideSync()
                    self.dmsDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsSyncDetailsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsDetails is not None:
            oprot.writeFieldBegin('dmsDetails', TType.STRUCT, 2)
            self.dmsDetails.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsTransactionDebugRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsTransactionId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsTransactionDebugRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDmsTransactionDebugResponse(object):
    """
    Attributes:
     - status
     - dmsFolderId
     - btId
     - dmsTransactionId
     - isDmsFolderDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'btId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'isDmsFolderDeleted', None, None, ),  # 5
    )
    def __init__(self, status=None, dmsFolderId=None, btId=None, dmsTransactionId=None, isDmsFolderDeleted=None, ):
        self.status = status
        self.dmsFolderId = dmsFolderId
        self.btId = btId
        self.dmsTransactionId = dmsTransactionId
        self.isDmsFolderDeleted = isDmsFolderDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isDmsFolderDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDmsTransactionDebugResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 3)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 4)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.isDmsFolderDeleted is not None:
            oprot.writeFieldBegin('isDmsFolderDeleted', TType.BOOL, 5)
            oprot.writeBool(self.isDmsFolderDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDocumentListMetadataRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - documentIds
     - isStaff
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'documentIds', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.BOOL, 'isStaff', None, None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, documentIds=None, isStaff=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.documentIds = documentIds
        self.isStaff = isStaff

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.documentIds = []
                    (_etype374, _size377) = iprot.readListBegin()
                    for _i375 in range(_size377):
                        _elem376 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.documentIds.append(_elem376)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isStaff = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDocumentListMetadataRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.documentIds is not None:
            oprot.writeFieldBegin('documentIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.documentIds))
            for _iter378 in self.documentIds:
                oprot.writeString(_iter378.encode('utf-8') if sys.version_info[0] == 2 else _iter378)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isStaff is not None:
            oprot.writeFieldBegin('isStaff', TType.BOOL, 7)
            oprot.writeBool(self.isStaff)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDocumentListMetadataResponse(object):
    """
    Attributes:
     - status
     - metadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'metadata', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.dms_document.ttypes.DmsDocumentMetadata, gen.urbancompass.dms_document.ttypes.DmsDocumentMetadata.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, metadata=None, ):
        self.status = status
        self.metadata = metadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.metadata = {}
                    (_ktype380, _vtype381, _size384) = iprot.readMapBegin()
                    for _i379 in range(_size384):
                        _key382 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val383 = gen.urbancompass.dms_document.ttypes.DmsDocumentMetadata()
                        _val383.read(iprot)
                        self.metadata[_key382] = _val383
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDocumentListMetadataResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.metadata))
            for _kiter385, _viter386 in self.metadata.items():
                oprot.writeString(_kiter385.encode('utf-8') if sys.version_info[0] == 2 else _kiter385)
                _viter386.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDocumentRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - documentId
     - includeContent
     - includeMetadata
     - includeNotes
     - isStaff
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'documentId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'includeContent', None, None, ),  # 7
        (8, TType.BOOL, 'includeMetadata', None, None, ),  # 8
        (9, TType.BOOL, 'includeNotes', None, None, ),  # 9
        (10, TType.BOOL, 'isStaff', None, None, ),  # 10
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, documentId=None, includeContent=None, includeMetadata=None, includeNotes=None, isStaff=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.documentId = documentId
        self.includeContent = includeContent
        self.includeMetadata = includeMetadata
        self.includeNotes = includeNotes
        self.isStaff = isStaff

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.includeContent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.includeMetadata = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.includeNotes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.isStaff = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 6)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.includeContent is not None:
            oprot.writeFieldBegin('includeContent', TType.BOOL, 7)
            oprot.writeBool(self.includeContent)
            oprot.writeFieldEnd()
        if self.includeMetadata is not None:
            oprot.writeFieldBegin('includeMetadata', TType.BOOL, 8)
            oprot.writeBool(self.includeMetadata)
            oprot.writeFieldEnd()
        if self.includeNotes is not None:
            oprot.writeFieldBegin('includeNotes', TType.BOOL, 9)
            oprot.writeBool(self.includeNotes)
            oprot.writeFieldEnd()
        if self.isStaff is not None:
            oprot.writeFieldBegin('isStaff', TType.BOOL, 10)
            oprot.writeBool(self.isStaff)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetDocumentResponse(object):
    """
    Attributes:
     - status
     - document
     - metadata
     - notes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'document', (gen.urbancompass.dms_document.ttypes.DmsDocument, gen.urbancompass.dms_document.ttypes.DmsDocument.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'metadata', (gen.urbancompass.dms_document.ttypes.DmsDocumentMetadata, gen.urbancompass.dms_document.ttypes.DmsDocumentMetadata.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'notes', (TType.STRUCT, (gen.urbancompass.dms_document.ttypes.DmsDocumentNote, gen.urbancompass.dms_document.ttypes.DmsDocumentNote.thrift_spec), False), None, ),  # 4
    )
    def __init__(self, status=None, document=None, metadata=None, notes=None, ):
        self.status = status
        self.document = document
        self.metadata = metadata
        self.notes = notes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.document = gen.urbancompass.dms_document.ttypes.DmsDocument()
                    self.document.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.metadata = gen.urbancompass.dms_document.ttypes.DmsDocumentMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.notes = []
                    (_etype387, _size390) = iprot.readListBegin()
                    for _i388 in range(_size390):
                        _elem389 = gen.urbancompass.dms_document.ttypes.DmsDocumentNote()
                        _elem389.read(iprot)
                        self.notes.append(_elem389)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.document is not None:
            oprot.writeFieldBegin('document', TType.STRUCT, 2)
            self.document.write(oprot)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 3)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.notes))
            for _iter391 in self.notes:
                _iter391.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImpactedFieldsForChecklistResponse(object):
    """
    Attributes:
     - status
     - fields
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'fields', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, fields=None, ):
        self.status = status
        self.fields = fields

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.fields = []
                    (_etype392, _size395) = iprot.readListBegin()
                    for _i393 in range(_size395):
                        _elem394 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fields.append(_elem394)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImpactedFieldsForChecklistResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.fields is not None:
            oprot.writeFieldBegin('fields', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.fields))
            for _iter396 in self.fields:
                oprot.writeString(_iter396.encode('utf-8') if sys.version_info[0] == 2 else _iter396)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetNextActionRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetNextActionRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetNextActionResponse(object):
    """
    Attributes:
     - status
     - nextAction
     - sideRepresented
     - isPrincipal
     - referralType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'nextAction', None, None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.BOOL, 'isPrincipal', None, None, ),  # 4
        (5, TType.I32, 'referralType', None, None, ),  # 5
    )
    def __init__(self, status=None, nextAction=None, sideRepresented=None, isPrincipal=None, referralType=None, ):
        self.status = status
        self.nextAction = nextAction
        self.sideRepresented = sideRepresented
        self.isPrincipal = isPrincipal
        self.referralType = referralType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.nextAction = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isPrincipal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetNextActionResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.nextAction is not None:
            oprot.writeFieldBegin('nextAction', TType.I32, 2)
            oprot.writeI32(self.nextAction)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.isPrincipal is not None:
            oprot.writeFieldBegin('isPrincipal', TType.BOOL, 4)
            oprot.writeBool(self.isPrincipal)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 5)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPreComplianceDMSFoldersRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPreComplianceDMSFoldersRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetPreComplianceDMSFoldersResponse(object):
    """
    Attributes:
     - status
     - dmsFolderIds
     - preComlianceDMSFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'dmsFolderIds', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'preComlianceDMSFolders', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.PreComplianceDMSFolder, gen.urbancompass.dms_translation_model.ttypes.PreComplianceDMSFolder.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, status=None, dmsFolderIds=None, preComlianceDMSFolders=None, ):
        self.status = status
        self.dmsFolderIds = dmsFolderIds
        self.preComlianceDMSFolders = preComlianceDMSFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderIds = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.preComlianceDMSFolders = []
                    (_etype397, _size400) = iprot.readListBegin()
                    for _i398 in range(_size400):
                        _elem399 = gen.urbancompass.dms_translation_model.ttypes.PreComplianceDMSFolder()
                        _elem399.read(iprot)
                        self.preComlianceDMSFolders.append(_elem399)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetPreComplianceDMSFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.STRING, 2)
            oprot.writeString(self.dmsFolderIds.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderIds)
            oprot.writeFieldEnd()
        if self.preComlianceDMSFolders is not None:
            oprot.writeFieldBegin('preComlianceDMSFolders', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.preComlianceDMSFolders))
            for _iter401 in self.preComlianceDMSFolders:
                _iter401.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetRegionSpecificPropertyTypesRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - region
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'region', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, region=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.region = region

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.region = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetRegionSpecificPropertyTypesRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.region is not None:
            oprot.writeFieldBegin('region', TType.STRING, 6)
            oprot.writeString(self.region.encode('utf-8') if sys.version_info[0] == 2 else self.region)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetRegionSpecificPropertyTypesResponse(object):
    """
    Attributes:
     - status
     - propertyTypes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'propertyTypes', (TType.STRUCT, (gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType, gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, propertyTypes=None, ):
        self.status = status
        self.propertyTypes = propertyTypes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype402, _size405) = iprot.readListBegin()
                    for _i403 in range(_size405):
                        _elem404 = gen.urbancompass.region_compliance_checklist_model.ttypes.RegionSpecificPropertyType()
                        _elem404.read(iprot)
                        self.propertyTypes.append(_elem404)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetRegionSpecificPropertyTypesResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.propertyTypes))
            for _iter406 in self.propertyTypes:
                _iter406.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetStaffPermissionForTeamRequest(object):
    """
    Attributes:
     - serviceName
     - token
     - staffUserId
     - resourceTeamId
     - operationType
     - impersonatorId
     - userId
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'serviceName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'token', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'staffUserId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'resourceTeamId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'operationType', None, None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'userId', 'UTF8', None, ),  # 7
        (8, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 8
    )
    def __init__(self, serviceName=None, token=None, staffUserId=None, resourceTeamId=None, operationType=None, impersonatorId=None, userId=None, signature=None, ):
        self.serviceName = serviceName
        self.token = token
        self.staffUserId = staffUserId
        self.resourceTeamId = resourceTeamId
        self.operationType = operationType
        self.impersonatorId = impersonatorId
        self.userId = userId
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.staffUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.resourceTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.operationType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetStaffPermissionForTeamRequest')
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 1)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 2)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.staffUserId is not None:
            oprot.writeFieldBegin('staffUserId', TType.STRING, 3)
            oprot.writeString(self.staffUserId.encode('utf-8') if sys.version_info[0] == 2 else self.staffUserId)
            oprot.writeFieldEnd()
        if self.resourceTeamId is not None:
            oprot.writeFieldBegin('resourceTeamId', TType.STRING, 4)
            oprot.writeString(self.resourceTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.resourceTeamId)
            oprot.writeFieldEnd()
        if self.operationType is not None:
            oprot.writeFieldBegin('operationType', TType.I32, 5)
            oprot.writeI32(self.operationType)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 7)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 8)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetStaffPermissionForTeamResponse(object):
    """
    Attributes:
     - status
     - isAllowed
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'isAllowed', None, None, ),  # 2
    )
    def __init__(self, status=None, isAllowed=None, ):
        self.status = status
        self.isAllowed = isAllowed

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isAllowed = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetStaffPermissionForTeamResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.isAllowed is not None:
            oprot.writeFieldBegin('isAllowed', TType.BOOL, 2)
            oprot.writeBool(self.isAllowed)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamDmsFoldersMatchingLocationRequest(object):
    """
    Attributes:
     - teamId
     - sideRepresentation
     - zipCode
     - address
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'teamId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'sideRepresentation', None, None, ),  # 2
        (3, TType.STRING, 'zipCode', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'address', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'userId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'serviceName', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'token', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 9
    )
    def __init__(self, teamId=None, sideRepresentation=None, zipCode=None, address=None, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.teamId = teamId
        self.sideRepresentation = sideRepresentation
        self.zipCode = zipCode
        self.address = address
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.sideRepresentation = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamDmsFoldersMatchingLocationRequest')
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 1)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.sideRepresentation is not None:
            oprot.writeFieldBegin('sideRepresentation', TType.I32, 2)
            oprot.writeI32(self.sideRepresentation)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 3)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 4)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 5)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 6)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 7)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 8)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 9)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetTeamDmsFoldersMatchingLocationResponse(object):
    """
    Attributes:
     - status
     - folders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'folders', (TType.STRUCT, (gen.urbancompass.dms_common.dms_folder.ttypes.TeamDmsFolderMatchingLocation, gen.urbancompass.dms_common.dms_folder.ttypes.TeamDmsFolderMatchingLocation.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, folders=None, ):
        self.status = status
        self.folders = folders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.folders = []
                    (_etype407, _size410) = iprot.readListBegin()
                    for _i408 in range(_size410):
                        _elem409 = gen.urbancompass.dms_common.dms_folder.ttypes.TeamDmsFolderMatchingLocation()
                        _elem409.read(iprot)
                        self.folders.append(_elem409)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetTeamDmsFoldersMatchingLocationResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.folders is not None:
            oprot.writeFieldBegin('folders', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.folders))
            for _iter411 in self.folders:
                _iter411.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetUserRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetUserRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetWithdrawnDMSListingsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetWithdrawnDMSListingsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetWithdrawnDMSListingsResponse(object):
    """
    Attributes:
     - status
     - withdrawnListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'withdrawnListings', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.WithdrawnDMSListing, gen.urbancompass.dms_translation_model.ttypes.WithdrawnDMSListing.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, withdrawnListings=None, ):
        self.status = status
        self.withdrawnListings = withdrawnListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.withdrawnListings = []
                    (_etype412, _size415) = iprot.readListBegin()
                    for _i413 in range(_size415):
                        _elem414 = gen.urbancompass.dms_translation_model.ttypes.WithdrawnDMSListing()
                        _elem414.read(iprot)
                        self.withdrawnListings.append(_elem414)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetWithdrawnDMSListingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.withdrawnListings is not None:
            oprot.writeFieldBegin('withdrawnListings', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.withdrawnListings))
            for _iter416 in self.withdrawnListings:
                _iter416.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListDMSFoldersRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListDMSFoldersRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListDMSFoldersResponse(object):
    """
    Attributes:
     - status
     - dmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderIds=None, ):
        self.status = status
        self.dmsFolderIds = dmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype417, _size420) = iprot.readListBegin()
                    for _i418 in range(_size420):
                        _elem419 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem419)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListDMSFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter421 in self.dmsFolderIds:
                oprot.writeString(_iter421.encode('utf-8') if sys.version_info[0] == 2 else _iter421)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListGlideDocsRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - userEmail
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'userEmail', 'UTF8', None, ),  # 7
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, userEmail=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.userEmail = userEmail

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.userEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListGlideDocsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userEmail is not None:
            oprot.writeFieldBegin('userEmail', TType.STRING, 7)
            oprot.writeString(self.userEmail.encode('utf-8') if sys.version_info[0] == 2 else self.userEmail)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListGlideDocsResponse(object):
    """
    Attributes:
     - status
     - glideDocs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'glideDocs', (TType.STRUCT, (gen.urbancompass.dms_common.dms_glide.ttypes.GlideDocMeta, gen.urbancompass.dms_common.dms_glide.ttypes.GlideDocMeta.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, glideDocs=None, ):
        self.status = status
        self.glideDocs = glideDocs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.glideDocs = []
                    (_etype422, _size425) = iprot.readListBegin()
                    for _i423 in range(_size425):
                        _elem424 = gen.urbancompass.dms_common.dms_glide.ttypes.GlideDocMeta()
                        _elem424.read(iprot)
                        self.glideDocs.append(_elem424)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListGlideDocsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.glideDocs is not None:
            oprot.writeFieldBegin('glideDocs', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.glideDocs))
            for _iter426 in self.glideDocs:
                _iter426.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RemoveDocumentRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - id
     - checklistItemId
     - dmsFolderId
     - stage
     - dmsListingId
     - dmsTransactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'id', 'UTF8', None, ),  # 6
        (7, TType.I32, 'checklistItemId', None, None, ),  # 7
        (8, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'stage', None, None, ),  # 9
        (10, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 11
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, id=None, checklistItemId=None, dmsFolderId=None, stage=None, dmsListingId=None, dmsTransactionId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.id = id
        self.checklistItemId = checklistItemId
        self.dmsFolderId = dmsFolderId
        self.stage = stage
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RemoveDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 6)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 7)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 8)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 9)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 10)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 11)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RemoveDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RemoveDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReviewDocumentRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - documentId
     - reviewStatus
     - note
     - dmsFolderId
     - stage
     - checklistItemId
     - dmsListingId
     - dmsTransactionId
     - checklistItemNoteRole
     - checklistItemNoteType
     - noteCreatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'documentId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'reviewStatus', None, None, ),  # 7
        (8, TType.STRING, 'note', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 9
        (10, TType.I32, 'stage', None, None, ),  # 10
        (11, TType.I32, 'checklistItemId', None, None, ),  # 11
        (12, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 13
        (14, TType.I32, 'checklistItemNoteRole', None, None, ),  # 14
        (15, TType.I32, 'checklistItemNoteType', None, None, ),  # 15
        (16, TType.I64, 'noteCreatedAt', None, None, ),  # 16
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, documentId=None, reviewStatus=None, note=None, dmsFolderId=None, stage=None, checklistItemId=None, dmsListingId=None, dmsTransactionId=None, checklistItemNoteRole=None, checklistItemNoteType=None, noteCreatedAt=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.documentId = documentId
        self.reviewStatus = reviewStatus
        self.note = note
        self.dmsFolderId = dmsFolderId
        self.stage = stage
        self.checklistItemId = checklistItemId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.checklistItemNoteRole = checklistItemNoteRole
        self.checklistItemNoteType = checklistItemNoteType
        self.noteCreatedAt = noteCreatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.reviewStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.checklistItemNoteRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.checklistItemNoteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I64:
                    self.noteCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReviewDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 6)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.reviewStatus is not None:
            oprot.writeFieldBegin('reviewStatus', TType.I32, 7)
            oprot.writeI32(self.reviewStatus)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 8)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 9)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 10)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 11)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 12)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 13)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.checklistItemNoteRole is not None:
            oprot.writeFieldBegin('checklistItemNoteRole', TType.I32, 14)
            oprot.writeI32(self.checklistItemNoteRole)
            oprot.writeFieldEnd()
        if self.checklistItemNoteType is not None:
            oprot.writeFieldBegin('checklistItemNoteType', TType.I32, 15)
            oprot.writeI32(self.checklistItemNoteType)
            oprot.writeFieldEnd()
        if self.noteCreatedAt is not None:
            oprot.writeFieldBegin('noteCreatedAt', TType.I64, 16)
            oprot.writeI64(self.noteCreatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReviewDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReviewDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShareDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - grantorId
     - granteeId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'grantorId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'granteeId', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, grantorId=None, granteeId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.grantorId = grantorId
        self.granteeId = granteeId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.grantorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.granteeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShareDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.grantorId is not None:
            oprot.writeFieldBegin('grantorId', TType.STRING, 7)
            oprot.writeString(self.grantorId.encode('utf-8') if sys.version_info[0] == 2 else self.grantorId)
            oprot.writeFieldEnd()
        if self.granteeId is not None:
            oprot.writeFieldBegin('granteeId', TType.STRING, 8)
            oprot.writeString(self.granteeId.encode('utf-8') if sys.version_info[0] == 2 else self.granteeId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ShareDMSFolderResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ShareDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SortDmsFoldersRequest(object):
    """
    Attributes:
     - dmsFolderIds
     - dmsFolderSortingOption
     - descending
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'dmsFolderSortingOption', None, None, ),  # 2
        (3, TType.BOOL, 'descending', None, None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'serviceName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'token', 'UTF8', None, ),  # 7
        (8, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 8
    )
    def __init__(self, dmsFolderIds=None, dmsFolderSortingOption=None, descending=None, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.dmsFolderIds = dmsFolderIds
        self.dmsFolderSortingOption = dmsFolderSortingOption
        self.descending = descending
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype427, _size430) = iprot.readListBegin()
                    for _i428 in range(_size430):
                        _elem429 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem429)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dmsFolderSortingOption = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.descending = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SortDmsFoldersRequest')
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter431 in self.dmsFolderIds:
                oprot.writeString(_iter431.encode('utf-8') if sys.version_info[0] == 2 else _iter431)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsFolderSortingOption is not None:
            oprot.writeFieldBegin('dmsFolderSortingOption', TType.I32, 2)
            oprot.writeI32(self.dmsFolderSortingOption)
            oprot.writeFieldEnd()
        if self.descending is not None:
            oprot.writeFieldBegin('descending', TType.BOOL, 3)
            oprot.writeBool(self.descending)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 5)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 6)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 7)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 8)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SortDmsFoldersResponse(object):
    """
    Attributes:
     - status
     - dmsFolderIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'dmsFolderIds', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, dmsFolderIds=None, ):
        self.status = status
        self.dmsFolderIds = dmsFolderIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsFolderIds = []
                    (_etype432, _size435) = iprot.readListBegin()
                    for _i433 in range(_size435):
                        _elem434 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.dmsFolderIds.append(_elem434)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SortDmsFoldersResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderIds is not None:
            oprot.writeFieldBegin('dmsFolderIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.dmsFolderIds))
            for _iter436 in self.dmsFolderIds:
                oprot.writeString(_iter436.encode('utf-8') if sys.version_info[0] == 2 else _iter436)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SplitDocumentRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - documentId
     - checklistIdToPages
     - dmsFolderId
     - stage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'documentId', 'UTF8', None, ),  # 6
        (7, TType.MAP, 'checklistIdToPages', (TType.I32, None, TType.STRUCT, (gen.urbancompass.dms_document.ttypes.PageInterval, gen.urbancompass.dms_document.ttypes.PageInterval.thrift_spec), False), None, ),  # 7
        (8, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'stage', None, None, ),  # 9
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, documentId=None, checklistIdToPages=None, dmsFolderId=None, stage=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.documentId = documentId
        self.checklistIdToPages = checklistIdToPages
        self.dmsFolderId = dmsFolderId
        self.stage = stage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.MAP:
                    self.checklistIdToPages = {}
                    (_ktype438, _vtype439, _size442) = iprot.readMapBegin()
                    for _i437 in range(_size442):
                        _key440 = iprot.readI32()
                        _val441 = gen.urbancompass.dms_document.ttypes.PageInterval()
                        _val441.read(iprot)
                        self.checklistIdToPages[_key440] = _val441
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SplitDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 6)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.checklistIdToPages is not None:
            oprot.writeFieldBegin('checklistIdToPages', TType.MAP, 7)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.checklistIdToPages))
            for _kiter443, _viter444 in self.checklistIdToPages.items():
                oprot.writeI32(_kiter443)
                _viter444.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 8)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 9)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SplitDocumentResponse(object):
    """
    Attributes:
     - status
     - checklistIdtoDocumentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'checklistIdtoDocumentId', (TType.I32, None, TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, status=None, checklistIdtoDocumentId=None, ):
        self.status = status
        self.checklistIdtoDocumentId = checklistIdtoDocumentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.checklistIdtoDocumentId = {}
                    (_ktype446, _vtype447, _size450) = iprot.readMapBegin()
                    for _i445 in range(_size450):
                        _key448 = iprot.readI32()
                        _val449 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.checklistIdtoDocumentId[_key448] = _val449
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SplitDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.checklistIdtoDocumentId is not None:
            oprot.writeFieldBegin('checklistIdtoDocumentId', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.STRING, len(self.checklistIdtoDocumentId))
            for _kiter451, _viter452 in self.checklistIdtoDocumentId.items():
                oprot.writeI32(_kiter451)
                oprot.writeString(_viter452.encode('utf-8') if sys.version_info[0] == 2 else _viter452)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnClaimDealRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnClaimDealRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnClaimDealResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnClaimDealResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnshareDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - grantorId
     - granteeId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'grantorId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'granteeId', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, grantorId=None, granteeId=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.grantorId = grantorId
        self.granteeId = granteeId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.grantorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.granteeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnshareDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.grantorId is not None:
            oprot.writeFieldBegin('grantorId', TType.STRING, 7)
            oprot.writeString(self.grantorId.encode('utf-8') if sys.version_info[0] == 2 else self.grantorId)
            oprot.writeFieldEnd()
        if self.granteeId is not None:
            oprot.writeFieldBegin('granteeId', TType.STRING, 8)
            oprot.writeString(self.granteeId.encode('utf-8') if sys.version_info[0] == 2 else self.granteeId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UnshareDMSFolderResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UnshareDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateChecklistItemRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - checklistItem
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'checklistItem', (gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem, gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem.thrift_spec), None, ),  # 9
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, checklistItem=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.checklistItem = checklistItem

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.checklistItem = gen.urbancompass.dms_translation_model.ttypes.DmsChecklistItem()
                    self.checklistItem.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateChecklistItemRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 7)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 8)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.checklistItem is not None:
            oprot.writeFieldBegin('checklistItem', TType.STRUCT, 9)
            self.checklistItem.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateChecklistItemResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateChecklistItemResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateClosingRequest(object):
    """
    Attributes:
     - dmsFolderId
     - userId
     - impersonatorId
     - closingRequest
     - serviceName
     - token
     - signature
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'closingRequest', (gen.urbancompass.closings.closings_service.ttypes.ClosingRequest, gen.urbancompass.closings.closings_service.ttypes.ClosingRequest.thrift_spec), None, ),  # 4
        (5, TType.STRING, 'serviceName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'token', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 7
    )
    def __init__(self, dmsFolderId=None, userId=None, impersonatorId=None, closingRequest=None, serviceName=None, token=None, signature=None, ):
        self.dmsFolderId = dmsFolderId
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.closingRequest = closingRequest
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.closingRequest = gen.urbancompass.closings.closings_service.ttypes.ClosingRequest()
                    self.closingRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateClosingRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 3)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.closingRequest is not None:
            oprot.writeFieldBegin('closingRequest', TType.STRUCT, 4)
            self.closingRequest.write(oprot)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 5)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 6)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 7)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSFolderRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - folderFieldsToUpdate
     - listingType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'folderFieldsToUpdate', (gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt, gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt.thrift_spec), None, ),  # 7
        (8, TType.I32, 'listingType', None, None, ),  # 8
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, folderFieldsToUpdate=None, listingType=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.folderFieldsToUpdate = folderFieldsToUpdate
        self.listingType = listingType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.folderFieldsToUpdate = gen.urbancompass.dms_translation_model.ttypes.DmsFolderExt()
                    self.folderFieldsToUpdate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSFolderRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.folderFieldsToUpdate is not None:
            oprot.writeFieldBegin('folderFieldsToUpdate', TType.STRUCT, 7)
            self.folderFieldsToUpdate.write(oprot)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 8)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSFolderResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSFolderResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - team
     - serviceName
     - token
     - signature
     - dmsListingId
     - dmsFolderId
     - dealListingId
     - propertyType
     - listingType
     - propertyAddress
     - unit
     - city
     - state
     - market
     - zipcode
     - listPrice
     - yearBuilt
     - usedConcierge
     - mediaUrl
     - expirationDate
     - yearlyRent
     - listingId
     - isNewConstruction
     - listDate
     - dmsAgents
     - mlsId
     - doNotCallLDFS
     - commissionRate
     - otherSideCommissionRate
     - submitStatus
     - fieldsToReset
     - isFullServiceRental
     - isHousingVoucher
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'propertyType', None, None, ),  # 9
        (10, TType.I32, 'listingType', None, None, ),  # 10
        (11, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'unit', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'city', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'state', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'zipcode', 'UTF8', None, ),  # 15
        (16, TType.DOUBLE, 'listPrice', None, None, ),  # 16
        (17, TType.I32, 'yearBuilt', None, None, ),  # 17
        (18, TType.STRING, 'team', 'UTF8', None, ),  # 18
        (19, TType.BOOL, 'usedConcierge', None, None, ),  # 19
        (20, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'expirationDate', 'UTF8', None, ),  # 21
        (22, TType.DOUBLE, 'yearlyRent', None, None, ),  # 22
        (23, TType.STRING, 'listingId', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'market', 'UTF8', None, ),  # 24
        (25, TType.BOOL, 'isNewConstruction', None, None, ),  # 25
        (26, TType.STRING, 'listDate', 'UTF8', None, ),  # 26
        (27, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 27
        (28, TType.STRING, 'mlsId', 'UTF8', None, ),  # 28
        (29, TType.BOOL, 'doNotCallLDFS', None, None, ),  # 29
        (30, TType.STRUCT, 'commissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 30
        (31, TType.STRUCT, 'otherSideCommissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 31
        (32, TType.I32, 'submitStatus', None, None, ),  # 32
        (33, TType.SET, 'fieldsToReset', (TType.STRING, 'UTF8', False), None, ),  # 33
        (34, TType.BOOL, 'isFullServiceRental', None, None, ),  # 34
        (35, TType.BOOL, 'isHousingVoucher', None, None, ),  # 35
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsListingId=None, dmsFolderId=None, dealListingId=None, propertyType=None, listingType=None, propertyAddress=None, unit=None, city=None, state=None, zipcode=None, listPrice=None, yearBuilt=None, team=None, usedConcierge=None, mediaUrl=None, expirationDate=None, yearlyRent=None, listingId=None, market=None, isNewConstruction=None, listDate=None, dmsAgents=None, mlsId=None, doNotCallLDFS=None, commissionRate=None, otherSideCommissionRate=None, submitStatus=None, fieldsToReset=None, isFullServiceRental=None, isHousingVoucher=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsListingId = dmsListingId
        self.dmsFolderId = dmsFolderId
        self.dealListingId = dealListingId
        self.propertyType = propertyType
        self.listingType = listingType
        self.propertyAddress = propertyAddress
        self.unit = unit
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.yearBuilt = yearBuilt
        self.team = team
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.expirationDate = expirationDate
        self.yearlyRent = yearlyRent
        self.listingId = listingId
        self.market = market
        self.isNewConstruction = isNewConstruction
        self.listDate = listDate
        self.dmsAgents = dmsAgents
        self.mlsId = mlsId
        self.doNotCallLDFS = doNotCallLDFS
        self.commissionRate = commissionRate
        self.otherSideCommissionRate = otherSideCommissionRate
        self.submitStatus = submitStatus
        self.fieldsToReset = fieldsToReset
        self.isFullServiceRental = isFullServiceRental
        self.isHousingVoucher = isHousingVoucher

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.expirationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.DOUBLE:
                    self.yearlyRent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.listDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype453, _size456) = iprot.readListBegin()
                    for _i454 in range(_size456):
                        _elem455 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem455.read(iprot)
                        self.dmsAgents.append(_elem455)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.BOOL:
                    self.doNotCallLDFS = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.commissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.commissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRUCT:
                    self.otherSideCommissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.otherSideCommissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.SET:
                    self.fieldsToReset = set()
                    (_etype458, _size460) = iprot.readSetBegin()
                    for _i457 in range(_size460):
                        _elem459 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fieldsToReset.add(_elem459)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.BOOL:
                    self.isFullServiceRental = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.BOOL:
                    self.isHousingVoucher = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 6)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 8)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 9)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 10)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 11)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 12)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 13)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 14)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 15)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 16)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 17)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 18)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 19)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 20)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.STRING, 21)
            oprot.writeString(self.expirationDate.encode('utf-8') if sys.version_info[0] == 2 else self.expirationDate)
            oprot.writeFieldEnd()
        if self.yearlyRent is not None:
            oprot.writeFieldBegin('yearlyRent', TType.DOUBLE, 22)
            oprot.writeDouble(self.yearlyRent)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 23)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 24)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 25)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.STRING, 26)
            oprot.writeString(self.listDate.encode('utf-8') if sys.version_info[0] == 2 else self.listDate)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 27)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter461 in self.dmsAgents:
                _iter461.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 28)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.doNotCallLDFS is not None:
            oprot.writeFieldBegin('doNotCallLDFS', TType.BOOL, 29)
            oprot.writeBool(self.doNotCallLDFS)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.STRUCT, 30)
            self.commissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.STRUCT, 31)
            self.otherSideCommissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 32)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        if self.fieldsToReset is not None:
            oprot.writeFieldBegin('fieldsToReset', TType.SET, 33)
            oprot.writeSetBegin(TType.STRING, len(self.fieldsToReset))
            for _iter462 in self.fieldsToReset:
                oprot.writeString(_iter462.encode('utf-8') if sys.version_info[0] == 2 else _iter462)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.isFullServiceRental is not None:
            oprot.writeFieldBegin('isFullServiceRental', TType.BOOL, 34)
            oprot.writeBool(self.isFullServiceRental)
            oprot.writeFieldEnd()
        if self.isHousingVoucher is not None:
            oprot.writeFieldBegin('isHousingVoucher', TType.BOOL, 35)
            oprot.writeBool(self.isHousingVoucher)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingResponse(object):
    """
    Attributes:
     - status
     - expiresIn
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'expiresIn', None, None, ),  # 2
    )
    def __init__(self, status=None, expiresIn=None, ):
        self.status = status
        self.expiresIn = expiresIn

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 2)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingTransactionSubStageRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - currentStage
     - currentSubStage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 8
        (9, TType.I32, 'currentStage', None, None, ),  # 9
        (10, TType.I32, 'currentSubStage', None, None, ),  # 10
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, currentStage=None, currentSubStage=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingTransactionSubStageRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 7)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 8)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 9)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 10)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSListingTransactionSubStageResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSListingTransactionSubStageResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSOfferRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - dmsOffer
     - team
     - dmsContacts
     - dmsAgents
     - shouldCreateDualRepDmsFolder
     - dualRepAgent
     - fieldsToReset
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'dmsOffer', (gen.urbancompass.dms_translation_model.ttypes.DmsOffer, gen.urbancompass.dms_translation_model.ttypes.DmsOffer.thrift_spec), None, ),  # 7
        None,  # 8
        (9, TType.STRING, 'team', 'UTF8', None, ),  # 9
        (10, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 10
        (11, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 11
        (12, TType.BOOL, 'shouldCreateDualRepDmsFolder', None, None, ),  # 12
        (13, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), None, ),  # 13
        (14, TType.SET, 'fieldsToReset', (TType.STRING, 'UTF8', False), None, ),  # 14
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, dmsOffer=None, team=None, dmsContacts=None, dmsAgents=None, shouldCreateDualRepDmsFolder=None, dualRepAgent=None, fieldsToReset=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.dmsOffer = dmsOffer
        self.team = team
        self.dmsContacts = dmsContacts
        self.dmsAgents = dmsAgents
        self.shouldCreateDualRepDmsFolder = shouldCreateDualRepDmsFolder
        self.dualRepAgent = dualRepAgent
        self.fieldsToReset = fieldsToReset

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.dmsOffer = gen.urbancompass.dms_translation_model.ttypes.DmsOffer()
                    self.dmsOffer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype463, _size466) = iprot.readListBegin()
                    for _i464 in range(_size466):
                        _elem465 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem465.read(iprot)
                        self.dmsContacts.append(_elem465)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype467, _size470) = iprot.readListBegin()
                    for _i468 in range(_size470):
                        _elem469 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem469.read(iprot)
                        self.dmsAgents.append(_elem469)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.shouldCreateDualRepDmsFolder = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.SET:
                    self.fieldsToReset = set()
                    (_etype472, _size474) = iprot.readSetBegin()
                    for _i471 in range(_size474):
                        _elem473 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.fieldsToReset.add(_elem473)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSOfferRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsOffer is not None:
            oprot.writeFieldBegin('dmsOffer', TType.STRUCT, 7)
            self.dmsOffer.write(oprot)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 9)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter475 in self.dmsContacts:
                _iter475.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter476 in self.dmsAgents:
                _iter476.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.shouldCreateDualRepDmsFolder is not None:
            oprot.writeFieldBegin('shouldCreateDualRepDmsFolder', TType.BOOL, 12)
            oprot.writeBool(self.shouldCreateDualRepDmsFolder)
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 13)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.fieldsToReset is not None:
            oprot.writeFieldBegin('fieldsToReset', TType.SET, 14)
            oprot.writeSetBegin(TType.STRING, len(self.fieldsToReset))
            for _iter477 in self.fieldsToReset:
                oprot.writeString(_iter477.encode('utf-8') if sys.version_info[0] == 2 else _iter477)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDMSOfferResponse(object):
    """
    Attributes:
     - status
     - isDmsOfferComplete
     - isDmsOfferSubmitted
     - expiresIn
     - dmsContacts
     - otherSideDualRepFolderBtId
     - otherSideDualRepDmsFolderId
     - dmsAgents
     - dualRepAgent
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 2
        (3, TType.I32, 'expiresIn', None, None, ),  # 3
        (4, TType.LIST, 'dmsContacts', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsContactExt, gen.urbancompass.dms_translation_model.ttypes.DmsContactExt.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'otherSideDualRepFolderBtId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'otherSideDualRepDmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'isDmsOfferSubmitted', None, None, ),  # 7
        (8, TType.LIST, 'dmsAgents', (TType.STRUCT, (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), False), None, ),  # 8
        (9, TType.STRUCT, 'dualRepAgent', (gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt, gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt.thrift_spec), None, ),  # 9
    )
    def __init__(self, status=None, isDmsOfferComplete=None, expiresIn=None, dmsContacts=None, otherSideDualRepFolderBtId=None, otherSideDualRepDmsFolderId=None, isDmsOfferSubmitted=None, dmsAgents=None, dualRepAgent=None, ):
        self.status = status
        self.isDmsOfferComplete = isDmsOfferComplete
        self.expiresIn = expiresIn
        self.dmsContacts = dmsContacts
        self.otherSideDualRepFolderBtId = otherSideDualRepFolderBtId
        self.otherSideDualRepDmsFolderId = otherSideDualRepDmsFolderId
        self.isDmsOfferSubmitted = isDmsOfferSubmitted
        self.dmsAgents = dmsAgents
        self.dualRepAgent = dualRepAgent

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype478, _size481) = iprot.readListBegin()
                    for _i479 in range(_size481):
                        _elem480 = gen.urbancompass.dms_translation_model.ttypes.DmsContactExt()
                        _elem480.read(iprot)
                        self.dmsContacts.append(_elem480)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.otherSideDualRepFolderBtId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.otherSideDualRepDmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isDmsOfferSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype482, _size485) = iprot.readListBegin()
                    for _i483 in range(_size485):
                        _elem484 = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                        _elem484.read(iprot)
                        self.dmsAgents.append(_elem484)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.dualRepAgent = gen.urbancompass.dms_translation_model.ttypes.DmsAgentExt()
                    self.dualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDMSOfferResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 2)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 3)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter486 in self.dmsContacts:
                _iter486.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideDualRepFolderBtId is not None:
            oprot.writeFieldBegin('otherSideDualRepFolderBtId', TType.STRING, 5)
            oprot.writeString(self.otherSideDualRepFolderBtId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepFolderBtId)
            oprot.writeFieldEnd()
        if self.otherSideDualRepDmsFolderId is not None:
            oprot.writeFieldBegin('otherSideDualRepDmsFolderId', TType.STRING, 6)
            oprot.writeString(self.otherSideDualRepDmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.otherSideDualRepDmsFolderId)
            oprot.writeFieldEnd()
        if self.isDmsOfferSubmitted is not None:
            oprot.writeFieldBegin('isDmsOfferSubmitted', TType.BOOL, 7)
            oprot.writeBool(self.isDmsOfferSubmitted)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter487 in self.dmsAgents:
                _iter487.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dualRepAgent is not None:
            oprot.writeFieldBegin('dualRepAgent', TType.STRUCT, 9)
            self.dualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateReferralDetailRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - dmsFolderId
     - referredBy
     - referredTo
     - referralDetail
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'referralDetail', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail.thrift_spec), None, ),  # 9
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, dmsFolderId=None, referredBy=None, referredTo=None, referralDetail=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.dmsFolderId = dmsFolderId
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.referralDetail = referralDetail

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.referralDetail = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail()
                    self.referralDetail.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateReferralDetailRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 6)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 7)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 8)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.referralDetail is not None:
            oprot.writeFieldBegin('referralDetail', TType.STRUCT, 9)
            self.referralDetail.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateReferralDetailResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateReferralDetailResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertCustomChecklistItemByItemIdRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - itemId
     - stage
     - dmsFolderId
     - dmsListingId
     - dmsTransactionId
     - isRequired
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
        (3, TType.I32, 'stage', None, None, ),  # 3
        (4, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'isRequired', None, None, ),  # 7
        (8, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'serviceName', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'token', 'UTF8', None, ),  # 10
        (11, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 11
    )
    def __init__(self, userId=None, itemId=None, stage=None, dmsFolderId=None, dmsListingId=None, dmsTransactionId=None, isRequired=None, impersonatorId=None, serviceName=None, token=None, signature=None, ):
        self.userId = userId
        self.itemId = itemId
        self.stage = stage
        self.dmsFolderId = dmsFolderId
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.isRequired = isRequired
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertCustomChecklistItemByItemIdRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 3)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 4)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 5)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 6)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 7)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 8)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 9)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 10)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 11)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertCustomChecklistItemByItemIdResponse(object):
    """
    Attributes:
     - status
     - itemId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'itemId', None, None, ),  # 2
    )
    def __init__(self, status=None, itemId=None, ):
        self.status = status
        self.itemId = itemId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.itemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertCustomChecklistItemByItemIdResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.itemId is not None:
            oprot.writeFieldBegin('itemId', TType.I32, 2)
            oprot.writeI32(self.itemId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertDocumentRequest(object):
    """
    Attributes:
     - userId
     - impersonatorId
     - serviceName
     - token
     - signature
     - teamId
     - dmsFolderId
     - dmsTransactionId
     - dmsListingId
     - dmsChecklistIds
     - stage
     - data
     - mimeType
     - filename
     - md5sum
     - glideUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'serviceName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'token', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'teamId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 7
        (8, TType.LIST, 'dmsChecklistIds', (TType.I32, None, False), None, ),  # 8
        (9, TType.I32, 'stage', None, None, ),  # 9
        (10, TType.STRING, 'data', 'BINARY', None, ),  # 10
        (11, TType.STRING, 'mimeType', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'filename', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'md5sum', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'glideUrl', 'UTF8', None, ),  # 16
    )
    def __init__(self, userId=None, impersonatorId=None, serviceName=None, token=None, signature=None, teamId=None, dmsFolderId=None, dmsChecklistIds=None, stage=None, data=None, mimeType=None, filename=None, md5sum=None, dmsTransactionId=None, dmsListingId=None, glideUrl=None, ):
        self.userId = userId
        self.impersonatorId = impersonatorId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.teamId = teamId
        self.dmsFolderId = dmsFolderId
        self.dmsChecklistIds = dmsChecklistIds
        self.stage = stage
        self.data = data
        self.mimeType = mimeType
        self.filename = filename
        self.md5sum = md5sum
        self.dmsTransactionId = dmsTransactionId
        self.dmsListingId = dmsListingId
        self.glideUrl = glideUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.dmsChecklistIds = []
                    (_etype488, _size491) = iprot.readListBegin()
                    for _i489 in range(_size491):
                        _elem490 = iprot.readI32()
                        self.dmsChecklistIds.append(_elem490)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.data = iprot.readBinary()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.mimeType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.filename = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.md5sum = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.glideUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertDocumentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 3)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 4)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 5)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 6)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 7)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsChecklistIds is not None:
            oprot.writeFieldBegin('dmsChecklistIds', TType.LIST, 8)
            oprot.writeListBegin(TType.I32, len(self.dmsChecklistIds))
            for _iter492 in self.dmsChecklistIds:
                oprot.writeI32(_iter492)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 9)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 10)
            oprot.writeBinary(self.data)
            oprot.writeFieldEnd()
        if self.mimeType is not None:
            oprot.writeFieldBegin('mimeType', TType.STRING, 11)
            oprot.writeString(self.mimeType.encode('utf-8') if sys.version_info[0] == 2 else self.mimeType)
            oprot.writeFieldEnd()
        if self.filename is not None:
            oprot.writeFieldBegin('filename', TType.STRING, 12)
            oprot.writeString(self.filename.encode('utf-8') if sys.version_info[0] == 2 else self.filename)
            oprot.writeFieldEnd()
        if self.md5sum is not None:
            oprot.writeFieldBegin('md5sum', TType.STRING, 13)
            oprot.writeString(self.md5sum.encode('utf-8') if sys.version_info[0] == 2 else self.md5sum)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 14)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 15)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.glideUrl is not None:
            oprot.writeFieldBegin('glideUrl', TType.STRING, 16)
            oprot.writeString(self.glideUrl.encode('utf-8') if sys.version_info[0] == 2 else self.glideUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpsertDocumentResponse(object):
    """
    Attributes:
     - status
     - documentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
    )
    def __init__(self, status=None, documentId=None, ):
        self.status = status
        self.documentId = documentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpsertDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ValidateOneFieldRequest(object):
    """
    Attributes:
     - dmsFolderId
     - impersonatorId
     - userId
     - serviceName
     - token
     - signature
     - createdAt
     - updatedAt
     - contractGrossAmount
     - closeDate
     - address
     - sideRepresented
     - listingType
     - status
     - brokerFee
     - isCompassLead
     - propertyType
     - fees
     - offMarketListing
     - allocations
     - notes
     - withExternalBroker
     - externalBrokerageName
     - externalBrokerName
     - externalBrokerEmail
     - submittedAt
     - agentName
     - listingIdSHA
     - files
     - agentSplitOverridePercent
     - agentSplitOverrideNotes
     - agentSplitOverrideReason
     - agentMasterDataId
     - zipCode
     - teamId
     - submittedById
     - submittedByName
     - submittedByAgentMasterDataId
     - notesForPrincipal
     - city
     - state
     - url
     - passThroughFees
     - ownerPaysBrokerFee
     - cdaType
     - netsuiteId
     - netsuiteStatus
     - netsuiteLastCheckedAt
     - fieldName
     - role
     - requireDocuments
     - GrossCommissionIncome
     - NetCommissionIncome
     - NetCommissionRemainingPercent
     - NetCommissionRemainingAmount
     - frontEndVersion
     - agentSplitAmount
     - compassTeamId
     - documentsRequired
     - email
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'impersonatorId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'serviceName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'token', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'signature', (gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature, gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature.thrift_spec), None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'updatedAt', None, None, ),  # 8
        (9, TType.DOUBLE, 'contractGrossAmount', None, None, ),  # 9
        (10, TType.STRING, 'closeDate', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'address', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'sideRepresented', 'UTF8', None, ),  # 12
        (13, TType.I32, 'listingType', None, None, ),  # 13
        (14, TType.I32, 'status', None, None, ),  # 14
        (15, TType.STRUCT, 'brokerFee', (gen.urbancompass.closings.closings_service.ttypes.PercentOrAmount, gen.urbancompass.closings.closings_service.ttypes.PercentOrAmount.thrift_spec), None, ),  # 15
        (16, TType.BOOL, 'isCompassLead', None, None, ),  # 16
        (17, TType.I32, 'propertyType', None, None, ),  # 17
        (18, TType.LIST, 'fees', (TType.STRUCT, (gen.urbancompass.closings.closings_service.ttypes.Fee, gen.urbancompass.closings.closings_service.ttypes.Fee.thrift_spec), False), None, ),  # 18
        (19, TType.BOOL, 'offMarketListing', None, None, ),  # 19
        (20, TType.LIST, 'allocations', (TType.STRUCT, (gen.urbancompass.closings.closings_service.ttypes.Allocation, gen.urbancompass.closings.closings_service.ttypes.Allocation.thrift_spec), False), None, ),  # 20
        (21, TType.STRING, 'notes', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'withExternalBroker', None, None, ),  # 22
        (23, TType.STRING, 'externalBrokerageName', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'externalBrokerName', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'externalBrokerEmail', 'UTF8', None, ),  # 25
        (26, TType.I64, 'submittedAt', None, None, ),  # 26
        None,  # 27
        (28, TType.STRING, 'agentName', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 29
        (30, TType.LIST, 'files', (TType.STRUCT, (gen.urbancompass.closings.closings_service.ttypes.File, gen.urbancompass.closings.closings_service.ttypes.File.thrift_spec), False), None, ),  # 30
        (31, TType.DOUBLE, 'agentSplitOverridePercent', None, None, ),  # 31
        (32, TType.STRING, 'agentSplitOverrideNotes', 'UTF8', None, ),  # 32
        (33, TType.I32, 'agentSplitOverrideReason', None, None, ),  # 33
        (34, TType.STRING, 'agentMasterDataId', 'UTF8', None, ),  # 34
        (35, TType.STRING, 'zipCode', 'UTF8', None, ),  # 35
        (36, TType.STRING, 'teamId', 'UTF8', None, ),  # 36
        (37, TType.STRING, 'submittedById', 'UTF8', None, ),  # 37
        (38, TType.STRING, 'submittedByName', 'UTF8', None, ),  # 38
        (39, TType.STRING, 'submittedByAgentMasterDataId', 'UTF8', None, ),  # 39
        (40, TType.STRING, 'notesForPrincipal', 'UTF8', None, ),  # 40
        (41, TType.STRING, 'city', 'UTF8', None, ),  # 41
        (42, TType.STRING, 'state', 'UTF8', None, ),  # 42
        (43, TType.STRING, 'url', 'UTF8', None, ),  # 43
        (44, TType.LIST, 'passThroughFees', (TType.STRUCT, (gen.urbancompass.closings.closings_service.ttypes.PassThroughFee, gen.urbancompass.closings.closings_service.ttypes.PassThroughFee.thrift_spec), False), None, ),  # 44
        (45, TType.BOOL, 'ownerPaysBrokerFee', None, None, ),  # 45
        (46, TType.I32, 'cdaType', None, None, ),  # 46
        (47, TType.STRING, 'netsuiteId', 'UTF8', None, ),  # 47
        (48, TType.STRING, 'netsuiteStatus', 'UTF8', None, ),  # 48
        (49, TType.I64, 'netsuiteLastCheckedAt', None, None, ),  # 49
        (50, TType.STRING, 'fieldName', 'UTF8', None, ),  # 50
        (51, TType.STRING, 'role', 'UTF8', None, ),  # 51
        (52, TType.BOOL, 'requireDocuments', None, None, ),  # 52
        (53, TType.DOUBLE, 'GrossCommissionIncome', None, None, ),  # 53
        (54, TType.DOUBLE, 'NetCommissionIncome', None, None, ),  # 54
        (55, TType.DOUBLE, 'NetCommissionRemainingPercent', None, None, ),  # 55
        (56, TType.DOUBLE, 'NetCommissionRemainingAmount', None, None, ),  # 56
        (57, TType.I32, 'frontEndVersion', None, None, ),  # 57
        (58, TType.DOUBLE, 'agentSplitAmount', None, None, ),  # 58
        (59, TType.STRING, 'compassTeamId', 'UTF8', None, ),  # 59
        (60, TType.LIST, 'documentsRequired', (TType.STRING, 'UTF8', False), None, ),  # 60
        (61, TType.STRING, 'email', 'UTF8', None, ),  # 61
    )
    def __init__(self, dmsFolderId=None, impersonatorId=None, userId=None, serviceName=None, token=None, signature=None, createdAt=None, updatedAt=None, contractGrossAmount=None, closeDate=None, address=None, sideRepresented=None, listingType=None, status=None, brokerFee=None, isCompassLead=None, propertyType=None, fees=None, offMarketListing=None, allocations=None, notes=None, withExternalBroker=None, externalBrokerageName=None, externalBrokerName=None, externalBrokerEmail=None, submittedAt=None, agentName=None, listingIdSHA=None, files=None, agentSplitOverridePercent=None, agentSplitOverrideNotes=None, agentSplitOverrideReason=None, agentMasterDataId=None, zipCode=None, teamId=None, submittedById=None, submittedByName=None, submittedByAgentMasterDataId=None, notesForPrincipal=None, city=None, state=None, url=None, passThroughFees=None, ownerPaysBrokerFee=None, cdaType=None, netsuiteId=None, netsuiteStatus=None, netsuiteLastCheckedAt=None, fieldName=None, role=None, requireDocuments=None, GrossCommissionIncome=None, NetCommissionIncome=None, NetCommissionRemainingPercent=None, NetCommissionRemainingAmount=None, frontEndVersion=None, agentSplitAmount=None, compassTeamId=None, documentsRequired=None, email=None, ):
        self.dmsFolderId = dmsFolderId
        self.impersonatorId = impersonatorId
        self.userId = userId
        self.serviceName = serviceName
        self.token = token
        self.signature = signature
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.contractGrossAmount = contractGrossAmount
        self.closeDate = closeDate
        self.address = address
        self.sideRepresented = sideRepresented
        self.listingType = listingType
        self.status = status
        self.brokerFee = brokerFee
        self.isCompassLead = isCompassLead
        self.propertyType = propertyType
        self.fees = fees
        self.offMarketListing = offMarketListing
        self.allocations = allocations
        self.notes = notes
        self.withExternalBroker = withExternalBroker
        self.externalBrokerageName = externalBrokerageName
        self.externalBrokerName = externalBrokerName
        self.externalBrokerEmail = externalBrokerEmail
        self.submittedAt = submittedAt
        self.agentName = agentName
        self.listingIdSHA = listingIdSHA
        self.files = files
        self.agentSplitOverridePercent = agentSplitOverridePercent
        self.agentSplitOverrideNotes = agentSplitOverrideNotes
        self.agentSplitOverrideReason = agentSplitOverrideReason
        self.agentMasterDataId = agentMasterDataId
        self.zipCode = zipCode
        self.teamId = teamId
        self.submittedById = submittedById
        self.submittedByName = submittedByName
        self.submittedByAgentMasterDataId = submittedByAgentMasterDataId
        self.notesForPrincipal = notesForPrincipal
        self.city = city
        self.state = state
        self.url = url
        self.passThroughFees = passThroughFees
        self.ownerPaysBrokerFee = ownerPaysBrokerFee
        self.cdaType = cdaType
        self.netsuiteId = netsuiteId
        self.netsuiteStatus = netsuiteStatus
        self.netsuiteLastCheckedAt = netsuiteLastCheckedAt
        self.fieldName = fieldName
        self.role = role
        self.requireDocuments = requireDocuments
        self.GrossCommissionIncome = GrossCommissionIncome
        self.NetCommissionIncome = NetCommissionIncome
        self.NetCommissionRemainingPercent = NetCommissionRemainingPercent
        self.NetCommissionRemainingAmount = NetCommissionRemainingAmount
        self.frontEndVersion = frontEndVersion
        self.agentSplitAmount = agentSplitAmount
        self.compassTeamId = compassTeamId
        self.documentsRequired = documentsRequired
        self.email = email

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.impersonatorId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.serviceName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.token = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.signature = gen.urbancompass.agent_finance_center.agent_finance.ttypes.Signature()
                    self.signature.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.DOUBLE:
                    self.contractGrossAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.sideRepresented = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.brokerFee = gen.urbancompass.closings.closings_service.ttypes.PercentOrAmount()
                    self.brokerFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.isCompassLead = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype493, _size496) = iprot.readListBegin()
                    for _i494 in range(_size496):
                        _elem495 = gen.urbancompass.closings.closings_service.ttypes.Fee()
                        _elem495.read(iprot)
                        self.fees.append(_elem495)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.offMarketListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.allocations = []
                    (_etype497, _size500) = iprot.readListBegin()
                    for _i498 in range(_size500):
                        _elem499 = gen.urbancompass.closings.closings_service.ttypes.Allocation()
                        _elem499.read(iprot)
                        self.allocations.append(_elem499)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.withExternalBroker = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.externalBrokerageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.externalBrokerName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.externalBrokerEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I64:
                    self.submittedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.LIST:
                    self.files = []
                    (_etype501, _size504) = iprot.readListBegin()
                    for _i502 in range(_size504):
                        _elem503 = gen.urbancompass.closings.closings_service.ttypes.File()
                        _elem503.read(iprot)
                        self.files.append(_elem503)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.DOUBLE:
                    self.agentSplitOverridePercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.agentSplitOverrideNotes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I32:
                    self.agentSplitOverrideReason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRING:
                    self.agentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.STRING:
                    self.submittedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRING:
                    self.submittedByName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.STRING:
                    self.submittedByAgentMasterDataId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.notesForPrincipal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.LIST:
                    self.passThroughFees = []
                    (_etype505, _size508) = iprot.readListBegin()
                    for _i506 in range(_size508):
                        _elem507 = gen.urbancompass.closings.closings_service.ttypes.PassThroughFee()
                        _elem507.read(iprot)
                        self.passThroughFees.append(_elem507)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.BOOL:
                    self.ownerPaysBrokerFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.I32:
                    self.cdaType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.STRING:
                    self.netsuiteId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.STRING:
                    self.netsuiteStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.I64:
                    self.netsuiteLastCheckedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.STRING:
                    self.fieldName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.STRING:
                    self.role = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.BOOL:
                    self.requireDocuments = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.DOUBLE:
                    self.GrossCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.DOUBLE:
                    self.NetCommissionIncome = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingPercent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.DOUBLE:
                    self.NetCommissionRemainingAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.I32:
                    self.frontEndVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.DOUBLE:
                    self.agentSplitAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.STRING:
                    self.compassTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.LIST:
                    self.documentsRequired = []
                    (_etype509, _size512) = iprot.readListBegin()
                    for _i510 in range(_size512):
                        _elem511 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.documentsRequired.append(_elem511)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ValidateOneFieldRequest')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.impersonatorId is not None:
            oprot.writeFieldBegin('impersonatorId', TType.STRING, 2)
            oprot.writeString(self.impersonatorId.encode('utf-8') if sys.version_info[0] == 2 else self.impersonatorId)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.serviceName is not None:
            oprot.writeFieldBegin('serviceName', TType.STRING, 4)
            oprot.writeString(self.serviceName.encode('utf-8') if sys.version_info[0] == 2 else self.serviceName)
            oprot.writeFieldEnd()
        if self.token is not None:
            oprot.writeFieldBegin('token', TType.STRING, 5)
            oprot.writeString(self.token.encode('utf-8') if sys.version_info[0] == 2 else self.token)
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRUCT, 6)
            self.signature.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 8)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.contractGrossAmount is not None:
            oprot.writeFieldBegin('contractGrossAmount', TType.DOUBLE, 9)
            oprot.writeDouble(self.contractGrossAmount)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 10)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 11)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.STRING, 12)
            oprot.writeString(self.sideRepresented.encode('utf-8') if sys.version_info[0] == 2 else self.sideRepresented)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 13)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 14)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.brokerFee is not None:
            oprot.writeFieldBegin('brokerFee', TType.STRUCT, 15)
            self.brokerFee.write(oprot)
            oprot.writeFieldEnd()
        if self.isCompassLead is not None:
            oprot.writeFieldBegin('isCompassLead', TType.BOOL, 16)
            oprot.writeBool(self.isCompassLead)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 17)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 18)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter513 in self.fees:
                _iter513.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.offMarketListing is not None:
            oprot.writeFieldBegin('offMarketListing', TType.BOOL, 19)
            oprot.writeBool(self.offMarketListing)
            oprot.writeFieldEnd()
        if self.allocations is not None:
            oprot.writeFieldBegin('allocations', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.allocations))
            for _iter514 in self.allocations:
                _iter514.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 21)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.withExternalBroker is not None:
            oprot.writeFieldBegin('withExternalBroker', TType.BOOL, 22)
            oprot.writeBool(self.withExternalBroker)
            oprot.writeFieldEnd()
        if self.externalBrokerageName is not None:
            oprot.writeFieldBegin('externalBrokerageName', TType.STRING, 23)
            oprot.writeString(self.externalBrokerageName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerageName)
            oprot.writeFieldEnd()
        if self.externalBrokerName is not None:
            oprot.writeFieldBegin('externalBrokerName', TType.STRING, 24)
            oprot.writeString(self.externalBrokerName.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerName)
            oprot.writeFieldEnd()
        if self.externalBrokerEmail is not None:
            oprot.writeFieldBegin('externalBrokerEmail', TType.STRING, 25)
            oprot.writeString(self.externalBrokerEmail.encode('utf-8') if sys.version_info[0] == 2 else self.externalBrokerEmail)
            oprot.writeFieldEnd()
        if self.submittedAt is not None:
            oprot.writeFieldBegin('submittedAt', TType.I64, 26)
            oprot.writeI64(self.submittedAt)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 28)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 29)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.files is not None:
            oprot.writeFieldBegin('files', TType.LIST, 30)
            oprot.writeListBegin(TType.STRUCT, len(self.files))
            for _iter515 in self.files:
                _iter515.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentSplitOverridePercent is not None:
            oprot.writeFieldBegin('agentSplitOverridePercent', TType.DOUBLE, 31)
            oprot.writeDouble(self.agentSplitOverridePercent)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideNotes is not None:
            oprot.writeFieldBegin('agentSplitOverrideNotes', TType.STRING, 32)
            oprot.writeString(self.agentSplitOverrideNotes.encode('utf-8') if sys.version_info[0] == 2 else self.agentSplitOverrideNotes)
            oprot.writeFieldEnd()
        if self.agentSplitOverrideReason is not None:
            oprot.writeFieldBegin('agentSplitOverrideReason', TType.I32, 33)
            oprot.writeI32(self.agentSplitOverrideReason)
            oprot.writeFieldEnd()
        if self.agentMasterDataId is not None:
            oprot.writeFieldBegin('agentMasterDataId', TType.STRING, 34)
            oprot.writeString(self.agentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.agentMasterDataId)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 35)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 36)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.submittedById is not None:
            oprot.writeFieldBegin('submittedById', TType.STRING, 37)
            oprot.writeString(self.submittedById.encode('utf-8') if sys.version_info[0] == 2 else self.submittedById)
            oprot.writeFieldEnd()
        if self.submittedByName is not None:
            oprot.writeFieldBegin('submittedByName', TType.STRING, 38)
            oprot.writeString(self.submittedByName.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByName)
            oprot.writeFieldEnd()
        if self.submittedByAgentMasterDataId is not None:
            oprot.writeFieldBegin('submittedByAgentMasterDataId', TType.STRING, 39)
            oprot.writeString(self.submittedByAgentMasterDataId.encode('utf-8') if sys.version_info[0] == 2 else self.submittedByAgentMasterDataId)
            oprot.writeFieldEnd()
        if self.notesForPrincipal is not None:
            oprot.writeFieldBegin('notesForPrincipal', TType.STRING, 40)
            oprot.writeString(self.notesForPrincipal.encode('utf-8') if sys.version_info[0] == 2 else self.notesForPrincipal)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 41)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 42)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 43)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.passThroughFees is not None:
            oprot.writeFieldBegin('passThroughFees', TType.LIST, 44)
            oprot.writeListBegin(TType.STRUCT, len(self.passThroughFees))
            for _iter516 in self.passThroughFees:
                _iter516.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ownerPaysBrokerFee is not None:
            oprot.writeFieldBegin('ownerPaysBrokerFee', TType.BOOL, 45)
            oprot.writeBool(self.ownerPaysBrokerFee)
            oprot.writeFieldEnd()
        if self.cdaType is not None:
            oprot.writeFieldBegin('cdaType', TType.I32, 46)
            oprot.writeI32(self.cdaType)
            oprot.writeFieldEnd()
        if self.netsuiteId is not None:
            oprot.writeFieldBegin('netsuiteId', TType.STRING, 47)
            oprot.writeString(self.netsuiteId.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteId)
            oprot.writeFieldEnd()
        if self.netsuiteStatus is not None:
            oprot.writeFieldBegin('netsuiteStatus', TType.STRING, 48)
            oprot.writeString(self.netsuiteStatus.encode('utf-8') if sys.version_info[0] == 2 else self.netsuiteStatus)
            oprot.writeFieldEnd()
        if self.netsuiteLastCheckedAt is not None:
            oprot.writeFieldBegin('netsuiteLastCheckedAt', TType.I64, 49)
            oprot.writeI64(self.netsuiteLastCheckedAt)
            oprot.writeFieldEnd()
        if self.fieldName is not None:
            oprot.writeFieldBegin('fieldName', TType.STRING, 50)
            oprot.writeString(self.fieldName.encode('utf-8') if sys.version_info[0] == 2 else self.fieldName)
            oprot.writeFieldEnd()
        if self.role is not None:
            oprot.writeFieldBegin('role', TType.STRING, 51)
            oprot.writeString(self.role.encode('utf-8') if sys.version_info[0] == 2 else self.role)
            oprot.writeFieldEnd()
        if self.requireDocuments is not None:
            oprot.writeFieldBegin('requireDocuments', TType.BOOL, 52)
            oprot.writeBool(self.requireDocuments)
            oprot.writeFieldEnd()
        if self.GrossCommissionIncome is not None:
            oprot.writeFieldBegin('GrossCommissionIncome', TType.DOUBLE, 53)
            oprot.writeDouble(self.GrossCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionIncome is not None:
            oprot.writeFieldBegin('NetCommissionIncome', TType.DOUBLE, 54)
            oprot.writeDouble(self.NetCommissionIncome)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingPercent is not None:
            oprot.writeFieldBegin('NetCommissionRemainingPercent', TType.DOUBLE, 55)
            oprot.writeDouble(self.NetCommissionRemainingPercent)
            oprot.writeFieldEnd()
        if self.NetCommissionRemainingAmount is not None:
            oprot.writeFieldBegin('NetCommissionRemainingAmount', TType.DOUBLE, 56)
            oprot.writeDouble(self.NetCommissionRemainingAmount)
            oprot.writeFieldEnd()
        if self.frontEndVersion is not None:
            oprot.writeFieldBegin('frontEndVersion', TType.I32, 57)
            oprot.writeI32(self.frontEndVersion)
            oprot.writeFieldEnd()
        if self.agentSplitAmount is not None:
            oprot.writeFieldBegin('agentSplitAmount', TType.DOUBLE, 58)
            oprot.writeDouble(self.agentSplitAmount)
            oprot.writeFieldEnd()
        if self.compassTeamId is not None:
            oprot.writeFieldBegin('compassTeamId', TType.STRING, 59)
            oprot.writeString(self.compassTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.compassTeamId)
            oprot.writeFieldEnd()
        if self.documentsRequired is not None:
            oprot.writeFieldBegin('documentsRequired', TType.LIST, 60)
            oprot.writeListBegin(TType.STRING, len(self.documentsRequired))
            for _iter517 in self.documentsRequired:
                oprot.writeString(_iter517.encode('utf-8') if sys.version_info[0] == 2 else _iter517)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 61)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetDMSFoldersOverviewExtResponse(object):
    """
    Attributes:
     - status
     - overviewOfDmsFolders
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'overviewOfDmsFolders', (TType.STRING, 'UTF8', TType.STRUCT, (GetDMSFolderOverviewResponse, GetDMSFolderOverviewResponse.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, overviewOfDmsFolders=None, ):
        self.status = status
        self.overviewOfDmsFolders = overviewOfDmsFolders

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.overviewOfDmsFolders = {}
                    (_ktype519, _vtype520, _size523) = iprot.readMapBegin()
                    for _i518 in range(_size523):
                        _key521 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val522 = GetDMSFolderOverviewResponse()
                        _val522.read(iprot)
                        self.overviewOfDmsFolders[_key521] = _val522
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetDMSFoldersOverviewExtResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.overviewOfDmsFolders is not None:
            oprot.writeFieldBegin('overviewOfDmsFolders', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.overviewOfDmsFolders))
            for _kiter524, _viter525 in self.overviewOfDmsFolders.items():
                oprot.writeString(_kiter524.encode('utf-8') if sys.version_info[0] == 2 else _kiter524)
                _viter525.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BatchGetDMSSpecificListingPageInfoResponse(object):
    """
    Attributes:
     - status
     - dmsSpecificListingPageInfos
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'dmsSpecificListingPageInfos', (TType.STRING, 'UTF8', TType.STRUCT, (GetDMSSpecificListingPageInfoResponse, GetDMSSpecificListingPageInfoResponse.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, dmsSpecificListingPageInfos=None, ):
        self.status = status
        self.dmsSpecificListingPageInfos = dmsSpecificListingPageInfos

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.dmsSpecificListingPageInfos = {}
                    (_ktype527, _vtype528, _size531) = iprot.readMapBegin()
                    for _i526 in range(_size531):
                        _key529 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val530 = GetDMSSpecificListingPageInfoResponse()
                        _val530.read(iprot)
                        self.dmsSpecificListingPageInfos[_key529] = _val530
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BatchGetDMSSpecificListingPageInfoResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsSpecificListingPageInfos is not None:
            oprot.writeFieldBegin('dmsSpecificListingPageInfos', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.dmsSpecificListingPageInfos))
            for _kiter532, _viter533 in self.dmsSpecificListingPageInfos.items():
                oprot.writeString(_kiter532.encode('utf-8') if sys.version_info[0] == 2 else _kiter532)
                _viter533.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
