
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes

from thrift.transport import TTransport


class ClosedDealType(object):
    SALE = 0
    RENTAL = 1

    _VALUES_TO_NAMES = {
        0: "SALE",
        1: "RENTAL",
    }

    _NAMES_TO_VALUES = {
        "SALE": 0,
        "RENTAL": 1,
    }


class ClosedDealsSort(object):
    PRICE_ASC = 0
    PRICE_DESC = 1
    CLOSE_DATE_ASC = 2
    CLOSE_DATE_DESC = 3

    _VALUES_TO_NAMES = {
        0: "PRICE_ASC",
        1: "PRICE_DESC",
        2: "CLOSE_DATE_ASC",
        3: "CLOSE_DATE_DESC",
    }

    _NAMES_TO_VALUES = {
        "PRICE_ASC": 0,
        "PRICE_DESC": 1,
        "CLOSE_DATE_ASC": 2,
        "CLOSE_DATE_DESC": 3,
    }


class ContactType(object):
    SELLER_AGENT = 0
    BUYER_AGENT = 1
    OTHER = 2

    _VALUES_TO_NAMES = {
        0: "SELLER_AGENT",
        1: "BUYER_AGENT",
        2: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "SELLER_AGENT": 0,
        "BUYER_AGENT": 1,
        "OTHER": 2,
    }


class DealType(object):
    BUY_AND_SELL = 0
    BUY = 1
    SELL = 2

    _VALUES_TO_NAMES = {
        0: "BUY_AND_SELL",
        1: "BUY",
        2: "SELL",
    }

    _NAMES_TO_VALUES = {
        "BUY_AND_SELL": 0,
        "BUY": 1,
        "SELL": 2,
    }


class EntityType(object):
    COMPASS_AGENT = 0
    COMPASS_TEAM = 1
    NON_COMPASS_AGENT = 2

    _VALUES_TO_NAMES = {
        0: "COMPASS_AGENT",
        1: "COMPASS_TEAM",
        2: "NON_COMPASS_AGENT",
    }

    _NAMES_TO_VALUES = {
        "COMPASS_AGENT": 0,
        "COMPASS_TEAM": 1,
        "NON_COMPASS_AGENT": 2,
    }


class ListingStatus(object):
    FOR_SALE = 0
    UNDER_CONTRACT = 1
    SOLD = 2
    OFF_MARKET = 3
    UNKNOWN = 4

    _VALUES_TO_NAMES = {
        0: "FOR_SALE",
        1: "UNDER_CONTRACT",
        2: "SOLD",
        3: "OFF_MARKET",
        4: "UNKNOWN",
    }

    _NAMES_TO_VALUES = {
        "FOR_SALE": 0,
        "UNDER_CONTRACT": 1,
        "SOLD": 2,
        "OFF_MARKET": 3,
        "UNKNOWN": 4,
    }


class OperationType(object):
    UPSERT = 0
    DELETE = 1

    _VALUES_TO_NAMES = {
        0: "UPSERT",
        1: "DELETE",
    }

    _NAMES_TO_VALUES = {
        "UPSERT": 0,
        "DELETE": 1,
    }


class Period(object):
    SIX_MONTHS = 0
    TWELVE_MONTHS = 1
    TWENTY_FOUR_MONTHS = 2

    _VALUES_TO_NAMES = {
        0: "SIX_MONTHS",
        1: "TWELVE_MONTHS",
        2: "TWENTY_FOUR_MONTHS",
    }

    _NAMES_TO_VALUES = {
        "SIX_MONTHS": 0,
        "TWELVE_MONTHS": 1,
        "TWENTY_FOUR_MONTHS": 2,
    }


class PropertyType(object):
    CO_OP = 0
    CONDO = 1
    CONDOP = 2
    LAND = 3
    MIXED_USE = 4
    MOBILE_MANUFACTURED = 5
    MULTI_FAMILY = 6
    NON_RESIDENTIAL = 7
    OTHER = 8
    RENTAL = 9
    SINGLE_FAMILY = 10
    TOWNHOUSE = 11

    _VALUES_TO_NAMES = {
        0: "CO_OP",
        1: "CONDO",
        2: "CONDOP",
        3: "LAND",
        4: "MIXED_USE",
        5: "MOBILE_MANUFACTURED",
        6: "MULTI_FAMILY",
        7: "NON_RESIDENTIAL",
        8: "OTHER",
        9: "RENTAL",
        10: "SINGLE_FAMILY",
        11: "TOWNHOUSE",
    }

    _NAMES_TO_VALUES = {
        "CO_OP": 0,
        "CONDO": 1,
        "CONDOP": 2,
        "LAND": 3,
        "MIXED_USE": 4,
        "MOBILE_MANUFACTURED": 5,
        "MULTI_FAMILY": 6,
        "NON_RESIDENTIAL": 7,
        "OTHER": 8,
        "RENTAL": 9,
        "SINGLE_FAMILY": 10,
        "TOWNHOUSE": 11,
    }


class SearchEntityType(object):
    ALL = 0
    COMPASS_ONLY = 1
    NON_COMPASS_ONLY = 2
    COMPASS_AGENTS_ONLY = 3
    AGENTS_ONLY = 4

    _VALUES_TO_NAMES = {
        0: "ALL",
        1: "COMPASS_ONLY",
        2: "NON_COMPASS_ONLY",
        3: "COMPASS_AGENTS_ONLY",
        4: "AGENTS_ONLY",
    }

    _NAMES_TO_VALUES = {
        "ALL": 0,
        "COMPASS_ONLY": 1,
        "NON_COMPASS_ONLY": 2,
        "COMPASS_AGENTS_ONLY": 3,
        "AGENTS_ONLY": 4,
    }


class SearchSortField(object):
    LAST_NAME = 0
    FIRST_NAME = 1
    LISTING_COUNT = 2

    _VALUES_TO_NAMES = {
        0: "LAST_NAME",
        1: "FIRST_NAME",
        2: "LISTING_COUNT",
    }

    _NAMES_TO_VALUES = {
        "LAST_NAME": 0,
        "FIRST_NAME": 1,
        "LISTING_COUNT": 2,
    }


class AgentTeamInfo(object):
    """
    Attributes:
     - hexID
     - name
     - avatarURL
     - memberCount
     - dealsCount
     - publicProfileUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'hexID', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'avatarURL', 'UTF8', None, ),  # 3
        (4, TType.I32, 'memberCount', None, None, ),  # 4
        (5, TType.I32, 'dealsCount', None, None, ),  # 5
        (6, TType.STRING, 'publicProfileUrl', 'UTF8', None, ),  # 6
    )
    def __init__(self, hexID=None, name=None, avatarURL=None, memberCount=None, dealsCount=None, publicProfileUrl=None, ):
        self.hexID = hexID
        self.name = name
        self.avatarURL = avatarURL
        self.memberCount = memberCount
        self.dealsCount = dealsCount
        self.publicProfileUrl = publicProfileUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.hexID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.avatarURL = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.memberCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.dealsCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.publicProfileUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentTeamInfo')
        if self.hexID is not None:
            oprot.writeFieldBegin('hexID', TType.STRING, 1)
            oprot.writeString(self.hexID.encode('utf-8') if sys.version_info[0] == 2 else self.hexID)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.avatarURL is not None:
            oprot.writeFieldBegin('avatarURL', TType.STRING, 3)
            oprot.writeString(self.avatarURL.encode('utf-8') if sys.version_info[0] == 2 else self.avatarURL)
            oprot.writeFieldEnd()
        if self.memberCount is not None:
            oprot.writeFieldBegin('memberCount', TType.I32, 4)
            oprot.writeI32(self.memberCount)
            oprot.writeFieldEnd()
        if self.dealsCount is not None:
            oprot.writeFieldBegin('dealsCount', TType.I32, 5)
            oprot.writeI32(self.dealsCount)
            oprot.writeFieldEnd()
        if self.publicProfileUrl is not None:
            oprot.writeFieldBegin('publicProfileUrl', TType.STRING, 6)
            oprot.writeString(self.publicProfileUrl.encode('utf-8') if sys.version_info[0] == 2 else self.publicProfileUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosedDealData(object):
    """
    Attributes:
     - imageUrls
     - listingType
     - bedrooms
     - bathrooms
     - contactType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'imageUrls', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'listingType', None, None, ),  # 2
        (3, TType.DOUBLE, 'bedrooms', None, None, ),  # 3
        (4, TType.DOUBLE, 'bathrooms', None, None, ),  # 4
        (5, TType.I32, 'contactType', None, None, ),  # 5
    )
    def __init__(self, imageUrls=None, listingType=None, bedrooms=None, bathrooms=None, contactType=None, ):
        self.imageUrls = imageUrls
        self.listingType = listingType
        self.bedrooms = bedrooms
        self.bathrooms = bathrooms
        self.contactType = contactType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.imageUrls = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.imageUrls.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.bedrooms = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.bathrooms = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.contactType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosedDealData')
        if self.imageUrls is not None:
            oprot.writeFieldBegin('imageUrls', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.imageUrls))
            for _iter6 in self.imageUrls:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 2)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.bedrooms is not None:
            oprot.writeFieldBegin('bedrooms', TType.DOUBLE, 3)
            oprot.writeDouble(self.bedrooms)
            oprot.writeFieldEnd()
        if self.bathrooms is not None:
            oprot.writeFieldBegin('bathrooms', TType.DOUBLE, 4)
            oprot.writeDouble(self.bathrooms)
            oprot.writeFieldEnd()
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.I32, 5)
            oprot.writeI32(self.contactType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosedDealOverrides(object):
    """
    Attributes:
     - hidePrice
     - priceOverride
     - disableLink
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'hidePrice', None, None, ),  # 1
        (2, TType.DOUBLE, 'priceOverride', None, None, ),  # 2
        (3, TType.BOOL, 'disableLink', None, None, ),  # 3
    )
    def __init__(self, hidePrice=None, priceOverride=None, disableLink=None, ):
        self.hidePrice = hidePrice
        self.priceOverride = priceOverride
        self.disableLink = disableLink

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.hidePrice = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.priceOverride = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.disableLink = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosedDealOverrides')
        if self.hidePrice is not None:
            oprot.writeFieldBegin('hidePrice', TType.BOOL, 1)
            oprot.writeBool(self.hidePrice)
            oprot.writeFieldEnd()
        if self.priceOverride is not None:
            oprot.writeFieldBegin('priceOverride', TType.DOUBLE, 2)
            oprot.writeDouble(self.priceOverride)
            oprot.writeFieldEnd()
        if self.disableLink is not None:
            oprot.writeFieldBegin('disableLink', TType.BOOL, 3)
            oprot.writeBool(self.disableLink)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosedDealWithID(object):
    """
    Attributes:
     - listingID
     - disableLink
     - hidePrice
     - priceOverride
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingID', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'disableLink', None, None, ),  # 2
        (3, TType.BOOL, 'hidePrice', None, None, ),  # 3
        (4, TType.DOUBLE, 'priceOverride', None, None, ),  # 4
    )
    def __init__(self, listingID=None, disableLink=None, hidePrice=None, priceOverride=None, ):
        self.listingID = listingID
        self.disableLink = disableLink
        self.hidePrice = hidePrice
        self.priceOverride = priceOverride

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.disableLink = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hidePrice = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.priceOverride = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosedDealWithID')
        if self.listingID is not None:
            oprot.writeFieldBegin('listingID', TType.STRING, 1)
            oprot.writeString(self.listingID.encode('utf-8') if sys.version_info[0] == 2 else self.listingID)
            oprot.writeFieldEnd()
        if self.disableLink is not None:
            oprot.writeFieldBegin('disableLink', TType.BOOL, 2)
            oprot.writeBool(self.disableLink)
            oprot.writeFieldEnd()
        if self.hidePrice is not None:
            oprot.writeFieldBegin('hidePrice', TType.BOOL, 3)
            oprot.writeBool(self.hidePrice)
            oprot.writeFieldEnd()
        if self.priceOverride is not None:
            oprot.writeFieldBegin('priceOverride', TType.DOUBLE, 4)
            oprot.writeDouble(self.priceOverride)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosedDealsAggregate(object):
    """
    Attributes:
     - count
     - meanListPrice
     - meanSoldPrice
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'count', None, None, ),  # 1
        (2, TType.DOUBLE, 'meanListPrice', None, None, ),  # 2
        (3, TType.DOUBLE, 'meanSoldPrice', None, None, ),  # 3
    )
    def __init__(self, count=None, meanListPrice=None, meanSoldPrice=None, ):
        self.count = count
        self.meanListPrice = meanListPrice
        self.meanSoldPrice = meanSoldPrice

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.meanListPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.meanSoldPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosedDealsAggregate')
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 1)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.meanListPrice is not None:
            oprot.writeFieldBegin('meanListPrice', TType.DOUBLE, 2)
            oprot.writeDouble(self.meanListPrice)
            oprot.writeFieldEnd()
        if self.meanSoldPrice is not None:
            oprot.writeFieldBegin('meanSoldPrice', TType.DOUBLE, 3)
            oprot.writeDouble(self.meanSoldPrice)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosedDealsFilters(object):
    """
    Attributes:
     - closedDealType
     - locations
     - getHiddenDeals
     - propertyTypes
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'closedDealType', None, None, ),  # 1
        (2, TType.LIST, 'locations', (TType.I32, None, False), None, ),  # 2
        (3, TType.BOOL, 'getHiddenDeals', None, None, ),  # 3
        (4, TType.LIST, 'propertyTypes', (TType.I64, None, False), None, ),  # 4
    )
    def __init__(self, closedDealType=None, locations=None, getHiddenDeals=None, propertyTypes=None, ):
        self.closedDealType = closedDealType
        self.locations = locations
        self.getHiddenDeals = getHiddenDeals
        self.propertyTypes = propertyTypes

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.closedDealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.locations = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readI32()
                        self.locations.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.getHiddenDeals = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = iprot.readI64()
                        self.propertyTypes.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosedDealsFilters')
        if self.closedDealType is not None:
            oprot.writeFieldBegin('closedDealType', TType.I32, 1)
            oprot.writeI32(self.closedDealType)
            oprot.writeFieldEnd()
        if self.locations is not None:
            oprot.writeFieldBegin('locations', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.locations))
            for _iter15 in self.locations:
                oprot.writeI32(_iter15)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.getHiddenDeals is not None:
            oprot.writeFieldBegin('getHiddenDeals', TType.BOOL, 3)
            oprot.writeBool(self.getHiddenDeals)
            oprot.writeFieldEnd()
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 4)
            oprot.writeListBegin(TType.I64, len(self.propertyTypes))
            for _iter16 in self.propertyTypes:
                oprot.writeI64(_iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class IdentifiedProcessedListing(object):
    """
    Attributes:
     - aiHexID
     - listing
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'aiHexID', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'listing', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 2
    )
    def __init__(self, aiHexID=None, listing=None, ):
        self.aiHexID = aiHexID
        self.listing = listing

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.aiHexID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listing = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.listing.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('IdentifiedProcessedListing')
        if self.aiHexID is not None:
            oprot.writeFieldBegin('aiHexID', TType.STRING, 1)
            oprot.writeString(self.aiHexID.encode('utf-8') if sys.version_info[0] == 2 else self.aiHexID)
            oprot.writeFieldEnd()
        if self.listing is not None:
            oprot.writeFieldBegin('listing', TType.STRUCT, 2)
            self.listing.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingsAggregate(object):
    """
    Attributes:
     - count
     - meanDaysOnMarket
     - meanListPrice
     - meanSoldPrice
     - meanPriceChangePercentage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'count', None, None, ),  # 1
        (2, TType.I32, 'meanDaysOnMarket', None, None, ),  # 2
        (3, TType.DOUBLE, 'meanListPrice', None, None, ),  # 3
        (4, TType.DOUBLE, 'meanSoldPrice', None, None, ),  # 4
        (5, TType.DOUBLE, 'meanPriceChangePercentage', None, None, ),  # 5
    )
    def __init__(self, count=None, meanDaysOnMarket=None, meanListPrice=None, meanSoldPrice=None, meanPriceChangePercentage=None, ):
        self.count = count
        self.meanDaysOnMarket = meanDaysOnMarket
        self.meanListPrice = meanListPrice
        self.meanSoldPrice = meanSoldPrice
        self.meanPriceChangePercentage = meanPriceChangePercentage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.meanDaysOnMarket = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.meanListPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.meanSoldPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.meanPriceChangePercentage = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingsAggregate')
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 1)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.meanDaysOnMarket is not None:
            oprot.writeFieldBegin('meanDaysOnMarket', TType.I32, 2)
            oprot.writeI32(self.meanDaysOnMarket)
            oprot.writeFieldEnd()
        if self.meanListPrice is not None:
            oprot.writeFieldBegin('meanListPrice', TType.DOUBLE, 3)
            oprot.writeDouble(self.meanListPrice)
            oprot.writeFieldEnd()
        if self.meanSoldPrice is not None:
            oprot.writeFieldBegin('meanSoldPrice', TType.DOUBLE, 4)
            oprot.writeDouble(self.meanSoldPrice)
            oprot.writeFieldEnd()
        if self.meanPriceChangePercentage is not None:
            oprot.writeFieldBegin('meanPriceChangePercentage', TType.DOUBLE, 5)
            oprot.writeDouble(self.meanPriceChangePercentage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MlsLicense(object):
    """
    Attributes:
     - mlsShortName
     - mlsAgentId
     - resoId
     - dataset
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'mlsShortName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'mlsAgentId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'resoId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'dataset', 'UTF8', None, ),  # 4
    )
    def __init__(self, mlsShortName=None, mlsAgentId=None, resoId=None, dataset=None, ):
        self.mlsShortName = mlsShortName
        self.mlsAgentId = mlsAgentId
        self.resoId = resoId
        self.dataset = dataset

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.mlsShortName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.mlsAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.resoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dataset = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MlsLicense')
        if self.mlsShortName is not None:
            oprot.writeFieldBegin('mlsShortName', TType.STRING, 1)
            oprot.writeString(self.mlsShortName.encode('utf-8') if sys.version_info[0] == 2 else self.mlsShortName)
            oprot.writeFieldEnd()
        if self.mlsAgentId is not None:
            oprot.writeFieldBegin('mlsAgentId', TType.STRING, 2)
            oprot.writeString(self.mlsAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsAgentId)
            oprot.writeFieldEnd()
        if self.resoId is not None:
            oprot.writeFieldBegin('resoId', TType.STRING, 3)
            oprot.writeString(self.resoId.encode('utf-8') if sys.version_info[0] == 2 else self.resoId)
            oprot.writeFieldEnd()
        if self.dataset is not None:
            oprot.writeFieldBegin('dataset', TType.STRING, 4)
            oprot.writeString(self.dataset.encode('utf-8') if sys.version_info[0] == 2 else self.dataset)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Office(object):
    """
    Attributes:
     - id
     - name
     - street
     - city
     - state
     - zipcode
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'street', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'city', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'state', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'zipcode', 'UTF8', None, ),  # 6
    )
    def __init__(self, id=None, name=None, street=None, city=None, state=None, zipcode=None, ):
        self.id = id
        self.name = name
        self.street = street
        self.city = city
        self.state = state
        self.zipcode = zipcode

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.street = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Office')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.street is not None:
            oprot.writeFieldBegin('street', TType.STRING, 3)
            oprot.writeString(self.street.encode('utf-8') if sys.version_info[0] == 2 else self.street)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 4)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 5)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 6)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ProfileFilters(object):
    """
    Attributes:
     - period
     - location
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'period', None, None, ),  # 1
        (2, TType.STRING, 'location', 'UTF8', None, ),  # 2
    )
    def __init__(self, period=None, location=None, ):
        self.period = period
        self.location = location

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.period = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.location = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ProfileFilters')
        if self.period is not None:
            oprot.writeFieldBegin('period', TType.I32, 1)
            oprot.writeI32(self.period)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.STRING, 2)
            oprot.writeString(self.location.encode('utf-8') if sys.version_info[0] == 2 else self.location)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchByNameFilters(object):
    """
    Attributes:
     - entityType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'entityType', None, None, ),  # 1
    )
    def __init__(self, entityType=None, ):
        self.entityType = entityType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.entityType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchByNameFilters')
        if self.entityType is not None:
            oprot.writeFieldBegin('entityType', TType.I32, 1)
            oprot.writeI32(self.entityType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchFilters(object):
    """
    Attributes:
     - propertyTypes
     - dealType
     - minListPrice
     - maxListPrice
     - entityType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'propertyTypes', (TType.I32, None, False), None, ),  # 1
        (2, TType.I32, 'dealType', None, None, ),  # 2
        (3, TType.DOUBLE, 'minListPrice', None, None, ),  # 3
        (4, TType.DOUBLE, 'maxListPrice', None, None, ),  # 4
        (5, TType.I32, 'entityType', None, None, ),  # 5
    )
    def __init__(self, propertyTypes=None, dealType=None, minListPrice=None, maxListPrice=None, entityType=None, ):
        self.propertyTypes = propertyTypes
        self.dealType = dealType
        self.minListPrice = minListPrice
        self.maxListPrice = maxListPrice
        self.entityType = entityType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.propertyTypes = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = iprot.readI32()
                        self.propertyTypes.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.minListPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.maxListPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.entityType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchFilters')
        if self.propertyTypes is not None:
            oprot.writeFieldBegin('propertyTypes', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.propertyTypes))
            for _iter21 in self.propertyTypes:
                oprot.writeI32(_iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 2)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.minListPrice is not None:
            oprot.writeFieldBegin('minListPrice', TType.DOUBLE, 3)
            oprot.writeDouble(self.minListPrice)
            oprot.writeFieldEnd()
        if self.maxListPrice is not None:
            oprot.writeFieldBegin('maxListPrice', TType.DOUBLE, 4)
            oprot.writeDouble(self.maxListPrice)
            oprot.writeFieldEnd()
        if self.entityType is not None:
            oprot.writeFieldBegin('entityType', TType.I32, 5)
            oprot.writeI32(self.entityType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchIndexEntity(object):
    """
    Attributes:
     - id
     - type
     - displayName
     - company
     - avatarUrl
     - urlName
     - geo
     - isPublicProfile
     - officeId
     - officeLocation
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
        (3, TType.STRING, 'displayName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'company', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'urlName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'geo', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isPublicProfile', None, None, ),  # 8
        (9, TType.STRING, 'officeId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'officeLocation', 'UTF8', None, ),  # 10
    )
    def __init__(self, id=None, type=None, displayName=None, company=None, avatarUrl=None, urlName=None, geo=None, isPublicProfile=None, officeId=None, officeLocation=None, ):
        self.id = id
        self.type = type
        self.displayName = displayName
        self.company = company
        self.avatarUrl = avatarUrl
        self.urlName = urlName
        self.geo = geo
        self.isPublicProfile = isPublicProfile
        self.officeId = officeId
        self.officeLocation = officeLocation

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.urlName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.geo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isPublicProfile = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.officeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.officeLocation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchIndexEntity')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 3)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 4)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 5)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.urlName is not None:
            oprot.writeFieldBegin('urlName', TType.STRING, 6)
            oprot.writeString(self.urlName.encode('utf-8') if sys.version_info[0] == 2 else self.urlName)
            oprot.writeFieldEnd()
        if self.geo is not None:
            oprot.writeFieldBegin('geo', TType.STRING, 7)
            oprot.writeString(self.geo.encode('utf-8') if sys.version_info[0] == 2 else self.geo)
            oprot.writeFieldEnd()
        if self.isPublicProfile is not None:
            oprot.writeFieldBegin('isPublicProfile', TType.BOOL, 8)
            oprot.writeBool(self.isPublicProfile)
            oprot.writeFieldEnd()
        if self.officeId is not None:
            oprot.writeFieldBegin('officeId', TType.STRING, 9)
            oprot.writeString(self.officeId.encode('utf-8') if sys.version_info[0] == 2 else self.officeId)
            oprot.writeFieldEnd()
        if self.officeLocation is not None:
            oprot.writeFieldBegin('officeLocation', TType.STRING, 10)
            oprot.writeString(self.officeLocation.encode('utf-8') if sys.version_info[0] == 2 else self.officeLocation)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchResult(object):
    """
    Attributes:
     - id
     - type
     - displayName
     - avatarUrl
     - officeLocation
     - company
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
        (3, TType.STRING, 'displayName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'officeLocation', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'company', 'UTF8', None, ),  # 6
    )
    def __init__(self, id=None, type=None, displayName=None, avatarUrl=None, officeLocation=None, company=None, ):
        self.id = id
        self.type = type
        self.displayName = displayName
        self.avatarUrl = avatarUrl
        self.officeLocation = officeLocation
        self.company = company

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.officeLocation = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchResult')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 3)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 4)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.officeLocation is not None:
            oprot.writeFieldBegin('officeLocation', TType.STRING, 5)
            oprot.writeString(self.officeLocation.encode('utf-8') if sys.version_info[0] == 2 else self.officeLocation)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 6)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class StateLicense(object):
    """
    Attributes:
     - state
     - licenseNumber
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'state', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'licenseNumber', 'UTF8', None, ),  # 2
    )
    def __init__(self, state=None, licenseNumber=None, ):
        self.state = state
        self.licenseNumber = licenseNumber

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.licenseNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('StateLicense')
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 1)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.licenseNumber is not None:
            oprot.writeFieldBegin('licenseNumber', TType.STRING, 2)
            oprot.writeString(self.licenseNumber.encode('utf-8') if sys.version_info[0] == 2 else self.licenseNumber)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamMemberInfo(object):
    """
    Attributes:
     - userId
     - avatarUrl
     - firstName
     - lastName
     - title
     - closedDealsCount
     - displayName
     - publicProfileUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'firstName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'lastName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'title', 'UTF8', None, ),  # 5
        (6, TType.I32, 'closedDealsCount', None, None, ),  # 6
        (7, TType.STRING, 'displayName', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'publicProfileUrl', 'UTF8', None, ),  # 8
    )
    def __init__(self, userId=None, avatarUrl=None, firstName=None, lastName=None, title=None, closedDealsCount=None, displayName=None, publicProfileUrl=None, ):
        self.userId = userId
        self.avatarUrl = avatarUrl
        self.firstName = firstName
        self.lastName = lastName
        self.title = title
        self.closedDealsCount = closedDealsCount
        self.displayName = displayName
        self.publicProfileUrl = publicProfileUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.closedDealsCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.publicProfileUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamMemberInfo')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 2)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 3)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 4)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 5)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.closedDealsCount is not None:
            oprot.writeFieldBegin('closedDealsCount', TType.I32, 6)
            oprot.writeI32(self.closedDealsCount)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 7)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.publicProfileUrl is not None:
            oprot.writeFieldBegin('publicProfileUrl', TType.STRING, 8)
            oprot.writeString(self.publicProfileUrl.encode('utf-8') if sys.version_info[0] == 2 else self.publicProfileUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentInfo(object):
    """
    Attributes:
     - userId
     - firstName
     - lastName
     - email
     - phone
     - title
     - avatarUrl
     - company
     - office
     - teamInfo
     - stateLicenses
     - mlsLicenses
     - displayName
     - publicProfileUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'firstName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'lastName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'phone', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'title', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'company', 'UTF8', None, ),  # 8
        (9, TType.STRUCT, 'office', (Office, Office.thrift_spec), None, ),  # 9
        (10, TType.STRUCT, 'teamInfo', (AgentTeamInfo, AgentTeamInfo.thrift_spec), None, ),  # 10
        (11, TType.LIST, 'stateLicenses', (TType.STRUCT, (StateLicense, StateLicense.thrift_spec), False), None, ),  # 11
        (12, TType.LIST, 'mlsLicenses', (TType.STRUCT, (MlsLicense, MlsLicense.thrift_spec), False), None, ),  # 12
        (13, TType.STRING, 'displayName', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'publicProfileUrl', 'UTF8', None, ),  # 14
    )
    def __init__(self, userId=None, firstName=None, lastName=None, email=None, phone=None, title=None, avatarUrl=None, company=None, office=None, teamInfo=None, stateLicenses=None, mlsLicenses=None, displayName=None, publicProfileUrl=None, ):
        self.userId = userId
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.phone = phone
        self.title = title
        self.avatarUrl = avatarUrl
        self.company = company
        self.office = office
        self.teamInfo = teamInfo
        self.stateLicenses = stateLicenses
        self.mlsLicenses = mlsLicenses
        self.displayName = displayName
        self.publicProfileUrl = publicProfileUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.office = Office()
                    self.office.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.teamInfo = AgentTeamInfo()
                    self.teamInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.stateLicenses = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = StateLicense()
                        _elem24.read(iprot)
                        self.stateLicenses.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.mlsLicenses = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = MlsLicense()
                        _elem28.read(iprot)
                        self.mlsLicenses.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.publicProfileUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentInfo')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 2)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 3)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 5)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 6)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 7)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 8)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.office is not None:
            oprot.writeFieldBegin('office', TType.STRUCT, 9)
            self.office.write(oprot)
            oprot.writeFieldEnd()
        if self.teamInfo is not None:
            oprot.writeFieldBegin('teamInfo', TType.STRUCT, 10)
            self.teamInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.stateLicenses is not None:
            oprot.writeFieldBegin('stateLicenses', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.stateLicenses))
            for _iter30 in self.stateLicenses:
                _iter30.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.mlsLicenses is not None:
            oprot.writeFieldBegin('mlsLicenses', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.mlsLicenses))
            for _iter31 in self.mlsLicenses:
                _iter31.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 13)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.publicProfileUrl is not None:
            oprot.writeFieldBegin('publicProfileUrl', TType.STRING, 14)
            oprot.writeString(self.publicProfileUrl.encode('utf-8') if sys.version_info[0] == 2 else self.publicProfileUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ClosedDealsAggregates(object):
    """
    Attributes:
     - seller
     - buyer
     - propertyTypeAggregates
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'seller', (ClosedDealsAggregate, ClosedDealsAggregate.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'buyer', (ClosedDealsAggregate, ClosedDealsAggregate.thrift_spec), None, ),  # 2
        (3, TType.MAP, 'propertyTypeAggregates', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 3
    )
    def __init__(self, seller=None, buyer=None, propertyTypeAggregates=None, ):
        self.seller = seller
        self.buyer = buyer
        self.propertyTypeAggregates = propertyTypeAggregates

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.seller = ClosedDealsAggregate()
                    self.seller.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.buyer = ClosedDealsAggregate()
                    self.buyer.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.propertyTypeAggregates = {}
                    (_ktype33, _vtype34, _size37) = iprot.readMapBegin()
                    for _i32 in range(_size37):
                        _key35 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val36 = iprot.readI32()
                        self.propertyTypeAggregates[_key35] = _val36
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosedDealsAggregates')
        if self.seller is not None:
            oprot.writeFieldBegin('seller', TType.STRUCT, 1)
            self.seller.write(oprot)
            oprot.writeFieldEnd()
        if self.buyer is not None:
            oprot.writeFieldBegin('buyer', TType.STRUCT, 2)
            self.buyer.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyTypeAggregates is not None:
            oprot.writeFieldBegin('propertyTypeAggregates', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.propertyTypeAggregates))
            for _kiter38, _viter39 in self.propertyTypeAggregates.items():
                oprot.writeString(_kiter38.encode('utf-8') if sys.version_info[0] == 2 else _kiter38)
                oprot.writeI32(_viter39)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingsAggregates(object):
    """
    Attributes:
     - aggregates
     - propertyTypeAggregates
     - neighborhoodAggregates
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'aggregates', (TType.I32, None, TType.STRUCT, (ListingsAggregate, ListingsAggregate.thrift_spec), False), None, ),  # 1
        (2, TType.MAP, 'propertyTypeAggregates', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 2
        (3, TType.MAP, 'neighborhoodAggregates', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 3
    )
    def __init__(self, aggregates=None, propertyTypeAggregates=None, neighborhoodAggregates=None, ):
        self.aggregates = aggregates
        self.propertyTypeAggregates = propertyTypeAggregates
        self.neighborhoodAggregates = neighborhoodAggregates

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.aggregates = {}
                    (_ktype41, _vtype42, _size45) = iprot.readMapBegin()
                    for _i40 in range(_size45):
                        _key43 = iprot.readI32()
                        _val44 = ListingsAggregate()
                        _val44.read(iprot)
                        self.aggregates[_key43] = _val44
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.propertyTypeAggregates = {}
                    (_ktype47, _vtype48, _size51) = iprot.readMapBegin()
                    for _i46 in range(_size51):
                        _key49 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val50 = iprot.readI32()
                        self.propertyTypeAggregates[_key49] = _val50
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.neighborhoodAggregates = {}
                    (_ktype53, _vtype54, _size57) = iprot.readMapBegin()
                    for _i52 in range(_size57):
                        _key55 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val56 = iprot.readI32()
                        self.neighborhoodAggregates[_key55] = _val56
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingsAggregates')
        if self.aggregates is not None:
            oprot.writeFieldBegin('aggregates', TType.MAP, 1)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.aggregates))
            for _kiter58, _viter59 in self.aggregates.items():
                oprot.writeI32(_kiter58)
                _viter59.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.propertyTypeAggregates is not None:
            oprot.writeFieldBegin('propertyTypeAggregates', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.propertyTypeAggregates))
            for _kiter60, _viter61 in self.propertyTypeAggregates.items():
                oprot.writeString(_kiter60.encode('utf-8') if sys.version_info[0] == 2 else _kiter60)
                oprot.writeI32(_viter61)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.neighborhoodAggregates is not None:
            oprot.writeFieldBegin('neighborhoodAggregates', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.neighborhoodAggregates))
            for _kiter62, _viter63 in self.neighborhoodAggregates.items():
                oprot.writeString(_kiter62.encode('utf-8') if sys.version_info[0] == 2 else _kiter62)
                oprot.writeI32(_viter63)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ManualClosedDeal(object):
    """
    Attributes:
     - streetAddress
     - city
     - state
     - zipcode
     - closePrice
     - closedDate
     - listingData
     - neighborhoods
     - disableLink
     - hidePrice
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'streetAddress', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'city', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'zipcode', 'UTF8', None, ),  # 4
        (5, TType.DOUBLE, 'closePrice', None, None, ),  # 5
        (6, TType.I64, 'closedDate', None, None, ),  # 6
        (7, TType.STRUCT, 'listingData', (ClosedDealData, ClosedDealData.thrift_spec), None, ),  # 7
        (8, TType.LIST, 'neighborhoods', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.BOOL, 'disableLink', None, None, ),  # 9
        (10, TType.BOOL, 'hidePrice', None, None, ),  # 10
    )
    def __init__(self, streetAddress=None, city=None, state=None, zipcode=None, closePrice=None, closedDate=None, listingData=None, neighborhoods=None, disableLink=None, hidePrice=None, ):
        self.streetAddress = streetAddress
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.closePrice = closePrice
        self.closedDate = closedDate
        self.listingData = listingData
        self.neighborhoods = neighborhoods
        self.disableLink = disableLink
        self.hidePrice = hidePrice

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.streetAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.closedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.listingData = ClosedDealData()
                    self.listingData.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.neighborhoods = []
                    (_etype64, _size67) = iprot.readListBegin()
                    for _i65 in range(_size67):
                        _elem66 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.neighborhoods.append(_elem66)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.disableLink = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.hidePrice = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ManualClosedDeal')
        if self.streetAddress is not None:
            oprot.writeFieldBegin('streetAddress', TType.STRING, 1)
            oprot.writeString(self.streetAddress.encode('utf-8') if sys.version_info[0] == 2 else self.streetAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 2)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 4)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 5)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.closedDate is not None:
            oprot.writeFieldBegin('closedDate', TType.I64, 6)
            oprot.writeI64(self.closedDate)
            oprot.writeFieldEnd()
        if self.listingData is not None:
            oprot.writeFieldBegin('listingData', TType.STRUCT, 7)
            self.listingData.write(oprot)
            oprot.writeFieldEnd()
        if self.neighborhoods is not None:
            oprot.writeFieldBegin('neighborhoods', TType.LIST, 8)
            oprot.writeListBegin(TType.STRING, len(self.neighborhoods))
            for _iter68 in self.neighborhoods:
                oprot.writeString(_iter68.encode('utf-8') if sys.version_info[0] == 2 else _iter68)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.disableLink is not None:
            oprot.writeFieldBegin('disableLink', TType.BOOL, 9)
            oprot.writeBool(self.disableLink)
            oprot.writeFieldEnd()
        if self.hidePrice is not None:
            oprot.writeFieldBegin('hidePrice', TType.BOOL, 10)
            oprot.writeBool(self.hidePrice)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NonCompassAgentIndexEntity(object):
    """
    Attributes:
     - userId
     - agentName
     - email
     - mlsMemberships
     - stateLicenses
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'agentName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'mlsMemberships', (TType.STRUCT, (MlsLicense, MlsLicense.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'stateLicenses', (TType.STRUCT, (StateLicense, StateLicense.thrift_spec), False), None, ),  # 5
    )
    def __init__(self, userId=None, agentName=None, email=None, mlsMemberships=None, stateLicenses=None, ):
        self.userId = userId
        self.agentName = agentName
        self.email = email
        self.mlsMemberships = mlsMemberships
        self.stateLicenses = stateLicenses

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.mlsMemberships = []
                    (_etype69, _size72) = iprot.readListBegin()
                    for _i70 in range(_size72):
                        _elem71 = MlsLicense()
                        _elem71.read(iprot)
                        self.mlsMemberships.append(_elem71)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.stateLicenses = []
                    (_etype73, _size76) = iprot.readListBegin()
                    for _i74 in range(_size76):
                        _elem75 = StateLicense()
                        _elem75.read(iprot)
                        self.stateLicenses.append(_elem75)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NonCompassAgentIndexEntity')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 2)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.mlsMemberships is not None:
            oprot.writeFieldBegin('mlsMemberships', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.mlsMemberships))
            for _iter77 in self.mlsMemberships:
                _iter77.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stateLicenses is not None:
            oprot.writeFieldBegin('stateLicenses', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.stateLicenses))
            for _iter78 in self.stateLicenses:
                _iter78.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchIndexMessage(object):
    """
    Attributes:
     - entity
     - operationType
     - operationTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'entity', (SearchIndexEntity, SearchIndexEntity.thrift_spec), None, ),  # 1
        (2, TType.I32, 'operationType', None, None, ),  # 2
        (3, TType.I64, 'operationTime', None, None, ),  # 3
    )
    def __init__(self, entity=None, operationType=None, operationTime=None, ):
        self.entity = entity
        self.operationType = operationType
        self.operationTime = operationTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.entity = SearchIndexEntity()
                    self.entity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.operationType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.operationTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchIndexMessage')
        if self.entity is not None:
            oprot.writeFieldBegin('entity', TType.STRUCT, 1)
            self.entity.write(oprot)
            oprot.writeFieldEnd()
        if self.operationType is not None:
            oprot.writeFieldBegin('operationType', TType.I32, 2)
            oprot.writeI32(self.operationType)
            oprot.writeFieldEnd()
        if self.operationTime is not None:
            oprot.writeFieldBegin('operationTime', TType.I64, 3)
            oprot.writeI64(self.operationTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamInfo(object):
    """
    Attributes:
     - hexId
     - name
     - email
     - phone
     - title
     - avatarUrl
     - company
     - office
     - members
     - stateLicenses
     - mlsLicenses
     - publicProfileUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'hexId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'phone', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'title', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'company', 'UTF8', None, ),  # 7
        (8, TType.STRUCT, 'office', (Office, Office.thrift_spec), None, ),  # 8
        (9, TType.LIST, 'members', (TType.STRUCT, (TeamMemberInfo, TeamMemberInfo.thrift_spec), False), None, ),  # 9
        (10, TType.LIST, 'stateLicenses', (TType.STRUCT, (StateLicense, StateLicense.thrift_spec), False), None, ),  # 10
        (11, TType.LIST, 'mlsLicenses', (TType.STRUCT, (MlsLicense, MlsLicense.thrift_spec), False), None, ),  # 11
        (12, TType.STRING, 'publicProfileUrl', 'UTF8', None, ),  # 12
    )
    def __init__(self, hexId=None, name=None, email=None, phone=None, title=None, avatarUrl=None, company=None, office=None, members=None, stateLicenses=None, mlsLicenses=None, publicProfileUrl=None, ):
        self.hexId = hexId
        self.name = name
        self.email = email
        self.phone = phone
        self.title = title
        self.avatarUrl = avatarUrl
        self.company = company
        self.office = office
        self.members = members
        self.stateLicenses = stateLicenses
        self.mlsLicenses = mlsLicenses
        self.publicProfileUrl = publicProfileUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.hexId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.office = Office()
                    self.office.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.members = []
                    (_etype79, _size82) = iprot.readListBegin()
                    for _i80 in range(_size82):
                        _elem81 = TeamMemberInfo()
                        _elem81.read(iprot)
                        self.members.append(_elem81)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.stateLicenses = []
                    (_etype83, _size86) = iprot.readListBegin()
                    for _i84 in range(_size86):
                        _elem85 = StateLicense()
                        _elem85.read(iprot)
                        self.stateLicenses.append(_elem85)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.mlsLicenses = []
                    (_etype87, _size90) = iprot.readListBegin()
                    for _i88 in range(_size90):
                        _elem89 = MlsLicense()
                        _elem89.read(iprot)
                        self.mlsLicenses.append(_elem89)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.publicProfileUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamInfo')
        if self.hexId is not None:
            oprot.writeFieldBegin('hexId', TType.STRING, 1)
            oprot.writeString(self.hexId.encode('utf-8') if sys.version_info[0] == 2 else self.hexId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 4)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 5)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 6)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 7)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.office is not None:
            oprot.writeFieldBegin('office', TType.STRUCT, 8)
            self.office.write(oprot)
            oprot.writeFieldEnd()
        if self.members is not None:
            oprot.writeFieldBegin('members', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.members))
            for _iter91 in self.members:
                _iter91.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.stateLicenses is not None:
            oprot.writeFieldBegin('stateLicenses', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.stateLicenses))
            for _iter92 in self.stateLicenses:
                _iter92.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.mlsLicenses is not None:
            oprot.writeFieldBegin('mlsLicenses', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.mlsLicenses))
            for _iter93 in self.mlsLicenses:
                _iter93.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.publicProfileUrl is not None:
            oprot.writeFieldBegin('publicProfileUrl', TType.STRING, 12)
            oprot.writeString(self.publicProfileUrl.encode('utf-8') if sys.version_info[0] == 2 else self.publicProfileUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NonCompassAgentIndexMessage(object):
    """
    Attributes:
     - entity
     - operationType
     - operationTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'entity', (NonCompassAgentIndexEntity, NonCompassAgentIndexEntity.thrift_spec), None, ),  # 1
        (2, TType.I32, 'operationType', None, None, ),  # 2
        (3, TType.I64, 'operationTime', None, None, ),  # 3
    )
    def __init__(self, entity=None, operationType=None, operationTime=None, ):
        self.entity = entity
        self.operationType = operationType
        self.operationTime = operationTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.entity = NonCompassAgentIndexEntity()
                    self.entity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.operationType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.operationTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NonCompassAgentIndexMessage')
        if self.entity is not None:
            oprot.writeFieldBegin('entity', TType.STRUCT, 1)
            self.entity.write(oprot)
            oprot.writeFieldEnd()
        if self.operationType is not None:
            oprot.writeFieldBegin('operationType', TType.I32, 2)
            oprot.writeI32(self.operationType)
            oprot.writeFieldEnd()
        if self.operationTime is not None:
            oprot.writeFieldBegin('operationTime', TType.I64, 3)
            oprot.writeI64(self.operationTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ProfileDealsData(object):
    """
    Attributes:
     - closedDealsAggregates
     - sellerListingsAggregates
     - buyerListingsAggregates
     - sellerListings
     - buyerListings
     - sellerListingsCount
     - buyerListingsCount
     - isNYCGeo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'closedDealsAggregates', (ClosedDealsAggregates, ClosedDealsAggregates.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'sellerListingsAggregates', (ListingsAggregates, ListingsAggregates.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'buyerListingsAggregates', (ListingsAggregates, ListingsAggregates.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'sellerListings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'buyerListings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 5
        (6, TType.I32, 'sellerListingsCount', None, None, ),  # 6
        (7, TType.I32, 'buyerListingsCount', None, None, ),  # 7
        (8, TType.BOOL, 'isNYCGeo', None, None, ),  # 8
    )
    def __init__(self, closedDealsAggregates=None, sellerListingsAggregates=None, buyerListingsAggregates=None, sellerListings=None, buyerListings=None, sellerListingsCount=None, buyerListingsCount=None, isNYCGeo=None, ):
        self.closedDealsAggregates = closedDealsAggregates
        self.sellerListingsAggregates = sellerListingsAggregates
        self.buyerListingsAggregates = buyerListingsAggregates
        self.sellerListings = sellerListings
        self.buyerListings = buyerListings
        self.sellerListingsCount = sellerListingsCount
        self.buyerListingsCount = buyerListingsCount
        self.isNYCGeo = isNYCGeo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.closedDealsAggregates = ClosedDealsAggregates()
                    self.closedDealsAggregates.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.sellerListingsAggregates = ListingsAggregates()
                    self.sellerListingsAggregates.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.buyerListingsAggregates = ListingsAggregates()
                    self.buyerListingsAggregates.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.sellerListings = []
                    (_etype94, _size97) = iprot.readListBegin()
                    for _i95 in range(_size97):
                        _elem96 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem96.read(iprot)
                        self.sellerListings.append(_elem96)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.buyerListings = []
                    (_etype98, _size101) = iprot.readListBegin()
                    for _i99 in range(_size101):
                        _elem100 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem100.read(iprot)
                        self.buyerListings.append(_elem100)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.sellerListingsCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.buyerListingsCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isNYCGeo = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ProfileDealsData')
        if self.closedDealsAggregates is not None:
            oprot.writeFieldBegin('closedDealsAggregates', TType.STRUCT, 1)
            self.closedDealsAggregates.write(oprot)
            oprot.writeFieldEnd()
        if self.sellerListingsAggregates is not None:
            oprot.writeFieldBegin('sellerListingsAggregates', TType.STRUCT, 2)
            self.sellerListingsAggregates.write(oprot)
            oprot.writeFieldEnd()
        if self.buyerListingsAggregates is not None:
            oprot.writeFieldBegin('buyerListingsAggregates', TType.STRUCT, 3)
            self.buyerListingsAggregates.write(oprot)
            oprot.writeFieldEnd()
        if self.sellerListings is not None:
            oprot.writeFieldBegin('sellerListings', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.sellerListings))
            for _iter102 in self.sellerListings:
                _iter102.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.buyerListings is not None:
            oprot.writeFieldBegin('buyerListings', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.buyerListings))
            for _iter103 in self.buyerListings:
                _iter103.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.sellerListingsCount is not None:
            oprot.writeFieldBegin('sellerListingsCount', TType.I32, 6)
            oprot.writeI32(self.sellerListingsCount)
            oprot.writeFieldEnd()
        if self.buyerListingsCount is not None:
            oprot.writeFieldBegin('buyerListingsCount', TType.I32, 7)
            oprot.writeI32(self.buyerListingsCount)
            oprot.writeFieldEnd()
        if self.isNYCGeo is not None:
            oprot.writeFieldBegin('isNYCGeo', TType.BOOL, 8)
            oprot.writeBool(self.isNYCGeo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentProfile(object):
    """
    Attributes:
     - dealsData
     - agentInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dealsData', (ProfileDealsData, ProfileDealsData.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'agentInfo', (AgentInfo, AgentInfo.thrift_spec), None, ),  # 2
    )
    def __init__(self, dealsData=None, agentInfo=None, ):
        self.dealsData = dealsData
        self.agentInfo = agentInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dealsData = ProfileDealsData()
                    self.dealsData.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.agentInfo = AgentInfo()
                    self.agentInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentProfile')
        if self.dealsData is not None:
            oprot.writeFieldBegin('dealsData', TType.STRUCT, 1)
            self.dealsData.write(oprot)
            oprot.writeFieldEnd()
        if self.agentInfo is not None:
            oprot.writeFieldBegin('agentInfo', TType.STRUCT, 2)
            self.agentInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TeamProfile(object):
    """
    Attributes:
     - dealsData
     - teamInfo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'dealsData', (ProfileDealsData, ProfileDealsData.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'teamInfo', (TeamInfo, TeamInfo.thrift_spec), None, ),  # 2
    )
    def __init__(self, dealsData=None, teamInfo=None, ):
        self.dealsData = dealsData
        self.teamInfo = teamInfo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.dealsData = ProfileDealsData()
                    self.dealsData.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.teamInfo = TeamInfo()
                    self.teamInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TeamProfile')
        if self.dealsData is not None:
            oprot.writeFieldBegin('dealsData', TType.STRUCT, 1)
            self.dealsData.write(oprot)
            oprot.writeFieldEnd()
        if self.teamInfo is not None:
            oprot.writeFieldBegin('teamInfo', TType.STRUCT, 2)
            self.teamInfo.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
