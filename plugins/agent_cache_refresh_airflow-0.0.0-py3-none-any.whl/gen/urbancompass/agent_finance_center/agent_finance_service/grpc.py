# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.agent_finance_center.agent_finance.ttypes as agent_finance
import gen.urbancompass.agent_finance_center.agent_finance_manual_patch.ttypes as agent_finance_manual_patch
import gen.urbancompass.common.base.ttypes as base
import uc.grpc.codec as _grpc_codec



class AgentFinanceServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.addUserAccess = channel.unary_unary(
        '/AgentFinanceService/addUserAccess',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddUserAccessResponse),
        )
    self.checkDealExist = channel.unary_unary(
        '/AgentFinanceService/checkDealExist',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DealExistResponse),
        )
    self.createAccountManualPatch = channel.unary_unary(
        '/AgentFinanceService/createAccountManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AccountManualPatchResponse),
        )
    self.createAgentRoleManualPatch = channel.unary_unary(
        '/AgentFinanceService/createAgentRoleManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AgentRoleManualPatchResponse),
        )
    self.createContactManualPatch = channel.unary_unary(
        '/AgentFinanceService/createContactManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ContactManualPatchResponse),
        )
    self.createDealManualPatch = channel.unary_unary(
        '/AgentFinanceService/createDealManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DealManualPatchResponse),
        )
    self.createEntityManualPatch = channel.unary_unary(
        '/AgentFinanceService/createEntityManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(EntityManualPatchResponse),
        )
    self.createTransactionManualPatch = channel.unary_unary(
        '/AgentFinanceService/createTransactionManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(TransactionManualPatchResponse),
        )
    self.deleteAccountManualPatch = channel.unary_unary(
        '/AgentFinanceService/deleteAccountManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteManualPatchResponse),
        )
    self.deleteAgentRoleManualPatch = channel.unary_unary(
        '/AgentFinanceService/deleteAgentRoleManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteManualPatchResponse),
        )
    self.deleteContactManualPatch = channel.unary_unary(
        '/AgentFinanceService/deleteContactManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteManualPatchResponse),
        )
    self.deleteDeal = channel.unary_unary(
        '/AgentFinanceService/deleteDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDealResponse),
        )
    self.deleteDealManualPatch = channel.unary_unary(
        '/AgentFinanceService/deleteDealManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteManualPatchResponse),
        )
    self.deleteEntityManualPatch = channel.unary_unary(
        '/AgentFinanceService/deleteEntityManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteManualPatchResponse),
        )
    self.deleteTransactionManualPatch = channel.unary_unary(
        '/AgentFinanceService/deleteTransactionManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteManualPatchResponse),
        )
    self.findDealById = channel.unary_unary(
        '/AgentFinanceService/findDealById',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FindDealByIdResponse),
        )
    self.getAccountManualPatch = channel.unary_unary(
        '/AgentFinanceService/getAccountManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AccountManualPatchResponse),
        )
    self.getAgentRoleManualPatch = channel.unary_unary(
        '/AgentFinanceService/getAgentRoleManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AgentRoleManualPatchResponse),
        )
    self.getAllUserDeals = channel.unary_unary(
        '/AgentFinanceService/getAllUserDeals',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllUserDealsResponse),
        )
    self.getAllUserDealsForExport = channel.unary_unary(
        '/AgentFinanceService/getAllUserDealsForExport',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllUserDealsResponse),
        )
    self.getAllUserDealsV2 = channel.unary_unary(
        '/AgentFinanceService/getAllUserDealsV2',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllUserDealsResponse),
        )
    self.getContactManualPatch = channel.unary_unary(
        '/AgentFinanceService/getContactManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ContactManualPatchResponse),
        )
    self.getCurrentUser = channel.unary_unary(
        '/AgentFinanceService/getCurrentUser',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetCurrentUserResponse),
        )
    self.getDealManualPatch = channel.unary_unary(
        '/AgentFinanceService/getDealManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DealManualPatchResponse),
        )
    self.getDealNetPayment = channel.unary_unary(
        '/AgentFinanceService/getDealNetPayment',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDealNetPaymentResponse),
        )
    self.getDealNetPaymentV2 = channel.unary_unary(
        '/AgentFinanceService/getDealNetPaymentV2',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDealNetPaymentResponse),
        )
    self.getDealsAssociatedAgents = channel.unary_unary(
        '/AgentFinanceService/getDealsAssociatedAgents',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDealsAssociatedAgentsResponse),
        )
    self.getDebugDeal = channel.unary_unary(
        '/AgentFinanceService/getDebugDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DebugDealResponse),
        )
    self.getEntityManualPatch = channel.unary_unary(
        '/AgentFinanceService/getEntityManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(EntityManualPatchResponse),
        )
    self.getFinanceEmailDistro = channel.unary_unary(
        '/AgentFinanceService/getFinanceEmailDistro',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetFinanceEmailDistroResponse),
        )
    self.getImpersonations = channel.unary_unary(
        '/AgentFinanceService/getImpersonations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetImpersonationsResponse),
        )
    self.getMostRecentAfcUpdateTime = channel.unary_unary(
        '/AgentFinanceService/getMostRecentAfcUpdateTime',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetMostRecentAfcUpdateTimeResponse),
        )
    self.getNumberOfObjects = channel.unary_unary(
        '/AgentFinanceService/getNumberOfObjects',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetNumberOfObjectsResponse),
        )
    self.getTeam = channel.unary_unary(
        '/AgentFinanceService/getTeam',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetTeamResponse),
        )
    self.getTeamSummary = channel.unary_unary(
        '/AgentFinanceService/getTeamSummary',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetTeamSummaryResponse),
        )
    self.getTeamSummaryV2 = channel.unary_unary(
        '/AgentFinanceService/getTeamSummaryV2',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetTeamSummaryResponse),
        )
    self.getTransactionManualPatch = channel.unary_unary(
        '/AgentFinanceService/getTransactionManualPatch',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(TransactionManualPatchResponse),
        )
    self.getUser = channel.unary_unary(
        '/AgentFinanceService/getUser',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetUserResponse),
        )
    self.getUserDealsAggregatedSummary = channel.unary_unary(
        '/AgentFinanceService/getUserDealsAggregatedSummary',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetUserDealsAggregatedSummaryResponse),
        )
    self.getUserDealsAggregatedSummaryV2 = channel.unary_unary(
        '/AgentFinanceService/getUserDealsAggregatedSummaryV2',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetUserDealsAggregatedSummaryResponse),
        )
    self.getUserDealsSummary = channel.unary_unary(
        '/AgentFinanceService/getUserDealsSummary',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetUserDealsSummaryResponse),
        )
    self.getUserDealsSummaryV2 = channel.unary_unary(
        '/AgentFinanceService/getUserDealsSummaryV2',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetUserDealsSummaryResponse),
        )
    self.reingestDeal = channel.unary_unary(
        '/AgentFinanceService/reingestDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReingestDealResponse),
        )
    self.reingestEntity = channel.unary_unary(
        '/AgentFinanceService/reingestEntity',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReingestEntityResponse),
        )
    self.reingestTransaction = channel.unary_unary(
        '/AgentFinanceService/reingestTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReingestTransactionResponse),
        )
    self.saveDeal = channel.unary_unary(
        '/AgentFinanceService/saveDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SaveDealResponse),
        )
    self.saveImpersonations = channel.unary_unary(
        '/AgentFinanceService/saveImpersonations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SaveImpersonationsResponse),
        )
    self.verifyImpersonation = channel.unary_unary(
        '/AgentFinanceService/verifyImpersonation',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(VerifyImpersonationResponse),
        )
    self.verifyTeamAccess = channel.unary_unary(
        '/AgentFinanceService/verifyTeamAccess',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckTeamDataAccessResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class AgentFinanceServiceServicer(BaseServiceServicer):
  """
    The AgentFinanceService Service definition
  """

  def addUserAccess(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkDealExist(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createAccountManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createAgentRoleManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createContactManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createDealManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createEntityManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createTransactionManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteAccountManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteAgentRoleManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteContactManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDealManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteEntityManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteTransactionManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def findDealById(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAccountManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentRoleManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllUserDeals(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllUserDealsForExport(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllUserDealsV2(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getContactManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getCurrentUser(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDealManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDealNetPayment(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDealNetPaymentV2(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDealsAssociatedAgents(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDebugDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getEntityManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getFinanceEmailDistro(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getImpersonations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getMostRecentAfcUpdateTime(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getNumberOfObjects(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeam(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeamSummary(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeamSummaryV2(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTransactionManualPatch(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUser(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUserDealsAggregatedSummary(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUserDealsAggregatedSummaryV2(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUserDealsSummary(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUserDealsSummaryV2(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def reingestDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def reingestEntity(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def reingestTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def saveDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def saveImpersonations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def verifyImpersonation(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def verifyTeamAccess(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_AgentFinanceServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'addUserAccess': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addUserAccess(req),
          request_deserializer=_grpc_codec.deserializer(AddUserAccessRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkDealExist': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkDealExist(req),
          request_deserializer=_grpc_codec.deserializer(DealExistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createAccountManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createAccountManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(CreateAccountManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createAgentRoleManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createAgentRoleManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(CreateAgentRoleManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createContactManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createContactManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(CreateContactManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDealManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createDealManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(CreateDealManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createEntityManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createEntityManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(CreateEntityManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createTransactionManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createTransactionManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(CreateTransactionManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteAccountManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteAccountManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteAgentRoleManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteAgentRoleManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(DeleteAgentRoleManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteContactManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteContactManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDeal(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDealManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDealManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteEntityManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteEntityManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteTransactionManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteTransactionManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'findDealById': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.findDealById(req),
          request_deserializer=_grpc_codec.deserializer(FindDealByIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAccountManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAccountManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(GetAccountManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentRoleManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentRoleManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(GetAgentRoleManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUserDeals': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllUserDeals(req),
          request_deserializer=_grpc_codec.deserializer(GetAllUserDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUserDealsForExport': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllUserDealsForExport(req),
          request_deserializer=_grpc_codec.deserializer(GetAllUserDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUserDealsV2': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllUserDealsV2(req),
          request_deserializer=_grpc_codec.deserializer(GetAllUserDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getContactManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getContactManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(GetContactManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCurrentUser': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getCurrentUser(req),
          request_deserializer=_grpc_codec.deserializer(GetCurrentUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDealManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(GetDealManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealNetPayment': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDealNetPayment(req),
          request_deserializer=_grpc_codec.deserializer(GetDealNetPaymentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealNetPaymentV2': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDealNetPaymentV2(req),
          request_deserializer=_grpc_codec.deserializer(GetDealNetPaymentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealsAssociatedAgents': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDealsAssociatedAgents(req),
          request_deserializer=_grpc_codec.deserializer(GetDealsAssociatedAgentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDebugDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDebugDeal(req),
          request_deserializer=_grpc_codec.deserializer(DebugDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getEntityManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getEntityManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(GetEntityManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getFinanceEmailDistro': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getFinanceEmailDistro(req),
          request_deserializer=_grpc_codec.deserializer(GetFinanceEmailDistroRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getImpersonations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getImpersonations(req),
          request_deserializer=_grpc_codec.deserializer(GetImpersonationsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getMostRecentAfcUpdateTime': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getMostRecentAfcUpdateTime(req),
          request_deserializer=_grpc_codec.deserializer(GetMostRecentAfcUpdateTimeRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getNumberOfObjects': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getNumberOfObjects(req),
          request_deserializer=_grpc_codec.deserializer(GetNumberOfObjectsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeam': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeam(req),
          request_deserializer=_grpc_codec.deserializer(GetTeamRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamSummary': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeamSummary(req),
          request_deserializer=_grpc_codec.deserializer(GetTeamSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamSummaryV2': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeamSummaryV2(req),
          request_deserializer=_grpc_codec.deserializer(GetTeamSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTransactionManualPatch': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTransactionManualPatch(req),
          request_deserializer=_grpc_codec.deserializer(GetTransactionManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUser(req),
          request_deserializer=_grpc_codec.deserializer(GetUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsAggregatedSummary': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUserDealsAggregatedSummary(req),
          request_deserializer=_grpc_codec.deserializer(GetUserDealsAggregatedSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsAggregatedSummaryV2': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUserDealsAggregatedSummaryV2(req),
          request_deserializer=_grpc_codec.deserializer(GetUserDealsAggregatedSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsSummary': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUserDealsSummary(req),
          request_deserializer=_grpc_codec.deserializer(GetUserDealsSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsSummaryV2': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUserDealsSummaryV2(req),
          request_deserializer=_grpc_codec.deserializer(GetUserDealsSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reingestDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reingestDeal(req),
          request_deserializer=_grpc_codec.deserializer(ReingestDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reingestEntity': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reingestEntity(req),
          request_deserializer=_grpc_codec.deserializer(ReingestEntityRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reingestTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reingestTransaction(req),
          request_deserializer=_grpc_codec.deserializer(ReingestTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.saveDeal(req),
          request_deserializer=_grpc_codec.deserializer(SaveDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveImpersonations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.saveImpersonations(req),
          request_deserializer=_grpc_codec.deserializer(SaveImpersonationsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'verifyImpersonation': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.verifyImpersonation(req),
          request_deserializer=_grpc_codec.deserializer(VerifyImpersonationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'verifyTeamAccess': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.verifyTeamAccess(req),
          request_deserializer=_grpc_codec.deserializer(CheckTeamDataAccessRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'AgentFinanceService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_AgentFinanceServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'addUserAccess': grpc.unary_unary_rpc_method_handler(
          servicer.addUserAccess,
          request_deserializer=_grpc_codec.deserializer(AddUserAccessRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkDealExist': grpc.unary_unary_rpc_method_handler(
          servicer.checkDealExist,
          request_deserializer=_grpc_codec.deserializer(DealExistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createAccountManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.createAccountManualPatch,
          request_deserializer=_grpc_codec.deserializer(CreateAccountManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createAgentRoleManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.createAgentRoleManualPatch,
          request_deserializer=_grpc_codec.deserializer(CreateAgentRoleManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createContactManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.createContactManualPatch,
          request_deserializer=_grpc_codec.deserializer(CreateContactManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDealManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.createDealManualPatch,
          request_deserializer=_grpc_codec.deserializer(CreateDealManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createEntityManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.createEntityManualPatch,
          request_deserializer=_grpc_codec.deserializer(CreateEntityManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createTransactionManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.createTransactionManualPatch,
          request_deserializer=_grpc_codec.deserializer(CreateTransactionManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteAccountManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.deleteAccountManualPatch,
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteAgentRoleManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.deleteAgentRoleManualPatch,
          request_deserializer=_grpc_codec.deserializer(DeleteAgentRoleManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteContactManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.deleteContactManualPatch,
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDeal': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDeal,
          request_deserializer=_grpc_codec.deserializer(DeleteDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDealManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDealManualPatch,
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteEntityManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.deleteEntityManualPatch,
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteTransactionManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.deleteTransactionManualPatch,
          request_deserializer=_grpc_codec.deserializer(DeleteManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'findDealById': grpc.unary_unary_rpc_method_handler(
          servicer.findDealById,
          request_deserializer=_grpc_codec.deserializer(FindDealByIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAccountManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.getAccountManualPatch,
          request_deserializer=_grpc_codec.deserializer(GetAccountManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentRoleManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentRoleManualPatch,
          request_deserializer=_grpc_codec.deserializer(GetAgentRoleManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUserDeals': grpc.unary_unary_rpc_method_handler(
          servicer.getAllUserDeals,
          request_deserializer=_grpc_codec.deserializer(GetAllUserDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUserDealsForExport': grpc.unary_unary_rpc_method_handler(
          servicer.getAllUserDealsForExport,
          request_deserializer=_grpc_codec.deserializer(GetAllUserDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllUserDealsV2': grpc.unary_unary_rpc_method_handler(
          servicer.getAllUserDealsV2,
          request_deserializer=_grpc_codec.deserializer(GetAllUserDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getContactManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.getContactManualPatch,
          request_deserializer=_grpc_codec.deserializer(GetContactManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCurrentUser': grpc.unary_unary_rpc_method_handler(
          servicer.getCurrentUser,
          request_deserializer=_grpc_codec.deserializer(GetCurrentUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.getDealManualPatch,
          request_deserializer=_grpc_codec.deserializer(GetDealManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealNetPayment': grpc.unary_unary_rpc_method_handler(
          servicer.getDealNetPayment,
          request_deserializer=_grpc_codec.deserializer(GetDealNetPaymentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealNetPaymentV2': grpc.unary_unary_rpc_method_handler(
          servicer.getDealNetPaymentV2,
          request_deserializer=_grpc_codec.deserializer(GetDealNetPaymentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDealsAssociatedAgents': grpc.unary_unary_rpc_method_handler(
          servicer.getDealsAssociatedAgents,
          request_deserializer=_grpc_codec.deserializer(GetDealsAssociatedAgentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDebugDeal': grpc.unary_unary_rpc_method_handler(
          servicer.getDebugDeal,
          request_deserializer=_grpc_codec.deserializer(DebugDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getEntityManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.getEntityManualPatch,
          request_deserializer=_grpc_codec.deserializer(GetEntityManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getFinanceEmailDistro': grpc.unary_unary_rpc_method_handler(
          servicer.getFinanceEmailDistro,
          request_deserializer=_grpc_codec.deserializer(GetFinanceEmailDistroRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getImpersonations': grpc.unary_unary_rpc_method_handler(
          servicer.getImpersonations,
          request_deserializer=_grpc_codec.deserializer(GetImpersonationsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getMostRecentAfcUpdateTime': grpc.unary_unary_rpc_method_handler(
          servicer.getMostRecentAfcUpdateTime,
          request_deserializer=_grpc_codec.deserializer(GetMostRecentAfcUpdateTimeRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getNumberOfObjects': grpc.unary_unary_rpc_method_handler(
          servicer.getNumberOfObjects,
          request_deserializer=_grpc_codec.deserializer(GetNumberOfObjectsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeam': grpc.unary_unary_rpc_method_handler(
          servicer.getTeam,
          request_deserializer=_grpc_codec.deserializer(GetTeamRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamSummary': grpc.unary_unary_rpc_method_handler(
          servicer.getTeamSummary,
          request_deserializer=_grpc_codec.deserializer(GetTeamSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamSummaryV2': grpc.unary_unary_rpc_method_handler(
          servicer.getTeamSummaryV2,
          request_deserializer=_grpc_codec.deserializer(GetTeamSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTransactionManualPatch': grpc.unary_unary_rpc_method_handler(
          servicer.getTransactionManualPatch,
          request_deserializer=_grpc_codec.deserializer(GetTransactionManualPatchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          servicer.getUser,
          request_deserializer=_grpc_codec.deserializer(GetUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsAggregatedSummary': grpc.unary_unary_rpc_method_handler(
          servicer.getUserDealsAggregatedSummary,
          request_deserializer=_grpc_codec.deserializer(GetUserDealsAggregatedSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsAggregatedSummaryV2': grpc.unary_unary_rpc_method_handler(
          servicer.getUserDealsAggregatedSummaryV2,
          request_deserializer=_grpc_codec.deserializer(GetUserDealsAggregatedSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsSummary': grpc.unary_unary_rpc_method_handler(
          servicer.getUserDealsSummary,
          request_deserializer=_grpc_codec.deserializer(GetUserDealsSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUserDealsSummaryV2': grpc.unary_unary_rpc_method_handler(
          servicer.getUserDealsSummaryV2,
          request_deserializer=_grpc_codec.deserializer(GetUserDealsSummaryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reingestDeal': grpc.unary_unary_rpc_method_handler(
          servicer.reingestDeal,
          request_deserializer=_grpc_codec.deserializer(ReingestDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reingestEntity': grpc.unary_unary_rpc_method_handler(
          servicer.reingestEntity,
          request_deserializer=_grpc_codec.deserializer(ReingestEntityRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reingestTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.reingestTransaction,
          request_deserializer=_grpc_codec.deserializer(ReingestTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveDeal': grpc.unary_unary_rpc_method_handler(
          servicer.saveDeal,
          request_deserializer=_grpc_codec.deserializer(SaveDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'saveImpersonations': grpc.unary_unary_rpc_method_handler(
          servicer.saveImpersonations,
          request_deserializer=_grpc_codec.deserializer(SaveImpersonationsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'verifyImpersonation': grpc.unary_unary_rpc_method_handler(
          servicer.verifyImpersonation,
          request_deserializer=_grpc_codec.deserializer(VerifyImpersonationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'verifyTeamAccess': grpc.unary_unary_rpc_method_handler(
          servicer.verifyTeamAccess,
          request_deserializer=_grpc_codec.deserializer(CheckTeamDataAccessRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'AgentFinanceService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

