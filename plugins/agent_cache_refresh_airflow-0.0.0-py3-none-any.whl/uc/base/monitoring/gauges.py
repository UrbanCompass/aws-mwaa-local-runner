# -*- coding: utf-8 -*-
"""
Please do not use classes in this file directly, rather instantiate them using
base.monitoring.gauge

:copyright: (c) 2014 by Urban Compass, Inc.
"""

import logging


class Gauge(object):
    """Class to implement a simple gauge

    This class is not thread-safe
    """

    def __init__(self, name, reporters):
        self.name = name
        self._reporters = reporters

    def set(self, value, subname=None):
        """
        Sets the value of the gauge.
        :return:
        """
        for r in self._reporters:
            r.report_gauge(value, subname)


class GaugeReporter(object):
    """Interface for reporting a gauge's value"""

    def report_gauge(self, value, subname):
        pass


class LoggingGaugeReporter(GaugeReporter):
    """
    A gauge that sends its results to logging module
    :return:
    """

    def __init__(self, name, log_level="INFO"):
        self.name = name
        self._log_level = logging.getLevelName(log_level)

    def report_gauge(self, value, subname):
        logging.log(
            self._log_level,
            "{}: {}".format(".".join([_f for _f in [self.name, subname] if _f]), value),
        )


class DatadogGaugeReporter(GaugeReporter):
    def __init__(self, name, client, tags=None):
        """
        :param name: gauge name
        :type name: str

        :param client: properly initialized StatsD client
        :type client: base.dd_statsd.StatsD

        :param tags: tags to apply to the metric. Tag keys and values can't have spaces
        :type tags: dict[str,str]
        """
        self.metric_name = name
        self.statsd = client
        self.tags = tags

    def report_gauge(self, value, subname):
        """Doesn't do anything with subname, only reports value"""
        self.statsd.gauge(self.metric_name, value, tags=self.tags)
