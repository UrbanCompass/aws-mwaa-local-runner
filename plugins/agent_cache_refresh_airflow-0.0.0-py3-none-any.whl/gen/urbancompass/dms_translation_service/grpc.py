# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.agent_finance_center.agent_finance.ttypes as agent_finance
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.closings.closings_service.ttypes as closings_service
import gen.urbancompass.contacts.api.contact.ttypes as contact
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes as deals_workflow_model
import gen.urbancompass.dms_common.dms_deal.ttypes as dms_deal
import gen.urbancompass.dms_document.ttypes as dms_document
import gen.urbancompass.dms_common.dms_folder.ttypes as dms_folder
import gen.urbancompass.dms_common.dms_glide.ttypes as dms_glide
import gen.urbancompass.dms_common.dms_listing.ttypes as dms_listing
import gen.urbancompass.dms_region_config_service.ttypes as dms_region_config_service
import gen.urbancompass.dms_state_model.ttypes as dms_state_model
import gen.urbancompass.dms_state_service.ttypes as dms_state_service
import gen.urbancompass.dms_translation_model.ttypes as dms_translation_model
import gen.urbancompass.listing.listing.ttypes as listing
import gen.urbancompass.listing.listing_compliance.ttypes as listing_compliance
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes as region_compliance_checklist_db_helper
import gen.urbancompass.region_compliance_checklist_model.ttypes as region_compliance_checklist_model
import gen.urbancompass.dms_region_config_service.regions.ttypes as regions
import uc.grpc.codec as _grpc_codec



class DmsTranslationServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.addChecklistItemNote = channel.unary_unary(
        '/DmsTranslationService/addChecklistItemNote',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddChecklistItemNoteResponse),
        )
    self.addCustomChecklistItem = channel.unary_unary(
        '/DmsTranslationService/addCustomChecklistItem',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddCustomChecklistItemResponse),
        )
    self.addDMSListing = channel.unary_unary(
        '/DmsTranslationService/addDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSListingResponse),
        )
    self.addDMSOffer = channel.unary_unary(
        '/DmsTranslationService/addDMSOffer',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSOfferResponse),
        )
    self.addDMSTransaction = channel.unary_unary(
        '/DmsTranslationService/addDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddDMSTransactionResponse),
        )
    self.addManualDMSFolderActivityLogEntry = channel.unary_unary(
        '/DmsTranslationService/addManualDMSFolderActivityLogEntry',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddManualDMSFolderActivityLogEntryResponse),
        )
    self.addReferralDeal = channel.unary_unary(
        '/DmsTranslationService/addReferralDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddReferralDealResponse),
        )
    self.addUsersToGroups = channel.unary_unary(
        '/DmsTranslationService/addUsersToGroups',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddUsersToGroupsResponse),
        )
    self.batchAddAdminComplianceChecklistDocuments = channel.unary_unary(
        '/DmsTranslationService/batchAddAdminComplianceChecklistDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchAddAdminComplianceDocumentInternalResponse),
        )
    self.batchGetAdminComplianceChecklistGroups = channel.unary_unary(
        '/DmsTranslationService/batchGetAdminComplianceChecklistGroups',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetAdminComplianceChecklistGroupsResponse),
        )
    self.batchGetDMSFoldersOverview = channel.unary_unary(
        '/DmsTranslationService/batchGetDMSFoldersOverview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetDMSFoldersOverviewExtResponse),
        )
    self.batchGetDMSSpecificListingPageInfo = channel.unary_unary(
        '/DmsTranslationService/batchGetDMSSpecificListingPageInfo',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchGetDMSSpecificListingPageInfoResponse),
        )
    self.batchUpsertAdminComplianceChecklistCriteria = channel.unary_unary(
        '/DmsTranslationService/batchUpsertAdminComplianceChecklistCriteria',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistCriteriaResponse),
        )
    self.batchUpsertAdminComplianceChecklistCriteriaRelations = channel.unary_unary(
        '/DmsTranslationService/batchUpsertAdminComplianceChecklistCriteriaRelations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistCriteriaRelationResponse),
        )
    self.batchUpsertAdminComplianceChecklistDocuments = channel.unary_unary(
        '/DmsTranslationService/batchUpsertAdminComplianceChecklistDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceDocumentInternalResponse),
        )
    self.batchUpsertAdminComplianceChecklists = channel.unary_unary(
        '/DmsTranslationService/batchUpsertAdminComplianceChecklists',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistResponse),
        )
    self.calculateCommissionsAndAllocations = channel.unary_unary(
        '/DmsTranslationService/calculateCommissionsAndAllocations',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.UpdateClosingResponse),
        )
    self.checkDMSAccess = channel.unary_unary(
        '/DmsTranslationService/checkDMSAccess',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CheckDMSAccessResponse),
        )
    self.claimDeal = channel.unary_unary(
        '/DmsTranslationService/claimDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ClaimDealResponse),
        )
    self.convertDocumentToPdf = channel.unary_unary(
        '/DmsTranslationService/convertDocumentToPdf',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ConvertDocumentToPdfResponse),
        )
    self.createClosing = channel.unary_unary(
        '/DmsTranslationService/createClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.CreateClosingResponse),
        )
    self.createDMSFolder = channel.unary_unary(
        '/DmsTranslationService/createDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(CreateDMSFolderResponse),
        )
    self.deleteDMSFolder = channel.unary_unary(
        '/DmsTranslationService/deleteDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSFolderResponse),
        )
    self.deleteDMSListing = channel.unary_unary(
        '/DmsTranslationService/deleteDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSListingResponse),
        )
    self.deleteDMSOffer = channel.unary_unary(
        '/DmsTranslationService/deleteDMSOffer',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSOfferResponse),
        )
    self.deleteDMSTransaction = channel.unary_unary(
        '/DmsTranslationService/deleteDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionResponse),
        )
    self.editDocumentChecklistItems = channel.unary_unary(
        '/DmsTranslationService/editDocumentChecklistItems',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(EditDocumentChecklistItemsResponse),
        )
    self.filterDMSFolders = channel.unary_unary(
        '/DmsTranslationService/filterDMSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FilterDMSFoldersResponse),
        )
    self.filterDMSFoldersByAddress = channel.unary_unary(
        '/DmsTranslationService/filterDMSFoldersByAddress',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(FilterDMSFoldersByAddressResponse),
        )
    self.getActivityLogsForFolder = channel.unary_unary(
        '/DmsTranslationService/getActivityLogsForFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(dms_state_service.GetActivityLogsForFolderResponse),
        )
    self.getAdminComplianceChecklistDocuments = channel.unary_unary(
        '/DmsTranslationService/getAdminComplianceChecklistDocuments',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAdminComplianceChecklistDocumentsResponse),
        )
    self.getAgentSplit = channel.unary_unary(
        '/DmsTranslationService/getAgentSplit',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.GetAgentSplitResponse),
        )
    self.getAgentsInfoByTeamId = channel.unary_unary(
        '/DmsTranslationService/getAgentsInfoByTeamId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAgentsInfoByTeamIdResponse),
        )
    self.getAllDocumentUploadsByDmsFolderId = channel.unary_unary(
        '/DmsTranslationService/getAllDocumentUploadsByDmsFolderId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllDocumentUploadsByDmsFolderIdResponse),
        )
    self.getAllSubStage = channel.unary_unary(
        '/DmsTranslationService/getAllSubStage',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetAllSubStageResponse),
        )
    self.getCancelledDMSOffers = channel.unary_unary(
        '/DmsTranslationService/getCancelledDMSOffers',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetCancelledDMSOffersResponse),
        )
    self.getChecklist = channel.unary_unary(
        '/DmsTranslationService/getChecklist',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistResponse),
        )
    self.getChecklistAdminSettings = channel.unary_unary(
        '/DmsTranslationService/getChecklistAdminSettings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistAdminSettingsResponse),
        )
    self.getChecklistDebug = channel.unary_unary(
        '/DmsTranslationService/getChecklistDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistDebugResponse),
        )
    self.getChecklistItem = channel.unary_unary(
        '/DmsTranslationService/getChecklistItem',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetChecklistItemResponse),
        )
    self.getClosing = channel.unary_unary(
        '/DmsTranslationService/getClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(dms_state_service.GetClosingResponse),
        )
    self.getClosingForDms = channel.unary_unary(
        '/DmsTranslationService/getClosingForDms',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(dms_state_service.GetClosingResponse),
        )
    self.getComplianceChecklistItems = channel.unary_unary(
        '/DmsTranslationService/getComplianceChecklistItems',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetComplianceChecklistItemsExternalResponse),
        )
    self.getDMSClosing = channel.unary_unary(
        '/DmsTranslationService/getDMSClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSClosingResponse),
        )
    self.getDMSFolder = channel.unary_unary(
        '/DmsTranslationService/getDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderResponse),
        )
    self.getDMSFolderChecklistItems = channel.unary_unary(
        '/DmsTranslationService/getDMSFolderChecklistItems',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderChecklistItemsResponse),
        )
    self.getDMSFolderOverview = channel.unary_unary(
        '/DmsTranslationService/getDMSFolderOverview',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderOverviewResponse),
        )
    self.getDMSFolderSettings = channel.unary_unary(
        '/DmsTranslationService/getDMSFolderSettings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFolderSettingsResponse),
        )
    self.getDMSFoldersForBTByIdDebug = channel.unary_unary(
        '/DmsTranslationService/getDMSFoldersForBTByIdDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTByIdDebugResponse),
        )
    self.getDMSFoldersForBTDebug = channel.unary_unary(
        '/DmsTranslationService/getDMSFoldersForBTDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTDebugResponse),
        )
    self.getDMSListing = channel.unary_unary(
        '/DmsTranslationService/getDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSListingResponse),
        )
    self.getDMSListingImpactedFieldsForChecklist = channel.unary_unary(
        '/DmsTranslationService/getDMSListingImpactedFieldsForChecklist',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetImpactedFieldsForChecklistResponse),
        )
    self.getDMSOffer = channel.unary_unary(
        '/DmsTranslationService/getDMSOffer',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSOfferResponse),
        )
    self.getDMSOfferImpactedFieldsForChecklist = channel.unary_unary(
        '/DmsTranslationService/getDMSOfferImpactedFieldsForChecklist',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetImpactedFieldsForChecklistResponse),
        )
    self.getDMSSpecificListingPageInfo = channel.unary_unary(
        '/DmsTranslationService/getDMSSpecificListingPageInfo',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSSpecificListingPageInfoResponse),
        )
    self.getDMSTransaction = channel.unary_unary(
        '/DmsTranslationService/getDMSTransaction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDMSTransactionResponse),
        )
    self.getDRSEnrichedFolder = channel.unary_unary(
        '/DmsTranslationService/getDRSEnrichedFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDRSEnrichedFolderResponse),
        )
    self.getDRSFolders = channel.unary_unary(
        '/DmsTranslationService/getDRSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDRSFoldersResponse),
        )
    self.getDRSGroups = channel.unary_unary(
        '/DmsTranslationService/getDRSGroups',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDRSGroupsResponse),
        )
    self.getDmsSyncDetails = channel.unary_unary(
        '/DmsTranslationService/getDmsSyncDetails',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDmsSyncDetailsResponse),
        )
    self.getDmsTransactionDebug = channel.unary_unary(
        '/DmsTranslationService/getDmsTransactionDebug',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDmsTransactionDebugResponse),
        )
    self.getDocument = channel.unary_unary(
        '/DmsTranslationService/getDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDocumentResponse),
        )
    self.getDocumentListMetadata = channel.unary_unary(
        '/DmsTranslationService/getDocumentListMetadata',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetDocumentListMetadataResponse),
        )
    self.getNextAction = channel.unary_unary(
        '/DmsTranslationService/getNextAction',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetNextActionResponse),
        )
    self.getPreComplianceDMSFolders = channel.unary_unary(
        '/DmsTranslationService/getPreComplianceDMSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetPreComplianceDMSFoldersResponse),
        )
    self.getRegionSpecificPropertyTypes = channel.unary_unary(
        '/DmsTranslationService/getRegionSpecificPropertyTypes',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetRegionSpecificPropertyTypesResponse),
        )
    self.getStaffPermissionForTeam = channel.unary_unary(
        '/DmsTranslationService/getStaffPermissionForTeam',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetStaffPermissionForTeamResponse),
        )
    self.getTeamDmsFoldersMatchingLocation = channel.unary_unary(
        '/DmsTranslationService/getTeamDmsFoldersMatchingLocation',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetTeamDmsFoldersMatchingLocationResponse),
        )
    self.getUser = channel.unary_unary(
        '/DmsTranslationService/getUser',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(closings_service.GetUserResponse),
        )
    self.getWithdrawnDMSListings = channel.unary_unary(
        '/DmsTranslationService/getWithdrawnDMSListings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(GetWithdrawnDMSListingsResponse),
        )
    self.listDMSFolders = channel.unary_unary(
        '/DmsTranslationService/listDMSFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ListDMSFoldersResponse),
        )
    self.listGlideDocs = channel.unary_unary(
        '/DmsTranslationService/listGlideDocs',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ListGlideDocsResponse),
        )
    self.removeDocument = channel.unary_unary(
        '/DmsTranslationService/removeDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(RemoveDocumentResponse),
        )
    self.reviewDocument = channel.unary_unary(
        '/DmsTranslationService/reviewDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReviewDocumentResponse),
        )
    self.shareDMSFolder = channel.unary_unary(
        '/DmsTranslationService/shareDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ShareDMSFolderResponse),
        )
    self.sortDmsFolders = channel.unary_unary(
        '/DmsTranslationService/sortDmsFolders',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SortDmsFoldersResponse),
        )
    self.splitDocument = channel.unary_unary(
        '/DmsTranslationService/splitDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SplitDocumentResponse),
        )
    self.syncDmsResources = channel.unary_unary(
        '/DmsTranslationService/syncDmsResources',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DmsSyncExternalResponse),
        )
    self.unClaimDeal = channel.unary_unary(
        '/DmsTranslationService/unClaimDeal',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UnClaimDealResponse),
        )
    self.unshareDMSFolder = channel.unary_unary(
        '/DmsTranslationService/unshareDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UnshareDMSFolderResponse),
        )
    self.updateChecklistItem = channel.unary_unary(
        '/DmsTranslationService/updateChecklistItem',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateChecklistItemResponse),
        )
    self.updateClosing = channel.unary_unary(
        '/DmsTranslationService/updateClosing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(dms_state_service.UpdateClosingResponse),
        )
    self.updateClosingForDms = channel.unary_unary(
        '/DmsTranslationService/updateClosingForDms',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(dms_state_service.UpdateClosingResponse),
        )
    self.updateCurrentSubStage = channel.unary_unary(
        '/DmsTranslationService/updateCurrentSubStage',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSListingTransactionSubStageResponse),
        )
    self.updateDMSFolder = channel.unary_unary(
        '/DmsTranslationService/updateDMSFolder',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSFolderResponse),
        )
    self.updateDMSListing = channel.unary_unary(
        '/DmsTranslationService/updateDMSListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSListingResponse),
        )
    self.updateDMSOffer = channel.unary_unary(
        '/DmsTranslationService/updateDMSOffer',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateDMSOfferResponse),
        )
    self.updateReferralDetail = channel.unary_unary(
        '/DmsTranslationService/updateReferralDetail',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpdateReferralDetailResponse),
        )
    self.upsertCustomChecklistItemByItemId = channel.unary_unary(
        '/DmsTranslationService/upsertCustomChecklistItemByItemId',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpsertCustomChecklistItemByItemIdResponse),
        )
    self.upsertDocument = channel.unary_unary(
        '/DmsTranslationService/upsertDocument',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(UpsertDocumentResponse),
        )
    self.validateOneField = channel.unary_unary(
        '/DmsTranslationService/validateOneField',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(dms_state_service.ValidateOneFieldResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class DmsTranslationServiceServicer(BaseServiceServicer):
  """
    The DmsTranslationService Service definition
  """

  def addChecklistItemNote(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addCustomChecklistItem(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSOffer(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addManualDMSFolderActivityLogEntry(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addReferralDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addUsersToGroups(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchAddAdminComplianceChecklistDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetAdminComplianceChecklistGroups(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetDMSFoldersOverview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchGetDMSSpecificListingPageInfo(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertAdminComplianceChecklistCriteria(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertAdminComplianceChecklistCriteriaRelations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertAdminComplianceChecklistDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def batchUpsertAdminComplianceChecklists(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def calculateCommissionsAndAllocations(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def checkDMSAccess(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def claimDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def convertDocumentToPdf(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def createDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSOffer(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def editDocumentChecklistItems(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def filterDMSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def filterDMSFoldersByAddress(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getActivityLogsForFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAdminComplianceChecklistDocuments(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentSplit(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentsInfoByTeamId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllDocumentUploadsByDmsFolderId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAllSubStage(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getCancelledDMSOffers(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklist(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklistAdminSettings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklistDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getChecklistItem(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getClosingForDms(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getComplianceChecklistItems(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolderChecklistItems(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolderOverview(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFolderSettings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFoldersForBTByIdDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSFoldersForBTDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSListingImpactedFieldsForChecklist(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSOffer(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSOfferImpactedFieldsForChecklist(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSSpecificListingPageInfo(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDMSTransaction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDRSEnrichedFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDRSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDRSGroups(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDmsSyncDetails(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDmsTransactionDebug(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getDocumentListMetadata(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getNextAction(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getPreComplianceDMSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getRegionSpecificPropertyTypes(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getStaffPermissionForTeam(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeamDmsFoldersMatchingLocation(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getUser(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getWithdrawnDMSListings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def listDMSFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def listGlideDocs(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def removeDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def reviewDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def shareDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def sortDmsFolders(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def splitDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def syncDmsResources(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def unClaimDeal(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def unshareDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateChecklistItem(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateClosing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateClosingForDms(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateCurrentSubStage(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSFolder(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateDMSOffer(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def updateReferralDetail(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def upsertCustomChecklistItemByItemId(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def upsertDocument(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def validateOneField(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_DmsTranslationServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'addChecklistItemNote': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addChecklistItemNote(req),
          request_deserializer=_grpc_codec.deserializer(AddChecklistItemNoteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addCustomChecklistItem': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addCustomChecklistItem(req),
          request_deserializer=_grpc_codec.deserializer(AddCustomChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSOffer': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSOffer(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(AddDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addManualDMSFolderActivityLogEntry': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addManualDMSFolderActivityLogEntry(req),
          request_deserializer=_grpc_codec.deserializer(AddManualDMSFolderActivityLogEntryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addReferralDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addReferralDeal(req),
          request_deserializer=_grpc_codec.deserializer(AddReferralDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addUsersToGroups': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addUsersToGroups(req),
          request_deserializer=_grpc_codec.deserializer(AddUsersToGroupsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchAddAdminComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchAddAdminComplianceChecklistDocuments(req),
          request_deserializer=_grpc_codec.deserializer(BatchAddAdminComplianceDocumentInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetAdminComplianceChecklistGroups': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetAdminComplianceChecklistGroups(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetAdminComplianceChecklistGroupsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetDMSFoldersOverview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetDMSFoldersOverview(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetDMSFoldersOverviewExtRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetDMSSpecificListingPageInfo': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchGetDMSSpecificListingPageInfo(req),
          request_deserializer=_grpc_codec.deserializer(BatchGetDMSSpecificListingPageInfoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklistCriteria': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertAdminComplianceChecklistCriteria(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistCriteriaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklistCriteriaRelations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertAdminComplianceChecklistCriteriaRelations(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistCriteriaRelationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertAdminComplianceChecklistDocuments(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceDocumentInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklists': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.batchUpsertAdminComplianceChecklists(req),
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionsAndAllocations': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.calculateCommissionsAndAllocations(req),
          request_deserializer=_grpc_codec.deserializer(CommissionsAndAllocationsCalculationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkDMSAccess': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.checkDMSAccess(req),
          request_deserializer=_grpc_codec.deserializer(CheckDMSAccessRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'claimDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.claimDeal(req),
          request_deserializer=_grpc_codec.deserializer(ClaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'convertDocumentToPdf': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.convertDocumentToPdf(req),
          request_deserializer=_grpc_codec.deserializer(ConvertDocumentToPdfRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createClosing(req),
          request_deserializer=_grpc_codec.deserializer(CreateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.createDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(CreateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSOffer': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSOffer(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'editDocumentChecklistItems': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.editDocumentChecklistItems(req),
          request_deserializer=_grpc_codec.deserializer(EditDocumentChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.filterDMSFolders(req),
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFoldersByAddress': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.filterDMSFoldersByAddress(req),
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getActivityLogsForFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getActivityLogsForFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetActivityLogsForFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAdminComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAdminComplianceChecklistDocuments(req),
          request_deserializer=_grpc_codec.deserializer(GetAdminComplianceChecklistDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentSplit': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentSplit(req),
          request_deserializer=_grpc_codec.deserializer(GetAgentSplitRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentsInfoByTeamId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentsInfoByTeamId(req),
          request_deserializer=_grpc_codec.deserializer(GetAgentsInfoByTeamIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllDocumentUploadsByDmsFolderId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllDocumentUploadsByDmsFolderId(req),
          request_deserializer=_grpc_codec.deserializer(GetAllDocumentUploadsByDmsFolderIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllSubStage': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAllSubStage(req),
          request_deserializer=_grpc_codec.deserializer(GetAllSubStageRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCancelledDMSOffers': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getCancelledDMSOffers(req),
          request_deserializer=_grpc_codec.deserializer(GetCancelledDMSOffersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklist': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklist(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistAdminSettings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklistAdminSettings(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistAdminSettingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklistDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistItem': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getChecklistItem(req),
          request_deserializer=_grpc_codec.deserializer(GetChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getClosing(req),
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosingForDms': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getClosingForDms(req),
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceChecklistItems': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getComplianceChecklistItems(req),
          request_deserializer=_grpc_codec.deserializer(GetComplianceChecklistItemsExternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSClosing(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderChecklistItems': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolderChecklistItems(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderOverview': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolderOverview(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderOverviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderSettings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFolderSettings(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderSettingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTByIdDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFoldersForBTByIdDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTByIdDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSFoldersForBTDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSListingImpactedFieldsForChecklist': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSListingImpactedFieldsForChecklist(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSOffer': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSOffer(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSOfferImpactedFieldsForChecklist': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSOfferImpactedFieldsForChecklist(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSSpecificListingPageInfo': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSSpecificListingPageInfo(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSSpecificListingPageInfoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSTransaction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDMSTransaction(req),
          request_deserializer=_grpc_codec.deserializer(GetDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDRSEnrichedFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDRSEnrichedFolder(req),
          request_deserializer=_grpc_codec.deserializer(GetDRSEnrichedFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDRSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDRSFolders(req),
          request_deserializer=_grpc_codec.deserializer(GetDRSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDRSGroups': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDRSGroups(req),
          request_deserializer=_grpc_codec.deserializer(GetDRSGroupsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsSyncDetails': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDmsSyncDetails(req),
          request_deserializer=_grpc_codec.deserializer(GetDmsSyncDetailsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsTransactionDebug': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDmsTransactionDebug(req),
          request_deserializer=_grpc_codec.deserializer(GetDmsTransactionDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDocument(req),
          request_deserializer=_grpc_codec.deserializer(GetDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocumentListMetadata': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getDocumentListMetadata(req),
          request_deserializer=_grpc_codec.deserializer(GetDocumentListMetadataRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getNextAction': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getNextAction(req),
          request_deserializer=_grpc_codec.deserializer(GetNextActionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPreComplianceDMSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getPreComplianceDMSFolders(req),
          request_deserializer=_grpc_codec.deserializer(GetPreComplianceDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getRegionSpecificPropertyTypes': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getRegionSpecificPropertyTypes(req),
          request_deserializer=_grpc_codec.deserializer(GetRegionSpecificPropertyTypesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getStaffPermissionForTeam': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getStaffPermissionForTeam(req),
          request_deserializer=_grpc_codec.deserializer(GetStaffPermissionForTeamRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamDmsFoldersMatchingLocation': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeamDmsFoldersMatchingLocation(req),
          request_deserializer=_grpc_codec.deserializer(GetTeamDmsFoldersMatchingLocationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getUser(req),
          request_deserializer=_grpc_codec.deserializer(GetUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getWithdrawnDMSListings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getWithdrawnDMSListings(req),
          request_deserializer=_grpc_codec.deserializer(GetWithdrawnDMSListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listDMSFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.listDMSFolders(req),
          request_deserializer=_grpc_codec.deserializer(ListDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listGlideDocs': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.listGlideDocs(req),
          request_deserializer=_grpc_codec.deserializer(ListGlideDocsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'removeDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.removeDocument(req),
          request_deserializer=_grpc_codec.deserializer(RemoveDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reviewDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reviewDocument(req),
          request_deserializer=_grpc_codec.deserializer(ReviewDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'shareDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.shareDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(ShareDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'sortDmsFolders': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.sortDmsFolders(req),
          request_deserializer=_grpc_codec.deserializer(SortDmsFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'splitDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.splitDocument(req),
          request_deserializer=_grpc_codec.deserializer(SplitDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'syncDmsResources': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.syncDmsResources(req),
          request_deserializer=_grpc_codec.deserializer(DmsSyncExternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unClaimDeal': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.unClaimDeal(req),
          request_deserializer=_grpc_codec.deserializer(UnClaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unshareDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.unshareDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(UnshareDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateChecklistItem': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateChecklistItem(req),
          request_deserializer=_grpc_codec.deserializer(UpdateChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateClosing(req),
          request_deserializer=_grpc_codec.deserializer(UpdateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosingForDms': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateClosingForDms(req),
          request_deserializer=_grpc_codec.deserializer(UpdateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateCurrentSubStage': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateCurrentSubStage(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingTransactionSubStageRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSFolder': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSFolder(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSListing(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSOffer': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateDMSOffer(req),
          request_deserializer=_grpc_codec.deserializer(UpdateDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateReferralDetail': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.updateReferralDetail(req),
          request_deserializer=_grpc_codec.deserializer(UpdateReferralDetailRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertCustomChecklistItemByItemId': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.upsertCustomChecklistItemByItemId(req),
          request_deserializer=_grpc_codec.deserializer(UpsertCustomChecklistItemByItemIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertDocument': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.upsertDocument(req),
          request_deserializer=_grpc_codec.deserializer(UpsertDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'validateOneField': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.validateOneField(req),
          request_deserializer=_grpc_codec.deserializer(ValidateOneFieldRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsTranslationService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_DmsTranslationServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'addChecklistItemNote': grpc.unary_unary_rpc_method_handler(
          servicer.addChecklistItemNote,
          request_deserializer=_grpc_codec.deserializer(AddChecklistItemNoteRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addCustomChecklistItem': grpc.unary_unary_rpc_method_handler(
          servicer.addCustomChecklistItem,
          request_deserializer=_grpc_codec.deserializer(AddCustomChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSListing,
          request_deserializer=_grpc_codec.deserializer(AddDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSOffer': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSOffer,
          request_deserializer=_grpc_codec.deserializer(AddDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.addDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(AddDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addManualDMSFolderActivityLogEntry': grpc.unary_unary_rpc_method_handler(
          servicer.addManualDMSFolderActivityLogEntry,
          request_deserializer=_grpc_codec.deserializer(AddManualDMSFolderActivityLogEntryRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addReferralDeal': grpc.unary_unary_rpc_method_handler(
          servicer.addReferralDeal,
          request_deserializer=_grpc_codec.deserializer(AddReferralDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addUsersToGroups': grpc.unary_unary_rpc_method_handler(
          servicer.addUsersToGroups,
          request_deserializer=_grpc_codec.deserializer(AddUsersToGroupsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchAddAdminComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.batchAddAdminComplianceChecklistDocuments,
          request_deserializer=_grpc_codec.deserializer(BatchAddAdminComplianceDocumentInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetAdminComplianceChecklistGroups': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetAdminComplianceChecklistGroups,
          request_deserializer=_grpc_codec.deserializer(BatchGetAdminComplianceChecklistGroupsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetDMSFoldersOverview': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetDMSFoldersOverview,
          request_deserializer=_grpc_codec.deserializer(BatchGetDMSFoldersOverviewExtRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchGetDMSSpecificListingPageInfo': grpc.unary_unary_rpc_method_handler(
          servicer.batchGetDMSSpecificListingPageInfo,
          request_deserializer=_grpc_codec.deserializer(BatchGetDMSSpecificListingPageInfoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklistCriteria': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertAdminComplianceChecklistCriteria,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistCriteriaRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklistCriteriaRelations': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertAdminComplianceChecklistCriteriaRelations,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistCriteriaRelationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertAdminComplianceChecklistDocuments,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceDocumentInternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'batchUpsertAdminComplianceChecklists': grpc.unary_unary_rpc_method_handler(
          servicer.batchUpsertAdminComplianceChecklists,
          request_deserializer=_grpc_codec.deserializer(BatchUpsertAdminComplianceChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'calculateCommissionsAndAllocations': grpc.unary_unary_rpc_method_handler(
          servicer.calculateCommissionsAndAllocations,
          request_deserializer=_grpc_codec.deserializer(CommissionsAndAllocationsCalculationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'checkDMSAccess': grpc.unary_unary_rpc_method_handler(
          servicer.checkDMSAccess,
          request_deserializer=_grpc_codec.deserializer(CheckDMSAccessRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'claimDeal': grpc.unary_unary_rpc_method_handler(
          servicer.claimDeal,
          request_deserializer=_grpc_codec.deserializer(ClaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'convertDocumentToPdf': grpc.unary_unary_rpc_method_handler(
          servicer.convertDocumentToPdf,
          request_deserializer=_grpc_codec.deserializer(ConvertDocumentToPdfRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createClosing': grpc.unary_unary_rpc_method_handler(
          servicer.createClosing,
          request_deserializer=_grpc_codec.deserializer(CreateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'createDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.createDMSFolder,
          request_deserializer=_grpc_codec.deserializer(CreateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSFolder,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSListing,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSOffer': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSOffer,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.deleteDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(DeleteDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'editDocumentChecklistItems': grpc.unary_unary_rpc_method_handler(
          servicer.editDocumentChecklistItems,
          request_deserializer=_grpc_codec.deserializer(EditDocumentChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.filterDMSFolders,
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'filterDMSFoldersByAddress': grpc.unary_unary_rpc_method_handler(
          servicer.filterDMSFoldersByAddress,
          request_deserializer=_grpc_codec.deserializer(FilterDMSFoldersByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getActivityLogsForFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getActivityLogsForFolder,
          request_deserializer=_grpc_codec.deserializer(GetActivityLogsForFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAdminComplianceChecklistDocuments': grpc.unary_unary_rpc_method_handler(
          servicer.getAdminComplianceChecklistDocuments,
          request_deserializer=_grpc_codec.deserializer(GetAdminComplianceChecklistDocumentsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentSplit': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentSplit,
          request_deserializer=_grpc_codec.deserializer(GetAgentSplitRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentsInfoByTeamId': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentsInfoByTeamId,
          request_deserializer=_grpc_codec.deserializer(GetAgentsInfoByTeamIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllDocumentUploadsByDmsFolderId': grpc.unary_unary_rpc_method_handler(
          servicer.getAllDocumentUploadsByDmsFolderId,
          request_deserializer=_grpc_codec.deserializer(GetAllDocumentUploadsByDmsFolderIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAllSubStage': grpc.unary_unary_rpc_method_handler(
          servicer.getAllSubStage,
          request_deserializer=_grpc_codec.deserializer(GetAllSubStageRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getCancelledDMSOffers': grpc.unary_unary_rpc_method_handler(
          servicer.getCancelledDMSOffers,
          request_deserializer=_grpc_codec.deserializer(GetCancelledDMSOffersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklist': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklist,
          request_deserializer=_grpc_codec.deserializer(GetChecklistRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistAdminSettings': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklistAdminSettings,
          request_deserializer=_grpc_codec.deserializer(GetChecklistAdminSettingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklistDebug,
          request_deserializer=_grpc_codec.deserializer(GetChecklistDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getChecklistItem': grpc.unary_unary_rpc_method_handler(
          servicer.getChecklistItem,
          request_deserializer=_grpc_codec.deserializer(GetChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosing': grpc.unary_unary_rpc_method_handler(
          servicer.getClosing,
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getClosingForDms': grpc.unary_unary_rpc_method_handler(
          servicer.getClosingForDms,
          request_deserializer=_grpc_codec.deserializer(GetClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getComplianceChecklistItems': grpc.unary_unary_rpc_method_handler(
          servicer.getComplianceChecklistItems,
          request_deserializer=_grpc_codec.deserializer(GetComplianceChecklistItemsExternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSClosing': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSClosing,
          request_deserializer=_grpc_codec.deserializer(GetDMSClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolder,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderChecklistItems': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolderChecklistItems,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderChecklistItemsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderOverview': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolderOverview,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderOverviewRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFolderSettings': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFolderSettings,
          request_deserializer=_grpc_codec.deserializer(GetDMSFolderSettingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTByIdDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFoldersForBTByIdDebug,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTByIdDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSFoldersForBTDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSFoldersForBTDebug,
          request_deserializer=_grpc_codec.deserializer(GetDMSFoldersForBTDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSListing,
          request_deserializer=_grpc_codec.deserializer(GetDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSListingImpactedFieldsForChecklist': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSListingImpactedFieldsForChecklist,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSOffer': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSOffer,
          request_deserializer=_grpc_codec.deserializer(GetDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSOfferImpactedFieldsForChecklist': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSOfferImpactedFieldsForChecklist,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSSpecificListingPageInfo': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSSpecificListingPageInfo,
          request_deserializer=_grpc_codec.deserializer(GetDMSSpecificListingPageInfoRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDMSTransaction': grpc.unary_unary_rpc_method_handler(
          servicer.getDMSTransaction,
          request_deserializer=_grpc_codec.deserializer(GetDMSTransactionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDRSEnrichedFolder': grpc.unary_unary_rpc_method_handler(
          servicer.getDRSEnrichedFolder,
          request_deserializer=_grpc_codec.deserializer(GetDRSEnrichedFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDRSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.getDRSFolders,
          request_deserializer=_grpc_codec.deserializer(GetDRSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDRSGroups': grpc.unary_unary_rpc_method_handler(
          servicer.getDRSGroups,
          request_deserializer=_grpc_codec.deserializer(GetDRSGroupsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsSyncDetails': grpc.unary_unary_rpc_method_handler(
          servicer.getDmsSyncDetails,
          request_deserializer=_grpc_codec.deserializer(GetDmsSyncDetailsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDmsTransactionDebug': grpc.unary_unary_rpc_method_handler(
          servicer.getDmsTransactionDebug,
          request_deserializer=_grpc_codec.deserializer(GetDmsTransactionDebugRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocument': grpc.unary_unary_rpc_method_handler(
          servicer.getDocument,
          request_deserializer=_grpc_codec.deserializer(GetDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getDocumentListMetadata': grpc.unary_unary_rpc_method_handler(
          servicer.getDocumentListMetadata,
          request_deserializer=_grpc_codec.deserializer(GetDocumentListMetadataRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getNextAction': grpc.unary_unary_rpc_method_handler(
          servicer.getNextAction,
          request_deserializer=_grpc_codec.deserializer(GetNextActionRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getPreComplianceDMSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.getPreComplianceDMSFolders,
          request_deserializer=_grpc_codec.deserializer(GetPreComplianceDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getRegionSpecificPropertyTypes': grpc.unary_unary_rpc_method_handler(
          servicer.getRegionSpecificPropertyTypes,
          request_deserializer=_grpc_codec.deserializer(GetRegionSpecificPropertyTypesRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getStaffPermissionForTeam': grpc.unary_unary_rpc_method_handler(
          servicer.getStaffPermissionForTeam,
          request_deserializer=_grpc_codec.deserializer(GetStaffPermissionForTeamRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamDmsFoldersMatchingLocation': grpc.unary_unary_rpc_method_handler(
          servicer.getTeamDmsFoldersMatchingLocation,
          request_deserializer=_grpc_codec.deserializer(GetTeamDmsFoldersMatchingLocationRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getUser': grpc.unary_unary_rpc_method_handler(
          servicer.getUser,
          request_deserializer=_grpc_codec.deserializer(GetUserRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getWithdrawnDMSListings': grpc.unary_unary_rpc_method_handler(
          servicer.getWithdrawnDMSListings,
          request_deserializer=_grpc_codec.deserializer(GetWithdrawnDMSListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listDMSFolders': grpc.unary_unary_rpc_method_handler(
          servicer.listDMSFolders,
          request_deserializer=_grpc_codec.deserializer(ListDMSFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'listGlideDocs': grpc.unary_unary_rpc_method_handler(
          servicer.listGlideDocs,
          request_deserializer=_grpc_codec.deserializer(ListGlideDocsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'removeDocument': grpc.unary_unary_rpc_method_handler(
          servicer.removeDocument,
          request_deserializer=_grpc_codec.deserializer(RemoveDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reviewDocument': grpc.unary_unary_rpc_method_handler(
          servicer.reviewDocument,
          request_deserializer=_grpc_codec.deserializer(ReviewDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'shareDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.shareDMSFolder,
          request_deserializer=_grpc_codec.deserializer(ShareDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'sortDmsFolders': grpc.unary_unary_rpc_method_handler(
          servicer.sortDmsFolders,
          request_deserializer=_grpc_codec.deserializer(SortDmsFoldersRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'splitDocument': grpc.unary_unary_rpc_method_handler(
          servicer.splitDocument,
          request_deserializer=_grpc_codec.deserializer(SplitDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'syncDmsResources': grpc.unary_unary_rpc_method_handler(
          servicer.syncDmsResources,
          request_deserializer=_grpc_codec.deserializer(DmsSyncExternalRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unClaimDeal': grpc.unary_unary_rpc_method_handler(
          servicer.unClaimDeal,
          request_deserializer=_grpc_codec.deserializer(UnClaimDealRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'unshareDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.unshareDMSFolder,
          request_deserializer=_grpc_codec.deserializer(UnshareDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateChecklistItem': grpc.unary_unary_rpc_method_handler(
          servicer.updateChecklistItem,
          request_deserializer=_grpc_codec.deserializer(UpdateChecklistItemRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosing': grpc.unary_unary_rpc_method_handler(
          servicer.updateClosing,
          request_deserializer=_grpc_codec.deserializer(UpdateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateClosingForDms': grpc.unary_unary_rpc_method_handler(
          servicer.updateClosingForDms,
          request_deserializer=_grpc_codec.deserializer(UpdateClosingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateCurrentSubStage': grpc.unary_unary_rpc_method_handler(
          servicer.updateCurrentSubStage,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingTransactionSubStageRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSFolder': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSFolder,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSFolderRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSListing': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSListing,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateDMSOffer': grpc.unary_unary_rpc_method_handler(
          servicer.updateDMSOffer,
          request_deserializer=_grpc_codec.deserializer(UpdateDMSOfferRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'updateReferralDetail': grpc.unary_unary_rpc_method_handler(
          servicer.updateReferralDetail,
          request_deserializer=_grpc_codec.deserializer(UpdateReferralDetailRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertCustomChecklistItemByItemId': grpc.unary_unary_rpc_method_handler(
          servicer.upsertCustomChecklistItemByItemId,
          request_deserializer=_grpc_codec.deserializer(UpsertCustomChecklistItemByItemIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'upsertDocument': grpc.unary_unary_rpc_method_handler(
          servicer.upsertDocument,
          request_deserializer=_grpc_codec.deserializer(UpsertDocumentRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'validateOneField': grpc.unary_unary_rpc_method_handler(
          servicer.validateOneField,
          request_deserializer=_grpc_codec.deserializer(ValidateOneFieldRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'DmsTranslationService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

