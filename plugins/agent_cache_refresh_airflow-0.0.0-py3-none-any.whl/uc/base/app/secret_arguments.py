# -*- coding: utf-8 -*-
"""
:copyright: (c) 2018 by Urban Compass, Inc.
"""
import argparse
import logging

from uc.aws import secrets_manager


class SecretReader(object):
    """Reader for Secrets Manager."""

    def __init__(self, secret, env=None):
        """
        :param secret: The secret configuration string.
        :param env: The environment to read from, if not given, injected in base/app
        """
        assert isinstance(secret, str)
        self._secret = secret
        self._env = env

    def __repr__(self):
        return "SecretReader(secret={}, env={})".format(self._secret, self._env or "")

    def __eq__(self, other):
        return (
            isinstance(other, self.__class__)
            and self._secret == other._secret
            and self._env == other._env
        )

    def __hash__(self):
        return hash((self._secret, self._env))

    def read(self, env=None, assume_role=None):
        """
        Get the secret value for the given environment.
        :param env: Ignored if the secret starts with no_env_secret.
        :param assume_role: ARN of AWS IAM role to assume via which to access resources.
        :return: The secret for the environment.
        :raise: Exception if the secret for the environment is not found in the section.
        """
        if not self._secret.startswith(("secret:", "no_env_secret:")):
            return self._secret

        try:
            secret_type, secret_name, secret_key = self._secret.split(":")
        except ValueError:
            # We consciously choose to ignore the error because it can only be a value unpack error.
            raise ValueError(
                "Badly formatted secret definition. Format: "
                "[secret|no_env_secret]:[secret-name]:[secret-key]"
            )
        needs_env = secret_type != "no_env_secret"
        if needs_env:
            env = self._env or env or ""
            assert (
                env != ""
            ), "Expected an environment to be set for environment-based secret: {}".format(
                self._secret
            )
            secret_name = "{}.{}".format(secret_name, env)
        try:
            secret = secrets_manager.get_secret(secret_name, assume_role=assume_role)
        except Exception:
            logging.error(
                "Encountered an exception while retrieving secret: {}".format(secret_name)
            )
            raise
        return secret[secret_key]


class SecretAction(argparse.Action):
    """
    Custom action to pull a secret from Secrets Manager

    The value should be a plain string or a magic string that starts with:
    secret: for an environment specific secret
    no_env_secret: for an environment-agnostic secret (only one value across all environments)
    """

    def __init__(self, option_strings, dest, nargs=None, default=None, **kwargs):
        if nargs is not None:
            raise ValueError("nargs not allowed")
        super(SecretAction, self).__init__(option_strings, dest, **kwargs)
        self.nargs = nargs
        if default is not None and not isinstance(default, SecretReader):
            default = SecretReader(default)
        self.default = default

    def __call__(self, parser, namespace, values, option_string=None):
        if not isinstance(values, str) and not isinstance(values, SecretReader):
            raise ValueError("Value must be a string or SecretReader")
        if not isinstance(values, SecretReader):
            values = SecretReader(values)
        setattr(namespace, self.dest, values)


def add_secret_argument(parser, name, **kwargs):
    """
    Add a command line argument pair to allow a value to be pulled from Secrets Manager

    Code looks like this:
    parser = argparse.ArgumentParser(description='Test')
    secret_arguments.add_secret_argument(parser, 'test')

    CLI args look like this:
    ./shorts run test.py --test no_env_secret:compass.app.mongo.readOnly:password

    :param argparse.ArgumentParser parser: argument parser
    :param string name: secret name
    :param kwargs: additional parameters to ArgumentParser.add_argument
    """
    if kwargs.get("type") is not None:
        raise ValueError("Invalid argument for add_secret_argument: type=%r" % kwargs["type"])
    if not name.startswith("--"):
        name = "--{}".format(name)
    help = [
        kwargs.get("help"),
        "(default={})".format(kwargs.get("default", "None")),
        "{}=a string value or (secret|no_env_secret):secret_name:secret_key".format(name),
    ]
    kwargs["help"] = " ".join([_f for _f in help if _f])
    parser.add_argument(name, action=SecretAction, **kwargs)


def read_secrets_into_parsed_namespace(namespace):
    """
    Replaces secret reader attributes in given the argparse namespace with the actual secret.
    Note: *This method mutates the given namespace object!*
    :type namespace: argparse.Namespace
    """
    assume_role = getattr(namespace, "base_app_assume_role", None)
    for k, v in list(vars(namespace).items()):
        if isinstance(v, SecretReader):
            setattr(namespace, k, v.read(env=namespace.env, assume_role=assume_role))
