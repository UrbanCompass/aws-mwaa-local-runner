
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
DMS_LISTING_TRANSACTION_SUB_STAGES = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    17,
    18,
    19,
]
LISTING_PROPERTY_TYPES = {
    "co-op": 0,
    "condo": 1,
    "condop": 2,
    "land": 3,
    "mixed use": 4,
    "mobile/manufactured": 5,
    "multi family": 6,
    "non-residential": 7,
    "other": 8,
    "rental": 9,
    "single family": 10,
    "townhouse": 11,
    "residential": 12,
}
