
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.apex.lead_generation_api.ttypes

from thrift.transport import TTransport


class AgentType(object):
    UNDEFINED = 0
    BUYER = 1
    SELLER = 2

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "BUYER",
        2: "SELLER",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "BUYER": 1,
        "SELLER": 2,
    }


class CommissionType(object):
    UNDEFINED = 0
    FLAT = 1
    PERCENTAGE = 2

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "FLAT",
        2: "PERCENTAGE",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "FLAT": 1,
        "PERCENTAGE": 2,
    }


class ClosingFees(object):
    """
    Attributes:
     - name
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
    )
    def __init__(self, name=None, value=None, ):
        self.name = name
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ClosingFees')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Commission(object):
    """
    Attributes:
     - type
     - value
     - min
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'min', None, None, ),  # 3
    )
    def __init__(self, type=None, value=None, min=None, ):
        self.type = type
        self.value = value
        self.min = min

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.min = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Commission')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        if self.min is not None:
            oprot.writeFieldBegin('min', TType.BOOL, 3)
            oprot.writeBool(self.min)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EquityInfo(object):
    """
    Attributes:
     - salePrice
     - mortgageBalance
     - netEquity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'salePrice', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'mortgageBalance', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'netEquity', 'UTF8', None, ),  # 3
    )
    def __init__(self, salePrice=None, mortgageBalance=None, netEquity=None, ):
        self.salePrice = salePrice
        self.mortgageBalance = mortgageBalance
        self.netEquity = netEquity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.salePrice = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.mortgageBalance = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.netEquity = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EquityInfo')
        if self.salePrice is not None:
            oprot.writeFieldBegin('salePrice', TType.STRING, 1)
            oprot.writeString(self.salePrice.encode('utf-8') if sys.version_info[0] == 2 else self.salePrice)
            oprot.writeFieldEnd()
        if self.mortgageBalance is not None:
            oprot.writeFieldBegin('mortgageBalance', TType.STRING, 2)
            oprot.writeString(self.mortgageBalance.encode('utf-8') if sys.version_info[0] == 2 else self.mortgageBalance)
            oprot.writeFieldEnd()
        if self.netEquity is not None:
            oprot.writeFieldBegin('netEquity', TType.STRING, 3)
            oprot.writeString(self.netEquity.encode('utf-8') if sys.version_info[0] == 2 else self.netEquity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LineItem(object):
    """
    Attributes:
     - name
     - description
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'description', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'amount', 'UTF8', None, ),  # 3
    )
    def __init__(self, name=None, description=None, amount=None, ):
        self.name = name
        self.description = description
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.description = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.description.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.amount = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LineItem')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.description))
            for _iter11 in self.description:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.STRING, 3)
            oprot.writeString(self.amount.encode('utf-8') if sys.version_info[0] == 2 else self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ProratedPropertyTax(object):
    """
    Attributes:
     - liabilityType
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'liabilityType', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'amount', 'UTF8', None, ),  # 2
    )
    def __init__(self, liabilityType=None, amount=None, ):
        self.liabilityType = liabilityType
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.liabilityType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.amount = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ProratedPropertyTax')
        if self.liabilityType is not None:
            oprot.writeFieldBegin('liabilityType', TType.STRING, 1)
            oprot.writeString(self.liabilityType.encode('utf-8') if sys.version_info[0] == 2 else self.liabilityType)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.STRING, 2)
            oprot.writeString(self.amount.encode('utf-8') if sys.version_info[0] == 2 else self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentCommission(object):
    """
    Attributes:
     - type
     - commissions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.LIST, 'commissions', (TType.STRUCT, (Commission, Commission.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, type=None, commissions=None, ):
        self.type = type
        self.commissions = commissions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.commissions = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = Commission()
                        _elem14.read(iprot)
                        self.commissions.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentCommission')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.commissions is not None:
            oprot.writeFieldBegin('commissions', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.commissions))
            for _iter16 in self.commissions:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PartnerNetproceedsRequest(object):
    """
    Attributes:
     - state
     - county
     - city
     - escrowRegion
     - contractType
     - serviceType
     - salePrice
     - loanAmount
     - mortgageBalance
     - propertyTax
     - estoppelFee
     - settlementDate
     - buyerAgentCommissionRate
     - sellerAgentCommissionRate
     - additionalLineItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'state', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'county', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'city', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'escrowRegion', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'contractType', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'serviceType', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'salePrice', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'loanAmount', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'mortgageBalance', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'propertyTax', 'UTF8', None, ),  # 10
        (11, TType.BOOL, 'estoppelFee', None, None, ),  # 11
        (12, TType.STRING, 'settlementDate', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'buyerAgentCommissionRate', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'sellerAgentCommissionRate', 'UTF8', None, ),  # 14
        (15, TType.LIST, 'additionalLineItems', (TType.STRUCT, (LineItem, LineItem.thrift_spec), False), None, ),  # 15
    )
    def __init__(self, state=None, county=None, city=None, escrowRegion=None, contractType=None, serviceType=None, salePrice=None, loanAmount=None, mortgageBalance=None, propertyTax=None, estoppelFee=None, settlementDate=None, buyerAgentCommissionRate=None, sellerAgentCommissionRate=None, additionalLineItems=None, ):
        self.state = state
        self.county = county
        self.city = city
        self.escrowRegion = escrowRegion
        self.contractType = contractType
        self.serviceType = serviceType
        self.salePrice = salePrice
        self.loanAmount = loanAmount
        self.mortgageBalance = mortgageBalance
        self.propertyTax = propertyTax
        self.estoppelFee = estoppelFee
        self.settlementDate = settlementDate
        self.buyerAgentCommissionRate = buyerAgentCommissionRate
        self.sellerAgentCommissionRate = sellerAgentCommissionRate
        self.additionalLineItems = additionalLineItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.county = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.escrowRegion = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.contractType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.serviceType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.salePrice = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.loanAmount = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.mortgageBalance = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.propertyTax = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.estoppelFee = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.settlementDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.buyerAgentCommissionRate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.sellerAgentCommissionRate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.additionalLineItems = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = LineItem()
                        _elem19.read(iprot)
                        self.additionalLineItems.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PartnerNetproceedsRequest')
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 1)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.county is not None:
            oprot.writeFieldBegin('county', TType.STRING, 2)
            oprot.writeString(self.county.encode('utf-8') if sys.version_info[0] == 2 else self.county)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 3)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.escrowRegion is not None:
            oprot.writeFieldBegin('escrowRegion', TType.STRING, 4)
            oprot.writeString(self.escrowRegion.encode('utf-8') if sys.version_info[0] == 2 else self.escrowRegion)
            oprot.writeFieldEnd()
        if self.contractType is not None:
            oprot.writeFieldBegin('contractType', TType.STRING, 5)
            oprot.writeString(self.contractType.encode('utf-8') if sys.version_info[0] == 2 else self.contractType)
            oprot.writeFieldEnd()
        if self.serviceType is not None:
            oprot.writeFieldBegin('serviceType', TType.STRING, 6)
            oprot.writeString(self.serviceType.encode('utf-8') if sys.version_info[0] == 2 else self.serviceType)
            oprot.writeFieldEnd()
        if self.salePrice is not None:
            oprot.writeFieldBegin('salePrice', TType.STRING, 7)
            oprot.writeString(self.salePrice.encode('utf-8') if sys.version_info[0] == 2 else self.salePrice)
            oprot.writeFieldEnd()
        if self.loanAmount is not None:
            oprot.writeFieldBegin('loanAmount', TType.STRING, 8)
            oprot.writeString(self.loanAmount.encode('utf-8') if sys.version_info[0] == 2 else self.loanAmount)
            oprot.writeFieldEnd()
        if self.mortgageBalance is not None:
            oprot.writeFieldBegin('mortgageBalance', TType.STRING, 9)
            oprot.writeString(self.mortgageBalance.encode('utf-8') if sys.version_info[0] == 2 else self.mortgageBalance)
            oprot.writeFieldEnd()
        if self.propertyTax is not None:
            oprot.writeFieldBegin('propertyTax', TType.STRING, 10)
            oprot.writeString(self.propertyTax.encode('utf-8') if sys.version_info[0] == 2 else self.propertyTax)
            oprot.writeFieldEnd()
        if self.estoppelFee is not None:
            oprot.writeFieldBegin('estoppelFee', TType.BOOL, 11)
            oprot.writeBool(self.estoppelFee)
            oprot.writeFieldEnd()
        if self.settlementDate is not None:
            oprot.writeFieldBegin('settlementDate', TType.STRING, 12)
            oprot.writeString(self.settlementDate.encode('utf-8') if sys.version_info[0] == 2 else self.settlementDate)
            oprot.writeFieldEnd()
        if self.buyerAgentCommissionRate is not None:
            oprot.writeFieldBegin('buyerAgentCommissionRate', TType.STRING, 13)
            oprot.writeString(self.buyerAgentCommissionRate.encode('utf-8') if sys.version_info[0] == 2 else self.buyerAgentCommissionRate)
            oprot.writeFieldEnd()
        if self.sellerAgentCommissionRate is not None:
            oprot.writeFieldBegin('sellerAgentCommissionRate', TType.STRING, 14)
            oprot.writeString(self.sellerAgentCommissionRate.encode('utf-8') if sys.version_info[0] == 2 else self.sellerAgentCommissionRate)
            oprot.writeFieldEnd()
        if self.additionalLineItems is not None:
            oprot.writeFieldBegin('additionalLineItems', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.additionalLineItems))
            for _iter21 in self.additionalLineItems:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ResponseResult(object):
    """
    Attributes:
     - equityInfo
     - proratedPropertyTax
     - commissions
     - fees
     - additionalFees
     - totalNetProceeds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'equityInfo', (EquityInfo, EquityInfo.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'proratedPropertyTax', (ProratedPropertyTax, ProratedPropertyTax.thrift_spec), None, ),  # 2
        (3, TType.LIST, 'commissions', (TType.STRUCT, (LineItem, LineItem.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'fees', (TType.STRUCT, (LineItem, LineItem.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'additionalFees', (TType.STRUCT, (LineItem, LineItem.thrift_spec), False), None, ),  # 5
        (6, TType.STRING, 'totalNetProceeds', 'UTF8', None, ),  # 6
    )
    def __init__(self, equityInfo=None, proratedPropertyTax=None, commissions=None, fees=None, additionalFees=None, totalNetProceeds=None, ):
        self.equityInfo = equityInfo
        self.proratedPropertyTax = proratedPropertyTax
        self.commissions = commissions
        self.fees = fees
        self.additionalFees = additionalFees
        self.totalNetProceeds = totalNetProceeds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.equityInfo = EquityInfo()
                    self.equityInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.proratedPropertyTax = ProratedPropertyTax()
                    self.proratedPropertyTax.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.commissions = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = LineItem()
                        _elem24.read(iprot)
                        self.commissions.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.fees = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = LineItem()
                        _elem28.read(iprot)
                        self.fees.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.additionalFees = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = LineItem()
                        _elem32.read(iprot)
                        self.additionalFees.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.totalNetProceeds = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ResponseResult')
        if self.equityInfo is not None:
            oprot.writeFieldBegin('equityInfo', TType.STRUCT, 1)
            self.equityInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.proratedPropertyTax is not None:
            oprot.writeFieldBegin('proratedPropertyTax', TType.STRUCT, 2)
            self.proratedPropertyTax.write(oprot)
            oprot.writeFieldEnd()
        if self.commissions is not None:
            oprot.writeFieldBegin('commissions', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.commissions))
            for _iter34 in self.commissions:
                _iter34.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fees is not None:
            oprot.writeFieldBegin('fees', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.fees))
            for _iter35 in self.fees:
                _iter35.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.additionalFees is not None:
            oprot.writeFieldBegin('additionalFees', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.additionalFees))
            for _iter36 in self.additionalFees:
                _iter36.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalNetProceeds is not None:
            oprot.writeFieldBegin('totalNetProceeds', TType.STRING, 6)
            oprot.writeString(self.totalNetProceeds.encode('utf-8') if sys.version_info[0] == 2 else self.totalNetProceeds)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetSheetsInputs(object):
    """
    Attributes:
     - agentCommissions
     - sellerMortgageBalance
     - settlementDateMs
     - closingFees
     - partner
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'agentCommissions', (TType.STRUCT, (AgentCommission, AgentCommission.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'sellerMortgageBalance', 'UTF8', None, ),  # 2
        (3, TType.I64, 'settlementDateMs', None, None, ),  # 3
        (4, TType.LIST, 'closingFees', (TType.STRUCT, (ClosingFees, ClosingFees.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'partner', 'UTF8', None, ),  # 5
    )
    def __init__(self, agentCommissions=None, sellerMortgageBalance=None, settlementDateMs=None, closingFees=None, partner=None, ):
        self.agentCommissions = agentCommissions
        self.sellerMortgageBalance = sellerMortgageBalance
        self.settlementDateMs = settlementDateMs
        self.closingFees = closingFees
        self.partner = partner

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.agentCommissions = []
                    (_etype37, _size40) = iprot.readListBegin()
                    for _i38 in range(_size40):
                        _elem39 = AgentCommission()
                        _elem39.read(iprot)
                        self.agentCommissions.append(_elem39)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.sellerMortgageBalance = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.settlementDateMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.closingFees = []
                    (_etype41, _size44) = iprot.readListBegin()
                    for _i42 in range(_size44):
                        _elem43 = ClosingFees()
                        _elem43.read(iprot)
                        self.closingFees.append(_elem43)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.partner = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetSheetsInputs')
        if self.agentCommissions is not None:
            oprot.writeFieldBegin('agentCommissions', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.agentCommissions))
            for _iter45 in self.agentCommissions:
                _iter45.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.sellerMortgageBalance is not None:
            oprot.writeFieldBegin('sellerMortgageBalance', TType.STRING, 2)
            oprot.writeString(self.sellerMortgageBalance.encode('utf-8') if sys.version_info[0] == 2 else self.sellerMortgageBalance)
            oprot.writeFieldEnd()
        if self.settlementDateMs is not None:
            oprot.writeFieldBegin('settlementDateMs', TType.I64, 3)
            oprot.writeI64(self.settlementDateMs)
            oprot.writeFieldEnd()
        if self.closingFees is not None:
            oprot.writeFieldBegin('closingFees', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.closingFees))
            for _iter46 in self.closingFees:
                _iter46.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.partner is not None:
            oprot.writeFieldBegin('partner', TType.STRING, 5)
            oprot.writeString(self.partner.encode('utf-8') if sys.version_info[0] == 2 else self.partner)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetproceedsRequest(object):
    """
    Attributes:
     - partner
     - partnerNetProceedsRequest
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'partner', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'partnerNetProceedsRequest', (PartnerNetproceedsRequest, PartnerNetproceedsRequest.thrift_spec), None, ),  # 2
    )
    def __init__(self, partner=None, partnerNetProceedsRequest=None, ):
        self.partner = partner
        self.partnerNetProceedsRequest = partnerNetProceedsRequest

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.partner = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.partnerNetProceedsRequest = PartnerNetproceedsRequest()
                    self.partnerNetProceedsRequest.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetproceedsRequest')
        if self.partner is not None:
            oprot.writeFieldBegin('partner', TType.STRING, 1)
            oprot.writeString(self.partner.encode('utf-8') if sys.version_info[0] == 2 else self.partner)
            oprot.writeFieldEnd()
        if self.partnerNetProceedsRequest is not None:
            oprot.writeFieldBegin('partnerNetProceedsRequest', TType.STRUCT, 2)
            self.partnerNetProceedsRequest.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetproceedsResponse(object):
    """
    Attributes:
     - status
     - responseResult
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'responseResult', (ResponseResult, ResponseResult.thrift_spec), None, ),  # 2
    )
    def __init__(self, status=None, responseResult=None, ):
        self.status = status
        self.responseResult = responseResult

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.responseResult = ResponseResult()
                    self.responseResult.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetproceedsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.responseResult is not None:
            oprot.writeFieldBegin('responseResult', TType.STRUCT, 2)
            self.responseResult.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
