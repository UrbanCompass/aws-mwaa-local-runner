
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.closings.closings_service.ttypes
import gen.urbancompass.contacts.api.contact.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_document.ttypes
import gen.urbancompass.dms_event_publisher.ttypes
import gen.urbancompass.dms_common.dms_folder.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.region_compliance_checklist_db_helper.ttypes

from thrift.transport import TTransport


class DmsFolderSortingOption(object):
    DMS_CLOSE_DATE = 0
    DMS_PAYMENT_DATE = 1
    DMS_CLOSE_PRICE = 2
    DMS_COMPLIANCE_STATUS = 3
    DMS_COMMISSION_STATUS = 4

    _VALUES_TO_NAMES = {
        0: "DMS_CLOSE_DATE",
        1: "DMS_PAYMENT_DATE",
        2: "DMS_CLOSE_PRICE",
        3: "DMS_COMPLIANCE_STATUS",
        4: "DMS_COMMISSION_STATUS",
    }

    _NAMES_TO_VALUES = {
        "DMS_CLOSE_DATE": 0,
        "DMS_PAYMENT_DATE": 1,
        "DMS_CLOSE_PRICE": 2,
        "DMS_COMPLIANCE_STATUS": 3,
        "DMS_COMMISSION_STATUS": 4,
    }


class DmsStaffOperationType(object):
    READ_DOCUMENT = 0
    CREATE_DOCUMENT = 1
    UPDATE_DOCUMENT = 2
    DELETE_DOCUMENT = 3
    READ_DMS_FOLDER = 4
    CREATE_DMS_FOLDER = 5

    _VALUES_TO_NAMES = {
        0: "READ_DOCUMENT",
        1: "CREATE_DOCUMENT",
        2: "UPDATE_DOCUMENT",
        3: "DELETE_DOCUMENT",
        4: "READ_DMS_FOLDER",
        5: "CREATE_DMS_FOLDER",
    }

    _NAMES_TO_VALUES = {
        "READ_DOCUMENT": 0,
        "CREATE_DOCUMENT": 1,
        "UPDATE_DOCUMENT": 2,
        "DELETE_DOCUMENT": 3,
        "READ_DMS_FOLDER": 4,
        "CREATE_DMS_FOLDER": 5,
    }


class DrsComplianceStatus(object):
    INCOMPLETE = 0
    SUBMITTED = 1
    PENDING_AGENT_UPDATE = 2
    APPROVED = 3

    _VALUES_TO_NAMES = {
        0: "INCOMPLETE",
        1: "SUBMITTED",
        2: "PENDING_AGENT_UPDATE",
        3: "APPROVED",
    }

    _NAMES_TO_VALUES = {
        "INCOMPLETE": 0,
        "SUBMITTED": 1,
        "PENDING_AGENT_UPDATE": 2,
        "APPROVED": 3,
    }


class ObjectState(object):
    PRE_CONTRACT_WITH_BUYER = 0
    IN_CONTRACT_WITH_BUYER = 1

    _VALUES_TO_NAMES = {
        0: "PRE_CONTRACT_WITH_BUYER",
        1: "IN_CONTRACT_WITH_BUYER",
    }

    _NAMES_TO_VALUES = {
        "PRE_CONTRACT_WITH_BUYER": 0,
        "IN_CONTRACT_WITH_BUYER": 1,
    }


class ObjectType(object):
    DMS_LISTING = 0
    DMS_TRANSACTION = 1

    _VALUES_TO_NAMES = {
        0: "DMS_LISTING",
        1: "DMS_TRANSACTION",
    }

    _NAMES_TO_VALUES = {
        "DMS_LISTING": 0,
        "DMS_TRANSACTION": 1,
    }


class AdditionalReferralDealFields(object):
    """
    Attributes:
     - propertyType
     - listingType
     - city
     - yearBuilt
     - propertyAddress
     - state
     - zipcode
     - unit
     - isNewConstruction
     - closePrice
     - closeDate
     - name
     - listingId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'propertyType', None, None, ),  # 1
        (2, TType.I32, 'listingType', None, None, ),  # 2
        (3, TType.STRING, 'city', 'UTF8', None, ),  # 3
        (4, TType.I32, 'yearBuilt', None, None, ),  # 4
        (5, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'state', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'zipcode', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'unit', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'isNewConstruction', None, None, ),  # 9
        (10, TType.DOUBLE, 'closePrice', None, None, ),  # 10
        (11, TType.STRING, 'closeDate', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'name', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'listingId', 'UTF8', None, ),  # 13
    )
    def __init__(self, propertyType=None, listingType=None, city=None, yearBuilt=None, propertyAddress=None, state=None, zipcode=None, unit=None, isNewConstruction=None, closePrice=None, closeDate=None, name=None, listingId=None, ):
        self.propertyType = propertyType
        self.listingType = listingType
        self.city = city
        self.yearBuilt = yearBuilt
        self.propertyAddress = propertyAddress
        self.state = state
        self.zipcode = zipcode
        self.unit = unit
        self.isNewConstruction = isNewConstruction
        self.closePrice = closePrice
        self.closeDate = closeDate
        self.name = name
        self.listingId = listingId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AdditionalReferralDealFields')
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 1)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 2)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 3)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 4)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 5)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 6)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 7)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 8)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 9)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 10)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 11)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 12)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 13)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AdminComplianceChecklistDocument(object):
    """
    Attributes:
     - relation
     - document
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'relation', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'document', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal.thrift_spec), None, ),  # 2
    )
    def __init__(self, relation=None, document=None, ):
        self.relation = relation
        self.document = document

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.relation = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteriaRelation()
                    self.relation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.document = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentInternal()
                    self.document.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AdminComplianceChecklistDocument')
        if self.relation is not None:
            oprot.writeFieldBegin('relation', TType.STRUCT, 1)
            self.relation.write(oprot)
            oprot.writeFieldEnd()
        if self.document is not None:
            oprot.writeFieldBegin('document', TType.STRUCT, 2)
            self.document.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AdminComplianceChecklistDocumentIdPair(object):
    """
    Attributes:
     - relationId
     - documentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'relationId', None, None, ),  # 1
        (2, TType.I32, 'documentId', None, None, ),  # 2
    )
    def __init__(self, relationId=None, documentId=None, ):
        self.relationId = relationId
        self.documentId = documentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.relationId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.documentId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AdminComplianceChecklistDocumentIdPair')
        if self.relationId is not None:
            oprot.writeFieldBegin('relationId', TType.I32, 1)
            oprot.writeI32(self.relationId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.I32, 2)
            oprot.writeI32(self.documentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AdminComplianceChecklistGroup(object):
    """
    Attributes:
     - checklist
     - criteria
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'checklist', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'criteria', (gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria, gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria.thrift_spec), None, ),  # 2
    )
    def __init__(self, checklist=None, criteria=None, ):
        self.checklist = checklist
        self.criteria = criteria

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.checklist = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklist()
                    self.checklist.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.criteria = gen.urbancompass.region_compliance_checklist_db_helper.ttypes.ComplianceDocumentChecklistCriteria()
                    self.criteria.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AdminComplianceChecklistGroup')
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.STRUCT, 1)
            self.checklist.write(oprot)
            oprot.writeFieldEnd()
        if self.criteria is not None:
            oprot.writeFieldBegin('criteria', TType.STRUCT, 2)
            self.criteria.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentInfo(object):
    """
    Attributes:
     - personId
     - agentUserId
     - displayName
     - email
     - phone
     - avatarUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'agentUserId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'displayName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'phone', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 6
    )
    def __init__(self, personId=None, agentUserId=None, displayName=None, email=None, phone=None, avatarUrl=None, ):
        self.personId = personId
        self.agentUserId = agentUserId
        self.displayName = displayName
        self.email = email
        self.phone = phone
        self.avatarUrl = avatarUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentInfo')
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 1)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.agentUserId is not None:
            oprot.writeFieldBegin('agentUserId', TType.STRING, 2)
            oprot.writeString(self.agentUserId.encode('utf-8') if sys.version_info[0] == 2 else self.agentUserId)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 3)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 5)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 6)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsAgentExt(object):
    """
    Attributes:
     - isPrimary
     - agentUserId
     - displayName
     - email
     - phone
     - avatarUrl
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'isPrimary', None, None, ),  # 1
        (2, TType.STRING, 'agentUserId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'displayName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'phone', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 6
        (7, TType.I64, 'id', None, None, ),  # 7
    )
    def __init__(self, isPrimary=None, agentUserId=None, displayName=None, email=None, phone=None, avatarUrl=None, id=None, ):
        self.isPrimary = isPrimary
        self.agentUserId = agentUserId
        self.displayName = displayName
        self.email = email
        self.phone = phone
        self.avatarUrl = avatarUrl
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.isPrimary = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.agentUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.phone = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsAgentExt')
        if self.isPrimary is not None:
            oprot.writeFieldBegin('isPrimary', TType.BOOL, 1)
            oprot.writeBool(self.isPrimary)
            oprot.writeFieldEnd()
        if self.agentUserId is not None:
            oprot.writeFieldBegin('agentUserId', TType.STRING, 2)
            oprot.writeString(self.agentUserId.encode('utf-8') if sys.version_info[0] == 2 else self.agentUserId)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 3)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phone is not None:
            oprot.writeFieldBegin('phone', TType.STRING, 5)
            oprot.writeString(self.phone.encode('utf-8') if sys.version_info[0] == 2 else self.phone)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 6)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 7)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsChecklistItem(object):
    """
    Attributes:
     - name
     - isRequired
     - documentId
     - status
     - stage
     - isComplete
     - itemType
     - id
     - description
     - priorityOrder
     - documentIsPacket
     - documentComment
     - purposeType
     - dmsListingId
     - dmsTransactionId
     - notesCount
     - notesResolved
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'isRequired', None, None, ),  # 2
        (3, TType.STRING, 'documentId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.I32, 'stage', None, None, ),  # 5
        (6, TType.BOOL, 'isComplete', None, None, ),  # 6
        (7, TType.I32, 'itemType', None, None, ),  # 7
        (8, TType.I32, 'id', None, None, ),  # 8
        (9, TType.STRING, 'description', 'UTF8', None, ),  # 9
        (10, TType.I32, 'priorityOrder', None, None, ),  # 10
        (11, TType.BOOL, 'documentIsPacket', None, None, ),  # 11
        (12, TType.STRING, 'documentComment', 'UTF8', None, ),  # 12
        (13, TType.I32, 'purposeType', None, None, ),  # 13
        (14, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'dmsTransactionId', 'UTF8', None, ),  # 15
        (16, TType.I32, 'notesCount', None, None, ),  # 16
        (17, TType.BOOL, 'notesResolved', None, None, ),  # 17
    )
    def __init__(self, name=None, isRequired=None, documentId=None, status=None, stage=None, isComplete=None, itemType=None, id=None, description=None, priorityOrder=None, documentIsPacket=None, documentComment=None, purposeType=None, dmsListingId=None, dmsTransactionId=None, notesCount=None, notesResolved=None, ):
        self.name = name
        self.isRequired = isRequired
        self.documentId = documentId
        self.status = status
        self.stage = stage
        self.isComplete = isComplete
        self.itemType = itemType
        self.id = id
        self.description = description
        self.priorityOrder = priorityOrder
        self.documentIsPacket = documentIsPacket
        self.documentComment = documentComment
        self.purposeType = purposeType
        self.dmsListingId = dmsListingId
        self.dmsTransactionId = dmsTransactionId
        self.notesCount = notesCount
        self.notesResolved = notesResolved

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.isRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.stage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.itemType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.priorityOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.documentIsPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.documentComment = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.dmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.notesCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.notesResolved = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsChecklistItem')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.isRequired is not None:
            oprot.writeFieldBegin('isRequired', TType.BOOL, 2)
            oprot.writeBool(self.isRequired)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 3)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.stage is not None:
            oprot.writeFieldBegin('stage', TType.I32, 5)
            oprot.writeI32(self.stage)
            oprot.writeFieldEnd()
        if self.isComplete is not None:
            oprot.writeFieldBegin('isComplete', TType.BOOL, 6)
            oprot.writeBool(self.isComplete)
            oprot.writeFieldEnd()
        if self.itemType is not None:
            oprot.writeFieldBegin('itemType', TType.I32, 7)
            oprot.writeI32(self.itemType)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 8)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 9)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.priorityOrder is not None:
            oprot.writeFieldBegin('priorityOrder', TType.I32, 10)
            oprot.writeI32(self.priorityOrder)
            oprot.writeFieldEnd()
        if self.documentIsPacket is not None:
            oprot.writeFieldBegin('documentIsPacket', TType.BOOL, 11)
            oprot.writeBool(self.documentIsPacket)
            oprot.writeFieldEnd()
        if self.documentComment is not None:
            oprot.writeFieldBegin('documentComment', TType.STRING, 12)
            oprot.writeString(self.documentComment.encode('utf-8') if sys.version_info[0] == 2 else self.documentComment)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 13)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 14)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.dmsTransactionId is not None:
            oprot.writeFieldBegin('dmsTransactionId', TType.STRING, 15)
            oprot.writeString(self.dmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionId)
            oprot.writeFieldEnd()
        if self.notesCount is not None:
            oprot.writeFieldBegin('notesCount', TType.I32, 16)
            oprot.writeI32(self.notesCount)
            oprot.writeFieldEnd()
        if self.notesResolved is not None:
            oprot.writeFieldBegin('notesResolved', TType.BOOL, 17)
            oprot.writeBool(self.notesResolved)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsChecklistItemNote(object):
    """
    Attributes:
     - noteId
     - createdAt
     - note
     - createdBy
     - userDisplayName
     - userFirstName
     - userLastName
     - checklistItemNoteRole
     - checklistItemNoteType
     - checklistItemNoteTypeDisplayStatus
     - checklistItemName
     - checklistItemId
     - checklistItemStage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'noteId', None, None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        None,  # 3
        (4, TType.STRING, 'note', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'createdBy', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'userDisplayName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'userFirstName', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'userLastName', 'UTF8', None, ),  # 8
        (9, TType.I32, 'checklistItemNoteRole', None, None, ),  # 9
        (10, TType.I32, 'checklistItemNoteType', None, None, ),  # 10
        (11, TType.STRING, 'checklistItemNoteTypeDisplayStatus', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'checklistItemName', 'UTF8', None, ),  # 12
        (13, TType.I32, 'checklistItemId', None, None, ),  # 13
        (14, TType.I32, 'checklistItemStage', None, None, ),  # 14
    )
    def __init__(self, noteId=None, createdAt=None, note=None, createdBy=None, userDisplayName=None, userFirstName=None, userLastName=None, checklistItemNoteRole=None, checklistItemNoteType=None, checklistItemNoteTypeDisplayStatus=None, checklistItemName=None, checklistItemId=None, checklistItemStage=None, ):
        self.noteId = noteId
        self.createdAt = createdAt
        self.note = note
        self.createdBy = createdBy
        self.userDisplayName = userDisplayName
        self.userFirstName = userFirstName
        self.userLastName = userLastName
        self.checklistItemNoteRole = checklistItemNoteRole
        self.checklistItemNoteType = checklistItemNoteType
        self.checklistItemNoteTypeDisplayStatus = checklistItemNoteTypeDisplayStatus
        self.checklistItemName = checklistItemName
        self.checklistItemId = checklistItemId
        self.checklistItemStage = checklistItemStage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.noteId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.userDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.userFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.userLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.checklistItemNoteRole = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.checklistItemNoteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.checklistItemNoteTypeDisplayStatus = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.checklistItemName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.checklistItemId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.checklistItemStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsChecklistItemNote')
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.I64, 1)
            oprot.writeI64(self.noteId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 4)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 5)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.userDisplayName is not None:
            oprot.writeFieldBegin('userDisplayName', TType.STRING, 6)
            oprot.writeString(self.userDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.userDisplayName)
            oprot.writeFieldEnd()
        if self.userFirstName is not None:
            oprot.writeFieldBegin('userFirstName', TType.STRING, 7)
            oprot.writeString(self.userFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.userFirstName)
            oprot.writeFieldEnd()
        if self.userLastName is not None:
            oprot.writeFieldBegin('userLastName', TType.STRING, 8)
            oprot.writeString(self.userLastName.encode('utf-8') if sys.version_info[0] == 2 else self.userLastName)
            oprot.writeFieldEnd()
        if self.checklistItemNoteRole is not None:
            oprot.writeFieldBegin('checklistItemNoteRole', TType.I32, 9)
            oprot.writeI32(self.checklistItemNoteRole)
            oprot.writeFieldEnd()
        if self.checklistItemNoteType is not None:
            oprot.writeFieldBegin('checklistItemNoteType', TType.I32, 10)
            oprot.writeI32(self.checklistItemNoteType)
            oprot.writeFieldEnd()
        if self.checklistItemNoteTypeDisplayStatus is not None:
            oprot.writeFieldBegin('checklistItemNoteTypeDisplayStatus', TType.STRING, 11)
            oprot.writeString(self.checklistItemNoteTypeDisplayStatus.encode('utf-8') if sys.version_info[0] == 2 else self.checklistItemNoteTypeDisplayStatus)
            oprot.writeFieldEnd()
        if self.checklistItemName is not None:
            oprot.writeFieldBegin('checklistItemName', TType.STRING, 12)
            oprot.writeString(self.checklistItemName.encode('utf-8') if sys.version_info[0] == 2 else self.checklistItemName)
            oprot.writeFieldEnd()
        if self.checklistItemId is not None:
            oprot.writeFieldBegin('checklistItemId', TType.I32, 13)
            oprot.writeI32(self.checklistItemId)
            oprot.writeFieldEnd()
        if self.checklistItemStage is not None:
            oprot.writeFieldBegin('checklistItemStage', TType.I32, 14)
            oprot.writeI32(self.checklistItemStage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsContactExt(object):
    """
    Attributes:
     - id
     - dmsFolderId
     - isTiedToOffer
     - sideRepresented
     - firstName
     - lastName
     - contactType
     - emailAddress
     - isCompany
     - companyName
     - crmContactId
     - isRecommended
     - avatarUrl
     - phoneNumber
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isTiedToOffer', None, None, ),  # 3
        (4, TType.I32, 'sideRepresented', None, None, ),  # 4
        (5, TType.STRING, 'firstName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'lastName', 'UTF8', None, ),  # 6
        (7, TType.I32, 'contactType', None, None, ),  # 7
        (8, TType.STRING, 'emailAddress', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'isCompany', None, None, ),  # 9
        (10, TType.STRING, 'companyName', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'crmContactId', 'UTF8', None, ),  # 11
        (12, TType.BOOL, 'isRecommended', None, None, ),  # 12
        (13, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'phoneNumber', 'UTF8', None, ),  # 14
    )
    def __init__(self, id=None, dmsFolderId=None, isTiedToOffer=None, sideRepresented=None, firstName=None, lastName=None, contactType=None, emailAddress=None, isCompany=None, companyName=None, crmContactId=None, isRecommended=None, avatarUrl=None, phoneNumber=None, ):
        self.id = id
        self.dmsFolderId = dmsFolderId
        self.isTiedToOffer = isTiedToOffer
        self.sideRepresented = sideRepresented
        self.firstName = firstName
        self.lastName = lastName
        self.contactType = contactType
        self.emailAddress = emailAddress
        self.isCompany = isCompany
        self.companyName = companyName
        self.crmContactId = crmContactId
        self.isRecommended = isRecommended
        self.avatarUrl = avatarUrl
        self.phoneNumber = phoneNumber

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isTiedToOffer = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.contactType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.emailAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isCompany = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.companyName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.crmContactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isRecommended = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.phoneNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsContactExt')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.isTiedToOffer is not None:
            oprot.writeFieldBegin('isTiedToOffer', TType.BOOL, 3)
            oprot.writeBool(self.isTiedToOffer)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 4)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 5)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 6)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.I32, 7)
            oprot.writeI32(self.contactType)
            oprot.writeFieldEnd()
        if self.emailAddress is not None:
            oprot.writeFieldBegin('emailAddress', TType.STRING, 8)
            oprot.writeString(self.emailAddress.encode('utf-8') if sys.version_info[0] == 2 else self.emailAddress)
            oprot.writeFieldEnd()
        if self.isCompany is not None:
            oprot.writeFieldBegin('isCompany', TType.BOOL, 9)
            oprot.writeBool(self.isCompany)
            oprot.writeFieldEnd()
        if self.companyName is not None:
            oprot.writeFieldBegin('companyName', TType.STRING, 10)
            oprot.writeString(self.companyName.encode('utf-8') if sys.version_info[0] == 2 else self.companyName)
            oprot.writeFieldEnd()
        if self.crmContactId is not None:
            oprot.writeFieldBegin('crmContactId', TType.STRING, 11)
            oprot.writeString(self.crmContactId.encode('utf-8') if sys.version_info[0] == 2 else self.crmContactId)
            oprot.writeFieldEnd()
        if self.isRecommended is not None:
            oprot.writeFieldBegin('isRecommended', TType.BOOL, 12)
            oprot.writeBool(self.isRecommended)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 13)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.phoneNumber is not None:
            oprot.writeFieldBegin('phoneNumber', TType.STRING, 14)
            oprot.writeString(self.phoneNumber.encode('utf-8') if sys.version_info[0] == 2 else self.phoneNumber)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderDetailsForGlideSync(object):
    """
    Attributes:
     - propertyAddress
     - propertyAddressTs
     - yearBuilt
     - yearBuiltTs
     - listDate
     - listDateTs
     - expirationDate
     - expirationDateTs
     - listPrice
     - listPriceTs
     - propertyType
     - propertyTypeTs
     - closePrice
     - closePriceTs
     - acceptanceDate
     - acceptanceDateTs
     - closeDate
     - closeDateTs
     - commissionRateAmount
     - commissionRateAmountTs
     - commissionRate
     - commissionRateTs
     - otherSideCommissionRateAmount
     - otherSideCommissionRateAmountTs
     - otherSideCommissionRate
     - otherSideCommissionRateTs
     - unit
     - unitTs
     - city
     - cityTs
     - state
     - stateTs
     - zipcode
     - zipcodeTs
     - dmsFolderId
     - mlsId
     - mlsIdTs
     - otherSideClientIds
     - otherSideClientIdsTs
     - otherSideAgentIds
     - otherSideAgentIdsTs
     - isSyncingListingInfoLocked
     - isSyncingOfferInfoLocked
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 1
        (2, TType.I32, 'yearBuilt', None, None, ),  # 2
        (3, TType.I64, 'listDate', None, None, ),  # 3
        (4, TType.I64, 'expirationDate', None, None, ),  # 4
        (5, TType.DOUBLE, 'listPrice', None, None, ),  # 5
        (6, TType.I32, 'propertyType', None, None, ),  # 6
        (7, TType.DOUBLE, 'closePrice', None, None, ),  # 7
        (8, TType.I64, 'acceptanceDate', None, None, ),  # 8
        (9, TType.I64, 'closeDate', None, None, ),  # 9
        (10, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 10
        (11, TType.DOUBLE, 'commissionRate', None, None, ),  # 11
        (12, TType.DOUBLE, 'otherSideCommissionRateAmount', None, None, ),  # 12
        (13, TType.DOUBLE, 'otherSideCommissionRate', None, None, ),  # 13
        (14, TType.STRING, 'unit', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'city', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'state', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'zipcode', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 18
        (19, TType.I64, 'propertyAddressTs', None, None, ),  # 19
        (20, TType.I64, 'yearBuiltTs', None, None, ),  # 20
        (21, TType.I64, 'listDateTs', None, None, ),  # 21
        (22, TType.I64, 'expirationDateTs', None, None, ),  # 22
        (23, TType.I64, 'listPriceTs', None, None, ),  # 23
        (24, TType.I64, 'propertyTypeTs', None, None, ),  # 24
        (25, TType.I64, 'closePriceTs', None, None, ),  # 25
        (26, TType.I64, 'acceptanceDateTs', None, None, ),  # 26
        (27, TType.I64, 'closeDateTs', None, None, ),  # 27
        (28, TType.I64, 'commissionRateAmountTs', None, None, ),  # 28
        (29, TType.I64, 'commissionRateTs', None, None, ),  # 29
        (30, TType.I64, 'otherSideCommissionRateAmountTs', None, None, ),  # 30
        (31, TType.I64, 'otherSideCommissionRateTs', None, None, ),  # 31
        (32, TType.I64, 'unitTs', None, None, ),  # 32
        (33, TType.I64, 'cityTs', None, None, ),  # 33
        (34, TType.I64, 'stateTs', None, None, ),  # 34
        (35, TType.I64, 'zipcodeTs', None, None, ),  # 35
        (36, TType.STRING, 'mlsId', 'UTF8', None, ),  # 36
        (37, TType.I64, 'mlsIdTs', None, None, ),  # 37
        (38, TType.LIST, 'otherSideClientIds', (TType.STRING, 'UTF8', False), None, ),  # 38
        (39, TType.I64, 'otherSideClientIdsTs', None, None, ),  # 39
        (40, TType.LIST, 'otherSideAgentIds', (TType.STRUCT, (gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId, gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId.thrift_spec), False), None, ),  # 40
        (41, TType.I64, 'otherSideAgentIdsTs', None, None, ),  # 41
        (42, TType.BOOL, 'isSyncingListingInfoLocked', None, None, ),  # 42
        (43, TType.BOOL, 'isSyncingOfferInfoLocked', None, None, ),  # 43
    )
    def __init__(self, propertyAddress=None, yearBuilt=None, listDate=None, expirationDate=None, listPrice=None, propertyType=None, closePrice=None, acceptanceDate=None, closeDate=None, commissionRateAmount=None, commissionRate=None, otherSideCommissionRateAmount=None, otherSideCommissionRate=None, unit=None, city=None, state=None, zipcode=None, dmsFolderId=None, propertyAddressTs=None, yearBuiltTs=None, listDateTs=None, expirationDateTs=None, listPriceTs=None, propertyTypeTs=None, closePriceTs=None, acceptanceDateTs=None, closeDateTs=None, commissionRateAmountTs=None, commissionRateTs=None, otherSideCommissionRateAmountTs=None, otherSideCommissionRateTs=None, unitTs=None, cityTs=None, stateTs=None, zipcodeTs=None, mlsId=None, mlsIdTs=None, otherSideClientIds=None, otherSideClientIdsTs=None, otherSideAgentIds=None, otherSideAgentIdsTs=None, isSyncingListingInfoLocked=None, isSyncingOfferInfoLocked=None, ):
        self.propertyAddress = propertyAddress
        self.yearBuilt = yearBuilt
        self.listDate = listDate
        self.expirationDate = expirationDate
        self.listPrice = listPrice
        self.propertyType = propertyType
        self.closePrice = closePrice
        self.acceptanceDate = acceptanceDate
        self.closeDate = closeDate
        self.commissionRateAmount = commissionRateAmount
        self.commissionRate = commissionRate
        self.otherSideCommissionRateAmount = otherSideCommissionRateAmount
        self.otherSideCommissionRate = otherSideCommissionRate
        self.unit = unit
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.dmsFolderId = dmsFolderId
        self.propertyAddressTs = propertyAddressTs
        self.yearBuiltTs = yearBuiltTs
        self.listDateTs = listDateTs
        self.expirationDateTs = expirationDateTs
        self.listPriceTs = listPriceTs
        self.propertyTypeTs = propertyTypeTs
        self.closePriceTs = closePriceTs
        self.acceptanceDateTs = acceptanceDateTs
        self.closeDateTs = closeDateTs
        self.commissionRateAmountTs = commissionRateAmountTs
        self.commissionRateTs = commissionRateTs
        self.otherSideCommissionRateAmountTs = otherSideCommissionRateAmountTs
        self.otherSideCommissionRateTs = otherSideCommissionRateTs
        self.unitTs = unitTs
        self.cityTs = cityTs
        self.stateTs = stateTs
        self.zipcodeTs = zipcodeTs
        self.mlsId = mlsId
        self.mlsIdTs = mlsIdTs
        self.otherSideClientIds = otherSideClientIds
        self.otherSideClientIdsTs = otherSideClientIdsTs
        self.otherSideAgentIds = otherSideAgentIds
        self.otherSideAgentIdsTs = otherSideAgentIdsTs
        self.isSyncingListingInfoLocked = isSyncingListingInfoLocked
        self.isSyncingOfferInfoLocked = isSyncingOfferInfoLocked

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.expirationDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.acceptanceDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I64:
                    self.propertyAddressTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I64:
                    self.yearBuiltTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I64:
                    self.listDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.expirationDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I64:
                    self.listPriceTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.I64:
                    self.propertyTypeTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I64:
                    self.closePriceTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I64:
                    self.acceptanceDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I64:
                    self.closeDateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.I64:
                    self.commissionRateAmountTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.I64:
                    self.commissionRateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.I64:
                    self.otherSideCommissionRateAmountTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.I64:
                    self.otherSideCommissionRateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.I64:
                    self.unitTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I64:
                    self.cityTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.I64:
                    self.stateTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.I64:
                    self.zipcodeTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.I64:
                    self.mlsIdTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.LIST:
                    self.otherSideClientIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.otherSideClientIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.I64:
                    self.otherSideClientIdsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.LIST:
                    self.otherSideAgentIds = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId()
                        _elem8.read(iprot)
                        self.otherSideAgentIds.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.I64:
                    self.otherSideAgentIdsTs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.BOOL:
                    self.isSyncingListingInfoLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.BOOL:
                    self.isSyncingOfferInfoLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderDetailsForGlideSync')
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 1)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 2)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 3)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.I64, 4)
            oprot.writeI64(self.expirationDate)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 5)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 6)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 7)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.I64, 8)
            oprot.writeI64(self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 9)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 10)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 11)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmount is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmount', TType.DOUBLE, 12)
            oprot.writeDouble(self.otherSideCommissionRateAmount)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.DOUBLE, 13)
            oprot.writeDouble(self.otherSideCommissionRate)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 14)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 15)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 16)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 17)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 18)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.propertyAddressTs is not None:
            oprot.writeFieldBegin('propertyAddressTs', TType.I64, 19)
            oprot.writeI64(self.propertyAddressTs)
            oprot.writeFieldEnd()
        if self.yearBuiltTs is not None:
            oprot.writeFieldBegin('yearBuiltTs', TType.I64, 20)
            oprot.writeI64(self.yearBuiltTs)
            oprot.writeFieldEnd()
        if self.listDateTs is not None:
            oprot.writeFieldBegin('listDateTs', TType.I64, 21)
            oprot.writeI64(self.listDateTs)
            oprot.writeFieldEnd()
        if self.expirationDateTs is not None:
            oprot.writeFieldBegin('expirationDateTs', TType.I64, 22)
            oprot.writeI64(self.expirationDateTs)
            oprot.writeFieldEnd()
        if self.listPriceTs is not None:
            oprot.writeFieldBegin('listPriceTs', TType.I64, 23)
            oprot.writeI64(self.listPriceTs)
            oprot.writeFieldEnd()
        if self.propertyTypeTs is not None:
            oprot.writeFieldBegin('propertyTypeTs', TType.I64, 24)
            oprot.writeI64(self.propertyTypeTs)
            oprot.writeFieldEnd()
        if self.closePriceTs is not None:
            oprot.writeFieldBegin('closePriceTs', TType.I64, 25)
            oprot.writeI64(self.closePriceTs)
            oprot.writeFieldEnd()
        if self.acceptanceDateTs is not None:
            oprot.writeFieldBegin('acceptanceDateTs', TType.I64, 26)
            oprot.writeI64(self.acceptanceDateTs)
            oprot.writeFieldEnd()
        if self.closeDateTs is not None:
            oprot.writeFieldBegin('closeDateTs', TType.I64, 27)
            oprot.writeI64(self.closeDateTs)
            oprot.writeFieldEnd()
        if self.commissionRateAmountTs is not None:
            oprot.writeFieldBegin('commissionRateAmountTs', TType.I64, 28)
            oprot.writeI64(self.commissionRateAmountTs)
            oprot.writeFieldEnd()
        if self.commissionRateTs is not None:
            oprot.writeFieldBegin('commissionRateTs', TType.I64, 29)
            oprot.writeI64(self.commissionRateTs)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmountTs is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmountTs', TType.I64, 30)
            oprot.writeI64(self.otherSideCommissionRateAmountTs)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateTs is not None:
            oprot.writeFieldBegin('otherSideCommissionRateTs', TType.I64, 31)
            oprot.writeI64(self.otherSideCommissionRateTs)
            oprot.writeFieldEnd()
        if self.unitTs is not None:
            oprot.writeFieldBegin('unitTs', TType.I64, 32)
            oprot.writeI64(self.unitTs)
            oprot.writeFieldEnd()
        if self.cityTs is not None:
            oprot.writeFieldBegin('cityTs', TType.I64, 33)
            oprot.writeI64(self.cityTs)
            oprot.writeFieldEnd()
        if self.stateTs is not None:
            oprot.writeFieldBegin('stateTs', TType.I64, 34)
            oprot.writeI64(self.stateTs)
            oprot.writeFieldEnd()
        if self.zipcodeTs is not None:
            oprot.writeFieldBegin('zipcodeTs', TType.I64, 35)
            oprot.writeI64(self.zipcodeTs)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 36)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.mlsIdTs is not None:
            oprot.writeFieldBegin('mlsIdTs', TType.I64, 37)
            oprot.writeI64(self.mlsIdTs)
            oprot.writeFieldEnd()
        if self.otherSideClientIds is not None:
            oprot.writeFieldBegin('otherSideClientIds', TType.LIST, 38)
            oprot.writeListBegin(TType.STRING, len(self.otherSideClientIds))
            for _iter10 in self.otherSideClientIds:
                oprot.writeString(_iter10.encode('utf-8') if sys.version_info[0] == 2 else _iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideClientIdsTs is not None:
            oprot.writeFieldBegin('otherSideClientIdsTs', TType.I64, 39)
            oprot.writeI64(self.otherSideClientIdsTs)
            oprot.writeFieldEnd()
        if self.otherSideAgentIds is not None:
            oprot.writeFieldBegin('otherSideAgentIds', TType.LIST, 40)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideAgentIds))
            for _iter11 in self.otherSideAgentIds:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideAgentIdsTs is not None:
            oprot.writeFieldBegin('otherSideAgentIdsTs', TType.I64, 41)
            oprot.writeI64(self.otherSideAgentIdsTs)
            oprot.writeFieldEnd()
        if self.isSyncingListingInfoLocked is not None:
            oprot.writeFieldBegin('isSyncingListingInfoLocked', TType.BOOL, 42)
            oprot.writeBool(self.isSyncingListingInfoLocked)
            oprot.writeFieldEnd()
        if self.isSyncingOfferInfoLocked is not None:
            oprot.writeFieldBegin('isSyncingOfferInfoLocked', TType.BOOL, 43)
            oprot.writeBool(self.isSyncingOfferInfoLocked)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderExt(object):
    """
    Attributes:
     - id
     - name
     - sideRepresented
     - createdBy
     - team
     - createdAt
     - updatedAt
     - isDeleted
     - partitionState
     - groupId
     - referralType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.STRING, 'createdBy', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'team', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.I32, 'partitionState', None, None, ),  # 9
        (10, TType.STRING, 'groupId', 'UTF8', None, ),  # 10
        (11, TType.I32, 'referralType', None, None, ),  # 11
    )
    def __init__(self, id=None, name=None, sideRepresented=None, createdBy=None, team=None, createdAt=None, updatedAt=None, isDeleted=None, partitionState=None, groupId=None, referralType=None, ):
        self.id = id
        self.name = name
        self.sideRepresented = sideRepresented
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.isDeleted = isDeleted
        self.partitionState = partitionState
        self.groupId = groupId
        self.referralType = referralType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.partitionState = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.groupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderExt')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 4)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 5)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.partitionState is not None:
            oprot.writeFieldBegin('partitionState', TType.I32, 9)
            oprot.writeI32(self.partitionState)
            oprot.writeFieldEnd()
        if self.groupId is not None:
            oprot.writeFieldBegin('groupId', TType.STRING, 10)
            oprot.writeString(self.groupId.encode('utf-8') if sys.version_info[0] == 2 else self.groupId)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 11)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderForBTByIdDebug(object):
    """
    Attributes:
     - dmsFolderId
     - dmsTransactionID
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsTransactionID', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
    )
    def __init__(self, dmsFolderId=None, dmsTransactionID=None, userId=None, ):
        self.dmsFolderId = dmsFolderId
        self.dmsTransactionID = dmsTransactionID
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsTransactionID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderForBTByIdDebug')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsTransactionID is not None:
            oprot.writeFieldBegin('dmsTransactionID', TType.STRING, 2)
            oprot.writeString(self.dmsTransactionID.encode('utf-8') if sys.version_info[0] == 2 else self.dmsTransactionID)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsFolderForBTDebug(object):
    """
    Attributes:
     - dmsFolderId
     - dmsPaymentStatus
     - hasFolderReadAccess
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'dmsPaymentStatus', None, None, ),  # 2
        (3, TType.BOOL, 'hasFolderReadAccess', None, None, ),  # 3
    )
    def __init__(self, dmsFolderId=None, dmsPaymentStatus=None, hasFolderReadAccess=None, ):
        self.dmsFolderId = dmsFolderId
        self.dmsPaymentStatus = dmsPaymentStatus
        self.hasFolderReadAccess = hasFolderReadAccess

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.dmsPaymentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasFolderReadAccess = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsFolderForBTDebug')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dmsPaymentStatus is not None:
            oprot.writeFieldBegin('dmsPaymentStatus', TType.I32, 2)
            oprot.writeI32(self.dmsPaymentStatus)
            oprot.writeFieldEnd()
        if self.hasFolderReadAccess is not None:
            oprot.writeFieldBegin('hasFolderReadAccess', TType.BOOL, 3)
            oprot.writeBool(self.hasFolderReadAccess)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingSyncValue(object):
    """
    Attributes:
     - propertyAddress
     - yearBuilt
     - listDate
     - expirationDate
     - listPrice
     - propertyType
     - unit
     - city
     - state
     - zipcode
     - mlsId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 1
        (2, TType.I32, 'yearBuilt', None, None, ),  # 2
        (3, TType.I64, 'listDate', None, None, ),  # 3
        (4, TType.I64, 'expirationDate', None, None, ),  # 4
        (5, TType.DOUBLE, 'listPrice', None, None, ),  # 5
        (6, TType.I32, 'propertyType', None, None, ),  # 6
        (7, TType.STRING, 'unit', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'city', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'state', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'zipcode', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'mlsId', 'UTF8', None, ),  # 11
    )
    def __init__(self, propertyAddress=None, yearBuilt=None, listDate=None, expirationDate=None, listPrice=None, propertyType=None, unit=None, city=None, state=None, zipcode=None, mlsId=None, ):
        self.propertyAddress = propertyAddress
        self.yearBuilt = yearBuilt
        self.listDate = listDate
        self.expirationDate = expirationDate
        self.listPrice = listPrice
        self.propertyType = propertyType
        self.unit = unit
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.mlsId = mlsId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.listDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.expirationDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingSyncValue')
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 1)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 2)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.I64, 3)
            oprot.writeI64(self.listDate)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.I64, 4)
            oprot.writeI64(self.expirationDate)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 5)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 6)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 7)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 8)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 9)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 10)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 11)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsOffer(object):
    """
    Attributes:
     - propertyType
     - listingType
     - city
     - yearBuilt
     - propertyAddress
     - state
     - market
     - zipcode
     - listPrice
     - usedConcierge
     - mediaUrl
     - unit
     - expirationDate
     - listingId
     - expiresIn
     - ctcServiceType
     - closeDate
     - acceptanceDate
     - submitStatus
     - primaryDualRepDmsTransactionId
     - commissionRate
     - closePrice
     - isNewConstruction
     - listDate
     - otherSideCommissionRate
     - mlsId
     - isFullServiceRental
     - isHousingVoucher
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'propertyType', None, None, ),  # 1
        (2, TType.I32, 'listingType', None, None, ),  # 2
        (3, TType.STRING, 'city', 'UTF8', None, ),  # 3
        (4, TType.I32, 'yearBuilt', None, None, ),  # 4
        (5, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'state', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'zipcode', 'UTF8', None, ),  # 7
        (8, TType.DOUBLE, 'listPrice', None, None, ),  # 8
        (9, TType.BOOL, 'usedConcierge', None, None, ),  # 9
        (10, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 10
        (11, TType.STRING, 'unit', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'expirationDate', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'closeDate', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'acceptanceDate', 'UTF8', None, ),  # 14
        (15, TType.STRUCT, 'commissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 15
        (16, TType.DOUBLE, 'closePrice', None, None, ),  # 16
        (17, TType.STRING, 'listingId', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'market', 'UTF8', None, ),  # 18
        (19, TType.BOOL, 'isNewConstruction', None, None, ),  # 19
        (20, TType.STRING, 'listDate', 'UTF8', None, ),  # 20
        (21, TType.I32, 'expiresIn', None, None, ),  # 21
        (22, TType.STRUCT, 'otherSideCommissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 22
        (23, TType.STRING, 'mlsId', 'UTF8', None, ),  # 23
        (24, TType.I32, 'ctcServiceType', None, None, ),  # 24
        (25, TType.I32, 'submitStatus', None, None, ),  # 25
        (26, TType.STRING, 'primaryDualRepDmsTransactionId', 'UTF8', None, ),  # 26
        (27, TType.BOOL, 'isFullServiceRental', None, None, ),  # 27
        (28, TType.BOOL, 'isHousingVoucher', None, None, ),  # 28
    )
    def __init__(self, propertyType=None, listingType=None, city=None, yearBuilt=None, propertyAddress=None, state=None, zipcode=None, listPrice=None, usedConcierge=None, mediaUrl=None, unit=None, expirationDate=None, closeDate=None, acceptanceDate=None, commissionRate=None, closePrice=None, listingId=None, market=None, isNewConstruction=None, listDate=None, expiresIn=None, otherSideCommissionRate=None, mlsId=None, ctcServiceType=None, submitStatus=None, primaryDualRepDmsTransactionId=None, isFullServiceRental=None, isHousingVoucher=None, ):
        self.propertyType = propertyType
        self.listingType = listingType
        self.city = city
        self.yearBuilt = yearBuilt
        self.propertyAddress = propertyAddress
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.unit = unit
        self.expirationDate = expirationDate
        self.closeDate = closeDate
        self.acceptanceDate = acceptanceDate
        self.commissionRate = commissionRate
        self.closePrice = closePrice
        self.listingId = listingId
        self.market = market
        self.isNewConstruction = isNewConstruction
        self.listDate = listDate
        self.expiresIn = expiresIn
        self.otherSideCommissionRate = otherSideCommissionRate
        self.mlsId = mlsId
        self.ctcServiceType = ctcServiceType
        self.submitStatus = submitStatus
        self.primaryDualRepDmsTransactionId = primaryDualRepDmsTransactionId
        self.isFullServiceRental = isFullServiceRental
        self.isHousingVoucher = isHousingVoucher

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.expirationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.acceptanceDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.commissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.commissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.listDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRUCT:
                    self.otherSideCommissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.otherSideCommissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.primaryDualRepDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.BOOL:
                    self.isFullServiceRental = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.BOOL:
                    self.isHousingVoucher = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsOffer')
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 1)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 2)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 3)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 4)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 5)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 6)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 7)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 8)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 9)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 10)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 11)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.STRING, 12)
            oprot.writeString(self.expirationDate.encode('utf-8') if sys.version_info[0] == 2 else self.expirationDate)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 13)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.STRING, 14)
            oprot.writeString(self.acceptanceDate.encode('utf-8') if sys.version_info[0] == 2 else self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.STRUCT, 15)
            self.commissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 16)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 17)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 18)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 19)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.STRING, 20)
            oprot.writeString(self.listDate.encode('utf-8') if sys.version_info[0] == 2 else self.listDate)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 21)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.STRUCT, 22)
            self.otherSideCommissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 23)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 24)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 25)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        if self.primaryDualRepDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDualRepDmsTransactionId', TType.STRING, 26)
            oprot.writeString(self.primaryDualRepDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDualRepDmsTransactionId)
            oprot.writeFieldEnd()
        if self.isFullServiceRental is not None:
            oprot.writeFieldBegin('isFullServiceRental', TType.BOOL, 27)
            oprot.writeBool(self.isFullServiceRental)
            oprot.writeFieldEnd()
        if self.isHousingVoucher is not None:
            oprot.writeFieldBegin('isHousingVoucher', TType.BOOL, 28)
            oprot.writeBool(self.isHousingVoucher)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsSpecificListingPageInfo(object):
    """
    Attributes:
     - closeDate
     - closeDateStr
     - complianceStatus
     - nextAction
     - paymentStatus
     - closePrice
     - acceptanceDate
     - acceptanceDateStr
     - commissionRate
     - dmsFolderExist
     - typeLocked
     - dateAgentPaid
     - hasCommissionAccess
     - deleteLocked
     - deleteLockedReason
     - referredBy
     - referredTo
     - isDmsOfferComplete
     - isClosingSubmitted
     - isSyncingListingInfoLocked
     - isSyncingOfferInfoLocked
     - referralType
     - sideRepresented
     - closingStatus
     - referralDetail
     - numberOfUnresolvedComments
     - issueTypeToCountMapping
     - dmsFolderId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'closeDate', None, None, ),  # 1
        (2, TType.I32, 'complianceStatus', None, None, ),  # 2
        (3, TType.I32, 'nextAction', None, None, ),  # 3
        (4, TType.I32, 'paymentStatus', None, None, ),  # 4
        (5, TType.DOUBLE, 'closePrice', None, None, ),  # 5
        (6, TType.I64, 'acceptanceDate', None, None, ),  # 6
        (7, TType.STRUCT, 'commissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 7
        (8, TType.BOOL, 'dmsFolderExist', None, None, ),  # 8
        (9, TType.BOOL, 'typeLocked', None, None, ),  # 9
        (10, TType.I64, 'dateAgentPaid', None, None, ),  # 10
        (11, TType.BOOL, 'hasCommissionAccess', None, None, ),  # 11
        (12, TType.STRING, 'closeDateStr', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'acceptanceDateStr', 'UTF8', None, ),  # 13
        (14, TType.BOOL, 'deleteLocked', None, None, ),  # 14
        (15, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 15
        (16, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 16
        (17, TType.BOOL, 'isDmsOfferComplete', None, None, ),  # 17
        (18, TType.BOOL, 'isClosingSubmitted', None, None, ),  # 18
        (19, TType.BOOL, 'isSyncingListingInfoLocked', None, None, ),  # 19
        (20, TType.BOOL, 'isSyncingOfferInfoLocked', None, None, ),  # 20
        (21, TType.I32, 'referralType', None, None, ),  # 21
        (22, TType.I32, 'sideRepresented', None, None, ),  # 22
        (23, TType.I32, 'closingStatus', None, None, ),  # 23
        (24, TType.STRUCT, 'referralDetail', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail.thrift_spec), None, ),  # 24
        (25, TType.I32, 'numberOfUnresolvedComments', None, None, ),  # 25
        (26, TType.MAP, 'issueTypeToCountMapping', (TType.I32, None, TType.I32, None, False), None, ),  # 26
        (27, TType.STRING, 'deleteLockedReason', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 28
    )
    def __init__(self, closeDate=None, complianceStatus=None, nextAction=None, paymentStatus=None, closePrice=None, acceptanceDate=None, commissionRate=None, dmsFolderExist=None, typeLocked=None, dateAgentPaid=None, hasCommissionAccess=None, closeDateStr=None, acceptanceDateStr=None, deleteLocked=None, referredBy=None, referredTo=None, isDmsOfferComplete=None, isClosingSubmitted=None, isSyncingListingInfoLocked=None, isSyncingOfferInfoLocked=None, referralType=None, sideRepresented=None, closingStatus=None, referralDetail=None, numberOfUnresolvedComments=None, issueTypeToCountMapping=None, deleteLockedReason=None, dmsFolderId=None, ):
        self.closeDate = closeDate
        self.complianceStatus = complianceStatus
        self.nextAction = nextAction
        self.paymentStatus = paymentStatus
        self.closePrice = closePrice
        self.acceptanceDate = acceptanceDate
        self.commissionRate = commissionRate
        self.dmsFolderExist = dmsFolderExist
        self.typeLocked = typeLocked
        self.dateAgentPaid = dateAgentPaid
        self.hasCommissionAccess = hasCommissionAccess
        self.closeDateStr = closeDateStr
        self.acceptanceDateStr = acceptanceDateStr
        self.deleteLocked = deleteLocked
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.isDmsOfferComplete = isDmsOfferComplete
        self.isClosingSubmitted = isClosingSubmitted
        self.isSyncingListingInfoLocked = isSyncingListingInfoLocked
        self.isSyncingOfferInfoLocked = isSyncingOfferInfoLocked
        self.referralType = referralType
        self.sideRepresented = sideRepresented
        self.closingStatus = closingStatus
        self.referralDetail = referralDetail
        self.numberOfUnresolvedComments = numberOfUnresolvedComments
        self.issueTypeToCountMapping = issueTypeToCountMapping
        self.deleteLockedReason = deleteLockedReason
        self.dmsFolderId = dmsFolderId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.complianceStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.nextAction = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.paymentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.acceptanceDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.commissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.commissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.dmsFolderExist = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.typeLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.dateAgentPaid = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.hasCommissionAccess = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.closeDateStr = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.acceptanceDateStr = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.deleteLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.isDmsOfferComplete = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.isClosingSubmitted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.isSyncingListingInfoLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.BOOL:
                    self.isSyncingOfferInfoLocked = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I32:
                    self.referralType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I32:
                    self.closingStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.referralDetail = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralDetail()
                    self.referralDetail.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.numberOfUnresolvedComments = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.MAP:
                    self.issueTypeToCountMapping = {}
                    (_ktype13, _vtype14, _size17) = iprot.readMapBegin()
                    for _i12 in range(_size17):
                        _key15 = iprot.readI32()
                        _val16 = iprot.readI32()
                        self.issueTypeToCountMapping[_key15] = _val16
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.deleteLockedReason = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsSpecificListingPageInfo')
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 1)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.complianceStatus is not None:
            oprot.writeFieldBegin('complianceStatus', TType.I32, 2)
            oprot.writeI32(self.complianceStatus)
            oprot.writeFieldEnd()
        if self.nextAction is not None:
            oprot.writeFieldBegin('nextAction', TType.I32, 3)
            oprot.writeI32(self.nextAction)
            oprot.writeFieldEnd()
        if self.paymentStatus is not None:
            oprot.writeFieldBegin('paymentStatus', TType.I32, 4)
            oprot.writeI32(self.paymentStatus)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 5)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.I64, 6)
            oprot.writeI64(self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.STRUCT, 7)
            self.commissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.dmsFolderExist is not None:
            oprot.writeFieldBegin('dmsFolderExist', TType.BOOL, 8)
            oprot.writeBool(self.dmsFolderExist)
            oprot.writeFieldEnd()
        if self.typeLocked is not None:
            oprot.writeFieldBegin('typeLocked', TType.BOOL, 9)
            oprot.writeBool(self.typeLocked)
            oprot.writeFieldEnd()
        if self.dateAgentPaid is not None:
            oprot.writeFieldBegin('dateAgentPaid', TType.I64, 10)
            oprot.writeI64(self.dateAgentPaid)
            oprot.writeFieldEnd()
        if self.hasCommissionAccess is not None:
            oprot.writeFieldBegin('hasCommissionAccess', TType.BOOL, 11)
            oprot.writeBool(self.hasCommissionAccess)
            oprot.writeFieldEnd()
        if self.closeDateStr is not None:
            oprot.writeFieldBegin('closeDateStr', TType.STRING, 12)
            oprot.writeString(self.closeDateStr.encode('utf-8') if sys.version_info[0] == 2 else self.closeDateStr)
            oprot.writeFieldEnd()
        if self.acceptanceDateStr is not None:
            oprot.writeFieldBegin('acceptanceDateStr', TType.STRING, 13)
            oprot.writeString(self.acceptanceDateStr.encode('utf-8') if sys.version_info[0] == 2 else self.acceptanceDateStr)
            oprot.writeFieldEnd()
        if self.deleteLocked is not None:
            oprot.writeFieldBegin('deleteLocked', TType.BOOL, 14)
            oprot.writeBool(self.deleteLocked)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 15)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 16)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.isDmsOfferComplete is not None:
            oprot.writeFieldBegin('isDmsOfferComplete', TType.BOOL, 17)
            oprot.writeBool(self.isDmsOfferComplete)
            oprot.writeFieldEnd()
        if self.isClosingSubmitted is not None:
            oprot.writeFieldBegin('isClosingSubmitted', TType.BOOL, 18)
            oprot.writeBool(self.isClosingSubmitted)
            oprot.writeFieldEnd()
        if self.isSyncingListingInfoLocked is not None:
            oprot.writeFieldBegin('isSyncingListingInfoLocked', TType.BOOL, 19)
            oprot.writeBool(self.isSyncingListingInfoLocked)
            oprot.writeFieldEnd()
        if self.isSyncingOfferInfoLocked is not None:
            oprot.writeFieldBegin('isSyncingOfferInfoLocked', TType.BOOL, 20)
            oprot.writeBool(self.isSyncingOfferInfoLocked)
            oprot.writeFieldEnd()
        if self.referralType is not None:
            oprot.writeFieldBegin('referralType', TType.I32, 21)
            oprot.writeI32(self.referralType)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 22)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.closingStatus is not None:
            oprot.writeFieldBegin('closingStatus', TType.I32, 23)
            oprot.writeI32(self.closingStatus)
            oprot.writeFieldEnd()
        if self.referralDetail is not None:
            oprot.writeFieldBegin('referralDetail', TType.STRUCT, 24)
            self.referralDetail.write(oprot)
            oprot.writeFieldEnd()
        if self.numberOfUnresolvedComments is not None:
            oprot.writeFieldBegin('numberOfUnresolvedComments', TType.I32, 25)
            oprot.writeI32(self.numberOfUnresolvedComments)
            oprot.writeFieldEnd()
        if self.issueTypeToCountMapping is not None:
            oprot.writeFieldBegin('issueTypeToCountMapping', TType.MAP, 26)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.issueTypeToCountMapping))
            for _kiter18, _viter19 in self.issueTypeToCountMapping.items():
                oprot.writeI32(_kiter18)
                oprot.writeI32(_viter19)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.deleteLockedReason is not None:
            oprot.writeFieldBegin('deleteLockedReason', TType.STRING, 27)
            oprot.writeString(self.deleteLockedReason.encode('utf-8') if sys.version_info[0] == 2 else self.deleteLockedReason)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 28)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionSyncValue(object):
    """
    Attributes:
     - closePrice
     - acceptanceDate
     - closeDate
     - commissionRateAmount
     - commissionRate
     - otherSideCommissionRateAmount
     - otherSideCommissionRate
     - otherSideClientIds
     - otherSideAgentIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'closePrice', None, None, ),  # 1
        (2, TType.I64, 'acceptanceDate', None, None, ),  # 2
        (3, TType.I64, 'closeDate', None, None, ),  # 3
        (4, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 4
        (5, TType.DOUBLE, 'commissionRate', None, None, ),  # 5
        (6, TType.DOUBLE, 'otherSideCommissionRateAmount', None, None, ),  # 6
        (7, TType.DOUBLE, 'otherSideCommissionRate', None, None, ),  # 7
        (8, TType.LIST, 'otherSideClientIds', (TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.LIST, 'otherSideAgentIds', (TType.STRUCT, (gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId, gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId.thrift_spec), False), None, ),  # 9
    )
    def __init__(self, closePrice=None, acceptanceDate=None, closeDate=None, commissionRateAmount=None, commissionRate=None, otherSideCommissionRateAmount=None, otherSideCommissionRate=None, otherSideClientIds=None, otherSideAgentIds=None, ):
        self.closePrice = closePrice
        self.acceptanceDate = acceptanceDate
        self.closeDate = closeDate
        self.commissionRateAmount = commissionRateAmount
        self.commissionRate = commissionRate
        self.otherSideCommissionRateAmount = otherSideCommissionRateAmount
        self.otherSideCommissionRate = otherSideCommissionRate
        self.otherSideClientIds = otherSideClientIds
        self.otherSideAgentIds = otherSideAgentIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.acceptanceDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.closeDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.DOUBLE:
                    self.otherSideCommissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.otherSideClientIds = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.otherSideClientIds.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.otherSideAgentIds = []
                    (_etype24, _size27) = iprot.readListBegin()
                    for _i25 in range(_size27):
                        _elem26 = gen.urbancompass.dms_event_publisher.ttypes.DmsAgentId()
                        _elem26.read(iprot)
                        self.otherSideAgentIds.append(_elem26)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionSyncValue')
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 1)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.I64, 2)
            oprot.writeI64(self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.I64, 3)
            oprot.writeI64(self.closeDate)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 4)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 5)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRateAmount is not None:
            oprot.writeFieldBegin('otherSideCommissionRateAmount', TType.DOUBLE, 6)
            oprot.writeDouble(self.otherSideCommissionRateAmount)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.DOUBLE, 7)
            oprot.writeDouble(self.otherSideCommissionRate)
            oprot.writeFieldEnd()
        if self.otherSideClientIds is not None:
            oprot.writeFieldBegin('otherSideClientIds', TType.LIST, 8)
            oprot.writeListBegin(TType.STRING, len(self.otherSideClientIds))
            for _iter28 in self.otherSideClientIds:
                oprot.writeString(_iter28.encode('utf-8') if sys.version_info[0] == 2 else _iter28)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.otherSideAgentIds is not None:
            oprot.writeFieldBegin('otherSideAgentIds', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.otherSideAgentIds))
            for _iter29 in self.otherSideAgentIds:
                _iter29.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DrsGroup(object):
    """
    Attributes:
     - id
     - displayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'displayName', 'UTF8', None, ),  # 2
    )
    def __init__(self, id=None, displayName=None, ):
        self.id = id
        self.displayName = displayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrsGroup')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 2)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DrsTeam(object):
    """
    Attributes:
     - id
     - displayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'displayName', 'UTF8', None, ),  # 2
    )
    def __init__(self, id=None, displayName=None, ):
        self.id = id
        self.displayName = displayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrsTeam')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 2)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ManualActivityLogEntry(object):
    """
    Attributes:
     - note
     - operatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'note', 'UTF8', None, ),  # 1
        (2, TType.I64, 'operatedAt', None, None, ),  # 2
    )
    def __init__(self, note=None, operatedAt=None, ):
        self.note = note
        self.operatedAt = operatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.operatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ManualActivityLogEntry')
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 1)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.operatedAt is not None:
            oprot.writeFieldBegin('operatedAt', TType.I64, 2)
            oprot.writeI64(self.operatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PreComplianceDMSFolder(object):
    """
    Attributes:
     - staffGroupId
     - dmsFolderID
     - agentId
     - agentName
     - propertyAddress
     - officeName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'staffGroupId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderID', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'agentId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'agentName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'officeName', 'UTF8', None, ),  # 6
    )
    def __init__(self, staffGroupId=None, dmsFolderID=None, agentId=None, agentName=None, propertyAddress=None, officeName=None, ):
        self.staffGroupId = staffGroupId
        self.dmsFolderID = dmsFolderID
        self.agentId = agentId
        self.agentName = agentName
        self.propertyAddress = propertyAddress
        self.officeName = officeName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.staffGroupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.agentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.officeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PreComplianceDMSFolder')
        if self.staffGroupId is not None:
            oprot.writeFieldBegin('staffGroupId', TType.STRING, 1)
            oprot.writeString(self.staffGroupId.encode('utf-8') if sys.version_info[0] == 2 else self.staffGroupId)
            oprot.writeFieldEnd()
        if self.dmsFolderID is not None:
            oprot.writeFieldBegin('dmsFolderID', TType.STRING, 2)
            oprot.writeString(self.dmsFolderID.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderID)
            oprot.writeFieldEnd()
        if self.agentId is not None:
            oprot.writeFieldBegin('agentId', TType.STRING, 3)
            oprot.writeString(self.agentId.encode('utf-8') if sys.version_info[0] == 2 else self.agentId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 4)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 5)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.officeName is not None:
            oprot.writeFieldBegin('officeName', TType.STRING, 6)
            oprot.writeString(self.officeName.encode('utf-8') if sys.version_info[0] == 2 else self.officeName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CancelledDMSOffer(object):
    """
    Attributes:
     - propertyAddress
     - city
     - state
     - zipcode
     - acceptanceDate
     - closePrice
     - checklist
     - dmsContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'city', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'zipcode', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'acceptanceDate', 'UTF8', None, ),  # 5
        (6, TType.DOUBLE, 'closePrice', None, None, ),  # 6
        (7, TType.LIST, 'checklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 7
        (8, TType.LIST, 'dmsContacts', (TType.STRUCT, (DmsContactExt, DmsContactExt.thrift_spec), False), None, ),  # 8
    )
    def __init__(self, propertyAddress=None, city=None, state=None, zipcode=None, acceptanceDate=None, closePrice=None, checklist=None, dmsContacts=None, ):
        self.propertyAddress = propertyAddress
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.acceptanceDate = acceptanceDate
        self.closePrice = closePrice
        self.checklist = checklist
        self.dmsContacts = dmsContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.acceptanceDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = DmsChecklistItem()
                        _elem32.read(iprot)
                        self.checklist.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.dmsContacts = []
                    (_etype34, _size37) = iprot.readListBegin()
                    for _i35 in range(_size37):
                        _elem36 = DmsContactExt()
                        _elem36.read(iprot)
                        self.dmsContacts.append(_elem36)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CancelledDMSOffer')
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 1)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 2)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 4)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.STRING, 5)
            oprot.writeString(self.acceptanceDate.encode('utf-8') if sys.version_info[0] == 2 else self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 6)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter38 in self.checklist:
                _iter38.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsContacts is not None:
            oprot.writeFieldBegin('dmsContacts', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsContacts))
            for _iter39 in self.dmsContacts:
                _iter39.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsChecklists(object):
    """
    Attributes:
     - checklistType
     - dmsListingChecklist
     - dmsTransactionChecklist
     - dmsClosedChecklist
     - dmsWithdrawnCancelledChecklist
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'checklistType', None, None, ),  # 1
        (2, TType.LIST, 'dmsListingChecklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'dmsTransactionChecklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'dmsClosedChecklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'dmsWithdrawnCancelledChecklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 5
    )
    def __init__(self, checklistType=None, dmsListingChecklist=None, dmsTransactionChecklist=None, dmsClosedChecklist=None, dmsWithdrawnCancelledChecklist=None, ):
        self.checklistType = checklistType
        self.dmsListingChecklist = dmsListingChecklist
        self.dmsTransactionChecklist = dmsTransactionChecklist
        self.dmsClosedChecklist = dmsClosedChecklist
        self.dmsWithdrawnCancelledChecklist = dmsWithdrawnCancelledChecklist

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.checklistType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.dmsListingChecklist = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = DmsChecklistItem()
                        _elem42.read(iprot)
                        self.dmsListingChecklist.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.dmsTransactionChecklist = []
                    (_etype44, _size47) = iprot.readListBegin()
                    for _i45 in range(_size47):
                        _elem46 = DmsChecklistItem()
                        _elem46.read(iprot)
                        self.dmsTransactionChecklist.append(_elem46)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.dmsClosedChecklist = []
                    (_etype48, _size51) = iprot.readListBegin()
                    for _i49 in range(_size51):
                        _elem50 = DmsChecklistItem()
                        _elem50.read(iprot)
                        self.dmsClosedChecklist.append(_elem50)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.dmsWithdrawnCancelledChecklist = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = DmsChecklistItem()
                        _elem54.read(iprot)
                        self.dmsWithdrawnCancelledChecklist.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsChecklists')
        if self.checklistType is not None:
            oprot.writeFieldBegin('checklistType', TType.I32, 1)
            oprot.writeI32(self.checklistType)
            oprot.writeFieldEnd()
        if self.dmsListingChecklist is not None:
            oprot.writeFieldBegin('dmsListingChecklist', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsListingChecklist))
            for _iter56 in self.dmsListingChecklist:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsTransactionChecklist is not None:
            oprot.writeFieldBegin('dmsTransactionChecklist', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsTransactionChecklist))
            for _iter57 in self.dmsTransactionChecklist:
                _iter57.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsClosedChecklist is not None:
            oprot.writeFieldBegin('dmsClosedChecklist', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsClosedChecklist))
            for _iter58 in self.dmsClosedChecklist:
                _iter58.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dmsWithdrawnCancelledChecklist is not None:
            oprot.writeFieldBegin('dmsWithdrawnCancelledChecklist', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsWithdrawnCancelledChecklist))
            for _iter59 in self.dmsWithdrawnCancelledChecklist:
                _iter59.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingExt(object):
    """
    Attributes:
     - id
     - dmsFolderId
     - dealListingId
     - createdBy
     - team
     - createdAt
     - updatedAt
     - propertyType
     - listingType
     - currentStage
     - currentSubStage
     - checklist
     - isDeleted
     - city
     - yearBuilt
     - propertyAddress
     - state
     - zipcode
     - listPrice
     - usedConcierge
     - mediaUrl
     - unit
     - expirationDate
     - yearlyRent
     - market
     - isNewConstruction
     - listDate
     - expiresIn
     - reasonForWithdrawal
     - initialCompletedAt
     - mlsId
     - primaryDmsListingId
     - commissionRate
     - otherSideCommissionRate
     - submitStatus
     - isFullServiceRental
     - isHousingVoucher
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'dealListingId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'createdBy', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'team', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
        (8, TType.I32, 'propertyType', None, None, ),  # 8
        (9, TType.I32, 'listingType', None, None, ),  # 9
        (10, TType.I32, 'currentStage', None, None, ),  # 10
        (11, TType.I32, 'currentSubStage', None, None, ),  # 11
        (12, TType.LIST, 'checklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 12
        (13, TType.BOOL, 'isDeleted', None, None, ),  # 13
        (14, TType.STRING, 'city', 'UTF8', None, ),  # 14
        (15, TType.I32, 'yearBuilt', None, None, ),  # 15
        (16, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'state', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'zipcode', 'UTF8', None, ),  # 18
        (19, TType.DOUBLE, 'listPrice', None, None, ),  # 19
        (20, TType.BOOL, 'isNewConstruction', None, None, ),  # 20
        (21, TType.STRING, 'listDate', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'usedConcierge', None, None, ),  # 22
        (23, TType.STRING, 'mediaUrl', 'UTF8', None, ),  # 23
        (24, TType.STRING, 'unit', 'UTF8', None, ),  # 24
        (25, TType.STRING, 'expirationDate', 'UTF8', None, ),  # 25
        (26, TType.DOUBLE, 'yearlyRent', None, None, ),  # 26
        (27, TType.STRING, 'market', 'UTF8', None, ),  # 27
        (28, TType.I32, 'expiresIn', None, None, ),  # 28
        (29, TType.STRING, 'reasonForWithdrawal', 'UTF8', None, ),  # 29
        (30, TType.I64, 'initialCompletedAt', None, None, ),  # 30
        (31, TType.STRING, 'mlsId', 'UTF8', None, ),  # 31
        (32, TType.STRING, 'primaryDmsListingId', 'UTF8', None, ),  # 32
        (33, TType.STRUCT, 'commissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 33
        (34, TType.STRUCT, 'otherSideCommissionRate', (gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount, gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount.thrift_spec), None, ),  # 34
        (35, TType.I32, 'submitStatus', None, None, ),  # 35
        (36, TType.BOOL, 'isFullServiceRental', None, None, ),  # 36
        (37, TType.BOOL, 'isHousingVoucher', None, None, ),  # 37
    )
    def __init__(self, id=None, dmsFolderId=None, dealListingId=None, createdBy=None, team=None, createdAt=None, updatedAt=None, propertyType=None, listingType=None, currentStage=None, currentSubStage=None, checklist=None, isDeleted=None, city=None, yearBuilt=None, propertyAddress=None, state=None, zipcode=None, listPrice=None, isNewConstruction=None, listDate=None, usedConcierge=None, mediaUrl=None, unit=None, expirationDate=None, yearlyRent=None, market=None, expiresIn=None, reasonForWithdrawal=None, initialCompletedAt=None, mlsId=None, primaryDmsListingId=None, commissionRate=None, otherSideCommissionRate=None, submitStatus=None, isFullServiceRental=None, isHousingVoucher=None, ):
        self.id = id
        self.dmsFolderId = dmsFolderId
        self.dealListingId = dealListingId
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.propertyType = propertyType
        self.listingType = listingType
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.checklist = checklist
        self.isDeleted = isDeleted
        self.city = city
        self.yearBuilt = yearBuilt
        self.propertyAddress = propertyAddress
        self.state = state
        self.zipcode = zipcode
        self.listPrice = listPrice
        self.isNewConstruction = isNewConstruction
        self.listDate = listDate
        self.usedConcierge = usedConcierge
        self.mediaUrl = mediaUrl
        self.unit = unit
        self.expirationDate = expirationDate
        self.yearlyRent = yearlyRent
        self.market = market
        self.expiresIn = expiresIn
        self.reasonForWithdrawal = reasonForWithdrawal
        self.initialCompletedAt = initialCompletedAt
        self.mlsId = mlsId
        self.primaryDmsListingId = primaryDmsListingId
        self.commissionRate = commissionRate
        self.otherSideCommissionRate = otherSideCommissionRate
        self.submitStatus = submitStatus
        self.isFullServiceRental = isFullServiceRental
        self.isHousingVoucher = isHousingVoucher

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.dealListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype60, _size63) = iprot.readListBegin()
                    for _i61 in range(_size63):
                        _elem62 = DmsChecklistItem()
                        _elem62.read(iprot)
                        self.checklist.append(_elem62)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.listDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.usedConcierge = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.mediaUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.expirationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.DOUBLE:
                    self.yearlyRent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.reasonForWithdrawal = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.I64:
                    self.initialCompletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.primaryDmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.STRUCT:
                    self.commissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.commissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRUCT:
                    self.otherSideCommissionRate = gen.urbancompass.dms_common.dms_deal.ttypes.PercentOrAmount()
                    self.otherSideCommissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.BOOL:
                    self.isFullServiceRental = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.BOOL:
                    self.isHousingVoucher = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingExt')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 2)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.dealListingId is not None:
            oprot.writeFieldBegin('dealListingId', TType.STRING, 3)
            oprot.writeString(self.dealListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dealListingId)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 4)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 5)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 8)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 9)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 10)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 11)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter64 in self.checklist:
                _iter64.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 13)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 14)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 15)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 16)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 17)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 18)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 19)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 20)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.STRING, 21)
            oprot.writeString(self.listDate.encode('utf-8') if sys.version_info[0] == 2 else self.listDate)
            oprot.writeFieldEnd()
        if self.usedConcierge is not None:
            oprot.writeFieldBegin('usedConcierge', TType.BOOL, 22)
            oprot.writeBool(self.usedConcierge)
            oprot.writeFieldEnd()
        if self.mediaUrl is not None:
            oprot.writeFieldBegin('mediaUrl', TType.STRING, 23)
            oprot.writeString(self.mediaUrl.encode('utf-8') if sys.version_info[0] == 2 else self.mediaUrl)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 24)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.STRING, 25)
            oprot.writeString(self.expirationDate.encode('utf-8') if sys.version_info[0] == 2 else self.expirationDate)
            oprot.writeFieldEnd()
        if self.yearlyRent is not None:
            oprot.writeFieldBegin('yearlyRent', TType.DOUBLE, 26)
            oprot.writeDouble(self.yearlyRent)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 27)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 28)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.reasonForWithdrawal is not None:
            oprot.writeFieldBegin('reasonForWithdrawal', TType.STRING, 29)
            oprot.writeString(self.reasonForWithdrawal.encode('utf-8') if sys.version_info[0] == 2 else self.reasonForWithdrawal)
            oprot.writeFieldEnd()
        if self.initialCompletedAt is not None:
            oprot.writeFieldBegin('initialCompletedAt', TType.I64, 30)
            oprot.writeI64(self.initialCompletedAt)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 31)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.primaryDmsListingId is not None:
            oprot.writeFieldBegin('primaryDmsListingId', TType.STRING, 32)
            oprot.writeString(self.primaryDmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsListingId)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.STRUCT, 33)
            self.commissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideCommissionRate is not None:
            oprot.writeFieldBegin('otherSideCommissionRate', TType.STRUCT, 34)
            self.otherSideCommissionRate.write(oprot)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 35)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        if self.isFullServiceRental is not None:
            oprot.writeFieldBegin('isFullServiceRental', TType.BOOL, 36)
            oprot.writeBool(self.isFullServiceRental)
            oprot.writeFieldEnd()
        if self.isHousingVoucher is not None:
            oprot.writeFieldBegin('isHousingVoucher', TType.BOOL, 37)
            oprot.writeBool(self.isHousingVoucher)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingExtSyncField(object):
    """
    Attributes:
     - value
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'value', (DmsListingSyncValue, DmsListingSyncValue.thrift_spec), None, ),  # 1
        (2, TType.I64, 'updatedAt', None, None, ),  # 2
    )
    def __init__(self, value=None, updatedAt=None, ):
        self.value = value
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.value = DmsListingSyncValue()
                    self.value.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingExtSyncField')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRUCT, 1)
            self.value.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 2)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionExt(object):
    """
    Attributes:
     - id
     - dmsListingId
     - createdBy
     - team
     - createdAt
     - updatedAt
     - currentStage
     - currentSubStage
     - isDeleted
     - closingId
     - checklist
     - ctcServiceType
     - primaryDmsTransactionId
     - submitStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'dmsListingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'createdBy', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'team', 'UTF8', None, ),  # 4
        (5, TType.I64, 'createdAt', None, None, ),  # 5
        (6, TType.I64, 'updatedAt', None, None, ),  # 6
        (7, TType.I32, 'currentStage', None, None, ),  # 7
        (8, TType.I32, 'currentSubStage', None, None, ),  # 8
        (9, TType.BOOL, 'isDeleted', None, None, ),  # 9
        (10, TType.I64, 'closingId', None, None, ),  # 10
        (11, TType.LIST, 'checklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 11
        (12, TType.I32, 'ctcServiceType', None, None, ),  # 12
        (13, TType.STRING, 'primaryDmsTransactionId', 'UTF8', None, ),  # 13
        (14, TType.I32, 'submitStatus', None, None, ),  # 14
    )
    def __init__(self, id=None, dmsListingId=None, createdBy=None, team=None, createdAt=None, updatedAt=None, currentStage=None, currentSubStage=None, isDeleted=None, closingId=None, checklist=None, ctcServiceType=None, primaryDmsTransactionId=None, submitStatus=None, ):
        self.id = id
        self.dmsListingId = dmsListingId
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.isDeleted = isDeleted
        self.closingId = closingId
        self.checklist = checklist
        self.ctcServiceType = ctcServiceType
        self.primaryDmsTransactionId = primaryDmsTransactionId
        self.submitStatus = submitStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.dmsListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.closingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = DmsChecklistItem()
                        _elem67.read(iprot)
                        self.checklist.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.primaryDmsTransactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.submitStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionExt')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.dmsListingId is not None:
            oprot.writeFieldBegin('dmsListingId', TType.STRING, 2)
            oprot.writeString(self.dmsListingId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsListingId)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 3)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 4)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 5)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 6)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 7)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 8)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 9)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.closingId is not None:
            oprot.writeFieldBegin('closingId', TType.I64, 10)
            oprot.writeI64(self.closingId)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter69 in self.checklist:
                _iter69.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 12)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        if self.primaryDmsTransactionId is not None:
            oprot.writeFieldBegin('primaryDmsTransactionId', TType.STRING, 13)
            oprot.writeString(self.primaryDmsTransactionId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryDmsTransactionId)
            oprot.writeFieldEnd()
        if self.submitStatus is not None:
            oprot.writeFieldBegin('submitStatus', TType.I32, 14)
            oprot.writeI32(self.submitStatus)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionExtSyncField(object):
    """
    Attributes:
     - value
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'value', (DmsTransactionSyncValue, DmsTransactionSyncValue.thrift_spec), None, ),  # 1
        (2, TType.I64, 'updatedAt', None, None, ),  # 2
    )
    def __init__(self, value=None, updatedAt=None, ):
        self.value = value
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.value = DmsTransactionSyncValue()
                    self.value.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionExtSyncField')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRUCT, 1)
            self.value.write(oprot)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 2)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DrsEnrichedFolder(object):
    """
    Attributes:
     - dmsFolderId
     - name
     - sideRepresented
     - createdBy
     - team
     - createdByDisplayName
     - teamDisplayName
     - createdAt
     - updatedAt
     - currentStage
     - currentSubStage
     - thisSideContact
     - otherSideAgent
     - otherSideClient
     - referredBy
     - referredTo
     - otherSideDualRepAgent
     - address
     - propertyType
     - listingStage
     - listingType
     - expirationDate
     - expiresIn
     - unit
     - city
     - state
     - zipcode
     - yearBuilt
     - mlsId
     - listPrice
     - closeDate
     - transactionStage
     - closePrice
     - commissionRate
     - commissionRateAmount
     - ctcServiceType
     - paymentStatus
     - folderTransactionType
     - drsGroupId
     - drsGroup
     - complianceStatus
     - lastDocumentUpdatedDate
     - numDocumentsPending
     - documentSplitNeeded
     - acceptanceDate
     - numDocumentsNeeded
     - lastDocumentReviewedDate
     - noteCount
     - unresolvedNotesCount
     - hasUnresolvedNotes
     - btId
     - dmsAgents
     - initialCompletedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I32, 'sideRepresented', None, None, ),  # 3
        (4, TType.STRING, 'createdBy', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'team', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
        None,  # 8
        (9, TType.STRING, 'address', 'UTF8', None, ),  # 9
        (10, TType.I32, 'propertyType', None, None, ),  # 10
        (11, TType.I32, 'listingStage', None, None, ),  # 11
        (12, TType.STRING, 'closeDate', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'drsGroupId', 'UTF8', None, ),  # 13
        (14, TType.I32, 'complianceStatus', None, None, ),  # 14
        (15, TType.I32, 'listingType', None, None, ),  # 15
        (16, TType.I32, 'transactionStage', None, None, ),  # 16
        (17, TType.I64, 'lastDocumentUpdatedDate', None, None, ),  # 17
        (18, TType.I32, 'numDocumentsPending', None, None, ),  # 18
        (19, TType.STRING, 'createdByDisplayName', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'teamDisplayName', 'UTF8', None, ),  # 20
        (21, TType.I32, 'currentStage', None, None, ),  # 21
        (22, TType.I32, 'currentSubStage', None, None, ),  # 22
        (23, TType.STRUCT, 'drsGroup', (DrsGroup, DrsGroup.thrift_spec), None, ),  # 23
        (24, TType.BOOL, 'documentSplitNeeded', None, None, ),  # 24
        (25, TType.STRING, 'acceptanceDate', 'UTF8', None, ),  # 25
        (26, TType.STRING, 'expirationDate', 'UTF8', None, ),  # 26
        (27, TType.I32, 'expiresIn', None, None, ),  # 27
        (28, TType.I32, 'numDocumentsNeeded', None, None, ),  # 28
        (29, TType.STRING, 'unit', 'UTF8', None, ),  # 29
        (30, TType.STRING, 'city', 'UTF8', None, ),  # 30
        (31, TType.STRING, 'state', 'UTF8', None, ),  # 31
        (32, TType.STRING, 'btId', 'UTF8', None, ),  # 32
        (33, TType.LIST, 'dmsAgents', (TType.STRUCT, (DmsAgentExt, DmsAgentExt.thrift_spec), False), None, ),  # 33
        (34, TType.DOUBLE, 'closePrice', None, None, ),  # 34
        (35, TType.DOUBLE, 'commissionRate', None, None, ),  # 35
        (36, TType.DOUBLE, 'commissionRateAmount', None, None, ),  # 36
        (37, TType.I32, 'yearBuilt', None, None, ),  # 37
        (38, TType.I64, 'initialCompletedAt', None, None, ),  # 38
        (39, TType.I32, 'ctcServiceType', None, None, ),  # 39
        (40, TType.I32, 'paymentStatus', None, None, ),  # 40
        (41, TType.STRING, 'zipcode', 'UTF8', None, ),  # 41
        (42, TType.I64, 'lastDocumentReviewedDate', None, None, ),  # 42
        (43, TType.I32, 'noteCount', None, None, ),  # 43
        (44, TType.BOOL, 'hasUnresolvedNotes', None, None, ),  # 44
        (45, TType.I32, 'folderTransactionType', None, None, ),  # 45
        (46, TType.I32, 'unresolvedNotesCount', None, None, ),  # 46
        (47, TType.STRUCT, 'thisSideContact', (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), None, ),  # 47
        (48, TType.STRUCT, 'otherSideAgent', (DmsContactExt, DmsContactExt.thrift_spec), None, ),  # 48
        (49, TType.STRUCT, 'otherSideClient', (DmsContactExt, DmsContactExt.thrift_spec), None, ),  # 49
        (50, TType.STRING, 'mlsId', 'UTF8', None, ),  # 50
        (51, TType.DOUBLE, 'listPrice', None, None, ),  # 51
        (52, TType.STRUCT, 'referredBy', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 52
        (53, TType.STRUCT, 'referredTo', (gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo, gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo.thrift_spec), None, ),  # 53
        (54, TType.STRUCT, 'otherSideDualRepAgent', (DmsAgentExt, DmsAgentExt.thrift_spec), None, ),  # 54
    )
    def __init__(self, dmsFolderId=None, name=None, sideRepresented=None, createdBy=None, team=None, createdAt=None, updatedAt=None, address=None, propertyType=None, listingStage=None, closeDate=None, drsGroupId=None, complianceStatus=None, listingType=None, transactionStage=None, lastDocumentUpdatedDate=None, numDocumentsPending=None, createdByDisplayName=None, teamDisplayName=None, currentStage=None, currentSubStage=None, drsGroup=None, documentSplitNeeded=None, acceptanceDate=None, expirationDate=None, expiresIn=None, numDocumentsNeeded=None, unit=None, city=None, state=None, btId=None, dmsAgents=None, closePrice=None, commissionRate=None, commissionRateAmount=None, yearBuilt=None, initialCompletedAt=None, ctcServiceType=None, paymentStatus=None, zipcode=None, lastDocumentReviewedDate=None, noteCount=None, hasUnresolvedNotes=None, folderTransactionType=None, unresolvedNotesCount=None, thisSideContact=None, otherSideAgent=None, otherSideClient=None, mlsId=None, listPrice=None, referredBy=None, referredTo=None, otherSideDualRepAgent=None, ):
        self.dmsFolderId = dmsFolderId
        self.name = name
        self.sideRepresented = sideRepresented
        self.createdBy = createdBy
        self.team = team
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.address = address
        self.propertyType = propertyType
        self.listingStage = listingStage
        self.closeDate = closeDate
        self.drsGroupId = drsGroupId
        self.complianceStatus = complianceStatus
        self.listingType = listingType
        self.transactionStage = transactionStage
        self.lastDocumentUpdatedDate = lastDocumentUpdatedDate
        self.numDocumentsPending = numDocumentsPending
        self.createdByDisplayName = createdByDisplayName
        self.teamDisplayName = teamDisplayName
        self.currentStage = currentStage
        self.currentSubStage = currentSubStage
        self.drsGroup = drsGroup
        self.documentSplitNeeded = documentSplitNeeded
        self.acceptanceDate = acceptanceDate
        self.expirationDate = expirationDate
        self.expiresIn = expiresIn
        self.numDocumentsNeeded = numDocumentsNeeded
        self.unit = unit
        self.city = city
        self.state = state
        self.btId = btId
        self.dmsAgents = dmsAgents
        self.closePrice = closePrice
        self.commissionRate = commissionRate
        self.commissionRateAmount = commissionRateAmount
        self.yearBuilt = yearBuilt
        self.initialCompletedAt = initialCompletedAt
        self.ctcServiceType = ctcServiceType
        self.paymentStatus = paymentStatus
        self.zipcode = zipcode
        self.lastDocumentReviewedDate = lastDocumentReviewedDate
        self.noteCount = noteCount
        self.hasUnresolvedNotes = hasUnresolvedNotes
        self.folderTransactionType = folderTransactionType
        self.unresolvedNotesCount = unresolvedNotesCount
        self.thisSideContact = thisSideContact
        self.otherSideAgent = otherSideAgent
        self.otherSideClient = otherSideClient
        self.mlsId = mlsId
        self.listPrice = listPrice
        self.referredBy = referredBy
        self.referredTo = referredTo
        self.otherSideDualRepAgent = otherSideDualRepAgent

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.team = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.listingStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.closeDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.drsGroupId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.complianceStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.transactionStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I64:
                    self.lastDocumentUpdatedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.numDocumentsPending = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.createdByDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.teamDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I32:
                    self.currentStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I32:
                    self.currentSubStage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRUCT:
                    self.drsGroup = DrsGroup()
                    self.drsGroup.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.documentSplitNeeded = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRING:
                    self.acceptanceDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.expirationDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I32:
                    self.expiresIn = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.I32:
                    self.numDocumentsNeeded = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.unit = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRING:
                    self.btId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.LIST:
                    self.dmsAgents = []
                    (_etype70, _size73) = iprot.readListBegin()
                    for _i71 in range(_size73):
                        _elem72 = DmsAgentExt()
                        _elem72.read(iprot)
                        self.dmsAgents.append(_elem72)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.DOUBLE:
                    self.commissionRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.DOUBLE:
                    self.commissionRateAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.I64:
                    self.initialCompletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.I32:
                    self.ctcServiceType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.I32:
                    self.paymentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.I64:
                    self.lastDocumentReviewedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.I32:
                    self.noteCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.BOOL:
                    self.hasUnresolvedNotes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.I32:
                    self.folderTransactionType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.I32:
                    self.unresolvedNotesCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.STRUCT:
                    self.thisSideContact = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                    self.thisSideContact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.STRUCT:
                    self.otherSideAgent = DmsContactExt()
                    self.otherSideAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.STRUCT:
                    self.otherSideClient = DmsContactExt()
                    self.otherSideClient.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.STRING:
                    self.mlsId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.STRUCT:
                    self.referredBy = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredBy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.STRUCT:
                    self.referredTo = gen.urbancompass.dms_common.dms_deal.ttypes.ReferralInfo()
                    self.referredTo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.STRUCT:
                    self.otherSideDualRepAgent = DmsAgentExt()
                    self.otherSideDualRepAgent.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DrsEnrichedFolder')
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 1)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 3)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 4)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.team is not None:
            oprot.writeFieldBegin('team', TType.STRING, 5)
            oprot.writeString(self.team.encode('utf-8') if sys.version_info[0] == 2 else self.team)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 9)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 10)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingStage is not None:
            oprot.writeFieldBegin('listingStage', TType.I32, 11)
            oprot.writeI32(self.listingStage)
            oprot.writeFieldEnd()
        if self.closeDate is not None:
            oprot.writeFieldBegin('closeDate', TType.STRING, 12)
            oprot.writeString(self.closeDate.encode('utf-8') if sys.version_info[0] == 2 else self.closeDate)
            oprot.writeFieldEnd()
        if self.drsGroupId is not None:
            oprot.writeFieldBegin('drsGroupId', TType.STRING, 13)
            oprot.writeString(self.drsGroupId.encode('utf-8') if sys.version_info[0] == 2 else self.drsGroupId)
            oprot.writeFieldEnd()
        if self.complianceStatus is not None:
            oprot.writeFieldBegin('complianceStatus', TType.I32, 14)
            oprot.writeI32(self.complianceStatus)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 15)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.transactionStage is not None:
            oprot.writeFieldBegin('transactionStage', TType.I32, 16)
            oprot.writeI32(self.transactionStage)
            oprot.writeFieldEnd()
        if self.lastDocumentUpdatedDate is not None:
            oprot.writeFieldBegin('lastDocumentUpdatedDate', TType.I64, 17)
            oprot.writeI64(self.lastDocumentUpdatedDate)
            oprot.writeFieldEnd()
        if self.numDocumentsPending is not None:
            oprot.writeFieldBegin('numDocumentsPending', TType.I32, 18)
            oprot.writeI32(self.numDocumentsPending)
            oprot.writeFieldEnd()
        if self.createdByDisplayName is not None:
            oprot.writeFieldBegin('createdByDisplayName', TType.STRING, 19)
            oprot.writeString(self.createdByDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.createdByDisplayName)
            oprot.writeFieldEnd()
        if self.teamDisplayName is not None:
            oprot.writeFieldBegin('teamDisplayName', TType.STRING, 20)
            oprot.writeString(self.teamDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.teamDisplayName)
            oprot.writeFieldEnd()
        if self.currentStage is not None:
            oprot.writeFieldBegin('currentStage', TType.I32, 21)
            oprot.writeI32(self.currentStage)
            oprot.writeFieldEnd()
        if self.currentSubStage is not None:
            oprot.writeFieldBegin('currentSubStage', TType.I32, 22)
            oprot.writeI32(self.currentSubStage)
            oprot.writeFieldEnd()
        if self.drsGroup is not None:
            oprot.writeFieldBegin('drsGroup', TType.STRUCT, 23)
            self.drsGroup.write(oprot)
            oprot.writeFieldEnd()
        if self.documentSplitNeeded is not None:
            oprot.writeFieldBegin('documentSplitNeeded', TType.BOOL, 24)
            oprot.writeBool(self.documentSplitNeeded)
            oprot.writeFieldEnd()
        if self.acceptanceDate is not None:
            oprot.writeFieldBegin('acceptanceDate', TType.STRING, 25)
            oprot.writeString(self.acceptanceDate.encode('utf-8') if sys.version_info[0] == 2 else self.acceptanceDate)
            oprot.writeFieldEnd()
        if self.expirationDate is not None:
            oprot.writeFieldBegin('expirationDate', TType.STRING, 26)
            oprot.writeString(self.expirationDate.encode('utf-8') if sys.version_info[0] == 2 else self.expirationDate)
            oprot.writeFieldEnd()
        if self.expiresIn is not None:
            oprot.writeFieldBegin('expiresIn', TType.I32, 27)
            oprot.writeI32(self.expiresIn)
            oprot.writeFieldEnd()
        if self.numDocumentsNeeded is not None:
            oprot.writeFieldBegin('numDocumentsNeeded', TType.I32, 28)
            oprot.writeI32(self.numDocumentsNeeded)
            oprot.writeFieldEnd()
        if self.unit is not None:
            oprot.writeFieldBegin('unit', TType.STRING, 29)
            oprot.writeString(self.unit.encode('utf-8') if sys.version_info[0] == 2 else self.unit)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 30)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 31)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.btId is not None:
            oprot.writeFieldBegin('btId', TType.STRING, 32)
            oprot.writeString(self.btId.encode('utf-8') if sys.version_info[0] == 2 else self.btId)
            oprot.writeFieldEnd()
        if self.dmsAgents is not None:
            oprot.writeFieldBegin('dmsAgents', TType.LIST, 33)
            oprot.writeListBegin(TType.STRUCT, len(self.dmsAgents))
            for _iter74 in self.dmsAgents:
                _iter74.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 34)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.DOUBLE, 35)
            oprot.writeDouble(self.commissionRate)
            oprot.writeFieldEnd()
        if self.commissionRateAmount is not None:
            oprot.writeFieldBegin('commissionRateAmount', TType.DOUBLE, 36)
            oprot.writeDouble(self.commissionRateAmount)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 37)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.initialCompletedAt is not None:
            oprot.writeFieldBegin('initialCompletedAt', TType.I64, 38)
            oprot.writeI64(self.initialCompletedAt)
            oprot.writeFieldEnd()
        if self.ctcServiceType is not None:
            oprot.writeFieldBegin('ctcServiceType', TType.I32, 39)
            oprot.writeI32(self.ctcServiceType)
            oprot.writeFieldEnd()
        if self.paymentStatus is not None:
            oprot.writeFieldBegin('paymentStatus', TType.I32, 40)
            oprot.writeI32(self.paymentStatus)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 41)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.lastDocumentReviewedDate is not None:
            oprot.writeFieldBegin('lastDocumentReviewedDate', TType.I64, 42)
            oprot.writeI64(self.lastDocumentReviewedDate)
            oprot.writeFieldEnd()
        if self.noteCount is not None:
            oprot.writeFieldBegin('noteCount', TType.I32, 43)
            oprot.writeI32(self.noteCount)
            oprot.writeFieldEnd()
        if self.hasUnresolvedNotes is not None:
            oprot.writeFieldBegin('hasUnresolvedNotes', TType.BOOL, 44)
            oprot.writeBool(self.hasUnresolvedNotes)
            oprot.writeFieldEnd()
        if self.folderTransactionType is not None:
            oprot.writeFieldBegin('folderTransactionType', TType.I32, 45)
            oprot.writeI32(self.folderTransactionType)
            oprot.writeFieldEnd()
        if self.unresolvedNotesCount is not None:
            oprot.writeFieldBegin('unresolvedNotesCount', TType.I32, 46)
            oprot.writeI32(self.unresolvedNotesCount)
            oprot.writeFieldEnd()
        if self.thisSideContact is not None:
            oprot.writeFieldBegin('thisSideContact', TType.STRUCT, 47)
            self.thisSideContact.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideAgent is not None:
            oprot.writeFieldBegin('otherSideAgent', TType.STRUCT, 48)
            self.otherSideAgent.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideClient is not None:
            oprot.writeFieldBegin('otherSideClient', TType.STRUCT, 49)
            self.otherSideClient.write(oprot)
            oprot.writeFieldEnd()
        if self.mlsId is not None:
            oprot.writeFieldBegin('mlsId', TType.STRING, 50)
            oprot.writeString(self.mlsId.encode('utf-8') if sys.version_info[0] == 2 else self.mlsId)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 51)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRUCT, 52)
            self.referredBy.write(oprot)
            oprot.writeFieldEnd()
        if self.referredTo is not None:
            oprot.writeFieldBegin('referredTo', TType.STRUCT, 53)
            self.referredTo.write(oprot)
            oprot.writeFieldEnd()
        if self.otherSideDualRepAgent is not None:
            oprot.writeFieldBegin('otherSideDualRepAgent', TType.STRUCT, 54)
            self.otherSideDualRepAgent.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class WithdrawnDMSListing(object):
    """
    Attributes:
     - propertyAddress
     - city
     - state
     - zipcode
     - listDate
     - withdrawDate
     - checklist
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'propertyAddress', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'city', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'state', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'zipcode', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'listDate', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'withdrawDate', 'UTF8', None, ),  # 6
        (7, TType.LIST, 'checklist', (TType.STRUCT, (DmsChecklistItem, DmsChecklistItem.thrift_spec), False), None, ),  # 7
    )
    def __init__(self, propertyAddress=None, city=None, state=None, zipcode=None, listDate=None, withdrawDate=None, checklist=None, ):
        self.propertyAddress = propertyAddress
        self.city = city
        self.state = state
        self.zipcode = zipcode
        self.listDate = listDate
        self.withdrawDate = withdrawDate
        self.checklist = checklist

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.propertyAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.listDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.withdrawDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.checklist = []
                    (_etype75, _size78) = iprot.readListBegin()
                    for _i76 in range(_size78):
                        _elem77 = DmsChecklistItem()
                        _elem77.read(iprot)
                        self.checklist.append(_elem77)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('WithdrawnDMSListing')
        if self.propertyAddress is not None:
            oprot.writeFieldBegin('propertyAddress', TType.STRING, 1)
            oprot.writeString(self.propertyAddress.encode('utf-8') if sys.version_info[0] == 2 else self.propertyAddress)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 2)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 3)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 4)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.listDate is not None:
            oprot.writeFieldBegin('listDate', TType.STRING, 5)
            oprot.writeString(self.listDate.encode('utf-8') if sys.version_info[0] == 2 else self.listDate)
            oprot.writeFieldEnd()
        if self.withdrawDate is not None:
            oprot.writeFieldBegin('withdrawDate', TType.STRING, 6)
            oprot.writeString(self.withdrawDate.encode('utf-8') if sys.version_info[0] == 2 else self.withdrawDate)
            oprot.writeFieldEnd()
        if self.checklist is not None:
            oprot.writeFieldBegin('checklist', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.checklist))
            for _iter79 in self.checklist:
                _iter79.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsListingExtSyncPayload(object):
    """
    Attributes:
     - fields
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'fields', (TType.STRUCT, (DmsListingExtSyncField, DmsListingExtSyncField.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, fields=None, ):
        self.fields = fields

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.fields = []
                    (_etype80, _size83) = iprot.readListBegin()
                    for _i81 in range(_size83):
                        _elem82 = DmsListingExtSyncField()
                        _elem82.read(iprot)
                        self.fields.append(_elem82)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsListingExtSyncPayload')
        if self.fields is not None:
            oprot.writeFieldBegin('fields', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.fields))
            for _iter84 in self.fields:
                _iter84.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsTransactionExtSyncPayload(object):
    """
    Attributes:
     - fields
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'fields', (TType.STRUCT, (DmsTransactionExtSyncField, DmsTransactionExtSyncField.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, fields=None, ):
        self.fields = fields

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.fields = []
                    (_etype85, _size88) = iprot.readListBegin()
                    for _i86 in range(_size88):
                        _elem87 = DmsTransactionExtSyncField()
                        _elem87.read(iprot)
                        self.fields.append(_elem87)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsTransactionExtSyncPayload')
        if self.fields is not None:
            oprot.writeFieldBegin('fields', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.fields))
            for _iter89 in self.fields:
                _iter89.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
