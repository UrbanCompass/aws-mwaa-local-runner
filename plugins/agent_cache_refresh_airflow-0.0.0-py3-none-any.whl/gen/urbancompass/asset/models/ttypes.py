
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.permissions.acl.ttypes
import gen.urbancompass.image.ttypes
import gen.urbancompass.profile.ttypes

from thrift.transport import TTransport


class AssetCategory(object):
    UNKNOWN = 0
    UPLOADED = 1
    FILESTACK = 2
    DOWNLOADED = 3
    PRINTED = 4

    _VALUES_TO_NAMES = {
        0: "UNKNOWN",
        1: "UPLOADED",
        2: "FILESTACK",
        3: "DOWNLOADED",
        4: "PRINTED",
    }

    _NAMES_TO_VALUES = {
        "UNKNOWN": 0,
        "UPLOADED": 1,
        "FILESTACK": 2,
        "DOWNLOADED": 3,
        "PRINTED": 4,
    }


class AssetStatus(object):
    NONE = 0
    OK = 1
    CREATING = 2
    UPLOADING = 3
    SUCCESS = 4
    ERROR = 5

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "OK",
        2: "CREATING",
        3: "UPLOADING",
        4: "SUCCESS",
        5: "ERROR",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "OK": 1,
        "CREATING": 2,
        "UPLOADING": 3,
        "SUCCESS": 4,
        "ERROR": 5,
    }


class AssetType(object):
    UNKNOWN = 0
    JPG = 1
    PNG = 2
    PDF = 3
    GIF = 4

    _VALUES_TO_NAMES = {
        0: "UNKNOWN",
        1: "JPG",
        2: "PNG",
        3: "PDF",
        4: "GIF",
    }

    _NAMES_TO_VALUES = {
        "UNKNOWN": 0,
        "JPG": 1,
        "PNG": 2,
        "PDF": 3,
        "GIF": 4,
    }


class SizeUnits(object):
    INCH = 0
    PX = 1

    _VALUES_TO_NAMES = {
        0: "INCH",
        1: "PX",
    }

    _NAMES_TO_VALUES = {
        "INCH": 0,
        "PX": 1,
    }


class Asset(object):
    """
    Attributes:
     - _id
     - workspaceId
     - ownerId
     - acl
     - original
     - scaled
     - thumbs
     - type
     - status
     - createdAt
     - updatedAt
     - handle
     - category
     - numOfPdfPages
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'workspaceId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'ownerId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'acl', (TType.STRUCT, (gen.urbancompass.permissions.acl.ttypes.ACLEntry, gen.urbancompass.permissions.acl.ttypes.ACLEntry.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'original', (gen.urbancompass.image.ttypes.ImageMetaData, gen.urbancompass.image.ttypes.ImageMetaData.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'scaled', (gen.urbancompass.image.ttypes.ImageMetaData, gen.urbancompass.image.ttypes.ImageMetaData.thrift_spec), None, ),  # 6
        (7, TType.LIST, 'thumbs', (TType.STRUCT, (gen.urbancompass.image.ttypes.ImageMetaData, gen.urbancompass.image.ttypes.ImageMetaData.thrift_spec), False), None, ),  # 7
        (8, TType.I32, 'type', None, None, ),  # 8
        (9, TType.I32, 'status', None, None, ),  # 9
        (10, TType.I64, 'createdAt', None, None, ),  # 10
        (11, TType.I64, 'updatedAt', None, None, ),  # 11
        (12, TType.STRING, 'handle', 'UTF8', None, ),  # 12
        (13, TType.I32, 'category', None, None, ),  # 13
        (14, TType.I32, 'numOfPdfPages', None, None, ),  # 14
    )
    def __init__(self, _id=None, workspaceId=None, ownerId=None, acl=None, original=None, scaled=None, thumbs=None, type=None, status=None, createdAt=None, updatedAt=None, handle=None, category=None, numOfPdfPages=None, ):
        self._id = _id
        self.workspaceId = workspaceId
        self.ownerId = ownerId
        self.acl = acl
        self.original = original
        self.scaled = scaled
        self.thumbs = thumbs
        self.type = type
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.handle = handle
        self.category = category
        self.numOfPdfPages = numOfPdfPages

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.workspaceId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.ownerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.acl = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.permissions.acl.ttypes.ACLEntry()
                        _elem4.read(iprot)
                        self.acl.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.original = gen.urbancompass.image.ttypes.ImageMetaData()
                    self.original.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.scaled = gen.urbancompass.image.ttypes.ImageMetaData()
                    self.scaled.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.thumbs = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = gen.urbancompass.image.ttypes.ImageMetaData()
                        _elem8.read(iprot)
                        self.thumbs.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.handle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.category = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.numOfPdfPages = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Asset')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.workspaceId is not None:
            oprot.writeFieldBegin('workspaceId', TType.STRING, 2)
            oprot.writeString(self.workspaceId.encode('utf-8') if sys.version_info[0] == 2 else self.workspaceId)
            oprot.writeFieldEnd()
        if self.ownerId is not None:
            oprot.writeFieldBegin('ownerId', TType.STRING, 3)
            oprot.writeString(self.ownerId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerId)
            oprot.writeFieldEnd()
        if self.acl is not None:
            oprot.writeFieldBegin('acl', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.acl))
            for _iter10 in self.acl:
                _iter10.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.original is not None:
            oprot.writeFieldBegin('original', TType.STRUCT, 5)
            self.original.write(oprot)
            oprot.writeFieldEnd()
        if self.scaled is not None:
            oprot.writeFieldBegin('scaled', TType.STRUCT, 6)
            self.scaled.write(oprot)
            oprot.writeFieldEnd()
        if self.thumbs is not None:
            oprot.writeFieldBegin('thumbs', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.thumbs))
            for _iter11 in self.thumbs:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 8)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 9)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 10)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 11)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.handle is not None:
            oprot.writeFieldBegin('handle', TType.STRING, 12)
            oprot.writeString(self.handle.encode('utf-8') if sys.version_info[0] == 2 else self.handle)
            oprot.writeFieldEnd()
        if self.category is not None:
            oprot.writeFieldBegin('category', TType.I32, 13)
            oprot.writeI32(self.category)
            oprot.writeFieldEnd()
        if self.numOfPdfPages is not None:
            oprot.writeFieldBegin('numOfPdfPages', TType.I32, 14)
            oprot.writeI32(self.numOfPdfPages)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PageSize(object):
    """
    Attributes:
     - width
     - height
     - units
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'width', None, None, ),  # 1
        (2, TType.DOUBLE, 'height', None, None, ),  # 2
        (3, TType.I32, 'units', None, None, ),  # 3
    )
    def __init__(self, width=None, height=None, units=None, ):
        self.width = width
        self.height = height
        self.units = units

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.width = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.height = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.units = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PageSize')
        if self.width is not None:
            oprot.writeFieldBegin('width', TType.DOUBLE, 1)
            oprot.writeDouble(self.width)
            oprot.writeFieldEnd()
        if self.height is not None:
            oprot.writeFieldBegin('height', TType.DOUBLE, 2)
            oprot.writeDouble(self.height)
            oprot.writeFieldEnd()
        if self.units is not None:
            oprot.writeFieldBegin('units', TType.I32, 3)
            oprot.writeI32(self.units)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
