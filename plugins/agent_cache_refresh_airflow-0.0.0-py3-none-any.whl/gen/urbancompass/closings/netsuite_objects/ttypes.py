
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class Link(object):
    """
    Attributes:
     - rel
     - href
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'rel', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'href', 'UTF8', None, ),  # 2
    )
    def __init__(self, rel=None, href=None, ):
        self.rel = rel
        self.href = href

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.rel = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.href = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Link')
        if self.rel is not None:
            oprot.writeFieldBegin('rel', TType.STRING, 1)
            oprot.writeString(self.rel.encode('utf-8') if sys.version_info[0] == 2 else self.rel)
            oprot.writeFieldEnd()
        if self.href is not None:
            oprot.writeFieldBegin('href', TType.STRING, 2)
            oprot.writeString(self.href.encode('utf-8') if sys.version_info[0] == 2 else self.href)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Status(object):
    """
    Attributes:
     - id
     - refName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'refName', 'UTF8', None, ),  # 2
    )
    def __init__(self, id=None, refName=None, ):
        self.id = id
        self.refName = refName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.refName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Status')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.refName is not None:
            oprot.writeFieldBegin('refName', TType.STRING, 2)
            oprot.writeString(self.refName.encode('utf-8') if sys.version_info[0] == 2 else self.refName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Links(object):
    """
    Attributes:
     - links
     - id
     - refName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'links', (TType.STRUCT, (Link, Link.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'id', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'refName', 'UTF8', None, ),  # 3
    )
    def __init__(self, links=None, id=None, refName=None, ):
        self.links = links
        self.id = id
        self.refName = refName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.links = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = Link()
                        _elem4.read(iprot)
                        self.links.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.refName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Links')
        if self.links is not None:
            oprot.writeFieldBegin('links', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.links))
            for _iter6 in self.links:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 2)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.refName is not None:
            oprot.writeFieldBegin('refName', TType.STRING, 3)
            oprot.writeString(self.refName.encode('utf-8') if sys.version_info[0] == 2 else self.refName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UcDeal(object):
    """
    Attributes:
     - links
     - custrecord_uc_deal_status
     - custrecord_uc_deal_contractstatus
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'links', (TType.STRUCT, (Link, Link.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'custrecord_uc_deal_status', (Links, Links.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'custrecord_uc_deal_contractstatus', (Links, Links.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'id', 'UTF8', None, ),  # 4
    )
    def __init__(self, links=None, custrecord_uc_deal_status=None, custrecord_uc_deal_contractstatus=None, id=None, ):
        self.links = links
        self.custrecord_uc_deal_status = custrecord_uc_deal_status
        self.custrecord_uc_deal_contractstatus = custrecord_uc_deal_contractstatus
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.links = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = Link()
                        _elem9.read(iprot)
                        self.links.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.custrecord_uc_deal_status = Links()
                    self.custrecord_uc_deal_status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.custrecord_uc_deal_contractstatus = Links()
                    self.custrecord_uc_deal_contractstatus.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UcDeal')
        if self.links is not None:
            oprot.writeFieldBegin('links', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.links))
            for _iter11 in self.links:
                _iter11.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.custrecord_uc_deal_status is not None:
            oprot.writeFieldBegin('custrecord_uc_deal_status', TType.STRUCT, 2)
            self.custrecord_uc_deal_status.write(oprot)
            oprot.writeFieldEnd()
        if self.custrecord_uc_deal_contractstatus is not None:
            oprot.writeFieldBegin('custrecord_uc_deal_contractstatus', TType.STRUCT, 3)
            self.custrecord_uc_deal_contractstatus.write(oprot)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 4)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UcDealQueryResult(object):
    """
    Attributes:
     - links
     - count
     - hasMore
     - items
     - offset
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'links', (TType.STRUCT, (Link, Link.thrift_spec), False), None, ),  # 1
        (2, TType.I32, 'count', None, None, ),  # 2
        (3, TType.BOOL, 'hasMore', None, None, ),  # 3
        (4, TType.LIST, 'items', (TType.STRUCT, (Links, Links.thrift_spec), False), None, ),  # 4
        (5, TType.I32, 'offset', None, None, ),  # 5
        (6, TType.I32, 'totalResults', None, None, ),  # 6
    )
    def __init__(self, links=None, count=None, hasMore=None, items=None, offset=None, totalResults=None, ):
        self.links = links
        self.count = count
        self.hasMore = hasMore
        self.items = items
        self.offset = offset
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.links = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = Link()
                        _elem14.read(iprot)
                        self.links.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasMore = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.items = []
                    (_etype16, _size19) = iprot.readListBegin()
                    for _i17 in range(_size19):
                        _elem18 = Links()
                        _elem18.read(iprot)
                        self.items.append(_elem18)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UcDealQueryResult')
        if self.links is not None:
            oprot.writeFieldBegin('links', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.links))
            for _iter20 in self.links:
                _iter20.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 2)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.hasMore is not None:
            oprot.writeFieldBegin('hasMore', TType.BOOL, 3)
            oprot.writeBool(self.hasMore)
            oprot.writeFieldEnd()
        if self.items is not None:
            oprot.writeFieldBegin('items', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.items))
            for _iter21 in self.items:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 5)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 6)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UcVendorBill(object):
    """
    Attributes:
     - links
     - status
     - total
     - received
     - custbody_callidus_deals_id_main
     - id
     - custbody_date_agent_paid
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'links', (TType.STRUCT, (Link, Link.thrift_spec), False), None, ),  # 1
        (2, TType.STRUCT, 'status', (Status, Status.thrift_spec), None, ),  # 2
        (3, TType.DOUBLE, 'total', None, None, ),  # 3
        (4, TType.BOOL, 'received', None, None, ),  # 4
        (5, TType.STRUCT, 'custbody_callidus_deals_id_main', (Links, Links.thrift_spec), None, ),  # 5
        (6, TType.STRING, 'id', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'custbody_date_agent_paid', 'UTF8', None, ),  # 7
    )
    def __init__(self, links=None, status=None, total=None, received=None, custbody_callidus_deals_id_main=None, id=None, custbody_date_agent_paid=None, ):
        self.links = links
        self.status = status
        self.total = total
        self.received = received
        self.custbody_callidus_deals_id_main = custbody_callidus_deals_id_main
        self.id = id
        self.custbody_date_agent_paid = custbody_date_agent_paid

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.links = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = Link()
                        _elem24.read(iprot)
                        self.links.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.status = Status()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.total = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.received = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.custbody_callidus_deals_id_main = Links()
                    self.custbody_callidus_deals_id_main.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.custbody_date_agent_paid = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UcVendorBill')
        if self.links is not None:
            oprot.writeFieldBegin('links', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.links))
            for _iter26 in self.links:
                _iter26.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 2)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.total is not None:
            oprot.writeFieldBegin('total', TType.DOUBLE, 3)
            oprot.writeDouble(self.total)
            oprot.writeFieldEnd()
        if self.received is not None:
            oprot.writeFieldBegin('received', TType.BOOL, 4)
            oprot.writeBool(self.received)
            oprot.writeFieldEnd()
        if self.custbody_callidus_deals_id_main is not None:
            oprot.writeFieldBegin('custbody_callidus_deals_id_main', TType.STRUCT, 5)
            self.custbody_callidus_deals_id_main.write(oprot)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 6)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.custbody_date_agent_paid is not None:
            oprot.writeFieldBegin('custbody_date_agent_paid', TType.STRING, 7)
            oprot.writeString(self.custbody_date_agent_paid.encode('utf-8') if sys.version_info[0] == 2 else self.custbody_date_agent_paid)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
