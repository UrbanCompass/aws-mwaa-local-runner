"""Module for configuring a logger to output JSON logs to stdout/stderr, with
Datadog-specific attributes. Also injects APM trace_id when found.

Example usage:
  >>> from base.dd_logs import cfg_docker_dd_json_logger
  >>> logger = cfg_docker_dd_json_logger('my_logger')
  >>> logger.info('Some log message')
  {"dd": {"span_id": 0, "trace_id": 0}, "logger": {"name": "my_logger",
  "thread_name": "not_set"}, "message": "Some log message", "status": "INFO",
  "time": "2019-03-26T18:30:00.899127"}

Or:
  >>> from base.dd_logs import cfg_docker_dd_json_logger
  >>> import logging
  >>> cfg_docker_dd_json_logger()
  >>> logging.info('%s', 'Some other log message', extra={'datadog': {'arbitrary': 'val'}})
  {"compass": {"arbitrary": "val"}, "dd": {"span_id": 0, "trace_id": 0},
  "logger": {"name": "root", "thread_name": "MainThread"},
  "message": "Some other log message", "status": "INFO",
  "time": "2019-04-10T16:22:22.653934"}
"""
import datetime
import json
import logging
import sys
import traceback

from ddtrace.helpers import get_correlation_ids


def _format_datadog_log(
    level,
    message,
    time_str=None,
    logger="not_set",
    thread_name="not_set",
    extra_fields=None,
    err=None,
):
    """All the fields set here are special Datadog attributes (except for 'compass')"""
    record = {
        "time": time_str or datetime.datetime.now().isoformat(),
        "status": level,
        "message": message,
        "logger": {
            "name": logger,
            "thread_name": thread_name,
        },
    }

    trace_id, span_id = get_correlation_ids()
    record["dd"] = {
        "trace_id": trace_id or 0,
        "span_id": span_id or 0,
    }

    if err:
        record["error"] = {
            "kind": type(err).__name__,
            # Apparently err.message doesn't exist in Python 3
            "message": str(err),
            "stack": traceback.format_exc(),
        }

    if extra_fields:
        record["compass"] = extra_fields

    return record


class DatadogJsonFormatter(logging.Formatter):
    """Format log messages in Datadog-specific JSON

    Truncates log messages at 10000 characters.

    Gives special treatment to the 'datadog' field in the dict passed to the
    'extra' param and ignores the rest of the fields. Ex:

    >>> logging.info('some message %s', some_str, extra={'datadog': some_dict})
    """

    def __init__(self, max_msg_len=10000):
        super(DatadogJsonFormatter, self).__init__(fmt="%(message)s", datefmt=None)
        self.MAX_MESSAGE_LENGTH = max_msg_len

    def format(self, record):
        message = record.message = record.getMessage()
        time_str = datetime.datetime.fromtimestamp(record.created).isoformat()

        if len(message) > self.MAX_MESSAGE_LENGTH:
            message = message[: self.MAX_MESSAGE_LENGTH] + " ... (truncated)"

        r = _format_datadog_log(
            record.levelname,
            message,
            time_str=time_str,
            logger=record.name,
            thread_name=record.threadName,
            extra_fields=getattr(record, "datadog", None),
            err=record.exc_info,
        )
        return json.dumps(r, sort_keys=True)


class _LevelFilter(logging.Filter):
    """Filter for logs that fall in a given range of log levels

    Taken from: https://stackoverflow.com/questions/36337244/
    """

    def __init__(self, low, high):
        self._low = low
        self._high = high
        super(_LevelFilter, self).__init__()

    def filter(self, record):
        return self._low <= record.levelno <= self._high


def cfg_docker_dd_json_logger(name=None, level=logging.INFO):
    """Configure a logger for sending logs in JSON to Datadog from a Docker
    container.

    Datadog magically parses JSON logs. Docker containers usually log to
    stdout/stderr.
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    f = DatadogJsonFormatter()

    # Log all WARNING and below logs to stdout
    h = logging.StreamHandler(sys.stdout)
    h.addFilter(_LevelFilter(logging.DEBUG, logging.WARNING))
    h.setFormatter(f)
    logger.addHandler(h)

    # Log all ERROR and above logs to stderr
    eh = logging.StreamHandler(sys.stderr)
    eh.setLevel(logging.ERROR)
    eh.setFormatter(f)
    logger.addHandler(eh)

    return logger
