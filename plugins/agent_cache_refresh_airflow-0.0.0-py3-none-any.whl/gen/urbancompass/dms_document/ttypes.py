
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes

from thrift.transport import TTransport


class DmsDocumentReviewStatus(object):
    APPROVED = 0
    REJECTED = 1
    COMMENTED = 2
    IN_REVIEW = 3

    _VALUES_TO_NAMES = {
        0: "APPROVED",
        1: "REJECTED",
        2: "COMMENTED",
        3: "IN_REVIEW",
    }

    _NAMES_TO_VALUES = {
        "APPROVED": 0,
        "REJECTED": 1,
        "COMMENTED": 2,
        "IN_REVIEW": 3,
    }


class DmsDocumentStatus(object):
    UPLOADED = 0
    READY_FOR_REVIEW = 1
    IN_REVIEW = 2
    APPROVED = 3
    REJECTED = 4

    _VALUES_TO_NAMES = {
        0: "UPLOADED",
        1: "READY_FOR_REVIEW",
        2: "IN_REVIEW",
        3: "APPROVED",
        4: "REJECTED",
    }

    _NAMES_TO_VALUES = {
        "UPLOADED": 0,
        "READY_FOR_REVIEW": 1,
        "IN_REVIEW": 2,
        "APPROVED": 3,
        "REJECTED": 4,
    }


class NoteType(object):
    COMMENT = 0
    REVIEW_COMMENT = 1

    _VALUES_TO_NAMES = {
        0: "COMMENT",
        1: "REVIEW_COMMENT",
    }

    _NAMES_TO_VALUES = {
        "COMMENT": 0,
        "REVIEW_COMMENT": 1,
    }


class AllUploadsEntry(object):
    """
    Attributes:
     - documentId
     - documentName
     - isPacket
     - createdDate
     - createdBy
     - createdByDisplayName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'documentId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentName', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isPacket', None, None, ),  # 3
        (4, TType.I64, 'createdDate', None, None, ),  # 4
        (5, TType.STRING, 'createdBy', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'createdByDisplayName', 'UTF8', None, ),  # 6
    )
    def __init__(self, documentId=None, documentName=None, isPacket=None, createdDate=None, createdBy=None, createdByDisplayName=None, ):
        self.documentId = documentId
        self.documentName = documentName
        self.isPacket = isPacket
        self.createdDate = createdDate
        self.createdBy = createdBy
        self.createdByDisplayName = createdByDisplayName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.createdDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.createdByDisplayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AllUploadsEntry')
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 1)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.documentName is not None:
            oprot.writeFieldBegin('documentName', TType.STRING, 2)
            oprot.writeString(self.documentName.encode('utf-8') if sys.version_info[0] == 2 else self.documentName)
            oprot.writeFieldEnd()
        if self.isPacket is not None:
            oprot.writeFieldBegin('isPacket', TType.BOOL, 3)
            oprot.writeBool(self.isPacket)
            oprot.writeFieldEnd()
        if self.createdDate is not None:
            oprot.writeFieldBegin('createdDate', TType.I64, 4)
            oprot.writeI64(self.createdDate)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 5)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.createdByDisplayName is not None:
            oprot.writeFieldBegin('createdByDisplayName', TType.STRING, 6)
            oprot.writeString(self.createdByDisplayName.encode('utf-8') if sys.version_info[0] == 2 else self.createdByDisplayName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDocument(object):
    """
    Attributes:
     - documentId
     - version
     - teamId
     - documentName
     - data
     - createdBy
     - mimeType
     - dmsFolderId
     - createdTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'documentId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'version', None, None, ),  # 2
        (3, TType.STRING, 'teamId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'documentName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'data', 'BINARY', None, ),  # 5
        (6, TType.STRING, 'createdBy', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'mimeType', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dmsFolderId', 'UTF8', None, ),  # 8
        (9, TType.I64, 'createdTime', None, None, ),  # 9
    )
    def __init__(self, documentId=None, version=None, teamId=None, documentName=None, data=None, createdBy=None, mimeType=None, dmsFolderId=None, createdTime=None, ):
        self.documentId = documentId
        self.version = version
        self.teamId = teamId
        self.documentName = documentName
        self.data = data
        self.createdBy = createdBy
        self.mimeType = mimeType
        self.dmsFolderId = dmsFolderId
        self.createdTime = createdTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.documentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.data = iprot.readBinary()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.mimeType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dmsFolderId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDocument')
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 1)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 2)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 3)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.documentName is not None:
            oprot.writeFieldBegin('documentName', TType.STRING, 4)
            oprot.writeString(self.documentName.encode('utf-8') if sys.version_info[0] == 2 else self.documentName)
            oprot.writeFieldEnd()
        if self.data is not None:
            oprot.writeFieldBegin('data', TType.STRING, 5)
            oprot.writeBinary(self.data)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 6)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.mimeType is not None:
            oprot.writeFieldBegin('mimeType', TType.STRING, 7)
            oprot.writeString(self.mimeType.encode('utf-8') if sys.version_info[0] == 2 else self.mimeType)
            oprot.writeFieldEnd()
        if self.dmsFolderId is not None:
            oprot.writeFieldBegin('dmsFolderId', TType.STRING, 8)
            oprot.writeString(self.dmsFolderId.encode('utf-8') if sys.version_info[0] == 2 else self.dmsFolderId)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 9)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDocumentInternal(object):
    """
    Attributes:
     - documentId
     - createdBy
     - createdTime
     - teamId
     - groupingId
     - documentName
     - lastModifiedTime
     - lastModifiedBy
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'documentId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'createdBy', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdTime', None, None, ),  # 3
        (4, TType.STRING, 'teamId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'groupingId', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'documentName', 'UTF8', None, ),  # 6
        (7, TType.I64, 'lastModifiedTime', None, None, ),  # 7
        (8, TType.STRING, 'lastModifiedBy', 'UTF8', None, ),  # 8
        (9, TType.BOOL, 'isDeleted', None, None, ),  # 9
    )
    def __init__(self, documentId=None, createdBy=None, createdTime=None, teamId=None, groupingId=None, documentName=None, lastModifiedTime=None, lastModifiedBy=None, isDeleted=None, ):
        self.documentId = documentId
        self.createdBy = createdBy
        self.createdTime = createdTime
        self.teamId = teamId
        self.groupingId = groupingId
        self.documentName = documentName
        self.lastModifiedTime = lastModifiedTime
        self.lastModifiedBy = lastModifiedBy
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.groupingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.documentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.lastModifiedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDocumentInternal')
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 1)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 2)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 3)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 4)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.groupingId is not None:
            oprot.writeFieldBegin('groupingId', TType.STRING, 5)
            oprot.writeString(self.groupingId.encode('utf-8') if sys.version_info[0] == 2 else self.groupingId)
            oprot.writeFieldEnd()
        if self.documentName is not None:
            oprot.writeFieldBegin('documentName', TType.STRING, 6)
            oprot.writeString(self.documentName.encode('utf-8') if sys.version_info[0] == 2 else self.documentName)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 7)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.lastModifiedBy is not None:
            oprot.writeFieldBegin('lastModifiedBy', TType.STRING, 8)
            oprot.writeString(self.lastModifiedBy.encode('utf-8') if sys.version_info[0] == 2 else self.lastModifiedBy)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 9)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDocumentMetadata(object):
    """
    Attributes:
     - currentVersion
     - lastModifiedTime
     - documentStatus
     - reviewedBy
     - reviewedTime
     - reviewNote
     - lastModifiedBy
     - isPacket
     - documentId
     - createdTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'currentVersion', None, None, ),  # 1
        (2, TType.I64, 'lastModifiedTime', None, None, ),  # 2
        (3, TType.I32, 'documentStatus', None, None, ),  # 3
        (4, TType.STRING, 'reviewedBy', 'UTF8', None, ),  # 4
        (5, TType.I64, 'reviewedTime', None, None, ),  # 5
        (6, TType.STRING, 'reviewNote', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'lastModifiedBy', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isPacket', None, None, ),  # 8
        (9, TType.STRING, 'documentId', 'UTF8', None, ),  # 9
        (10, TType.I64, 'createdTime', None, None, ),  # 10
    )
    def __init__(self, currentVersion=None, lastModifiedTime=None, documentStatus=None, reviewedBy=None, reviewedTime=None, reviewNote=None, lastModifiedBy=None, isPacket=None, documentId=None, createdTime=None, ):
        self.currentVersion = currentVersion
        self.lastModifiedTime = lastModifiedTime
        self.documentStatus = documentStatus
        self.reviewedBy = reviewedBy
        self.reviewedTime = reviewedTime
        self.reviewNote = reviewNote
        self.lastModifiedBy = lastModifiedBy
        self.isPacket = isPacket
        self.documentId = documentId
        self.createdTime = createdTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.currentVersion = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.documentStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.reviewedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.reviewedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.reviewNote = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.lastModifiedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDocumentMetadata')
        if self.currentVersion is not None:
            oprot.writeFieldBegin('currentVersion', TType.I32, 1)
            oprot.writeI32(self.currentVersion)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 2)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.documentStatus is not None:
            oprot.writeFieldBegin('documentStatus', TType.I32, 3)
            oprot.writeI32(self.documentStatus)
            oprot.writeFieldEnd()
        if self.reviewedBy is not None:
            oprot.writeFieldBegin('reviewedBy', TType.STRING, 4)
            oprot.writeString(self.reviewedBy.encode('utf-8') if sys.version_info[0] == 2 else self.reviewedBy)
            oprot.writeFieldEnd()
        if self.reviewedTime is not None:
            oprot.writeFieldBegin('reviewedTime', TType.I64, 5)
            oprot.writeI64(self.reviewedTime)
            oprot.writeFieldEnd()
        if self.reviewNote is not None:
            oprot.writeFieldBegin('reviewNote', TType.STRING, 6)
            oprot.writeString(self.reviewNote.encode('utf-8') if sys.version_info[0] == 2 else self.reviewNote)
            oprot.writeFieldEnd()
        if self.lastModifiedBy is not None:
            oprot.writeFieldBegin('lastModifiedBy', TType.STRING, 7)
            oprot.writeString(self.lastModifiedBy.encode('utf-8') if sys.version_info[0] == 2 else self.lastModifiedBy)
            oprot.writeFieldEnd()
        if self.isPacket is not None:
            oprot.writeFieldBegin('isPacket', TType.BOOL, 8)
            oprot.writeBool(self.isPacket)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 9)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 10)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDocumentNote(object):
    """
    Attributes:
     - noteId
     - version
     - createdBy
     - note
     - createdTime
     - lastModifiedTime
     - documentId
     - noteType
     - isDeleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'noteId', None, None, ),  # 1
        (2, TType.I32, 'version', None, None, ),  # 2
        (3, TType.STRING, 'createdBy', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'note', 'UTF8', None, ),  # 4
        (5, TType.I64, 'createdTime', None, None, ),  # 5
        (6, TType.I64, 'lastModifiedTime', None, None, ),  # 6
        (7, TType.STRING, 'documentId', 'UTF8', None, ),  # 7
        (8, TType.I32, 'noteType', None, None, ),  # 8
        (9, TType.BOOL, 'isDeleted', None, None, ),  # 9
    )
    def __init__(self, noteId=None, version=None, createdBy=None, note=None, createdTime=None, lastModifiedTime=None, documentId=None, noteType=None, isDeleted=None, ):
        self.noteId = noteId
        self.version = version
        self.createdBy = createdBy
        self.note = note
        self.createdTime = createdTime
        self.lastModifiedTime = lastModifiedTime
        self.documentId = documentId
        self.noteType = noteType
        self.isDeleted = isDeleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.noteId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.note = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.noteType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDocumentNote')
        if self.noteId is not None:
            oprot.writeFieldBegin('noteId', TType.I32, 1)
            oprot.writeI32(self.noteId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 2)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 3)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.note is not None:
            oprot.writeFieldBegin('note', TType.STRING, 4)
            oprot.writeString(self.note.encode('utf-8') if sys.version_info[0] == 2 else self.note)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 5)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 6)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 7)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.noteType is not None:
            oprot.writeFieldBegin('noteType', TType.I32, 8)
            oprot.writeI32(self.noteType)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 9)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDocumentReviewInternal(object):
    """
    Attributes:
     - documentId
     - version
     - reviewedBy
     - reviewedTime
     - reviewStatus
     - reviewNoteId
     - isDeleted
     - reviewId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'documentId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'version', None, None, ),  # 2
        (3, TType.STRING, 'reviewedBy', 'UTF8', None, ),  # 3
        (4, TType.I64, 'reviewedTime', None, None, ),  # 4
        (5, TType.I32, 'reviewStatus', None, None, ),  # 5
        (6, TType.I32, 'reviewNoteId', None, None, ),  # 6
        (7, TType.BOOL, 'isDeleted', None, None, ),  # 7
        (8, TType.I32, 'reviewId', None, None, ),  # 8
    )
    def __init__(self, documentId=None, version=None, reviewedBy=None, reviewedTime=None, reviewStatus=None, reviewNoteId=None, isDeleted=None, reviewId=None, ):
        self.documentId = documentId
        self.version = version
        self.reviewedBy = reviewedBy
        self.reviewedTime = reviewedTime
        self.reviewStatus = reviewStatus
        self.reviewNoteId = reviewNoteId
        self.isDeleted = isDeleted
        self.reviewId = reviewId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.reviewedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.reviewedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.reviewStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.reviewNoteId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.reviewId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDocumentReviewInternal')
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 1)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 2)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.reviewedBy is not None:
            oprot.writeFieldBegin('reviewedBy', TType.STRING, 3)
            oprot.writeString(self.reviewedBy.encode('utf-8') if sys.version_info[0] == 2 else self.reviewedBy)
            oprot.writeFieldEnd()
        if self.reviewedTime is not None:
            oprot.writeFieldBegin('reviewedTime', TType.I64, 4)
            oprot.writeI64(self.reviewedTime)
            oprot.writeFieldEnd()
        if self.reviewStatus is not None:
            oprot.writeFieldBegin('reviewStatus', TType.I32, 5)
            oprot.writeI32(self.reviewStatus)
            oprot.writeFieldEnd()
        if self.reviewNoteId is not None:
            oprot.writeFieldBegin('reviewNoteId', TType.I32, 6)
            oprot.writeI32(self.reviewNoteId)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 7)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.reviewId is not None:
            oprot.writeFieldBegin('reviewId', TType.I32, 8)
            oprot.writeI32(self.reviewId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DmsDocumentVersion(object):
    """
    Attributes:
     - documentId
     - version
     - createdBy
     - createdTime
     - status
     - lastModifiedTime
     - lastModifiedBy
     - isDeleted
     - isPacket
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'documentId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'version', None, None, ),  # 2
        (3, TType.STRING, 'createdBy', 'UTF8', None, ),  # 3
        (4, TType.I64, 'createdTime', None, None, ),  # 4
        (5, TType.I32, 'status', None, None, ),  # 5
        (6, TType.I64, 'lastModifiedTime', None, None, ),  # 6
        (7, TType.STRING, 'lastModifiedBy', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.BOOL, 'isPacket', None, None, ),  # 9
    )
    def __init__(self, documentId=None, version=None, createdBy=None, createdTime=None, status=None, lastModifiedTime=None, lastModifiedBy=None, isDeleted=None, isPacket=None, ):
        self.documentId = documentId
        self.version = version
        self.createdBy = createdBy
        self.createdTime = createdTime
        self.status = status
        self.lastModifiedTime = lastModifiedTime
        self.lastModifiedBy = lastModifiedBy
        self.isDeleted = isDeleted
        self.isPacket = isPacket

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.lastModifiedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isPacket = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DmsDocumentVersion')
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 1)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 2)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 3)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 4)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 5)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 6)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.lastModifiedBy is not None:
            oprot.writeFieldBegin('lastModifiedBy', TType.STRING, 7)
            oprot.writeString(self.lastModifiedBy.encode('utf-8') if sys.version_info[0] == 2 else self.lastModifiedBy)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.isPacket is not None:
            oprot.writeFieldBegin('isPacket', TType.BOOL, 9)
            oprot.writeBool(self.isPacket)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DocumentGroupingSummary(object):
    """
    Attributes:
     - lastUpdatedDate
     - numDocumentsPending
     - lastReviewedDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'lastUpdatedDate', None, None, ),  # 1
        (2, TType.I32, 'numDocumentsPending', None, None, ),  # 2
        (3, TType.I64, 'lastReviewedDate', None, None, ),  # 3
    )
    def __init__(self, lastUpdatedDate=None, numDocumentsPending=None, lastReviewedDate=None, ):
        self.lastUpdatedDate = lastUpdatedDate
        self.numDocumentsPending = numDocumentsPending
        self.lastReviewedDate = lastReviewedDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.lastUpdatedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.numDocumentsPending = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.lastReviewedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DocumentGroupingSummary')
        if self.lastUpdatedDate is not None:
            oprot.writeFieldBegin('lastUpdatedDate', TType.I64, 1)
            oprot.writeI64(self.lastUpdatedDate)
            oprot.writeFieldEnd()
        if self.numDocumentsPending is not None:
            oprot.writeFieldBegin('numDocumentsPending', TType.I32, 2)
            oprot.writeI32(self.numDocumentsPending)
            oprot.writeFieldEnd()
        if self.lastReviewedDate is not None:
            oprot.writeFieldBegin('lastReviewedDate', TType.I64, 3)
            oprot.writeI64(self.lastReviewedDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PageInterval(object):
    """
    Attributes:
     - startPage
     - endPage
     - fileName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'startPage', None, None, ),  # 1
        (2, TType.I32, 'endPage', None, None, ),  # 2
        (3, TType.STRING, 'fileName', 'UTF8', None, ),  # 3
    )
    def __init__(self, startPage=None, endPage=None, fileName=None, ):
        self.startPage = startPage
        self.endPage = endPage
        self.fileName = fileName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.startPage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.endPage = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.fileName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PageInterval')
        if self.startPage is not None:
            oprot.writeFieldBegin('startPage', TType.I32, 1)
            oprot.writeI32(self.startPage)
            oprot.writeFieldEnd()
        if self.endPage is not None:
            oprot.writeFieldBegin('endPage', TType.I32, 2)
            oprot.writeI32(self.endPage)
            oprot.writeFieldEnd()
        if self.fileName is not None:
            oprot.writeFieldBegin('fileName', TType.STRING, 3)
            oprot.writeString(self.fileName.encode('utf-8') if sys.version_info[0] == 2 else self.fileName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
