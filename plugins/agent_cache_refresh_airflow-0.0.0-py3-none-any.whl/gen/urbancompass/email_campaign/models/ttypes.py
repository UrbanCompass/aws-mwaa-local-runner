
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class CampaignStatus(object):
    SCHEDULED = 0
    CANCELED = 1
    SENT = 2
    PENDING = 3
    FAILED = 4
    CREATED = 5

    _VALUES_TO_NAMES = {
        0: "SCHEDULED",
        1: "CANCELED",
        2: "SENT",
        3: "PENDING",
        4: "FAILED",
        5: "CREATED",
    }

    _NAMES_TO_VALUES = {
        "SCHEDULED": 0,
        "CANCELED": 1,
        "SENT": 2,
        "PENDING": 3,
        "FAILED": 4,
        "CREATED": 5,
    }


class CrmCategory(object):
    GROUP = 0
    TAG = 1
    AUDIENCE = 2
    CONTACT = 3

    _VALUES_TO_NAMES = {
        0: "GROUP",
        1: "TAG",
        2: "AUDIENCE",
        3: "CONTACT",
    }

    _NAMES_TO_VALUES = {
        "GROUP": 0,
        "TAG": 1,
        "AUDIENCE": 2,
        "CONTACT": 3,
    }


class Esp(object):
    SENDGRID_MC = 0
    NOTIFICATION_SERVICE = 1

    _VALUES_TO_NAMES = {
        0: "SENDGRID_MC",
        1: "NOTIFICATION_SERVICE",
    }

    _NAMES_TO_VALUES = {
        "SENDGRID_MC": 0,
        "NOTIFICATION_SERVICE": 1,
    }


class FilterReason(object):
    UNSUBSCRIBE = 0
    NON_DELIVERY = 1

    _VALUES_TO_NAMES = {
        0: "UNSUBSCRIBE",
        1: "NON_DELIVERY",
    }

    _NAMES_TO_VALUES = {
        "UNSUBSCRIBE": 0,
        "NON_DELIVERY": 1,
    }


class ImportJobStatus(object):
    DEFAULT = 0
    IN_PROGRESS = 1
    COMPLETED = 2
    FAILED = 3

    _VALUES_TO_NAMES = {
        0: "DEFAULT",
        1: "IN_PROGRESS",
        2: "COMPLETED",
        3: "FAILED",
    }

    _NAMES_TO_VALUES = {
        "DEFAULT": 0,
        "IN_PROGRESS": 1,
        "COMPLETED": 2,
        "FAILED": 3,
    }


class Contact(object):
    """
    Attributes:
     - name
     - emailAddress
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'emailAddress', 'UTF8', None, ),  # 2
    )
    def __init__(self, name=None, emailAddress=None, ):
        self.name = name
        self.emailAddress = emailAddress

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.emailAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Contact')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.emailAddress is not None:
            oprot.writeFieldBegin('emailAddress', TType.STRING, 2)
            oprot.writeString(self.emailAddress.encode('utf-8') if sys.version_info[0] == 2 else self.emailAddress)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CrmEntity(object):
    """
    Attributes:
     - crmId
     - category
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'crmId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'category', None, None, ),  # 2
    )
    def __init__(self, crmId=None, category=None, ):
        self.crmId = crmId
        self.category = category

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.crmId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.category = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CrmEntity')
        if self.crmId is not None:
            oprot.writeFieldBegin('crmId', TType.STRING, 1)
            oprot.writeString(self.crmId.encode('utf-8') if sys.version_info[0] == 2 else self.crmId)
            oprot.writeFieldEnd()
        if self.category is not None:
            oprot.writeFieldBegin('category', TType.I32, 2)
            oprot.writeI32(self.category)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FilteredRecipient(object):
    """
    Attributes:
     - email
     - reason
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'email', 'UTF8', None, ),  # 1
        (2, TType.I32, 'reason', None, None, ),  # 2
    )
    def __init__(self, email=None, reason=None, ):
        self.email = email
        self.reason = reason

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.reason = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FilteredRecipient')
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 1)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.reason is not None:
            oprot.writeFieldBegin('reason', TType.I32, 2)
            oprot.writeI32(self.reason)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ImportJob(object):
    """
    Attributes:
     - id
     - userId
     - jobStarted
     - fetchCompleted
     - jobCompleted
     - status
     - numSendgridContacts
     - numProcessedContacts
     - numCrmMarketingContacts
     - failureReason
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        (3, TType.I64, 'jobStarted', None, None, ),  # 3
        (4, TType.I64, 'fetchCompleted', None, None, ),  # 4
        (5, TType.I64, 'jobCompleted', None, None, ),  # 5
        (6, TType.I32, 'status', None, None, ),  # 6
        (7, TType.I32, 'numSendgridContacts', None, None, ),  # 7
        (8, TType.I32, 'numProcessedContacts', None, None, ),  # 8
        (9, TType.I32, 'numCrmMarketingContacts', None, None, ),  # 9
        (10, TType.STRING, 'failureReason', 'UTF8', None, ),  # 10
    )
    def __init__(self, id=None, userId=None, jobStarted=None, fetchCompleted=None, jobCompleted=None, status=None, numSendgridContacts=None, numProcessedContacts=None, numCrmMarketingContacts=None, failureReason=None, ):
        self.id = id
        self.userId = userId
        self.jobStarted = jobStarted
        self.fetchCompleted = fetchCompleted
        self.jobCompleted = jobCompleted
        self.status = status
        self.numSendgridContacts = numSendgridContacts
        self.numProcessedContacts = numProcessedContacts
        self.numCrmMarketingContacts = numCrmMarketingContacts
        self.failureReason = failureReason

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.jobStarted = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.fetchCompleted = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.jobCompleted = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.numSendgridContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.numProcessedContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.numCrmMarketingContacts = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.failureReason = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ImportJob')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.jobStarted is not None:
            oprot.writeFieldBegin('jobStarted', TType.I64, 3)
            oprot.writeI64(self.jobStarted)
            oprot.writeFieldEnd()
        if self.fetchCompleted is not None:
            oprot.writeFieldBegin('fetchCompleted', TType.I64, 4)
            oprot.writeI64(self.fetchCompleted)
            oprot.writeFieldEnd()
        if self.jobCompleted is not None:
            oprot.writeFieldBegin('jobCompleted', TType.I64, 5)
            oprot.writeI64(self.jobCompleted)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 6)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.numSendgridContacts is not None:
            oprot.writeFieldBegin('numSendgridContacts', TType.I32, 7)
            oprot.writeI32(self.numSendgridContacts)
            oprot.writeFieldEnd()
        if self.numProcessedContacts is not None:
            oprot.writeFieldBegin('numProcessedContacts', TType.I32, 8)
            oprot.writeI32(self.numProcessedContacts)
            oprot.writeFieldEnd()
        if self.numCrmMarketingContacts is not None:
            oprot.writeFieldBegin('numCrmMarketingContacts', TType.I32, 9)
            oprot.writeI32(self.numCrmMarketingContacts)
            oprot.writeFieldEnd()
        if self.failureReason is not None:
            oprot.writeFieldBegin('failureReason', TType.STRING, 10)
            oprot.writeString(self.failureReason.encode('utf-8') if sys.version_info[0] == 2 else self.failureReason)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SendDetails(object):
    """
    Attributes:
     - status
     - scheduledTime
     - statusSetAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'status', None, None, ),  # 1
        (2, TType.I64, 'scheduledTime', None, None, ),  # 2
        (3, TType.I64, 'statusSetAt', None, None, ),  # 3
    )
    def __init__(self, status=None, scheduledTime=None, statusSetAt=None, ):
        self.status = status
        self.scheduledTime = scheduledTime
        self.statusSetAt = statusSetAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.scheduledTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.statusSetAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SendDetails')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 1)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.scheduledTime is not None:
            oprot.writeFieldBegin('scheduledTime', TType.I64, 2)
            oprot.writeI64(self.scheduledTime)
            oprot.writeFieldEnd()
        if self.statusSetAt is not None:
            oprot.writeFieldBegin('statusSetAt', TType.I64, 3)
            oprot.writeI64(self.statusSetAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SenderIdentity(object):
    """
    Attributes:
     - id
     - fromName
     - fromAddress
     - replyToAddress
     - verified
     - userId
     - userEmail
     - createdAt
     - updatedAt
     - defaultIdentity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'fromName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'fromAddress', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'replyToAddress', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'verified', None, None, ),  # 5
        (6, TType.STRING, 'userId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'userEmail', 'UTF8', None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
        (9, TType.I64, 'updatedAt', None, None, ),  # 9
        (10, TType.BOOL, 'defaultIdentity', None, None, ),  # 10
    )
    def __init__(self, id=None, fromName=None, fromAddress=None, replyToAddress=None, verified=None, userId=None, userEmail=None, createdAt=None, updatedAt=None, defaultIdentity=None, ):
        self.id = id
        self.fromName = fromName
        self.fromAddress = fromAddress
        self.replyToAddress = replyToAddress
        self.verified = verified
        self.userId = userId
        self.userEmail = userEmail
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.defaultIdentity = defaultIdentity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.fromName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.fromAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.replyToAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.verified = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.userEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.defaultIdentity = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SenderIdentity')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.fromName is not None:
            oprot.writeFieldBegin('fromName', TType.STRING, 2)
            oprot.writeString(self.fromName.encode('utf-8') if sys.version_info[0] == 2 else self.fromName)
            oprot.writeFieldEnd()
        if self.fromAddress is not None:
            oprot.writeFieldBegin('fromAddress', TType.STRING, 3)
            oprot.writeString(self.fromAddress.encode('utf-8') if sys.version_info[0] == 2 else self.fromAddress)
            oprot.writeFieldEnd()
        if self.replyToAddress is not None:
            oprot.writeFieldBegin('replyToAddress', TType.STRING, 4)
            oprot.writeString(self.replyToAddress.encode('utf-8') if sys.version_info[0] == 2 else self.replyToAddress)
            oprot.writeFieldEnd()
        if self.verified is not None:
            oprot.writeFieldBegin('verified', TType.BOOL, 5)
            oprot.writeBool(self.verified)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 6)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userEmail is not None:
            oprot.writeFieldBegin('userEmail', TType.STRING, 7)
            oprot.writeString(self.userEmail.encode('utf-8') if sys.version_info[0] == 2 else self.userEmail)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 9)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.defaultIdentity is not None:
            oprot.writeFieldBegin('defaultIdentity', TType.BOOL, 10)
            oprot.writeBool(self.defaultIdentity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TargetRecipientGroup(object):
    """
    Attributes:
     - crmEntities
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'crmEntities', (TType.STRUCT, (CrmEntity, CrmEntity.thrift_spec), False), None, ),  # 1
    )
    def __init__(self, crmEntities=None, ):
        self.crmEntities = crmEntities

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.crmEntities = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = CrmEntity()
                        _elem4.read(iprot)
                        self.crmEntities.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TargetRecipientGroup')
        if self.crmEntities is not None:
            oprot.writeFieldBegin('crmEntities', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.crmEntities))
            for _iter6 in self.crmEntities:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EmailCampaign(object):
    """
    Attributes:
     - id
     - subject
     - previewText
     - mcEmailId
     - recipientGroup
     - senderIdentity
     - sendDetails
     - userId
     - createdAt
     - updatedAt
     - recipients
     - html
     - htmlUrl
     - excludeTeamContacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'subject', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'previewText', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'mcEmailId', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'recipientGroup', (TargetRecipientGroup, TargetRecipientGroup.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'senderIdentity', (SenderIdentity, SenderIdentity.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'sendDetails', (SendDetails, SendDetails.thrift_spec), None, ),  # 7
        (8, TType.STRING, 'userId', 'UTF8', None, ),  # 8
        (9, TType.I64, 'createdAt', None, None, ),  # 9
        (10, TType.I64, 'updatedAt', None, None, ),  # 10
        (11, TType.LIST, 'recipients', (TType.STRING, 'UTF8', False), None, ),  # 11
        (12, TType.STRING, 'html', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'htmlUrl', 'UTF8', None, ),  # 13
        (14, TType.BOOL, 'excludeTeamContacts', None, None, ),  # 14
    )
    def __init__(self, id=None, subject=None, previewText=None, mcEmailId=None, recipientGroup=None, senderIdentity=None, sendDetails=None, userId=None, createdAt=None, updatedAt=None, recipients=None, html=None, htmlUrl=None, excludeTeamContacts=None, ):
        self.id = id
        self.subject = subject
        self.previewText = previewText
        self.mcEmailId = mcEmailId
        self.recipientGroup = recipientGroup
        self.senderIdentity = senderIdentity
        self.sendDetails = sendDetails
        self.userId = userId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.recipients = recipients
        self.html = html
        self.htmlUrl = htmlUrl
        self.excludeTeamContacts = excludeTeamContacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.previewText = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.mcEmailId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.recipientGroup = TargetRecipientGroup()
                    self.recipientGroup.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.senderIdentity = SenderIdentity()
                    self.senderIdentity.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.sendDetails = SendDetails()
                    self.sendDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.recipients = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.recipients.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.html = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.htmlUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.excludeTeamContacts = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EmailCampaign')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 2)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.previewText is not None:
            oprot.writeFieldBegin('previewText', TType.STRING, 3)
            oprot.writeString(self.previewText.encode('utf-8') if sys.version_info[0] == 2 else self.previewText)
            oprot.writeFieldEnd()
        if self.mcEmailId is not None:
            oprot.writeFieldBegin('mcEmailId', TType.STRING, 4)
            oprot.writeString(self.mcEmailId.encode('utf-8') if sys.version_info[0] == 2 else self.mcEmailId)
            oprot.writeFieldEnd()
        if self.recipientGroup is not None:
            oprot.writeFieldBegin('recipientGroup', TType.STRUCT, 5)
            self.recipientGroup.write(oprot)
            oprot.writeFieldEnd()
        if self.senderIdentity is not None:
            oprot.writeFieldBegin('senderIdentity', TType.STRUCT, 6)
            self.senderIdentity.write(oprot)
            oprot.writeFieldEnd()
        if self.sendDetails is not None:
            oprot.writeFieldBegin('sendDetails', TType.STRUCT, 7)
            self.sendDetails.write(oprot)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 8)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 9)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 10)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.recipients is not None:
            oprot.writeFieldBegin('recipients', TType.LIST, 11)
            oprot.writeListBegin(TType.STRING, len(self.recipients))
            for _iter11 in self.recipients:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.html is not None:
            oprot.writeFieldBegin('html', TType.STRING, 12)
            oprot.writeString(self.html.encode('utf-8') if sys.version_info[0] == 2 else self.html)
            oprot.writeFieldEnd()
        if self.htmlUrl is not None:
            oprot.writeFieldBegin('htmlUrl', TType.STRING, 13)
            oprot.writeString(self.htmlUrl.encode('utf-8') if sys.version_info[0] == 2 else self.htmlUrl)
            oprot.writeFieldEnd()
        if self.excludeTeamContacts is not None:
            oprot.writeFieldBegin('excludeTeamContacts', TType.BOOL, 14)
            oprot.writeBool(self.excludeTeamContacts)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
