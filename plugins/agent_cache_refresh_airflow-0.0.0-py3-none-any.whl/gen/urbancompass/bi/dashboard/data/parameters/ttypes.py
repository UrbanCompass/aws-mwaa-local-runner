
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.bi.dashboard.data.value_formats.ttypes
import gen.urbancompass.bi.dashboard.data.values.ttypes
import gen.urbancompass.bi.dashboard.data.visibility.ttypes

from thrift.transport import TTransport


class GroupedScalars(object):
    """
    Attributes:
     - group
     - values
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'group', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'values', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar, gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, group=None, values=None, ):
        self.group = group
        self.values = values

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.group = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar()
                        _elem4.read(iprot)
                        self.values.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GroupedScalars')
        if self.group is not None:
            oprot.writeFieldBegin('group', TType.STRING, 1)
            oprot.writeString(self.group.encode('utf-8') if sys.version_info[0] == 2 else self.group)
            oprot.writeFieldEnd()
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.values))
            for _iter6 in self.values:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NamedParameterValue(object):
    """
    Attributes:
     - name
     - value
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'value', (gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar, gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar.thrift_spec), None, ),  # 2
    )
    def __init__(self, name=None, value=None, ):
        self.name = name
        self.value = value

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.value = gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar()
                    self.value.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NamedParameterValue')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRUCT, 2)
            self.value.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ScalarParameterSpec(object):
    """
    Attributes:
     - parameterType
     - defaultValue
     - isSelectedValueDefault
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'parameterType', None, None, ),  # 1
        (2, TType.STRUCT, 'defaultValue', (gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar, gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isSelectedValueDefault', None, None, ),  # 3
    )
    def __init__(self, parameterType=None, defaultValue=None, isSelectedValueDefault=None, ):
        self.parameterType = parameterType
        self.defaultValue = defaultValue
        self.isSelectedValueDefault = isSelectedValueDefault

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.parameterType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.defaultValue = gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar()
                    self.defaultValue.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isSelectedValueDefault = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ScalarParameterSpec')
        if self.parameterType is not None:
            oprot.writeFieldBegin('parameterType', TType.I32, 1)
            oprot.writeI32(self.parameterType)
            oprot.writeFieldEnd()
        if self.defaultValue is not None:
            oprot.writeFieldBegin('defaultValue', TType.STRUCT, 2)
            self.defaultValue.write(oprot)
            oprot.writeFieldEnd()
        if self.isSelectedValueDefault is not None:
            oprot.writeFieldBegin('isSelectedValueDefault', TType.BOOL, 3)
            oprot.writeBool(self.isSelectedValueDefault)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UserIdParameterSpec(object):
    """
    Attributes:
     - autoResolve
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'autoResolve', None, None, ),  # 1
    )
    def __init__(self, autoResolve=None, ):
        self.autoResolve = autoResolve

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.autoResolve = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UserIdParameterSpec')
        if self.autoResolve is not None:
            oprot.writeFieldBegin('autoResolve', TType.BOOL, 1)
            oprot.writeBool(self.autoResolve)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Parameter(object):
    """
    Attributes:
     - name
     - values
     - groupedValues
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'values', (TType.STRUCT, (gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar, gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'groupedValues', (TType.STRUCT, (GroupedScalars, GroupedScalars.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, name=None, values=None, groupedValues=None, ):
        self.name = name
        self.values = values
        self.groupedValues = groupedValues

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = gen.urbancompass.bi.dashboard.data.values.ttypes.Scalar()
                        _elem9.read(iprot)
                        self.values.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.groupedValues = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = GroupedScalars()
                        _elem13.read(iprot)
                        self.groupedValues.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Parameter')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.values))
            for _iter15 in self.values:
                _iter15.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.groupedValues is not None:
            oprot.writeFieldBegin('groupedValues', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.groupedValues))
            for _iter16 in self.groupedValues:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SelectParameterSpec(object):
    """
    Attributes:
     - values
     - allowMultiple
     - selectedValuesIndices
     - isSelectedValueDefault
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'values', (TType.STRUCT, (NamedParameterValue, NamedParameterValue.thrift_spec), False), None, ),  # 1
        (2, TType.BOOL, 'allowMultiple', None, None, ),  # 2
        (3, TType.LIST, 'selectedValuesIndices', (TType.I32, None, False), None, ),  # 3
        (4, TType.BOOL, 'isSelectedValueDefault', None, None, ),  # 4
    )
    def __init__(self, values=None, allowMultiple=None, selectedValuesIndices=None, isSelectedValueDefault=None, ):
        self.values = values
        self.allowMultiple = allowMultiple
        self.selectedValuesIndices = selectedValuesIndices
        self.isSelectedValueDefault = isSelectedValueDefault

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = NamedParameterValue()
                        _elem19.read(iprot)
                        self.values.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.allowMultiple = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.selectedValuesIndices = []
                    (_etype21, _size24) = iprot.readListBegin()
                    for _i22 in range(_size24):
                        _elem23 = iprot.readI32()
                        self.selectedValuesIndices.append(_elem23)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isSelectedValueDefault = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SelectParameterSpec')
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.values))
            for _iter25 in self.values:
                _iter25.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.allowMultiple is not None:
            oprot.writeFieldBegin('allowMultiple', TType.BOOL, 2)
            oprot.writeBool(self.allowMultiple)
            oprot.writeFieldEnd()
        if self.selectedValuesIndices is not None:
            oprot.writeFieldBegin('selectedValuesIndices', TType.LIST, 3)
            oprot.writeListBegin(TType.I32, len(self.selectedValuesIndices))
            for _iter26 in self.selectedValuesIndices:
                oprot.writeI32(_iter26)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isSelectedValueDefault is not None:
            oprot.writeFieldBegin('isSelectedValueDefault', TType.BOOL, 4)
            oprot.writeBool(self.isSelectedValueDefault)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SelectGroup(object):
    """
    Attributes:
     - groupName
     - groupValue
     - select
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'groupName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'groupValue', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'select', (SelectParameterSpec, SelectParameterSpec.thrift_spec), None, ),  # 3
    )
    def __init__(self, groupName=None, groupValue=None, select=None, ):
        self.groupName = groupName
        self.groupValue = groupValue
        self.select = select

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.groupName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.groupValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.select = SelectParameterSpec()
                    self.select.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SelectGroup')
        if self.groupName is not None:
            oprot.writeFieldBegin('groupName', TType.STRING, 1)
            oprot.writeString(self.groupName.encode('utf-8') if sys.version_info[0] == 2 else self.groupName)
            oprot.writeFieldEnd()
        if self.groupValue is not None:
            oprot.writeFieldBegin('groupValue', TType.STRING, 2)
            oprot.writeString(self.groupValue.encode('utf-8') if sys.version_info[0] == 2 else self.groupValue)
            oprot.writeFieldEnd()
        if self.select is not None:
            oprot.writeFieldBegin('select', TType.STRUCT, 3)
            self.select.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GroupedSelectParameterSpec(object):
    """
    Attributes:
     - groups
     - selectedGroupsIndices
     - areSelectedValuesDefault
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'groups', (TType.STRUCT, (SelectGroup, SelectGroup.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'selectedGroupsIndices', (TType.I32, None, False), None, ),  # 2
        (3, TType.BOOL, 'areSelectedValuesDefault', None, None, ),  # 3
    )
    def __init__(self, groups=None, selectedGroupsIndices=None, areSelectedValuesDefault=None, ):
        self.groups = groups
        self.selectedGroupsIndices = selectedGroupsIndices
        self.areSelectedValuesDefault = areSelectedValuesDefault

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.groups = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = SelectGroup()
                        _elem29.read(iprot)
                        self.groups.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.selectedGroupsIndices = []
                    (_etype31, _size34) = iprot.readListBegin()
                    for _i32 in range(_size34):
                        _elem33 = iprot.readI32()
                        self.selectedGroupsIndices.append(_elem33)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.areSelectedValuesDefault = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GroupedSelectParameterSpec')
        if self.groups is not None:
            oprot.writeFieldBegin('groups', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.groups))
            for _iter35 in self.groups:
                _iter35.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.selectedGroupsIndices is not None:
            oprot.writeFieldBegin('selectedGroupsIndices', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.selectedGroupsIndices))
            for _iter36 in self.selectedGroupsIndices:
                oprot.writeI32(_iter36)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.areSelectedValuesDefault is not None:
            oprot.writeFieldBegin('areSelectedValuesDefault', TType.BOOL, 3)
            oprot.writeBool(self.areSelectedValuesDefault)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ParameterSpecType(object):
    """
    Attributes:
     - select
     - userId
     - scalar
     - groupedSelect
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'select', (SelectParameterSpec, SelectParameterSpec.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'userId', (UserIdParameterSpec, UserIdParameterSpec.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'scalar', (ScalarParameterSpec, ScalarParameterSpec.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'groupedSelect', (GroupedSelectParameterSpec, GroupedSelectParameterSpec.thrift_spec), None, ),  # 4
    )
    def __init__(self, select=None, userId=None, scalar=None, groupedSelect=None, ):
        self.select = select
        self.userId = userId
        self.scalar = scalar
        self.groupedSelect = groupedSelect

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.select = SelectParameterSpec()
                    self.select.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.userId = UserIdParameterSpec()
                    self.userId.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.scalar = ScalarParameterSpec()
                    self.scalar.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.groupedSelect = GroupedSelectParameterSpec()
                    self.groupedSelect.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ParameterSpecType')
        if self.select is not None:
            oprot.writeFieldBegin('select', TType.STRUCT, 1)
            self.select.write(oprot)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRUCT, 2)
            self.userId.write(oprot)
            oprot.writeFieldEnd()
        if self.scalar is not None:
            oprot.writeFieldBegin('scalar', TType.STRUCT, 3)
            self.scalar.write(oprot)
            oprot.writeFieldEnd()
        if self.groupedSelect is not None:
            oprot.writeFieldBegin('groupedSelect', TType.STRUCT, 4)
            self.groupedSelect.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ParameterSpec(object):
    """
    Attributes:
     - name
     - displayName
     - spec
     - isUserVisible
     - isNullable
     - isMandatory
     - visibility
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'spec', (ParameterSpecType, ParameterSpecType.thrift_spec), None, ),  # 2
        (3, TType.BOOL, 'isUserVisible', None, None, ),  # 3
        (4, TType.BOOL, 'isNullable', None, None, ),  # 4
        (5, TType.BOOL, 'isMandatory', None, None, ),  # 5
        (6, TType.STRING, 'displayName', 'UTF8', None, ),  # 6
        (7, TType.STRUCT, 'visibility', (gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings, gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings.thrift_spec), None, ),  # 7
    )
    def __init__(self, name=None, spec=None, isUserVisible=None, isNullable=None, isMandatory=None, displayName=None, visibility=None, ):
        self.name = name
        self.spec = spec
        self.isUserVisible = isUserVisible
        self.isNullable = isNullable
        self.isMandatory = isMandatory
        self.displayName = displayName
        self.visibility = visibility

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.spec = ParameterSpecType()
                    self.spec.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isUserVisible = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isNullable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.isMandatory = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.visibility = gen.urbancompass.bi.dashboard.data.visibility.ttypes.VisibilitySettings()
                    self.visibility.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ParameterSpec')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.spec is not None:
            oprot.writeFieldBegin('spec', TType.STRUCT, 2)
            self.spec.write(oprot)
            oprot.writeFieldEnd()
        if self.isUserVisible is not None:
            oprot.writeFieldBegin('isUserVisible', TType.BOOL, 3)
            oprot.writeBool(self.isUserVisible)
            oprot.writeFieldEnd()
        if self.isNullable is not None:
            oprot.writeFieldBegin('isNullable', TType.BOOL, 4)
            oprot.writeBool(self.isNullable)
            oprot.writeFieldEnd()
        if self.isMandatory is not None:
            oprot.writeFieldBegin('isMandatory', TType.BOOL, 5)
            oprot.writeBool(self.isMandatory)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 6)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.visibility is not None:
            oprot.writeFieldBegin('visibility', TType.STRUCT, 7)
            self.visibility.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
