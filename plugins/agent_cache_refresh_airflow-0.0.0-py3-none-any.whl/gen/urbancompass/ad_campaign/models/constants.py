
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
ADDRESS_TEXT_PLACEHOLDER = "{address}"
AGENT_TEXT_PLACEHOLDER = "{agent}"
BATHS_TEXT_PLACEHOLDER = "{baths}"
BEDS_TEXT_PLACEHOLDER = "{beds}"
CITY_TEXT_PLACEHOLDER = "{city}"
DATE_TEXT_PLACEHOLDER = "{date}"
LISTING_TYPE_TEXT_PLACEHOLDER = "{listing_type}"
MAX_BUDGET = 10000
STATE_TEXT_PLACEHOLDER = "{state}"
TIME_TEXT_PLACEHOLDER = "{time}"
