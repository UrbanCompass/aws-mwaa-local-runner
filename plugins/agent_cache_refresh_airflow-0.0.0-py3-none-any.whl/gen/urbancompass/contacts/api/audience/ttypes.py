
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class GetAudiencesOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
    }


class Audience(object):
    """
    Attributes:
     - id
     - createdAt
     - updatedAt
     - name
     - contactCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.STRING, 'name', 'UTF8', None, ),  # 4
        (5, TType.I32, 'contactCount', None, None, ),  # 5
    )
    def __init__(self, id=None, createdAt=None, updatedAt=None, name=None, contactCount=None, ):
        self.id = id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.name = name
        self.contactCount = contactCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.contactCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Audience')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 4)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.contactCount is not None:
            oprot.writeFieldBegin('contactCount', TType.I32, 5)
            oprot.writeI32(self.contactCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetAudiencesFilter(object):
    """
    Attributes:
     - order
     - id
     - idNot
     - createdAtNone
     - createdAtAfter
     - createdAtBefore
     - updatedAtAfter
     - updatedAtBefore
     - query
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'order', (TType.I32, None, False), None, ),  # 1
        (2, TType.LIST, 'id', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'idNot', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.BOOL, 'createdAtNone', None, None, ),  # 4
        (5, TType.I64, 'createdAtAfter', None, None, ),  # 5
        (6, TType.I64, 'createdAtBefore', None, None, ),  # 6
        (7, TType.I64, 'updatedAtAfter', None, None, ),  # 7
        (8, TType.I64, 'updatedAtBefore', None, None, ),  # 8
        (9, TType.STRING, 'query', 'UTF8', None, ),  # 9
    )
    def __init__(self, order=None, id=None, idNot=None, createdAtNone=None, createdAtAfter=None, createdAtBefore=None, updatedAtAfter=None, updatedAtBefore=None, query=None, ):
        self.order = order
        self.id = id
        self.idNot = idNot
        self.createdAtNone = createdAtNone
        self.createdAtAfter = createdAtAfter
        self.createdAtBefore = createdAtBefore
        self.updatedAtAfter = updatedAtAfter
        self.updatedAtBefore = updatedAtBefore
        self.query = query

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.order = []
                    (_etype100, _size103) = iprot.readListBegin()
                    for _i101 in range(_size103):
                        _elem102 = iprot.readI32()
                        self.order.append(_elem102)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.id = []
                    (_etype108, _size111) = iprot.readListBegin()
                    for _i109 in range(_size111):
                        _elem110 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.id.append(_elem110)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.idNot = []
                    (_etype116, _size119) = iprot.readListBegin()
                    for _i117 in range(_size119):
                        _elem118 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.idNot.append(_elem118)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.createdAtNone = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAtBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAtBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.query = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetAudiencesFilter')
        if self.order is not None:
            oprot.writeFieldBegin('order', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.order))
            for _iter126 in self.order:
                oprot.writeI32(_iter126)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.id))
            for _iter127 in self.id:
                oprot.writeString(_iter127.encode('utf-8') if sys.version_info[0] == 2 else _iter127)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.idNot is not None:
            oprot.writeFieldBegin('idNot', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.idNot))
            for _iter128 in self.idNot:
                oprot.writeString(_iter128.encode('utf-8') if sys.version_info[0] == 2 else _iter128)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdAtNone is not None:
            oprot.writeFieldBegin('createdAtNone', TType.BOOL, 4)
            oprot.writeBool(self.createdAtNone)
            oprot.writeFieldEnd()
        if self.createdAtAfter is not None:
            oprot.writeFieldBegin('createdAtAfter', TType.I64, 5)
            oprot.writeI64(self.createdAtAfter)
            oprot.writeFieldEnd()
        if self.createdAtBefore is not None:
            oprot.writeFieldBegin('createdAtBefore', TType.I64, 6)
            oprot.writeI64(self.createdAtBefore)
            oprot.writeFieldEnd()
        if self.updatedAtAfter is not None:
            oprot.writeFieldBegin('updatedAtAfter', TType.I64, 7)
            oprot.writeI64(self.updatedAtAfter)
            oprot.writeFieldEnd()
        if self.updatedAtBefore is not None:
            oprot.writeFieldBegin('updatedAtBefore', TType.I64, 8)
            oprot.writeI64(self.updatedAtBefore)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRING, 9)
            oprot.writeString(self.query.encode('utf-8') if sys.version_info[0] == 2 else self.query)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
