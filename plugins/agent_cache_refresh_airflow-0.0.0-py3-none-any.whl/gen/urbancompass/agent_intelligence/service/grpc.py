# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.agent_intelligence.models.ttypes as agent_intelligence_models
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.listing.listing_compliance.ttypes as listing_compliance
import gen.urbancompass.listing_translation.processed_listing.ttypes as processed_listing
import gen.urbancompass.user.user.ttypes as user
import uc.grpc.codec as _grpc_codec



class AgentIntelligenceServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.addAgentListingsByAddress = channel.unary_unary(
        '/AgentIntelligenceService/addAgentListingsByAddress',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddAgentListingsByAddressResponse),
        )
    self.addAgentListingsById = channel.unary_unary(
        '/AgentIntelligenceService/addAgentListingsById',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddAgentListingsByIdResponse),
        )
    self.addTeamListingsByAddress = channel.unary_unary(
        '/AgentIntelligenceService/addTeamListingsByAddress',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddTeamListingsByAddressResponse),
        )
    self.addTeamListingsById = channel.unary_unary(
        '/AgentIntelligenceService/addTeamListingsById',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AddTeamListingsByIdResponse),
        )
    self.deleteAgentClosedDeals = channel.unary_unary(
        '/AgentIntelligenceService/deleteAgentClosedDeals',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteAgentClosedDealsResponse),
        )
    self.deleteTeamClosedDeals = channel.unary_unary(
        '/AgentIntelligenceService/deleteTeamClosedDeals',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(DeleteTeamClosedDealsResponse),
        )
    self.getAgentProfile = channel.unary_unary(
        '/AgentIntelligenceService/getAgentProfile',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AgentProfileResponse),
        )
    self.getAgentProfileNeighborhoods = channel.unary_unary(
        '/AgentIntelligenceService/getAgentProfileNeighborhoods',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsResponse),
        )
    self.getExternalAgentProfile = channel.unary_unary(
        '/AgentIntelligenceService/getExternalAgentProfile',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(AgentProfileResponse),
        )
    self.getExternalAgentProfileNeighborhoods = channel.unary_unary(
        '/AgentIntelligenceService/getExternalAgentProfileNeighborhoods',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsResponse),
        )
    self.getTeamProfile = channel.unary_unary(
        '/AgentIntelligenceService/getTeamProfile',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(TeamProfileResponse),
        )
    self.getTeamProfileNeighborhoods = channel.unary_unary(
        '/AgentIntelligenceService/getTeamProfileNeighborhoods',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsResponse),
        )
    self.loadAgentClosedDeals = channel.unary_unary(
        '/AgentIntelligenceService/loadAgentClosedDeals',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(LoadAgentClosedDealsResponse),
        )
    self.loadListings = channel.unary_unary(
        '/AgentIntelligenceService/loadListings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(LoadListingsResponse),
        )
    self.loadTeamClosedDeals = channel.unary_unary(
        '/AgentIntelligenceService/loadTeamClosedDeals',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(LoadTeamClosedDealsResponse),
        )
    self.search = channel.unary_unary(
        '/AgentIntelligenceService/search',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SearchResponse),
        )
    self.searchByName = channel.unary_unary(
        '/AgentIntelligenceService/searchByName',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SearchResponse),
        )
    self.setAgentClosedDealsVisibility = channel.unary_unary(
        '/AgentIntelligenceService/setAgentClosedDealsVisibility',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SetAgentClosedDealsVisibilityResponse),
        )
    self.setShowIndividualsListings = channel.unary_unary(
        '/AgentIntelligenceService/setShowIndividualsListings',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SetShowIndividualsListingsResponse),
        )
    self.setTeamClosedDealsVisibility = channel.unary_unary(
        '/AgentIntelligenceService/setTeamClosedDealsVisibility',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(SetTeamClosedDealsVisibilityResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class AgentIntelligenceServiceServicer(BaseServiceServicer):
  """
    The AgentIntelligenceService Service definition
  """

  def addAgentListingsByAddress(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addAgentListingsById(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addTeamListingsByAddress(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def addTeamListingsById(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteAgentClosedDeals(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def deleteTeamClosedDeals(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentProfile(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getAgentProfileNeighborhoods(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getExternalAgentProfile(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getExternalAgentProfileNeighborhoods(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeamProfile(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def getTeamProfileNeighborhoods(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def loadAgentClosedDeals(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def loadListings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def loadTeamClosedDeals(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def search(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def searchByName(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def setAgentClosedDealsVisibility(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def setShowIndividualsListings(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def setTeamClosedDealsVisibility(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_AgentIntelligenceServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'addAgentListingsByAddress': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addAgentListingsByAddress(req),
          request_deserializer=_grpc_codec.deserializer(AddAgentListingsByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addAgentListingsById': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addAgentListingsById(req),
          request_deserializer=_grpc_codec.deserializer(AddAgentListingsByIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addTeamListingsByAddress': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addTeamListingsByAddress(req),
          request_deserializer=_grpc_codec.deserializer(AddTeamListingsByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addTeamListingsById': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.addTeamListingsById(req),
          request_deserializer=_grpc_codec.deserializer(AddTeamListingsByIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteAgentClosedDeals': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteAgentClosedDeals(req),
          request_deserializer=_grpc_codec.deserializer(DeleteAgentClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteTeamClosedDeals': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.deleteTeamClosedDeals(req),
          request_deserializer=_grpc_codec.deserializer(DeleteTeamClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentProfile': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentProfile(req),
          request_deserializer=_grpc_codec.deserializer(AgentProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentProfileNeighborhoods': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getAgentProfileNeighborhoods(req),
          request_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getExternalAgentProfile': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getExternalAgentProfile(req),
          request_deserializer=_grpc_codec.deserializer(AgentProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getExternalAgentProfileNeighborhoods': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getExternalAgentProfileNeighborhoods(req),
          request_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamProfile': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeamProfile(req),
          request_deserializer=_grpc_codec.deserializer(TeamProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamProfileNeighborhoods': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.getTeamProfileNeighborhoods(req),
          request_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadAgentClosedDeals': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.loadAgentClosedDeals(req),
          request_deserializer=_grpc_codec.deserializer(LoadAgentClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadListings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.loadListings(req),
          request_deserializer=_grpc_codec.deserializer(LoadListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadTeamClosedDeals': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.loadTeamClosedDeals(req),
          request_deserializer=_grpc_codec.deserializer(LoadTeamClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'search': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.search(req),
          request_deserializer=_grpc_codec.deserializer(SearchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'searchByName': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.searchByName(req),
          request_deserializer=_grpc_codec.deserializer(SearchByNameRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setAgentClosedDealsVisibility': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.setAgentClosedDealsVisibility(req),
          request_deserializer=_grpc_codec.deserializer(SetAgentClosedDealsVisibilityRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setShowIndividualsListings': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.setShowIndividualsListings(req),
          request_deserializer=_grpc_codec.deserializer(SetShowIndividualsListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setTeamClosedDealsVisibility': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.setTeamClosedDealsVisibility(req),
          request_deserializer=_grpc_codec.deserializer(SetTeamClosedDealsVisibilityRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'AgentIntelligenceService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_AgentIntelligenceServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'addAgentListingsByAddress': grpc.unary_unary_rpc_method_handler(
          servicer.addAgentListingsByAddress,
          request_deserializer=_grpc_codec.deserializer(AddAgentListingsByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addAgentListingsById': grpc.unary_unary_rpc_method_handler(
          servicer.addAgentListingsById,
          request_deserializer=_grpc_codec.deserializer(AddAgentListingsByIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addTeamListingsByAddress': grpc.unary_unary_rpc_method_handler(
          servicer.addTeamListingsByAddress,
          request_deserializer=_grpc_codec.deserializer(AddTeamListingsByAddressRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'addTeamListingsById': grpc.unary_unary_rpc_method_handler(
          servicer.addTeamListingsById,
          request_deserializer=_grpc_codec.deserializer(AddTeamListingsByIdRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteAgentClosedDeals': grpc.unary_unary_rpc_method_handler(
          servicer.deleteAgentClosedDeals,
          request_deserializer=_grpc_codec.deserializer(DeleteAgentClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'deleteTeamClosedDeals': grpc.unary_unary_rpc_method_handler(
          servicer.deleteTeamClosedDeals,
          request_deserializer=_grpc_codec.deserializer(DeleteTeamClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentProfile': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentProfile,
          request_deserializer=_grpc_codec.deserializer(AgentProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getAgentProfileNeighborhoods': grpc.unary_unary_rpc_method_handler(
          servicer.getAgentProfileNeighborhoods,
          request_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getExternalAgentProfile': grpc.unary_unary_rpc_method_handler(
          servicer.getExternalAgentProfile,
          request_deserializer=_grpc_codec.deserializer(AgentProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getExternalAgentProfileNeighborhoods': grpc.unary_unary_rpc_method_handler(
          servicer.getExternalAgentProfileNeighborhoods,
          request_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamProfile': grpc.unary_unary_rpc_method_handler(
          servicer.getTeamProfile,
          request_deserializer=_grpc_codec.deserializer(TeamProfileRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'getTeamProfileNeighborhoods': grpc.unary_unary_rpc_method_handler(
          servicer.getTeamProfileNeighborhoods,
          request_deserializer=_grpc_codec.deserializer(ProfileNeighborhoodsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadAgentClosedDeals': grpc.unary_unary_rpc_method_handler(
          servicer.loadAgentClosedDeals,
          request_deserializer=_grpc_codec.deserializer(LoadAgentClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadListings': grpc.unary_unary_rpc_method_handler(
          servicer.loadListings,
          request_deserializer=_grpc_codec.deserializer(LoadListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'loadTeamClosedDeals': grpc.unary_unary_rpc_method_handler(
          servicer.loadTeamClosedDeals,
          request_deserializer=_grpc_codec.deserializer(LoadTeamClosedDealsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'search': grpc.unary_unary_rpc_method_handler(
          servicer.search,
          request_deserializer=_grpc_codec.deserializer(SearchRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'searchByName': grpc.unary_unary_rpc_method_handler(
          servicer.searchByName,
          request_deserializer=_grpc_codec.deserializer(SearchByNameRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setAgentClosedDealsVisibility': grpc.unary_unary_rpc_method_handler(
          servicer.setAgentClosedDealsVisibility,
          request_deserializer=_grpc_codec.deserializer(SetAgentClosedDealsVisibilityRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setShowIndividualsListings': grpc.unary_unary_rpc_method_handler(
          servicer.setShowIndividualsListings,
          request_deserializer=_grpc_codec.deserializer(SetShowIndividualsListingsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'setTeamClosedDealsVisibility': grpc.unary_unary_rpc_method_handler(
          servicer.setTeamClosedDealsVisibility,
          request_deserializer=_grpc_codec.deserializer(SetTeamClosedDealsVisibilityRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'AgentIntelligenceService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

