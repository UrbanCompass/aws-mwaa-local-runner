
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
from .ttypes import *
BUILDING_PREVIEW_STATUS_TYPE_TO_STRING_MAP = {
    0: "-",
    1: "Aggregator Initialized",
    2: "Editor Created",
    3: "Editor Updated",
    4: "Approved",
    5: "Rejected",
    6: "Published",
}
DETAIL_OPTION_TO_DISPLAY_NAME_MAP = {
    0: "None",
    1: "Allowed",
    2: "Not Allowed",
    3: "Unknown",
    4: "HDFC Income Restrictions",
    5: "Not Applicable",
    6: "Collected",
    7: "Not Collected",
    8: "Yes",
    9: "No",
}
DETAIL_POLICY_FIELD_TO_FIELD_NAME_MAP = {
    0: "detailPolicyLandMarked",
    1: "detailPolicyLandLeased",
    2: "detailPolicyLiveWork",
    3: "detailPolicyWasherDryer",
    4: "detailPolicyHDFCRestriction",
    5: "detailPolicyTransferFee",
    6: "detailPolicyGifitingAllowed",
    7: "detailPolicyDiplomatsAllowed",
    8: "detailPolicyOpenHousesAllowed",
    9: "detailPolicySublet",
    10: "detailPolicyPiedATerre",
    11: "detailPolicyCoPurchasing",
    12: "detailPolicyParentalPurchasing",
    13: "detailPolicyGuarantor",
}
DISTRICT_TYPE_TO_FIELD_NAME_MAP = {
    0: "districtSchool",
    1: "districtCityCouncil",
    2: "districtPoliceDepartment",
    3: "districtFireDepartment",
    4: "districtSanitation",
    5: "districtHistoric",
    6: "districtCommunity",
    7: "districtHealthCenter",
}
LEED_CERTIFIED_TYPE_TO_DISPLAY_NAME_MAP = {
    0: "None",
    1: "Certified",
    2: "Silver",
    3: "Gold",
    4: "Platinum",
}
PROPERTY_TYPE_TO_DISPLAY_NAME_MAP = {
    0: "-",
    1: "Single Family",
    2: "Condop",
    3: "Co-op",
    4: "Condo",
    5: "Rental",
    6: "Mixed Use",
    7: "Multi Family",
    8: "Townhouse",
    9: "Mobile/Manufactured",
    10: "Non-Residential",
    11: "Other",
}
