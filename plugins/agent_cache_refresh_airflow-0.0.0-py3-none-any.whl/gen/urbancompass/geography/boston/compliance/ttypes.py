
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class COMPLIANCE_TYPES(object):
    BASE = 0
    VOW = 1
    OFFICE_OPT_OUT = 2
    LISTING_OPT_OUT = 3
    HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER = 4
    NO_ADDRESS_FOR_LOGGED_OUT_USER = 5
    HIDE_PHOTOS = 6
    REQUIRED_LOGIN = 7
    HIDE_DETAILS = 8

    _VALUES_TO_NAMES = {
        0: "BASE",
        1: "VOW",
        2: "OFFICE_OPT_OUT",
        3: "LISTING_OPT_OUT",
        4: "HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER",
        5: "NO_ADDRESS_FOR_LOGGED_OUT_USER",
        6: "HIDE_PHOTOS",
        7: "REQUIRED_LOGIN",
        8: "HIDE_DETAILS",
    }

    _NAMES_TO_VALUES = {
        "BASE": 0,
        "VOW": 1,
        "OFFICE_OPT_OUT": 2,
        "LISTING_OPT_OUT": 3,
        "HIDE_FROM_SEARCH_FOR_LOGGED_OUT_USER": 4,
        "NO_ADDRESS_FOR_LOGGED_OUT_USER": 5,
        "HIDE_PHOTOS": 6,
        "REQUIRED_LOGIN": 7,
        "HIDE_DETAILS": 8,
    }

