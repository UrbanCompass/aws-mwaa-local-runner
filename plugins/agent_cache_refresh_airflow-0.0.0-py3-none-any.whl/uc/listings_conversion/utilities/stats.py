from os import environ as env
from uc.base.monitoring.dd_statsd import StatsD


from uc.listings_conversion.utilities.constants import TEAM_NAME, SERVICE_NAME, DATADOG_HOST


class conversionStatsD:
    """
    Conversion Team Datadog Format: {team_name}.{application}.{descriptor}.{metric}
    e.g. listings_conversion.listings_conversion.load_converter_module.duration

    The purpose of this object is to force us into this convention
    and to remove duplicate work by using a consistent TEAM_NAME.

    It is up to the user to implement a valid descriptor and metric.

    :param application: application name
                        example: "conversion_proxy", "nestio_consumer"
    :param service_name: service name, default is "conversion_service"
                         example: "conversion_service", "nestio"
    """

    def __init__(self, application, service_name=SERVICE_NAME):
        prefix = "{}.{}".format(TEAM_NAME, application)
        self.statsd = StatsD(
            env.get(DATADOG_HOST, "localhost"), tags={"service": service_name}, prefix=prefix
        )


statsd = conversionStatsD(application=SERVICE_NAME).statsd
