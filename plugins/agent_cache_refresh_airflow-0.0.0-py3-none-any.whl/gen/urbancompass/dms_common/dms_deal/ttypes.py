
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals.constants.ttypes

from thrift.transport import TTransport


class ChecklistItemNoteRole(object):
    AGENT = 0
    TRANSACTION_COORDINATOR = 1
    COMMISSION_SPECIALIST = 2

    _VALUES_TO_NAMES = {
        0: "AGENT",
        1: "TRANSACTION_COORDINATOR",
        2: "COMMISSION_SPECIALIST",
    }

    _NAMES_TO_VALUES = {
        "AGENT": 0,
        "TRANSACTION_COORDINATOR": 1,
        "COMMISSION_SPECIALIST": 2,
    }


class ChecklistItemNoteType(object):
    MANUAL_COMMENT = 0
    DOCUMENT_STATUS_APPROVED = 1
    DOCUMENT_STATUS_ISSUE_FOUND = 2
    DOCUMENT_STATUS_PENDING = 3

    _VALUES_TO_NAMES = {
        0: "MANUAL_COMMENT",
        1: "DOCUMENT_STATUS_APPROVED",
        2: "DOCUMENT_STATUS_ISSUE_FOUND",
        3: "DOCUMENT_STATUS_PENDING",
    }

    _NAMES_TO_VALUES = {
        "MANUAL_COMMENT": 0,
        "DOCUMENT_STATUS_APPROVED": 1,
        "DOCUMENT_STATUS_ISSUE_FOUND": 2,
        "DOCUMENT_STATUS_PENDING": 3,
    }


class CtcServiceType(object):
    NONE = 0
    BASIC = 1
    PREMIUM = 2
    STANDARD = 3
    LITE = 4
    FULL = 5
    PLUS = 6
    CONVEYANCING = 7
    COMPLIANCE = 8
    COMPLIANCE_LITE = 9
    DUAL_AGENCY = 10
    RENTAL = 11
    COMPLIANCE_PLUS = 12
    DUAL_AGENCY_WITH_CONVEYANCING = 13
    DUAL_PREMIUM = 14

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "BASIC",
        2: "PREMIUM",
        3: "STANDARD",
        4: "LITE",
        5: "FULL",
        6: "PLUS",
        7: "CONVEYANCING",
        8: "COMPLIANCE",
        9: "COMPLIANCE_LITE",
        10: "DUAL_AGENCY",
        11: "RENTAL",
        12: "COMPLIANCE_PLUS",
        13: "DUAL_AGENCY_WITH_CONVEYANCING",
        14: "DUAL_PREMIUM",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "BASIC": 1,
        "PREMIUM": 2,
        "STANDARD": 3,
        "LITE": 4,
        "FULL": 5,
        "PLUS": 6,
        "CONVEYANCING": 7,
        "COMPLIANCE": 8,
        "COMPLIANCE_LITE": 9,
        "DUAL_AGENCY": 10,
        "RENTAL": 11,
        "COMPLIANCE_PLUS": 12,
        "DUAL_AGENCY_WITH_CONVEYANCING": 13,
        "DUAL_PREMIUM": 14,
    }


class DisableSubmitToCommissionReason(object):
    MISSING_CLIENT_CONTACT = 0
    PRIMARY_DUAL_REP_FOLDER_NOT_YET_SUBMITTED = 1

    _VALUES_TO_NAMES = {
        0: "MISSING_CLIENT_CONTACT",
        1: "PRIMARY_DUAL_REP_FOLDER_NOT_YET_SUBMITTED",
    }

    _NAMES_TO_VALUES = {
        "MISSING_CLIENT_CONTACT": 0,
        "PRIMARY_DUAL_REP_FOLDER_NOT_YET_SUBMITTED": 1,
    }


class DmsChecklistItemType(object):
    DOCUMENT = 0

    _VALUES_TO_NAMES = {
        0: "DOCUMENT",
    }

    _NAMES_TO_VALUES = {
        "DOCUMENT": 0,
    }


class DmsChecklistType(object):
    COMPLIANCE = 0

    _VALUES_TO_NAMES = {
        0: "COMPLIANCE",
    }

    _NAMES_TO_VALUES = {
        "COMPLIANCE": 0,
    }


class DmsComplianceStatus(object):
    UNDER_REVIEW = 0
    PENDING_AGENT_UPDATE = 1
    APPROVED = 2
    ISSUE_FOUND = 3

    _VALUES_TO_NAMES = {
        0: "UNDER_REVIEW",
        1: "PENDING_AGENT_UPDATE",
        2: "APPROVED",
        3: "ISSUE_FOUND",
    }

    _NAMES_TO_VALUES = {
        "UNDER_REVIEW": 0,
        "PENDING_AGENT_UPDATE": 1,
        "APPROVED": 2,
        "ISSUE_FOUND": 3,
    }


class DmsContactType(object):
    AGENT = 0
    CLIENT = 1

    _VALUES_TO_NAMES = {
        0: "AGENT",
        1: "CLIENT",
    }

    _NAMES_TO_VALUES = {
        "AGENT": 0,
        "CLIENT": 1,
    }


class DmsNextAction(object):
    ADD_LISTNG_DETAILS = 0
    ADD_LISTING_DOCUMENTS = 1
    ADD_ACCEPTED_OFFER = 2
    ADD_TRANSACTION_DOCUMENTS = 3
    ADD_CLOSING_DOCUMENTS = 4
    SUBMIT_COMMISSION_REQUEST = 5
    ADD_WITHDRAWN_CANCELED_DOCUMENTS = 6
    WAIT_FOR_TC_RESPONSE = 7
    ADD_REFERRAL_AGREEMENT = 8
    CORRECT_LISTING_DOCUMENTS = 9
    CORRECT_TRANSACTION_DOCUMENTS = 10
    CORRECT_CLOSING_DOCUMENTS = 11
    CORRECT_WITHDRAWN_CANCELED_DOCUMENTS = 12

    _VALUES_TO_NAMES = {
        0: "ADD_LISTNG_DETAILS",
        1: "ADD_LISTING_DOCUMENTS",
        2: "ADD_ACCEPTED_OFFER",
        3: "ADD_TRANSACTION_DOCUMENTS",
        4: "ADD_CLOSING_DOCUMENTS",
        5: "SUBMIT_COMMISSION_REQUEST",
        6: "ADD_WITHDRAWN_CANCELED_DOCUMENTS",
        7: "WAIT_FOR_TC_RESPONSE",
        8: "ADD_REFERRAL_AGREEMENT",
        9: "CORRECT_LISTING_DOCUMENTS",
        10: "CORRECT_TRANSACTION_DOCUMENTS",
        11: "CORRECT_CLOSING_DOCUMENTS",
        12: "CORRECT_WITHDRAWN_CANCELED_DOCUMENTS",
    }

    _NAMES_TO_VALUES = {
        "ADD_LISTNG_DETAILS": 0,
        "ADD_LISTING_DOCUMENTS": 1,
        "ADD_ACCEPTED_OFFER": 2,
        "ADD_TRANSACTION_DOCUMENTS": 3,
        "ADD_CLOSING_DOCUMENTS": 4,
        "SUBMIT_COMMISSION_REQUEST": 5,
        "ADD_WITHDRAWN_CANCELED_DOCUMENTS": 6,
        "WAIT_FOR_TC_RESPONSE": 7,
        "ADD_REFERRAL_AGREEMENT": 8,
        "CORRECT_LISTING_DOCUMENTS": 9,
        "CORRECT_TRANSACTION_DOCUMENTS": 10,
        "CORRECT_CLOSING_DOCUMENTS": 11,
        "CORRECT_WITHDRAWN_CANCELED_DOCUMENTS": 12,
    }


class DmsPaymentStatus(object):
    WAITING_FOR_REVIEW = 0
    UNDER_REVIEW = 1
    PAID_IN_FULL = 2
    SENT_FOR_REVIEW = 3
    NEEDS_REVIEW = 4
    UNDER_REVIEW_BY_FINANCE = 5
    VOID = 6

    _VALUES_TO_NAMES = {
        0: "WAITING_FOR_REVIEW",
        1: "UNDER_REVIEW",
        2: "PAID_IN_FULL",
        3: "SENT_FOR_REVIEW",
        4: "NEEDS_REVIEW",
        5: "UNDER_REVIEW_BY_FINANCE",
        6: "VOID",
    }

    _NAMES_TO_VALUES = {
        "WAITING_FOR_REVIEW": 0,
        "UNDER_REVIEW": 1,
        "PAID_IN_FULL": 2,
        "SENT_FOR_REVIEW": 3,
        "NEEDS_REVIEW": 4,
        "UNDER_REVIEW_BY_FINANCE": 5,
        "VOID": 6,
    }


class DocumentType(object):
    LISTING_DOC = 0
    TRANSACTION_DOC = 1
    CLOSING_DOC = 2
    WITHDRAWN_CANCELED_DOC = 3

    _VALUES_TO_NAMES = {
        0: "LISTING_DOC",
        1: "TRANSACTION_DOC",
        2: "CLOSING_DOC",
        3: "WITHDRAWN_CANCELED_DOC",
    }

    _NAMES_TO_VALUES = {
        "LISTING_DOC": 0,
        "TRANSACTION_DOC": 1,
        "CLOSING_DOC": 2,
        "WITHDRAWN_CANCELED_DOC": 3,
    }


class DualRepSide(object):
    PRIMARY = 0
    SECONDARY = 1

    _VALUES_TO_NAMES = {
        0: "PRIMARY",
        1: "SECONDARY",
    }

    _NAMES_TO_VALUES = {
        "PRIMARY": 0,
        "SECONDARY": 1,
    }


class FolderTransactionType(object):
    TRANSACTION = 0
    REFERRAL = 1
    LISTING = 2

    _VALUES_TO_NAMES = {
        0: "TRANSACTION",
        1: "REFERRAL",
        2: "LISTING",
    }

    _NAMES_TO_VALUES = {
        "TRANSACTION": 0,
        "REFERRAL": 1,
        "LISTING": 2,
    }


class IssueType(object):
    LISTING_DOC_ISSUE = 0
    TRANSACTION_DOC_ISSUE = 1
    CLOSING_DOC_ISSUE = 2
    WITHDRAWN_CANCELED_DOC_ISSUE = 3

    _VALUES_TO_NAMES = {
        0: "LISTING_DOC_ISSUE",
        1: "TRANSACTION_DOC_ISSUE",
        2: "CLOSING_DOC_ISSUE",
        3: "WITHDRAWN_CANCELED_DOC_ISSUE",
    }

    _NAMES_TO_VALUES = {
        "LISTING_DOC_ISSUE": 0,
        "TRANSACTION_DOC_ISSUE": 1,
        "CLOSING_DOC_ISSUE": 2,
        "WITHDRAWN_CANCELED_DOC_ISSUE": 3,
    }


class SideRepresentation(object):
    SELLER = 0
    BUYER = 1
    LANDLORD = 2
    TENANT = 3
    BOTH = 4
    REFERRAL = 5

    _VALUES_TO_NAMES = {
        0: "SELLER",
        1: "BUYER",
        2: "LANDLORD",
        3: "TENANT",
        4: "BOTH",
        5: "REFERRAL",
    }

    _NAMES_TO_VALUES = {
        "SELLER": 0,
        "BUYER": 1,
        "LANDLORD": 2,
        "TENANT": 3,
        "BOTH": 4,
        "REFERRAL": 5,
    }


class DateRange(object):
    """
    Attributes:
     - startDateTime
     - endDateTime
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'startDateTime', None, None, ),  # 1
        (2, TType.I64, 'endDateTime', None, None, ),  # 2
    )
    def __init__(self, startDateTime=None, endDateTime=None, ):
        self.startDateTime = startDateTime
        self.endDateTime = endDateTime

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.startDateTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.endDateTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DateRange')
        if self.startDateTime is not None:
            oprot.writeFieldBegin('startDateTime', TType.I64, 1)
            oprot.writeI64(self.startDateTime)
            oprot.writeFieldEnd()
        if self.endDateTime is not None:
            oprot.writeFieldBegin('endDateTime', TType.I64, 2)
            oprot.writeI64(self.endDateTime)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PercentOrAmount(object):
    """
    Attributes:
     - percent
     - amount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'percent', None, None, ),  # 1
        (2, TType.DOUBLE, 'amount', None, None, ),  # 2
    )
    def __init__(self, percent=None, amount=None, ):
        self.percent = percent
        self.amount = amount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.percent = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.amount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PercentOrAmount')
        if self.percent is not None:
            oprot.writeFieldBegin('percent', TType.DOUBLE, 1)
            oprot.writeDouble(self.percent)
            oprot.writeFieldEnd()
        if self.amount is not None:
            oprot.writeFieldBegin('amount', TType.DOUBLE, 2)
            oprot.writeDouble(self.amount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PriceRange(object):
    """
    Attributes:
     - max
     - min
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'max', None, None, ),  # 1
        (2, TType.DOUBLE, 'min', None, None, ),  # 2
    )
    def __init__(self, max=None, min=None, ):
        self.max = max
        self.min = min

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.max = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.min = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PriceRange')
        if self.max is not None:
            oprot.writeFieldBegin('max', TType.DOUBLE, 1)
            oprot.writeDouble(self.max)
            oprot.writeFieldEnd()
        if self.min is not None:
            oprot.writeFieldBegin('min', TType.DOUBLE, 2)
            oprot.writeDouble(self.min)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralInfo(object):
    """
    Attributes:
     - personId
     - contactId
     - brokerageName
     - isExternal
     - side
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'contactId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'brokerageName', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'isExternal', None, None, ),  # 4
        (5, TType.I32, 'side', None, None, ),  # 5
    )
    def __init__(self, personId=None, contactId=None, brokerageName=None, isExternal=None, side=None, ):
        self.personId = personId
        self.contactId = contactId
        self.brokerageName = brokerageName
        self.isExternal = isExternal
        self.side = side

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.brokerageName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isExternal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.side = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralInfo')
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 1)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 2)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.brokerageName is not None:
            oprot.writeFieldBegin('brokerageName', TType.STRING, 3)
            oprot.writeString(self.brokerageName.encode('utf-8') if sys.version_info[0] == 2 else self.brokerageName)
            oprot.writeFieldEnd()
        if self.isExternal is not None:
            oprot.writeFieldBegin('isExternal', TType.BOOL, 4)
            oprot.writeBool(self.isExternal)
            oprot.writeFieldEnd()
        if self.side is not None:
            oprot.writeFieldBegin('side', TType.I32, 5)
            oprot.writeI32(self.side)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdatedFieldsByDMS(object):
    """
    Attributes:
     - dealType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'dealType', None, None, ),  # 1
    )
    def __init__(self, dealType=None, ):
        self.dealType = dealType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdatedFieldsByDMS')
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 1)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DealQuery(object):
    """
    Attributes:
     - closeDateRange
     - paymentDateRange
     - closePriceRange
     - complianceStatus
     - paymentStatus
     - dealShownToPrincipal
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'closeDateRange', (DateRange, DateRange.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'paymentDateRange', (DateRange, DateRange.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'closePriceRange', (PriceRange, PriceRange.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'complianceStatus', (TType.I32, None, False), None, ),  # 4
        (5, TType.LIST, 'paymentStatus', (TType.I32, None, False), None, ),  # 5
        (6, TType.BOOL, 'dealShownToPrincipal', None, None, ),  # 6
    )
    def __init__(self, closeDateRange=None, paymentDateRange=None, closePriceRange=None, complianceStatus=None, paymentStatus=None, dealShownToPrincipal=None, ):
        self.closeDateRange = closeDateRange
        self.paymentDateRange = paymentDateRange
        self.closePriceRange = closePriceRange
        self.complianceStatus = complianceStatus
        self.paymentStatus = paymentStatus
        self.dealShownToPrincipal = dealShownToPrincipal

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.closeDateRange = DateRange()
                    self.closeDateRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.paymentDateRange = DateRange()
                    self.paymentDateRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.closePriceRange = PriceRange()
                    self.closePriceRange.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.complianceStatus = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readI32()
                        self.complianceStatus.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.paymentStatus = []
                    (_etype6, _size9) = iprot.readListBegin()
                    for _i7 in range(_size9):
                        _elem8 = iprot.readI32()
                        self.paymentStatus.append(_elem8)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.dealShownToPrincipal = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DealQuery')
        if self.closeDateRange is not None:
            oprot.writeFieldBegin('closeDateRange', TType.STRUCT, 1)
            self.closeDateRange.write(oprot)
            oprot.writeFieldEnd()
        if self.paymentDateRange is not None:
            oprot.writeFieldBegin('paymentDateRange', TType.STRUCT, 2)
            self.paymentDateRange.write(oprot)
            oprot.writeFieldEnd()
        if self.closePriceRange is not None:
            oprot.writeFieldBegin('closePriceRange', TType.STRUCT, 3)
            self.closePriceRange.write(oprot)
            oprot.writeFieldEnd()
        if self.complianceStatus is not None:
            oprot.writeFieldBegin('complianceStatus', TType.LIST, 4)
            oprot.writeListBegin(TType.I32, len(self.complianceStatus))
            for _iter10 in self.complianceStatus:
                oprot.writeI32(_iter10)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.paymentStatus is not None:
            oprot.writeFieldBegin('paymentStatus', TType.LIST, 5)
            oprot.writeListBegin(TType.I32, len(self.paymentStatus))
            for _iter11 in self.paymentStatus:
                oprot.writeI32(_iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.dealShownToPrincipal is not None:
            oprot.writeFieldBegin('dealShownToPrincipal', TType.BOOL, 6)
            oprot.writeBool(self.dealShownToPrincipal)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferralDetail(object):
    """
    Attributes:
     - commissionRate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'commissionRate', (PercentOrAmount, PercentOrAmount.thrift_spec), None, ),  # 1
    )
    def __init__(self, commissionRate=None, ):
        self.commissionRate = commissionRate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.commissionRate = PercentOrAmount()
                    self.commissionRate.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferralDetail')
        if self.commissionRate is not None:
            oprot.writeFieldBegin('commissionRate', TType.STRUCT, 1)
            self.commissionRate.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
