
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.deals_platform.deals_workflow.deals_workflow_model.ttypes
import gen.urbancompass.dms_common.dms_deal.ttypes
import gen.urbancompass.dms_common.dms_listing.ttypes
import gen.urbancompass.listing.listing.ttypes

from thrift.transport import TTransport


class ChecklistPurposeType(object):
    DEFAULT = 0
    REFERRAL = 1
    CUSTOM = 2
    DUAL_REP = 3
    FULL_SERVICE_RENTAL = 4

    _VALUES_TO_NAMES = {
        0: "DEFAULT",
        1: "REFERRAL",
        2: "CUSTOM",
        3: "DUAL_REP",
        4: "FULL_SERVICE_RENTAL",
    }

    _NAMES_TO_VALUES = {
        "DEFAULT": 0,
        "REFERRAL": 1,
        "CUSTOM": 2,
        "DUAL_REP": 3,
        "FULL_SERVICE_RENTAL": 4,
    }


class ComplianceDocumentChecklist(object):
    """
    Attributes:
     - id
     - checklistName
     - complianceState
     - market
     - createdTime
     - version
     - checklistPrecedence
     - isDeleted
     - isDraft
     - lastModifiedTime
     - createdBy
     - updatedBy
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'checklistName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'complianceState', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'market', 'UTF8', None, ),  # 4
        (5, TType.I64, 'createdTime', None, None, ),  # 5
        (6, TType.I32, 'version', None, None, ),  # 6
        (7, TType.I32, 'checklistPrecedence', None, None, ),  # 7
        (8, TType.BOOL, 'isDeleted', None, None, ),  # 8
        (9, TType.BOOL, 'isDraft', None, None, ),  # 9
        (10, TType.I64, 'lastModifiedTime', None, None, ),  # 10
        (11, TType.STRING, 'createdBy', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 12
    )
    def __init__(self, id=None, checklistName=None, complianceState=None, market=None, createdTime=None, version=None, checklistPrecedence=None, isDeleted=None, isDraft=None, lastModifiedTime=None, createdBy=None, updatedBy=None, ):
        self.id = id
        self.checklistName = checklistName
        self.complianceState = complianceState
        self.market = market
        self.createdTime = createdTime
        self.version = version
        self.checklistPrecedence = checklistPrecedence
        self.isDeleted = isDeleted
        self.isDraft = isDraft
        self.lastModifiedTime = lastModifiedTime
        self.createdBy = createdBy
        self.updatedBy = updatedBy

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.checklistName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.market = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.checklistPrecedence = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDraft = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceDocumentChecklist')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.checklistName is not None:
            oprot.writeFieldBegin('checklistName', TType.STRING, 2)
            oprot.writeString(self.checklistName.encode('utf-8') if sys.version_info[0] == 2 else self.checklistName)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 3)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.market is not None:
            oprot.writeFieldBegin('market', TType.STRING, 4)
            oprot.writeString(self.market.encode('utf-8') if sys.version_info[0] == 2 else self.market)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 5)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 6)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.checklistPrecedence is not None:
            oprot.writeFieldBegin('checklistPrecedence', TType.I32, 7)
            oprot.writeI32(self.checklistPrecedence)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 8)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.isDraft is not None:
            oprot.writeFieldBegin('isDraft', TType.BOOL, 9)
            oprot.writeBool(self.isDraft)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 10)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 11)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 12)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ComplianceDocumentChecklistCriteria(object):
    """
    Attributes:
     - id
     - checklistId
     - propertyType
     - listingType
     - createdTime
     - isNewConstruction
     - purposeType
     - dealType
     - isDeleted
     - lastModifiedTime
     - createdBy
     - updatedBy
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.I32, 'checklistId', None, None, ),  # 2
        (3, TType.I32, 'propertyType', None, None, ),  # 3
        (4, TType.I32, 'listingType', None, None, ),  # 4
        (5, TType.I64, 'createdTime', None, None, ),  # 5
        (6, TType.BOOL, 'isNewConstruction', None, None, ),  # 6
        (7, TType.I32, 'purposeType', None, None, ),  # 7
        (8, TType.I32, 'dealType', None, None, ),  # 8
        (9, TType.BOOL, 'isDeleted', None, None, ),  # 9
        (10, TType.I64, 'lastModifiedTime', None, None, ),  # 10
        (11, TType.STRING, 'createdBy', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 12
    )
    def __init__(self, id=None, checklistId=None, propertyType=None, listingType=None, createdTime=None, isNewConstruction=None, purposeType=None, dealType=None, isDeleted=None, lastModifiedTime=None, createdBy=None, updatedBy=None, ):
        self.id = id
        self.checklistId = checklistId
        self.propertyType = propertyType
        self.listingType = listingType
        self.createdTime = createdTime
        self.isNewConstruction = isNewConstruction
        self.purposeType = purposeType
        self.dealType = dealType
        self.isDeleted = isDeleted
        self.lastModifiedTime = lastModifiedTime
        self.createdBy = createdBy
        self.updatedBy = updatedBy

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.propertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.listingType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isNewConstruction = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.purposeType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.dealType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceDocumentChecklistCriteria')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.checklistId is not None:
            oprot.writeFieldBegin('checklistId', TType.I32, 2)
            oprot.writeI32(self.checklistId)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.I32, 3)
            oprot.writeI32(self.propertyType)
            oprot.writeFieldEnd()
        if self.listingType is not None:
            oprot.writeFieldBegin('listingType', TType.I32, 4)
            oprot.writeI32(self.listingType)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 5)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.isNewConstruction is not None:
            oprot.writeFieldBegin('isNewConstruction', TType.BOOL, 6)
            oprot.writeBool(self.isNewConstruction)
            oprot.writeFieldEnd()
        if self.purposeType is not None:
            oprot.writeFieldBegin('purposeType', TType.I32, 7)
            oprot.writeI32(self.purposeType)
            oprot.writeFieldEnd()
        if self.dealType is not None:
            oprot.writeFieldBegin('dealType', TType.I32, 8)
            oprot.writeI32(self.dealType)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 9)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 10)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 11)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 12)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ComplianceDocumentChecklistCriteriaRelation(object):
    """
    Attributes:
     - id
     - checklistCriteriaId
     - documentId
     - builtBeforeYear
     - builtAfterYear
     - documentRequired
     - documentPriority
     - sideRepresented
     - createdTime
     - lastModifiedTime
     - isDeleted
     - createdBy
     - updatedBy
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.I32, 'checklistCriteriaId', None, None, ),  # 2
        (3, TType.I32, 'documentId', None, None, ),  # 3
        (4, TType.I32, 'builtBeforeYear', None, None, ),  # 4
        (5, TType.I32, 'builtAfterYear', None, None, ),  # 5
        (6, TType.BOOL, 'documentRequired', None, None, ),  # 6
        (7, TType.I32, 'documentPriority', None, None, ),  # 7
        (8, TType.I32, 'sideRepresented', None, None, ),  # 8
        (9, TType.I64, 'createdTime', None, None, ),  # 9
        (10, TType.I64, 'lastModifiedTime', None, None, ),  # 10
        (11, TType.BOOL, 'isDeleted', None, None, ),  # 11
        (12, TType.STRING, 'createdBy', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 13
    )
    def __init__(self, id=None, checklistCriteriaId=None, documentId=None, builtBeforeYear=None, builtAfterYear=None, documentRequired=None, documentPriority=None, sideRepresented=None, createdTime=None, lastModifiedTime=None, isDeleted=None, createdBy=None, updatedBy=None, ):
        self.id = id
        self.checklistCriteriaId = checklistCriteriaId
        self.documentId = documentId
        self.builtBeforeYear = builtBeforeYear
        self.builtAfterYear = builtAfterYear
        self.documentRequired = documentRequired
        self.documentPriority = documentPriority
        self.sideRepresented = sideRepresented
        self.createdTime = createdTime
        self.lastModifiedTime = lastModifiedTime
        self.isDeleted = isDeleted
        self.createdBy = createdBy
        self.updatedBy = updatedBy

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.checklistCriteriaId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.documentId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.builtBeforeYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.builtAfterYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.documentRequired = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.documentPriority = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.sideRepresented = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.isDeleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceDocumentChecklistCriteriaRelation')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.checklistCriteriaId is not None:
            oprot.writeFieldBegin('checklistCriteriaId', TType.I32, 2)
            oprot.writeI32(self.checklistCriteriaId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.I32, 3)
            oprot.writeI32(self.documentId)
            oprot.writeFieldEnd()
        if self.builtBeforeYear is not None:
            oprot.writeFieldBegin('builtBeforeYear', TType.I32, 4)
            oprot.writeI32(self.builtBeforeYear)
            oprot.writeFieldEnd()
        if self.builtAfterYear is not None:
            oprot.writeFieldBegin('builtAfterYear', TType.I32, 5)
            oprot.writeI32(self.builtAfterYear)
            oprot.writeFieldEnd()
        if self.documentRequired is not None:
            oprot.writeFieldBegin('documentRequired', TType.BOOL, 6)
            oprot.writeBool(self.documentRequired)
            oprot.writeFieldEnd()
        if self.documentPriority is not None:
            oprot.writeFieldBegin('documentPriority', TType.I32, 7)
            oprot.writeI32(self.documentPriority)
            oprot.writeFieldEnd()
        if self.sideRepresented is not None:
            oprot.writeFieldBegin('sideRepresented', TType.I32, 8)
            oprot.writeI32(self.sideRepresented)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 9)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 10)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.isDeleted is not None:
            oprot.writeFieldBegin('isDeleted', TType.BOOL, 11)
            oprot.writeBool(self.isDeleted)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 12)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 13)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ComplianceDocumentInternal(object):
    """
    Attributes:
     - id
     - documentName
     - documentDescription
     - dealPhase
     - complianceState
     - createdTime
     - lastModifiedTime
     - documentInactive
     - createdBy
     - updatedBy
     - glideDocIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'id', None, None, ),  # 1
        (2, TType.STRING, 'documentName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'documentDescription', 'UTF8', None, ),  # 3
        (4, TType.I32, 'dealPhase', None, None, ),  # 4
        (5, TType.STRING, 'complianceState', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdTime', None, None, ),  # 6
        (7, TType.I64, 'lastModifiedTime', None, None, ),  # 7
        (8, TType.BOOL, 'documentInactive', None, None, ),  # 8
        (9, TType.STRING, 'createdBy', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'updatedBy', 'UTF8', None, ),  # 10
        (11, TType.LIST, 'glideDocIds', (TType.STRING, 'UTF8', False), None, ),  # 11
    )
    def __init__(self, id=None, documentName=None, documentDescription=None, dealPhase=None, complianceState=None, createdTime=None, lastModifiedTime=None, documentInactive=None, createdBy=None, updatedBy=None, glideDocIds=None, ):
        self.id = id
        self.documentName = documentName
        self.documentDescription = documentDescription
        self.dealPhase = dealPhase
        self.complianceState = complianceState
        self.createdTime = createdTime
        self.lastModifiedTime = lastModifiedTime
        self.documentInactive = documentInactive
        self.createdBy = createdBy
        self.updatedBy = updatedBy
        self.glideDocIds = glideDocIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.id = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.documentDescription = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.dealPhase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.complianceState = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastModifiedTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.documentInactive = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.createdBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.updatedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.glideDocIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.glideDocIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ComplianceDocumentInternal')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I32, 1)
            oprot.writeI32(self.id)
            oprot.writeFieldEnd()
        if self.documentName is not None:
            oprot.writeFieldBegin('documentName', TType.STRING, 2)
            oprot.writeString(self.documentName.encode('utf-8') if sys.version_info[0] == 2 else self.documentName)
            oprot.writeFieldEnd()
        if self.documentDescription is not None:
            oprot.writeFieldBegin('documentDescription', TType.STRING, 3)
            oprot.writeString(self.documentDescription.encode('utf-8') if sys.version_info[0] == 2 else self.documentDescription)
            oprot.writeFieldEnd()
        if self.dealPhase is not None:
            oprot.writeFieldBegin('dealPhase', TType.I32, 4)
            oprot.writeI32(self.dealPhase)
            oprot.writeFieldEnd()
        if self.complianceState is not None:
            oprot.writeFieldBegin('complianceState', TType.STRING, 5)
            oprot.writeString(self.complianceState.encode('utf-8') if sys.version_info[0] == 2 else self.complianceState)
            oprot.writeFieldEnd()
        if self.createdTime is not None:
            oprot.writeFieldBegin('createdTime', TType.I64, 6)
            oprot.writeI64(self.createdTime)
            oprot.writeFieldEnd()
        if self.lastModifiedTime is not None:
            oprot.writeFieldBegin('lastModifiedTime', TType.I64, 7)
            oprot.writeI64(self.lastModifiedTime)
            oprot.writeFieldEnd()
        if self.documentInactive is not None:
            oprot.writeFieldBegin('documentInactive', TType.BOOL, 8)
            oprot.writeBool(self.documentInactive)
            oprot.writeFieldEnd()
        if self.createdBy is not None:
            oprot.writeFieldBegin('createdBy', TType.STRING, 9)
            oprot.writeString(self.createdBy.encode('utf-8') if sys.version_info[0] == 2 else self.createdBy)
            oprot.writeFieldEnd()
        if self.updatedBy is not None:
            oprot.writeFieldBegin('updatedBy', TType.STRING, 10)
            oprot.writeString(self.updatedBy.encode('utf-8') if sys.version_info[0] == 2 else self.updatedBy)
            oprot.writeFieldEnd()
        if self.glideDocIds is not None:
            oprot.writeFieldBegin('glideDocIds', TType.LIST, 11)
            oprot.writeListBegin(TType.STRING, len(self.glideDocIds))
            for _iter6 in self.glideDocIds:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
