# -*- coding: utf-8 -*-
"""
Provides Factory class for thrift clients.

:copyright: (c) 2014 by Urban Compass, Inc.
"""

import threading
from collections import namedtuple

from gen.urbancompass.common.misc.ttypes import Ports
from gen.urbancompass.conversions_dlq.service.grpc import ConversionsDlqServiceStub
from gen.urbancompass.inventory_apps.metalist.metalist_service.grpc import MetalistServiceStub
from gen.urbancompass.listing_conversion_py3.service.grpc import ListingConversionPy3ServiceStub
from gen.urbancompass.listings_conversion.service.grpc import ListingsConversionServiceStub
from gen.urbancompass.messier.services.grpc import MessierServiceStub
from gen.urbancompass.opty.opty_service.grpc import OptyServiceStub
from uc.grpc import grpc_client2
from uc.grpc.port_converter import grpc_port_from_thrift_port

_RPCService = namedtuple("Service", ["argname", "human_name", "default_port", "default_protocol"])

_SERVICES = [
    _RPCService(
        "--conversions_dlq_service_hostport", "Listing Conversion", Ports.CONVERSIONS_DLQ, "grpc"
    ),
    _RPCService(
        "--listings_conversion_service_hostport",
        "Listing Conversion",
        Ports.LISTINGS_CONVERSION_SERVICE,
        "grpc",
    ),
    _RPCService("--messier_service_hostport", "Messier", Ports.MESSIER, "grpc"),
    _RPCService("--metalist_service_hostport", "Metalist service", Ports.METALIST, "grpc"),
    _RPCService("--opty_service_hostport", "Opty service", Ports.OPTY, "grpc"),
]


_SERVICE_NAME_TO_SERVICES = {service.human_name: service for service in _SERVICES}


def add_args(parser, whitelist_services_by_name=None):
    """
    Register remote thrift service configuration arguments to argument parser.
    :param whitelist_services_by_name: a list of service names to be installed - or None to install
    all services. Notice that services that are not part of this list will NOT be installed and their
    arguments will not be added.
    """
    try:
        iter(whitelist_services_by_name)
    except TypeError:
        whitelist_services_by_name = []
    services = _SERVICES
    if whitelist_services_by_name:
        services = []
        for service_name in whitelist_services_by_name:
            service = _SERVICE_NAME_TO_SERVICES.get(service_name)
            assert service is not None
            # We use the human names since the thrift definition names are not available here.
            services.append(service)

    group = parser.add_argument_group("Remote Services configuration.")
    for service in services:
        protocol = "grpc://" if service.default_protocol == "grpc" else ""
        port = (
            grpc_port_from_thrift_port(service.default_port)
            if service.default_protocol == "grpc"
            else service.default_port
        )
        group.add_argument(
            service.argname,
            default="{}127.0.0.1:{}".format(protocol, port),
            help="{} service address (default: %(default)r)",
        )


class GrpcClientFactory(object):
    """
    Thrift client factory that is configured via parsed arguments.
    """

    def __init__(self, options, grpc_client_class=grpc_client2.GrpcClient2):
        self._options = options
        self._grpc_client_class = grpc_client_class
        self._grpc_client_lock = threading.Lock()
        self._grpc_clients = dict()

    # Select Thrift or GRPC client based on the grpc:// URI prefix of address.
    def _select_service(self, grpc_cls, address, **kwargs):
        with self._grpc_client_lock:
            key = (grpc_cls, address)
            if key not in self._grpc_clients:
                self._grpc_clients[key] = self._grpc_client_class(grpc_cls, address[7:], **kwargs)
            return self._grpc_clients[key]

    def conversions_dlq_service(
        self, timeout_in_seconds=grpc_client2.DEFAULT_REQUEST_TIMEOUT_SECONDS
    ):
        return self._select_service(
            ConversionsDlqServiceStub,
            self._options.conversions_dlq_service_hostport,
        )

    def listings_conversion_service(self):
        return self._select_service(
            ListingsConversionServiceStub,
            self._options.listings_conversion_service_hostport,
        )

    def listings_conversion_service_py3(self):
        return self._select_service(
            ListingConversionPy3ServiceStub,
            self._options.listings_conversion_service_hostport,
        )

    def messier_service(self, timeout_in_seconds=grpc_client2.DEFAULT_REQUEST_TIMEOUT_SECONDS):
        return self._select_service(
            MessierServiceStub,
            self._options.messier_service_hostport,
            timeout_seconds=timeout_in_seconds,
        )

    def metalist_service(self, timeout_in_seconds=grpc_client2.DEFAULT_REQUEST_TIMEOUT_SECONDS):
        return self._select_service(
            grpc_cls=MetalistServiceStub,
            address=self._options.metalist_service_hostport,
        )

    def opty_service(self):
        return self._select_service(OptyServiceStub, self._options.opty_service_hostport)
