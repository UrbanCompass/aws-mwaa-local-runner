
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.user.user.ttypes
import gen.urbancompass.common.utils.ttypes

from thrift.transport import TTransport


class ContactMethod(object):
    EMAIL = 0
    PHONE = 1

    _VALUES_TO_NAMES = {
        0: "EMAIL",
        1: "PHONE",
    }

    _NAMES_TO_VALUES = {
        "EMAIL": 0,
        "PHONE": 1,
    }


class CustomerInterestType(object):
    SELLER = 0
    BUYER = 1
    RENTER = 2
    BUYER_AND_SELLER = 3

    _VALUES_TO_NAMES = {
        0: "SELLER",
        1: "BUYER",
        2: "RENTER",
        3: "BUYER_AND_SELLER",
    }

    _NAMES_TO_VALUES = {
        "SELLER": 0,
        "BUYER": 1,
        "RENTER": 2,
        "BUYER_AND_SELLER": 3,
    }


class CustomerPhase(object):
    UNCATEGORIZED = 0
    ACTIVE = 1
    PASSIVE = 2
    INACTIVE = 3
    DEAL_CLOSED = 4
    OFFER_MADE = 5
    IN_CONTRACT = 6
    CONTINGENCY = 7
    LISTING_EXPIRED = 8
    OTHER = 9

    _VALUES_TO_NAMES = {
        0: "UNCATEGORIZED",
        1: "ACTIVE",
        2: "PASSIVE",
        3: "INACTIVE",
        4: "DEAL_CLOSED",
        5: "OFFER_MADE",
        6: "IN_CONTRACT",
        7: "CONTINGENCY",
        8: "LISTING_EXPIRED",
        9: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "UNCATEGORIZED": 0,
        "ACTIVE": 1,
        "PASSIVE": 2,
        "INACTIVE": 3,
        "DEAL_CLOSED": 4,
        "OFFER_MADE": 5,
        "IN_CONTRACT": 6,
        "CONTINGENCY": 7,
        "LISTING_EXPIRED": 8,
        "OTHER": 9,
    }


class CustomerProfileEventType(object):
    CHANGE_STATUS = 0
    CHANGE_OWNERSHIP = 1

    _VALUES_TO_NAMES = {
        0: "CHANGE_STATUS",
        1: "CHANGE_OWNERSHIP",
    }

    _NAMES_TO_VALUES = {
        "CHANGE_STATUS": 0,
        "CHANGE_OWNERSHIP": 1,
    }


class CustomerStatus(object):
    NEW = 0
    UNASSIGNED = 1
    ACTIVE = 2
    PROSPECTIVE = 3
    APPLIED = 4
    SUBMITTED = 5
    CLOSED = 6
    LOST = 7
    NEVER_MET = 8
    FAKE = 9

    _VALUES_TO_NAMES = {
        0: "NEW",
        1: "UNASSIGNED",
        2: "ACTIVE",
        3: "PROSPECTIVE",
        4: "APPLIED",
        5: "SUBMITTED",
        6: "CLOSED",
        7: "LOST",
        8: "NEVER_MET",
        9: "FAKE",
    }

    _NAMES_TO_VALUES = {
        "NEW": 0,
        "UNASSIGNED": 1,
        "ACTIVE": 2,
        "PROSPECTIVE": 3,
        "APPLIED": 4,
        "SUBMITTED": 5,
        "CLOSED": 6,
        "LOST": 7,
        "NEVER_MET": 8,
        "FAKE": 9,
    }


class DocumentAccess(object):
    CLIENT = 0
    GUARANTOR = 1
    UC = 2

    _VALUES_TO_NAMES = {
        0: "CLIENT",
        1: "GUARANTOR",
        2: "UC",
    }

    _NAMES_TO_VALUES = {
        "CLIENT": 0,
        "GUARANTOR": 1,
        "UC": 2,
    }


class CreateCustomerProfileResponse(object):
    """
    Attributes:
     - success
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'success', None, None, ),  # 1
        (2, TType.STRING, 'id', 'UTF8', None, ),  # 2
    )
    def __init__(self, success=None, id=None, ):
        self.success = success
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.success = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateCustomerProfileResponse')
        if self.success is not None:
            oprot.writeFieldBegin('success', TType.BOOL, 1)
            oprot.writeBool(self.success)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 2)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CustomerProfileEvent(object):
    """
    Attributes:
     - type
     - createdAt
     - userId
     - customerStatus
     - specialistId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.I32, 'customerStatus', None, None, ),  # 4
        (5, TType.STRING, 'specialistId', 'UTF8', None, ),  # 5
    )
    def __init__(self, type=None, createdAt=None, userId=None, customerStatus=None, specialistId=None, ):
        self.type = type
        self.createdAt = createdAt
        self.userId = userId
        self.customerStatus = customerStatus
        self.specialistId = specialistId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.customerStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.specialistId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CustomerProfileEvent')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.customerStatus is not None:
            oprot.writeFieldBegin('customerStatus', TType.I32, 4)
            oprot.writeI32(self.customerStatus)
            oprot.writeFieldEnd()
        if self.specialistId is not None:
            oprot.writeFieldBegin('specialistId', TType.STRING, 5)
            oprot.writeString(self.specialistId.encode('utf-8') if sys.version_info[0] == 2 else self.specialistId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DocumentRecord(object):
    """
    Attributes:
     - _id
     - filename
     - title
     - access
     - checksum
     - deleted
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'filename', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'title', 'UTF8', None, ),  # 3
        (4, TType.I32, 'access', None, None, ),  # 4
        (5, TType.STRING, 'checksum', 'UTF8', None, ),  # 5
        (6, TType.BOOL, 'deleted', None, None, ),  # 6
    )
    def __init__(self, _id=None, filename=None, title=None, access=None, checksum=None, deleted=None, ):
        self._id = _id
        self.filename = filename
        self.title = title
        self.access = access
        self.checksum = checksum
        self.deleted = deleted

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.filename = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.access = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.checksum = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.deleted = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DocumentRecord')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.filename is not None:
            oprot.writeFieldBegin('filename', TType.STRING, 2)
            oprot.writeString(self.filename.encode('utf-8') if sys.version_info[0] == 2 else self.filename)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 3)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.access is not None:
            oprot.writeFieldBegin('access', TType.I32, 4)
            oprot.writeI32(self.access)
            oprot.writeFieldEnd()
        if self.checksum is not None:
            oprot.writeFieldBegin('checksum', TType.STRING, 5)
            oprot.writeString(self.checksum.encode('utf-8') if sys.version_info[0] == 2 else self.checksum)
            oprot.writeFieldEnd()
        if self.deleted is not None:
            oprot.writeFieldBegin('deleted', TType.BOOL, 6)
            oprot.writeBool(self.deleted)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class EmailPreferences(object):
    """
    Attributes:
     - subscribed
     - generalUpdates
     - relatedToSearch
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'subscribed', None, None, ),  # 1
        (2, TType.BOOL, 'generalUpdates', None, None, ),  # 2
        (3, TType.BOOL, 'relatedToSearch', None, None, ),  # 3
    )
    def __init__(self, subscribed=None, generalUpdates=None, relatedToSearch=None, ):
        self.subscribed = subscribed
        self.generalUpdates = generalUpdates
        self.relatedToSearch = relatedToSearch

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.subscribed = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.generalUpdates = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.relatedToSearch = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EmailPreferences')
        if self.subscribed is not None:
            oprot.writeFieldBegin('subscribed', TType.BOOL, 1)
            oprot.writeBool(self.subscribed)
            oprot.writeFieldEnd()
        if self.generalUpdates is not None:
            oprot.writeFieldBegin('generalUpdates', TType.BOOL, 2)
            oprot.writeBool(self.generalUpdates)
            oprot.writeFieldEnd()
        if self.relatedToSearch is not None:
            oprot.writeFieldBegin('relatedToSearch', TType.BOOL, 3)
            oprot.writeBool(self.relatedToSearch)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FacebookInformation(object):
    """
    Attributes:
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
    )
    def __init__(self, id=None, ):
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FacebookInformation')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindCustomerProfileRequest(object):
    """
    Attributes:
     - id
     - lastName
     - email
     - skip
     - limit
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'lastName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'email', 'UTF8', None, ),  # 3
        (4, TType.I32, 'skip', None, None, ),  # 4
        (5, TType.I32, 'limit', None, None, ),  # 5
    )
    def __init__(self, id=None, lastName=None, email=None, skip=None, limit=None, ):
        self.id = id
        self.lastName = lastName
        self.email = email
        self.skip = skip
        self.limit = limit

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.skip = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindCustomerProfileRequest')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 2)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 3)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.I32, 4)
            oprot.writeI32(self.skip)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 5)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GeographyPreferences(object):
    """
    Attributes:
     - geographyAbbrev
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'geographyAbbrev', 'UTF8', None, ),  # 1
    )
    def __init__(self, geographyAbbrev=None, ):
        self.geographyAbbrev = geographyAbbrev

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.geographyAbbrev = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GeographyPreferences')
        if self.geographyAbbrev is not None:
            oprot.writeFieldBegin('geographyAbbrev', TType.STRING, 1)
            oprot.writeString(self.geographyAbbrev.encode('utf-8') if sys.version_info[0] == 2 else self.geographyAbbrev)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCustomerEmailsRequest(object):
    """
    Attributes:
     - userIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'userIds', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, userIds=None, ):
        self.userIds = userIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.userIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCustomerEmailsRequest')
        if self.userIds is not None:
            oprot.writeFieldBegin('userIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.userIds))
            for _iter6 in self.userIds:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCustomerEmailsResponse(object):
    """
    Attributes:
     - userIds
     - emails
     - errorMessage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'userIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'emails', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'errorMessage', 'UTF8', None, ),  # 3
    )
    def __init__(self, userIds=None, emails=None, errorMessage=None, ):
        self.userIds = userIds
        self.emails = emails
        self.errorMessage = errorMessage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.userIds = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userIds.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.emails = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.emails.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.errorMessage = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCustomerEmailsResponse')
        if self.userIds is not None:
            oprot.writeFieldBegin('userIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.userIds))
            for _iter15 in self.userIds:
                oprot.writeString(_iter15.encode('utf-8') if sys.version_info[0] == 2 else _iter15)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.emails is not None:
            oprot.writeFieldBegin('emails', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.emails))
            for _iter16 in self.emails:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.errorMessage is not None:
            oprot.writeFieldBegin('errorMessage', TType.STRING, 3)
            oprot.writeString(self.errorMessage.encode('utf-8') if sys.version_info[0] == 2 else self.errorMessage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCustomerProfileRequest(object):
    """
    Attributes:
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
    )
    def __init__(self, userId=None, ):
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCustomerProfileRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadCustomerProfilesRequest(object):
    """
    Attributes:
     - userIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.SET, 'userIds', (TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, userIds=None, ):
        self.userIds = userIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.SET:
                    self.userIds = set()
                    (_etype18, _size20) = iprot.readSetBegin()
                    for _i17 in range(_size20):
                        _elem19 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userIds.add(_elem19)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadCustomerProfilesRequest')
        if self.userIds is not None:
            oprot.writeFieldBegin('userIds', TType.SET, 1)
            oprot.writeSetBegin(TType.STRING, len(self.userIds))
            for _iter21 in self.userIds:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Notification(object):
    """
    Attributes:
     - type
     - notifiedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'type', 'UTF8', None, ),  # 1
        (2, TType.I64, 'notifiedAt', None, None, ),  # 2
    )
    def __init__(self, type=None, notifiedAt=None, ):
        self.type = type
        self.notifiedAt = notifiedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.type = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.notifiedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Notification')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.STRING, 1)
            oprot.writeString(self.type.encode('utf-8') if sys.version_info[0] == 2 else self.type)
            oprot.writeFieldEnd()
        if self.notifiedAt is not None:
            oprot.writeFieldBegin('notifiedAt', TType.I64, 2)
            oprot.writeI64(self.notifiedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Roommate(object):
    """
    Attributes:
     - name
     - email
     - relationship
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'email', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'relationship', 'UTF8', None, ),  # 3
    )
    def __init__(self, name=None, email=None, relationship=None, ):
        self.name = name
        self.email = email
        self.relationship = relationship

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.relationship = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Roommate')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 2)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.relationship is not None:
            oprot.writeFieldBegin('relationship', TType.STRING, 3)
            oprot.writeString(self.relationship.encode('utf-8') if sys.version_info[0] == 2 else self.relationship)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchPreferences(object):
    """
    Attributes:
     - selectedSearchView
     - assignedSearchView
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'selectedSearchView', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'assignedSearchView', 'UTF8', None, ),  # 2
    )
    def __init__(self, selectedSearchView=None, assignedSearchView=None, ):
        self.selectedSearchView = selectedSearchView
        self.assignedSearchView = assignedSearchView

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.selectedSearchView = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.assignedSearchView = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchPreferences')
        if self.selectedSearchView is not None:
            oprot.writeFieldBegin('selectedSearchView', TType.STRING, 1)
            oprot.writeString(self.selectedSearchView.encode('utf-8') if sys.version_info[0] == 2 else self.selectedSearchView)
            oprot.writeFieldEnd()
        if self.assignedSearchView is not None:
            oprot.writeFieldBegin('assignedSearchView', TType.STRING, 2)
            oprot.writeString(self.assignedSearchView.encode('utf-8') if sys.version_info[0] == 2 else self.assignedSearchView)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SocialProfile(object):
    """
    Attributes:
     - typeId
     - typeName
     - url
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'typeId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'typeName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'url', 'UTF8', None, ),  # 3
    )
    def __init__(self, typeId=None, typeName=None, url=None, ):
        self.typeId = typeId
        self.typeName = typeName
        self.url = url

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.typeId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.typeName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SocialProfile')
        if self.typeId is not None:
            oprot.writeFieldBegin('typeId', TType.STRING, 1)
            oprot.writeString(self.typeId.encode('utf-8') if sys.version_info[0] == 2 else self.typeId)
            oprot.writeFieldEnd()
        if self.typeName is not None:
            oprot.writeFieldBegin('typeName', TType.STRING, 2)
            oprot.writeString(self.typeName.encode('utf-8') if sys.version_info[0] == 2 else self.typeName)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 3)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateCustomerProfileResponse(object):
    """
    Attributes:
     - success
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'success', None, None, ),  # 1
    )
    def __init__(self, success=None, ):
        self.success = success

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.success = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateCustomerProfileResponse')
        if self.success is not None:
            oprot.writeFieldBegin('success', TType.BOOL, 1)
            oprot.writeBool(self.success)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FullContactInformation(object):
    """
    Attributes:
     - name
     - location
     - jobTitle
     - employer
     - photo
     - socialProfiles
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'location', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'jobTitle', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'employer', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'photo', 'UTF8', None, ),  # 5
        (6, TType.LIST, 'socialProfiles', (TType.STRUCT, (SocialProfile, SocialProfile.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, name=None, location=None, jobTitle=None, employer=None, photo=None, socialProfiles=None, ):
        self.name = name
        self.location = location
        self.jobTitle = jobTitle
        self.employer = employer
        self.photo = photo
        self.socialProfiles = socialProfiles

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.location = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.jobTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.employer = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.photo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.socialProfiles = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = SocialProfile()
                        _elem24.read(iprot)
                        self.socialProfiles.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FullContactInformation')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.STRING, 2)
            oprot.writeString(self.location.encode('utf-8') if sys.version_info[0] == 2 else self.location)
            oprot.writeFieldEnd()
        if self.jobTitle is not None:
            oprot.writeFieldBegin('jobTitle', TType.STRING, 3)
            oprot.writeString(self.jobTitle.encode('utf-8') if sys.version_info[0] == 2 else self.jobTitle)
            oprot.writeFieldEnd()
        if self.employer is not None:
            oprot.writeFieldBegin('employer', TType.STRING, 4)
            oprot.writeString(self.employer.encode('utf-8') if sys.version_info[0] == 2 else self.employer)
            oprot.writeFieldEnd()
        if self.photo is not None:
            oprot.writeFieldBegin('photo', TType.STRING, 5)
            oprot.writeString(self.photo.encode('utf-8') if sys.version_info[0] == 2 else self.photo)
            oprot.writeFieldEnd()
        if self.socialProfiles is not None:
            oprot.writeFieldBegin('socialProfiles', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.socialProfiles))
            for _iter26 in self.socialProfiles:
                _iter26.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MoveInInformation(object):
    """
    Attributes:
     - moveInDateFrom
     - moveInDateTo
     - hasRoommates
     - roommates
     - hasPet
     - employerOrSchool
     - hasQualifiedIncome
     - hasQualifiedGuarantor
     - customerNotes
     - referredBy
     - breed
     - weight
     - availabilityDescription
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'moveInDateFrom', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'moveInDateTo', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'hasRoommates', None, None, ),  # 3
        (4, TType.LIST, 'roommates', (TType.STRUCT, (Roommate, Roommate.thrift_spec), False), None, ),  # 4
        (5, TType.BOOL, 'hasPet', None, None, ),  # 5
        None,  # 6
        (7, TType.STRING, 'employerOrSchool', 'UTF8', None, ),  # 7
        (8, TType.BOOL, 'hasQualifiedIncome', None, None, ),  # 8
        (9, TType.BOOL, 'hasQualifiedGuarantor', None, None, ),  # 9
        (10, TType.STRING, 'customerNotes', 'UTF8', None, ),  # 10
        None,  # 11
        None,  # 12
        (13, TType.STRING, 'referredBy', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'breed', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'weight', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'availabilityDescription', 'UTF8', None, ),  # 16
    )
    def __init__(self, moveInDateFrom=None, moveInDateTo=None, hasRoommates=None, roommates=None, hasPet=None, employerOrSchool=None, hasQualifiedIncome=None, hasQualifiedGuarantor=None, customerNotes=None, referredBy=None, breed=None, weight=None, availabilityDescription=None, ):
        self.moveInDateFrom = moveInDateFrom
        self.moveInDateTo = moveInDateTo
        self.hasRoommates = hasRoommates
        self.roommates = roommates
        self.hasPet = hasPet
        self.employerOrSchool = employerOrSchool
        self.hasQualifiedIncome = hasQualifiedIncome
        self.hasQualifiedGuarantor = hasQualifiedGuarantor
        self.customerNotes = customerNotes
        self.referredBy = referredBy
        self.breed = breed
        self.weight = weight
        self.availabilityDescription = availabilityDescription

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.moveInDateFrom = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.moveInDateTo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.hasRoommates = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.roommates = []
                    (_etype27, _size30) = iprot.readListBegin()
                    for _i28 in range(_size30):
                        _elem29 = Roommate()
                        _elem29.read(iprot)
                        self.roommates.append(_elem29)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.hasPet = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.employerOrSchool = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.hasQualifiedIncome = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.hasQualifiedGuarantor = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.customerNotes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.referredBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.breed = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.weight = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.availabilityDescription = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MoveInInformation')
        if self.moveInDateFrom is not None:
            oprot.writeFieldBegin('moveInDateFrom', TType.STRING, 1)
            oprot.writeString(self.moveInDateFrom.encode('utf-8') if sys.version_info[0] == 2 else self.moveInDateFrom)
            oprot.writeFieldEnd()
        if self.moveInDateTo is not None:
            oprot.writeFieldBegin('moveInDateTo', TType.STRING, 2)
            oprot.writeString(self.moveInDateTo.encode('utf-8') if sys.version_info[0] == 2 else self.moveInDateTo)
            oprot.writeFieldEnd()
        if self.hasRoommates is not None:
            oprot.writeFieldBegin('hasRoommates', TType.BOOL, 3)
            oprot.writeBool(self.hasRoommates)
            oprot.writeFieldEnd()
        if self.roommates is not None:
            oprot.writeFieldBegin('roommates', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.roommates))
            for _iter31 in self.roommates:
                _iter31.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hasPet is not None:
            oprot.writeFieldBegin('hasPet', TType.BOOL, 5)
            oprot.writeBool(self.hasPet)
            oprot.writeFieldEnd()
        if self.employerOrSchool is not None:
            oprot.writeFieldBegin('employerOrSchool', TType.STRING, 7)
            oprot.writeString(self.employerOrSchool.encode('utf-8') if sys.version_info[0] == 2 else self.employerOrSchool)
            oprot.writeFieldEnd()
        if self.hasQualifiedIncome is not None:
            oprot.writeFieldBegin('hasQualifiedIncome', TType.BOOL, 8)
            oprot.writeBool(self.hasQualifiedIncome)
            oprot.writeFieldEnd()
        if self.hasQualifiedGuarantor is not None:
            oprot.writeFieldBegin('hasQualifiedGuarantor', TType.BOOL, 9)
            oprot.writeBool(self.hasQualifiedGuarantor)
            oprot.writeFieldEnd()
        if self.customerNotes is not None:
            oprot.writeFieldBegin('customerNotes', TType.STRING, 10)
            oprot.writeString(self.customerNotes.encode('utf-8') if sys.version_info[0] == 2 else self.customerNotes)
            oprot.writeFieldEnd()
        if self.referredBy is not None:
            oprot.writeFieldBegin('referredBy', TType.STRING, 13)
            oprot.writeString(self.referredBy.encode('utf-8') if sys.version_info[0] == 2 else self.referredBy)
            oprot.writeFieldEnd()
        if self.breed is not None:
            oprot.writeFieldBegin('breed', TType.STRING, 14)
            oprot.writeString(self.breed.encode('utf-8') if sys.version_info[0] == 2 else self.breed)
            oprot.writeFieldEnd()
        if self.weight is not None:
            oprot.writeFieldBegin('weight', TType.STRING, 15)
            oprot.writeString(self.weight.encode('utf-8') if sys.version_info[0] == 2 else self.weight)
            oprot.writeFieldEnd()
        if self.availabilityDescription is not None:
            oprot.writeFieldBegin('availabilityDescription', TType.STRING, 16)
            oprot.writeString(self.availabilityDescription.encode('utf-8') if sys.version_info[0] == 2 else self.availabilityDescription)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CustomerProfile(object):
    """
    Attributes:
     - _id
     - id
     - userId
     - firstName
     - lastName
     - email
     - phoneNumber
     - moveInInformation
     - createdAt
     - updatedAt
     - customerNotes
     - firstTimeAddingListing
     - stripe_id
     - emailPreferences
     - specialistId
     - documents
     - facebookInformation
     - isActivelyLooking
     - customerStatus
     - events
     - defaultAgentId
     - searchPreferences
     - isSelectedAgent
     - geographyPreferences
     - preferredContactMethod
     - customerInterestType
     - budget
     - phase
     - invitedBy
     - fullContactInformation
     - channel
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'firstName', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'lastName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'email', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'phoneNumber', 'UTF8', None, ),  # 5
        None,  # 6
        None,  # 7
        (8, TType.STRUCT, 'moveInInformation', (MoveInInformation, MoveInInformation.thrift_spec), None, ),  # 8
        None,  # 9
        (10, TType.I64, 'createdAt', None, None, ),  # 10
        (11, TType.I64, 'updatedAt', None, None, ),  # 11
        (12, TType.LIST, 'customerNotes', (TType.STRUCT, (gen.urbancompass.common.utils.ttypes.Note, gen.urbancompass.common.utils.ttypes.Note.thrift_spec), False), None, ),  # 12
        (13, TType.STRING, 'userId', 'UTF8', None, ),  # 13
        (14, TType.BOOL, 'firstTimeAddingListing', None, None, ),  # 14
        (15, TType.STRING, 'stripe_id', 'UTF8', None, ),  # 15
        (16, TType.STRUCT, 'emailPreferences', (EmailPreferences, EmailPreferences.thrift_spec), None, ),  # 16
        None,  # 17
        None,  # 18
        (19, TType.STRING, 'specialistId', 'UTF8', None, ),  # 19
        (20, TType.LIST, 'documents', (TType.STRUCT, (DocumentRecord, DocumentRecord.thrift_spec), False), None, ),  # 20
        (21, TType.STRING, 'id', 'UTF8', None, ),  # 21
        (22, TType.STRUCT, 'facebookInformation', (FacebookInformation, FacebookInformation.thrift_spec), None, ),  # 22
        None,  # 23
        (24, TType.BOOL, 'isActivelyLooking', None, None, ),  # 24
        None,  # 25
        None,  # 26
        (27, TType.I32, 'customerStatus', None, None, ),  # 27
        (28, TType.LIST, 'events', (TType.STRUCT, (CustomerProfileEvent, CustomerProfileEvent.thrift_spec), False), None, ),  # 28
        (29, TType.STRING, 'defaultAgentId', 'UTF8', None, ),  # 29
        (30, TType.STRUCT, 'searchPreferences', (SearchPreferences, SearchPreferences.thrift_spec), None, ),  # 30
        (31, TType.BOOL, 'isSelectedAgent', None, None, ),  # 31
        (32, TType.STRUCT, 'geographyPreferences', (GeographyPreferences, GeographyPreferences.thrift_spec), None, ),  # 32
        (33, TType.I32, 'preferredContactMethod', None, None, ),  # 33
        (34, TType.I32, 'customerInterestType', None, None, ),  # 34
        (35, TType.I32, 'budget', None, None, ),  # 35
        (36, TType.I32, 'phase', None, None, ),  # 36
        (37, TType.LIST, 'invitedBy', (TType.STRING, 'UTF8', False), None, ),  # 37
        (38, TType.STRUCT, 'fullContactInformation', (FullContactInformation, FullContactInformation.thrift_spec), None, ),  # 38
        (39, TType.I32, 'channel', None, None, ),  # 39
    )
    def __init__(self, _id=None, firstName=None, lastName=None, email=None, phoneNumber=None, moveInInformation=None, createdAt=None, updatedAt=None, customerNotes=None, userId=None, firstTimeAddingListing=None, stripe_id=None, emailPreferences=None, specialistId=None, documents=None, id=None, facebookInformation=None, isActivelyLooking=None, customerStatus=None, events=None, defaultAgentId=None, searchPreferences=None, isSelectedAgent=None, geographyPreferences=None, preferredContactMethod=None, customerInterestType=None, budget=None, phase=None, invitedBy=None, fullContactInformation=None, channel=None, ):
        self._id = _id
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.phoneNumber = phoneNumber
        self.moveInInformation = moveInInformation
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.customerNotes = customerNotes
        self.userId = userId
        self.firstTimeAddingListing = firstTimeAddingListing
        self.stripe_id = stripe_id
        self.emailPreferences = emailPreferences
        self.specialistId = specialistId
        self.documents = documents
        self.id = id
        self.facebookInformation = facebookInformation
        self.isActivelyLooking = isActivelyLooking
        self.customerStatus = customerStatus
        self.events = events
        self.defaultAgentId = defaultAgentId
        self.searchPreferences = searchPreferences
        self.isSelectedAgent = isSelectedAgent
        self.geographyPreferences = geographyPreferences
        self.preferredContactMethod = preferredContactMethod
        self.customerInterestType = customerInterestType
        self.budget = budget
        self.phase = phase
        self.invitedBy = invitedBy
        self.fullContactInformation = fullContactInformation
        self.channel = channel

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.phoneNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.moveInInformation = MoveInInformation()
                    self.moveInInformation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.customerNotes = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = gen.urbancompass.common.utils.ttypes.Note()
                        _elem34.read(iprot)
                        self.customerNotes.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.firstTimeAddingListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.stripe_id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.emailPreferences = EmailPreferences()
                    self.emailPreferences.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.specialistId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.documents = []
                    (_etype36, _size39) = iprot.readListBegin()
                    for _i37 in range(_size39):
                        _elem38 = DocumentRecord()
                        _elem38.read(iprot)
                        self.documents.append(_elem38)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRUCT:
                    self.facebookInformation = FacebookInformation()
                    self.facebookInformation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.isActivelyLooking = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I32:
                    self.customerStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.LIST:
                    self.events = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = CustomerProfileEvent()
                        _elem42.read(iprot)
                        self.events.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.defaultAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.searchPreferences = SearchPreferences()
                    self.searchPreferences.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.BOOL:
                    self.isSelectedAgent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.STRUCT:
                    self.geographyPreferences = GeographyPreferences()
                    self.geographyPreferences.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I32:
                    self.preferredContactMethod = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.I32:
                    self.customerInterestType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.I32:
                    self.budget = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.I32:
                    self.phase = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.LIST:
                    self.invitedBy = []
                    (_etype44, _size47) = iprot.readListBegin()
                    for _i45 in range(_size47):
                        _elem46 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.invitedBy.append(_elem46)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.STRUCT:
                    self.fullContactInformation = FullContactInformation()
                    self.fullContactInformation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.I32:
                    self.channel = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CustomerProfile')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 2)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 3)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 4)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.phoneNumber is not None:
            oprot.writeFieldBegin('phoneNumber', TType.STRING, 5)
            oprot.writeString(self.phoneNumber.encode('utf-8') if sys.version_info[0] == 2 else self.phoneNumber)
            oprot.writeFieldEnd()
        if self.moveInInformation is not None:
            oprot.writeFieldBegin('moveInInformation', TType.STRUCT, 8)
            self.moveInInformation.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 10)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 11)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.customerNotes is not None:
            oprot.writeFieldBegin('customerNotes', TType.LIST, 12)
            oprot.writeListBegin(TType.STRUCT, len(self.customerNotes))
            for _iter48 in self.customerNotes:
                _iter48.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 13)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.firstTimeAddingListing is not None:
            oprot.writeFieldBegin('firstTimeAddingListing', TType.BOOL, 14)
            oprot.writeBool(self.firstTimeAddingListing)
            oprot.writeFieldEnd()
        if self.stripe_id is not None:
            oprot.writeFieldBegin('stripe_id', TType.STRING, 15)
            oprot.writeString(self.stripe_id.encode('utf-8') if sys.version_info[0] == 2 else self.stripe_id)
            oprot.writeFieldEnd()
        if self.emailPreferences is not None:
            oprot.writeFieldBegin('emailPreferences', TType.STRUCT, 16)
            self.emailPreferences.write(oprot)
            oprot.writeFieldEnd()
        if self.specialistId is not None:
            oprot.writeFieldBegin('specialistId', TType.STRING, 19)
            oprot.writeString(self.specialistId.encode('utf-8') if sys.version_info[0] == 2 else self.specialistId)
            oprot.writeFieldEnd()
        if self.documents is not None:
            oprot.writeFieldBegin('documents', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.documents))
            for _iter49 in self.documents:
                _iter49.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 21)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.facebookInformation is not None:
            oprot.writeFieldBegin('facebookInformation', TType.STRUCT, 22)
            self.facebookInformation.write(oprot)
            oprot.writeFieldEnd()
        if self.isActivelyLooking is not None:
            oprot.writeFieldBegin('isActivelyLooking', TType.BOOL, 24)
            oprot.writeBool(self.isActivelyLooking)
            oprot.writeFieldEnd()
        if self.customerStatus is not None:
            oprot.writeFieldBegin('customerStatus', TType.I32, 27)
            oprot.writeI32(self.customerStatus)
            oprot.writeFieldEnd()
        if self.events is not None:
            oprot.writeFieldBegin('events', TType.LIST, 28)
            oprot.writeListBegin(TType.STRUCT, len(self.events))
            for _iter50 in self.events:
                _iter50.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.defaultAgentId is not None:
            oprot.writeFieldBegin('defaultAgentId', TType.STRING, 29)
            oprot.writeString(self.defaultAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.defaultAgentId)
            oprot.writeFieldEnd()
        if self.searchPreferences is not None:
            oprot.writeFieldBegin('searchPreferences', TType.STRUCT, 30)
            self.searchPreferences.write(oprot)
            oprot.writeFieldEnd()
        if self.isSelectedAgent is not None:
            oprot.writeFieldBegin('isSelectedAgent', TType.BOOL, 31)
            oprot.writeBool(self.isSelectedAgent)
            oprot.writeFieldEnd()
        if self.geographyPreferences is not None:
            oprot.writeFieldBegin('geographyPreferences', TType.STRUCT, 32)
            self.geographyPreferences.write(oprot)
            oprot.writeFieldEnd()
        if self.preferredContactMethod is not None:
            oprot.writeFieldBegin('preferredContactMethod', TType.I32, 33)
            oprot.writeI32(self.preferredContactMethod)
            oprot.writeFieldEnd()
        if self.customerInterestType is not None:
            oprot.writeFieldBegin('customerInterestType', TType.I32, 34)
            oprot.writeI32(self.customerInterestType)
            oprot.writeFieldEnd()
        if self.budget is not None:
            oprot.writeFieldBegin('budget', TType.I32, 35)
            oprot.writeI32(self.budget)
            oprot.writeFieldEnd()
        if self.phase is not None:
            oprot.writeFieldBegin('phase', TType.I32, 36)
            oprot.writeI32(self.phase)
            oprot.writeFieldEnd()
        if self.invitedBy is not None:
            oprot.writeFieldBegin('invitedBy', TType.LIST, 37)
            oprot.writeListBegin(TType.STRING, len(self.invitedBy))
            for _iter51 in self.invitedBy:
                oprot.writeString(_iter51.encode('utf-8') if sys.version_info[0] == 2 else _iter51)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.fullContactInformation is not None:
            oprot.writeFieldBegin('fullContactInformation', TType.STRUCT, 38)
            self.fullContactInformation.write(oprot)
            oprot.writeFieldEnd()
        if self.channel is not None:
            oprot.writeFieldBegin('channel', TType.I32, 39)
            oprot.writeI32(self.channel)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindCustomerProfileResponse(object):
    """
    Attributes:
     - totalMatches
     - customerProfiles
    """

    thrift_spec = (
        None,  # 0
        None,  # 1
        (2, TType.LIST, 'customerProfiles', (TType.STRUCT, (CustomerProfile, CustomerProfile.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalMatches', None, None, ),  # 3
    )
    def __init__(self, customerProfiles=None, totalMatches=None, ):
        self.customerProfiles = customerProfiles
        self.totalMatches = totalMatches

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 2:
                if ftype == TType.LIST:
                    self.customerProfiles = []
                    (_etype52, _size55) = iprot.readListBegin()
                    for _i53 in range(_size55):
                        _elem54 = CustomerProfile()
                        _elem54.read(iprot)
                        self.customerProfiles.append(_elem54)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalMatches = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindCustomerProfileResponse')
        if self.customerProfiles is not None:
            oprot.writeFieldBegin('customerProfiles', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.customerProfiles))
            for _iter56 in self.customerProfiles:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalMatches is not None:
            oprot.writeFieldBegin('totalMatches', TType.I32, 3)
            oprot.writeI32(self.totalMatches)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetCustomerProfileResponse(object):
    """
    Attributes:
     - customerProfile
     - error
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'customerProfile', (CustomerProfile, CustomerProfile.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'error', 'UTF8', None, ),  # 2
    )
    def __init__(self, customerProfile=None, error=None, ):
        self.customerProfile = customerProfile
        self.error = error

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.customerProfile = CustomerProfile()
                    self.customerProfile.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetCustomerProfileResponse')
        if self.customerProfile is not None:
            oprot.writeFieldBegin('customerProfile', TType.STRUCT, 1)
            self.customerProfile.write(oprot)
            oprot.writeFieldEnd()
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 2)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LoadCustomerProfilesResponse(object):
    """
    Attributes:
     - error
     - customerProfiles
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'error', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'customerProfiles', (TType.STRUCT, (CustomerProfile, CustomerProfile.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, error=None, customerProfiles=None, ):
        self.error = error
        self.customerProfiles = customerProfiles

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.error = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.customerProfiles = []
                    (_etype57, _size60) = iprot.readListBegin()
                    for _i58 in range(_size60):
                        _elem59 = CustomerProfile()
                        _elem59.read(iprot)
                        self.customerProfiles.append(_elem59)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LoadCustomerProfilesResponse')
        if self.error is not None:
            oprot.writeFieldBegin('error', TType.STRING, 1)
            oprot.writeString(self.error.encode('utf-8') if sys.version_info[0] == 2 else self.error)
            oprot.writeFieldEnd()
        if self.customerProfiles is not None:
            oprot.writeFieldBegin('customerProfiles', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.customerProfiles))
            for _iter61 in self.customerProfiles:
                _iter61.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
