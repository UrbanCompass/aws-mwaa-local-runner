
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.application.ttypes
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.listing.listing_compliance.ttypes
import gen.urbancompass.profile.ttypes
import gen.urbancompass.user.user.ttypes

from thrift.transport import TTransport


class CommentsEnrichOptions(object):
    AUTHORS = 0

    _VALUES_TO_NAMES = {
        0: "AUTHORS",
    }

    _NAMES_TO_VALUES = {
        "AUTHORS": 0,
    }


class CommentsSortableFields(object):
    CREATED_AT = 0

    _VALUES_TO_NAMES = {
        0: "CREATED_AT",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT": 0,
    }


class CommentsTypeFilter(object):
    LISTING_COMMENTS_ONLY = 0

    _VALUES_TO_NAMES = {
        0: "LISTING_COMMENTS_ONLY",
    }

    _NAMES_TO_VALUES = {
        "LISTING_COMMENTS_ONLY": 0,
    }


class Comment(object):
    """
    Attributes:
     - commentId
     - parentIds
     - author
     - content
     - createdAt
     - updatedAt
     - deletedAt
     - keys
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'commentId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'parentIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRUCT, 'author', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 3
        (4, TType.STRING, 'content', 'UTF8', None, ),  # 4
        (5, TType.I64, 'createdAt', None, None, ),  # 5
        (6, TType.I64, 'updatedAt', None, None, ),  # 6
        (7, TType.I64, 'deletedAt', None, None, ),  # 7
        (8, TType.MAP, 'keys', (TType.I32, None, TType.STRING, 'UTF8', False), None, ),  # 8
    )
    def __init__(self, commentId=None, parentIds=None, author=None, content=None, createdAt=None, updatedAt=None, deletedAt=None, keys=None, ):
        self.commentId = commentId
        self.parentIds = parentIds
        self.author = author
        self.content = content
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.deletedAt = deletedAt
        self.keys = keys

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.commentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.parentIds = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.parentIds.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.author = gen.urbancompass.profile.ttypes.Entity()
                    self.author.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.content = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.keys = {}
                    (_ktype7, _vtype8, _size11) = iprot.readMapBegin()
                    for _i6 in range(_size11):
                        _key9 = iprot.readI32()
                        _val10 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.keys[_key9] = _val10
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Comment')
        if self.commentId is not None:
            oprot.writeFieldBegin('commentId', TType.STRING, 1)
            oprot.writeString(self.commentId.encode('utf-8') if sys.version_info[0] == 2 else self.commentId)
            oprot.writeFieldEnd()
        if self.parentIds is not None:
            oprot.writeFieldBegin('parentIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.parentIds))
            for _iter12 in self.parentIds:
                oprot.writeString(_iter12.encode('utf-8') if sys.version_info[0] == 2 else _iter12)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.author is not None:
            oprot.writeFieldBegin('author', TType.STRUCT, 3)
            self.author.write(oprot)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 4)
            oprot.writeString(self.content.encode('utf-8') if sys.version_info[0] == 2 else self.content)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 5)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 6)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 7)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        if self.keys is not None:
            oprot.writeFieldBegin('keys', TType.MAP, 8)
            oprot.writeMapBegin(TType.I32, TType.STRING, len(self.keys))
            for _kiter13, _viter14 in self.keys.items():
                oprot.writeI32(_kiter13)
                oprot.writeString(_viter14.encode('utf-8') if sys.version_info[0] == 2 else _viter14)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommentsEnrichError(object):
    """
    Attributes:
     - commentId
     - enrichOption
     - errorCode
     - errorMessage
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'commentId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'enrichOption', None, None, ),  # 2
        (3, TType.I32, 'errorCode', None, None, ),  # 3
        (4, TType.STRING, 'errorMessage', 'UTF8', None, ),  # 4
    )
    def __init__(self, commentId=None, enrichOption=None, errorCode=None, errorMessage=None, ):
        self.commentId = commentId
        self.enrichOption = enrichOption
        self.errorCode = errorCode
        self.errorMessage = errorMessage

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.commentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.enrichOption = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.errorCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.errorMessage = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommentsEnrichError')
        if self.commentId is not None:
            oprot.writeFieldBegin('commentId', TType.STRING, 1)
            oprot.writeString(self.commentId.encode('utf-8') if sys.version_info[0] == 2 else self.commentId)
            oprot.writeFieldEnd()
        if self.enrichOption is not None:
            oprot.writeFieldBegin('enrichOption', TType.I32, 2)
            oprot.writeI32(self.enrichOption)
            oprot.writeFieldEnd()
        if self.errorCode is not None:
            oprot.writeFieldBegin('errorCode', TType.I32, 3)
            oprot.writeI32(self.errorCode)
            oprot.writeFieldEnd()
        if self.errorMessage is not None:
            oprot.writeFieldBegin('errorMessage', TType.STRING, 4)
            oprot.writeString(self.errorMessage.encode('utf-8') if sys.version_info[0] == 2 else self.errorMessage)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommentsPerParentsTotalCount(object):
    """
    Attributes:
     - parentIds
     - count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'parentIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'count', None, None, ),  # 2
    )
    def __init__(self, parentIds=None, count=None, ):
        self.parentIds = parentIds
        self.count = count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.parentIds = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.parentIds.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommentsPerParentsTotalCount')
        if self.parentIds is not None:
            oprot.writeFieldBegin('parentIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.parentIds))
            for _iter19 in self.parentIds:
                oprot.writeString(_iter19.encode('utf-8') if sys.version_info[0] == 2 else _iter19)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 2)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CommentsSort(object):
    """
    Attributes:
     - orderBy
     - orderAsc
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'orderBy', None, None, ),  # 1
        (2, TType.BOOL, 'orderAsc', None, None, ),  # 2
    )
    def __init__(self, orderBy=None, orderAsc=None, ):
        self.orderBy = orderBy
        self.orderAsc = orderAsc

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.orderAsc = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CommentsSort')
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 1)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.orderAsc is not None:
            oprot.writeFieldBegin('orderAsc', TType.BOOL, 2)
            oprot.writeBool(self.orderAsc)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateCollectionListingCommentModel(object):
    """
    Attributes:
     - collectionId
     - listingId
     - content
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'collectionId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'content', 'UTF8', None, ),  # 3
    )
    def __init__(self, collectionId=None, listingId=None, content=None, ):
        self.collectionId = collectionId
        self.listingId = listingId
        self.content = content

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.collectionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.content = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateCollectionListingCommentModel')
        if self.collectionId is not None:
            oprot.writeFieldBegin('collectionId', TType.STRING, 1)
            oprot.writeString(self.collectionId.encode('utf-8') if sys.version_info[0] == 2 else self.collectionId)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 2)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 3)
            oprot.writeString(self.content.encode('utf-8') if sys.version_info[0] == 2 else self.content)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateCommentRequest(object):
    """
    Attributes:
     - userId
     - content
     - parentIds
     - roles
     - enrichOptions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'content', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'parentIds', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        (15, TType.SET, 'enrichOptions', (TType.I32, None, False), None, ),  # 15
    )
    def __init__(self, userId=None, content=None, parentIds=None, roles=None, enrichOptions=None, ):
        self.userId = userId
        self.content = content
        self.parentIds = parentIds
        self.roles = roles
        self.enrichOptions = enrichOptions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.content = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.parentIds = []
                    (_etype20, _size23) = iprot.readListBegin()
                    for _i21 in range(_size23):
                        _elem22 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.parentIds.append(_elem22)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype24, _size27) = iprot.readListBegin()
                    for _i25 in range(_size27):
                        _elem26 = gen.urbancompass.user.user.ttypes.Role()
                        _elem26.read(iprot)
                        self.roles.append(_elem26)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.SET:
                    self.enrichOptions = set()
                    (_etype29, _size31) = iprot.readSetBegin()
                    for _i28 in range(_size31):
                        _elem30 = iprot.readI32()
                        self.enrichOptions.add(_elem30)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateCommentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 2)
            oprot.writeString(self.content.encode('utf-8') if sys.version_info[0] == 2 else self.content)
            oprot.writeFieldEnd()
        if self.parentIds is not None:
            oprot.writeFieldBegin('parentIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.parentIds))
            for _iter32 in self.parentIds:
                oprot.writeString(_iter32.encode('utf-8') if sys.version_info[0] == 2 else _iter32)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter33 in self.roles:
                _iter33.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.enrichOptions is not None:
            oprot.writeFieldBegin('enrichOptions', TType.SET, 15)
            oprot.writeSetBegin(TType.I32, len(self.enrichOptions))
            for _iter34 in self.enrichOptions:
                oprot.writeI32(_iter34)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteCollectionListingCommentRequest(object):
    """
    Attributes:
     - userId
     - userTypeOverrides
     - roles
     - experiments
     - userType
     - isMobileApp
     - collectionId
     - listingId
     - commentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 2
        (3, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'experiments', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.I32, 'userType', None, None, ),  # 5
        (6, TType.BOOL, 'isMobileApp', None, None, ),  # 6
        (7, TType.STRING, 'collectionId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'listingId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'commentId', 'UTF8', None, ),  # 9
    )
    def __init__(self, userId=None, userTypeOverrides=None, roles=None, experiments=None, userType=None, isMobileApp=None, collectionId=None, listingId=None, commentId=None, ):
        self.userId = userId
        self.userTypeOverrides = userTypeOverrides
        self.roles = roles
        self.experiments = experiments
        self.userType = userType
        self.isMobileApp = isMobileApp
        self.collectionId = collectionId
        self.listingId = listingId
        self.commentId = commentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype36, _vtype37, _size40) = iprot.readMapBegin()
                    for _i35 in range(_size40):
                        _key38 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val39 = iprot.readI32()
                        self.userTypeOverrides[_key38] = _val39
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype41, _size44) = iprot.readListBegin()
                    for _i42 in range(_size44):
                        _elem43 = gen.urbancompass.user.user.ttypes.Role()
                        _elem43.read(iprot)
                        self.roles.append(_elem43)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.experiments = []
                    (_etype45, _size48) = iprot.readListBegin()
                    for _i46 in range(_size48):
                        _elem47 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.experiments.append(_elem47)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isMobileApp = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.collectionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.commentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteCollectionListingCommentRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter49, _viter50 in self.userTypeOverrides.items():
                oprot.writeString(_kiter49.encode('utf-8') if sys.version_info[0] == 2 else _kiter49)
                oprot.writeI32(_viter50)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter51 in self.roles:
                _iter51.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.experiments is not None:
            oprot.writeFieldBegin('experiments', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.experiments))
            for _iter52 in self.experiments:
                oprot.writeString(_iter52.encode('utf-8') if sys.version_info[0] == 2 else _iter52)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 5)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.isMobileApp is not None:
            oprot.writeFieldBegin('isMobileApp', TType.BOOL, 6)
            oprot.writeBool(self.isMobileApp)
            oprot.writeFieldEnd()
        if self.collectionId is not None:
            oprot.writeFieldBegin('collectionId', TType.STRING, 7)
            oprot.writeString(self.collectionId.encode('utf-8') if sys.version_info[0] == 2 else self.collectionId)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 8)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.commentId is not None:
            oprot.writeFieldBegin('commentId', TType.STRING, 9)
            oprot.writeString(self.commentId.encode('utf-8') if sys.version_info[0] == 2 else self.commentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteCollectionListingCommentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteCollectionListingCommentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteCommentsRequest(object):
    """
    Attributes:
     - commentIds
     - userId
     - roles
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'commentIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        None,  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        (10, TType.STRING, 'userId', 'UTF8', None, ),  # 10
        (11, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 11
    )
    def __init__(self, commentIds=None, userId=None, roles=None, ):
        self.commentIds = commentIds
        self.userId = userId
        self.roles = roles

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.commentIds = []
                    (_etype53, _size56) = iprot.readListBegin()
                    for _i54 in range(_size56):
                        _elem55 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.commentIds.append(_elem55)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype57, _size60) = iprot.readListBegin()
                    for _i58 in range(_size60):
                        _elem59 = gen.urbancompass.user.user.ttypes.Role()
                        _elem59.read(iprot)
                        self.roles.append(_elem59)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteCommentsRequest')
        if self.commentIds is not None:
            oprot.writeFieldBegin('commentIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.commentIds))
            for _iter61 in self.commentIds:
                oprot.writeString(_iter61.encode('utf-8') if sys.version_info[0] == 2 else _iter61)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 10)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter62 in self.roles:
                _iter62.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteCommentsResponse(object):
    """
    Attributes:
     - status
     - count
     - result
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'count', None, None, ),  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        (10, TType.STRUCT, 'result', (gen.urbancompass.common.application.ttypes.BulkResult, gen.urbancompass.common.application.ttypes.BulkResult.thrift_spec), None, ),  # 10
    )
    def __init__(self, status=None, count=None, result=None, ):
        self.status = status
        self.count = count
        self.result = result

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.result = gen.urbancompass.common.application.ttypes.BulkResult()
                    self.result.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteCommentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 2)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.result is not None:
            oprot.writeFieldBegin('result', TType.STRUCT, 10)
            self.result.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryCommentsRequest(object):
    """
    Attributes:
     - parents
     - authors
     - comments
     - userId
     - roles
     - excludeProfiles
     - limitPerParent
     - orderByMostRecent
     - returnTotalsPerParent
     - keyList
     - enrichOptions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'parents', (TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 1
        (2, TType.LIST, 'authors', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'comments', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 5
        (6, TType.BOOL, 'excludeProfiles', None, None, ),  # 6
        (7, TType.I32, 'limitPerParent', None, None, ),  # 7
        (8, TType.BOOL, 'orderByMostRecent', None, None, ),  # 8
        (9, TType.BOOL, 'returnTotalsPerParent', None, None, ),  # 9
        (10, TType.LIST, 'keyList', (TType.MAP, (TType.I32, None, TType.STRING, 'UTF8', False), False), None, ),  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        (20, TType.SET, 'enrichOptions', (TType.I32, None, False), None, ),  # 20
    )
    def __init__(self, parents=None, authors=None, comments=None, userId=None, roles=None, excludeProfiles=None, limitPerParent=None, orderByMostRecent=None, returnTotalsPerParent=None, keyList=None, enrichOptions=None, ):
        self.parents = parents
        self.authors = authors
        self.comments = comments
        self.userId = userId
        self.roles = roles
        self.excludeProfiles = excludeProfiles
        self.limitPerParent = limitPerParent
        self.orderByMostRecent = orderByMostRecent
        self.returnTotalsPerParent = returnTotalsPerParent
        self.keyList = keyList
        self.enrichOptions = enrichOptions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.parents = []
                    (_etype63, _size66) = iprot.readListBegin()
                    for _i64 in range(_size66):
                        _elem65 = []
                        (_etype67, _size70) = iprot.readListBegin()
                        for _i68 in range(_size70):
                            _elem69 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _elem65.append(_elem69)
                        iprot.readListEnd()
                        self.parents.append(_elem65)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.authors = []
                    (_etype71, _size74) = iprot.readListBegin()
                    for _i72 in range(_size74):
                        _elem73 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.authors.append(_elem73)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.comments = []
                    (_etype75, _size78) = iprot.readListBegin()
                    for _i76 in range(_size78):
                        _elem77 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.comments.append(_elem77)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype79, _size82) = iprot.readListBegin()
                    for _i80 in range(_size82):
                        _elem81 = gen.urbancompass.user.user.ttypes.Role()
                        _elem81.read(iprot)
                        self.roles.append(_elem81)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.excludeProfiles = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.limitPerParent = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.orderByMostRecent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.returnTotalsPerParent = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.keyList = []
                    (_etype83, _size86) = iprot.readListBegin()
                    for _i84 in range(_size86):
                        _elem85 = {}
                        (_ktype88, _vtype89, _size92) = iprot.readMapBegin()
                        for _i87 in range(_size92):
                            _key90 = iprot.readI32()
                            _val91 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _elem85[_key90] = _val91
                        iprot.readMapEnd()
                        self.keyList.append(_elem85)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.SET:
                    self.enrichOptions = set()
                    (_etype94, _size96) = iprot.readSetBegin()
                    for _i93 in range(_size96):
                        _elem95 = iprot.readI32()
                        self.enrichOptions.add(_elem95)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryCommentsRequest')
        if self.parents is not None:
            oprot.writeFieldBegin('parents', TType.LIST, 1)
            oprot.writeListBegin(TType.LIST, len(self.parents))
            for _iter97 in self.parents:
                oprot.writeListBegin(TType.STRING, len(_iter97))
                for _iter98 in _iter97:
                    oprot.writeString(_iter98.encode('utf-8') if sys.version_info[0] == 2 else _iter98)
                oprot.writeListEnd()
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.authors is not None:
            oprot.writeFieldBegin('authors', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.authors))
            for _iter99 in self.authors:
                oprot.writeString(_iter99.encode('utf-8') if sys.version_info[0] == 2 else _iter99)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.comments is not None:
            oprot.writeFieldBegin('comments', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.comments))
            for _iter100 in self.comments:
                oprot.writeString(_iter100.encode('utf-8') if sys.version_info[0] == 2 else _iter100)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter101 in self.roles:
                _iter101.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.excludeProfiles is not None:
            oprot.writeFieldBegin('excludeProfiles', TType.BOOL, 6)
            oprot.writeBool(self.excludeProfiles)
            oprot.writeFieldEnd()
        if self.limitPerParent is not None:
            oprot.writeFieldBegin('limitPerParent', TType.I32, 7)
            oprot.writeI32(self.limitPerParent)
            oprot.writeFieldEnd()
        if self.orderByMostRecent is not None:
            oprot.writeFieldBegin('orderByMostRecent', TType.BOOL, 8)
            oprot.writeBool(self.orderByMostRecent)
            oprot.writeFieldEnd()
        if self.returnTotalsPerParent is not None:
            oprot.writeFieldBegin('returnTotalsPerParent', TType.BOOL, 9)
            oprot.writeBool(self.returnTotalsPerParent)
            oprot.writeFieldEnd()
        if self.keyList is not None:
            oprot.writeFieldBegin('keyList', TType.LIST, 10)
            oprot.writeListBegin(TType.MAP, len(self.keyList))
            for _iter102 in self.keyList:
                oprot.writeMapBegin(TType.I32, TType.STRING, len(_iter102))
                for _kiter103, _viter104 in _iter102.items():
                    oprot.writeI32(_kiter103)
                    oprot.writeString(_viter104.encode('utf-8') if sys.version_info[0] == 2 else _viter104)
                oprot.writeMapEnd()
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.enrichOptions is not None:
            oprot.writeFieldBegin('enrichOptions', TType.SET, 20)
            oprot.writeSetBegin(TType.I32, len(self.enrichOptions))
            for _iter105 in self.enrichOptions:
                oprot.writeI32(_iter105)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateCommentRequest(object):
    """
    Attributes:
     - commentId
     - content
     - userId
     - roles
     - enrichOptions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'commentId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'content', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        (15, TType.SET, 'enrichOptions', (TType.I32, None, False), None, ),  # 15
    )
    def __init__(self, commentId=None, content=None, userId=None, roles=None, enrichOptions=None, ):
        self.commentId = commentId
        self.content = content
        self.userId = userId
        self.roles = roles
        self.enrichOptions = enrichOptions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.commentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.content = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype106, _size109) = iprot.readListBegin()
                    for _i107 in range(_size109):
                        _elem108 = gen.urbancompass.user.user.ttypes.Role()
                        _elem108.read(iprot)
                        self.roles.append(_elem108)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.SET:
                    self.enrichOptions = set()
                    (_etype111, _size113) = iprot.readSetBegin()
                    for _i110 in range(_size113):
                        _elem112 = iprot.readI32()
                        self.enrichOptions.add(_elem112)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateCommentRequest')
        if self.commentId is not None:
            oprot.writeFieldBegin('commentId', TType.STRING, 1)
            oprot.writeString(self.commentId.encode('utf-8') if sys.version_info[0] == 2 else self.commentId)
            oprot.writeFieldEnd()
        if self.content is not None:
            oprot.writeFieldBegin('content', TType.STRING, 2)
            oprot.writeString(self.content.encode('utf-8') if sys.version_info[0] == 2 else self.content)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter114 in self.roles:
                _iter114.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.enrichOptions is not None:
            oprot.writeFieldBegin('enrichOptions', TType.SET, 15)
            oprot.writeSetBegin(TType.I32, len(self.enrichOptions))
            for _iter115 in self.enrichOptions:
                oprot.writeI32(_iter115)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateCollectionsListingsCommentsRequest(object):
    """
    Attributes:
     - userId
     - userTypeOverrides
     - roles
     - experiments
     - userType
     - isMobileApp
     - collectionListingComments
     - enrichAuthor
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 2
        (3, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'experiments', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.I32, 'userType', None, None, ),  # 5
        (6, TType.BOOL, 'isMobileApp', None, None, ),  # 6
        (7, TType.LIST, 'collectionListingComments', (TType.STRUCT, (CreateCollectionListingCommentModel, CreateCollectionListingCommentModel.thrift_spec), False), None, ),  # 7
        (8, TType.BOOL, 'enrichAuthor', None, None, ),  # 8
    )
    def __init__(self, userId=None, userTypeOverrides=None, roles=None, experiments=None, userType=None, isMobileApp=None, collectionListingComments=None, enrichAuthor=None, ):
        self.userId = userId
        self.userTypeOverrides = userTypeOverrides
        self.roles = roles
        self.experiments = experiments
        self.userType = userType
        self.isMobileApp = isMobileApp
        self.collectionListingComments = collectionListingComments
        self.enrichAuthor = enrichAuthor

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype117, _vtype118, _size121) = iprot.readMapBegin()
                    for _i116 in range(_size121):
                        _key119 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val120 = iprot.readI32()
                        self.userTypeOverrides[_key119] = _val120
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype122, _size125) = iprot.readListBegin()
                    for _i123 in range(_size125):
                        _elem124 = gen.urbancompass.user.user.ttypes.Role()
                        _elem124.read(iprot)
                        self.roles.append(_elem124)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.experiments = []
                    (_etype126, _size129) = iprot.readListBegin()
                    for _i127 in range(_size129):
                        _elem128 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.experiments.append(_elem128)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.isMobileApp = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.collectionListingComments = []
                    (_etype130, _size133) = iprot.readListBegin()
                    for _i131 in range(_size133):
                        _elem132 = CreateCollectionListingCommentModel()
                        _elem132.read(iprot)
                        self.collectionListingComments.append(_elem132)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.BOOL:
                    self.enrichAuthor = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateCollectionsListingsCommentsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter134, _viter135 in self.userTypeOverrides.items():
                oprot.writeString(_kiter134.encode('utf-8') if sys.version_info[0] == 2 else _kiter134)
                oprot.writeI32(_viter135)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter136 in self.roles:
                _iter136.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.experiments is not None:
            oprot.writeFieldBegin('experiments', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.experiments))
            for _iter137 in self.experiments:
                oprot.writeString(_iter137.encode('utf-8') if sys.version_info[0] == 2 else _iter137)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 5)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.isMobileApp is not None:
            oprot.writeFieldBegin('isMobileApp', TType.BOOL, 6)
            oprot.writeBool(self.isMobileApp)
            oprot.writeFieldEnd()
        if self.collectionListingComments is not None:
            oprot.writeFieldBegin('collectionListingComments', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.collectionListingComments))
            for _iter138 in self.collectionListingComments:
                _iter138.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.enrichAuthor is not None:
            oprot.writeFieldBegin('enrichAuthor', TType.BOOL, 8)
            oprot.writeBool(self.enrichAuthor)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateCommentResponse(object):
    """
    Attributes:
     - status
     - comment
     - enrichErrors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'comment', (Comment, Comment.thrift_spec), None, ),  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        (10, TType.LIST, 'enrichErrors', (TType.STRUCT, (CommentsEnrichError, CommentsEnrichError.thrift_spec), False), None, ),  # 10
    )
    def __init__(self, status=None, comment=None, enrichErrors=None, ):
        self.status = status
        self.comment = comment
        self.enrichErrors = enrichErrors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.comment = Comment()
                    self.comment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.enrichErrors = []
                    (_etype139, _size142) = iprot.readListBegin()
                    for _i140 in range(_size142):
                        _elem141 = CommentsEnrichError()
                        _elem141.read(iprot)
                        self.enrichErrors.append(_elem141)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateCommentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.comment is not None:
            oprot.writeFieldBegin('comment', TType.STRUCT, 2)
            self.comment.write(oprot)
            oprot.writeFieldEnd()
        if self.enrichErrors is not None:
            oprot.writeFieldBegin('enrichErrors', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.enrichErrors))
            for _iter143 in self.enrichErrors:
                _iter143.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreatedCollectionListingCommentModel(object):
    """
    Attributes:
     - collectionId
     - listingId
     - comment
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'collectionId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingId', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'comment', (Comment, Comment.thrift_spec), None, ),  # 3
    )
    def __init__(self, collectionId=None, listingId=None, comment=None, ):
        self.collectionId = collectionId
        self.listingId = listingId
        self.comment = comment

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.collectionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.comment = Comment()
                    self.comment.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreatedCollectionListingCommentModel')
        if self.collectionId is not None:
            oprot.writeFieldBegin('collectionId', TType.STRING, 1)
            oprot.writeString(self.collectionId.encode('utf-8') if sys.version_info[0] == 2 else self.collectionId)
            oprot.writeFieldEnd()
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 2)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.comment is not None:
            oprot.writeFieldBegin('comment', TType.STRUCT, 3)
            self.comment.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryBulkCommentsRequest(object):
    """
    Attributes:
     - collectionIds
     - userId
     - sort
     - pagination
     - startDateTime
     - commentsTypeFilter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'collectionIds', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'userId', 'UTF8', None, ),  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        (10, TType.STRUCT, 'sort', (CommentsSort, CommentsSort.thrift_spec), None, ),  # 10
        (11, TType.STRUCT, 'pagination', (gen.urbancompass.common.application.ttypes.Pagination, gen.urbancompass.common.application.ttypes.Pagination.thrift_spec), None, ),  # 11
        (12, TType.I64, 'startDateTime', None, None, ),  # 12
        (13, TType.I32, 'commentsTypeFilter', None, None, ),  # 13
    )
    def __init__(self, collectionIds=None, userId=None, sort=None, pagination=None, startDateTime=None, commentsTypeFilter=None, ):
        self.collectionIds = collectionIds
        self.userId = userId
        self.sort = sort
        self.pagination = pagination
        self.startDateTime = startDateTime
        self.commentsTypeFilter = commentsTypeFilter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.collectionIds = []
                    (_etype144, _size147) = iprot.readListBegin()
                    for _i145 in range(_size147):
                        _elem146 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.collectionIds.append(_elem146)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.sort = CommentsSort()
                    self.sort.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.pagination = gen.urbancompass.common.application.ttypes.Pagination()
                    self.pagination.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.startDateTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.I32:
                    self.commentsTypeFilter = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryBulkCommentsRequest')
        if self.collectionIds is not None:
            oprot.writeFieldBegin('collectionIds', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.collectionIds))
            for _iter148 in self.collectionIds:
                oprot.writeString(_iter148.encode('utf-8') if sys.version_info[0] == 2 else _iter148)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 2)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.sort is not None:
            oprot.writeFieldBegin('sort', TType.STRUCT, 10)
            self.sort.write(oprot)
            oprot.writeFieldEnd()
        if self.pagination is not None:
            oprot.writeFieldBegin('pagination', TType.STRUCT, 11)
            self.pagination.write(oprot)
            oprot.writeFieldEnd()
        if self.startDateTime is not None:
            oprot.writeFieldBegin('startDateTime', TType.I64, 12)
            oprot.writeI64(self.startDateTime)
            oprot.writeFieldEnd()
        if self.commentsTypeFilter is not None:
            oprot.writeFieldBegin('commentsTypeFilter', TType.I32, 13)
            oprot.writeI32(self.commentsTypeFilter)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryBulkCommentsResponse(object):
    """
    Attributes:
     - status
     - comments
     - totalResults
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'comments', (TType.STRUCT, (Comment, Comment.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalResults', None, None, ),  # 3
    )
    def __init__(self, status=None, comments=None, totalResults=None, ):
        self.status = status
        self.comments = comments
        self.totalResults = totalResults

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.comments = []
                    (_etype149, _size152) = iprot.readListBegin()
                    for _i150 in range(_size152):
                        _elem151 = Comment()
                        _elem151.read(iprot)
                        self.comments.append(_elem151)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalResults = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryBulkCommentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.comments is not None:
            oprot.writeFieldBegin('comments', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.comments))
            for _iter153 in self.comments:
                _iter153.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalResults is not None:
            oprot.writeFieldBegin('totalResults', TType.I32, 3)
            oprot.writeI32(self.totalResults)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class QueryCommentsResponse(object):
    """
    Attributes:
     - status
     - comments
     - totalCountPerParent
     - enrichErrors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'comments', (TType.STRUCT, (Comment, Comment.thrift_spec), False), None, ),  # 2
        (3, TType.LIST, 'totalCountPerParent', (TType.STRUCT, (CommentsPerParentsTotalCount, CommentsPerParentsTotalCount.thrift_spec), False), None, ),  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        (15, TType.LIST, 'enrichErrors', (TType.STRUCT, (CommentsEnrichError, CommentsEnrichError.thrift_spec), False), None, ),  # 15
    )
    def __init__(self, status=None, comments=None, totalCountPerParent=None, enrichErrors=None, ):
        self.status = status
        self.comments = comments
        self.totalCountPerParent = totalCountPerParent
        self.enrichErrors = enrichErrors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.comments = []
                    (_etype154, _size157) = iprot.readListBegin()
                    for _i155 in range(_size157):
                        _elem156 = Comment()
                        _elem156.read(iprot)
                        self.comments.append(_elem156)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.totalCountPerParent = []
                    (_etype158, _size161) = iprot.readListBegin()
                    for _i159 in range(_size161):
                        _elem160 = CommentsPerParentsTotalCount()
                        _elem160.read(iprot)
                        self.totalCountPerParent.append(_elem160)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.enrichErrors = []
                    (_etype162, _size165) = iprot.readListBegin()
                    for _i163 in range(_size165):
                        _elem164 = CommentsEnrichError()
                        _elem164.read(iprot)
                        self.enrichErrors.append(_elem164)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('QueryCommentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.comments is not None:
            oprot.writeFieldBegin('comments', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.comments))
            for _iter166 in self.comments:
                _iter166.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalCountPerParent is not None:
            oprot.writeFieldBegin('totalCountPerParent', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.totalCountPerParent))
            for _iter167 in self.totalCountPerParent:
                _iter167.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.enrichErrors is not None:
            oprot.writeFieldBegin('enrichErrors', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.enrichErrors))
            for _iter168 in self.enrichErrors:
                _iter168.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateCommentResponse(object):
    """
    Attributes:
     - status
     - comment
     - enrichErrors
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'comment', (Comment, Comment.thrift_spec), None, ),  # 2
        None,  # 3
        None,  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        (10, TType.LIST, 'enrichErrors', (TType.STRUCT, (CommentsEnrichError, CommentsEnrichError.thrift_spec), False), None, ),  # 10
    )
    def __init__(self, status=None, comment=None, enrichErrors=None, ):
        self.status = status
        self.comment = comment
        self.enrichErrors = enrichErrors

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.comment = Comment()
                    self.comment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.enrichErrors = []
                    (_etype169, _size172) = iprot.readListBegin()
                    for _i170 in range(_size172):
                        _elem171 = CommentsEnrichError()
                        _elem171.read(iprot)
                        self.enrichErrors.append(_elem171)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateCommentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.comment is not None:
            oprot.writeFieldBegin('comment', TType.STRUCT, 2)
            self.comment.write(oprot)
            oprot.writeFieldEnd()
        if self.enrichErrors is not None:
            oprot.writeFieldBegin('enrichErrors', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.enrichErrors))
            for _iter173 in self.enrichErrors:
                _iter173.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateCollectionsListingsCommentsResponse(object):
    """
    Attributes:
     - status
     - collectionListingComments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'collectionListingComments', (TType.STRUCT, (CreatedCollectionListingCommentModel, CreatedCollectionListingCommentModel.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, collectionListingComments=None, ):
        self.status = status
        self.collectionListingComments = collectionListingComments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.collectionListingComments = []
                    (_etype174, _size177) = iprot.readListBegin()
                    for _i175 in range(_size177):
                        _elem176 = CreatedCollectionListingCommentModel()
                        _elem176.read(iprot)
                        self.collectionListingComments.append(_elem176)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateCollectionsListingsCommentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.collectionListingComments is not None:
            oprot.writeFieldBegin('collectionListingComments', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.collectionListingComments))
            for _iter178 in self.collectionListingComments:
                _iter178.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
