
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.concierge_lens_v0.lens_processed_listing.ttypes

from thrift.transport import TTransport


class ProjectStatus(object):
    ALL = 0
    ACTIVE = 1
    PAST = 2
    UNKNOWN = 3

    _VALUES_TO_NAMES = {
        0: "ALL",
        1: "ACTIVE",
        2: "PAST",
        3: "UNKNOWN",
    }

    _NAMES_TO_VALUES = {
        "ALL": 0,
        "ACTIVE": 1,
        "PAST": 2,
        "UNKNOWN": 3,
    }


class EncodingModelResponse(object):
    """
    Attributes:
     - valid
     - roomType
     - roomTypeScore
     - embedding
     - url
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'valid', None, None, ),  # 1
        (2, TType.STRING, 'roomType', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'roomTypeScore', None, None, ),  # 3
        (4, TType.LIST, 'embedding', (TType.DOUBLE, None, False), None, ),  # 4
        (5, TType.STRING, 'url', 'UTF8', None, ),  # 5
    )
    def __init__(self, valid=None, roomType=None, roomTypeScore=None, embedding=None, url=None, ):
        self.valid = valid
        self.roomType = roomType
        self.roomTypeScore = roomTypeScore
        self.embedding = embedding
        self.url = url

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.valid = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.roomType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.roomTypeScore = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.embedding = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readDouble()
                        self.embedding.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('EncodingModelResponse')
        if self.valid is not None:
            oprot.writeFieldBegin('valid', TType.BOOL, 1)
            oprot.writeBool(self.valid)
            oprot.writeFieldEnd()
        if self.roomType is not None:
            oprot.writeFieldBegin('roomType', TType.STRING, 2)
            oprot.writeString(self.roomType.encode('utf-8') if sys.version_info[0] == 2 else self.roomType)
            oprot.writeFieldEnd()
        if self.roomTypeScore is not None:
            oprot.writeFieldBegin('roomTypeScore', TType.DOUBLE, 3)
            oprot.writeDouble(self.roomTypeScore)
            oprot.writeFieldEnd()
        if self.embedding is not None:
            oprot.writeFieldBegin('embedding', TType.LIST, 4)
            oprot.writeListBegin(TType.DOUBLE, len(self.embedding))
            for _iter6 in self.embedding:
                oprot.writeDouble(_iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 5)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Filter(object):
    """
    Attributes:
     - geoId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'geoId', 'UTF8', None, ),  # 1
    )
    def __init__(self, geoId=None, ):
        self.geoId = geoId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Filter')
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 1)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetConciergeProjectRequest(object):
    """
    Attributes:
     - offset
     - pageSize
     - userEmail
     - requestProjectStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'offset', None, None, ),  # 1
        (2, TType.I32, 'pageSize', None, None, ),  # 2
        (3, TType.STRING, 'userEmail', 'UTF8', None, ),  # 3
        (4, TType.I32, 'requestProjectStatus', None, None, ),  # 4
    )
    def __init__(self, offset=None, pageSize=None, userEmail=None, requestProjectStatus=None, ):
        self.offset = offset
        self.pageSize = pageSize
        self.userEmail = userEmail
        self.requestProjectStatus = requestProjectStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.pageSize = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.requestProjectStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetConciergeProjectRequest')
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 1)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.pageSize is not None:
            oprot.writeFieldBegin('pageSize', TType.I32, 2)
            oprot.writeI32(self.pageSize)
            oprot.writeFieldEnd()
        if self.userEmail is not None:
            oprot.writeFieldBegin('userEmail', TType.STRING, 3)
            oprot.writeString(self.userEmail.encode('utf-8') if sys.version_info[0] == 2 else self.userEmail)
            oprot.writeFieldEnd()
        if self.requestProjectStatus is not None:
            oprot.writeFieldBegin('requestProjectStatus', TType.I32, 4)
            oprot.writeI32(self.requestProjectStatus)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImageFeedRequest(object):
    """
    Attributes:
     - minPrice
     - maxPrice
     - zipcodes
     - roomtypes
     - conciergeProjectStart
     - conciergeProjectNum
     - compassAgentListingStart
     - compassAgentListingNum
     - nonCompassAgentListingStart
     - nonCompassAgentListingNum
     - geoId
     - extraFilterJson
     - listingIdSha
     - totalLimit
     - conciergeProjectImageItemTypes
     - isConciergeProjectOnly
     - isCompassAgentListingOnly
     - isUserFavoriteImageOnly
     - pageSize
     - offset
     - agentOpinionPriceMinRatio
     - agentOpinionPriceMaxRatio
     - hasAgentOpinionPrice
     - hasTotalPaymentsApproved
     - minTotalPaymentsApproved
     - maxTotalPaymentsApproved
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'minPrice', None, None, ),  # 1
        (2, TType.DOUBLE, 'maxPrice', None, None, ),  # 2
        (3, TType.LIST, 'zipcodes', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'roomtypes', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.I32, 'conciergeProjectStart', None, None, ),  # 5
        (6, TType.I32, 'conciergeProjectNum', None, None, ),  # 6
        (7, TType.I32, 'compassAgentListingStart', None, None, ),  # 7
        (8, TType.I32, 'compassAgentListingNum', None, None, ),  # 8
        (9, TType.I32, 'nonCompassAgentListingStart', None, None, ),  # 9
        (10, TType.I32, 'nonCompassAgentListingNum', None, None, ),  # 10
        (11, TType.STRING, 'geoId', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'extraFilterJson', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'listingIdSha', 'UTF8', None, ),  # 13
        (14, TType.I32, 'totalLimit', None, None, ),  # 14
        (15, TType.LIST, 'conciergeProjectImageItemTypes', (TType.STRING, 'UTF8', False), None, ),  # 15
        (16, TType.BOOL, 'isConciergeProjectOnly', None, None, ),  # 16
        (17, TType.BOOL, 'isCompassAgentListingOnly', None, None, ),  # 17
        (18, TType.BOOL, 'isUserFavoriteImageOnly', None, None, ),  # 18
        (19, TType.I32, 'pageSize', None, None, ),  # 19
        (20, TType.I32, 'offset', None, None, ),  # 20
        (21, TType.DOUBLE, 'agentOpinionPriceMinRatio', None, None, ),  # 21
        (22, TType.DOUBLE, 'agentOpinionPriceMaxRatio', None, None, ),  # 22
        (23, TType.BOOL, 'hasAgentOpinionPrice', None, None, ),  # 23
        (24, TType.BOOL, 'hasTotalPaymentsApproved', None, None, ),  # 24
        (25, TType.DOUBLE, 'minTotalPaymentsApproved', None, None, ),  # 25
        (26, TType.DOUBLE, 'maxTotalPaymentsApproved', None, None, ),  # 26
        (27, TType.STRING, 'userId', 'UTF8', None, ),  # 27
    )
    def __init__(self, minPrice=None, maxPrice=None, zipcodes=None, roomtypes=None, conciergeProjectStart=None, conciergeProjectNum=None, compassAgentListingStart=None, compassAgentListingNum=None, nonCompassAgentListingStart=None, nonCompassAgentListingNum=None, geoId=None, extraFilterJson=None, listingIdSha=None, totalLimit=None, conciergeProjectImageItemTypes=None, isConciergeProjectOnly=None, isCompassAgentListingOnly=None, isUserFavoriteImageOnly=None, pageSize=None, offset=None, agentOpinionPriceMinRatio=None, agentOpinionPriceMaxRatio=None, hasAgentOpinionPrice=None, hasTotalPaymentsApproved=None, minTotalPaymentsApproved=None, maxTotalPaymentsApproved=None, userId=None, ):
        self.minPrice = minPrice
        self.maxPrice = maxPrice
        self.zipcodes = zipcodes
        self.roomtypes = roomtypes
        self.conciergeProjectStart = conciergeProjectStart
        self.conciergeProjectNum = conciergeProjectNum
        self.compassAgentListingStart = compassAgentListingStart
        self.compassAgentListingNum = compassAgentListingNum
        self.nonCompassAgentListingStart = nonCompassAgentListingStart
        self.nonCompassAgentListingNum = nonCompassAgentListingNum
        self.geoId = geoId
        self.extraFilterJson = extraFilterJson
        self.listingIdSha = listingIdSha
        self.totalLimit = totalLimit
        self.conciergeProjectImageItemTypes = conciergeProjectImageItemTypes
        self.isConciergeProjectOnly = isConciergeProjectOnly
        self.isCompassAgentListingOnly = isCompassAgentListingOnly
        self.isUserFavoriteImageOnly = isUserFavoriteImageOnly
        self.pageSize = pageSize
        self.offset = offset
        self.agentOpinionPriceMinRatio = agentOpinionPriceMinRatio
        self.agentOpinionPriceMaxRatio = agentOpinionPriceMaxRatio
        self.hasAgentOpinionPrice = hasAgentOpinionPrice
        self.hasTotalPaymentsApproved = hasTotalPaymentsApproved
        self.minTotalPaymentsApproved = minTotalPaymentsApproved
        self.maxTotalPaymentsApproved = maxTotalPaymentsApproved
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.minPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.maxPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.zipcodes = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.zipcodes.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.roomtypes = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.roomtypes.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.conciergeProjectStart = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I32:
                    self.conciergeProjectNum = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.compassAgentListingStart = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.compassAgentListingNum = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.nonCompassAgentListingStart = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.nonCompassAgentListingNum = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.extraFilterJson = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.listingIdSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I32:
                    self.totalLimit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.conciergeProjectImageItemTypes = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.conciergeProjectImageItemTypes.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.isConciergeProjectOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.BOOL:
                    self.isCompassAgentListingOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.BOOL:
                    self.isUserFavoriteImageOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.pageSize = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.offset = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.DOUBLE:
                    self.agentOpinionPriceMinRatio = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.DOUBLE:
                    self.agentOpinionPriceMaxRatio = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.BOOL:
                    self.hasAgentOpinionPrice = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.BOOL:
                    self.hasTotalPaymentsApproved = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.DOUBLE:
                    self.minTotalPaymentsApproved = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.DOUBLE:
                    self.maxTotalPaymentsApproved = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImageFeedRequest')
        if self.minPrice is not None:
            oprot.writeFieldBegin('minPrice', TType.DOUBLE, 1)
            oprot.writeDouble(self.minPrice)
            oprot.writeFieldEnd()
        if self.maxPrice is not None:
            oprot.writeFieldBegin('maxPrice', TType.DOUBLE, 2)
            oprot.writeDouble(self.maxPrice)
            oprot.writeFieldEnd()
        if self.zipcodes is not None:
            oprot.writeFieldBegin('zipcodes', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.zipcodes))
            for _iter19 in self.zipcodes:
                oprot.writeString(_iter19.encode('utf-8') if sys.version_info[0] == 2 else _iter19)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.roomtypes is not None:
            oprot.writeFieldBegin('roomtypes', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.roomtypes))
            for _iter20 in self.roomtypes:
                oprot.writeString(_iter20.encode('utf-8') if sys.version_info[0] == 2 else _iter20)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.conciergeProjectStart is not None:
            oprot.writeFieldBegin('conciergeProjectStart', TType.I32, 5)
            oprot.writeI32(self.conciergeProjectStart)
            oprot.writeFieldEnd()
        if self.conciergeProjectNum is not None:
            oprot.writeFieldBegin('conciergeProjectNum', TType.I32, 6)
            oprot.writeI32(self.conciergeProjectNum)
            oprot.writeFieldEnd()
        if self.compassAgentListingStart is not None:
            oprot.writeFieldBegin('compassAgentListingStart', TType.I32, 7)
            oprot.writeI32(self.compassAgentListingStart)
            oprot.writeFieldEnd()
        if self.compassAgentListingNum is not None:
            oprot.writeFieldBegin('compassAgentListingNum', TType.I32, 8)
            oprot.writeI32(self.compassAgentListingNum)
            oprot.writeFieldEnd()
        if self.nonCompassAgentListingStart is not None:
            oprot.writeFieldBegin('nonCompassAgentListingStart', TType.I32, 9)
            oprot.writeI32(self.nonCompassAgentListingStart)
            oprot.writeFieldEnd()
        if self.nonCompassAgentListingNum is not None:
            oprot.writeFieldBegin('nonCompassAgentListingNum', TType.I32, 10)
            oprot.writeI32(self.nonCompassAgentListingNum)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 11)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.extraFilterJson is not None:
            oprot.writeFieldBegin('extraFilterJson', TType.STRING, 12)
            oprot.writeString(self.extraFilterJson.encode('utf-8') if sys.version_info[0] == 2 else self.extraFilterJson)
            oprot.writeFieldEnd()
        if self.listingIdSha is not None:
            oprot.writeFieldBegin('listingIdSha', TType.STRING, 13)
            oprot.writeString(self.listingIdSha.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSha)
            oprot.writeFieldEnd()
        if self.totalLimit is not None:
            oprot.writeFieldBegin('totalLimit', TType.I32, 14)
            oprot.writeI32(self.totalLimit)
            oprot.writeFieldEnd()
        if self.conciergeProjectImageItemTypes is not None:
            oprot.writeFieldBegin('conciergeProjectImageItemTypes', TType.LIST, 15)
            oprot.writeListBegin(TType.STRING, len(self.conciergeProjectImageItemTypes))
            for _iter21 in self.conciergeProjectImageItemTypes:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isConciergeProjectOnly is not None:
            oprot.writeFieldBegin('isConciergeProjectOnly', TType.BOOL, 16)
            oprot.writeBool(self.isConciergeProjectOnly)
            oprot.writeFieldEnd()
        if self.isCompassAgentListingOnly is not None:
            oprot.writeFieldBegin('isCompassAgentListingOnly', TType.BOOL, 17)
            oprot.writeBool(self.isCompassAgentListingOnly)
            oprot.writeFieldEnd()
        if self.isUserFavoriteImageOnly is not None:
            oprot.writeFieldBegin('isUserFavoriteImageOnly', TType.BOOL, 18)
            oprot.writeBool(self.isUserFavoriteImageOnly)
            oprot.writeFieldEnd()
        if self.pageSize is not None:
            oprot.writeFieldBegin('pageSize', TType.I32, 19)
            oprot.writeI32(self.pageSize)
            oprot.writeFieldEnd()
        if self.offset is not None:
            oprot.writeFieldBegin('offset', TType.I32, 20)
            oprot.writeI32(self.offset)
            oprot.writeFieldEnd()
        if self.agentOpinionPriceMinRatio is not None:
            oprot.writeFieldBegin('agentOpinionPriceMinRatio', TType.DOUBLE, 21)
            oprot.writeDouble(self.agentOpinionPriceMinRatio)
            oprot.writeFieldEnd()
        if self.agentOpinionPriceMaxRatio is not None:
            oprot.writeFieldBegin('agentOpinionPriceMaxRatio', TType.DOUBLE, 22)
            oprot.writeDouble(self.agentOpinionPriceMaxRatio)
            oprot.writeFieldEnd()
        if self.hasAgentOpinionPrice is not None:
            oprot.writeFieldBegin('hasAgentOpinionPrice', TType.BOOL, 23)
            oprot.writeBool(self.hasAgentOpinionPrice)
            oprot.writeFieldEnd()
        if self.hasTotalPaymentsApproved is not None:
            oprot.writeFieldBegin('hasTotalPaymentsApproved', TType.BOOL, 24)
            oprot.writeBool(self.hasTotalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.minTotalPaymentsApproved is not None:
            oprot.writeFieldBegin('minTotalPaymentsApproved', TType.DOUBLE, 25)
            oprot.writeDouble(self.minTotalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.maxTotalPaymentsApproved is not None:
            oprot.writeFieldBegin('maxTotalPaymentsApproved', TType.DOUBLE, 26)
            oprot.writeDouble(self.maxTotalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 27)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImageUrlRequest(object):
    """
    Attributes:
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
    )
    def __init__(self, userId=None, ):
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImageUrlRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImageUrlResponse(object):
    """
    Attributes:
     - status
     - url
     - transactionId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'url', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'transactionId', 'UTF8', None, ),  # 3
    )
    def __init__(self, status=None, url=None, transactionId=None, ):
        self.status = status
        self.url = url
        self.transactionId = transactionId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.transactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImageUrlResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 2)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.transactionId is not None:
            oprot.writeFieldBegin('transactionId', TType.STRING, 3)
            oprot.writeString(self.transactionId.encode('utf-8') if sys.version_info[0] == 2 else self.transactionId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImageUrlsRequest(object):
    """
    Attributes:
     - listingId
     - imageSize
     - agentId
     - agentEmail
     - agentFirstName
     - agentLastName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'imageSize', None, None, ),  # 2
        (3, TType.STRING, 'agentId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'agentEmail', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'agentFirstName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'agentLastName', 'UTF8', None, ),  # 6
    )
    def __init__(self, listingId=None, imageSize=None, agentId=None, agentEmail=None, agentFirstName=None, agentLastName=None, ):
        self.listingId = listingId
        self.imageSize = imageSize
        self.agentId = agentId
        self.agentEmail = agentEmail
        self.agentFirstName = agentFirstName
        self.agentLastName = agentLastName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.imageSize = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.agentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.agentEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.agentFirstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.agentLastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImageUrlsRequest')
        if self.listingId is not None:
            oprot.writeFieldBegin('listingId', TType.STRING, 1)
            oprot.writeString(self.listingId.encode('utf-8') if sys.version_info[0] == 2 else self.listingId)
            oprot.writeFieldEnd()
        if self.imageSize is not None:
            oprot.writeFieldBegin('imageSize', TType.I32, 2)
            oprot.writeI32(self.imageSize)
            oprot.writeFieldEnd()
        if self.agentId is not None:
            oprot.writeFieldBegin('agentId', TType.STRING, 3)
            oprot.writeString(self.agentId.encode('utf-8') if sys.version_info[0] == 2 else self.agentId)
            oprot.writeFieldEnd()
        if self.agentEmail is not None:
            oprot.writeFieldBegin('agentEmail', TType.STRING, 4)
            oprot.writeString(self.agentEmail.encode('utf-8') if sys.version_info[0] == 2 else self.agentEmail)
            oprot.writeFieldEnd()
        if self.agentFirstName is not None:
            oprot.writeFieldBegin('agentFirstName', TType.STRING, 5)
            oprot.writeString(self.agentFirstName.encode('utf-8') if sys.version_info[0] == 2 else self.agentFirstName)
            oprot.writeFieldEnd()
        if self.agentLastName is not None:
            oprot.writeFieldBegin('agentLastName', TType.STRING, 6)
            oprot.writeString(self.agentLastName.encode('utf-8') if sys.version_info[0] == 2 else self.agentLastName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImageUrlsResponse(object):
    """
    Attributes:
     - status
     - imageUrls
     - presignedUrls
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'imageUrls', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'presignedUrls', (TType.STRING, 'UTF8', False), None, ),  # 3
    )
    def __init__(self, status=None, imageUrls=None, presignedUrls=None, ):
        self.status = status
        self.imageUrls = imageUrls
        self.presignedUrls = presignedUrls

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.imageUrls = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.imageUrls.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.presignedUrls = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.presignedUrls.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImageUrlsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.imageUrls is not None:
            oprot.writeFieldBegin('imageUrls', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.imageUrls))
            for _iter30 in self.imageUrls:
                oprot.writeString(_iter30.encode('utf-8') if sys.version_info[0] == 2 else _iter30)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.presignedUrls is not None:
            oprot.writeFieldBegin('presignedUrls', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.presignedUrls))
            for _iter31 in self.presignedUrls:
                oprot.writeString(_iter31.encode('utf-8') if sys.version_info[0] == 2 else _iter31)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class KnnModelResponse(object):
    """
    Attributes:
     - valid
     - distances
     - ids
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'valid', None, None, ),  # 1
        (2, TType.LIST, 'distances', (TType.DOUBLE, None, False), None, ),  # 2
        (3, TType.LIST, 'ids', (TType.STRING, 'UTF8', False), None, ),  # 3
    )
    def __init__(self, valid=None, distances=None, ids=None, ):
        self.valid = valid
        self.distances = distances
        self.ids = ids

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.valid = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.distances = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = iprot.readDouble()
                        self.distances.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.ids = []
                    (_etype36, _size39) = iprot.readListBegin()
                    for _i37 in range(_size39):
                        _elem38 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.ids.append(_elem38)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('KnnModelResponse')
        if self.valid is not None:
            oprot.writeFieldBegin('valid', TType.BOOL, 1)
            oprot.writeBool(self.valid)
            oprot.writeFieldEnd()
        if self.distances is not None:
            oprot.writeFieldBegin('distances', TType.LIST, 2)
            oprot.writeListBegin(TType.DOUBLE, len(self.distances))
            for _iter40 in self.distances:
                oprot.writeDouble(_iter40)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.ids is not None:
            oprot.writeFieldBegin('ids', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.ids))
            for _iter41 in self.ids:
                oprot.writeString(_iter41.encode('utf-8') if sys.version_info[0] == 2 else _iter41)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LensConciergeProjectItem(object):
    """
    Attributes:
     - count
     - conciergeProjectId
     - conciergeInfo
     - agentName
     - address
     - expectedSalesPriceWithoutConcierge
     - status
     - dateRequested
     - dateApproved
     - totalPaymentsRequested
     - totalPaymentsApproved
     - spentAmount
     - agentEmail
     - confirmedListingId
     - knackRecordId
     - listPrice
     - closePrice
     - descriptionOfWork
     - listingInfo
     - remaining
     - listingAddress
     - conciergeClassic
     - approvedBudget
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'count', None, None, ),  # 1
        (2, TType.STRING, 'conciergeProjectId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'conciergeInfo', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'agentName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'address', 'UTF8', None, ),  # 5
        (6, TType.DOUBLE, 'expectedSalesPriceWithoutConcierge', None, None, ),  # 6
        (7, TType.STRING, 'status', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'dateRequested', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'dateApproved', 'UTF8', None, ),  # 9
        (10, TType.DOUBLE, 'totalPaymentsRequested', None, None, ),  # 10
        (11, TType.DOUBLE, 'totalPaymentsApproved', None, None, ),  # 11
        (12, TType.DOUBLE, 'spentAmount', None, None, ),  # 12
        (13, TType.STRING, 'agentEmail', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'confirmedListingId', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'knackRecordId', 'UTF8', None, ),  # 15
        (16, TType.DOUBLE, 'listPrice', None, None, ),  # 16
        (17, TType.DOUBLE, 'closePrice', None, None, ),  # 17
        (18, TType.STRING, 'descriptionOfWork', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'listingInfo', 'UTF8', None, ),  # 19
        (20, TType.DOUBLE, 'remaining', None, None, ),  # 20
        (21, TType.STRING, 'listingAddress', 'UTF8', None, ),  # 21
        (22, TType.BOOL, 'conciergeClassic', None, None, ),  # 22
        (23, TType.DOUBLE, 'approvedBudget', None, None, ),  # 23
    )
    def __init__(self, count=None, conciergeProjectId=None, conciergeInfo=None, agentName=None, address=None, expectedSalesPriceWithoutConcierge=None, status=None, dateRequested=None, dateApproved=None, totalPaymentsRequested=None, totalPaymentsApproved=None, spentAmount=None, agentEmail=None, confirmedListingId=None, knackRecordId=None, listPrice=None, closePrice=None, descriptionOfWork=None, listingInfo=None, remaining=None, listingAddress=None, conciergeClassic=None, approvedBudget=None, ):
        self.count = count
        self.conciergeProjectId = conciergeProjectId
        self.conciergeInfo = conciergeInfo
        self.agentName = agentName
        self.address = address
        self.expectedSalesPriceWithoutConcierge = expectedSalesPriceWithoutConcierge
        self.status = status
        self.dateRequested = dateRequested
        self.dateApproved = dateApproved
        self.totalPaymentsRequested = totalPaymentsRequested
        self.totalPaymentsApproved = totalPaymentsApproved
        self.spentAmount = spentAmount
        self.agentEmail = agentEmail
        self.confirmedListingId = confirmedListingId
        self.knackRecordId = knackRecordId
        self.listPrice = listPrice
        self.closePrice = closePrice
        self.descriptionOfWork = descriptionOfWork
        self.listingInfo = listingInfo
        self.remaining = remaining
        self.listingAddress = listingAddress
        self.conciergeClassic = conciergeClassic
        self.approvedBudget = approvedBudget

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.conciergeProjectId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.conciergeInfo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.expectedSalesPriceWithoutConcierge = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.status = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.dateRequested = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.dateApproved = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.DOUBLE:
                    self.totalPaymentsRequested = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.totalPaymentsApproved = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.DOUBLE:
                    self.spentAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.agentEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.confirmedListingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.knackRecordId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.descriptionOfWork = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.listingInfo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.DOUBLE:
                    self.remaining = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.listingAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.BOOL:
                    self.conciergeClassic = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.DOUBLE:
                    self.approvedBudget = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LensConciergeProjectItem')
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 1)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.conciergeProjectId is not None:
            oprot.writeFieldBegin('conciergeProjectId', TType.STRING, 2)
            oprot.writeString(self.conciergeProjectId.encode('utf-8') if sys.version_info[0] == 2 else self.conciergeProjectId)
            oprot.writeFieldEnd()
        if self.conciergeInfo is not None:
            oprot.writeFieldBegin('conciergeInfo', TType.STRING, 3)
            oprot.writeString(self.conciergeInfo.encode('utf-8') if sys.version_info[0] == 2 else self.conciergeInfo)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 4)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 5)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.expectedSalesPriceWithoutConcierge is not None:
            oprot.writeFieldBegin('expectedSalesPriceWithoutConcierge', TType.DOUBLE, 6)
            oprot.writeDouble(self.expectedSalesPriceWithoutConcierge)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRING, 7)
            oprot.writeString(self.status.encode('utf-8') if sys.version_info[0] == 2 else self.status)
            oprot.writeFieldEnd()
        if self.dateRequested is not None:
            oprot.writeFieldBegin('dateRequested', TType.STRING, 8)
            oprot.writeString(self.dateRequested.encode('utf-8') if sys.version_info[0] == 2 else self.dateRequested)
            oprot.writeFieldEnd()
        if self.dateApproved is not None:
            oprot.writeFieldBegin('dateApproved', TType.STRING, 9)
            oprot.writeString(self.dateApproved.encode('utf-8') if sys.version_info[0] == 2 else self.dateApproved)
            oprot.writeFieldEnd()
        if self.totalPaymentsRequested is not None:
            oprot.writeFieldBegin('totalPaymentsRequested', TType.DOUBLE, 10)
            oprot.writeDouble(self.totalPaymentsRequested)
            oprot.writeFieldEnd()
        if self.totalPaymentsApproved is not None:
            oprot.writeFieldBegin('totalPaymentsApproved', TType.DOUBLE, 11)
            oprot.writeDouble(self.totalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.spentAmount is not None:
            oprot.writeFieldBegin('spentAmount', TType.DOUBLE, 12)
            oprot.writeDouble(self.spentAmount)
            oprot.writeFieldEnd()
        if self.agentEmail is not None:
            oprot.writeFieldBegin('agentEmail', TType.STRING, 13)
            oprot.writeString(self.agentEmail.encode('utf-8') if sys.version_info[0] == 2 else self.agentEmail)
            oprot.writeFieldEnd()
        if self.confirmedListingId is not None:
            oprot.writeFieldBegin('confirmedListingId', TType.STRING, 14)
            oprot.writeString(self.confirmedListingId.encode('utf-8') if sys.version_info[0] == 2 else self.confirmedListingId)
            oprot.writeFieldEnd()
        if self.knackRecordId is not None:
            oprot.writeFieldBegin('knackRecordId', TType.STRING, 15)
            oprot.writeString(self.knackRecordId.encode('utf-8') if sys.version_info[0] == 2 else self.knackRecordId)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 16)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 17)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.descriptionOfWork is not None:
            oprot.writeFieldBegin('descriptionOfWork', TType.STRING, 18)
            oprot.writeString(self.descriptionOfWork.encode('utf-8') if sys.version_info[0] == 2 else self.descriptionOfWork)
            oprot.writeFieldEnd()
        if self.listingInfo is not None:
            oprot.writeFieldBegin('listingInfo', TType.STRING, 19)
            oprot.writeString(self.listingInfo.encode('utf-8') if sys.version_info[0] == 2 else self.listingInfo)
            oprot.writeFieldEnd()
        if self.remaining is not None:
            oprot.writeFieldBegin('remaining', TType.DOUBLE, 20)
            oprot.writeDouble(self.remaining)
            oprot.writeFieldEnd()
        if self.listingAddress is not None:
            oprot.writeFieldBegin('listingAddress', TType.STRING, 21)
            oprot.writeString(self.listingAddress.encode('utf-8') if sys.version_info[0] == 2 else self.listingAddress)
            oprot.writeFieldEnd()
        if self.conciergeClassic is not None:
            oprot.writeFieldBegin('conciergeClassic', TType.BOOL, 22)
            oprot.writeBool(self.conciergeClassic)
            oprot.writeFieldEnd()
        if self.approvedBudget is not None:
            oprot.writeFieldBegin('approvedBudget', TType.DOUBLE, 23)
            oprot.writeDouble(self.approvedBudget)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LensImageItem(object):
    """
    Attributes:
     - imageItemId
     - imageItemType
     - beforeImageUrl
     - afterImageUrl
     - imageSourceType
     - beforeListingIdSha
     - afterListingIdSha
     - listingInfo
     - zipcode
     - price
     - roomType
     - roomTypeScore
     - isConciergeProject
     - isCompassAgentListing
     - geoId
     - extraJson
     - count
     - beforeImageId
     - afterImageId
     - agentName
     - agentEmail
     - totalPaymentsRequested
     - totalPaymentsApproved
     - approvedBudget
     - listPrice
     - closePrice
     - expectedSalesPriceWithoutConcierge
     - descriptionOfWork
     - lensProcessedListing
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'imageItemId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'imageItemType', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'beforeImageUrl', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'afterImageUrl', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'imageSourceType', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'beforeListingIdSha', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'afterListingIdSha', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'listingInfo', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'zipcode', 'UTF8', None, ),  # 9
        (10, TType.DOUBLE, 'price', None, None, ),  # 10
        (11, TType.STRING, 'roomType', 'UTF8', None, ),  # 11
        (12, TType.DOUBLE, 'roomTypeScore', None, None, ),  # 12
        (13, TType.BOOL, 'isConciergeProject', None, None, ),  # 13
        (14, TType.BOOL, 'isCompassAgentListing', None, None, ),  # 14
        (15, TType.STRING, 'geoId', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'extraJson', 'UTF8', None, ),  # 16
        (17, TType.I32, 'count', None, None, ),  # 17
        (18, TType.STRING, 'beforeImageId', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'afterImageId', 'UTF8', None, ),  # 19
        (20, TType.STRING, 'agentName', 'UTF8', None, ),  # 20
        (21, TType.STRING, 'agentEmail', 'UTF8', None, ),  # 21
        (22, TType.DOUBLE, 'totalPaymentsRequested', None, None, ),  # 22
        (23, TType.DOUBLE, 'totalPaymentsApproved', None, None, ),  # 23
        (24, TType.DOUBLE, 'approvedBudget', None, None, ),  # 24
        (25, TType.DOUBLE, 'listPrice', None, None, ),  # 25
        (26, TType.DOUBLE, 'closePrice', None, None, ),  # 26
        (27, TType.DOUBLE, 'expectedSalesPriceWithoutConcierge', None, None, ),  # 27
        (28, TType.STRING, 'descriptionOfWork', 'UTF8', None, ),  # 28
        (29, TType.STRUCT, 'lensProcessedListing', (gen.urbancompass.concierge_lens_v0.lens_processed_listing.ttypes.LensProcessedListing, gen.urbancompass.concierge_lens_v0.lens_processed_listing.ttypes.LensProcessedListing.thrift_spec), None, ),  # 29
    )
    def __init__(self, imageItemId=None, imageItemType=None, beforeImageUrl=None, afterImageUrl=None, imageSourceType=None, beforeListingIdSha=None, afterListingIdSha=None, listingInfo=None, zipcode=None, price=None, roomType=None, roomTypeScore=None, isConciergeProject=None, isCompassAgentListing=None, geoId=None, extraJson=None, count=None, beforeImageId=None, afterImageId=None, agentName=None, agentEmail=None, totalPaymentsRequested=None, totalPaymentsApproved=None, approvedBudget=None, listPrice=None, closePrice=None, expectedSalesPriceWithoutConcierge=None, descriptionOfWork=None, lensProcessedListing=None, ):
        self.imageItemId = imageItemId
        self.imageItemType = imageItemType
        self.beforeImageUrl = beforeImageUrl
        self.afterImageUrl = afterImageUrl
        self.imageSourceType = imageSourceType
        self.beforeListingIdSha = beforeListingIdSha
        self.afterListingIdSha = afterListingIdSha
        self.listingInfo = listingInfo
        self.zipcode = zipcode
        self.price = price
        self.roomType = roomType
        self.roomTypeScore = roomTypeScore
        self.isConciergeProject = isConciergeProject
        self.isCompassAgentListing = isCompassAgentListing
        self.geoId = geoId
        self.extraJson = extraJson
        self.count = count
        self.beforeImageId = beforeImageId
        self.afterImageId = afterImageId
        self.agentName = agentName
        self.agentEmail = agentEmail
        self.totalPaymentsRequested = totalPaymentsRequested
        self.totalPaymentsApproved = totalPaymentsApproved
        self.approvedBudget = approvedBudget
        self.listPrice = listPrice
        self.closePrice = closePrice
        self.expectedSalesPriceWithoutConcierge = expectedSalesPriceWithoutConcierge
        self.descriptionOfWork = descriptionOfWork
        self.lensProcessedListing = lensProcessedListing

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.imageItemId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.imageItemType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.beforeImageUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.afterImageUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.imageSourceType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.beforeListingIdSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.afterListingIdSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.listingInfo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.zipcode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.DOUBLE:
                    self.price = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.roomType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.DOUBLE:
                    self.roomTypeScore = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isConciergeProject = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.isCompassAgentListing = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.extraJson = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.beforeImageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.afterImageId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRING:
                    self.agentName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.agentEmail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.DOUBLE:
                    self.totalPaymentsRequested = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.DOUBLE:
                    self.totalPaymentsApproved = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.DOUBLE:
                    self.approvedBudget = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.DOUBLE:
                    self.listPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.DOUBLE:
                    self.closePrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.DOUBLE:
                    self.expectedSalesPriceWithoutConcierge = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.descriptionOfWork = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRUCT:
                    self.lensProcessedListing = gen.urbancompass.concierge_lens_v0.lens_processed_listing.ttypes.LensProcessedListing()
                    self.lensProcessedListing.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LensImageItem')
        if self.imageItemId is not None:
            oprot.writeFieldBegin('imageItemId', TType.STRING, 1)
            oprot.writeString(self.imageItemId.encode('utf-8') if sys.version_info[0] == 2 else self.imageItemId)
            oprot.writeFieldEnd()
        if self.imageItemType is not None:
            oprot.writeFieldBegin('imageItemType', TType.STRING, 2)
            oprot.writeString(self.imageItemType.encode('utf-8') if sys.version_info[0] == 2 else self.imageItemType)
            oprot.writeFieldEnd()
        if self.beforeImageUrl is not None:
            oprot.writeFieldBegin('beforeImageUrl', TType.STRING, 3)
            oprot.writeString(self.beforeImageUrl.encode('utf-8') if sys.version_info[0] == 2 else self.beforeImageUrl)
            oprot.writeFieldEnd()
        if self.afterImageUrl is not None:
            oprot.writeFieldBegin('afterImageUrl', TType.STRING, 4)
            oprot.writeString(self.afterImageUrl.encode('utf-8') if sys.version_info[0] == 2 else self.afterImageUrl)
            oprot.writeFieldEnd()
        if self.imageSourceType is not None:
            oprot.writeFieldBegin('imageSourceType', TType.STRING, 5)
            oprot.writeString(self.imageSourceType.encode('utf-8') if sys.version_info[0] == 2 else self.imageSourceType)
            oprot.writeFieldEnd()
        if self.beforeListingIdSha is not None:
            oprot.writeFieldBegin('beforeListingIdSha', TType.STRING, 6)
            oprot.writeString(self.beforeListingIdSha.encode('utf-8') if sys.version_info[0] == 2 else self.beforeListingIdSha)
            oprot.writeFieldEnd()
        if self.afterListingIdSha is not None:
            oprot.writeFieldBegin('afterListingIdSha', TType.STRING, 7)
            oprot.writeString(self.afterListingIdSha.encode('utf-8') if sys.version_info[0] == 2 else self.afterListingIdSha)
            oprot.writeFieldEnd()
        if self.listingInfo is not None:
            oprot.writeFieldBegin('listingInfo', TType.STRING, 8)
            oprot.writeString(self.listingInfo.encode('utf-8') if sys.version_info[0] == 2 else self.listingInfo)
            oprot.writeFieldEnd()
        if self.zipcode is not None:
            oprot.writeFieldBegin('zipcode', TType.STRING, 9)
            oprot.writeString(self.zipcode.encode('utf-8') if sys.version_info[0] == 2 else self.zipcode)
            oprot.writeFieldEnd()
        if self.price is not None:
            oprot.writeFieldBegin('price', TType.DOUBLE, 10)
            oprot.writeDouble(self.price)
            oprot.writeFieldEnd()
        if self.roomType is not None:
            oprot.writeFieldBegin('roomType', TType.STRING, 11)
            oprot.writeString(self.roomType.encode('utf-8') if sys.version_info[0] == 2 else self.roomType)
            oprot.writeFieldEnd()
        if self.roomTypeScore is not None:
            oprot.writeFieldBegin('roomTypeScore', TType.DOUBLE, 12)
            oprot.writeDouble(self.roomTypeScore)
            oprot.writeFieldEnd()
        if self.isConciergeProject is not None:
            oprot.writeFieldBegin('isConciergeProject', TType.BOOL, 13)
            oprot.writeBool(self.isConciergeProject)
            oprot.writeFieldEnd()
        if self.isCompassAgentListing is not None:
            oprot.writeFieldBegin('isCompassAgentListing', TType.BOOL, 14)
            oprot.writeBool(self.isCompassAgentListing)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 15)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.extraJson is not None:
            oprot.writeFieldBegin('extraJson', TType.STRING, 16)
            oprot.writeString(self.extraJson.encode('utf-8') if sys.version_info[0] == 2 else self.extraJson)
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 17)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.beforeImageId is not None:
            oprot.writeFieldBegin('beforeImageId', TType.STRING, 18)
            oprot.writeString(self.beforeImageId.encode('utf-8') if sys.version_info[0] == 2 else self.beforeImageId)
            oprot.writeFieldEnd()
        if self.afterImageId is not None:
            oprot.writeFieldBegin('afterImageId', TType.STRING, 19)
            oprot.writeString(self.afterImageId.encode('utf-8') if sys.version_info[0] == 2 else self.afterImageId)
            oprot.writeFieldEnd()
        if self.agentName is not None:
            oprot.writeFieldBegin('agentName', TType.STRING, 20)
            oprot.writeString(self.agentName.encode('utf-8') if sys.version_info[0] == 2 else self.agentName)
            oprot.writeFieldEnd()
        if self.agentEmail is not None:
            oprot.writeFieldBegin('agentEmail', TType.STRING, 21)
            oprot.writeString(self.agentEmail.encode('utf-8') if sys.version_info[0] == 2 else self.agentEmail)
            oprot.writeFieldEnd()
        if self.totalPaymentsRequested is not None:
            oprot.writeFieldBegin('totalPaymentsRequested', TType.DOUBLE, 22)
            oprot.writeDouble(self.totalPaymentsRequested)
            oprot.writeFieldEnd()
        if self.totalPaymentsApproved is not None:
            oprot.writeFieldBegin('totalPaymentsApproved', TType.DOUBLE, 23)
            oprot.writeDouble(self.totalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.approvedBudget is not None:
            oprot.writeFieldBegin('approvedBudget', TType.DOUBLE, 24)
            oprot.writeDouble(self.approvedBudget)
            oprot.writeFieldEnd()
        if self.listPrice is not None:
            oprot.writeFieldBegin('listPrice', TType.DOUBLE, 25)
            oprot.writeDouble(self.listPrice)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.DOUBLE, 26)
            oprot.writeDouble(self.closePrice)
            oprot.writeFieldEnd()
        if self.expectedSalesPriceWithoutConcierge is not None:
            oprot.writeFieldBegin('expectedSalesPriceWithoutConcierge', TType.DOUBLE, 27)
            oprot.writeDouble(self.expectedSalesPriceWithoutConcierge)
            oprot.writeFieldEnd()
        if self.descriptionOfWork is not None:
            oprot.writeFieldBegin('descriptionOfWork', TType.STRING, 28)
            oprot.writeString(self.descriptionOfWork.encode('utf-8') if sys.version_info[0] == 2 else self.descriptionOfWork)
            oprot.writeFieldEnd()
        if self.lensProcessedListing is not None:
            oprot.writeFieldBegin('lensProcessedListing', TType.STRUCT, 29)
            self.lensProcessedListing.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchImageRequest(object):
    """
    Attributes:
     - userId
     - transactionId
     - minPrice
     - maxPrice
     - zipcodes
     - roomtypes
     - geoId
     - extraFilterJson
     - recordNum
     - conciergeProjectImageItemTypes
     - isConciergeProjectOnly
     - isCompassAgentListingOnly
     - agentOpinionPriceMinRatio
     - agentOpinionPriceMaxRatio
     - hasAgentOpinionPrice
     - hasTotalPaymentsApproved
     - minTotalPaymentsApproved
     - maxTotalPaymentsApproved
     - isUserFavoriteImageOnly
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'transactionId', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'minPrice', None, None, ),  # 3
        (4, TType.DOUBLE, 'maxPrice', None, None, ),  # 4
        (5, TType.LIST, 'zipcodes', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.LIST, 'roomtypes', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.STRING, 'geoId', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'extraFilterJson', 'UTF8', None, ),  # 8
        (9, TType.I32, 'recordNum', None, None, ),  # 9
        (10, TType.LIST, 'conciergeProjectImageItemTypes', (TType.STRING, 'UTF8', False), None, ),  # 10
        (11, TType.BOOL, 'isConciergeProjectOnly', None, None, ),  # 11
        (12, TType.BOOL, 'isCompassAgentListingOnly', None, None, ),  # 12
        (13, TType.DOUBLE, 'agentOpinionPriceMinRatio', None, None, ),  # 13
        (14, TType.DOUBLE, 'agentOpinionPriceMaxRatio', None, None, ),  # 14
        (15, TType.BOOL, 'hasAgentOpinionPrice', None, None, ),  # 15
        (16, TType.BOOL, 'hasTotalPaymentsApproved', None, None, ),  # 16
        (17, TType.DOUBLE, 'minTotalPaymentsApproved', None, None, ),  # 17
        (18, TType.DOUBLE, 'maxTotalPaymentsApproved', None, None, ),  # 18
        (19, TType.BOOL, 'isUserFavoriteImageOnly', None, None, ),  # 19
    )
    def __init__(self, userId=None, transactionId=None, minPrice=None, maxPrice=None, zipcodes=None, roomtypes=None, geoId=None, extraFilterJson=None, recordNum=None, conciergeProjectImageItemTypes=None, isConciergeProjectOnly=None, isCompassAgentListingOnly=None, agentOpinionPriceMinRatio=None, agentOpinionPriceMaxRatio=None, hasAgentOpinionPrice=None, hasTotalPaymentsApproved=None, minTotalPaymentsApproved=None, maxTotalPaymentsApproved=None, isUserFavoriteImageOnly=None, ):
        self.userId = userId
        self.transactionId = transactionId
        self.minPrice = minPrice
        self.maxPrice = maxPrice
        self.zipcodes = zipcodes
        self.roomtypes = roomtypes
        self.geoId = geoId
        self.extraFilterJson = extraFilterJson
        self.recordNum = recordNum
        self.conciergeProjectImageItemTypes = conciergeProjectImageItemTypes
        self.isConciergeProjectOnly = isConciergeProjectOnly
        self.isCompassAgentListingOnly = isCompassAgentListingOnly
        self.agentOpinionPriceMinRatio = agentOpinionPriceMinRatio
        self.agentOpinionPriceMaxRatio = agentOpinionPriceMaxRatio
        self.hasAgentOpinionPrice = hasAgentOpinionPrice
        self.hasTotalPaymentsApproved = hasTotalPaymentsApproved
        self.minTotalPaymentsApproved = minTotalPaymentsApproved
        self.maxTotalPaymentsApproved = maxTotalPaymentsApproved
        self.isUserFavoriteImageOnly = isUserFavoriteImageOnly

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.transactionId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.minPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.maxPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.zipcodes = []
                    (_etype42, _size45) = iprot.readListBegin()
                    for _i43 in range(_size45):
                        _elem44 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.zipcodes.append(_elem44)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.roomtypes = []
                    (_etype46, _size49) = iprot.readListBegin()
                    for _i47 in range(_size49):
                        _elem48 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.roomtypes.append(_elem48)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.extraFilterJson = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.recordNum = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.conciergeProjectImageItemTypes = []
                    (_etype50, _size53) = iprot.readListBegin()
                    for _i51 in range(_size53):
                        _elem52 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.conciergeProjectImageItemTypes.append(_elem52)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.isConciergeProjectOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.BOOL:
                    self.isCompassAgentListingOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.DOUBLE:
                    self.agentOpinionPriceMinRatio = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.agentOpinionPriceMaxRatio = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.BOOL:
                    self.hasAgentOpinionPrice = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.hasTotalPaymentsApproved = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.DOUBLE:
                    self.minTotalPaymentsApproved = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.DOUBLE:
                    self.maxTotalPaymentsApproved = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.BOOL:
                    self.isUserFavoriteImageOnly = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchImageRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.transactionId is not None:
            oprot.writeFieldBegin('transactionId', TType.STRING, 2)
            oprot.writeString(self.transactionId.encode('utf-8') if sys.version_info[0] == 2 else self.transactionId)
            oprot.writeFieldEnd()
        if self.minPrice is not None:
            oprot.writeFieldBegin('minPrice', TType.DOUBLE, 3)
            oprot.writeDouble(self.minPrice)
            oprot.writeFieldEnd()
        if self.maxPrice is not None:
            oprot.writeFieldBegin('maxPrice', TType.DOUBLE, 4)
            oprot.writeDouble(self.maxPrice)
            oprot.writeFieldEnd()
        if self.zipcodes is not None:
            oprot.writeFieldBegin('zipcodes', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.zipcodes))
            for _iter54 in self.zipcodes:
                oprot.writeString(_iter54.encode('utf-8') if sys.version_info[0] == 2 else _iter54)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.roomtypes is not None:
            oprot.writeFieldBegin('roomtypes', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.roomtypes))
            for _iter55 in self.roomtypes:
                oprot.writeString(_iter55.encode('utf-8') if sys.version_info[0] == 2 else _iter55)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 7)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.extraFilterJson is not None:
            oprot.writeFieldBegin('extraFilterJson', TType.STRING, 8)
            oprot.writeString(self.extraFilterJson.encode('utf-8') if sys.version_info[0] == 2 else self.extraFilterJson)
            oprot.writeFieldEnd()
        if self.recordNum is not None:
            oprot.writeFieldBegin('recordNum', TType.I32, 9)
            oprot.writeI32(self.recordNum)
            oprot.writeFieldEnd()
        if self.conciergeProjectImageItemTypes is not None:
            oprot.writeFieldBegin('conciergeProjectImageItemTypes', TType.LIST, 10)
            oprot.writeListBegin(TType.STRING, len(self.conciergeProjectImageItemTypes))
            for _iter56 in self.conciergeProjectImageItemTypes:
                oprot.writeString(_iter56.encode('utf-8') if sys.version_info[0] == 2 else _iter56)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isConciergeProjectOnly is not None:
            oprot.writeFieldBegin('isConciergeProjectOnly', TType.BOOL, 11)
            oprot.writeBool(self.isConciergeProjectOnly)
            oprot.writeFieldEnd()
        if self.isCompassAgentListingOnly is not None:
            oprot.writeFieldBegin('isCompassAgentListingOnly', TType.BOOL, 12)
            oprot.writeBool(self.isCompassAgentListingOnly)
            oprot.writeFieldEnd()
        if self.agentOpinionPriceMinRatio is not None:
            oprot.writeFieldBegin('agentOpinionPriceMinRatio', TType.DOUBLE, 13)
            oprot.writeDouble(self.agentOpinionPriceMinRatio)
            oprot.writeFieldEnd()
        if self.agentOpinionPriceMaxRatio is not None:
            oprot.writeFieldBegin('agentOpinionPriceMaxRatio', TType.DOUBLE, 14)
            oprot.writeDouble(self.agentOpinionPriceMaxRatio)
            oprot.writeFieldEnd()
        if self.hasAgentOpinionPrice is not None:
            oprot.writeFieldBegin('hasAgentOpinionPrice', TType.BOOL, 15)
            oprot.writeBool(self.hasAgentOpinionPrice)
            oprot.writeFieldEnd()
        if self.hasTotalPaymentsApproved is not None:
            oprot.writeFieldBegin('hasTotalPaymentsApproved', TType.BOOL, 16)
            oprot.writeBool(self.hasTotalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.minTotalPaymentsApproved is not None:
            oprot.writeFieldBegin('minTotalPaymentsApproved', TType.DOUBLE, 17)
            oprot.writeDouble(self.minTotalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.maxTotalPaymentsApproved is not None:
            oprot.writeFieldBegin('maxTotalPaymentsApproved', TType.DOUBLE, 18)
            oprot.writeDouble(self.maxTotalPaymentsApproved)
            oprot.writeFieldEnd()
        if self.isUserFavoriteImageOnly is not None:
            oprot.writeFieldBegin('isUserFavoriteImageOnly', TType.BOOL, 19)
            oprot.writeBool(self.isUserFavoriteImageOnly)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ServiceModelResponse(object):
    """
    Attributes:
     - valid
     - roomType
     - roomTypeScore
     - embedding
     - url
    """

    thrift_spec = (
        None,  # 0
        (1, TType.BOOL, 'valid', None, None, ),  # 1
        (2, TType.STRING, 'roomType', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'roomTypeScore', None, None, ),  # 3
        (4, TType.LIST, 'embedding', (TType.DOUBLE, None, False), None, ),  # 4
        (5, TType.STRING, 'url', 'UTF8', None, ),  # 5
    )
    def __init__(self, valid=None, roomType=None, roomTypeScore=None, embedding=None, url=None, ):
        self.valid = valid
        self.roomType = roomType
        self.roomTypeScore = roomTypeScore
        self.embedding = embedding
        self.url = url

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.BOOL:
                    self.valid = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.roomType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.roomTypeScore = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.embedding = []
                    (_etype57, _size60) = iprot.readListBegin()
                    for _i58 in range(_size60):
                        _elem59 = iprot.readDouble()
                        self.embedding.append(_elem59)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ServiceModelResponse')
        if self.valid is not None:
            oprot.writeFieldBegin('valid', TType.BOOL, 1)
            oprot.writeBool(self.valid)
            oprot.writeFieldEnd()
        if self.roomType is not None:
            oprot.writeFieldBegin('roomType', TType.STRING, 2)
            oprot.writeString(self.roomType.encode('utf-8') if sys.version_info[0] == 2 else self.roomType)
            oprot.writeFieldEnd()
        if self.roomTypeScore is not None:
            oprot.writeFieldBegin('roomTypeScore', TType.DOUBLE, 3)
            oprot.writeDouble(self.roomTypeScore)
            oprot.writeFieldEnd()
        if self.embedding is not None:
            oprot.writeFieldBegin('embedding', TType.LIST, 4)
            oprot.writeListBegin(TType.DOUBLE, len(self.embedding))
            for _iter61 in self.embedding:
                oprot.writeDouble(_iter61)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 5)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetConciergeProjectResponse(object):
    """
    Attributes:
     - status
     - conciergeProjectItems
     - totalNum
     - projectStatus
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'conciergeProjectItems', (TType.STRUCT, (LensConciergeProjectItem, LensConciergeProjectItem.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'totalNum', None, None, ),  # 3
        (4, TType.I32, 'projectStatus', None, None, ),  # 4
    )
    def __init__(self, status=None, conciergeProjectItems=None, totalNum=None, projectStatus=None, ):
        self.status = status
        self.conciergeProjectItems = conciergeProjectItems
        self.totalNum = totalNum
        self.projectStatus = projectStatus

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.conciergeProjectItems = []
                    (_etype62, _size65) = iprot.readListBegin()
                    for _i63 in range(_size65):
                        _elem64 = LensConciergeProjectItem()
                        _elem64.read(iprot)
                        self.conciergeProjectItems.append(_elem64)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.totalNum = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.projectStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetConciergeProjectResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.conciergeProjectItems is not None:
            oprot.writeFieldBegin('conciergeProjectItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.conciergeProjectItems))
            for _iter66 in self.conciergeProjectItems:
                _iter66.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.totalNum is not None:
            oprot.writeFieldBegin('totalNum', TType.I32, 3)
            oprot.writeI32(self.totalNum)
            oprot.writeFieldEnd()
        if self.projectStatus is not None:
            oprot.writeFieldBegin('projectStatus', TType.I32, 4)
            oprot.writeI32(self.projectStatus)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetImageFeedResponse(object):
    """
    Attributes:
     - status
     - richImageItems
     - extraResponseJson
     - userFavoredImages
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'richImageItems', (TType.STRUCT, (LensImageItem, LensImageItem.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'extraResponseJson', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'userFavoredImages', (TType.STRING, 'UTF8', False), None, ),  # 4
    )
    def __init__(self, status=None, richImageItems=None, extraResponseJson=None, userFavoredImages=None, ):
        self.status = status
        self.richImageItems = richImageItems
        self.extraResponseJson = extraResponseJson
        self.userFavoredImages = userFavoredImages

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.richImageItems = []
                    (_etype67, _size70) = iprot.readListBegin()
                    for _i68 in range(_size70):
                        _elem69 = LensImageItem()
                        _elem69.read(iprot)
                        self.richImageItems.append(_elem69)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.extraResponseJson = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.userFavoredImages = []
                    (_etype71, _size74) = iprot.readListBegin()
                    for _i72 in range(_size74):
                        _elem73 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userFavoredImages.append(_elem73)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetImageFeedResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.richImageItems is not None:
            oprot.writeFieldBegin('richImageItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.richImageItems))
            for _iter75 in self.richImageItems:
                _iter75.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.extraResponseJson is not None:
            oprot.writeFieldBegin('extraResponseJson', TType.STRING, 3)
            oprot.writeString(self.extraResponseJson.encode('utf-8') if sys.version_info[0] == 2 else self.extraResponseJson)
            oprot.writeFieldEnd()
        if self.userFavoredImages is not None:
            oprot.writeFieldBegin('userFavoredImages', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.userFavoredImages))
            for _iter76 in self.userFavoredImages:
                oprot.writeString(_iter76.encode('utf-8') if sys.version_info[0] == 2 else _iter76)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ImageBatchSearchData(object):
    """
    Attributes:
     - distances
     - lensImageItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'distances', (TType.DOUBLE, None, False), None, ),  # 1
        (2, TType.LIST, 'lensImageItems', (TType.STRUCT, (LensImageItem, LensImageItem.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, distances=None, lensImageItems=None, ):
        self.distances = distances
        self.lensImageItems = lensImageItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.distances = []
                    (_etype77, _size80) = iprot.readListBegin()
                    for _i78 in range(_size80):
                        _elem79 = iprot.readDouble()
                        self.distances.append(_elem79)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.lensImageItems = []
                    (_etype81, _size84) = iprot.readListBegin()
                    for _i82 in range(_size84):
                        _elem83 = LensImageItem()
                        _elem83.read(iprot)
                        self.lensImageItems.append(_elem83)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ImageBatchSearchData')
        if self.distances is not None:
            oprot.writeFieldBegin('distances', TType.LIST, 1)
            oprot.writeListBegin(TType.DOUBLE, len(self.distances))
            for _iter85 in self.distances:
                oprot.writeDouble(_iter85)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lensImageItems is not None:
            oprot.writeFieldBegin('lensImageItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.lensImageItems))
            for _iter86 in self.lensImageItems:
                _iter86.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchImageByUrlsRequest(object):
    """
    Attributes:
     - imageUrlList
     - recordNum
     - filter
     - excludeSampleImages
     - enableFallback
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'imageUrlList', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.I32, 'recordNum', None, None, ),  # 2
        (3, TType.STRUCT, 'filter', (Filter, Filter.thrift_spec), None, ),  # 3
        (4, TType.BOOL, 'excludeSampleImages', None, None, ),  # 4
        (5, TType.BOOL, 'enableFallback', None, None, ),  # 5
    )
    def __init__(self, imageUrlList=None, recordNum=None, filter=None, excludeSampleImages=None, enableFallback=None, ):
        self.imageUrlList = imageUrlList
        self.recordNum = recordNum
        self.filter = filter
        self.excludeSampleImages = excludeSampleImages
        self.enableFallback = enableFallback

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.imageUrlList = []
                    (_etype87, _size90) = iprot.readListBegin()
                    for _i88 in range(_size90):
                        _elem89 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.imageUrlList.append(_elem89)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.recordNum = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.filter = Filter()
                    self.filter.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.excludeSampleImages = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.enableFallback = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchImageByUrlsRequest')
        if self.imageUrlList is not None:
            oprot.writeFieldBegin('imageUrlList', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.imageUrlList))
            for _iter91 in self.imageUrlList:
                oprot.writeString(_iter91.encode('utf-8') if sys.version_info[0] == 2 else _iter91)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.recordNum is not None:
            oprot.writeFieldBegin('recordNum', TType.I32, 2)
            oprot.writeI32(self.recordNum)
            oprot.writeFieldEnd()
        if self.filter is not None:
            oprot.writeFieldBegin('filter', TType.STRUCT, 3)
            self.filter.write(oprot)
            oprot.writeFieldEnd()
        if self.excludeSampleImages is not None:
            oprot.writeFieldBegin('excludeSampleImages', TType.BOOL, 4)
            oprot.writeBool(self.excludeSampleImages)
            oprot.writeFieldEnd()
        if self.enableFallback is not None:
            oprot.writeFieldBegin('enableFallback', TType.BOOL, 5)
            oprot.writeBool(self.enableFallback)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchImageByUrlsResponse(object):
    """
    Attributes:
     - status
     - richImageItems
     - strForDebug
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'richImageItems', (TType.STRUCT, (LensImageItem, LensImageItem.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'strForDebug', 'UTF8', None, ),  # 3
    )
    def __init__(self, status=None, richImageItems=None, strForDebug=None, ):
        self.status = status
        self.richImageItems = richImageItems
        self.strForDebug = strForDebug

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.richImageItems = []
                    (_etype92, _size95) = iprot.readListBegin()
                    for _i93 in range(_size95):
                        _elem94 = LensImageItem()
                        _elem94.read(iprot)
                        self.richImageItems.append(_elem94)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.strForDebug = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchImageByUrlsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.richImageItems is not None:
            oprot.writeFieldBegin('richImageItems', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.richImageItems))
            for _iter96 in self.richImageItems:
                _iter96.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.strForDebug is not None:
            oprot.writeFieldBegin('strForDebug', TType.STRING, 3)
            oprot.writeString(self.strForDebug.encode('utf-8') if sys.version_info[0] == 2 else self.strForDebug)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SearchImageResponse(object):
    """
    Attributes:
     - status
     - result
     - richImageItems
     - distances
     - userFavoredImages
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'result', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'richImageItems', (TType.STRUCT, (LensImageItem, LensImageItem.thrift_spec), False), None, ),  # 3
        (4, TType.LIST, 'distances', (TType.DOUBLE, None, False), None, ),  # 4
        (5, TType.LIST, 'userFavoredImages', (TType.STRING, 'UTF8', False), None, ),  # 5
    )
    def __init__(self, status=None, result=None, richImageItems=None, distances=None, userFavoredImages=None, ):
        self.status = status
        self.result = result
        self.richImageItems = richImageItems
        self.distances = distances
        self.userFavoredImages = userFavoredImages

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.result = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.richImageItems = []
                    (_etype97, _size100) = iprot.readListBegin()
                    for _i98 in range(_size100):
                        _elem99 = LensImageItem()
                        _elem99.read(iprot)
                        self.richImageItems.append(_elem99)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.distances = []
                    (_etype101, _size104) = iprot.readListBegin()
                    for _i102 in range(_size104):
                        _elem103 = iprot.readDouble()
                        self.distances.append(_elem103)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.userFavoredImages = []
                    (_etype105, _size108) = iprot.readListBegin()
                    for _i106 in range(_size108):
                        _elem107 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userFavoredImages.append(_elem107)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SearchImageResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.result is not None:
            oprot.writeFieldBegin('result', TType.STRING, 2)
            oprot.writeString(self.result.encode('utf-8') if sys.version_info[0] == 2 else self.result)
            oprot.writeFieldEnd()
        if self.richImageItems is not None:
            oprot.writeFieldBegin('richImageItems', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.richImageItems))
            for _iter109 in self.richImageItems:
                _iter109.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.distances is not None:
            oprot.writeFieldBegin('distances', TType.LIST, 4)
            oprot.writeListBegin(TType.DOUBLE, len(self.distances))
            for _iter110 in self.distances:
                oprot.writeDouble(_iter110)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.userFavoredImages is not None:
            oprot.writeFieldBegin('userFavoredImages', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.userFavoredImages))
            for _iter111 in self.userFavoredImages:
                oprot.writeString(_iter111.encode('utf-8') if sys.version_info[0] == 2 else _iter111)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
