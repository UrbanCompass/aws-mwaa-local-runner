# -*- coding: utf-8 -*-
"""
Client Internal Token interceptor

:copyright: (c) 2021 by UrbanCompass, Inc.
"""
import grpc
from grpc._interceptor import _ClientCallDetails

from uc.base.uc_logging import get_internal_token
from gen.urbancompass.common.base.constants import INTERNAL_TOKEN_KEY


class ClientInternalTokenInterceptor(grpc.UnaryUnaryClientInterceptor):
    def intercept_unary_unary(self, continuation, client_call_details, request):
        metadata = {}
        if client_call_details.metadata is not None:
            metadata = dict(client_call_details.metadata)
        internal_token = get_internal_token()
        if internal_token is not None:
            metadata[INTERNAL_TOKEN_KEY] = internal_token
        client_call_details = _ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            metadata.items(),
            client_call_details.credentials,
            client_call_details.wait_for_ready,
            client_call_details.compression,
        )
        response = continuation(client_call_details, request)
        return response
