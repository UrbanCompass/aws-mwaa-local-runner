
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.valuation.ai_valuation.adjustments.ttypes
import gen.urbancompass.apex.apex_service.ttypes
import gen.urbancompass.asset_library.asset_library_models.ttypes
import gen.urbancompass.concierge_lens_v0.service.ttypes
import gen.urbancompass.contacts.api.contact.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.listing.listing_status.ttypes
import gen.urbancompass.people.api.person.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes
import gen.urbancompass.search.search.ttypes
import gen.urbancompass.trend_chart.trend_chart_service.ttypes

from thrift.transport import TTransport


class CmaOutputSection(object):
    UNDEFINED = 0
    COVER = 1
    SUBJECT_DETAILS = 2
    MAP = 3
    SIDE_BY_SIDE_COMPARISON = 4
    STATUS_COMPARISON = 5
    CHARTS_PRICE_VS_SQFT = 6
    CHARTS_PRICE_VS_DOM = 7
    CHARTS_LISTING_AVERAGES = 8
    ESTIMATE = 9
    UPGRADE_SUGGESTIONS = 10
    CONTACT = 11
    CUSTOM_PDF = 12
    MARKET_TREND_REPORT = 13
    NETSHEETS = 14

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "COVER",
        2: "SUBJECT_DETAILS",
        3: "MAP",
        4: "SIDE_BY_SIDE_COMPARISON",
        5: "STATUS_COMPARISON",
        6: "CHARTS_PRICE_VS_SQFT",
        7: "CHARTS_PRICE_VS_DOM",
        8: "CHARTS_LISTING_AVERAGES",
        9: "ESTIMATE",
        10: "UPGRADE_SUGGESTIONS",
        11: "CONTACT",
        12: "CUSTOM_PDF",
        13: "MARKET_TREND_REPORT",
        14: "NETSHEETS",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "COVER": 1,
        "SUBJECT_DETAILS": 2,
        "MAP": 3,
        "SIDE_BY_SIDE_COMPARISON": 4,
        "STATUS_COMPARISON": 5,
        "CHARTS_PRICE_VS_SQFT": 6,
        "CHARTS_PRICE_VS_DOM": 7,
        "CHARTS_LISTING_AVERAGES": 8,
        "ESTIMATE": 9,
        "UPGRADE_SUGGESTIONS": 10,
        "CONTACT": 11,
        "CUSTOM_PDF": 12,
        "MARKET_TREND_REPORT": 13,
        "NETSHEETS": 14,
    }


class CmaSource(object):
    CMAHUB = 0
    SEARCH = 1
    LISTING = 2
    CRM = 3
    MC = 4
    BT = 5
    COLLECTIONS = 6

    _VALUES_TO_NAMES = {
        0: "CMAHUB",
        1: "SEARCH",
        2: "LISTING",
        3: "CRM",
        4: "MC",
        5: "BT",
        6: "COLLECTIONS",
    }

    _NAMES_TO_VALUES = {
        "CMAHUB": 0,
        "SEARCH": 1,
        "LISTING": 2,
        "CRM": 3,
        "MC": 4,
        "BT": 5,
        "COLLECTIONS": 6,
    }


class CmaState(object):
    UNDEFINED = 0
    CREATED = 1
    PUBLISHING = 2
    PUBLISHED = 3
    PUBLISHING_FAILED = 4
    DELETED = 5
    INSTANTIATED = 6

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "CREATED",
        2: "PUBLISHING",
        3: "PUBLISHED",
        4: "PUBLISHING_FAILED",
        5: "DELETED",
        6: "INSTANTIATED",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "CREATED": 1,
        "PUBLISHING": 2,
        "PUBLISHED": 3,
        "PUBLISHING_FAILED": 4,
        "DELETED": 5,
        "INSTANTIATED": 6,
    }


class CompsOrder(object):
    UNDEFINED = 0
    MANUAL = 1
    STATUS = 2
    SALE_STATUS = 3

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "MANUAL",
        2: "STATUS",
        3: "SALE_STATUS",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "MANUAL": 1,
        "STATUS": 2,
        "SALE_STATUS": 3,
    }


class Fetcher(object):
    UNDEFINED = 0
    PEOPLE_SERVICE = 1
    LISTING_TRANSLATION_SERVICE = 2
    REKOGNITION_PLATFORM_SERVICE = 3
    MARKET_ANALYSIS_SERVICE = 4

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "PEOPLE_SERVICE",
        2: "LISTING_TRANSLATION_SERVICE",
        3: "REKOGNITION_PLATFORM_SERVICE",
        4: "MARKET_ANALYSIS_SERVICE",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "PEOPLE_SERVICE": 1,
        "LISTING_TRANSLATION_SERVICE": 2,
        "REKOGNITION_PLATFORM_SERVICE": 3,
        "MARKET_ANALYSIS_SERVICE": 4,
    }


class FileStatus(object):
    UNDEFINED = 0
    CREATING = 1
    CREATED = 2
    FAILED = 3

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "CREATING",
        2: "CREATED",
        3: "FAILED",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "CREATING": 1,
        "CREATED": 2,
        "FAILED": 3,
    }


class LotSizeUnit(object):
    UNDEFINED = 0
    SQFT = 1
    ACRES = 2

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "SQFT",
        2: "ACRES",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "SQFT": 1,
        "ACRES": 2,
    }


class PriceEstimateSources(object):
    UNDEFINED = 0
    AGENT_ADJUSTMENTS = 1
    AI_ADJUSTMENTS = 2
    AI_VALUATION = 3
    PROPERTY_DATA_AVM = 4
    CMA_COMPASS_VALUATION = 5

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "AGENT_ADJUSTMENTS",
        2: "AI_ADJUSTMENTS",
        3: "AI_VALUATION",
        4: "PROPERTY_DATA_AVM",
        5: "CMA_COMPASS_VALUATION",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "AGENT_ADJUSTMENTS": 1,
        "AI_ADJUSTMENTS": 2,
        "AI_VALUATION": 3,
        "PROPERTY_DATA_AVM": 4,
        "CMA_COMPASS_VALUATION": 5,
    }


class PriceType(object):
    UNDEFINED = 0
    EXACT = 1
    RANGE = 2
    EXCLUDED = 3

    _VALUES_TO_NAMES = {
        0: "UNDEFINED",
        1: "EXACT",
        2: "RANGE",
        3: "EXCLUDED",
    }

    _NAMES_TO_VALUES = {
        "UNDEFINED": 0,
        "EXACT": 1,
        "RANGE": 2,
        "EXCLUDED": 3,
    }


class AIInputs(object):
    """
    Attributes:
     - recommendedAdjustments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'recommendedAdjustments', (TType.STRING, 'UTF8', TType.LIST, (TType.STRUCT, (gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.Adjustment, gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.Adjustment.thrift_spec), False), False), None, ),  # 1
    )
    def __init__(self, recommendedAdjustments=None, ):
        self.recommendedAdjustments = recommendedAdjustments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.recommendedAdjustments = {}
                    (_ktype3, _vtype4, _size7) = iprot.readMapBegin()
                    for _i2 in range(_size7):
                        _key5 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val6 = []
                        (_etype8, _size11) = iprot.readListBegin()
                        for _i9 in range(_size11):
                            _elem10 = gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.Adjustment()
                            _elem10.read(iprot)
                            _val6.append(_elem10)
                        iprot.readListEnd()
                        self.recommendedAdjustments[_key5] = _val6
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AIInputs')
        if self.recommendedAdjustments is not None:
            oprot.writeFieldBegin('recommendedAdjustments', TType.MAP, 1)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.recommendedAdjustments))
            for _kiter12, _viter13 in self.recommendedAdjustments.items():
                oprot.writeString(_kiter12.encode('utf-8') if sys.version_info[0] == 2 else _kiter12)
                oprot.writeListBegin(TType.STRUCT, len(_viter13))
                for _iter14 in _viter13:
                    _iter14.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentInfo(object):
    """
    Attributes:
     - name
     - imageUrl
     - info
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'imageUrl', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'info', 'UTF8', None, ),  # 3
    )
    def __init__(self, name=None, imageUrl=None, info=None, ):
        self.name = name
        self.imageUrl = imageUrl
        self.info = info

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.imageUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.info = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentInfo')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.imageUrl is not None:
            oprot.writeFieldBegin('imageUrl', TType.STRING, 2)
            oprot.writeString(self.imageUrl.encode('utf-8') if sys.version_info[0] == 2 else self.imageUrl)
            oprot.writeFieldEnd()
        if self.info is not None:
            oprot.writeFieldBegin('info', TType.STRING, 3)
            oprot.writeString(self.info.encode('utf-8') if sys.version_info[0] == 2 else self.info)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AttachedFile(object):
    """
    Attributes:
     - url
     - assetId
     - createdTimeMs
     - status
     - contentSHA
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'url', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'assetId', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdTimeMs', None, None, ),  # 3
        (4, TType.I32, 'status', None, None, ),  # 4
        (5, TType.STRING, 'contentSHA', 'UTF8', None, ),  # 5
    )
    def __init__(self, url=None, assetId=None, createdTimeMs=None, status=None, contentSHA=None, ):
        self.url = url
        self.assetId = assetId
        self.createdTimeMs = createdTimeMs
        self.status = status
        self.contentSHA = contentSHA

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.assetId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdTimeMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.status = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.contentSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AttachedFile')
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 1)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.assetId is not None:
            oprot.writeFieldBegin('assetId', TType.STRING, 2)
            oprot.writeString(self.assetId.encode('utf-8') if sys.version_info[0] == 2 else self.assetId)
            oprot.writeFieldEnd()
        if self.createdTimeMs is not None:
            oprot.writeFieldBegin('createdTimeMs', TType.I64, 3)
            oprot.writeI64(self.createdTimeMs)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.I32, 4)
            oprot.writeI32(self.status)
            oprot.writeFieldEnd()
        if self.contentSHA is not None:
            oprot.writeFieldBegin('contentSHA', TType.STRING, 5)
            oprot.writeString(self.contentSHA.encode('utf-8') if sys.version_info[0] == 2 else self.contentSHA)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Charge(object):
    """
    Attributes:
     - chargeAmount
     - feePaymentFrequentType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'chargeAmount', None, None, ),  # 1
        (2, TType.I32, 'feePaymentFrequentType', None, None, ),  # 2
    )
    def __init__(self, chargeAmount=None, feePaymentFrequentType=None, ):
        self.chargeAmount = chargeAmount
        self.feePaymentFrequentType = feePaymentFrequentType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.chargeAmount = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.feePaymentFrequentType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Charge')
        if self.chargeAmount is not None:
            oprot.writeFieldBegin('chargeAmount', TType.DOUBLE, 1)
            oprot.writeDouble(self.chargeAmount)
            oprot.writeFieldEnd()
        if self.feePaymentFrequentType is not None:
            oprot.writeFieldBegin('feePaymentFrequentType', TType.I32, 2)
            oprot.writeI32(self.feePaymentFrequentType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CmaClient(object):
    """
    Attributes:
     - displayName
     - contactId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'displayName', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'contactId', 'UTF8', None, ),  # 2
    )
    def __init__(self, displayName=None, contactId=None, ):
        self.displayName = displayName
        self.contactId = contactId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CmaClient')
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 1)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 2)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Comp(object):
    """
    Attributes:
     - compId
     - similarityScore
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'compId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'similarityScore', 'UTF8', None, ),  # 2
    )
    def __init__(self, compId=None, similarityScore=None, ):
        self.compId = compId
        self.similarityScore = similarityScore

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.compId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.similarityScore = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Comp')
        if self.compId is not None:
            oprot.writeFieldBegin('compId', TType.STRING, 1)
            oprot.writeString(self.compId.encode('utf-8') if sys.version_info[0] == 2 else self.compId)
            oprot.writeFieldEnd()
        if self.similarityScore is not None:
            oprot.writeFieldBegin('similarityScore', TType.STRING, 2)
            oprot.writeString(self.similarityScore.encode('utf-8') if sys.version_info[0] == 2 else self.similarityScore)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CompsBuilderInputs(object):
    """
    Attributes:
     - searchQuery
     - searchResults
     - cqbId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'searchQuery', (gen.urbancompass.search.search.ttypes.SearchQuery, gen.urbancompass.search.search.ttypes.SearchQuery.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'searchResults', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'cqbId', 'UTF8', None, ),  # 3
    )
    def __init__(self, searchQuery=None, searchResults=None, cqbId=None, ):
        self.searchQuery = searchQuery
        self.searchResults = searchResults
        self.cqbId = cqbId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.searchQuery = gen.urbancompass.search.search.ttypes.SearchQuery()
                    self.searchQuery.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.searchResults = []
                    (_etype15, _size18) = iprot.readListBegin()
                    for _i16 in range(_size18):
                        _elem17 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem17.read(iprot)
                        self.searchResults.append(_elem17)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.cqbId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CompsBuilderInputs')
        if self.searchQuery is not None:
            oprot.writeFieldBegin('searchQuery', TType.STRUCT, 1)
            self.searchQuery.write(oprot)
            oprot.writeFieldEnd()
        if self.searchResults is not None:
            oprot.writeFieldBegin('searchResults', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.searchResults))
            for _iter19 in self.searchResults:
                _iter19.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.cqbId is not None:
            oprot.writeFieldBegin('cqbId', TType.STRING, 3)
            oprot.writeString(self.cqbId.encode('utf-8') if sys.version_info[0] == 2 else self.cqbId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Contact(object):
    """
    Attributes:
     - contactType
     - company
     - userId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactType', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'company', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'userId', 'UTF8', None, ),  # 3
    )
    def __init__(self, contactType=None, company=None, userId=None, ):
        self.contactType = contactType
        self.company = company
        self.userId = userId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Contact')
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.STRING, 1)
            oprot.writeString(self.contactType.encode('utf-8') if sys.version_info[0] == 2 else self.contactType)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 2)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 3)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CustomListingAttribute(object):
    """
    Attributes:
     - processedListingPath
     - overrideValue
     - displayFieldName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'processedListingPath', 'UTF8', None, ),  # 1
        (2, TType.MAP, 'overrideValue', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'displayFieldName', 'UTF8', None, ),  # 3
    )
    def __init__(self, processedListingPath=None, overrideValue=None, displayFieldName=None, ):
        self.processedListingPath = processedListingPath
        self.overrideValue = overrideValue
        self.displayFieldName = displayFieldName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.processedListingPath = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.overrideValue = {}
                    (_ktype21, _vtype22, _size25) = iprot.readMapBegin()
                    for _i20 in range(_size25):
                        _key23 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.overrideValue[_key23] = _val24
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.displayFieldName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CustomListingAttribute')
        if self.processedListingPath is not None:
            oprot.writeFieldBegin('processedListingPath', TType.STRING, 1)
            oprot.writeString(self.processedListingPath.encode('utf-8') if sys.version_info[0] == 2 else self.processedListingPath)
            oprot.writeFieldEnd()
        if self.overrideValue is not None:
            oprot.writeFieldBegin('overrideValue', TType.MAP, 2)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.overrideValue))
            for _kiter26, _viter27 in self.overrideValue.items():
                oprot.writeString(_kiter26.encode('utf-8') if sys.version_info[0] == 2 else _kiter26)
                oprot.writeString(_viter27.encode('utf-8') if sys.version_info[0] == 2 else _viter27)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.displayFieldName is not None:
            oprot.writeFieldBegin('displayFieldName', TType.STRING, 3)
            oprot.writeString(self.displayFieldName.encode('utf-8') if sys.version_info[0] == 2 else self.displayFieldName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CustomPdfSection(object):
    """
    Attributes:
     - id
     - source
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'source', 'UTF8', None, ),  # 2
    )
    def __init__(self, id=None, source=None, ):
        self.id = id
        self.source = source

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CustomPdfSection')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 2)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingDetail(object):
    """
    Attributes:
     - listingDetailPath
     - values
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingDetailPath', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'values', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'textValue', 'UTF8', None, ),  # 3
    )
    def __init__(self, listingDetailPath=None, values=None, textValue=None, ):
        self.listingDetailPath = listingDetailPath
        self.values = values
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingDetailPath = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.values = []
                    (_etype28, _size31) = iprot.readListBegin()
                    for _i29 in range(_size31):
                        _elem30 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.values.append(_elem30)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingDetail')
        if self.listingDetailPath is not None:
            oprot.writeFieldBegin('listingDetailPath', TType.STRING, 1)
            oprot.writeString(self.listingDetailPath.encode('utf-8') if sys.version_info[0] == 2 else self.listingDetailPath)
            oprot.writeFieldEnd()
        if self.values is not None:
            oprot.writeFieldBegin('values', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.values))
            for _iter32 in self.values:
                oprot.writeString(_iter32.encode('utf-8') if sys.version_info[0] == 2 else _iter32)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 3)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueDouble(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'value', None, None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.value = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueDouble')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.DOUBLE, 1)
            oprot.writeDouble(self.value)
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueI32(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'value', None, None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.value = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueI32')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.I32, 1)
            oprot.writeI32(self.value)
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueI64(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'value', None, None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.value = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueI64')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.I64, 1)
            oprot.writeI64(self.value)
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueListingStatus(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'value', None, None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.value = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueListingStatus')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.I32, 1)
            oprot.writeI32(self.value)
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueString(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'value', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueString')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 1)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueStringArray(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'value', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.value = []
                    (_etype33, _size36) = iprot.readListBegin()
                    for _i34 in range(_size36):
                        _elem35 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.value.append(_elem35)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueStringArray')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.value))
            for _iter37 in self.value:
                oprot.writeString(_iter37.encode('utf-8') if sys.version_info[0] == 2 else _iter37)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueStringMap(object):
    """
    Attributes:
     - valueMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'valueMap', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 1
    )
    def __init__(self, valueMap=None, ):
        self.valueMap = valueMap

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.valueMap = {}
                    (_ktype39, _vtype40, _size43) = iprot.readMapBegin()
                    for _i38 in range(_size43):
                        _key41 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val42 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.valueMap[_key41] = _val42
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueStringMap')
        if self.valueMap is not None:
            oprot.writeFieldBegin('valueMap', TType.MAP, 1)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.valueMap))
            for _kiter44, _viter45 in self.valueMap.items():
                oprot.writeString(_kiter44.encode('utf-8') if sys.version_info[0] == 2 else _kiter44)
                oprot.writeString(_viter45.encode('utf-8') if sys.version_info[0] == 2 else _viter45)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MarketReportChart(object):
    """
    Attributes:
     - chartName
     - label
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'chartName', None, None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
    )
    def __init__(self, chartName=None, label=None, ):
        self.chartName = chartName
        self.label = label

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.chartName = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MarketReportChart')
        if self.chartName is not None:
            oprot.writeFieldBegin('chartName', TType.I32, 1)
            oprot.writeI32(self.chartName)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetSheetsCalculations(object):
    """
    Attributes:
     - lastModifiedMs
     - calculations
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'lastModifiedMs', None, None, ),  # 1
        (2, TType.STRUCT, 'calculations', (gen.urbancompass.apex.apex_service.ttypes.ResponseResult, gen.urbancompass.apex.apex_service.ttypes.ResponseResult.thrift_spec), None, ),  # 2
    )
    def __init__(self, lastModifiedMs=None, calculations=None, ):
        self.lastModifiedMs = lastModifiedMs
        self.calculations = calculations

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.lastModifiedMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.calculations = gen.urbancompass.apex.apex_service.ttypes.ResponseResult()
                    self.calculations.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetSheetsCalculations')
        if self.lastModifiedMs is not None:
            oprot.writeFieldBegin('lastModifiedMs', TType.I64, 1)
            oprot.writeI64(self.lastModifiedMs)
            oprot.writeFieldEnd()
        if self.calculations is not None:
            oprot.writeFieldBegin('calculations', TType.STRUCT, 2)
            self.calculations.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PriceEstimate(object):
    """
    Attributes:
     - type
     - value
     - pricePerSqft
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'pricePerSqft', 'UTF8', None, ),  # 3
    )
    def __init__(self, type=None, value=None, pricePerSqft=None, ):
        self.type = type
        self.value = value
        self.pricePerSqft = pricePerSqft

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.pricePerSqft = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PriceEstimate')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        if self.pricePerSqft is not None:
            oprot.writeFieldBegin('pricePerSqft', TType.STRING, 3)
            oprot.writeString(self.pricePerSqft.encode('utf-8') if sys.version_info[0] == 2 else self.pricePerSqft)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PriceEstimateFeedback(object):
    """
    Attributes:
     - minRecomPrice
     - maxRecomPrice
     - feedback
     - like
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'minRecomPrice', None, None, ),  # 1
        (2, TType.I64, 'maxRecomPrice', None, None, ),  # 2
        (3, TType.STRING, 'feedback', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'like', None, None, ),  # 4
    )
    def __init__(self, minRecomPrice=None, maxRecomPrice=None, feedback=None, like=None, ):
        self.minRecomPrice = minRecomPrice
        self.maxRecomPrice = maxRecomPrice
        self.feedback = feedback
        self.like = like

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.minRecomPrice = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.maxRecomPrice = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.feedback = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.like = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PriceEstimateFeedback')
        if self.minRecomPrice is not None:
            oprot.writeFieldBegin('minRecomPrice', TType.I64, 1)
            oprot.writeI64(self.minRecomPrice)
            oprot.writeFieldEnd()
        if self.maxRecomPrice is not None:
            oprot.writeFieldBegin('maxRecomPrice', TType.I64, 2)
            oprot.writeI64(self.maxRecomPrice)
            oprot.writeFieldEnd()
        if self.feedback is not None:
            oprot.writeFieldBegin('feedback', TType.STRING, 3)
            oprot.writeString(self.feedback.encode('utf-8') if sys.version_info[0] == 2 else self.feedback)
            oprot.writeFieldEnd()
        if self.like is not None:
            oprot.writeFieldBegin('like', TType.BOOL, 4)
            oprot.writeBool(self.like)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReferencePriceEstimate(object):
    """
    Attributes:
     - min
     - max
     - average
     - avgPricePerSqft
     - minPricePerSqft
     - maxPricePerSqft
     - confidenceScore
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'min', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'max', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'average', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'avgPricePerSqft', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'minPricePerSqft', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'maxPricePerSqft', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'confidenceScore', 'UTF8', None, ),  # 7
    )
    def __init__(self, min=None, max=None, average=None, avgPricePerSqft=None, minPricePerSqft=None, maxPricePerSqft=None, confidenceScore=None, ):
        self.min = min
        self.max = max
        self.average = average
        self.avgPricePerSqft = avgPricePerSqft
        self.minPricePerSqft = minPricePerSqft
        self.maxPricePerSqft = maxPricePerSqft
        self.confidenceScore = confidenceScore

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.min = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.max = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.average = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.avgPricePerSqft = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.minPricePerSqft = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.maxPricePerSqft = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.confidenceScore = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReferencePriceEstimate')
        if self.min is not None:
            oprot.writeFieldBegin('min', TType.STRING, 1)
            oprot.writeString(self.min.encode('utf-8') if sys.version_info[0] == 2 else self.min)
            oprot.writeFieldEnd()
        if self.max is not None:
            oprot.writeFieldBegin('max', TType.STRING, 2)
            oprot.writeString(self.max.encode('utf-8') if sys.version_info[0] == 2 else self.max)
            oprot.writeFieldEnd()
        if self.average is not None:
            oprot.writeFieldBegin('average', TType.STRING, 3)
            oprot.writeString(self.average.encode('utf-8') if sys.version_info[0] == 2 else self.average)
            oprot.writeFieldEnd()
        if self.avgPricePerSqft is not None:
            oprot.writeFieldBegin('avgPricePerSqft', TType.STRING, 4)
            oprot.writeString(self.avgPricePerSqft.encode('utf-8') if sys.version_info[0] == 2 else self.avgPricePerSqft)
            oprot.writeFieldEnd()
        if self.minPricePerSqft is not None:
            oprot.writeFieldBegin('minPricePerSqft', TType.STRING, 5)
            oprot.writeString(self.minPricePerSqft.encode('utf-8') if sys.version_info[0] == 2 else self.minPricePerSqft)
            oprot.writeFieldEnd()
        if self.maxPricePerSqft is not None:
            oprot.writeFieldBegin('maxPricePerSqft', TType.STRING, 6)
            oprot.writeString(self.maxPricePerSqft.encode('utf-8') if sys.version_info[0] == 2 else self.maxPricePerSqft)
            oprot.writeFieldEnd()
        if self.confidenceScore is not None:
            oprot.writeFieldBegin('confidenceScore', TType.STRING, 7)
            oprot.writeString(self.confidenceScore.encode('utf-8') if sys.version_info[0] == 2 else self.confidenceScore)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ThankYouSection(object):
    """
    Attributes:
     - title
     - showTitle
     - notes
     - showNotes
     - showAddButton
     - logoLink
     - showLogo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'showTitle', None, None, ),  # 2
        (3, TType.STRING, 'notes', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'showNotes', None, None, ),  # 4
        (5, TType.BOOL, 'showAddButton', None, None, ),  # 5
        (6, TType.STRING, 'logoLink', 'UTF8', None, ),  # 6
        (7, TType.BOOL, 'showLogo', None, None, ),  # 7
    )
    def __init__(self, title=None, showTitle=None, notes=None, showNotes=None, showAddButton=None, logoLink=None, showLogo=None, ):
        self.title = title
        self.showTitle = showTitle
        self.notes = notes
        self.showNotes = showNotes
        self.showAddButton = showAddButton
        self.logoLink = logoLink
        self.showLogo = showLogo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.showTitle = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.notes = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.showNotes = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.showAddButton = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.logoLink = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.BOOL:
                    self.showLogo = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ThankYouSection')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.showTitle is not None:
            oprot.writeFieldBegin('showTitle', TType.BOOL, 2)
            oprot.writeBool(self.showTitle)
            oprot.writeFieldEnd()
        if self.notes is not None:
            oprot.writeFieldBegin('notes', TType.STRING, 3)
            oprot.writeString(self.notes.encode('utf-8') if sys.version_info[0] == 2 else self.notes)
            oprot.writeFieldEnd()
        if self.showNotes is not None:
            oprot.writeFieldBegin('showNotes', TType.BOOL, 4)
            oprot.writeBool(self.showNotes)
            oprot.writeFieldEnd()
        if self.showAddButton is not None:
            oprot.writeFieldBegin('showAddButton', TType.BOOL, 5)
            oprot.writeBool(self.showAddButton)
            oprot.writeFieldEnd()
        if self.logoLink is not None:
            oprot.writeFieldBegin('logoLink', TType.STRING, 6)
            oprot.writeString(self.logoLink.encode('utf-8') if sys.version_info[0] == 2 else self.logoLink)
            oprot.writeFieldEnd()
        if self.showLogo is not None:
            oprot.writeFieldBegin('showLogo', TType.BOOL, 7)
            oprot.writeBool(self.showLogo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpgradeItem(object):
    """
    Attributes:
     - title
     - description
     - lensImageItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'description', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'lensImageItems', (TType.STRUCT, (gen.urbancompass.concierge_lens_v0.service.ttypes.LensImageItem, gen.urbancompass.concierge_lens_v0.service.ttypes.LensImageItem.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, title=None, description=None, lensImageItems=None, ):
        self.title = title
        self.description = description
        self.lensImageItems = lensImageItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.lensImageItems = []
                    (_etype46, _size49) = iprot.readListBegin()
                    for _i47 in range(_size49):
                        _elem48 = gen.urbancompass.concierge_lens_v0.service.ttypes.LensImageItem()
                        _elem48.read(iprot)
                        self.lensImageItems.append(_elem48)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpgradeItem')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 2)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.lensImageItems is not None:
            oprot.writeFieldBegin('lensImageItems', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.lensImageItems))
            for _iter50 in self.lensImageItems:
                _iter50.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CoverSection(object):
    """
    Attributes:
     - title
     - agentsInfo
     - logoLink
     - showLogo
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'agentsInfo', (TType.STRUCT, (AgentInfo, AgentInfo.thrift_spec), False), None, ),  # 2
        (3, TType.STRING, 'logoLink', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'showLogo', None, None, ),  # 4
    )
    def __init__(self, title=None, agentsInfo=None, logoLink=None, showLogo=None, ):
        self.title = title
        self.agentsInfo = agentsInfo
        self.logoLink = logoLink
        self.showLogo = showLogo

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.agentsInfo = []
                    (_etype51, _size54) = iprot.readListBegin()
                    for _i52 in range(_size54):
                        _elem53 = AgentInfo()
                        _elem53.read(iprot)
                        self.agentsInfo.append(_elem53)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.logoLink = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.showLogo = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CoverSection')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.agentsInfo is not None:
            oprot.writeFieldBegin('agentsInfo', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.agentsInfo))
            for _iter55 in self.agentsInfo:
                _iter55.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.logoLink is not None:
            oprot.writeFieldBegin('logoLink', TType.STRING, 3)
            oprot.writeString(self.logoLink.encode('utf-8') if sys.version_info[0] == 2 else self.logoLink)
            oprot.writeFieldEnd()
        if self.showLogo is not None:
            oprot.writeFieldBegin('showLogo', TType.BOOL, 4)
            oprot.writeBool(self.showLogo)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueCharge(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'value', (Charge, Charge.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.value = Charge()
                    self.value.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueCharge')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRUCT, 1)
            self.value.write(oprot)
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ListingValueContactArray(object):
    """
    Attributes:
     - value
     - textValue
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'value', (TType.STRUCT, (Contact, Contact.thrift_spec), False), None, ),  # 1
        (2, TType.STRING, 'textValue', 'UTF8', None, ),  # 2
    )
    def __init__(self, value=None, textValue=None, ):
        self.value = value
        self.textValue = textValue

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.value = []
                    (_etype56, _size59) = iprot.readListBegin()
                    for _i57 in range(_size59):
                        _elem58 = Contact()
                        _elem58.read(iprot)
                        self.value.append(_elem58)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.textValue = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ListingValueContactArray')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.value))
            for _iter60 in self.value:
                _iter60.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.textValue is not None:
            oprot.writeFieldBegin('textValue', TType.STRING, 2)
            oprot.writeString(self.textValue.encode('utf-8') if sys.version_info[0] == 2 else self.textValue)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MarketReportSettings(object):
    """
    Attributes:
     - visibleCharts
     - visibleMetrics
     - marketReportTitle
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'visibleCharts', (TType.STRUCT, (MarketReportChart, MarketReportChart.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'visibleMetrics', (TType.I32, None, False), None, ),  # 2
        (3, TType.STRING, 'marketReportTitle', 'UTF8', None, ),  # 3
    )
    def __init__(self, visibleCharts=None, visibleMetrics=None, marketReportTitle=None, ):
        self.visibleCharts = visibleCharts
        self.visibleMetrics = visibleMetrics
        self.marketReportTitle = marketReportTitle

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.visibleCharts = []
                    (_etype61, _size64) = iprot.readListBegin()
                    for _i62 in range(_size64):
                        _elem63 = MarketReportChart()
                        _elem63.read(iprot)
                        self.visibleCharts.append(_elem63)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.visibleMetrics = []
                    (_etype65, _size68) = iprot.readListBegin()
                    for _i66 in range(_size68):
                        _elem67 = iprot.readI32()
                        self.visibleMetrics.append(_elem67)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.marketReportTitle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MarketReportSettings')
        if self.visibleCharts is not None:
            oprot.writeFieldBegin('visibleCharts', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.visibleCharts))
            for _iter69 in self.visibleCharts:
                _iter69.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.visibleMetrics is not None:
            oprot.writeFieldBegin('visibleMetrics', TType.LIST, 2)
            oprot.writeListBegin(TType.I32, len(self.visibleMetrics))
            for _iter70 in self.visibleMetrics:
                oprot.writeI32(_iter70)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.marketReportTitle is not None:
            oprot.writeFieldBegin('marketReportTitle', TType.STRING, 3)
            oprot.writeString(self.marketReportTitle.encode('utf-8') if sys.version_info[0] == 2 else self.marketReportTitle)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Metadata(object):
    """
    Attributes:
     - cmaState
     - collaboratorIds
     - lastUpdateTimeMs
     - publishTimeMs
     - createdTimeMs
     - ownerId
     - s3Url
     - canvasId
     - ttl
     - title
     - publishingProgress
     - versions
     - pdfFile
     - collateralUUID
     - dealId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'cmaState', None, None, ),  # 1
        (2, TType.SET, 'collaboratorIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.I64, 'lastUpdateTimeMs', None, None, ),  # 3
        (4, TType.I64, 'publishTimeMs', None, None, ),  # 4
        (5, TType.I64, 'createdTimeMs', None, None, ),  # 5
        (6, TType.STRING, 'ownerId', 'UTF8', None, ),  # 6
        (7, TType.STRING, 's3Url', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'canvasId', 'UTF8', None, ),  # 8
        (9, TType.I64, 'ttl', None, None, ),  # 9
        (10, TType.STRING, 'title', 'UTF8', None, ),  # 10
        (11, TType.DOUBLE, 'publishingProgress', None, None, ),  # 11
        (12, TType.SET, 'versions', (TType.STRING, 'UTF8', False), None, ),  # 12
        (13, TType.STRUCT, 'pdfFile', (AttachedFile, AttachedFile.thrift_spec), None, ),  # 13
        (14, TType.STRING, 'collateralUUID', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'dealId', 'UTF8', None, ),  # 15
    )
    def __init__(self, cmaState=None, collaboratorIds=None, lastUpdateTimeMs=None, publishTimeMs=None, createdTimeMs=None, ownerId=None, s3Url=None, canvasId=None, ttl=None, title=None, publishingProgress=None, versions=None, pdfFile=None, collateralUUID=None, dealId=None, ):
        self.cmaState = cmaState
        self.collaboratorIds = collaboratorIds
        self.lastUpdateTimeMs = lastUpdateTimeMs
        self.publishTimeMs = publishTimeMs
        self.createdTimeMs = createdTimeMs
        self.ownerId = ownerId
        self.s3Url = s3Url
        self.canvasId = canvasId
        self.ttl = ttl
        self.title = title
        self.publishingProgress = publishingProgress
        self.versions = versions
        self.pdfFile = pdfFile
        self.collateralUUID = collateralUUID
        self.dealId = dealId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.cmaState = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.SET:
                    self.collaboratorIds = set()
                    (_etype72, _size74) = iprot.readSetBegin()
                    for _i71 in range(_size74):
                        _elem73 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.collaboratorIds.add(_elem73)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.lastUpdateTimeMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.publishTimeMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdTimeMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.ownerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.s3Url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.canvasId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.ttl = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.DOUBLE:
                    self.publishingProgress = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.SET:
                    self.versions = set()
                    (_etype76, _size78) = iprot.readSetBegin()
                    for _i75 in range(_size78):
                        _elem77 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.versions.add(_elem77)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.pdfFile = AttachedFile()
                    self.pdfFile.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.collateralUUID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.dealId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Metadata')
        if self.cmaState is not None:
            oprot.writeFieldBegin('cmaState', TType.I32, 1)
            oprot.writeI32(self.cmaState)
            oprot.writeFieldEnd()
        if self.collaboratorIds is not None:
            oprot.writeFieldBegin('collaboratorIds', TType.SET, 2)
            oprot.writeSetBegin(TType.STRING, len(self.collaboratorIds))
            for _iter79 in self.collaboratorIds:
                oprot.writeString(_iter79.encode('utf-8') if sys.version_info[0] == 2 else _iter79)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.lastUpdateTimeMs is not None:
            oprot.writeFieldBegin('lastUpdateTimeMs', TType.I64, 3)
            oprot.writeI64(self.lastUpdateTimeMs)
            oprot.writeFieldEnd()
        if self.publishTimeMs is not None:
            oprot.writeFieldBegin('publishTimeMs', TType.I64, 4)
            oprot.writeI64(self.publishTimeMs)
            oprot.writeFieldEnd()
        if self.createdTimeMs is not None:
            oprot.writeFieldBegin('createdTimeMs', TType.I64, 5)
            oprot.writeI64(self.createdTimeMs)
            oprot.writeFieldEnd()
        if self.ownerId is not None:
            oprot.writeFieldBegin('ownerId', TType.STRING, 6)
            oprot.writeString(self.ownerId.encode('utf-8') if sys.version_info[0] == 2 else self.ownerId)
            oprot.writeFieldEnd()
        if self.s3Url is not None:
            oprot.writeFieldBegin('s3Url', TType.STRING, 7)
            oprot.writeString(self.s3Url.encode('utf-8') if sys.version_info[0] == 2 else self.s3Url)
            oprot.writeFieldEnd()
        if self.canvasId is not None:
            oprot.writeFieldBegin('canvasId', TType.STRING, 8)
            oprot.writeString(self.canvasId.encode('utf-8') if sys.version_info[0] == 2 else self.canvasId)
            oprot.writeFieldEnd()
        if self.ttl is not None:
            oprot.writeFieldBegin('ttl', TType.I64, 9)
            oprot.writeI64(self.ttl)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 10)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.publishingProgress is not None:
            oprot.writeFieldBegin('publishingProgress', TType.DOUBLE, 11)
            oprot.writeDouble(self.publishingProgress)
            oprot.writeFieldEnd()
        if self.versions is not None:
            oprot.writeFieldBegin('versions', TType.SET, 12)
            oprot.writeSetBegin(TType.STRING, len(self.versions))
            for _iter80 in self.versions:
                oprot.writeString(_iter80.encode('utf-8') if sys.version_info[0] == 2 else _iter80)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.pdfFile is not None:
            oprot.writeFieldBegin('pdfFile', TType.STRUCT, 13)
            self.pdfFile.write(oprot)
            oprot.writeFieldEnd()
        if self.collateralUUID is not None:
            oprot.writeFieldBegin('collateralUUID', TType.STRING, 14)
            oprot.writeString(self.collateralUUID.encode('utf-8') if sys.version_info[0] == 2 else self.collateralUUID)
            oprot.writeFieldEnd()
        if self.dealId is not None:
            oprot.writeFieldBegin('dealId', TType.STRING, 15)
            oprot.writeString(self.dealId.encode('utf-8') if sys.version_info[0] == 2 else self.dealId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NetSheets(object):
    """
    Attributes:
     - input
     - minResults
     - maxResults
     - inputModifiedMs
     - partnerLeadGenerationOptIn
     - addedToCma
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'input', (gen.urbancompass.apex.apex_service.ttypes.NetSheetsInputs, gen.urbancompass.apex.apex_service.ttypes.NetSheetsInputs.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'minResults', (NetSheetsCalculations, NetSheetsCalculations.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'maxResults', (NetSheetsCalculations, NetSheetsCalculations.thrift_spec), None, ),  # 3
        (4, TType.I64, 'inputModifiedMs', None, None, ),  # 4
        (5, TType.BOOL, 'partnerLeadGenerationOptIn', None, None, ),  # 5
        (6, TType.BOOL, 'addedToCma', None, None, ),  # 6
    )
    def __init__(self, input=None, minResults=None, maxResults=None, inputModifiedMs=None, partnerLeadGenerationOptIn=None, addedToCma=None, ):
        self.input = input
        self.minResults = minResults
        self.maxResults = maxResults
        self.inputModifiedMs = inputModifiedMs
        self.partnerLeadGenerationOptIn = partnerLeadGenerationOptIn
        self.addedToCma = addedToCma

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.input = gen.urbancompass.apex.apex_service.ttypes.NetSheetsInputs()
                    self.input.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.minResults = NetSheetsCalculations()
                    self.minResults.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.maxResults = NetSheetsCalculations()
                    self.maxResults.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.inputModifiedMs = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.partnerLeadGenerationOptIn = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.BOOL:
                    self.addedToCma = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NetSheets')
        if self.input is not None:
            oprot.writeFieldBegin('input', TType.STRUCT, 1)
            self.input.write(oprot)
            oprot.writeFieldEnd()
        if self.minResults is not None:
            oprot.writeFieldBegin('minResults', TType.STRUCT, 2)
            self.minResults.write(oprot)
            oprot.writeFieldEnd()
        if self.maxResults is not None:
            oprot.writeFieldBegin('maxResults', TType.STRUCT, 3)
            self.maxResults.write(oprot)
            oprot.writeFieldEnd()
        if self.inputModifiedMs is not None:
            oprot.writeFieldBegin('inputModifiedMs', TType.I64, 4)
            oprot.writeI64(self.inputModifiedMs)
            oprot.writeFieldEnd()
        if self.partnerLeadGenerationOptIn is not None:
            oprot.writeFieldBegin('partnerLeadGenerationOptIn', TType.BOOL, 5)
            oprot.writeBool(self.partnerLeadGenerationOptIn)
            oprot.writeFieldEnd()
        if self.addedToCma is not None:
            oprot.writeFieldBegin('addedToCma', TType.BOOL, 6)
            oprot.writeBool(self.addedToCma)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PriceEstimation(object):
    """
    Attributes:
     - cmaId
     - listingIdSHA
     - cmaEstimatedPrice
     - referencedEstimate
     - compsPrices
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'cmaId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'cmaEstimatedPrice', 'UTF8', None, ),  # 3
        (4, TType.MAP, 'referencedEstimate', (TType.I32, None, TType.STRUCT, (ReferencePriceEstimate, ReferencePriceEstimate.thrift_spec), False), None, ),  # 4
        (5, TType.MAP, 'compsPrices', (TType.STRING, 'UTF8', TType.DOUBLE, None, False), None, ),  # 5
    )
    def __init__(self, cmaId=None, listingIdSHA=None, cmaEstimatedPrice=None, referencedEstimate=None, compsPrices=None, ):
        self.cmaId = cmaId
        self.listingIdSHA = listingIdSHA
        self.cmaEstimatedPrice = cmaEstimatedPrice
        self.referencedEstimate = referencedEstimate
        self.compsPrices = compsPrices

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.cmaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.cmaEstimatedPrice = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.MAP:
                    self.referencedEstimate = {}
                    (_ktype82, _vtype83, _size86) = iprot.readMapBegin()
                    for _i81 in range(_size86):
                        _key84 = iprot.readI32()
                        _val85 = ReferencePriceEstimate()
                        _val85.read(iprot)
                        self.referencedEstimate[_key84] = _val85
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.compsPrices = {}
                    (_ktype88, _vtype89, _size92) = iprot.readMapBegin()
                    for _i87 in range(_size92):
                        _key90 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val91 = iprot.readDouble()
                        self.compsPrices[_key90] = _val91
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PriceEstimation')
        if self.cmaId is not None:
            oprot.writeFieldBegin('cmaId', TType.STRING, 1)
            oprot.writeString(self.cmaId.encode('utf-8') if sys.version_info[0] == 2 else self.cmaId)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 2)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.cmaEstimatedPrice is not None:
            oprot.writeFieldBegin('cmaEstimatedPrice', TType.STRING, 3)
            oprot.writeString(self.cmaEstimatedPrice.encode('utf-8') if sys.version_info[0] == 2 else self.cmaEstimatedPrice)
            oprot.writeFieldEnd()
        if self.referencedEstimate is not None:
            oprot.writeFieldBegin('referencedEstimate', TType.MAP, 4)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.referencedEstimate))
            for _kiter93, _viter94 in self.referencedEstimate.items():
                oprot.writeI32(_kiter93)
                _viter94.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.compsPrices is not None:
            oprot.writeFieldBegin('compsPrices', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.DOUBLE, len(self.compsPrices))
            for _kiter95, _viter96 in self.compsPrices.items():
                oprot.writeString(_kiter95.encode('utf-8') if sys.version_info[0] == 2 else _kiter95)
                oprot.writeDouble(_viter96)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpgradeRecommendation(object):
    """
    Attributes:
     - estimatedTotalCost
     - estimatedTotalImpact
     - upgradeItems
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'estimatedTotalCost', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'estimatedTotalImpact', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'upgradeItems', (TType.STRUCT, (UpgradeItem, UpgradeItem.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, estimatedTotalCost=None, estimatedTotalImpact=None, upgradeItems=None, ):
        self.estimatedTotalCost = estimatedTotalCost
        self.estimatedTotalImpact = estimatedTotalImpact
        self.upgradeItems = upgradeItems

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.estimatedTotalCost = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.estimatedTotalImpact = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.upgradeItems = []
                    (_etype97, _size100) = iprot.readListBegin()
                    for _i98 in range(_size100):
                        _elem99 = UpgradeItem()
                        _elem99.read(iprot)
                        self.upgradeItems.append(_elem99)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpgradeRecommendation')
        if self.estimatedTotalCost is not None:
            oprot.writeFieldBegin('estimatedTotalCost', TType.STRING, 1)
            oprot.writeString(self.estimatedTotalCost.encode('utf-8') if sys.version_info[0] == 2 else self.estimatedTotalCost)
            oprot.writeFieldEnd()
        if self.estimatedTotalImpact is not None:
            oprot.writeFieldBegin('estimatedTotalImpact', TType.STRING, 2)
            oprot.writeString(self.estimatedTotalImpact.encode('utf-8') if sys.version_info[0] == 2 else self.estimatedTotalImpact)
            oprot.writeFieldEnd()
        if self.upgradeItems is not None:
            oprot.writeFieldBegin('upgradeItems', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.upgradeItems))
            for _iter101 in self.upgradeItems:
                _iter101.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DisplayListing(object):
    """
    Attributes:
     - listingIdSHA
     - listingStatus
     - bedrooms
     - bathrooms
     - squareFeet
     - pricePerSquareFoot
     - origListingPrice
     - lastAskingPrice
     - closePrice
     - hoaFee
     - propertyTax
     - listedDate
     - contractDate
     - closedDate
     - daysOnMarket
     - lotSizeInSquareFeet
     - propertyType
     - yearBuilt
     - geoId
     - latitude
     - longitude
     - address
     - city
     - state
     - zipCode
     - amenities
     - listingContacts
     - maintenanceCommonCharges
     - localizedStatus
     - cumulativeDaysOnMarket
     - listingDetails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'listingIdSHA', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'listingStatus', (ListingValueListingStatus, ListingValueListingStatus.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'bedrooms', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'bathrooms', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 4
        (5, TType.STRUCT, 'squareFeet', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'pricePerSquareFoot', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'origListingPrice', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'lastAskingPrice', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 8
        (9, TType.STRUCT, 'closePrice', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 9
        (10, TType.STRUCT, 'hoaFee', (ListingValueCharge, ListingValueCharge.thrift_spec), None, ),  # 10
        (11, TType.STRUCT, 'propertyTax', (ListingValueCharge, ListingValueCharge.thrift_spec), None, ),  # 11
        (12, TType.STRUCT, 'listedDate', (ListingValueI64, ListingValueI64.thrift_spec), None, ),  # 12
        (13, TType.STRUCT, 'contractDate', (ListingValueI64, ListingValueI64.thrift_spec), None, ),  # 13
        (14, TType.STRUCT, 'closedDate', (ListingValueI64, ListingValueI64.thrift_spec), None, ),  # 14
        (15, TType.STRUCT, 'daysOnMarket', (ListingValueI32, ListingValueI32.thrift_spec), None, ),  # 15
        (16, TType.STRUCT, 'lotSizeInSquareFeet', (ListingValueI32, ListingValueI32.thrift_spec), None, ),  # 16
        (17, TType.STRUCT, 'propertyType', (ListingValueStringArray, ListingValueStringArray.thrift_spec), None, ),  # 17
        (18, TType.STRUCT, 'yearBuilt', (ListingValueI32, ListingValueI32.thrift_spec), None, ),  # 18
        (19, TType.STRUCT, 'geoId', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 19
        (20, TType.STRUCT, 'latitude', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 20
        (21, TType.STRUCT, 'longitude', (ListingValueDouble, ListingValueDouble.thrift_spec), None, ),  # 21
        (22, TType.STRUCT, 'address', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 22
        (23, TType.STRUCT, 'city', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 23
        (24, TType.STRUCT, 'state', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 24
        (25, TType.STRUCT, 'zipCode', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 25
        (26, TType.STRUCT, 'amenities', (ListingValueStringMap, ListingValueStringMap.thrift_spec), None, ),  # 26
        (27, TType.STRUCT, 'listingContacts', (ListingValueContactArray, ListingValueContactArray.thrift_spec), None, ),  # 27
        (28, TType.STRUCT, 'maintenanceCommonCharges', (ListingValueCharge, ListingValueCharge.thrift_spec), None, ),  # 28
        (29, TType.STRUCT, 'localizedStatus', (ListingValueString, ListingValueString.thrift_spec), None, ),  # 29
        (30, TType.STRUCT, 'cumulativeDaysOnMarket', (ListingValueI32, ListingValueI32.thrift_spec), None, ),  # 30
        (31, TType.LIST, 'listingDetails', (TType.STRUCT, (ListingDetail, ListingDetail.thrift_spec), False), None, ),  # 31
    )
    def __init__(self, listingIdSHA=None, listingStatus=None, bedrooms=None, bathrooms=None, squareFeet=None, pricePerSquareFoot=None, origListingPrice=None, lastAskingPrice=None, closePrice=None, hoaFee=None, propertyTax=None, listedDate=None, contractDate=None, closedDate=None, daysOnMarket=None, lotSizeInSquareFeet=None, propertyType=None, yearBuilt=None, geoId=None, latitude=None, longitude=None, address=None, city=None, state=None, zipCode=None, amenities=None, listingContacts=None, maintenanceCommonCharges=None, localizedStatus=None, cumulativeDaysOnMarket=None, listingDetails=None, ):
        self.listingIdSHA = listingIdSHA
        self.listingStatus = listingStatus
        self.bedrooms = bedrooms
        self.bathrooms = bathrooms
        self.squareFeet = squareFeet
        self.pricePerSquareFoot = pricePerSquareFoot
        self.origListingPrice = origListingPrice
        self.lastAskingPrice = lastAskingPrice
        self.closePrice = closePrice
        self.hoaFee = hoaFee
        self.propertyTax = propertyTax
        self.listedDate = listedDate
        self.contractDate = contractDate
        self.closedDate = closedDate
        self.daysOnMarket = daysOnMarket
        self.lotSizeInSquareFeet = lotSizeInSquareFeet
        self.propertyType = propertyType
        self.yearBuilt = yearBuilt
        self.geoId = geoId
        self.latitude = latitude
        self.longitude = longitude
        self.address = address
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.amenities = amenities
        self.listingContacts = listingContacts
        self.maintenanceCommonCharges = maintenanceCommonCharges
        self.localizedStatus = localizedStatus
        self.cumulativeDaysOnMarket = cumulativeDaysOnMarket
        self.listingDetails = listingDetails

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.listingIdSHA = ListingValueString()
                    self.listingIdSHA.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.listingStatus = ListingValueListingStatus()
                    self.listingStatus.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.bedrooms = ListingValueDouble()
                    self.bedrooms.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.bathrooms = ListingValueDouble()
                    self.bathrooms.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.squareFeet = ListingValueDouble()
                    self.squareFeet.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.pricePerSquareFoot = ListingValueDouble()
                    self.pricePerSquareFoot.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.origListingPrice = ListingValueDouble()
                    self.origListingPrice.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.lastAskingPrice = ListingValueDouble()
                    self.lastAskingPrice.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.closePrice = ListingValueDouble()
                    self.closePrice.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRUCT:
                    self.hoaFee = ListingValueCharge()
                    self.hoaFee.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.propertyTax = ListingValueCharge()
                    self.propertyTax.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.listedDate = ListingValueI64()
                    self.listedDate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.contractDate = ListingValueI64()
                    self.contractDate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.closedDate = ListingValueI64()
                    self.closedDate.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.daysOnMarket = ListingValueI32()
                    self.daysOnMarket.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRUCT:
                    self.lotSizeInSquareFeet = ListingValueI32()
                    self.lotSizeInSquareFeet.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRUCT:
                    self.propertyType = ListingValueStringArray()
                    self.propertyType.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRUCT:
                    self.yearBuilt = ListingValueI32()
                    self.yearBuilt.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRUCT:
                    self.geoId = ListingValueString()
                    self.geoId.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.STRUCT:
                    self.latitude = ListingValueDouble()
                    self.latitude.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRUCT:
                    self.longitude = ListingValueDouble()
                    self.longitude.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRUCT:
                    self.address = ListingValueString()
                    self.address.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRUCT:
                    self.city = ListingValueString()
                    self.city.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.state = ListingValueString()
                    self.state.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRUCT:
                    self.zipCode = ListingValueString()
                    self.zipCode.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRUCT:
                    self.amenities = ListingValueStringMap()
                    self.amenities.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRUCT:
                    self.listingContacts = ListingValueContactArray()
                    self.listingContacts.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRUCT:
                    self.maintenanceCommonCharges = ListingValueCharge()
                    self.maintenanceCommonCharges.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRUCT:
                    self.localizedStatus = ListingValueString()
                    self.localizedStatus.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.cumulativeDaysOnMarket = ListingValueI32()
                    self.cumulativeDaysOnMarket.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.LIST:
                    self.listingDetails = []
                    (_etype102, _size105) = iprot.readListBegin()
                    for _i103 in range(_size105):
                        _elem104 = ListingDetail()
                        _elem104.read(iprot)
                        self.listingDetails.append(_elem104)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DisplayListing')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRUCT, 1)
            self.listingIdSHA.write(oprot)
            oprot.writeFieldEnd()
        if self.listingStatus is not None:
            oprot.writeFieldBegin('listingStatus', TType.STRUCT, 2)
            self.listingStatus.write(oprot)
            oprot.writeFieldEnd()
        if self.bedrooms is not None:
            oprot.writeFieldBegin('bedrooms', TType.STRUCT, 3)
            self.bedrooms.write(oprot)
            oprot.writeFieldEnd()
        if self.bathrooms is not None:
            oprot.writeFieldBegin('bathrooms', TType.STRUCT, 4)
            self.bathrooms.write(oprot)
            oprot.writeFieldEnd()
        if self.squareFeet is not None:
            oprot.writeFieldBegin('squareFeet', TType.STRUCT, 5)
            self.squareFeet.write(oprot)
            oprot.writeFieldEnd()
        if self.pricePerSquareFoot is not None:
            oprot.writeFieldBegin('pricePerSquareFoot', TType.STRUCT, 6)
            self.pricePerSquareFoot.write(oprot)
            oprot.writeFieldEnd()
        if self.origListingPrice is not None:
            oprot.writeFieldBegin('origListingPrice', TType.STRUCT, 7)
            self.origListingPrice.write(oprot)
            oprot.writeFieldEnd()
        if self.lastAskingPrice is not None:
            oprot.writeFieldBegin('lastAskingPrice', TType.STRUCT, 8)
            self.lastAskingPrice.write(oprot)
            oprot.writeFieldEnd()
        if self.closePrice is not None:
            oprot.writeFieldBegin('closePrice', TType.STRUCT, 9)
            self.closePrice.write(oprot)
            oprot.writeFieldEnd()
        if self.hoaFee is not None:
            oprot.writeFieldBegin('hoaFee', TType.STRUCT, 10)
            self.hoaFee.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyTax is not None:
            oprot.writeFieldBegin('propertyTax', TType.STRUCT, 11)
            self.propertyTax.write(oprot)
            oprot.writeFieldEnd()
        if self.listedDate is not None:
            oprot.writeFieldBegin('listedDate', TType.STRUCT, 12)
            self.listedDate.write(oprot)
            oprot.writeFieldEnd()
        if self.contractDate is not None:
            oprot.writeFieldBegin('contractDate', TType.STRUCT, 13)
            self.contractDate.write(oprot)
            oprot.writeFieldEnd()
        if self.closedDate is not None:
            oprot.writeFieldBegin('closedDate', TType.STRUCT, 14)
            self.closedDate.write(oprot)
            oprot.writeFieldEnd()
        if self.daysOnMarket is not None:
            oprot.writeFieldBegin('daysOnMarket', TType.STRUCT, 15)
            self.daysOnMarket.write(oprot)
            oprot.writeFieldEnd()
        if self.lotSizeInSquareFeet is not None:
            oprot.writeFieldBegin('lotSizeInSquareFeet', TType.STRUCT, 16)
            self.lotSizeInSquareFeet.write(oprot)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.STRUCT, 17)
            self.propertyType.write(oprot)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.STRUCT, 18)
            self.yearBuilt.write(oprot)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRUCT, 19)
            self.geoId.write(oprot)
            oprot.writeFieldEnd()
        if self.latitude is not None:
            oprot.writeFieldBegin('latitude', TType.STRUCT, 20)
            self.latitude.write(oprot)
            oprot.writeFieldEnd()
        if self.longitude is not None:
            oprot.writeFieldBegin('longitude', TType.STRUCT, 21)
            self.longitude.write(oprot)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRUCT, 22)
            self.address.write(oprot)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRUCT, 23)
            self.city.write(oprot)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRUCT, 24)
            self.state.write(oprot)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRUCT, 25)
            self.zipCode.write(oprot)
            oprot.writeFieldEnd()
        if self.amenities is not None:
            oprot.writeFieldBegin('amenities', TType.STRUCT, 26)
            self.amenities.write(oprot)
            oprot.writeFieldEnd()
        if self.listingContacts is not None:
            oprot.writeFieldBegin('listingContacts', TType.STRUCT, 27)
            self.listingContacts.write(oprot)
            oprot.writeFieldEnd()
        if self.maintenanceCommonCharges is not None:
            oprot.writeFieldBegin('maintenanceCommonCharges', TType.STRUCT, 28)
            self.maintenanceCommonCharges.write(oprot)
            oprot.writeFieldEnd()
        if self.localizedStatus is not None:
            oprot.writeFieldBegin('localizedStatus', TType.STRUCT, 29)
            self.localizedStatus.write(oprot)
            oprot.writeFieldEnd()
        if self.cumulativeDaysOnMarket is not None:
            oprot.writeFieldBegin('cumulativeDaysOnMarket', TType.STRUCT, 30)
            self.cumulativeDaysOnMarket.write(oprot)
            oprot.writeFieldEnd()
        if self.listingDetails is not None:
            oprot.writeFieldBegin('listingDetails', TType.LIST, 31)
            oprot.writeListBegin(TType.STRUCT, len(self.listingDetails))
            for _iter106 in self.listingDetails:
                _iter106.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PresentationalSectionSettings(object):
    """
    Attributes:
     - sectionType
     - customPdfSection
     - coverSection
     - thankYouSection
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'sectionType', None, None, ),  # 1
        (2, TType.STRUCT, 'customPdfSection', (CustomPdfSection, CustomPdfSection.thrift_spec), None, ),  # 2
        (3, TType.STRUCT, 'coverSection', (CoverSection, CoverSection.thrift_spec), None, ),  # 3
        (4, TType.STRUCT, 'thankYouSection', (ThankYouSection, ThankYouSection.thrift_spec), None, ),  # 4
    )
    def __init__(self, sectionType=None, customPdfSection=None, coverSection=None, thankYouSection=None, ):
        self.sectionType = sectionType
        self.customPdfSection = customPdfSection
        self.coverSection = coverSection
        self.thankYouSection = thankYouSection

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.sectionType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.customPdfSection = CustomPdfSection()
                    self.customPdfSection.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.coverSection = CoverSection()
                    self.coverSection.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.thankYouSection = ThankYouSection()
                    self.thankYouSection.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PresentationalSectionSettings')
        if self.sectionType is not None:
            oprot.writeFieldBegin('sectionType', TType.I32, 1)
            oprot.writeI32(self.sectionType)
            oprot.writeFieldEnd()
        if self.customPdfSection is not None:
            oprot.writeFieldBegin('customPdfSection', TType.STRUCT, 2)
            self.customPdfSection.write(oprot)
            oprot.writeFieldEnd()
        if self.coverSection is not None:
            oprot.writeFieldBegin('coverSection', TType.STRUCT, 3)
            self.coverSection.write(oprot)
            oprot.writeFieldEnd()
        if self.thankYouSection is not None:
            oprot.writeFieldBegin('thankYouSection', TType.STRUCT, 4)
            self.thankYouSection.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PresentationalSettings(object):
    """
    Attributes:
     - visibleSections
     - hiddenSections
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'visibleSections', (TType.STRUCT, (PresentationalSectionSettings, PresentationalSectionSettings.thrift_spec), False), None, ),  # 1
        (2, TType.LIST, 'hiddenSections', (TType.STRUCT, (PresentationalSectionSettings, PresentationalSectionSettings.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, visibleSections=None, hiddenSections=None, ):
        self.visibleSections = visibleSections
        self.hiddenSections = hiddenSections

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.visibleSections = []
                    (_etype107, _size110) = iprot.readListBegin()
                    for _i108 in range(_size110):
                        _elem109 = PresentationalSectionSettings()
                        _elem109.read(iprot)
                        self.visibleSections.append(_elem109)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.hiddenSections = []
                    (_etype111, _size114) = iprot.readListBegin()
                    for _i112 in range(_size114):
                        _elem113 = PresentationalSectionSettings()
                        _elem113.read(iprot)
                        self.hiddenSections.append(_elem113)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PresentationalSettings')
        if self.visibleSections is not None:
            oprot.writeFieldBegin('visibleSections', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.visibleSections))
            for _iter115 in self.visibleSections:
                _iter115.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.hiddenSections is not None:
            oprot.writeFieldBegin('hiddenSections', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.hiddenSections))
            for _iter116 in self.hiddenSections:
                _iter116.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AgentInputs(object):
    """
    Attributes:
     - title
     - agentIds
     - clientIds
     - subjectProperty
     - compSearchParams
     - compIds
     - appliedAdjustments
     - price
     - remarks
     - adjustmentFeedback
     - assets
     - compSearchQuery
     - isManualCompsSearch
     - selectListingAttributes
     - compsNotes
     - compsOrder
     - upgradeRecommendation
     - origDisplayListings
     - editedDisplayListings
     - lotSizeUnit
     - presentationalSettings
     - customListings
     - comps
     - chartQuery
     - marketReportSettings
     - netsheets
     - priceEstimateFeedback
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'agentIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'clientIds', (TType.STRUCT, (CmaClient, CmaClient.thrift_spec), False), None, ),  # 3
        (4, TType.STRUCT, 'subjectProperty', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 4
        (5, TType.MAP, 'compSearchParams', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.LIST, 'compIds', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.MAP, 'appliedAdjustments', (TType.STRING, 'UTF8', TType.LIST, (TType.STRUCT, (gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.Adjustment, gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.Adjustment.thrift_spec), False), False), None, ),  # 7
        (8, TType.STRUCT, 'price', (PriceEstimate, PriceEstimate.thrift_spec), None, ),  # 8
        (9, TType.STRING, 'remarks', 'UTF8', None, ),  # 9
        (10, TType.MAP, 'adjustmentFeedback', (TType.STRING, 'UTF8', TType.STRUCT, (gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.AdjustmentFeedback, gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.AdjustmentFeedback.thrift_spec), False), None, ),  # 10
        (11, TType.LIST, 'assets', (TType.STRUCT, (gen.urbancompass.asset_library.asset_library_models.ttypes.Asset, gen.urbancompass.asset_library.asset_library_models.ttypes.Asset.thrift_spec), False), None, ),  # 11
        (12, TType.STRUCT, 'compSearchQuery', (gen.urbancompass.search.search.ttypes.SearchQuery, gen.urbancompass.search.search.ttypes.SearchQuery.thrift_spec), None, ),  # 12
        (13, TType.BOOL, 'isManualCompsSearch', None, None, ),  # 13
        (14, TType.LIST, 'selectListingAttributes', (TType.STRUCT, (CustomListingAttribute, CustomListingAttribute.thrift_spec), False), None, ),  # 14
        (15, TType.MAP, 'compsNotes', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 15
        (16, TType.I32, 'compsOrder', None, None, ),  # 16
        (17, TType.STRUCT, 'upgradeRecommendation', (UpgradeRecommendation, UpgradeRecommendation.thrift_spec), None, ),  # 17
        (18, TType.MAP, 'origDisplayListings', (TType.STRING, 'UTF8', TType.STRUCT, (DisplayListing, DisplayListing.thrift_spec), False), None, ),  # 18
        (19, TType.MAP, 'editedDisplayListings', (TType.STRING, 'UTF8', TType.STRUCT, (DisplayListing, DisplayListing.thrift_spec), False), None, ),  # 19
        (20, TType.I32, 'lotSizeUnit', None, None, ),  # 20
        (21, TType.STRUCT, 'presentationalSettings', (PresentationalSettings, PresentationalSettings.thrift_spec), None, ),  # 21
        (22, TType.LIST, 'customListings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 22
        (23, TType.LIST, 'comps', (TType.STRUCT, (Comp, Comp.thrift_spec), False), None, ),  # 23
        (24, TType.STRUCT, 'chartQuery', (gen.urbancompass.trend_chart.trend_chart_service.ttypes.QueryParams, gen.urbancompass.trend_chart.trend_chart_service.ttypes.QueryParams.thrift_spec), None, ),  # 24
        (25, TType.STRUCT, 'marketReportSettings', (MarketReportSettings, MarketReportSettings.thrift_spec), None, ),  # 25
        (26, TType.STRUCT, 'netsheets', (NetSheets, NetSheets.thrift_spec), None, ),  # 26
        (27, TType.STRUCT, 'priceEstimateFeedback', (PriceEstimateFeedback, PriceEstimateFeedback.thrift_spec), None, ),  # 27
    )
    def __init__(self, title=None, agentIds=None, clientIds=None, subjectProperty=None, compSearchParams=None, compIds=None, appliedAdjustments=None, price=None, remarks=None, adjustmentFeedback=None, assets=None, compSearchQuery=None, isManualCompsSearch=None, selectListingAttributes=None, compsNotes=None, compsOrder=None, upgradeRecommendation=None, origDisplayListings=None, editedDisplayListings=None, lotSizeUnit=None, presentationalSettings=None, customListings=None, comps=None, chartQuery=None, marketReportSettings=None, netsheets=None, priceEstimateFeedback=None, ):
        self.title = title
        self.agentIds = agentIds
        self.clientIds = clientIds
        self.subjectProperty = subjectProperty
        self.compSearchParams = compSearchParams
        self.compIds = compIds
        self.appliedAdjustments = appliedAdjustments
        self.price = price
        self.remarks = remarks
        self.adjustmentFeedback = adjustmentFeedback
        self.assets = assets
        self.compSearchQuery = compSearchQuery
        self.isManualCompsSearch = isManualCompsSearch
        self.selectListingAttributes = selectListingAttributes
        self.compsNotes = compsNotes
        self.compsOrder = compsOrder
        self.upgradeRecommendation = upgradeRecommendation
        self.origDisplayListings = origDisplayListings
        self.editedDisplayListings = editedDisplayListings
        self.lotSizeUnit = lotSizeUnit
        self.presentationalSettings = presentationalSettings
        self.customListings = customListings
        self.comps = comps
        self.chartQuery = chartQuery
        self.marketReportSettings = marketReportSettings
        self.netsheets = netsheets
        self.priceEstimateFeedback = priceEstimateFeedback

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.agentIds = []
                    (_etype117, _size120) = iprot.readListBegin()
                    for _i118 in range(_size120):
                        _elem119 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.agentIds.append(_elem119)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.clientIds = []
                    (_etype121, _size124) = iprot.readListBegin()
                    for _i122 in range(_size124):
                        _elem123 = CmaClient()
                        _elem123.read(iprot)
                        self.clientIds.append(_elem123)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.subjectProperty = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.subjectProperty.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.MAP:
                    self.compSearchParams = {}
                    (_ktype126, _vtype127, _size130) = iprot.readMapBegin()
                    for _i125 in range(_size130):
                        _key128 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val129 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.compSearchParams[_key128] = _val129
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.compIds = []
                    (_etype131, _size134) = iprot.readListBegin()
                    for _i132 in range(_size134):
                        _elem133 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.compIds.append(_elem133)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.MAP:
                    self.appliedAdjustments = {}
                    (_ktype136, _vtype137, _size140) = iprot.readMapBegin()
                    for _i135 in range(_size140):
                        _key138 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val139 = []
                        (_etype141, _size144) = iprot.readListBegin()
                        for _i142 in range(_size144):
                            _elem143 = gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.Adjustment()
                            _elem143.read(iprot)
                            _val139.append(_elem143)
                        iprot.readListEnd()
                        self.appliedAdjustments[_key138] = _val139
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.price = PriceEstimate()
                    self.price.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.remarks = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.MAP:
                    self.adjustmentFeedback = {}
                    (_ktype146, _vtype147, _size150) = iprot.readMapBegin()
                    for _i145 in range(_size150):
                        _key148 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val149 = gen.urbancompass.valuation.ai_valuation.adjustments.ttypes.AdjustmentFeedback()
                        _val149.read(iprot)
                        self.adjustmentFeedback[_key148] = _val149
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.assets = []
                    (_etype151, _size154) = iprot.readListBegin()
                    for _i152 in range(_size154):
                        _elem153 = gen.urbancompass.asset_library.asset_library_models.ttypes.Asset()
                        _elem153.read(iprot)
                        self.assets.append(_elem153)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.compSearchQuery = gen.urbancompass.search.search.ttypes.SearchQuery()
                    self.compSearchQuery.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isManualCompsSearch = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.selectListingAttributes = []
                    (_etype155, _size158) = iprot.readListBegin()
                    for _i156 in range(_size158):
                        _elem157 = CustomListingAttribute()
                        _elem157.read(iprot)
                        self.selectListingAttributes.append(_elem157)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.MAP:
                    self.compsNotes = {}
                    (_ktype160, _vtype161, _size164) = iprot.readMapBegin()
                    for _i159 in range(_size164):
                        _key162 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val163 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.compsNotes[_key162] = _val163
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.compsOrder = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRUCT:
                    self.upgradeRecommendation = UpgradeRecommendation()
                    self.upgradeRecommendation.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.MAP:
                    self.origDisplayListings = {}
                    (_ktype166, _vtype167, _size170) = iprot.readMapBegin()
                    for _i165 in range(_size170):
                        _key168 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val169 = DisplayListing()
                        _val169.read(iprot)
                        self.origDisplayListings[_key168] = _val169
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.MAP:
                    self.editedDisplayListings = {}
                    (_ktype172, _vtype173, _size176) = iprot.readMapBegin()
                    for _i171 in range(_size176):
                        _key174 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val175 = DisplayListing()
                        _val175.read(iprot)
                        self.editedDisplayListings[_key174] = _val175
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.lotSizeUnit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRUCT:
                    self.presentationalSettings = PresentationalSettings()
                    self.presentationalSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.LIST:
                    self.customListings = []
                    (_etype177, _size180) = iprot.readListBegin()
                    for _i178 in range(_size180):
                        _elem179 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem179.read(iprot)
                        self.customListings.append(_elem179)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.LIST:
                    self.comps = []
                    (_etype181, _size184) = iprot.readListBegin()
                    for _i182 in range(_size184):
                        _elem183 = Comp()
                        _elem183.read(iprot)
                        self.comps.append(_elem183)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.chartQuery = gen.urbancompass.trend_chart.trend_chart_service.ttypes.QueryParams()
                    self.chartQuery.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.STRUCT:
                    self.marketReportSettings = MarketReportSettings()
                    self.marketReportSettings.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRUCT:
                    self.netsheets = NetSheets()
                    self.netsheets.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRUCT:
                    self.priceEstimateFeedback = PriceEstimateFeedback()
                    self.priceEstimateFeedback.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AgentInputs')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.agentIds is not None:
            oprot.writeFieldBegin('agentIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.agentIds))
            for _iter185 in self.agentIds:
                oprot.writeString(_iter185.encode('utf-8') if sys.version_info[0] == 2 else _iter185)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.clientIds is not None:
            oprot.writeFieldBegin('clientIds', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.clientIds))
            for _iter186 in self.clientIds:
                _iter186.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.subjectProperty is not None:
            oprot.writeFieldBegin('subjectProperty', TType.STRUCT, 4)
            self.subjectProperty.write(oprot)
            oprot.writeFieldEnd()
        if self.compSearchParams is not None:
            oprot.writeFieldBegin('compSearchParams', TType.MAP, 5)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.compSearchParams))
            for _kiter187, _viter188 in self.compSearchParams.items():
                oprot.writeString(_kiter187.encode('utf-8') if sys.version_info[0] == 2 else _kiter187)
                oprot.writeString(_viter188.encode('utf-8') if sys.version_info[0] == 2 else _viter188)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.compIds is not None:
            oprot.writeFieldBegin('compIds', TType.LIST, 6)
            oprot.writeListBegin(TType.STRING, len(self.compIds))
            for _iter189 in self.compIds:
                oprot.writeString(_iter189.encode('utf-8') if sys.version_info[0] == 2 else _iter189)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.appliedAdjustments is not None:
            oprot.writeFieldBegin('appliedAdjustments', TType.MAP, 7)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.appliedAdjustments))
            for _kiter190, _viter191 in self.appliedAdjustments.items():
                oprot.writeString(_kiter190.encode('utf-8') if sys.version_info[0] == 2 else _kiter190)
                oprot.writeListBegin(TType.STRUCT, len(_viter191))
                for _iter192 in _viter191:
                    _iter192.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.price is not None:
            oprot.writeFieldBegin('price', TType.STRUCT, 8)
            self.price.write(oprot)
            oprot.writeFieldEnd()
        if self.remarks is not None:
            oprot.writeFieldBegin('remarks', TType.STRING, 9)
            oprot.writeString(self.remarks.encode('utf-8') if sys.version_info[0] == 2 else self.remarks)
            oprot.writeFieldEnd()
        if self.adjustmentFeedback is not None:
            oprot.writeFieldBegin('adjustmentFeedback', TType.MAP, 10)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.adjustmentFeedback))
            for _kiter193, _viter194 in self.adjustmentFeedback.items():
                oprot.writeString(_kiter193.encode('utf-8') if sys.version_info[0] == 2 else _kiter193)
                _viter194.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.assets is not None:
            oprot.writeFieldBegin('assets', TType.LIST, 11)
            oprot.writeListBegin(TType.STRUCT, len(self.assets))
            for _iter195 in self.assets:
                _iter195.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.compSearchQuery is not None:
            oprot.writeFieldBegin('compSearchQuery', TType.STRUCT, 12)
            self.compSearchQuery.write(oprot)
            oprot.writeFieldEnd()
        if self.isManualCompsSearch is not None:
            oprot.writeFieldBegin('isManualCompsSearch', TType.BOOL, 13)
            oprot.writeBool(self.isManualCompsSearch)
            oprot.writeFieldEnd()
        if self.selectListingAttributes is not None:
            oprot.writeFieldBegin('selectListingAttributes', TType.LIST, 14)
            oprot.writeListBegin(TType.STRUCT, len(self.selectListingAttributes))
            for _iter196 in self.selectListingAttributes:
                _iter196.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.compsNotes is not None:
            oprot.writeFieldBegin('compsNotes', TType.MAP, 15)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.compsNotes))
            for _kiter197, _viter198 in self.compsNotes.items():
                oprot.writeString(_kiter197.encode('utf-8') if sys.version_info[0] == 2 else _kiter197)
                oprot.writeString(_viter198.encode('utf-8') if sys.version_info[0] == 2 else _viter198)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.compsOrder is not None:
            oprot.writeFieldBegin('compsOrder', TType.I32, 16)
            oprot.writeI32(self.compsOrder)
            oprot.writeFieldEnd()
        if self.upgradeRecommendation is not None:
            oprot.writeFieldBegin('upgradeRecommendation', TType.STRUCT, 17)
            self.upgradeRecommendation.write(oprot)
            oprot.writeFieldEnd()
        if self.origDisplayListings is not None:
            oprot.writeFieldBegin('origDisplayListings', TType.MAP, 18)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.origDisplayListings))
            for _kiter199, _viter200 in self.origDisplayListings.items():
                oprot.writeString(_kiter199.encode('utf-8') if sys.version_info[0] == 2 else _kiter199)
                _viter200.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.editedDisplayListings is not None:
            oprot.writeFieldBegin('editedDisplayListings', TType.MAP, 19)
            oprot.writeMapBegin(TType.STRING, TType.STRUCT, len(self.editedDisplayListings))
            for _kiter201, _viter202 in self.editedDisplayListings.items():
                oprot.writeString(_kiter201.encode('utf-8') if sys.version_info[0] == 2 else _kiter201)
                _viter202.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.lotSizeUnit is not None:
            oprot.writeFieldBegin('lotSizeUnit', TType.I32, 20)
            oprot.writeI32(self.lotSizeUnit)
            oprot.writeFieldEnd()
        if self.presentationalSettings is not None:
            oprot.writeFieldBegin('presentationalSettings', TType.STRUCT, 21)
            self.presentationalSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.customListings is not None:
            oprot.writeFieldBegin('customListings', TType.LIST, 22)
            oprot.writeListBegin(TType.STRUCT, len(self.customListings))
            for _iter203 in self.customListings:
                _iter203.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.comps is not None:
            oprot.writeFieldBegin('comps', TType.LIST, 23)
            oprot.writeListBegin(TType.STRUCT, len(self.comps))
            for _iter204 in self.comps:
                _iter204.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.chartQuery is not None:
            oprot.writeFieldBegin('chartQuery', TType.STRUCT, 24)
            self.chartQuery.write(oprot)
            oprot.writeFieldEnd()
        if self.marketReportSettings is not None:
            oprot.writeFieldBegin('marketReportSettings', TType.STRUCT, 25)
            self.marketReportSettings.write(oprot)
            oprot.writeFieldEnd()
        if self.netsheets is not None:
            oprot.writeFieldBegin('netsheets', TType.STRUCT, 26)
            self.netsheets.write(oprot)
            oprot.writeFieldEnd()
        if self.priceEstimateFeedback is not None:
            oprot.writeFieldBegin('priceEstimateFeedback', TType.STRUCT, 27)
            self.priceEstimateFeedback.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Cma(object):
    """
    Attributes:
     - cmaId
     - version
     - subjectProperty
     - compListings
     - metadata
     - agentInputs
     - aiInputs
     - compsBuilderInputs
     - agents
     - clients
     - owner
     - marketReportChartsItems
     - marketReportMetricsItems
     - marketReportDisclaimer
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'cmaId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'version', 'UTF8', None, ),  # 2
        (3, TType.STRUCT, 'subjectProperty', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'compListings', (TType.STRUCT, (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), False), None, ),  # 4
        (5, TType.STRUCT, 'metadata', (Metadata, Metadata.thrift_spec), None, ),  # 5
        (6, TType.STRUCT, 'agentInputs', (AgentInputs, AgentInputs.thrift_spec), None, ),  # 6
        (7, TType.STRUCT, 'aiInputs', (AIInputs, AIInputs.thrift_spec), None, ),  # 7
        (8, TType.STRUCT, 'compsBuilderInputs', (CompsBuilderInputs, CompsBuilderInputs.thrift_spec), None, ),  # 8
        (9, TType.LIST, 'agents', (TType.STRUCT, (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), False), None, ),  # 9
        (10, TType.LIST, 'clients', (TType.STRUCT, (gen.urbancompass.contacts.api.contact.ttypes.Contact, gen.urbancompass.contacts.api.contact.ttypes.Contact.thrift_spec), False), None, ),  # 10
        (11, TType.STRUCT, 'owner', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 11
        (12, TType.MAP, 'marketReportChartsItems', (TType.I32, None, TType.LIST, (TType.STRUCT, (gen.urbancompass.trend_chart.trend_chart_service.ttypes.XYChartItem, gen.urbancompass.trend_chart.trend_chart_service.ttypes.XYChartItem.thrift_spec), False), False), None, ),  # 12
        (13, TType.MAP, 'marketReportMetricsItems', (TType.I32, None, TType.LIST, (TType.STRUCT, (gen.urbancompass.trend_chart.trend_chart_service.ttypes.XYChartItem, gen.urbancompass.trend_chart.trend_chart_service.ttypes.XYChartItem.thrift_spec), False), False), None, ),  # 13
        (14, TType.STRUCT, 'marketReportDisclaimer', (gen.urbancompass.trend_chart.trend_chart_service.ttypes.DisclaimerResponse, gen.urbancompass.trend_chart.trend_chart_service.ttypes.DisclaimerResponse.thrift_spec), None, ),  # 14
    )
    def __init__(self, cmaId=None, version=None, subjectProperty=None, compListings=None, metadata=None, agentInputs=None, aiInputs=None, compsBuilderInputs=None, agents=None, clients=None, owner=None, marketReportChartsItems=None, marketReportMetricsItems=None, marketReportDisclaimer=None, ):
        self.cmaId = cmaId
        self.version = version
        self.subjectProperty = subjectProperty
        self.compListings = compListings
        self.metadata = metadata
        self.agentInputs = agentInputs
        self.aiInputs = aiInputs
        self.compsBuilderInputs = compsBuilderInputs
        self.agents = agents
        self.clients = clients
        self.owner = owner
        self.marketReportChartsItems = marketReportChartsItems
        self.marketReportMetricsItems = marketReportMetricsItems
        self.marketReportDisclaimer = marketReportDisclaimer

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.cmaId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.version = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.subjectProperty = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.subjectProperty.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.compListings = []
                    (_etype205, _size208) = iprot.readListBegin()
                    for _i206 in range(_size208):
                        _elem207 = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                        _elem207.read(iprot)
                        self.compListings.append(_elem207)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.metadata = Metadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.agentInputs = AgentInputs()
                    self.agentInputs.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.aiInputs = AIInputs()
                    self.aiInputs.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRUCT:
                    self.compsBuilderInputs = CompsBuilderInputs()
                    self.compsBuilderInputs.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.agents = []
                    (_etype209, _size212) = iprot.readListBegin()
                    for _i210 in range(_size212):
                        _elem211 = gen.urbancompass.people.api.person.ttypes.Person()
                        _elem211.read(iprot)
                        self.agents.append(_elem211)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.clients = []
                    (_etype213, _size216) = iprot.readListBegin()
                    for _i214 in range(_size216):
                        _elem215 = gen.urbancompass.contacts.api.contact.ttypes.Contact()
                        _elem215.read(iprot)
                        self.clients.append(_elem215)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRUCT:
                    self.owner = gen.urbancompass.people.api.person.ttypes.Person()
                    self.owner.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.MAP:
                    self.marketReportChartsItems = {}
                    (_ktype218, _vtype219, _size222) = iprot.readMapBegin()
                    for _i217 in range(_size222):
                        _key220 = iprot.readI32()
                        _val221 = []
                        (_etype223, _size226) = iprot.readListBegin()
                        for _i224 in range(_size226):
                            _elem225 = gen.urbancompass.trend_chart.trend_chart_service.ttypes.XYChartItem()
                            _elem225.read(iprot)
                            _val221.append(_elem225)
                        iprot.readListEnd()
                        self.marketReportChartsItems[_key220] = _val221
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.MAP:
                    self.marketReportMetricsItems = {}
                    (_ktype228, _vtype229, _size232) = iprot.readMapBegin()
                    for _i227 in range(_size232):
                        _key230 = iprot.readI32()
                        _val231 = []
                        (_etype233, _size236) = iprot.readListBegin()
                        for _i234 in range(_size236):
                            _elem235 = gen.urbancompass.trend_chart.trend_chart_service.ttypes.XYChartItem()
                            _elem235.read(iprot)
                            _val231.append(_elem235)
                        iprot.readListEnd()
                        self.marketReportMetricsItems[_key230] = _val231
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.marketReportDisclaimer = gen.urbancompass.trend_chart.trend_chart_service.ttypes.DisclaimerResponse()
                    self.marketReportDisclaimer.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Cma')
        if self.cmaId is not None:
            oprot.writeFieldBegin('cmaId', TType.STRING, 1)
            oprot.writeString(self.cmaId.encode('utf-8') if sys.version_info[0] == 2 else self.cmaId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.STRING, 2)
            oprot.writeString(self.version.encode('utf-8') if sys.version_info[0] == 2 else self.version)
            oprot.writeFieldEnd()
        if self.subjectProperty is not None:
            oprot.writeFieldBegin('subjectProperty', TType.STRUCT, 3)
            self.subjectProperty.write(oprot)
            oprot.writeFieldEnd()
        if self.compListings is not None:
            oprot.writeFieldBegin('compListings', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.compListings))
            for _iter237 in self.compListings:
                _iter237.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 5)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.agentInputs is not None:
            oprot.writeFieldBegin('agentInputs', TType.STRUCT, 6)
            self.agentInputs.write(oprot)
            oprot.writeFieldEnd()
        if self.aiInputs is not None:
            oprot.writeFieldBegin('aiInputs', TType.STRUCT, 7)
            self.aiInputs.write(oprot)
            oprot.writeFieldEnd()
        if self.compsBuilderInputs is not None:
            oprot.writeFieldBegin('compsBuilderInputs', TType.STRUCT, 8)
            self.compsBuilderInputs.write(oprot)
            oprot.writeFieldEnd()
        if self.agents is not None:
            oprot.writeFieldBegin('agents', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.agents))
            for _iter238 in self.agents:
                _iter238.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.clients is not None:
            oprot.writeFieldBegin('clients', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.clients))
            for _iter239 in self.clients:
                _iter239.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.owner is not None:
            oprot.writeFieldBegin('owner', TType.STRUCT, 11)
            self.owner.write(oprot)
            oprot.writeFieldEnd()
        if self.marketReportChartsItems is not None:
            oprot.writeFieldBegin('marketReportChartsItems', TType.MAP, 12)
            oprot.writeMapBegin(TType.I32, TType.LIST, len(self.marketReportChartsItems))
            for _kiter240, _viter241 in self.marketReportChartsItems.items():
                oprot.writeI32(_kiter240)
                oprot.writeListBegin(TType.STRUCT, len(_viter241))
                for _iter242 in _viter241:
                    _iter242.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.marketReportMetricsItems is not None:
            oprot.writeFieldBegin('marketReportMetricsItems', TType.MAP, 13)
            oprot.writeMapBegin(TType.I32, TType.LIST, len(self.marketReportMetricsItems))
            for _kiter243, _viter244 in self.marketReportMetricsItems.items():
                oprot.writeI32(_kiter243)
                oprot.writeListBegin(TType.STRUCT, len(_viter244))
                for _iter245 in _viter244:
                    _iter245.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.marketReportDisclaimer is not None:
            oprot.writeFieldBegin('marketReportDisclaimer', TType.STRUCT, 14)
            self.marketReportDisclaimer.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
