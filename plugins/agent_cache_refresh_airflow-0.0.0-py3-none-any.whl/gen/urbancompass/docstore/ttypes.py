
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.permissions.acl.ttypes
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.deals.deals_summary.ttypes
import gen.urbancompass.profile.ttypes
import gen.urbancompass.user.user.ttypes

from thrift.transport import TTransport


class AppId(object):
    VALUATION = 0
    SHOWSHEET = 1
    CUSTOM_BOUNDS = 2
    PITCH = 3
    TOURSHEET = 4
    BOARD_DRAFTS = 5
    DESIGN_STUDIO = 6
    BRIEF = 7
    DESIGN_STUDIO_DOCUMENT = 8
    DESIGN_STUDIO_TEMPLATE = 9
    VALUATION_CMA_REPORT = 10
    DESIGN_STUDIO_VIDEO = 11

    _VALUES_TO_NAMES = {
        0: "VALUATION",
        1: "SHOWSHEET",
        2: "CUSTOM_BOUNDS",
        3: "PITCH",
        4: "TOURSHEET",
        5: "BOARD_DRAFTS",
        6: "DESIGN_STUDIO",
        7: "BRIEF",
        8: "DESIGN_STUDIO_DOCUMENT",
        9: "DESIGN_STUDIO_TEMPLATE",
        10: "VALUATION_CMA_REPORT",
        11: "DESIGN_STUDIO_VIDEO",
    }

    _NAMES_TO_VALUES = {
        "VALUATION": 0,
        "SHOWSHEET": 1,
        "CUSTOM_BOUNDS": 2,
        "PITCH": 3,
        "TOURSHEET": 4,
        "BOARD_DRAFTS": 5,
        "DESIGN_STUDIO": 6,
        "BRIEF": 7,
        "DESIGN_STUDIO_DOCUMENT": 8,
        "DESIGN_STUDIO_TEMPLATE": 9,
        "VALUATION_CMA_REPORT": 10,
        "DESIGN_STUDIO_VIDEO": 11,
    }


class CollateralsSortableFields(object):
    ID = 0
    TITLE = 1
    CREATED_AT = 2
    CREATED_BY = 3
    UPDATED_AT = 4
    UPDATED_BY = 5
    COLLATERAL_TYPE = 6

    _VALUES_TO_NAMES = {
        0: "ID",
        1: "TITLE",
        2: "CREATED_AT",
        3: "CREATED_BY",
        4: "UPDATED_AT",
        5: "UPDATED_BY",
        6: "COLLATERAL_TYPE",
    }

    _NAMES_TO_VALUES = {
        "ID": 0,
        "TITLE": 1,
        "CREATED_AT": 2,
        "CREATED_BY": 3,
        "UPDATED_AT": 4,
        "UPDATED_BY": 5,
        "COLLATERAL_TYPE": 6,
    }


class DocumentType(object):
    STANDARD = 0
    PUBLIC = 1

    _VALUES_TO_NAMES = {
        0: "STANDARD",
        1: "PUBLIC",
    }

    _NAMES_TO_VALUES = {
        "STANDARD": 0,
        "PUBLIC": 1,
    }


class SortField(object):
    TITLE = 0
    CREATED_AT = 1
    UPDATED_AT = 2
    DETAIL = 3
    APP = 4
    TAG = 5
    DELETED_AT = 6

    _VALUES_TO_NAMES = {
        0: "TITLE",
        1: "CREATED_AT",
        2: "UPDATED_AT",
        3: "DETAIL",
        4: "APP",
        5: "TAG",
        6: "DELETED_AT",
    }

    _NAMES_TO_VALUES = {
        "TITLE": 0,
        "CREATED_AT": 1,
        "UPDATED_AT": 2,
        "DETAIL": 3,
        "APP": 4,
        "TAG": 5,
        "DELETED_AT": 6,
    }


class TagOperator(object):
    AND = 0
    OR = 1

    _VALUES_TO_NAMES = {
        0: "AND",
        1: "OR",
    }

    _NAMES_TO_VALUES = {
        "AND": 0,
        "OR": 1,
    }


class CollateralsGroupValue(object):
    """
    Attributes:
     - templatePublishDetailsCategory
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'templatePublishDetailsCategory', 'UTF8', None, ),  # 1
    )
    def __init__(self, templatePublishDetailsCategory=None, ):
        self.templatePublishDetailsCategory = templatePublishDetailsCategory

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.templatePublishDetailsCategory = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CollateralsGroupValue')
        if self.templatePublishDetailsCategory is not None:
            oprot.writeFieldBegin('templatePublishDetailsCategory', TType.STRING, 1)
            oprot.writeString(self.templatePublishDetailsCategory.encode('utf-8') if sys.version_info[0] == 2 else self.templatePublishDetailsCategory)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CollateralsSort(object):
    """
    Attributes:
     - orderBy
     - orderAsc
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'orderBy', None, None, ),  # 1
        (2, TType.BOOL, 'orderAsc', None, None, ),  # 2
    )
    def __init__(self, orderBy=None, orderAsc=None, ):
        self.orderBy = orderBy
        self.orderAsc = orderAsc

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.orderAsc = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CollateralsSort')
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 1)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.orderAsc is not None:
            oprot.writeFieldBegin('orderAsc', TType.BOOL, 2)
            oprot.writeBool(self.orderAsc)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Customer(object):
    """
    Attributes:
     - profile
     - createdAt
     - createdByUserId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'profile', (gen.urbancompass.profile.ttypes.Entity, gen.urbancompass.profile.ttypes.Entity.thrift_spec), None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 3
    )
    def __init__(self, profile=None, createdAt=None, createdByUserId=None, ):
        self.profile = profile
        self.createdAt = createdAt
        self.createdByUserId = createdByUserId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.profile = gen.urbancompass.profile.ttypes.Entity()
                    self.profile.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Customer')
        if self.profile is not None:
            oprot.writeFieldBegin('profile', TType.STRUCT, 1)
            self.profile.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 3)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDocumentRequest(object):
    """
    Attributes:
     - requesterId
     - documentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
    )
    def __init__(self, requesterId=None, documentId=None, ):
        self.requesterId = requesterId
        self.documentId = documentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDocumentRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DeleteDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DeleteDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DocumentCopy(object):
    """
    Attributes:
     - sourceDocumentId
     - newName
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'sourceDocumentId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'newName', 'UTF8', None, ),  # 2
    )
    def __init__(self, sourceDocumentId=None, newName=None, ):
        self.sourceDocumentId = sourceDocumentId
        self.newName = newName

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.sourceDocumentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.newName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DocumentCopy')
        if self.sourceDocumentId is not None:
            oprot.writeFieldBegin('sourceDocumentId', TType.STRING, 1)
            oprot.writeString(self.sourceDocumentId.encode('utf-8') if sys.version_info[0] == 2 else self.sourceDocumentId)
            oprot.writeFieldEnd()
        if self.newName is not None:
            oprot.writeFieldBegin('newName', TType.STRING, 2)
            oprot.writeString(self.newName.encode('utf-8') if sys.version_info[0] == 2 else self.newName)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReadDocumentRequest(object):
    """
    Attributes:
     - requesterId
     - documentId
     - isAdmin
     - roles
     - includeDealSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'isAdmin', None, None, ),  # 3
        (4, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.BOOL, 'includeDealSummary', None, None, ),  # 100
    )
    def __init__(self, requesterId=None, documentId=None, isAdmin=None, roles=None, includeDealSummary=None, ):
        self.requesterId = requesterId
        self.documentId = documentId
        self.isAdmin = isAdmin
        self.roles = roles
        self.includeDealSummary = includeDealSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isAdmin = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = gen.urbancompass.user.user.ttypes.Role()
                        _elem4.read(iprot)
                        self.roles.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.BOOL:
                    self.includeDealSummary = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReadDocumentRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.isAdmin is not None:
            oprot.writeFieldBegin('isAdmin', TType.BOOL, 3)
            oprot.writeBool(self.isAdmin)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter6 in self.roles:
                _iter6.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeDealSummary is not None:
            oprot.writeFieldBegin('includeDealSummary', TType.BOOL, 100)
            oprot.writeBool(self.includeDealSummary)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReadDocumentsRequest(object):
    """
    Attributes:
     - requesterId
     - documentIds
     - isAdmin
     - roles
     - includeDealSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'documentIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.BOOL, 'isAdmin', None, None, ),  # 3
        (4, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.BOOL, 'includeDealSummary', None, None, ),  # 100
    )
    def __init__(self, requesterId=None, documentIds=None, isAdmin=None, roles=None, includeDealSummary=None, ):
        self.requesterId = requesterId
        self.documentIds = documentIds
        self.isAdmin = isAdmin
        self.roles = roles
        self.includeDealSummary = includeDealSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.documentIds = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.documentIds.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.isAdmin = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype11, _size14) = iprot.readListBegin()
                    for _i12 in range(_size14):
                        _elem13 = gen.urbancompass.user.user.ttypes.Role()
                        _elem13.read(iprot)
                        self.roles.append(_elem13)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.BOOL:
                    self.includeDealSummary = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReadDocumentsRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.documentIds is not None:
            oprot.writeFieldBegin('documentIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.documentIds))
            for _iter15 in self.documentIds:
                oprot.writeString(_iter15.encode('utf-8') if sys.version_info[0] == 2 else _iter15)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.isAdmin is not None:
            oprot.writeFieldBegin('isAdmin', TType.BOOL, 3)
            oprot.writeBool(self.isAdmin)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter16 in self.roles:
                _iter16.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeDealSummary is not None:
            oprot.writeFieldBegin('includeDealSummary', TType.BOOL, 100)
            oprot.writeBool(self.includeDealSummary)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RestoreDocumentRequest(object):
    """
    Attributes:
     - requesterId
     - documentId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
    )
    def __init__(self, requesterId=None, documentId=None, ):
        self.requesterId = requesterId
        self.documentId = documentId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RestoreDocumentRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RestoreDocumentResponse(object):
    """
    Attributes:
     - status
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
    )
    def __init__(self, status=None, ):
        self.status = status

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RestoreDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Tag(object):
    """
    Attributes:
     - key
     - value
     - noCopy
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'key', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'value', 'UTF8', None, ),  # 2
        (3, TType.BOOL, 'noCopy', None, None, ),  # 3
    )
    def __init__(self, key=None, value=None, noCopy=None, ):
        self.key = key
        self.value = value
        self.noCopy = noCopy

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.key = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.value = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.BOOL:
                    self.noCopy = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Tag')
        if self.key is not None:
            oprot.writeFieldBegin('key', TType.STRING, 1)
            oprot.writeString(self.key.encode('utf-8') if sys.version_info[0] == 2 else self.key)
            oprot.writeFieldEnd()
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRING, 2)
            oprot.writeString(self.value.encode('utf-8') if sys.version_info[0] == 2 else self.value)
            oprot.writeFieldEnd()
        if self.noCopy is not None:
            oprot.writeFieldBegin('noCopy', TType.BOOL, 3)
            oprot.writeBool(self.noCopy)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CollateralsGroup(object):
    """
    Attributes:
     - value
     - sortOrder
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'value', (CollateralsGroupValue, CollateralsGroupValue.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'sortOrder', (TType.STRUCT, (CollateralsSort, CollateralsSort.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, value=None, sortOrder=None, ):
        self.value = value
        self.sortOrder = sortOrder

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.value = CollateralsGroupValue()
                    self.value.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.sortOrder = []
                    (_etype17, _size20) = iprot.readListBegin()
                    for _i18 in range(_size20):
                        _elem19 = CollateralsSort()
                        _elem19.read(iprot)
                        self.sortOrder.append(_elem19)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CollateralsGroup')
        if self.value is not None:
            oprot.writeFieldBegin('value', TType.STRUCT, 1)
            self.value.write(oprot)
            oprot.writeFieldEnd()
        if self.sortOrder is not None:
            oprot.writeFieldBegin('sortOrder', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.sortOrder))
            for _iter21 in self.sortOrder:
                _iter21.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CopyDocumentRequest(object):
    """
    Attributes:
     - requesterId
     - sourceDocumentIds
     - copies
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.LIST, 'sourceDocumentIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'copies', (TType.STRUCT, (DocumentCopy, DocumentCopy.thrift_spec), False), None, ),  # 3
    )
    def __init__(self, requesterId=None, sourceDocumentIds=None, copies=None, ):
        self.requesterId = requesterId
        self.sourceDocumentIds = sourceDocumentIds
        self.copies = copies

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.sourceDocumentIds = []
                    (_etype22, _size25) = iprot.readListBegin()
                    for _i23 in range(_size25):
                        _elem24 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.sourceDocumentIds.append(_elem24)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.copies = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = DocumentCopy()
                        _elem28.read(iprot)
                        self.copies.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CopyDocumentRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.sourceDocumentIds is not None:
            oprot.writeFieldBegin('sourceDocumentIds', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.sourceDocumentIds))
            for _iter30 in self.sourceDocumentIds:
                oprot.writeString(_iter30.encode('utf-8') if sys.version_info[0] == 2 else _iter30)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.copies is not None:
            oprot.writeFieldBegin('copies', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.copies))
            for _iter31 in self.copies:
                _iter31.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DocumentMetadata(object):
    """
    Attributes:
     - _id
     - appId
     - title
     - acl
     - detail
     - createdAt
     - updatedAt
     - deletedAt
     - createdByUserId
     - updatedByUserId
     - deletedByUserId
     - customers
     - indexedText
     - tags
     - isPublic
     - dealSummary
     - dealSummaries
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'appId', None, None, ),  # 2
        (3, TType.STRING, 'title', 'UTF8', None, ),  # 3
        (4, TType.SET, 'acl', (TType.STRUCT, (gen.urbancompass.permissions.acl.ttypes.ACLEntry, gen.urbancompass.permissions.acl.ttypes.ACLEntry.thrift_spec), False), None, ),  # 4
        (5, TType.STRING, 'detail', 'UTF8', None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'updatedAt', None, None, ),  # 7
        (8, TType.STRING, 'createdByUserId', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'updatedByUserId', 'UTF8', None, ),  # 9
        (10, TType.SET, 'customers', (TType.STRUCT, (Customer, Customer.thrift_spec), False), None, ),  # 10
        (11, TType.SET, 'indexedText', (TType.STRING, 'UTF8', False), None, ),  # 11
        (12, TType.SET, 'tags', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 12
        (13, TType.BOOL, 'isPublic', None, None, ),  # 13
        (14, TType.I64, 'deletedAt', None, None, ),  # 14
        (15, TType.STRING, 'deletedByUserId', 'UTF8', None, ),  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.STRUCT, 'dealSummary', (gen.urbancompass.deals.deals_summary.ttypes.DealSummary, gen.urbancompass.deals.deals_summary.ttypes.DealSummary.thrift_spec), None, ),  # 100
        (101, TType.LIST, 'dealSummaries', (TType.STRUCT, (gen.urbancompass.deals.deals_summary.ttypes.DealSummary, gen.urbancompass.deals.deals_summary.ttypes.DealSummary.thrift_spec), False), None, ),  # 101
    )
    def __init__(self, _id=None, appId=None, title=None, acl=None, detail=None, createdAt=None, updatedAt=None, createdByUserId=None, updatedByUserId=None, customers=None, indexedText=None, tags=None, isPublic=None, deletedAt=None, deletedByUserId=None, dealSummary=None, dealSummaries=None, ):
        self._id = _id
        self.appId = appId
        self.title = title
        self.acl = acl
        self.detail = detail
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.createdByUserId = createdByUserId
        self.updatedByUserId = updatedByUserId
        self.customers = customers
        self.indexedText = indexedText
        self.tags = tags
        self.isPublic = isPublic
        self.deletedAt = deletedAt
        self.deletedByUserId = deletedByUserId
        self.dealSummary = dealSummary
        self.dealSummaries = dealSummaries

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.appId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.SET:
                    self.acl = set()
                    (_etype33, _size35) = iprot.readSetBegin()
                    for _i32 in range(_size35):
                        _elem34 = gen.urbancompass.permissions.acl.ttypes.ACLEntry()
                        _elem34.read(iprot)
                        self.acl.add(_elem34)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.detail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.createdByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.updatedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.SET:
                    self.customers = set()
                    (_etype37, _size39) = iprot.readSetBegin()
                    for _i36 in range(_size39):
                        _elem38 = Customer()
                        _elem38.read(iprot)
                        self.customers.add(_elem38)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.SET:
                    self.indexedText = set()
                    (_etype41, _size43) = iprot.readSetBegin()
                    for _i40 in range(_size43):
                        _elem42 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.indexedText.add(_elem42)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.SET:
                    self.tags = set()
                    (_etype45, _size47) = iprot.readSetBegin()
                    for _i44 in range(_size47):
                        _elem46 = Tag()
                        _elem46.read(iprot)
                        self.tags.add(_elem46)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.isPublic = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.deletedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.deletedByUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.STRUCT:
                    self.dealSummary = gen.urbancompass.deals.deals_summary.ttypes.DealSummary()
                    self.dealSummary.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 101:
                if ftype == TType.LIST:
                    self.dealSummaries = []
                    (_etype48, _size51) = iprot.readListBegin()
                    for _i49 in range(_size51):
                        _elem50 = gen.urbancompass.deals.deals_summary.ttypes.DealSummary()
                        _elem50.read(iprot)
                        self.dealSummaries.append(_elem50)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DocumentMetadata')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.appId is not None:
            oprot.writeFieldBegin('appId', TType.I32, 2)
            oprot.writeI32(self.appId)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 3)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.acl is not None:
            oprot.writeFieldBegin('acl', TType.SET, 4)
            oprot.writeSetBegin(TType.STRUCT, len(self.acl))
            for _iter52 in self.acl:
                _iter52.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.detail is not None:
            oprot.writeFieldBegin('detail', TType.STRING, 5)
            oprot.writeString(self.detail.encode('utf-8') if sys.version_info[0] == 2 else self.detail)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 7)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.createdByUserId is not None:
            oprot.writeFieldBegin('createdByUserId', TType.STRING, 8)
            oprot.writeString(self.createdByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.createdByUserId)
            oprot.writeFieldEnd()
        if self.updatedByUserId is not None:
            oprot.writeFieldBegin('updatedByUserId', TType.STRING, 9)
            oprot.writeString(self.updatedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.updatedByUserId)
            oprot.writeFieldEnd()
        if self.customers is not None:
            oprot.writeFieldBegin('customers', TType.SET, 10)
            oprot.writeSetBegin(TType.STRUCT, len(self.customers))
            for _iter53 in self.customers:
                _iter53.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.indexedText is not None:
            oprot.writeFieldBegin('indexedText', TType.SET, 11)
            oprot.writeSetBegin(TType.STRING, len(self.indexedText))
            for _iter54 in self.indexedText:
                oprot.writeString(_iter54.encode('utf-8') if sys.version_info[0] == 2 else _iter54)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.SET, 12)
            oprot.writeSetBegin(TType.STRUCT, len(self.tags))
            for _iter55 in self.tags:
                _iter55.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.isPublic is not None:
            oprot.writeFieldBegin('isPublic', TType.BOOL, 13)
            oprot.writeBool(self.isPublic)
            oprot.writeFieldEnd()
        if self.deletedAt is not None:
            oprot.writeFieldBegin('deletedAt', TType.I64, 14)
            oprot.writeI64(self.deletedAt)
            oprot.writeFieldEnd()
        if self.deletedByUserId is not None:
            oprot.writeFieldBegin('deletedByUserId', TType.STRING, 15)
            oprot.writeString(self.deletedByUserId.encode('utf-8') if sys.version_info[0] == 2 else self.deletedByUserId)
            oprot.writeFieldEnd()
        if self.dealSummary is not None:
            oprot.writeFieldBegin('dealSummary', TType.STRUCT, 100)
            self.dealSummary.write(oprot)
            oprot.writeFieldEnd()
        if self.dealSummaries is not None:
            oprot.writeFieldBegin('dealSummaries', TType.LIST, 101)
            oprot.writeListBegin(TType.STRUCT, len(self.dealSummaries))
            for _iter56 in self.dealSummaries:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DocumentMetadataUpdate(object):
    """
    Attributes:
     - title
     - detail
     - userIdsToAdd
     - userIdsToRemove
     - customerIdsToAdd
     - customerIdsToRemove
     - tagsToAdd
     - tagsToRemove
     - isPublic
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'title', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'detail', 'UTF8', None, ),  # 2
        (3, TType.SET, 'userIdsToAdd', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.SET, 'userIdsToRemove', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.SET, 'customerIdsToAdd', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.SET, 'customerIdsToRemove', (TType.STRING, 'UTF8', False), None, ),  # 6
        (7, TType.SET, 'tagsToAdd', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 7
        (8, TType.SET, 'tagsToRemove', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 8
        (9, TType.BOOL, 'isPublic', None, None, ),  # 9
    )
    def __init__(self, title=None, detail=None, userIdsToAdd=None, userIdsToRemove=None, customerIdsToAdd=None, customerIdsToRemove=None, tagsToAdd=None, tagsToRemove=None, isPublic=None, ):
        self.title = title
        self.detail = detail
        self.userIdsToAdd = userIdsToAdd
        self.userIdsToRemove = userIdsToRemove
        self.customerIdsToAdd = customerIdsToAdd
        self.customerIdsToRemove = customerIdsToRemove
        self.tagsToAdd = tagsToAdd
        self.tagsToRemove = tagsToRemove
        self.isPublic = isPublic

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.detail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.SET:
                    self.userIdsToAdd = set()
                    (_etype58, _size60) = iprot.readSetBegin()
                    for _i57 in range(_size60):
                        _elem59 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userIdsToAdd.add(_elem59)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.SET:
                    self.userIdsToRemove = set()
                    (_etype62, _size64) = iprot.readSetBegin()
                    for _i61 in range(_size64):
                        _elem63 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.userIdsToRemove.add(_elem63)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.SET:
                    self.customerIdsToAdd = set()
                    (_etype66, _size68) = iprot.readSetBegin()
                    for _i65 in range(_size68):
                        _elem67 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.customerIdsToAdd.add(_elem67)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.SET:
                    self.customerIdsToRemove = set()
                    (_etype70, _size72) = iprot.readSetBegin()
                    for _i69 in range(_size72):
                        _elem71 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.customerIdsToRemove.add(_elem71)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.SET:
                    self.tagsToAdd = set()
                    (_etype74, _size76) = iprot.readSetBegin()
                    for _i73 in range(_size76):
                        _elem75 = Tag()
                        _elem75.read(iprot)
                        self.tagsToAdd.add(_elem75)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.SET:
                    self.tagsToRemove = set()
                    (_etype78, _size80) = iprot.readSetBegin()
                    for _i77 in range(_size80):
                        _elem79 = Tag()
                        _elem79.read(iprot)
                        self.tagsToRemove.add(_elem79)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.isPublic = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DocumentMetadataUpdate')
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 1)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.detail is not None:
            oprot.writeFieldBegin('detail', TType.STRING, 2)
            oprot.writeString(self.detail.encode('utf-8') if sys.version_info[0] == 2 else self.detail)
            oprot.writeFieldEnd()
        if self.userIdsToAdd is not None:
            oprot.writeFieldBegin('userIdsToAdd', TType.SET, 3)
            oprot.writeSetBegin(TType.STRING, len(self.userIdsToAdd))
            for _iter81 in self.userIdsToAdd:
                oprot.writeString(_iter81.encode('utf-8') if sys.version_info[0] == 2 else _iter81)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.userIdsToRemove is not None:
            oprot.writeFieldBegin('userIdsToRemove', TType.SET, 4)
            oprot.writeSetBegin(TType.STRING, len(self.userIdsToRemove))
            for _iter82 in self.userIdsToRemove:
                oprot.writeString(_iter82.encode('utf-8') if sys.version_info[0] == 2 else _iter82)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.customerIdsToAdd is not None:
            oprot.writeFieldBegin('customerIdsToAdd', TType.SET, 5)
            oprot.writeSetBegin(TType.STRING, len(self.customerIdsToAdd))
            for _iter83 in self.customerIdsToAdd:
                oprot.writeString(_iter83.encode('utf-8') if sys.version_info[0] == 2 else _iter83)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.customerIdsToRemove is not None:
            oprot.writeFieldBegin('customerIdsToRemove', TType.SET, 6)
            oprot.writeSetBegin(TType.STRING, len(self.customerIdsToRemove))
            for _iter84 in self.customerIdsToRemove:
                oprot.writeString(_iter84.encode('utf-8') if sys.version_info[0] == 2 else _iter84)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.tagsToAdd is not None:
            oprot.writeFieldBegin('tagsToAdd', TType.SET, 7)
            oprot.writeSetBegin(TType.STRUCT, len(self.tagsToAdd))
            for _iter85 in self.tagsToAdd:
                _iter85.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.tagsToRemove is not None:
            oprot.writeFieldBegin('tagsToRemove', TType.SET, 8)
            oprot.writeSetBegin(TType.STRUCT, len(self.tagsToRemove))
            for _iter86 in self.tagsToRemove:
                _iter86.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.isPublic is not None:
            oprot.writeFieldBegin('isPublic', TType.BOOL, 9)
            oprot.writeBool(self.isPublic)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDocumentRequest(object):
    """
    Attributes:
     - requesterId
     - metadata
     - contents
     - appId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'metadata', (DocumentMetadataUpdate, DocumentMetadataUpdate.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'contents', 'UTF8', None, ),  # 3
        (4, TType.I32, 'appId', None, None, ),  # 4
    )
    def __init__(self, requesterId=None, metadata=None, contents=None, appId=None, ):
        self.requesterId = requesterId
        self.metadata = metadata
        self.contents = contents
        self.appId = appId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.metadata = DocumentMetadataUpdate()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.contents = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.appId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDocumentRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 2)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.contents is not None:
            oprot.writeFieldBegin('contents', TType.STRING, 3)
            oprot.writeString(self.contents.encode('utf-8') if sys.version_info[0] == 2 else self.contents)
            oprot.writeFieldEnd()
        if self.appId is not None:
            oprot.writeFieldBegin('appId', TType.I32, 4)
            oprot.writeI32(self.appId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CreateDocumentResponse(object):
    """
    Attributes:
     - status
     - documentId
     - version
     - metadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.I32, 'version', None, None, ),  # 3
        (4, TType.STRUCT, 'metadata', (DocumentMetadata, DocumentMetadata.thrift_spec), None, ),  # 4
    )
    def __init__(self, status=None, documentId=None, version=None, metadata=None, ):
        self.status = status
        self.documentId = documentId
        self.version = version
        self.metadata = metadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.metadata = DocumentMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CreateDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 3)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 4)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindDocumentsRequest(object):
    """
    Attributes:
     - requesterId
     - skip
     - limit
     - orderBy
     - ascending
     - textQuery
     - appIds
     - customerId
     - tags
     - types
     - sortTag
     - anyTags
     - useRegex
     - tagOperator
     - groupsToOrderFirst
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'skip', None, None, ),  # 2
        (3, TType.I32, 'limit', None, None, ),  # 3
        (4, TType.I32, 'orderBy', None, None, ),  # 4
        (5, TType.BOOL, 'ascending', None, None, ),  # 5
        (6, TType.STRING, 'textQuery', 'UTF8', None, ),  # 6
        (7, TType.SET, 'appIds', (TType.I32, None, False), None, ),  # 7
        (8, TType.STRING, 'customerId', 'UTF8', None, ),  # 8
        (9, TType.SET, 'tags', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 9
        (10, TType.SET, 'types', (TType.I32, None, False), None, ),  # 10
        (11, TType.STRING, 'sortTag', 'UTF8', None, ),  # 11
        (12, TType.I32, 'tagOperator', None, None, ),  # 12
        (13, TType.SET, 'anyTags', (TType.STRUCT, (Tag, Tag.thrift_spec), False), None, ),  # 13
        (14, TType.BOOL, 'useRegex', None, None, ),  # 14
        (15, TType.LIST, 'groupsToOrderFirst', (TType.STRUCT, (CollateralsGroup, CollateralsGroup.thrift_spec), False), None, ),  # 15
    )
    def __init__(self, requesterId=None, skip=None, limit=None, orderBy=None, ascending=None, textQuery=None, appIds=None, customerId=None, tags=None, types=None, sortTag=None, tagOperator=None, anyTags=None, useRegex=None, groupsToOrderFirst=None, ):
        self.requesterId = requesterId
        self.skip = skip
        self.limit = limit
        self.orderBy = orderBy
        self.ascending = ascending
        self.textQuery = textQuery
        self.appIds = appIds
        self.customerId = customerId
        self.tags = tags
        self.types = types
        self.sortTag = sortTag
        self.tagOperator = tagOperator
        self.anyTags = anyTags
        self.useRegex = useRegex
        self.groupsToOrderFirst = groupsToOrderFirst

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.skip = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.orderBy = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.ascending = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.textQuery = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.SET:
                    self.appIds = set()
                    (_etype88, _size90) = iprot.readSetBegin()
                    for _i87 in range(_size90):
                        _elem89 = iprot.readI32()
                        self.appIds.add(_elem89)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.customerId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.SET:
                    self.tags = set()
                    (_etype92, _size94) = iprot.readSetBegin()
                    for _i91 in range(_size94):
                        _elem93 = Tag()
                        _elem93.read(iprot)
                        self.tags.add(_elem93)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.SET:
                    self.types = set()
                    (_etype96, _size98) = iprot.readSetBegin()
                    for _i95 in range(_size98):
                        _elem97 = iprot.readI32()
                        self.types.add(_elem97)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.sortTag = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.tagOperator = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.SET:
                    self.anyTags = set()
                    (_etype100, _size102) = iprot.readSetBegin()
                    for _i99 in range(_size102):
                        _elem101 = Tag()
                        _elem101.read(iprot)
                        self.anyTags.add(_elem101)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.BOOL:
                    self.useRegex = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.groupsToOrderFirst = []
                    (_etype103, _size106) = iprot.readListBegin()
                    for _i104 in range(_size106):
                        _elem105 = CollateralsGroup()
                        _elem105.read(iprot)
                        self.groupsToOrderFirst.append(_elem105)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindDocumentsRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.skip is not None:
            oprot.writeFieldBegin('skip', TType.I32, 2)
            oprot.writeI32(self.skip)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 3)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.orderBy is not None:
            oprot.writeFieldBegin('orderBy', TType.I32, 4)
            oprot.writeI32(self.orderBy)
            oprot.writeFieldEnd()
        if self.ascending is not None:
            oprot.writeFieldBegin('ascending', TType.BOOL, 5)
            oprot.writeBool(self.ascending)
            oprot.writeFieldEnd()
        if self.textQuery is not None:
            oprot.writeFieldBegin('textQuery', TType.STRING, 6)
            oprot.writeString(self.textQuery.encode('utf-8') if sys.version_info[0] == 2 else self.textQuery)
            oprot.writeFieldEnd()
        if self.appIds is not None:
            oprot.writeFieldBegin('appIds', TType.SET, 7)
            oprot.writeSetBegin(TType.I32, len(self.appIds))
            for _iter107 in self.appIds:
                oprot.writeI32(_iter107)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.customerId is not None:
            oprot.writeFieldBegin('customerId', TType.STRING, 8)
            oprot.writeString(self.customerId.encode('utf-8') if sys.version_info[0] == 2 else self.customerId)
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.SET, 9)
            oprot.writeSetBegin(TType.STRUCT, len(self.tags))
            for _iter108 in self.tags:
                _iter108.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.types is not None:
            oprot.writeFieldBegin('types', TType.SET, 10)
            oprot.writeSetBegin(TType.I32, len(self.types))
            for _iter109 in self.types:
                oprot.writeI32(_iter109)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.sortTag is not None:
            oprot.writeFieldBegin('sortTag', TType.STRING, 11)
            oprot.writeString(self.sortTag.encode('utf-8') if sys.version_info[0] == 2 else self.sortTag)
            oprot.writeFieldEnd()
        if self.tagOperator is not None:
            oprot.writeFieldBegin('tagOperator', TType.I32, 12)
            oprot.writeI32(self.tagOperator)
            oprot.writeFieldEnd()
        if self.anyTags is not None:
            oprot.writeFieldBegin('anyTags', TType.SET, 13)
            oprot.writeSetBegin(TType.STRUCT, len(self.anyTags))
            for _iter110 in self.anyTags:
                _iter110.write(oprot)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.useRegex is not None:
            oprot.writeFieldBegin('useRegex', TType.BOOL, 14)
            oprot.writeBool(self.useRegex)
            oprot.writeFieldEnd()
        if self.groupsToOrderFirst is not None:
            oprot.writeFieldBegin('groupsToOrderFirst', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.groupsToOrderFirst))
            for _iter111 in self.groupsToOrderFirst:
                _iter111.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FindDocumentsResponse(object):
    """
    Attributes:
     - status
     - documents
     - count
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'documents', (TType.STRUCT, (DocumentMetadata, DocumentMetadata.thrift_spec), False), None, ),  # 2
        (3, TType.I32, 'count', None, None, ),  # 3
    )
    def __init__(self, status=None, documents=None, count=None, ):
        self.status = status
        self.documents = documents
        self.count = count

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.documents = []
                    (_etype112, _size115) = iprot.readListBegin()
                    for _i113 in range(_size115):
                        _elem114 = DocumentMetadata()
                        _elem114.read(iprot)
                        self.documents.append(_elem114)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FindDocumentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.documents is not None:
            oprot.writeFieldBegin('documents', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.documents))
            for _iter116 in self.documents:
                _iter116.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 3)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FullDocumentData(object):
    """
    Attributes:
     - metadata
     - contents
     - version
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'metadata', (DocumentMetadata, DocumentMetadata.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'contents', 'UTF8', None, ),  # 2
        (3, TType.I32, 'version', None, None, ),  # 3
    )
    def __init__(self, metadata=None, contents=None, version=None, ):
        self.metadata = metadata
        self.contents = contents
        self.version = version

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.metadata = DocumentMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.contents = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FullDocumentData')
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 1)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.contents is not None:
            oprot.writeFieldBegin('contents', TType.STRING, 2)
            oprot.writeString(self.contents.encode('utf-8') if sys.version_info[0] == 2 else self.contents)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 3)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReadDocumentResponse(object):
    """
    Attributes:
     - status
     - metadata
     - contents
     - version
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.STRUCT, 'metadata', (DocumentMetadata, DocumentMetadata.thrift_spec), None, ),  # 2
        (3, TType.STRING, 'contents', 'UTF8', None, ),  # 3
        (4, TType.I32, 'version', None, None, ),  # 4
    )
    def __init__(self, status=None, metadata=None, contents=None, version=None, ):
        self.status = status
        self.metadata = metadata
        self.contents = contents
        self.version = version

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.metadata = DocumentMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.contents = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReadDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 2)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.contents is not None:
            oprot.writeFieldBegin('contents', TType.STRING, 3)
            oprot.writeString(self.contents.encode('utf-8') if sys.version_info[0] == 2 else self.contents)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 4)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDocumentRequest(object):
    """
    Attributes:
     - requesterId
     - documentId
     - contents
     - metadata
     - version
     - roles
     - includeDealSummary
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'requesterId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'documentId', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'contents', 'UTF8', None, ),  # 3
        (4, TType.STRUCT, 'metadata', (DocumentMetadataUpdate, DocumentMetadataUpdate.thrift_spec), None, ),  # 4
        (5, TType.I32, 'version', None, None, ),  # 5
        (6, TType.LIST, 'roles', (TType.STRUCT, (gen.urbancompass.user.user.ttypes.Role, gen.urbancompass.user.user.ttypes.Role.thrift_spec), False), None, ),  # 6
        None,  # 7
        None,  # 8
        None,  # 9
        None,  # 10
        None,  # 11
        None,  # 12
        None,  # 13
        None,  # 14
        None,  # 15
        None,  # 16
        None,  # 17
        None,  # 18
        None,  # 19
        None,  # 20
        None,  # 21
        None,  # 22
        None,  # 23
        None,  # 24
        None,  # 25
        None,  # 26
        None,  # 27
        None,  # 28
        None,  # 29
        None,  # 30
        None,  # 31
        None,  # 32
        None,  # 33
        None,  # 34
        None,  # 35
        None,  # 36
        None,  # 37
        None,  # 38
        None,  # 39
        None,  # 40
        None,  # 41
        None,  # 42
        None,  # 43
        None,  # 44
        None,  # 45
        None,  # 46
        None,  # 47
        None,  # 48
        None,  # 49
        None,  # 50
        None,  # 51
        None,  # 52
        None,  # 53
        None,  # 54
        None,  # 55
        None,  # 56
        None,  # 57
        None,  # 58
        None,  # 59
        None,  # 60
        None,  # 61
        None,  # 62
        None,  # 63
        None,  # 64
        None,  # 65
        None,  # 66
        None,  # 67
        None,  # 68
        None,  # 69
        None,  # 70
        None,  # 71
        None,  # 72
        None,  # 73
        None,  # 74
        None,  # 75
        None,  # 76
        None,  # 77
        None,  # 78
        None,  # 79
        None,  # 80
        None,  # 81
        None,  # 82
        None,  # 83
        None,  # 84
        None,  # 85
        None,  # 86
        None,  # 87
        None,  # 88
        None,  # 89
        None,  # 90
        None,  # 91
        None,  # 92
        None,  # 93
        None,  # 94
        None,  # 95
        None,  # 96
        None,  # 97
        None,  # 98
        None,  # 99
        (100, TType.BOOL, 'includeDealSummary', None, None, ),  # 100
    )
    def __init__(self, requesterId=None, documentId=None, contents=None, metadata=None, version=None, roles=None, includeDealSummary=None, ):
        self.requesterId = requesterId
        self.documentId = documentId
        self.contents = contents
        self.metadata = metadata
        self.version = version
        self.roles = roles
        self.includeDealSummary = includeDealSummary

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.requesterId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.documentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.contents = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.metadata = DocumentMetadataUpdate()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.roles = []
                    (_etype117, _size120) = iprot.readListBegin()
                    for _i118 in range(_size120):
                        _elem119 = gen.urbancompass.user.user.ttypes.Role()
                        _elem119.read(iprot)
                        self.roles.append(_elem119)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.BOOL:
                    self.includeDealSummary = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDocumentRequest')
        if self.requesterId is not None:
            oprot.writeFieldBegin('requesterId', TType.STRING, 1)
            oprot.writeString(self.requesterId.encode('utf-8') if sys.version_info[0] == 2 else self.requesterId)
            oprot.writeFieldEnd()
        if self.documentId is not None:
            oprot.writeFieldBegin('documentId', TType.STRING, 2)
            oprot.writeString(self.documentId.encode('utf-8') if sys.version_info[0] == 2 else self.documentId)
            oprot.writeFieldEnd()
        if self.contents is not None:
            oprot.writeFieldBegin('contents', TType.STRING, 3)
            oprot.writeString(self.contents.encode('utf-8') if sys.version_info[0] == 2 else self.contents)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 4)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 5)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.roles is not None:
            oprot.writeFieldBegin('roles', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.roles))
            for _iter121 in self.roles:
                _iter121.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.includeDealSummary is not None:
            oprot.writeFieldBegin('includeDealSummary', TType.BOOL, 100)
            oprot.writeBool(self.includeDealSummary)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class UpdateDocumentResponse(object):
    """
    Attributes:
     - status
     - version
     - metadata
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.I32, 'version', None, None, ),  # 2
        (3, TType.STRUCT, 'metadata', (DocumentMetadata, DocumentMetadata.thrift_spec), None, ),  # 3
    )
    def __init__(self, status=None, version=None, metadata=None, ):
        self.status = status
        self.version = version
        self.metadata = metadata

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.version = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.metadata = DocumentMetadata()
                    self.metadata.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('UpdateDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.I32, 2)
            oprot.writeI32(self.version)
            oprot.writeFieldEnd()
        if self.metadata is not None:
            oprot.writeFieldBegin('metadata', TType.STRUCT, 3)
            self.metadata.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class CopyDocumentResponse(object):
    """
    Attributes:
     - status
     - copiedDocuments
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'copiedDocuments', (TType.STRUCT, (CreateDocumentResponse, CreateDocumentResponse.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, copiedDocuments=None, ):
        self.status = status
        self.copiedDocuments = copiedDocuments

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.copiedDocuments = []
                    (_etype122, _size125) = iprot.readListBegin()
                    for _i123 in range(_size125):
                        _elem124 = CreateDocumentResponse()
                        _elem124.read(iprot)
                        self.copiedDocuments.append(_elem124)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('CopyDocumentResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.copiedDocuments is not None:
            oprot.writeFieldBegin('copiedDocuments', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.copiedDocuments))
            for _iter126 in self.copiedDocuments:
                _iter126.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ReadDocumentsResponse(object):
    """
    Attributes:
     - status
     - documents
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.LIST, 'documents', (TType.STRUCT, (FullDocumentData, FullDocumentData.thrift_spec), False), None, ),  # 2
    )
    def __init__(self, status=None, documents=None, ):
        self.status = status
        self.documents = documents

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.documents = []
                    (_etype127, _size130) = iprot.readListBegin()
                    for _i128 in range(_size130):
                        _elem129 = FullDocumentData()
                        _elem129.read(iprot)
                        self.documents.append(_elem129)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ReadDocumentsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.documents is not None:
            oprot.writeFieldBegin('documents', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.documents))
            for _iter131 in self.documents:
                _iter131.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
