
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class ComparableScoringType(object):
    ACTIVE_LISTING = 0
    IN_CONTRACT = 1
    RECENTLY_SOLD_LISTING = 2
    IN_BUILDING_RECENT = 3
    IN_BUILDING_HISTORY = 4

    _VALUES_TO_NAMES = {
        0: "ACTIVE_LISTING",
        1: "IN_CONTRACT",
        2: "RECENTLY_SOLD_LISTING",
        3: "IN_BUILDING_RECENT",
        4: "IN_BUILDING_HISTORY",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE_LISTING": 0,
        "IN_CONTRACT": 1,
        "RECENTLY_SOLD_LISTING": 2,
        "IN_BUILDING_RECENT": 3,
        "IN_BUILDING_HISTORY": 4,
    }

