# GENERATED CODE: DO NOT MODIFY
from __future__ import absolute_import

import grpc

from .ttypes import *
import gen.urbancompass.common.base.ttypes as base
import gen.urbancompass.listings_conversion.service.ttypes as listings_conversion_service
import uc.grpc.codec as _grpc_codec



class ConversionsDlqServiceStub(object):
  """Interface exported by the server.
  """

  def __init__(self, channel):
    """
    :param channel: A grpc.Channel.
    """
    self.reportSourceFeeds = channel.unary_unary(
        '/ConversionsDlqService/reportSourceFeeds',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReportSourceFeedsResponse),
        )
    self.reprocessSourceFeed = channel.unary_unary(
        '/ConversionsDlqService/reprocessSourceFeed',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(ReprocessSourceFeedsResponse),
        )
    self.storeListing = channel.unary_unary(
        '/ConversionsDlqService/storeListing',
        request_serializer=_grpc_codec.serialize,
        response_deserializer=_grpc_codec.deserializer(StoreListingResponse),
        )



from gen.urbancompass.common.base.grpc import BaseServiceServicer


class ConversionsDlqServiceServicer(BaseServiceServicer):
  """
    The ConversionsDlqService Service definition
  """

  def reportSourceFeeds(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def reprocessSourceFeed(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')

  def storeListing(self, request, context):
    """
    :param request
    :param context
    """
    raise NotImplementedError('Method not implemented!')



def add_legacy_ConversionsDlqServiceServicer_to_server(servicer, server):
  """Add a legacy Thrift server to the GRPC server.

  A legacy server implementation has methods that accept just a request.
  """
  rpc_method_handlers = {
      'reportSourceFeeds': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reportSourceFeeds(req),
          request_deserializer=_grpc_codec.deserializer(ReportSourceFeedsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reprocessSourceFeed': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.reprocessSourceFeed(req),
          request_deserializer=_grpc_codec.deserializer(ReprocessSourceFeedsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'storeListing': grpc.unary_unary_rpc_method_handler(
          lambda req, ctx: servicer.storeListing(req),
          request_deserializer=_grpc_codec.deserializer(StoreListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'ConversionsDlqService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))


def add_ConversionsDlqServiceServicer_to_server(servicer, server):
  """Add a server implementation with GRPC-style method signatures to the GRPC server.

  A GRPC-style implementation has methods that accept (request, context)
  where context is a grpc.ServicerContext.
  """
  rpc_method_handlers = {
      'reportSourceFeeds': grpc.unary_unary_rpc_method_handler(
          servicer.reportSourceFeeds,
          request_deserializer=_grpc_codec.deserializer(ReportSourceFeedsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'reprocessSourceFeed': grpc.unary_unary_rpc_method_handler(
          servicer.reprocessSourceFeed,
          request_deserializer=_grpc_codec.deserializer(ReprocessSourceFeedsRequest),
          response_serializer=_grpc_codec.serialize,
      ),
      'storeListing': grpc.unary_unary_rpc_method_handler(
          servicer.storeListing,
          request_deserializer=_grpc_codec.deserializer(StoreListingRequest),
          response_serializer=_grpc_codec.serialize,
      ),
  }
  generic_handler = grpc.method_handlers_generic_handler(
      'ConversionsDlqService', rpc_method_handlers)
  server.add_generic_rpc_handlers((generic_handler,))

