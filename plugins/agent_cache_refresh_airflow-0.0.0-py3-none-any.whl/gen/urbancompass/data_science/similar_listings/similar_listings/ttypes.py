
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.listing.listing_compliance.ttypes
import gen.urbancompass.listing_translation.processed_listing.ttypes

from thrift.transport import TTransport


class RequestedListingStatus(object):
    ACTIVE = 0
    IN_CONTRACT = 1
    SOLD = 2

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "IN_CONTRACT",
        2: "SOLD",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "IN_CONTRACT": 1,
        "SOLD": 2,
    }


class GetSimilarListingsForListingIdRequest(object):
    """
    Attributes:
     - userId
     - userType
     - userTypeOverrides
     - experiments
     - requestedListingStatuses
     - listingIdSHA
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'userType', None, None, ),  # 2
        (3, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 3
        (4, TType.LIST, 'experiments', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'requestedListingStatuses', (TType.I32, None, False), None, ),  # 5
        (6, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 6
    )
    def __init__(self, userId=None, userType=None, userTypeOverrides=None, experiments=None, requestedListingStatuses=None, listingIdSHA=None, ):
        self.userId = userId
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.experiments = experiments
        self.requestedListingStatuses = requestedListingStatuses
        self.listingIdSHA = listingIdSHA

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype3, _vtype4, _size7) = iprot.readMapBegin()
                    for _i2 in range(_size7):
                        _key5 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val6 = iprot.readI32()
                        self.userTypeOverrides[_key5] = _val6
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.experiments = []
                    (_etype8, _size11) = iprot.readListBegin()
                    for _i9 in range(_size11):
                        _elem10 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.experiments.append(_elem10)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.requestedListingStatuses = []
                    (_etype12, _size15) = iprot.readListBegin()
                    for _i13 in range(_size15):
                        _elem14 = iprot.readI32()
                        self.requestedListingStatuses.append(_elem14)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetSimilarListingsForListingIdRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 2)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter16, _viter17 in self.userTypeOverrides.items():
                oprot.writeString(_kiter16.encode('utf-8') if sys.version_info[0] == 2 else _kiter16)
                oprot.writeI32(_viter17)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.experiments is not None:
            oprot.writeFieldBegin('experiments', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.experiments))
            for _iter18 in self.experiments:
                oprot.writeString(_iter18.encode('utf-8') if sys.version_info[0] == 2 else _iter18)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.requestedListingStatuses is not None:
            oprot.writeFieldBegin('requestedListingStatuses', TType.LIST, 5)
            oprot.writeListBegin(TType.I32, len(self.requestedListingStatuses))
            for _iter19 in self.requestedListingStatuses:
                oprot.writeI32(_iter19)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 6)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetSimilarListingsRequest(object):
    """
    Attributes:
     - userId
     - userType
     - userTypeOverrides
     - experiments
     - processedListing
     - requestedListingStatuses
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'userType', None, None, ),  # 2
        (3, TType.MAP, 'userTypeOverrides', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 3
        (4, TType.LIST, 'experiments', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.STRUCT, 'processedListing', (gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing, gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'requestedListingStatuses', (TType.I32, None, False), None, ),  # 6
    )
    def __init__(self, userId=None, userType=None, userTypeOverrides=None, experiments=None, processedListing=None, requestedListingStatuses=None, ):
        self.userId = userId
        self.userType = userType
        self.userTypeOverrides = userTypeOverrides
        self.experiments = experiments
        self.processedListing = processedListing
        self.requestedListingStatuses = requestedListingStatuses

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.userType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.MAP:
                    self.userTypeOverrides = {}
                    (_ktype21, _vtype22, _size25) = iprot.readMapBegin()
                    for _i20 in range(_size25):
                        _key23 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val24 = iprot.readI32()
                        self.userTypeOverrides[_key23] = _val24
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.experiments = []
                    (_etype26, _size29) = iprot.readListBegin()
                    for _i27 in range(_size29):
                        _elem28 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.experiments.append(_elem28)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.processedListing = gen.urbancompass.listing_translation.processed_listing.ttypes.ProcessedListing()
                    self.processedListing.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.requestedListingStatuses = []
                    (_etype30, _size33) = iprot.readListBegin()
                    for _i31 in range(_size33):
                        _elem32 = iprot.readI32()
                        self.requestedListingStatuses.append(_elem32)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetSimilarListingsRequest')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.userType is not None:
            oprot.writeFieldBegin('userType', TType.I32, 2)
            oprot.writeI32(self.userType)
            oprot.writeFieldEnd()
        if self.userTypeOverrides is not None:
            oprot.writeFieldBegin('userTypeOverrides', TType.MAP, 3)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.userTypeOverrides))
            for _kiter34, _viter35 in self.userTypeOverrides.items():
                oprot.writeString(_kiter34.encode('utf-8') if sys.version_info[0] == 2 else _kiter34)
                oprot.writeI32(_viter35)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.experiments is not None:
            oprot.writeFieldBegin('experiments', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.experiments))
            for _iter36 in self.experiments:
                oprot.writeString(_iter36.encode('utf-8') if sys.version_info[0] == 2 else _iter36)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.processedListing is not None:
            oprot.writeFieldBegin('processedListing', TType.STRUCT, 5)
            self.processedListing.write(oprot)
            oprot.writeFieldEnd()
        if self.requestedListingStatuses is not None:
            oprot.writeFieldBegin('requestedListingStatuses', TType.LIST, 6)
            oprot.writeListBegin(TType.I32, len(self.requestedListingStatuses))
            for _iter37 in self.requestedListingStatuses:
                oprot.writeI32(_iter37)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SimilarListingInfo(object):
    """
    Attributes:
     - listingIdSHA
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 1
    )
    def __init__(self, listingIdSHA=None, ):
        self.listingIdSHA = listingIdSHA

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SimilarListingInfo')
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 1)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetSimilarListingsResponse(object):
    """
    Attributes:
     - status
     - similarListings
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'status', (gen.urbancompass.common.base.ttypes.ResponseStatus, gen.urbancompass.common.base.ttypes.ResponseStatus.thrift_spec), None, ),  # 1
        (2, TType.MAP, 'similarListings', (TType.I32, None, TType.LIST, (TType.STRUCT, (SimilarListingInfo, SimilarListingInfo.thrift_spec), False), False), None, ),  # 2
    )
    def __init__(self, status=None, similarListings=None, ):
        self.status = status
        self.similarListings = similarListings

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.status = gen.urbancompass.common.base.ttypes.ResponseStatus()
                    self.status.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.MAP:
                    self.similarListings = {}
                    (_ktype39, _vtype40, _size43) = iprot.readMapBegin()
                    for _i38 in range(_size43):
                        _key41 = iprot.readI32()
                        _val42 = []
                        (_etype44, _size47) = iprot.readListBegin()
                        for _i45 in range(_size47):
                            _elem46 = SimilarListingInfo()
                            _elem46.read(iprot)
                            _val42.append(_elem46)
                        iprot.readListEnd()
                        self.similarListings[_key41] = _val42
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetSimilarListingsResponse')
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.STRUCT, 1)
            self.status.write(oprot)
            oprot.writeFieldEnd()
        if self.similarListings is not None:
            oprot.writeFieldBegin('similarListings', TType.MAP, 2)
            oprot.writeMapBegin(TType.I32, TType.LIST, len(self.similarListings))
            for _kiter48, _viter49 in self.similarListings.items():
                oprot.writeI32(_kiter48)
                oprot.writeListBegin(TType.STRUCT, len(_viter49))
                for _iter50 in _viter49:
                    _iter50.write(oprot)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
