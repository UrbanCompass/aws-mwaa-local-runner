
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class NewPersonAction(object):
    ADD_EXTERNAL_ID = 0
    PROCESS_INVITE = 1

    _VALUES_TO_NAMES = {
        0: "ADD_EXTERNAL_ID",
        1: "PROCESS_INVITE",
    }

    _NAMES_TO_VALUES = {
        "ADD_EXTERNAL_ID": 0,
        "PROCESS_INVITE": 1,
    }

