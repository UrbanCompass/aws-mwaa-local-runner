
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.listing.listing_status.ttypes

from thrift.transport import TTransport


class AdCampaignStatus(object):
    INACTIVE = 0
    ACTIVE = 1
    EXPIRED = 2
    CANCELLED = 3
    LISTING_INACTIVE = 4
    NONE = 5

    _VALUES_TO_NAMES = {
        0: "INACTIVE",
        1: "ACTIVE",
        2: "EXPIRED",
        3: "CANCELLED",
        4: "LISTING_INACTIVE",
        5: "NONE",
    }

    _NAMES_TO_VALUES = {
        "INACTIVE": 0,
        "ACTIVE": 1,
        "EXPIRED": 2,
        "CANCELLED": 3,
        "LISTING_INACTIVE": 4,
        "NONE": 5,
    }


class AdType(object):
    ACTIVE = 0
    COMING_SOON = 1
    OPEN_HOUSE = 2

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "COMING_SOON",
        2: "OPEN_HOUSE",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "COMING_SOON": 1,
        "OPEN_HOUSE": 2,
    }


class AgentSelection(object):
    SINGLE_PRIMARY_AGENT = 0
    SINGLE_NON_PRIMARY_AGENT = 1
    TEAM = 2
    MULTIPLE_AGENTS = 3

    _VALUES_TO_NAMES = {
        0: "SINGLE_PRIMARY_AGENT",
        1: "SINGLE_NON_PRIMARY_AGENT",
        2: "TEAM",
        3: "MULTIPLE_AGENTS",
    }

    _NAMES_TO_VALUES = {
        "SINGLE_PRIMARY_AGENT": 0,
        "SINGLE_NON_PRIMARY_AGENT": 1,
        "TEAM": 2,
        "MULTIPLE_AGENTS": 3,
    }


class DesignType(object):
    AUTOMATIC = 0
    CUSTOM = 1

    _VALUES_TO_NAMES = {
        0: "AUTOMATIC",
        1: "CUSTOM",
    }

    _NAMES_TO_VALUES = {
        "AUTOMATIC": 0,
        "CUSTOM": 1,
    }


class MessageType(object):
    AUTO = 0
    CUSTOM = 1

    _VALUES_TO_NAMES = {
        0: "AUTO",
        1: "CUSTOM",
    }

    _NAMES_TO_VALUES = {
        "AUTO": 0,
        "CUSTOM": 1,
    }


class DesignOptions(object):
    """
    Attributes:
     - type
     - images
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.LIST, 'images', (TType.STRING, 'UTF8', False), None, ),  # 2
    )
    def __init__(self, type=None, images=None, ):
        self.type = type
        self.images = images

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.images = []
                    (_etype2, _size5) = iprot.readListBegin()
                    for _i3 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.images.append(_elem4)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DesignOptions')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.images is not None:
            oprot.writeFieldBegin('images', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.images))
            for _iter6 in self.images:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DisplayedAgentDetails(object):
    """
    Attributes:
     - userId
     - avatarUrl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 2
    )
    def __init__(self, userId=None, avatarUrl=None, ):
        self.userId = userId
        self.avatarUrl = avatarUrl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DisplayedAgentDetails')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 2)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MessageDetails(object):
    """
    Attributes:
     - templateId
     - messageType
     - message
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'templateId', None, None, ),  # 1
        (2, TType.I32, 'messageType', None, None, ),  # 2
        (3, TType.STRING, 'message', 'UTF8', None, ),  # 3
    )
    def __init__(self, templateId=None, messageType=None, message=None, ):
        self.templateId = templateId
        self.messageType = messageType
        self.message = message

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.templateId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.messageType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.message = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MessageDetails')
        if self.templateId is not None:
            oprot.writeFieldBegin('templateId', TType.I64, 1)
            oprot.writeI64(self.templateId)
            oprot.writeFieldEnd()
        if self.messageType is not None:
            oprot.writeFieldBegin('messageType', TType.I32, 2)
            oprot.writeI32(self.messageType)
            oprot.writeFieldEnd()
        if self.message is not None:
            oprot.writeFieldBegin('message', TType.STRING, 3)
            oprot.writeString(self.message.encode('utf-8') if sys.version_info[0] == 2 else self.message)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Template(object):
    """
    Attributes:
     - id
     - templateBody
     - templateFooter
     - isDefault
     - adType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'id', None, None, ),  # 1
        (2, TType.STRING, 'templateBody', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'templateFooter', 'UTF8', None, ),  # 3
        (4, TType.BOOL, 'isDefault', None, None, ),  # 4
        (5, TType.I32, 'adType', None, None, ),  # 5
    )
    def __init__(self, id=None, templateBody=None, templateFooter=None, isDefault=None, adType=None, ):
        self.id = id
        self.templateBody = templateBody
        self.templateFooter = templateFooter
        self.isDefault = isDefault
        self.adType = adType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.id = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.templateBody = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.templateFooter = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.isDefault = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.adType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Template')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.I64, 1)
            oprot.writeI64(self.id)
            oprot.writeFieldEnd()
        if self.templateBody is not None:
            oprot.writeFieldBegin('templateBody', TType.STRING, 2)
            oprot.writeString(self.templateBody.encode('utf-8') if sys.version_info[0] == 2 else self.templateBody)
            oprot.writeFieldEnd()
        if self.templateFooter is not None:
            oprot.writeFieldBegin('templateFooter', TType.STRING, 3)
            oprot.writeString(self.templateFooter.encode('utf-8') if sys.version_info[0] == 2 else self.templateFooter)
            oprot.writeFieldEnd()
        if self.isDefault is not None:
            oprot.writeFieldBegin('isDefault', TType.BOOL, 4)
            oprot.writeBool(self.isDefault)
            oprot.writeFieldEnd()
        if self.adType is not None:
            oprot.writeFieldBegin('adType', TType.I32, 5)
            oprot.writeI32(self.adType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AdCampaign(object):
    """
    Attributes:
     - _id
     - createdAt
     - updatedAt
     - userId
     - listingAgentUserId
     - email
     - firstName
     - lastName
     - region
     - title
     - startTime
     - stopTime
     - budget
     - spend
     - templateId
     - contentSelection
     - internalStatus
     - externalStatus
     - listingIdSHA
     - impressions
     - reach
     - clicks
     - shares
     - likes
     - managementFee
     - internalStatusUpdatedAt
     - externalStatusUpdatedAt
     - managementRate
     - originalListingStatus
     - designOptions
     - messageDetails
     - displayedAgents
     - agentSelection
     - adType
     - displayedAgentDetails
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.STRING, 'userId', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'email', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'firstName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'lastName', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'region', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'title', 'UTF8', None, ),  # 9
        (10, TType.I64, 'startTime', None, None, ),  # 10
        (11, TType.I64, 'stopTime', None, None, ),  # 11
        (12, TType.DOUBLE, 'budget', None, None, ),  # 12
        (13, TType.DOUBLE, 'spend', None, None, ),  # 13
        (14, TType.STRING, 'templateId', 'UTF8', None, ),  # 14
        (15, TType.STRING, 'contentSelection', 'UTF8', None, ),  # 15
        (16, TType.I32, 'internalStatus', None, None, ),  # 16
        (17, TType.I32, 'externalStatus', None, None, ),  # 17
        (18, TType.STRING, 'listingIdSHA', 'UTF8', None, ),  # 18
        (19, TType.I64, 'impressions', None, None, ),  # 19
        (20, TType.I64, 'reach', None, None, ),  # 20
        (21, TType.I64, 'clicks', None, None, ),  # 21
        (22, TType.I64, 'shares', None, None, ),  # 22
        (23, TType.I64, 'likes', None, None, ),  # 23
        (24, TType.DOUBLE, 'managementFee', None, None, ),  # 24
        (25, TType.I64, 'internalStatusUpdatedAt', None, None, ),  # 25
        (26, TType.I64, 'externalStatusUpdatedAt', None, None, ),  # 26
        (27, TType.DOUBLE, 'managementRate', None, None, ),  # 27
        (28, TType.STRING, 'listingAgentUserId', 'UTF8', None, ),  # 28
        (29, TType.I32, 'originalListingStatus', None, None, ),  # 29
        (30, TType.STRUCT, 'designOptions', (DesignOptions, DesignOptions.thrift_spec), None, ),  # 30
        (31, TType.STRUCT, 'messageDetails', (MessageDetails, MessageDetails.thrift_spec), None, ),  # 31
        (32, TType.LIST, 'displayedAgents', (TType.STRING, 'UTF8', False), None, ),  # 32
        (33, TType.I32, 'agentSelection', None, None, ),  # 33
        (34, TType.I32, 'adType', None, None, ),  # 34
        (35, TType.STRUCT, 'displayedAgentDetails', (DisplayedAgentDetails, DisplayedAgentDetails.thrift_spec), None, ),  # 35
    )
    def __init__(self, _id=None, createdAt=None, updatedAt=None, userId=None, email=None, firstName=None, lastName=None, region=None, title=None, startTime=None, stopTime=None, budget=None, spend=None, templateId=None, contentSelection=None, internalStatus=None, externalStatus=None, listingIdSHA=None, impressions=None, reach=None, clicks=None, shares=None, likes=None, managementFee=None, internalStatusUpdatedAt=None, externalStatusUpdatedAt=None, managementRate=None, listingAgentUserId=None, originalListingStatus=None, designOptions=None, messageDetails=None, displayedAgents=None, agentSelection=None, adType=None, displayedAgentDetails=None, ):
        self._id = _id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.userId = userId
        self.email = email
        self.firstName = firstName
        self.lastName = lastName
        self.region = region
        self.title = title
        self.startTime = startTime
        self.stopTime = stopTime
        self.budget = budget
        self.spend = spend
        self.templateId = templateId
        self.contentSelection = contentSelection
        self.internalStatus = internalStatus
        self.externalStatus = externalStatus
        self.listingIdSHA = listingIdSHA
        self.impressions = impressions
        self.reach = reach
        self.clicks = clicks
        self.shares = shares
        self.likes = likes
        self.managementFee = managementFee
        self.internalStatusUpdatedAt = internalStatusUpdatedAt
        self.externalStatusUpdatedAt = externalStatusUpdatedAt
        self.managementRate = managementRate
        self.listingAgentUserId = listingAgentUserId
        self.originalListingStatus = originalListingStatus
        self.designOptions = designOptions
        self.messageDetails = messageDetails
        self.displayedAgents = displayedAgents
        self.agentSelection = agentSelection
        self.adType = adType
        self.displayedAgentDetails = displayedAgentDetails

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.email = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.region = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.startTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I64:
                    self.stopTime = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.DOUBLE:
                    self.budget = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.DOUBLE:
                    self.spend = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.templateId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.contentSelection = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.I32:
                    self.internalStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.externalStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.listingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I64:
                    self.impressions = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I64:
                    self.reach = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.I64:
                    self.clicks = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.shares = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I64:
                    self.likes = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.DOUBLE:
                    self.managementFee = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I64:
                    self.internalStatusUpdatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I64:
                    self.externalStatusUpdatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.DOUBLE:
                    self.managementRate = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.listingAgentUserId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.I32:
                    self.originalListingStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRUCT:
                    self.designOptions = DesignOptions()
                    self.designOptions.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRUCT:
                    self.messageDetails = MessageDetails()
                    self.messageDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.LIST:
                    self.displayedAgents = []
                    (_etype7, _size10) = iprot.readListBegin()
                    for _i8 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.displayedAgents.append(_elem9)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I32:
                    self.agentSelection = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.I32:
                    self.adType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.STRUCT:
                    self.displayedAgentDetails = DisplayedAgentDetails()
                    self.displayedAgentDetails.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AdCampaign')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 4)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.email is not None:
            oprot.writeFieldBegin('email', TType.STRING, 5)
            oprot.writeString(self.email.encode('utf-8') if sys.version_info[0] == 2 else self.email)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 6)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 7)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.region is not None:
            oprot.writeFieldBegin('region', TType.STRING, 8)
            oprot.writeString(self.region.encode('utf-8') if sys.version_info[0] == 2 else self.region)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 9)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.startTime is not None:
            oprot.writeFieldBegin('startTime', TType.I64, 10)
            oprot.writeI64(self.startTime)
            oprot.writeFieldEnd()
        if self.stopTime is not None:
            oprot.writeFieldBegin('stopTime', TType.I64, 11)
            oprot.writeI64(self.stopTime)
            oprot.writeFieldEnd()
        if self.budget is not None:
            oprot.writeFieldBegin('budget', TType.DOUBLE, 12)
            oprot.writeDouble(self.budget)
            oprot.writeFieldEnd()
        if self.spend is not None:
            oprot.writeFieldBegin('spend', TType.DOUBLE, 13)
            oprot.writeDouble(self.spend)
            oprot.writeFieldEnd()
        if self.templateId is not None:
            oprot.writeFieldBegin('templateId', TType.STRING, 14)
            oprot.writeString(self.templateId.encode('utf-8') if sys.version_info[0] == 2 else self.templateId)
            oprot.writeFieldEnd()
        if self.contentSelection is not None:
            oprot.writeFieldBegin('contentSelection', TType.STRING, 15)
            oprot.writeString(self.contentSelection.encode('utf-8') if sys.version_info[0] == 2 else self.contentSelection)
            oprot.writeFieldEnd()
        if self.internalStatus is not None:
            oprot.writeFieldBegin('internalStatus', TType.I32, 16)
            oprot.writeI32(self.internalStatus)
            oprot.writeFieldEnd()
        if self.externalStatus is not None:
            oprot.writeFieldBegin('externalStatus', TType.I32, 17)
            oprot.writeI32(self.externalStatus)
            oprot.writeFieldEnd()
        if self.listingIdSHA is not None:
            oprot.writeFieldBegin('listingIdSHA', TType.STRING, 18)
            oprot.writeString(self.listingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.listingIdSHA)
            oprot.writeFieldEnd()
        if self.impressions is not None:
            oprot.writeFieldBegin('impressions', TType.I64, 19)
            oprot.writeI64(self.impressions)
            oprot.writeFieldEnd()
        if self.reach is not None:
            oprot.writeFieldBegin('reach', TType.I64, 20)
            oprot.writeI64(self.reach)
            oprot.writeFieldEnd()
        if self.clicks is not None:
            oprot.writeFieldBegin('clicks', TType.I64, 21)
            oprot.writeI64(self.clicks)
            oprot.writeFieldEnd()
        if self.shares is not None:
            oprot.writeFieldBegin('shares', TType.I64, 22)
            oprot.writeI64(self.shares)
            oprot.writeFieldEnd()
        if self.likes is not None:
            oprot.writeFieldBegin('likes', TType.I64, 23)
            oprot.writeI64(self.likes)
            oprot.writeFieldEnd()
        if self.managementFee is not None:
            oprot.writeFieldBegin('managementFee', TType.DOUBLE, 24)
            oprot.writeDouble(self.managementFee)
            oprot.writeFieldEnd()
        if self.internalStatusUpdatedAt is not None:
            oprot.writeFieldBegin('internalStatusUpdatedAt', TType.I64, 25)
            oprot.writeI64(self.internalStatusUpdatedAt)
            oprot.writeFieldEnd()
        if self.externalStatusUpdatedAt is not None:
            oprot.writeFieldBegin('externalStatusUpdatedAt', TType.I64, 26)
            oprot.writeI64(self.externalStatusUpdatedAt)
            oprot.writeFieldEnd()
        if self.managementRate is not None:
            oprot.writeFieldBegin('managementRate', TType.DOUBLE, 27)
            oprot.writeDouble(self.managementRate)
            oprot.writeFieldEnd()
        if self.listingAgentUserId is not None:
            oprot.writeFieldBegin('listingAgentUserId', TType.STRING, 28)
            oprot.writeString(self.listingAgentUserId.encode('utf-8') if sys.version_info[0] == 2 else self.listingAgentUserId)
            oprot.writeFieldEnd()
        if self.originalListingStatus is not None:
            oprot.writeFieldBegin('originalListingStatus', TType.I32, 29)
            oprot.writeI32(self.originalListingStatus)
            oprot.writeFieldEnd()
        if self.designOptions is not None:
            oprot.writeFieldBegin('designOptions', TType.STRUCT, 30)
            self.designOptions.write(oprot)
            oprot.writeFieldEnd()
        if self.messageDetails is not None:
            oprot.writeFieldBegin('messageDetails', TType.STRUCT, 31)
            self.messageDetails.write(oprot)
            oprot.writeFieldEnd()
        if self.displayedAgents is not None:
            oprot.writeFieldBegin('displayedAgents', TType.LIST, 32)
            oprot.writeListBegin(TType.STRING, len(self.displayedAgents))
            for _iter11 in self.displayedAgents:
                oprot.writeString(_iter11.encode('utf-8') if sys.version_info[0] == 2 else _iter11)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.agentSelection is not None:
            oprot.writeFieldBegin('agentSelection', TType.I32, 33)
            oprot.writeI32(self.agentSelection)
            oprot.writeFieldEnd()
        if self.adType is not None:
            oprot.writeFieldBegin('adType', TType.I32, 34)
            oprot.writeI32(self.adType)
            oprot.writeFieldEnd()
        if self.displayedAgentDetails is not None:
            oprot.writeFieldBegin('displayedAgentDetails', TType.STRUCT, 35)
            self.displayedAgentDetails.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
