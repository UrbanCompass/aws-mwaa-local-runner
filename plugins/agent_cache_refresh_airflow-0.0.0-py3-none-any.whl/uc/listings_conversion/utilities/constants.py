import os

# Team & application
TEAM_NAME = "listings_conversion"
CONVERSION_SERVICE_NAME = "conversion_service_py3"
SERVICE_NAME = os.environ.get("SERVICE_NAME", CONVERSION_SERVICE_NAME)
RETRY_COUNT = 3

# Environments
DEVELOPMENT = "development"
STAGING = "staging"
BETA = "beta"
GAMMA = "gamma"
PRODUCTION = "production"

# S3 NOTE: S3 does not like underscores
S3_PREFIX = "compass"

# datadog
DATADOG_HOST = "DATADOG_AGENT_HOST"
INCREMENT_AMT = 1
SOURCE_FEED_NAME = "source_feed_name"
MODE = "mode"

# AWS Generic
AWS_SERVICE_NAME = "data-conversion-service"
AWS_TEAM_NAME = "listings-conversion"
AWS_PREFIX = "compass.{}.{}".format(AWS_SERVICE_NAME, AWS_TEAM_NAME)

# AWS Session Client
DEFAULT_REGION = "us-east-1"
DEFAULT_SESSION_NAME = "session"
DEFAULT_DURATION_SECS = 3600  # 60 mins
DEFAULT_REFRESH_RETRIES = 10
DEFAULT_REFRESH_RETRIES_SECS = 2
EXTERNAL_ID = "149465543054"
ROLE_ARNS = {
    BETA: "arn:aws:iam::149465543054:role/ListingConversionServiceStaging",
    GAMMA: "arn:aws:iam::149465543054:role/ListingConversionServiceGamma",
    STAGING: "arn:aws:iam::149465543054:role/ListingConversionServiceStaging",
    PRODUCTION: "arn:aws:iam::149465543054:role/ListingConversionServiceProduction",
}

# Service return codes
SUCCESS_STATUS_CODE = 200
INCOMPLETE_STATUS_CODE = 206
UNSUCCESS_STATUS_CODE = 400
EXCEPTION_STATUS_CODE = 500

STATUS_CODE_METRIC_NAME_MAP = {
    SUCCESS_STATUS_CODE: "successful_conversion.count",
    INCOMPLETE_STATUS_CODE: "successful_conversion.count",
    UNSUCCESS_STATUS_CODE: "unsuccessful_conversion.count",
    EXCEPTION_STATUS_CODE: "error.count",
}

# Optimizely
OPTY_SERVICE = "opty_service"

# App Mode
APP_MODE = "APP_MODE"  # environment variable key
APP_INCREMENTAL = "incremental"
APP_MIGRATION = "migration"
APP_DEVELOPMENT = "development"

# Add Agent Team Members Whitelist
ADD_AGENT_TEAM_WHITELIST = [
    "sf_bareis",
    "sf_ebrd",
    "sf_mlslistings",
    "sf_sfar",
    "la_gpsmls",
    "la_rowmls",
    "la_claw_v2",
    "la_trestle_idx_plus",
    "la_itech",
    "san_diego_sandicor",
    "santa_barbara_montecito_mls_rets",
    "santa_barbara_montecito_nsbcrmls",
    "santa_barbara_montecito_rentals",
    "lake_tahoe_metrolist",
    "lake_tahoe_stmls",
    "lake_tahoe_tsmls",
    "bakersfield_avmls",
    "bakersfield_gemls",
    "la_vcrds",
    "la_pfar",
    "lake_tahoe_ivrmls",
]

"""
Example:
{
"event_type": "media_completeness_metrics",
"event_source": "conversion_support",
"listing_id": "bd9347160174d0874ff06eeda9be64332ca80dc5",
"source_name": "some_mls_source_name",
"json_data": {
    “imageCount”: 16,
    “virtualTourCount”: 1,
    “documentCount”: 0
}
"""

MEDIA_VALUE_SCHEMA = {
    "type": "record",
    "name": "media_metrics",
    "fields": [
        {"name": "event_type", "type": ["string", "null"]},
        {"name": "event_source", "type": ["string", "null"]},
        {"name": "listing_id", "type": "string"},
        {"name": "source_name", "type": ["string", "null"]},
        {"name": "json_data", "type": "map", "values": "long"},
    ],
}

MEDIA_KEY_SCHEMA = {
    "type": "record",
    "name": "mm_key",
    "fields": [{"name": "trace_id", "type": "string"}],
}
