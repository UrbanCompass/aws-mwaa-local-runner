
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class AccountType(object):
    FACEBOOK = 0
    GOOGLE = 1
    GOOGLE_CALENDAR = 2
    ICAL = 3
    IMAP = 4
    LINKED_IN = 5
    MICROSOFT_EXCHANGE = 6
    OFFICE_365 = 7
    TWITTER = 8
    NYLAS = 9
    TEST = 10

    _VALUES_TO_NAMES = {
        0: "FACEBOOK",
        1: "GOOGLE",
        2: "GOOGLE_CALENDAR",
        3: "ICAL",
        4: "IMAP",
        5: "LINKED_IN",
        6: "MICROSOFT_EXCHANGE",
        7: "OFFICE_365",
        8: "TWITTER",
        9: "NYLAS",
        10: "TEST",
    }

    _NAMES_TO_VALUES = {
        "FACEBOOK": 0,
        "GOOGLE": 1,
        "GOOGLE_CALENDAR": 2,
        "ICAL": 3,
        "IMAP": 4,
        "LINKED_IN": 5,
        "MICROSOFT_EXCHANGE": 6,
        "OFFICE_365": 7,
        "TWITTER": 8,
        "NYLAS": 9,
        "TEST": 10,
    }


class ContactSyncStatus(object):
    COMPLETE = 0
    ENQUEUED = 1
    RUNNING = 2

    _VALUES_TO_NAMES = {
        0: "COMPLETE",
        1: "ENQUEUED",
        2: "RUNNING",
    }

    _NAMES_TO_VALUES = {
        "COMPLETE": 0,
        "ENQUEUED": 1,
        "RUNNING": 2,
    }


class MessageSyncStatus(object):
    COMPLETE = 0
    ENQUEUED = 1
    RUNNING = 2

    _VALUES_TO_NAMES = {
        0: "COMPLETE",
        1: "ENQUEUED",
        2: "RUNNING",
    }

    _NAMES_TO_VALUES = {
        "COMPLETE": 0,
        "ENQUEUED": 1,
        "RUNNING": 2,
    }


class TypeCategory(object):
    CONTACTS = 0
    EMAIL = 1
    EVENTS = 2
    MESSAGES = 3

    _VALUES_TO_NAMES = {
        0: "CONTACTS",
        1: "EMAIL",
        2: "EVENTS",
        3: "MESSAGES",
    }

    _NAMES_TO_VALUES = {
        "CONTACTS": 0,
        "EMAIL": 1,
        "EVENTS": 2,
        "MESSAGES": 3,
    }


class ConnectedAccount(object):
    """
    Attributes:
     - id
     - createdAt
     - updatedAt
     - disabledAt
     - handle
     - externalId
     - type
     - contactSyncStatus
     - messageSyncStatus
     - typeCategories
     - signature
     - scopes
     - reconnect
     - lastSyncedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.I64, 'disabledAt', None, None, ),  # 4
        (5, TType.STRING, 'handle', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'externalId', 'UTF8', None, ),  # 6
        (7, TType.I32, 'type', None, None, ),  # 7
        (8, TType.I32, 'contactSyncStatus', None, None, ),  # 8
        (9, TType.I32, 'messageSyncStatus', None, None, ),  # 9
        (10, TType.LIST, 'typeCategories', (TType.I32, None, False), None, ),  # 10
        (11, TType.STRING, 'signature', 'UTF8', None, ),  # 11
        (12, TType.LIST, 'scopes', (TType.STRING, 'UTF8', False), None, ),  # 12
        (13, TType.BOOL, 'reconnect', None, None, ),  # 13
        (14, TType.I64, 'lastSyncedAt', None, None, ),  # 14
    )
    def __init__(self, id=None, createdAt=None, updatedAt=None, disabledAt=None, handle=None, externalId=None, type=None, contactSyncStatus=None, messageSyncStatus=None, typeCategories=None, signature=None, scopes=None, reconnect=None, lastSyncedAt=None, ):
        self.id = id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.disabledAt = disabledAt
        self.handle = handle
        self.externalId = externalId
        self.type = type
        self.contactSyncStatus = contactSyncStatus
        self.messageSyncStatus = messageSyncStatus
        self.typeCategories = typeCategories
        self.signature = signature
        self.scopes = scopes
        self.reconnect = reconnect
        self.lastSyncedAt = lastSyncedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.disabledAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.handle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.externalId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.contactSyncStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I32:
                    self.messageSyncStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.typeCategories = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = iprot.readI32()
                        self.typeCategories.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.signature = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.LIST:
                    self.scopes = []
                    (_etype45, _size48) = iprot.readListBegin()
                    for _i46 in range(_size48):
                        _elem47 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.scopes.append(_elem47)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.BOOL:
                    self.reconnect = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.I64:
                    self.lastSyncedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ConnectedAccount')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.disabledAt is not None:
            oprot.writeFieldBegin('disabledAt', TType.I64, 4)
            oprot.writeI64(self.disabledAt)
            oprot.writeFieldEnd()
        if self.handle is not None:
            oprot.writeFieldBegin('handle', TType.STRING, 5)
            oprot.writeString(self.handle.encode('utf-8') if sys.version_info[0] == 2 else self.handle)
            oprot.writeFieldEnd()
        if self.externalId is not None:
            oprot.writeFieldBegin('externalId', TType.STRING, 6)
            oprot.writeString(self.externalId.encode('utf-8') if sys.version_info[0] == 2 else self.externalId)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 7)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.contactSyncStatus is not None:
            oprot.writeFieldBegin('contactSyncStatus', TType.I32, 8)
            oprot.writeI32(self.contactSyncStatus)
            oprot.writeFieldEnd()
        if self.messageSyncStatus is not None:
            oprot.writeFieldBegin('messageSyncStatus', TType.I32, 9)
            oprot.writeI32(self.messageSyncStatus)
            oprot.writeFieldEnd()
        if self.typeCategories is not None:
            oprot.writeFieldBegin('typeCategories', TType.LIST, 10)
            oprot.writeListBegin(TType.I32, len(self.typeCategories))
            for _iter76 in self.typeCategories:
                oprot.writeI32(_iter76)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.signature is not None:
            oprot.writeFieldBegin('signature', TType.STRING, 11)
            oprot.writeString(self.signature.encode('utf-8') if sys.version_info[0] == 2 else self.signature)
            oprot.writeFieldEnd()
        if self.scopes is not None:
            oprot.writeFieldBegin('scopes', TType.LIST, 12)
            oprot.writeListBegin(TType.STRING, len(self.scopes))
            for _iter77 in self.scopes:
                oprot.writeString(_iter77.encode('utf-8') if sys.version_info[0] == 2 else _iter77)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.reconnect is not None:
            oprot.writeFieldBegin('reconnect', TType.BOOL, 13)
            oprot.writeBool(self.reconnect)
            oprot.writeFieldEnd()
        if self.lastSyncedAt is not None:
            oprot.writeFieldBegin('lastSyncedAt', TType.I64, 14)
            oprot.writeI64(self.lastSyncedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
