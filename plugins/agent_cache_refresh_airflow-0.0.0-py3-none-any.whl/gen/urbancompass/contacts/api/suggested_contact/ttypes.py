
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.contacts.api.contact.ttypes

from thrift.transport import TTransport


class ContactsSuggestedAction(object):
    ADD_CONTACT = 0
    ADD_ALL_CONTACTS = 1

    _VALUES_TO_NAMES = {
        0: "ADD_CONTACT",
        1: "ADD_ALL_CONTACTS",
    }

    _NAMES_TO_VALUES = {
        "ADD_CONTACT": 0,
        "ADD_ALL_CONTACTS": 1,
    }


class ContactsSuggestedMessage(object):
    """
    Attributes:
     - personId
     - action
     - contactId
     - contactPersonId
     - contactIds
     - jobId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'action', None, None, ),  # 2
        (3, TType.STRING, 'contactId', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'contactPersonId', 'UTF8', None, ),  # 4
        (5, TType.SET, 'contactIds', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRING, 'jobId', 'UTF8', None, ),  # 6
    )
    def __init__(self, personId=None, action=None, contactId=None, contactPersonId=None, contactIds=None, jobId=None, ):
        self.personId = personId
        self.action = action
        self.contactId = contactId
        self.contactPersonId = contactPersonId
        self.contactIds = contactIds
        self.jobId = jobId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.action = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.contactPersonId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.SET:
                    self.contactIds = set()
                    (_etype8, _size10) = iprot.readSetBegin()
                    for _i7 in range(_size10):
                        _elem9 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.contactIds.add(_elem9)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.jobId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactsSuggestedMessage')
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 1)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        if self.action is not None:
            oprot.writeFieldBegin('action', TType.I32, 2)
            oprot.writeI32(self.action)
            oprot.writeFieldEnd()
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 3)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.contactPersonId is not None:
            oprot.writeFieldBegin('contactPersonId', TType.STRING, 4)
            oprot.writeString(self.contactPersonId.encode('utf-8') if sys.version_info[0] == 2 else self.contactPersonId)
            oprot.writeFieldEnd()
        if self.contactIds is not None:
            oprot.writeFieldBegin('contactIds', TType.SET, 5)
            oprot.writeSetBegin(TType.STRING, len(self.contactIds))
            for _iter16 in self.contactIds:
                oprot.writeString(_iter16.encode('utf-8') if sys.version_info[0] == 2 else _iter16)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.jobId is not None:
            oprot.writeFieldBegin('jobId', TType.STRING, 6)
            oprot.writeString(self.jobId.encode('utf-8') if sys.version_info[0] == 2 else self.jobId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
