
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.contacts.api.audience.ttypes
import gen.urbancompass.contacts.api.custom_field.ttypes
import gen.urbancompass.contacts.api.deal.ttypes
import gen.urbancompass.contacts.api.group.ttypes
import gen.urbancompass.people.api.person.ttypes
import gen.urbancompass.qualified_leads.qualified_leads_api.ttypes
import gen.urbancompass.contacts.api.shallow_contact.ttypes
import gen.urbancompass.tasks.tasks.api.ttypes
import gen.urbancompass.user.user.ttypes

from thrift.transport import TTransport


class ContactType(object):
    CONTACT = 0
    AGENT = 1

    _VALUES_TO_NAMES = {
        0: "CONTACT",
        1: "AGENT",
    }

    _NAMES_TO_VALUES = {
        "CONTACT": 0,
        "AGENT": 1,
    }


class EntityType(object):
    UNKNOWN = 0
    INDIVIDUAL = 1
    TRUST = 2
    CORPORATION = 3
    LLC = 4
    PARTNERSHIP = 5
    ESTATE = 6
    POA = 7
    OTHER_ENTITY = 8

    _VALUES_TO_NAMES = {
        0: "UNKNOWN",
        1: "INDIVIDUAL",
        2: "TRUST",
        3: "CORPORATION",
        4: "LLC",
        5: "PARTNERSHIP",
        6: "ESTATE",
        7: "POA",
        8: "OTHER_ENTITY",
    }

    _NAMES_TO_VALUES = {
        "UNKNOWN": 0,
        "INDIVIDUAL": 1,
        "TRUST": 2,
        "CORPORATION": 3,
        "LLC": 4,
        "PARTNERSHIP": 5,
        "ESTATE": 6,
        "POA": 7,
        "OTHER_ENTITY": 8,
    }


class EventType(object):
    BIRTHDAY = 0
    ANNIVERSARY = 1
    OTHER = 2
    HOME_ANNIVERSARY = 3
    WEDDING_ANNIVERSARY = 4
    LEASE_ANNIVERSARY = 5

    _VALUES_TO_NAMES = {
        0: "BIRTHDAY",
        1: "ANNIVERSARY",
        2: "OTHER",
        3: "HOME_ANNIVERSARY",
        4: "WEDDING_ANNIVERSARY",
        5: "LEASE_ANNIVERSARY",
    }

    _NAMES_TO_VALUES = {
        "BIRTHDAY": 0,
        "ANNIVERSARY": 1,
        "OTHER": 2,
        "HOME_ANNIVERSARY": 3,
        "WEDDING_ANNIVERSARY": 4,
        "LEASE_ANNIVERSARY": 5,
    }


class FilterStatus(object):
    ACTIVE = 0
    INACTIVE = 1

    _VALUES_TO_NAMES = {
        0: "ACTIVE",
        1: "INACTIVE",
    }

    _NAMES_TO_VALUES = {
        "ACTIVE": 0,
        "INACTIVE": 1,
    }


class GetContactIdsField(object):
    CONTACT_ID = 0
    PERSON_ID = 1
    EMAIL = 2

    _VALUES_TO_NAMES = {
        0: "CONTACT_ID",
        1: "PERSON_ID",
        2: "EMAIL",
    }

    _NAMES_TO_VALUES = {
        "CONTACT_ID": 0,
        "PERSON_ID": 1,
        "EMAIL": 2,
    }


class GetContactTagsOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3
    NAME_ASC = 4
    NAME_DESC = 5
    NUMBER_OF_CONTACTS_ASC = 6
    NUMBER_OF_CONTACTS_DESC = 7

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
        4: "NAME_ASC",
        5: "NAME_DESC",
        6: "NUMBER_OF_CONTACTS_ASC",
        7: "NUMBER_OF_CONTACTS_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
        "NAME_ASC": 4,
        "NAME_DESC": 5,
        "NUMBER_OF_CONTACTS_ASC": 6,
        "NUMBER_OF_CONTACTS_DESC": 7,
    }


class GetContactsOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3
    FIRST_NAME_ASC = 4
    FIRST_NAME_DESC = 5
    LAST_NAME_ASC = 6
    LAST_NAME_DESC = 7
    LAST_CONTACTED_ASC = 8
    LAST_CONTACTED_DESC = 9
    USER_LAST_CONTACTED_AT_ASC = 10
    USER_LAST_CONTACTED_AT_DESC = 11
    TEAM_LAST_CONTACTED_AT_ASC = 12
    TEAM_LAST_CONTACTED_AT_DESC = 13
    LAST_ACTIVE_AT_ASC = 14
    LAST_ACTIVE_AT_DESC = 15
    CONTACT_ID_ASC = 16
    CONTACT_ID_DESC = 17
    SOURCE_ASC = 18
    SOURCE_DESC = 19
    MANUALLY_UPDATED_AT_ASC = 20
    MANUALLY_UPDATED_AT_DESC = 21
    TASK_DUE_DATE_ASC = 22
    TASK_DUE_DATE_DESC = 23
    BIRTHDAY_ASC = 24
    BIRTHDAY_DESC = 25
    TOTAL_INTERACTION_COUNT_ASC = 26
    TOTAL_INTERACTION_COUNT_DESC = 27
    QUALIFIED_LEADS_BUDGET_ASC = 28
    QUALIFIED_LEADS_BUDGET_DESC = 29
    QUALIFIED_LEADS_MOTIVATION_ASC = 30
    QUALIFIED_LEADS_MOTIVATION_DESC = 31
    QUALIFIED_LEADS_TIMELINE_END_ASC = 32
    QUALIFIED_LEADS_TIMELINE_END_DESC = 33
    DAYS_TO_FOLLOWUP_ASC = 34
    DAYS_TO_FOLLOWUP_DESC = 35
    DAYS_OVERDUE_ASC = 36
    DAYS_OVERDUE_DESC = 37

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
        4: "FIRST_NAME_ASC",
        5: "FIRST_NAME_DESC",
        6: "LAST_NAME_ASC",
        7: "LAST_NAME_DESC",
        8: "LAST_CONTACTED_ASC",
        9: "LAST_CONTACTED_DESC",
        10: "USER_LAST_CONTACTED_AT_ASC",
        11: "USER_LAST_CONTACTED_AT_DESC",
        12: "TEAM_LAST_CONTACTED_AT_ASC",
        13: "TEAM_LAST_CONTACTED_AT_DESC",
        14: "LAST_ACTIVE_AT_ASC",
        15: "LAST_ACTIVE_AT_DESC",
        16: "CONTACT_ID_ASC",
        17: "CONTACT_ID_DESC",
        18: "SOURCE_ASC",
        19: "SOURCE_DESC",
        20: "MANUALLY_UPDATED_AT_ASC",
        21: "MANUALLY_UPDATED_AT_DESC",
        22: "TASK_DUE_DATE_ASC",
        23: "TASK_DUE_DATE_DESC",
        24: "BIRTHDAY_ASC",
        25: "BIRTHDAY_DESC",
        26: "TOTAL_INTERACTION_COUNT_ASC",
        27: "TOTAL_INTERACTION_COUNT_DESC",
        28: "QUALIFIED_LEADS_BUDGET_ASC",
        29: "QUALIFIED_LEADS_BUDGET_DESC",
        30: "QUALIFIED_LEADS_MOTIVATION_ASC",
        31: "QUALIFIED_LEADS_MOTIVATION_DESC",
        32: "QUALIFIED_LEADS_TIMELINE_END_ASC",
        33: "QUALIFIED_LEADS_TIMELINE_END_DESC",
        34: "DAYS_TO_FOLLOWUP_ASC",
        35: "DAYS_TO_FOLLOWUP_DESC",
        36: "DAYS_OVERDUE_ASC",
        37: "DAYS_OVERDUE_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
        "FIRST_NAME_ASC": 4,
        "FIRST_NAME_DESC": 5,
        "LAST_NAME_ASC": 6,
        "LAST_NAME_DESC": 7,
        "LAST_CONTACTED_ASC": 8,
        "LAST_CONTACTED_DESC": 9,
        "USER_LAST_CONTACTED_AT_ASC": 10,
        "USER_LAST_CONTACTED_AT_DESC": 11,
        "TEAM_LAST_CONTACTED_AT_ASC": 12,
        "TEAM_LAST_CONTACTED_AT_DESC": 13,
        "LAST_ACTIVE_AT_ASC": 14,
        "LAST_ACTIVE_AT_DESC": 15,
        "CONTACT_ID_ASC": 16,
        "CONTACT_ID_DESC": 17,
        "SOURCE_ASC": 18,
        "SOURCE_DESC": 19,
        "MANUALLY_UPDATED_AT_ASC": 20,
        "MANUALLY_UPDATED_AT_DESC": 21,
        "TASK_DUE_DATE_ASC": 22,
        "TASK_DUE_DATE_DESC": 23,
        "BIRTHDAY_ASC": 24,
        "BIRTHDAY_DESC": 25,
        "TOTAL_INTERACTION_COUNT_ASC": 26,
        "TOTAL_INTERACTION_COUNT_DESC": 27,
        "QUALIFIED_LEADS_BUDGET_ASC": 28,
        "QUALIFIED_LEADS_BUDGET_DESC": 29,
        "QUALIFIED_LEADS_MOTIVATION_ASC": 30,
        "QUALIFIED_LEADS_MOTIVATION_DESC": 31,
        "QUALIFIED_LEADS_TIMELINE_END_ASC": 32,
        "QUALIFIED_LEADS_TIMELINE_END_DESC": 33,
        "DAYS_TO_FOLLOWUP_ASC": 34,
        "DAYS_TO_FOLLOWUP_DESC": 35,
        "DAYS_OVERDUE_ASC": 36,
        "DAYS_OVERDUE_DESC": 37,
    }


class GetInteractionsOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
    }


class GetMergeSuggestionsOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3
    ID_ASC = 4
    ID_DESC = 5

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
        4: "ID_ASC",
        5: "ID_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
        "ID_ASC": 4,
        "ID_DESC": 5,
    }


class GetOrganizationsOrder(object):
    CREATED_AT_ASC = 0
    CREATED_AT_DESC = 1
    UPDATED_AT_ASC = 2
    UPDATED_AT_DESC = 3

    _VALUES_TO_NAMES = {
        0: "CREATED_AT_ASC",
        1: "CREATED_AT_DESC",
        2: "UPDATED_AT_ASC",
        3: "UPDATED_AT_DESC",
    }

    _NAMES_TO_VALUES = {
        "CREATED_AT_ASC": 0,
        "CREATED_AT_DESC": 1,
        "UPDATED_AT_ASC": 2,
        "UPDATED_AT_DESC": 3,
    }


class GetSuggestedContactsOrder(object):
    FIRST_NAME_ASC = 0
    LAST_NAME_ASC = 1
    LAST_CONTACTED_DESC = 2
    CREATED_AT_DESC = 3

    _VALUES_TO_NAMES = {
        0: "FIRST_NAME_ASC",
        1: "LAST_NAME_ASC",
        2: "LAST_CONTACTED_DESC",
        3: "CREATED_AT_DESC",
    }

    _NAMES_TO_VALUES = {
        "FIRST_NAME_ASC": 0,
        "LAST_NAME_ASC": 1,
        "LAST_CONTACTED_DESC": 2,
        "CREATED_AT_DESC": 3,
    }


class InteractionSubtype(object):
    GIFT_ORDERED = 0
    GIFT_SHIPPED = 1
    GIFT_DELIVERED = 2
    NOTIFICATIONS_EMAIL = 3
    NOTIFICATIONS_NONTRANSACTIONABLE_EMAIL = 4
    CRM_COMPASS_SMS = 5

    _VALUES_TO_NAMES = {
        0: "GIFT_ORDERED",
        1: "GIFT_SHIPPED",
        2: "GIFT_DELIVERED",
        3: "NOTIFICATIONS_EMAIL",
        4: "NOTIFICATIONS_NONTRANSACTIONABLE_EMAIL",
        5: "CRM_COMPASS_SMS",
    }

    _NAMES_TO_VALUES = {
        "GIFT_ORDERED": 0,
        "GIFT_SHIPPED": 1,
        "GIFT_DELIVERED": 2,
        "NOTIFICATIONS_EMAIL": 3,
        "NOTIFICATIONS_NONTRANSACTIONABLE_EMAIL": 4,
        "CRM_COMPASS_SMS": 5,
    }


class InteractionType(object):
    EMAIL = 0
    SMS = 1
    PHONE = 2
    IN_PERSON = 3
    CALENDAR_EVENT = 4
    TWITTER = 5
    FACEBOOK = 6
    LINKED_IN = 7
    MAIL_CHIMP = 8
    ZAPIER = 9
    MAD_MIMI = 10
    OTHER = 11
    CUSTOM = 12

    _VALUES_TO_NAMES = {
        0: "EMAIL",
        1: "SMS",
        2: "PHONE",
        3: "IN_PERSON",
        4: "CALENDAR_EVENT",
        5: "TWITTER",
        6: "FACEBOOK",
        7: "LINKED_IN",
        8: "MAIL_CHIMP",
        9: "ZAPIER",
        10: "MAD_MIMI",
        11: "OTHER",
        12: "CUSTOM",
    }

    _NAMES_TO_VALUES = {
        "EMAIL": 0,
        "SMS": 1,
        "PHONE": 2,
        "IN_PERSON": 3,
        "CALENDAR_EVENT": 4,
        "TWITTER": 5,
        "FACEBOOK": 6,
        "LINKED_IN": 7,
        "MAIL_CHIMP": 8,
        "ZAPIER": 9,
        "MAD_MIMI": 10,
        "OTHER": 11,
        "CUSTOM": 12,
    }


class LicenseState(object):
    AL = 0
    AK = 1
    AZ = 2
    AR = 3
    CA = 4
    CZ = 5
    CO = 6
    CT = 7
    DE = 8
    DC = 9
    FL = 10
    GA = 11
    GU = 12
    HI = 13
    ID = 14
    IL = 15
    IND = 16
    IA = 17
    KS = 18
    KY = 19
    LA = 20
    ME = 21
    MD = 22
    MA = 23
    MI = 24
    MN = 25
    MS = 26
    MO = 27
    MT = 28
    NE = 29
    NV = 30
    NH = 31
    NJ = 32
    NM = 33
    NY = 34
    NC = 35
    ND = 36
    OH = 37
    OK = 38
    OR = 39
    PA = 40
    PR = 41
    RI = 42
    SC = 43
    SD = 44
    TN = 45
    TX = 46
    UT = 47
    VT = 48
    VI = 49
    VA = 50
    WA = 51
    WV = 52
    WI = 53
    WY = 54
    UNKNOWN = 55

    _VALUES_TO_NAMES = {
        0: "AL",
        1: "AK",
        2: "AZ",
        3: "AR",
        4: "CA",
        5: "CZ",
        6: "CO",
        7: "CT",
        8: "DE",
        9: "DC",
        10: "FL",
        11: "GA",
        12: "GU",
        13: "HI",
        14: "ID",
        15: "IL",
        16: "IND",
        17: "IA",
        18: "KS",
        19: "KY",
        20: "LA",
        21: "ME",
        22: "MD",
        23: "MA",
        24: "MI",
        25: "MN",
        26: "MS",
        27: "MO",
        28: "MT",
        29: "NE",
        30: "NV",
        31: "NH",
        32: "NJ",
        33: "NM",
        34: "NY",
        35: "NC",
        36: "ND",
        37: "OH",
        38: "OK",
        39: "OR",
        40: "PA",
        41: "PR",
        42: "RI",
        43: "SC",
        44: "SD",
        45: "TN",
        46: "TX",
        47: "UT",
        48: "VT",
        49: "VI",
        50: "VA",
        51: "WA",
        52: "WV",
        53: "WI",
        54: "WY",
        55: "UNKNOWN",
    }

    _NAMES_TO_VALUES = {
        "AL": 0,
        "AK": 1,
        "AZ": 2,
        "AR": 3,
        "CA": 4,
        "CZ": 5,
        "CO": 6,
        "CT": 7,
        "DE": 8,
        "DC": 9,
        "FL": 10,
        "GA": 11,
        "GU": 12,
        "HI": 13,
        "ID": 14,
        "IL": 15,
        "IND": 16,
        "IA": 17,
        "KS": 18,
        "KY": 19,
        "LA": 20,
        "ME": 21,
        "MD": 22,
        "MA": 23,
        "MI": 24,
        "MN": 25,
        "MS": 26,
        "MO": 27,
        "MT": 28,
        "NE": 29,
        "NV": 30,
        "NH": 31,
        "NJ": 32,
        "NM": 33,
        "NY": 34,
        "NC": 35,
        "ND": 36,
        "OH": 37,
        "OK": 38,
        "OR": 39,
        "PA": 40,
        "PR": 41,
        "RI": 42,
        "SC": 43,
        "SD": 44,
        "TN": 45,
        "TX": 46,
        "UT": 47,
        "VT": 48,
        "VI": 49,
        "VA": 50,
        "WA": 51,
        "WV": 52,
        "WI": 53,
        "WY": 54,
        "UNKNOWN": 55,
    }


class LinkedContactLabel(object):
    AGENT = 0
    CHILD = 1
    CLIENT = 2
    COWORKER = 3
    FATHER_MOTHER = 4
    FRIEND = 5
    OTHER = 6
    PARTNER = 7
    REFEREE = 8
    REFERRER = 9
    RELATIVE = 10
    SIBLING = 11
    SPOUSE = 12

    _VALUES_TO_NAMES = {
        0: "AGENT",
        1: "CHILD",
        2: "CLIENT",
        3: "COWORKER",
        4: "FATHER_MOTHER",
        5: "FRIEND",
        6: "OTHER",
        7: "PARTNER",
        8: "REFEREE",
        9: "REFERRER",
        10: "RELATIVE",
        11: "SIBLING",
        12: "SPOUSE",
    }

    _NAMES_TO_VALUES = {
        "AGENT": 0,
        "CHILD": 1,
        "CLIENT": 2,
        "COWORKER": 3,
        "FATHER_MOTHER": 4,
        "FRIEND": 5,
        "OTHER": 6,
        "PARTNER": 7,
        "REFEREE": 8,
        "REFERRER": 9,
        "RELATIVE": 10,
        "SIBLING": 11,
        "SPOUSE": 12,
    }


class OrgRecsCategory(object):
    AGENT = 0

    _VALUES_TO_NAMES = {
        0: "AGENT",
    }

    _NAMES_TO_VALUES = {
        "AGENT": 0,
    }


class PreferredContactMethod(object):
    EMAIL = 0
    PHONE = 1
    TEXT = 2

    _VALUES_TO_NAMES = {
        0: "EMAIL",
        1: "PHONE",
        2: "TEXT",
    }

    _NAMES_TO_VALUES = {
        "EMAIL": 0,
        "PHONE": 1,
        "TEXT": 2,
    }


class RelationshipType(object):
    PENDING_REVIEW = 0
    APPROVED_FOR_CRM = 1
    MARKETING_CENTER = 2
    LIKELY_PAST_CLIENT = 3

    _VALUES_TO_NAMES = {
        0: "PENDING_REVIEW",
        1: "APPROVED_FOR_CRM",
        2: "MARKETING_CENTER",
        3: "LIKELY_PAST_CLIENT",
    }

    _NAMES_TO_VALUES = {
        "PENDING_REVIEW": 0,
        "APPROVED_FOR_CRM": 1,
        "MARKETING_CENTER": 2,
        "LIKELY_PAST_CLIENT": 3,
    }


class SuggestedContactsView(object):
    EVERYONE = 0
    SUGGESTED = 1

    _VALUES_TO_NAMES = {
        0: "EVERYONE",
        1: "SUGGESTED",
    }

    _NAMES_TO_VALUES = {
        "EVERYONE": 0,
        "SUGGESTED": 1,
    }


class AssociatedItem(object):
    """
    Attributes:
     - id
     - createdAt
     - updatedAt
     - contactCount
     - name
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.I32, 'contactCount', None, None, ),  # 4
        (5, TType.STRING, 'name', 'UTF8', None, ),  # 5
    )
    def __init__(self, id=None, createdAt=None, updatedAt=None, contactCount=None, name=None, ):
        self.id = id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.contactCount = contactCount
        self.name = name

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.contactCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AssociatedItem')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.contactCount is not None:
            oprot.writeFieldBegin('contactCount', TType.I32, 4)
            oprot.writeI32(self.contactCount)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 5)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactAddress(object):
    """
    Attributes:
     - id
     - full_address
     - label
     - street1
     - street2
     - city
     - state
     - zip
     - country
     - verificationFlag
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'full_address', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'label', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'street1', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'street2', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'city', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'state', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'zip', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'country', 'UTF8', None, ),  # 9
        (10, TType.I32, 'verificationFlag', None, None, ),  # 10
    )
    def __init__(self, id=None, full_address=None, label=None, street1=None, street2=None, city=None, state=None, zip=None, country=None, verificationFlag=None, ):
        self.id = id
        self.full_address = full_address
        self.label = label
        self.street1 = street1
        self.street2 = street2
        self.city = city
        self.state = state
        self.zip = zip
        self.country = country
        self.verificationFlag = verificationFlag

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.full_address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.street1 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.street2 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.zip = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.country = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I32:
                    self.verificationFlag = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactAddress')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.full_address is not None:
            oprot.writeFieldBegin('full_address', TType.STRING, 2)
            oprot.writeString(self.full_address.encode('utf-8') if sys.version_info[0] == 2 else self.full_address)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 3)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.street1 is not None:
            oprot.writeFieldBegin('street1', TType.STRING, 4)
            oprot.writeString(self.street1.encode('utf-8') if sys.version_info[0] == 2 else self.street1)
            oprot.writeFieldEnd()
        if self.street2 is not None:
            oprot.writeFieldBegin('street2', TType.STRING, 5)
            oprot.writeString(self.street2.encode('utf-8') if sys.version_info[0] == 2 else self.street2)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 6)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 7)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zip is not None:
            oprot.writeFieldBegin('zip', TType.STRING, 8)
            oprot.writeString(self.zip.encode('utf-8') if sys.version_info[0] == 2 else self.zip)
            oprot.writeFieldEnd()
        if self.country is not None:
            oprot.writeFieldBegin('country', TType.STRING, 9)
            oprot.writeString(self.country.encode('utf-8') if sys.version_info[0] == 2 else self.country)
            oprot.writeFieldEnd()
        if self.verificationFlag is not None:
            oprot.writeFieldBegin('verificationFlag', TType.I32, 10)
            oprot.writeI32(self.verificationFlag)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactPhoneNumber(object):
    """
    Attributes:
     - id
     - label
     - number
     - verificationFlag
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'number', 'UTF8', None, ),  # 3
        (4, TType.I32, 'verificationFlag', None, None, ),  # 4
    )
    def __init__(self, id=None, label=None, number=None, verificationFlag=None, ):
        self.id = id
        self.label = label
        self.number = number
        self.verificationFlag = verificationFlag

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.number = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.verificationFlag = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactPhoneNumber')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.number is not None:
            oprot.writeFieldBegin('number', TType.STRING, 3)
            oprot.writeString(self.number.encode('utf-8') if sys.version_info[0] == 2 else self.number)
            oprot.writeFieldEnd()
        if self.verificationFlag is not None:
            oprot.writeFieldBegin('verificationFlag', TType.I32, 4)
            oprot.writeI32(self.verificationFlag)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactSocialMediaProfile(object):
    """
    Attributes:
     - id
     - label
     - url
     - verificationFlag
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'url', 'UTF8', None, ),  # 3
        (4, TType.I32, 'verificationFlag', None, None, ),  # 4
    )
    def __init__(self, id=None, label=None, url=None, verificationFlag=None, ):
        self.id = id
        self.label = label
        self.url = url
        self.verificationFlag = verificationFlag

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.url = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.verificationFlag = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactSocialMediaProfile')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.url is not None:
            oprot.writeFieldBegin('url', TType.STRING, 3)
            oprot.writeString(self.url.encode('utf-8') if sys.version_info[0] == 2 else self.url)
            oprot.writeFieldEnd()
        if self.verificationFlag is not None:
            oprot.writeFieldBegin('verificationFlag', TType.I32, 4)
            oprot.writeI32(self.verificationFlag)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ContactWebsite(object):
    """
    Attributes:
     - id
     - label
     - address
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'label', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'address', 'UTF8', None, ),  # 3
    )
    def __init__(self, id=None, label=None, address=None, ):
        self.id = id
        self.label = label
        self.address = address

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.label = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ContactWebsite')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.STRING, 2)
            oprot.writeString(self.label.encode('utf-8') if sys.version_info[0] == 2 else self.label)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 3)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class ExportFilter(object):
    """
    Attributes:
     - assignedTo
     - groups
     - companies
     - connectedAccounts
     - connectedTo
     - createdAtAfter
     - createdAtBefore
     - customFields
     - lastContactedAfter
     - lastContactedBefore
     - locations
     - order
     - query
     - status
     - tags
     - teamSearch
     - timesContactedMax
     - timesContactedMin
     - source
     - contactIDs
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'assignedTo', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'groups', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'companies', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.LIST, 'connectedAccounts', (TType.STRING, 'UTF8', False), None, ),  # 4
        (5, TType.LIST, 'connectedTo', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.I64, 'createdAtAfter', None, None, ),  # 6
        (7, TType.I64, 'createdAtBefore', None, None, ),  # 7
        (8, TType.MAP, 'customFields', (TType.STRING, 'UTF8', TType.STRING, 'UTF8', False), None, ),  # 8
        (9, TType.I64, 'lastContactedAfter', None, None, ),  # 9
        (10, TType.I64, 'lastContactedBefore', None, None, ),  # 10
        (11, TType.LIST, 'locations', (TType.STRING, 'UTF8', False), None, ),  # 11
        (12, TType.I32, 'order', None, None, ),  # 12
        (13, TType.STRING, 'query', 'UTF8', None, ),  # 13
        (14, TType.LIST, 'status', (TType.I32, None, False), None, ),  # 14
        (15, TType.LIST, 'tags', (TType.STRING, 'UTF8', False), None, ),  # 15
        (16, TType.BOOL, 'teamSearch', None, None, ),  # 16
        (17, TType.I32, 'timesContactedMax', None, None, ),  # 17
        (18, TType.I32, 'timesContactedMin', None, None, ),  # 18
        (19, TType.STRING, 'source', 'UTF8', None, ),  # 19
        (20, TType.LIST, 'contactIDs', (TType.STRING, 'UTF8', False), None, ),  # 20
    )
    def __init__(self, assignedTo=None, groups=None, companies=None, connectedAccounts=None, connectedTo=None, createdAtAfter=None, createdAtBefore=None, customFields=None, lastContactedAfter=None, lastContactedBefore=None, locations=None, order=None, query=None, status=None, tags=None, teamSearch=None, timesContactedMax=None, timesContactedMin=None, source=None, contactIDs=None, ):
        self.assignedTo = assignedTo
        self.groups = groups
        self.companies = companies
        self.connectedAccounts = connectedAccounts
        self.connectedTo = connectedTo
        self.createdAtAfter = createdAtAfter
        self.createdAtBefore = createdAtBefore
        self.customFields = customFields
        self.lastContactedAfter = lastContactedAfter
        self.lastContactedBefore = lastContactedBefore
        self.locations = locations
        self.order = order
        self.query = query
        self.status = status
        self.tags = tags
        self.teamSearch = teamSearch
        self.timesContactedMax = timesContactedMax
        self.timesContactedMin = timesContactedMin
        self.source = source
        self.contactIDs = contactIDs

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.assignedTo = []
                    (_etype165, _size168) = iprot.readListBegin()
                    for _i166 in range(_size168):
                        _elem167 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.assignedTo.append(_elem167)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.groups = []
                    (_etype169, _size172) = iprot.readListBegin()
                    for _i170 in range(_size172):
                        _elem171 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.groups.append(_elem171)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.companies = []
                    (_etype173, _size176) = iprot.readListBegin()
                    for _i174 in range(_size176):
                        _elem175 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.companies.append(_elem175)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.connectedAccounts = []
                    (_etype177, _size180) = iprot.readListBegin()
                    for _i178 in range(_size180):
                        _elem179 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.connectedAccounts.append(_elem179)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.connectedTo = []
                    (_etype181, _size184) = iprot.readListBegin()
                    for _i182 in range(_size184):
                        _elem183 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.connectedTo.append(_elem183)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAtBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.MAP:
                    self.customFields = {}
                    (_ktype186, _vtype187, _size190) = iprot.readMapBegin()
                    for _i185 in range(_size190):
                        _key188 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val189 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.customFields[_key188] = _val189
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.lastContactedAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.I64:
                    self.lastContactedBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.locations = []
                    (_etype191, _size194) = iprot.readListBegin()
                    for _i192 in range(_size194):
                        _elem193 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.locations.append(_elem193)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.order = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.query = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.status = []
                    (_etype195, _size198) = iprot.readListBegin()
                    for _i196 in range(_size198):
                        _elem197 = iprot.readI32()
                        self.status.append(_elem197)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.tags = []
                    (_etype199, _size202) = iprot.readListBegin()
                    for _i200 in range(_size202):
                        _elem201 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.tags.append(_elem201)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.BOOL:
                    self.teamSearch = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.I32:
                    self.timesContactedMax = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.I32:
                    self.timesContactedMin = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.source = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.contactIDs = []
                    (_etype203, _size206) = iprot.readListBegin()
                    for _i204 in range(_size206):
                        _elem205 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.contactIDs.append(_elem205)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('ExportFilter')
        if self.assignedTo is not None:
            oprot.writeFieldBegin('assignedTo', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.assignedTo))
            for _iter207 in self.assignedTo:
                oprot.writeString(_iter207.encode('utf-8') if sys.version_info[0] == 2 else _iter207)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.groups is not None:
            oprot.writeFieldBegin('groups', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.groups))
            for _iter208 in self.groups:
                oprot.writeString(_iter208.encode('utf-8') if sys.version_info[0] == 2 else _iter208)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.companies is not None:
            oprot.writeFieldBegin('companies', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.companies))
            for _iter209 in self.companies:
                oprot.writeString(_iter209.encode('utf-8') if sys.version_info[0] == 2 else _iter209)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.connectedAccounts is not None:
            oprot.writeFieldBegin('connectedAccounts', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.connectedAccounts))
            for _iter210 in self.connectedAccounts:
                oprot.writeString(_iter210.encode('utf-8') if sys.version_info[0] == 2 else _iter210)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.connectedTo is not None:
            oprot.writeFieldBegin('connectedTo', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.connectedTo))
            for _iter211 in self.connectedTo:
                oprot.writeString(_iter211.encode('utf-8') if sys.version_info[0] == 2 else _iter211)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdAtAfter is not None:
            oprot.writeFieldBegin('createdAtAfter', TType.I64, 6)
            oprot.writeI64(self.createdAtAfter)
            oprot.writeFieldEnd()
        if self.createdAtBefore is not None:
            oprot.writeFieldBegin('createdAtBefore', TType.I64, 7)
            oprot.writeI64(self.createdAtBefore)
            oprot.writeFieldEnd()
        if self.customFields is not None:
            oprot.writeFieldBegin('customFields', TType.MAP, 8)
            oprot.writeMapBegin(TType.STRING, TType.STRING, len(self.customFields))
            for _kiter212, _viter213 in self.customFields.items():
                oprot.writeString(_kiter212.encode('utf-8') if sys.version_info[0] == 2 else _kiter212)
                oprot.writeString(_viter213.encode('utf-8') if sys.version_info[0] == 2 else _viter213)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.lastContactedAfter is not None:
            oprot.writeFieldBegin('lastContactedAfter', TType.I64, 9)
            oprot.writeI64(self.lastContactedAfter)
            oprot.writeFieldEnd()
        if self.lastContactedBefore is not None:
            oprot.writeFieldBegin('lastContactedBefore', TType.I64, 10)
            oprot.writeI64(self.lastContactedBefore)
            oprot.writeFieldEnd()
        if self.locations is not None:
            oprot.writeFieldBegin('locations', TType.LIST, 11)
            oprot.writeListBegin(TType.STRING, len(self.locations))
            for _iter214 in self.locations:
                oprot.writeString(_iter214.encode('utf-8') if sys.version_info[0] == 2 else _iter214)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.order is not None:
            oprot.writeFieldBegin('order', TType.I32, 12)
            oprot.writeI32(self.order)
            oprot.writeFieldEnd()
        if self.query is not None:
            oprot.writeFieldBegin('query', TType.STRING, 13)
            oprot.writeString(self.query.encode('utf-8') if sys.version_info[0] == 2 else self.query)
            oprot.writeFieldEnd()
        if self.status is not None:
            oprot.writeFieldBegin('status', TType.LIST, 14)
            oprot.writeListBegin(TType.I32, len(self.status))
            for _iter215 in self.status:
                oprot.writeI32(_iter215)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.LIST, 15)
            oprot.writeListBegin(TType.STRING, len(self.tags))
            for _iter216 in self.tags:
                oprot.writeString(_iter216.encode('utf-8') if sys.version_info[0] == 2 else _iter216)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.teamSearch is not None:
            oprot.writeFieldBegin('teamSearch', TType.BOOL, 16)
            oprot.writeBool(self.teamSearch)
            oprot.writeFieldEnd()
        if self.timesContactedMax is not None:
            oprot.writeFieldBegin('timesContactedMax', TType.I32, 17)
            oprot.writeI32(self.timesContactedMax)
            oprot.writeFieldEnd()
        if self.timesContactedMin is not None:
            oprot.writeFieldBegin('timesContactedMin', TType.I32, 18)
            oprot.writeI32(self.timesContactedMin)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.STRING, 19)
            oprot.writeString(self.source.encode('utf-8') if sys.version_info[0] == 2 else self.source)
            oprot.writeFieldEnd()
        if self.contactIDs is not None:
            oprot.writeFieldBegin('contactIDs', TType.LIST, 20)
            oprot.writeListBegin(TType.STRING, len(self.contactIDs))
            for _iter217 in self.contactIDs:
                oprot.writeString(_iter217.encode('utf-8') if sys.version_info[0] == 2 else _iter217)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class LinkedContact(object):
    """
    Attributes:
     - contactId
     - label
     - contact
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'label', None, None, ),  # 2
        (3, TType.STRUCT, 'contact', (gen.urbancompass.contacts.api.shallow_contact.ttypes.ShallowContact, gen.urbancompass.contacts.api.shallow_contact.ttypes.ShallowContact.thrift_spec), None, ),  # 3
    )
    def __init__(self, contactId=None, label=None, contact=None, ):
        self.contactId = contactId
        self.label = label
        self.contact = contact

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.label = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.contact = gen.urbancompass.contacts.api.shallow_contact.ttypes.ShallowContact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('LinkedContact')
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 1)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.label is not None:
            oprot.writeFieldBegin('label', TType.I32, 2)
            oprot.writeI32(self.label)
            oprot.writeFieldEnd()
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 3)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MergeSuggestionsFilter(object):
    """
    Attributes:
     - order
     - id
     - idNot
     - createdAtNone
     - createdAtAfter
     - createdAtBefore
     - updatedAtAfter
     - updatedAtBefore
     - updatedAtNone
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'order', (TType.I32, None, False), None, ),  # 1
        (2, TType.LIST, 'id', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.LIST, 'idNot', (TType.STRING, 'UTF8', False), None, ),  # 3
        (4, TType.BOOL, 'createdAtNone', None, None, ),  # 4
        (5, TType.I64, 'createdAtAfter', None, None, ),  # 5
        (6, TType.I64, 'createdAtBefore', None, None, ),  # 6
        (7, TType.I64, 'updatedAtAfter', None, None, ),  # 7
        (8, TType.I64, 'updatedAtBefore', None, None, ),  # 8
        (9, TType.BOOL, 'updatedAtNone', None, None, ),  # 9
    )
    def __init__(self, order=None, id=None, idNot=None, createdAtNone=None, createdAtAfter=None, createdAtBefore=None, updatedAtAfter=None, updatedAtBefore=None, updatedAtNone=None, ):
        self.order = order
        self.id = id
        self.idNot = idNot
        self.createdAtNone = createdAtNone
        self.createdAtAfter = createdAtAfter
        self.createdAtBefore = createdAtBefore
        self.updatedAtAfter = updatedAtAfter
        self.updatedAtBefore = updatedAtBefore
        self.updatedAtNone = updatedAtNone

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.order = []
                    (_etype218, _size221) = iprot.readListBegin()
                    for _i219 in range(_size221):
                        _elem220 = iprot.readI32()
                        self.order.append(_elem220)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.id = []
                    (_etype222, _size225) = iprot.readListBegin()
                    for _i223 in range(_size225):
                        _elem224 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.id.append(_elem224)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.idNot = []
                    (_etype226, _size229) = iprot.readListBegin()
                    for _i227 in range(_size229):
                        _elem228 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.idNot.append(_elem228)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.BOOL:
                    self.createdAtNone = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.createdAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAtBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.updatedAtAfter = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAtBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.BOOL:
                    self.updatedAtNone = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MergeSuggestionsFilter')
        if self.order is not None:
            oprot.writeFieldBegin('order', TType.LIST, 1)
            oprot.writeListBegin(TType.I32, len(self.order))
            for _iter230 in self.order:
                oprot.writeI32(_iter230)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.id))
            for _iter231 in self.id:
                oprot.writeString(_iter231.encode('utf-8') if sys.version_info[0] == 2 else _iter231)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.idNot is not None:
            oprot.writeFieldBegin('idNot', TType.LIST, 3)
            oprot.writeListBegin(TType.STRING, len(self.idNot))
            for _iter232 in self.idNot:
                oprot.writeString(_iter232.encode('utf-8') if sys.version_info[0] == 2 else _iter232)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.createdAtNone is not None:
            oprot.writeFieldBegin('createdAtNone', TType.BOOL, 4)
            oprot.writeBool(self.createdAtNone)
            oprot.writeFieldEnd()
        if self.createdAtAfter is not None:
            oprot.writeFieldBegin('createdAtAfter', TType.I64, 5)
            oprot.writeI64(self.createdAtAfter)
            oprot.writeFieldEnd()
        if self.createdAtBefore is not None:
            oprot.writeFieldBegin('createdAtBefore', TType.I64, 6)
            oprot.writeI64(self.createdAtBefore)
            oprot.writeFieldEnd()
        if self.updatedAtAfter is not None:
            oprot.writeFieldBegin('updatedAtAfter', TType.I64, 7)
            oprot.writeI64(self.updatedAtAfter)
            oprot.writeFieldEnd()
        if self.updatedAtBefore is not None:
            oprot.writeFieldBegin('updatedAtBefore', TType.I64, 8)
            oprot.writeI64(self.updatedAtBefore)
            oprot.writeFieldEnd()
        if self.updatedAtNone is not None:
            oprot.writeFieldBegin('updatedAtNone', TType.BOOL, 9)
            oprot.writeBool(self.updatedAtNone)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MergeSuggestionsInput(object):
    """
    Attributes:
     - accepted
     - rejected
     - primaryContactId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'accepted', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'rejected', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'primaryContactId', 'UTF8', None, ),  # 3
    )
    def __init__(self, accepted=None, rejected=None, primaryContactId=None, ):
        self.accepted = accepted
        self.rejected = rejected
        self.primaryContactId = primaryContactId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.accepted = []
                    (_etype233, _size236) = iprot.readListBegin()
                    for _i234 in range(_size236):
                        _elem235 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.accepted.append(_elem235)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.rejected = []
                    (_etype237, _size240) = iprot.readListBegin()
                    for _i238 in range(_size240):
                        _elem239 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.rejected.append(_elem239)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.primaryContactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MergeSuggestionsInput')
        if self.accepted is not None:
            oprot.writeFieldBegin('accepted', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.accepted))
            for _iter241 in self.accepted:
                oprot.writeString(_iter241.encode('utf-8') if sys.version_info[0] == 2 else _iter241)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.rejected is not None:
            oprot.writeFieldBegin('rejected', TType.LIST, 2)
            oprot.writeListBegin(TType.STRING, len(self.rejected))
            for _iter242 in self.rejected:
                oprot.writeString(_iter242.encode('utf-8') if sys.version_info[0] == 2 else _iter242)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.primaryContactId is not None:
            oprot.writeFieldBegin('primaryContactId', TType.STRING, 3)
            oprot.writeString(self.primaryContactId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryContactId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RecurringEvent(object):
    """
    Attributes:
     - contactId
     - createdAt
     - updatedAt
     - dueDate
     - id
     - title
     - eventType
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactId', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.STRING, 'dueDate', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'id', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'title', 'UTF8', None, ),  # 6
        (7, TType.I32, 'eventType', None, None, ),  # 7
    )
    def __init__(self, contactId=None, createdAt=None, updatedAt=None, dueDate=None, id=None, title=None, eventType=None, ):
        self.contactId = contactId
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.dueDate = dueDate
        self.id = id
        self.title = title
        self.eventType = eventType

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.dueDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.eventType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RecurringEvent')
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 1)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.dueDate is not None:
            oprot.writeFieldBegin('dueDate', TType.STRING, 4)
            oprot.writeString(self.dueDate.encode('utf-8') if sys.version_info[0] == 2 else self.dueDate)
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 5)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 6)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.eventType is not None:
            oprot.writeFieldBegin('eventType', TType.I32, 7)
            oprot.writeI32(self.eventType)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class RelationshipShare(object):
    """
    Attributes:
     - personID
     - direct
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'personID', 'UTF8', None, ),  # 1
        (2, TType.BOOL, 'direct', None, None, ),  # 2
    )
    def __init__(self, personID=None, direct=None, ):
        self.personID = personID
        self.direct = direct

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.personID = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.BOOL:
                    self.direct = iprot.readBool()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('RelationshipShare')
        if self.personID is not None:
            oprot.writeFieldBegin('personID', TType.STRING, 1)
            oprot.writeString(self.personID.encode('utf-8') if sys.version_info[0] == 2 else self.personID)
            oprot.writeFieldEnd()
        if self.direct is not None:
            oprot.writeFieldBegin('direct', TType.BOOL, 2)
            oprot.writeBool(self.direct)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Tag(object):
    """
    Attributes:
     - id
     - name
     - createdAt
     - updatedAt
     - contactCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'name', 'UTF8', None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.I32, 'contactCount', None, None, ),  # 5
    )
    def __init__(self, id=None, name=None, createdAt=None, updatedAt=None, contactCount=None, ):
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.contactCount = contactCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.contactCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Tag')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 2)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.contactCount is not None:
            oprot.writeFieldBegin('contactCount', TType.I32, 5)
            oprot.writeI32(self.contactCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TimeToEmailPeriod(object):
    """
    Attributes:
     - startHourOfDay
     - endHourOfDay
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'startHourOfDay', None, None, ),  # 1
        (2, TType.I32, 'endHourOfDay', None, None, ),  # 2
    )
    def __init__(self, startHourOfDay=None, endHourOfDay=None, ):
        self.startHourOfDay = startHourOfDay
        self.endHourOfDay = endHourOfDay

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.startHourOfDay = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.endHourOfDay = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TimeToEmailPeriod')
        if self.startHourOfDay is not None:
            oprot.writeFieldBegin('startHourOfDay', TType.I32, 1)
            oprot.writeI32(self.startHourOfDay)
            oprot.writeFieldEnd()
        if self.endHourOfDay is not None:
            oprot.writeFieldBegin('endHourOfDay', TType.I32, 2)
            oprot.writeI32(self.endHourOfDay)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        if self.startHourOfDay is None:
            raise TProtocolException(message='Required field startHourOfDay is unset!')
        if self.endHourOfDay is None:
            raise TProtocolException(message='Required field endHourOfDay is unset!')
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TransactionData(object):
    """
    Attributes:
     - id
     - createdAt
     - updatedAt
     - entityName
     - licenseNumber
     - nrdsNumber
     - companyLicenseNumber
     - companyLogoUrl
     - brandLogoUrl
     - avatarUrlSm
     - entityType
     - licenseState
     - roleHints
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.STRING, 'entityName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'licenseNumber', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'nrdsNumber', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'companyLicenseNumber', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'companyLogoUrl', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'brandLogoUrl', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'avatarUrlSm', 'UTF8', None, ),  # 10
        (11, TType.I32, 'entityType', None, None, ),  # 11
        (12, TType.I32, 'licenseState', None, None, ),  # 12
        (13, TType.LIST, 'roleHints', (TType.STRING, 'UTF8', False), None, ),  # 13
    )
    def __init__(self, id=None, createdAt=None, updatedAt=None, entityName=None, licenseNumber=None, nrdsNumber=None, companyLicenseNumber=None, companyLogoUrl=None, brandLogoUrl=None, avatarUrlSm=None, entityType=None, licenseState=None, roleHints=None, ):
        self.id = id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.entityName = entityName
        self.licenseNumber = licenseNumber
        self.nrdsNumber = nrdsNumber
        self.companyLicenseNumber = companyLicenseNumber
        self.companyLogoUrl = companyLogoUrl
        self.brandLogoUrl = brandLogoUrl
        self.avatarUrlSm = avatarUrlSm
        self.entityType = entityType
        self.licenseState = licenseState
        self.roleHints = roleHints

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.entityName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.licenseNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.nrdsNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.companyLicenseNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.companyLogoUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.brandLogoUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.avatarUrlSm = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.entityType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I32:
                    self.licenseState = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.roleHints = []
                    (_etype243, _size246) = iprot.readListBegin()
                    for _i244 in range(_size246):
                        _elem245 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.roleHints.append(_elem245)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TransactionData')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.entityName is not None:
            oprot.writeFieldBegin('entityName', TType.STRING, 4)
            oprot.writeString(self.entityName.encode('utf-8') if sys.version_info[0] == 2 else self.entityName)
            oprot.writeFieldEnd()
        if self.licenseNumber is not None:
            oprot.writeFieldBegin('licenseNumber', TType.STRING, 5)
            oprot.writeString(self.licenseNumber.encode('utf-8') if sys.version_info[0] == 2 else self.licenseNumber)
            oprot.writeFieldEnd()
        if self.nrdsNumber is not None:
            oprot.writeFieldBegin('nrdsNumber', TType.STRING, 6)
            oprot.writeString(self.nrdsNumber.encode('utf-8') if sys.version_info[0] == 2 else self.nrdsNumber)
            oprot.writeFieldEnd()
        if self.companyLicenseNumber is not None:
            oprot.writeFieldBegin('companyLicenseNumber', TType.STRING, 7)
            oprot.writeString(self.companyLicenseNumber.encode('utf-8') if sys.version_info[0] == 2 else self.companyLicenseNumber)
            oprot.writeFieldEnd()
        if self.companyLogoUrl is not None:
            oprot.writeFieldBegin('companyLogoUrl', TType.STRING, 8)
            oprot.writeString(self.companyLogoUrl.encode('utf-8') if sys.version_info[0] == 2 else self.companyLogoUrl)
            oprot.writeFieldEnd()
        if self.brandLogoUrl is not None:
            oprot.writeFieldBegin('brandLogoUrl', TType.STRING, 9)
            oprot.writeString(self.brandLogoUrl.encode('utf-8') if sys.version_info[0] == 2 else self.brandLogoUrl)
            oprot.writeFieldEnd()
        if self.avatarUrlSm is not None:
            oprot.writeFieldBegin('avatarUrlSm', TType.STRING, 10)
            oprot.writeString(self.avatarUrlSm.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrlSm)
            oprot.writeFieldEnd()
        if self.entityType is not None:
            oprot.writeFieldBegin('entityType', TType.I32, 11)
            oprot.writeI32(self.entityType)
            oprot.writeFieldEnd()
        if self.licenseState is not None:
            oprot.writeFieldBegin('licenseState', TType.I32, 12)
            oprot.writeI32(self.licenseState)
            oprot.writeFieldEnd()
        if self.roleHints is not None:
            oprot.writeFieldBegin('roleHints', TType.LIST, 13)
            oprot.writeListBegin(TType.STRING, len(self.roleHints))
            for _iter247 in self.roleHints:
                oprot.writeString(_iter247.encode('utf-8') if sys.version_info[0] == 2 else _iter247)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Contact(object):
    """
    Attributes:
     - id
     - person
     - createdAt
     - updatedAt
     - archivedAt
     - firstName
     - lastName
     - company
     - location
     - title
     - avatarUrl
     - tags
     - assignedToId
     - addresses
     - emailAddresses
     - socialMediaProfiles
     - websites
     - phoneNumbers
     - customFields
     - recurringEvents
     - lastContacted
     - groups
     - associatedTags
     - lastActive
     - manuallyUpdatedAt
     - geography
     - source
     - sourceDetail
     - invitedBy
     - linkedContacts
     - contactType
     - sellerScore
     - sellerScoreDate
     - sellerScoreAddress
     - bestTimesToEmail
     - inviteSentAt
     - relationshipTypes
     - audiences
     - tasks
     - outboundInteractionCount
     - inboundInteractionCount
     - totalInteractionCount
     - qualifiedLead
     - audienceList
     - removeAudiences
     - replyHistogramHour
     - baselineReplyHistogramHour
     - orgRecommendations
     - teamId
     - daysToFollowup
     - daysOverdue
     - associatedDeals
     - teamLastContacted
     - relationshipShares
     - relationshipShareConnections
     - directConnection
     - externalToTeam
     - manuallyUpdatedById
     - mobileIdentifiers
     - householdId
     - preferredContactMethod
     - linkedContactLabels
     - nextOutReach
     - transactionData
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRUCT, 'person', (gen.urbancompass.people.api.person.ttypes.Person, gen.urbancompass.people.api.person.ttypes.Person.thrift_spec), None, ),  # 2
        (3, TType.I64, 'createdAt', None, None, ),  # 3
        (4, TType.I64, 'updatedAt', None, None, ),  # 4
        (5, TType.STRING, 'firstName', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'lastName', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'company', 'UTF8', None, ),  # 7
        (8, TType.STRING, 'location', 'UTF8', None, ),  # 8
        (9, TType.STRING, 'title', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'avatarUrl', 'UTF8', None, ),  # 10
        (11, TType.LIST, 'tags', (TType.STRING, 'UTF8', False), None, ),  # 11
        (12, TType.STRING, 'assignedToId', 'UTF8', None, ),  # 12
        (13, TType.LIST, 'addresses', (TType.STRUCT, (ContactAddress, ContactAddress.thrift_spec), False), None, ),  # 13
        (14, TType.LIST, 'emailAddresses', (TType.STRUCT, (gen.urbancompass.contacts.api.shallow_contact.ttypes.ContactEmailAddress, gen.urbancompass.contacts.api.shallow_contact.ttypes.ContactEmailAddress.thrift_spec), False), None, ),  # 14
        (15, TType.LIST, 'socialMediaProfiles', (TType.STRUCT, (ContactSocialMediaProfile, ContactSocialMediaProfile.thrift_spec), False), None, ),  # 15
        (16, TType.LIST, 'websites', (TType.STRUCT, (ContactWebsite, ContactWebsite.thrift_spec), False), None, ),  # 16
        (17, TType.LIST, 'phoneNumbers', (TType.STRUCT, (ContactPhoneNumber, ContactPhoneNumber.thrift_spec), False), None, ),  # 17
        (18, TType.LIST, 'customFields', (TType.STRUCT, (gen.urbancompass.contacts.api.custom_field.ttypes.CustomFieldValue, gen.urbancompass.contacts.api.custom_field.ttypes.CustomFieldValue.thrift_spec), False), None, ),  # 18
        (19, TType.I64, 'lastContacted', None, None, ),  # 19
        (20, TType.LIST, 'groups', (TType.STRUCT, (gen.urbancompass.contacts.api.group.ttypes.Group, gen.urbancompass.contacts.api.group.ttypes.Group.thrift_spec), False), None, ),  # 20
        (21, TType.LIST, 'associatedTags', (TType.STRUCT, (AssociatedItem, AssociatedItem.thrift_spec), False), None, ),  # 21
        (22, TType.I64, 'lastActive', None, None, ),  # 22
        (23, TType.I64, 'archivedAt', None, None, ),  # 23
        (24, TType.LIST, 'recurringEvents', (TType.STRUCT, (RecurringEvent, RecurringEvent.thrift_spec), False), None, ),  # 24
        (25, TType.I64, 'manuallyUpdatedAt', None, None, ),  # 25
        (26, TType.STRING, 'geography', 'UTF8', None, ),  # 26
        (27, TType.I32, 'source', None, None, ),  # 27
        (28, TType.STRING, 'invitedBy', 'UTF8', None, ),  # 28
        (29, TType.LIST, 'linkedContacts', (TType.STRUCT, (LinkedContact, LinkedContact.thrift_spec), False), None, ),  # 29
        (30, TType.I32, 'contactType', None, None, ),  # 30
        (31, TType.STRING, 'sourceDetail', 'UTF8', None, ),  # 31
        (32, TType.DOUBLE, 'sellerScore', None, None, ),  # 32
        (33, TType.I64, 'sellerScoreDate', None, None, ),  # 33
        (34, TType.STRUCT, 'sellerScoreAddress', (ContactAddress, ContactAddress.thrift_spec), None, ),  # 34
        (35, TType.LIST, 'bestTimesToEmail', (TType.STRUCT, (TimeToEmailPeriod, TimeToEmailPeriod.thrift_spec), False), None, ),  # 35
        (36, TType.I64, 'inviteSentAt', None, None, ),  # 36
        (37, TType.LIST, 'relationshipTypes', (TType.I32, None, False), None, ),  # 37
        (38, TType.LIST, 'audiences', (TType.STRUCT, (gen.urbancompass.contacts.api.audience.ttypes.Audience, gen.urbancompass.contacts.api.audience.ttypes.Audience.thrift_spec), False), None, ),  # 38
        (39, TType.LIST, 'tasks', (TType.STRUCT, (gen.urbancompass.tasks.tasks.api.ttypes.Task, gen.urbancompass.tasks.tasks.api.ttypes.Task.thrift_spec), False), None, ),  # 39
        (40, TType.I32, 'outboundInteractionCount', None, None, ),  # 40
        (41, TType.I32, 'inboundInteractionCount', None, None, ),  # 41
        (42, TType.I32, 'totalInteractionCount', None, None, ),  # 42
        (43, TType.STRUCT, 'qualifiedLead', (gen.urbancompass.qualified_leads.qualified_leads_api.ttypes.QualifiedLead, gen.urbancompass.qualified_leads.qualified_leads_api.ttypes.QualifiedLead.thrift_spec), None, ),  # 43
        (44, TType.LIST, 'audienceList', (TType.STRING, 'UTF8', False), None, ),  # 44
        (45, TType.BOOL, 'removeAudiences', None, None, ),  # 45
        (46, TType.LIST, 'replyHistogramHour', (TType.I32, None, False), None, ),  # 46
        (47, TType.LIST, 'baselineReplyHistogramHour', (TType.I32, None, False), None, ),  # 47
        (48, TType.LIST, 'orgRecommendations', (TType.I32, None, False), None, ),  # 48
        (49, TType.STRING, 'teamId', 'UTF8', None, ),  # 49
        (50, TType.I32, 'daysToFollowup', None, None, ),  # 50
        (51, TType.I32, 'daysOverdue', None, None, ),  # 51
        (52, TType.LIST, 'associatedDeals', (TType.STRUCT, (gen.urbancompass.contacts.api.deal.ttypes.MinimalDeal, gen.urbancompass.contacts.api.deal.ttypes.MinimalDeal.thrift_spec), False), None, ),  # 52
        (53, TType.I64, 'teamLastContacted', None, None, ),  # 53
        (54, TType.LIST, 'relationshipShares', (TType.STRING, 'UTF8', False), None, ),  # 54
        (55, TType.LIST, 'relationshipShareConnections', (TType.STRUCT, (RelationshipShare, RelationshipShare.thrift_spec), False), None, ),  # 55
        (56, TType.BOOL, 'directConnection', None, None, ),  # 56
        (57, TType.BOOL, 'externalToTeam', None, None, ),  # 57
        (58, TType.STRING, 'manuallyUpdatedById', 'UTF8', None, ),  # 58
        (59, TType.LIST, 'mobileIdentifiers', (TType.STRUCT, (gen.urbancompass.contacts.api.shallow_contact.ttypes.ContactMobileIdentifier, gen.urbancompass.contacts.api.shallow_contact.ttypes.ContactMobileIdentifier.thrift_spec), False), None, ),  # 59
        (60, TType.STRING, 'householdId', 'UTF8', None, ),  # 60
        (61, TType.I32, 'preferredContactMethod', None, None, ),  # 61
        (62, TType.MAP, 'linkedContactLabels', (TType.STRING, 'UTF8', TType.I32, None, False), None, ),  # 62
        (63, TType.I64, 'nextOutReach', None, None, ),  # 63
        (64, TType.STRUCT, 'transactionData', (TransactionData, TransactionData.thrift_spec), None, ),  # 64
    )
    def __init__(self, id=None, person=None, createdAt=None, updatedAt=None, firstName=None, lastName=None, company=None, location=None, title=None, avatarUrl=None, tags=None, assignedToId=None, addresses=None, emailAddresses=None, socialMediaProfiles=None, websites=None, phoneNumbers=None, customFields=None, lastContacted=None, groups=None, associatedTags=None, lastActive=None, archivedAt=None, recurringEvents=None, manuallyUpdatedAt=None, geography=None, source=None, invitedBy=None, linkedContacts=None, contactType=None, sourceDetail=None, sellerScore=None, sellerScoreDate=None, sellerScoreAddress=None, bestTimesToEmail=None, inviteSentAt=None, relationshipTypes=None, audiences=None, tasks=None, outboundInteractionCount=None, inboundInteractionCount=None, totalInteractionCount=None, qualifiedLead=None, audienceList=None, removeAudiences=None, replyHistogramHour=None, baselineReplyHistogramHour=None, orgRecommendations=None, teamId=None, daysToFollowup=None, daysOverdue=None, associatedDeals=None, teamLastContacted=None, relationshipShares=None, relationshipShareConnections=None, directConnection=None, externalToTeam=None, manuallyUpdatedById=None, mobileIdentifiers=None, householdId=None, preferredContactMethod=None, linkedContactLabels=None, nextOutReach=None, transactionData=None, ):
        self.id = id
        self.person = person
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.firstName = firstName
        self.lastName = lastName
        self.company = company
        self.location = location
        self.title = title
        self.avatarUrl = avatarUrl
        self.tags = tags
        self.assignedToId = assignedToId
        self.addresses = addresses
        self.emailAddresses = emailAddresses
        self.socialMediaProfiles = socialMediaProfiles
        self.websites = websites
        self.phoneNumbers = phoneNumbers
        self.customFields = customFields
        self.lastContacted = lastContacted
        self.groups = groups
        self.associatedTags = associatedTags
        self.lastActive = lastActive
        self.archivedAt = archivedAt
        self.recurringEvents = recurringEvents
        self.manuallyUpdatedAt = manuallyUpdatedAt
        self.geography = geography
        self.source = source
        self.invitedBy = invitedBy
        self.linkedContacts = linkedContacts
        self.contactType = contactType
        self.sourceDetail = sourceDetail
        self.sellerScore = sellerScore
        self.sellerScoreDate = sellerScoreDate
        self.sellerScoreAddress = sellerScoreAddress
        self.bestTimesToEmail = bestTimesToEmail
        self.inviteSentAt = inviteSentAt
        self.relationshipTypes = relationshipTypes
        self.audiences = audiences
        self.tasks = tasks
        self.outboundInteractionCount = outboundInteractionCount
        self.inboundInteractionCount = inboundInteractionCount
        self.totalInteractionCount = totalInteractionCount
        self.qualifiedLead = qualifiedLead
        self.audienceList = audienceList
        self.removeAudiences = removeAudiences
        self.replyHistogramHour = replyHistogramHour
        self.baselineReplyHistogramHour = baselineReplyHistogramHour
        self.orgRecommendations = orgRecommendations
        self.teamId = teamId
        self.daysToFollowup = daysToFollowup
        self.daysOverdue = daysOverdue
        self.associatedDeals = associatedDeals
        self.teamLastContacted = teamLastContacted
        self.relationshipShares = relationshipShares
        self.relationshipShareConnections = relationshipShareConnections
        self.directConnection = directConnection
        self.externalToTeam = externalToTeam
        self.manuallyUpdatedById = manuallyUpdatedById
        self.mobileIdentifiers = mobileIdentifiers
        self.householdId = householdId
        self.preferredContactMethod = preferredContactMethod
        self.linkedContactLabels = linkedContactLabels
        self.nextOutReach = nextOutReach
        self.transactionData = transactionData

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRUCT:
                    self.person = gen.urbancompass.people.api.person.ttypes.Person()
                    self.person.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.company = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.STRING:
                    self.location = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.title = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.avatarUrl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.LIST:
                    self.tags = []
                    (_etype248, _size251) = iprot.readListBegin()
                    for _i249 in range(_size251):
                        _elem250 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.tags.append(_elem250)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.assignedToId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.LIST:
                    self.addresses = []
                    (_etype252, _size255) = iprot.readListBegin()
                    for _i253 in range(_size255):
                        _elem254 = ContactAddress()
                        _elem254.read(iprot)
                        self.addresses.append(_elem254)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.LIST:
                    self.emailAddresses = []
                    (_etype256, _size259) = iprot.readListBegin()
                    for _i257 in range(_size259):
                        _elem258 = gen.urbancompass.contacts.api.shallow_contact.ttypes.ContactEmailAddress()
                        _elem258.read(iprot)
                        self.emailAddresses.append(_elem258)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.LIST:
                    self.socialMediaProfiles = []
                    (_etype260, _size263) = iprot.readListBegin()
                    for _i261 in range(_size263):
                        _elem262 = ContactSocialMediaProfile()
                        _elem262.read(iprot)
                        self.socialMediaProfiles.append(_elem262)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.LIST:
                    self.websites = []
                    (_etype264, _size267) = iprot.readListBegin()
                    for _i265 in range(_size267):
                        _elem266 = ContactWebsite()
                        _elem266.read(iprot)
                        self.websites.append(_elem266)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.LIST:
                    self.phoneNumbers = []
                    (_etype268, _size271) = iprot.readListBegin()
                    for _i269 in range(_size271):
                        _elem270 = ContactPhoneNumber()
                        _elem270.read(iprot)
                        self.phoneNumbers.append(_elem270)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.LIST:
                    self.customFields = []
                    (_etype272, _size275) = iprot.readListBegin()
                    for _i273 in range(_size275):
                        _elem274 = gen.urbancompass.contacts.api.custom_field.ttypes.CustomFieldValue()
                        _elem274.read(iprot)
                        self.customFields.append(_elem274)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I64:
                    self.lastContacted = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.LIST:
                    self.groups = []
                    (_etype276, _size279) = iprot.readListBegin()
                    for _i277 in range(_size279):
                        _elem278 = gen.urbancompass.contacts.api.group.ttypes.Group()
                        _elem278.read(iprot)
                        self.groups.append(_elem278)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.LIST:
                    self.associatedTags = []
                    (_etype280, _size283) = iprot.readListBegin()
                    for _i281 in range(_size283):
                        _elem282 = AssociatedItem()
                        _elem282.read(iprot)
                        self.associatedTags.append(_elem282)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.I64:
                    self.lastActive = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.I64:
                    self.archivedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.LIST:
                    self.recurringEvents = []
                    (_etype284, _size287) = iprot.readListBegin()
                    for _i285 in range(_size287):
                        _elem286 = RecurringEvent()
                        _elem286.read(iprot)
                        self.recurringEvents.append(_elem286)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I64:
                    self.manuallyUpdatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRING:
                    self.geography = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.I32:
                    self.source = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.invitedBy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.LIST:
                    self.linkedContacts = []
                    (_etype288, _size291) = iprot.readListBegin()
                    for _i289 in range(_size291):
                        _elem290 = LinkedContact()
                        _elem290.read(iprot)
                        self.linkedContacts.append(_elem290)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.I32:
                    self.contactType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.sourceDetail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.DOUBLE:
                    self.sellerScore = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I64:
                    self.sellerScoreDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.STRUCT:
                    self.sellerScoreAddress = ContactAddress()
                    self.sellerScoreAddress.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.LIST:
                    self.bestTimesToEmail = []
                    (_etype292, _size295) = iprot.readListBegin()
                    for _i293 in range(_size295):
                        _elem294 = TimeToEmailPeriod()
                        _elem294.read(iprot)
                        self.bestTimesToEmail.append(_elem294)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.I64:
                    self.inviteSentAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.LIST:
                    self.relationshipTypes = []
                    (_etype296, _size299) = iprot.readListBegin()
                    for _i297 in range(_size299):
                        _elem298 = iprot.readI32()
                        self.relationshipTypes.append(_elem298)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.LIST:
                    self.audiences = []
                    (_etype300, _size303) = iprot.readListBegin()
                    for _i301 in range(_size303):
                        _elem302 = gen.urbancompass.contacts.api.audience.ttypes.Audience()
                        _elem302.read(iprot)
                        self.audiences.append(_elem302)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.LIST:
                    self.tasks = []
                    (_etype304, _size307) = iprot.readListBegin()
                    for _i305 in range(_size307):
                        _elem306 = gen.urbancompass.tasks.tasks.api.ttypes.Task()
                        _elem306.read(iprot)
                        self.tasks.append(_elem306)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.I32:
                    self.outboundInteractionCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.I32:
                    self.inboundInteractionCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.I32:
                    self.totalInteractionCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRUCT:
                    self.qualifiedLead = gen.urbancompass.qualified_leads.qualified_leads_api.ttypes.QualifiedLead()
                    self.qualifiedLead.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.LIST:
                    self.audienceList = []
                    (_etype308, _size311) = iprot.readListBegin()
                    for _i309 in range(_size311):
                        _elem310 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.audienceList.append(_elem310)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.BOOL:
                    self.removeAudiences = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.LIST:
                    self.replyHistogramHour = []
                    (_etype312, _size315) = iprot.readListBegin()
                    for _i313 in range(_size315):
                        _elem314 = iprot.readI32()
                        self.replyHistogramHour.append(_elem314)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.LIST:
                    self.baselineReplyHistogramHour = []
                    (_etype316, _size319) = iprot.readListBegin()
                    for _i317 in range(_size319):
                        _elem318 = iprot.readI32()
                        self.baselineReplyHistogramHour.append(_elem318)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.LIST:
                    self.orgRecommendations = []
                    (_etype320, _size323) = iprot.readListBegin()
                    for _i321 in range(_size323):
                        _elem322 = iprot.readI32()
                        self.orgRecommendations.append(_elem322)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.STRING:
                    self.teamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.I32:
                    self.daysToFollowup = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.I32:
                    self.daysOverdue = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.LIST:
                    self.associatedDeals = []
                    (_etype324, _size327) = iprot.readListBegin()
                    for _i325 in range(_size327):
                        _elem326 = gen.urbancompass.contacts.api.deal.ttypes.MinimalDeal()
                        _elem326.read(iprot)
                        self.associatedDeals.append(_elem326)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.I64:
                    self.teamLastContacted = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.LIST:
                    self.relationshipShares = []
                    (_etype328, _size331) = iprot.readListBegin()
                    for _i329 in range(_size331):
                        _elem330 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.relationshipShares.append(_elem330)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.LIST:
                    self.relationshipShareConnections = []
                    (_etype332, _size335) = iprot.readListBegin()
                    for _i333 in range(_size335):
                        _elem334 = RelationshipShare()
                        _elem334.read(iprot)
                        self.relationshipShareConnections.append(_elem334)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.BOOL:
                    self.directConnection = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.BOOL:
                    self.externalToTeam = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.STRING:
                    self.manuallyUpdatedById = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.LIST:
                    self.mobileIdentifiers = []
                    (_etype336, _size339) = iprot.readListBegin()
                    for _i337 in range(_size339):
                        _elem338 = gen.urbancompass.contacts.api.shallow_contact.ttypes.ContactMobileIdentifier()
                        _elem338.read(iprot)
                        self.mobileIdentifiers.append(_elem338)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.STRING:
                    self.householdId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.I32:
                    self.preferredContactMethod = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 62:
                if ftype == TType.MAP:
                    self.linkedContactLabels = {}
                    (_ktype341, _vtype342, _size345) = iprot.readMapBegin()
                    for _i340 in range(_size345):
                        _key343 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val344 = iprot.readI32()
                        self.linkedContactLabels[_key343] = _val344
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 63:
                if ftype == TType.I64:
                    self.nextOutReach = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 64:
                if ftype == TType.STRUCT:
                    self.transactionData = TransactionData()
                    self.transactionData.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Contact')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.person is not None:
            oprot.writeFieldBegin('person', TType.STRUCT, 2)
            self.person.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 3)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 4)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 5)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 6)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.company is not None:
            oprot.writeFieldBegin('company', TType.STRING, 7)
            oprot.writeString(self.company.encode('utf-8') if sys.version_info[0] == 2 else self.company)
            oprot.writeFieldEnd()
        if self.location is not None:
            oprot.writeFieldBegin('location', TType.STRING, 8)
            oprot.writeString(self.location.encode('utf-8') if sys.version_info[0] == 2 else self.location)
            oprot.writeFieldEnd()
        if self.title is not None:
            oprot.writeFieldBegin('title', TType.STRING, 9)
            oprot.writeString(self.title.encode('utf-8') if sys.version_info[0] == 2 else self.title)
            oprot.writeFieldEnd()
        if self.avatarUrl is not None:
            oprot.writeFieldBegin('avatarUrl', TType.STRING, 10)
            oprot.writeString(self.avatarUrl.encode('utf-8') if sys.version_info[0] == 2 else self.avatarUrl)
            oprot.writeFieldEnd()
        if self.tags is not None:
            oprot.writeFieldBegin('tags', TType.LIST, 11)
            oprot.writeListBegin(TType.STRING, len(self.tags))
            for _iter346 in self.tags:
                oprot.writeString(_iter346.encode('utf-8') if sys.version_info[0] == 2 else _iter346)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.assignedToId is not None:
            oprot.writeFieldBegin('assignedToId', TType.STRING, 12)
            oprot.writeString(self.assignedToId.encode('utf-8') if sys.version_info[0] == 2 else self.assignedToId)
            oprot.writeFieldEnd()
        if self.addresses is not None:
            oprot.writeFieldBegin('addresses', TType.LIST, 13)
            oprot.writeListBegin(TType.STRUCT, len(self.addresses))
            for _iter347 in self.addresses:
                _iter347.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.emailAddresses is not None:
            oprot.writeFieldBegin('emailAddresses', TType.LIST, 14)
            oprot.writeListBegin(TType.STRUCT, len(self.emailAddresses))
            for _iter348 in self.emailAddresses:
                _iter348.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.socialMediaProfiles is not None:
            oprot.writeFieldBegin('socialMediaProfiles', TType.LIST, 15)
            oprot.writeListBegin(TType.STRUCT, len(self.socialMediaProfiles))
            for _iter349 in self.socialMediaProfiles:
                _iter349.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.websites is not None:
            oprot.writeFieldBegin('websites', TType.LIST, 16)
            oprot.writeListBegin(TType.STRUCT, len(self.websites))
            for _iter350 in self.websites:
                _iter350.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.phoneNumbers is not None:
            oprot.writeFieldBegin('phoneNumbers', TType.LIST, 17)
            oprot.writeListBegin(TType.STRUCT, len(self.phoneNumbers))
            for _iter351 in self.phoneNumbers:
                _iter351.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.customFields is not None:
            oprot.writeFieldBegin('customFields', TType.LIST, 18)
            oprot.writeListBegin(TType.STRUCT, len(self.customFields))
            for _iter352 in self.customFields:
                _iter352.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastContacted is not None:
            oprot.writeFieldBegin('lastContacted', TType.I64, 19)
            oprot.writeI64(self.lastContacted)
            oprot.writeFieldEnd()
        if self.groups is not None:
            oprot.writeFieldBegin('groups', TType.LIST, 20)
            oprot.writeListBegin(TType.STRUCT, len(self.groups))
            for _iter353 in self.groups:
                _iter353.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.associatedTags is not None:
            oprot.writeFieldBegin('associatedTags', TType.LIST, 21)
            oprot.writeListBegin(TType.STRUCT, len(self.associatedTags))
            for _iter354 in self.associatedTags:
                _iter354.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastActive is not None:
            oprot.writeFieldBegin('lastActive', TType.I64, 22)
            oprot.writeI64(self.lastActive)
            oprot.writeFieldEnd()
        if self.archivedAt is not None:
            oprot.writeFieldBegin('archivedAt', TType.I64, 23)
            oprot.writeI64(self.archivedAt)
            oprot.writeFieldEnd()
        if self.recurringEvents is not None:
            oprot.writeFieldBegin('recurringEvents', TType.LIST, 24)
            oprot.writeListBegin(TType.STRUCT, len(self.recurringEvents))
            for _iter355 in self.recurringEvents:
                _iter355.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.manuallyUpdatedAt is not None:
            oprot.writeFieldBegin('manuallyUpdatedAt', TType.I64, 25)
            oprot.writeI64(self.manuallyUpdatedAt)
            oprot.writeFieldEnd()
        if self.geography is not None:
            oprot.writeFieldBegin('geography', TType.STRING, 26)
            oprot.writeString(self.geography.encode('utf-8') if sys.version_info[0] == 2 else self.geography)
            oprot.writeFieldEnd()
        if self.source is not None:
            oprot.writeFieldBegin('source', TType.I32, 27)
            oprot.writeI32(self.source)
            oprot.writeFieldEnd()
        if self.invitedBy is not None:
            oprot.writeFieldBegin('invitedBy', TType.STRING, 28)
            oprot.writeString(self.invitedBy.encode('utf-8') if sys.version_info[0] == 2 else self.invitedBy)
            oprot.writeFieldEnd()
        if self.linkedContacts is not None:
            oprot.writeFieldBegin('linkedContacts', TType.LIST, 29)
            oprot.writeListBegin(TType.STRUCT, len(self.linkedContacts))
            for _iter356 in self.linkedContacts:
                _iter356.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.contactType is not None:
            oprot.writeFieldBegin('contactType', TType.I32, 30)
            oprot.writeI32(self.contactType)
            oprot.writeFieldEnd()
        if self.sourceDetail is not None:
            oprot.writeFieldBegin('sourceDetail', TType.STRING, 31)
            oprot.writeString(self.sourceDetail.encode('utf-8') if sys.version_info[0] == 2 else self.sourceDetail)
            oprot.writeFieldEnd()
        if self.sellerScore is not None:
            oprot.writeFieldBegin('sellerScore', TType.DOUBLE, 32)
            oprot.writeDouble(self.sellerScore)
            oprot.writeFieldEnd()
        if self.sellerScoreDate is not None:
            oprot.writeFieldBegin('sellerScoreDate', TType.I64, 33)
            oprot.writeI64(self.sellerScoreDate)
            oprot.writeFieldEnd()
        if self.sellerScoreAddress is not None:
            oprot.writeFieldBegin('sellerScoreAddress', TType.STRUCT, 34)
            self.sellerScoreAddress.write(oprot)
            oprot.writeFieldEnd()
        if self.bestTimesToEmail is not None:
            oprot.writeFieldBegin('bestTimesToEmail', TType.LIST, 35)
            oprot.writeListBegin(TType.STRUCT, len(self.bestTimesToEmail))
            for _iter357 in self.bestTimesToEmail:
                _iter357.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.inviteSentAt is not None:
            oprot.writeFieldBegin('inviteSentAt', TType.I64, 36)
            oprot.writeI64(self.inviteSentAt)
            oprot.writeFieldEnd()
        if self.relationshipTypes is not None:
            oprot.writeFieldBegin('relationshipTypes', TType.LIST, 37)
            oprot.writeListBegin(TType.I32, len(self.relationshipTypes))
            for _iter358 in self.relationshipTypes:
                oprot.writeI32(_iter358)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.audiences is not None:
            oprot.writeFieldBegin('audiences', TType.LIST, 38)
            oprot.writeListBegin(TType.STRUCT, len(self.audiences))
            for _iter359 in self.audiences:
                _iter359.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.tasks is not None:
            oprot.writeFieldBegin('tasks', TType.LIST, 39)
            oprot.writeListBegin(TType.STRUCT, len(self.tasks))
            for _iter360 in self.tasks:
                _iter360.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.outboundInteractionCount is not None:
            oprot.writeFieldBegin('outboundInteractionCount', TType.I32, 40)
            oprot.writeI32(self.outboundInteractionCount)
            oprot.writeFieldEnd()
        if self.inboundInteractionCount is not None:
            oprot.writeFieldBegin('inboundInteractionCount', TType.I32, 41)
            oprot.writeI32(self.inboundInteractionCount)
            oprot.writeFieldEnd()
        if self.totalInteractionCount is not None:
            oprot.writeFieldBegin('totalInteractionCount', TType.I32, 42)
            oprot.writeI32(self.totalInteractionCount)
            oprot.writeFieldEnd()
        if self.qualifiedLead is not None:
            oprot.writeFieldBegin('qualifiedLead', TType.STRUCT, 43)
            self.qualifiedLead.write(oprot)
            oprot.writeFieldEnd()
        if self.audienceList is not None:
            oprot.writeFieldBegin('audienceList', TType.LIST, 44)
            oprot.writeListBegin(TType.STRING, len(self.audienceList))
            for _iter361 in self.audienceList:
                oprot.writeString(_iter361.encode('utf-8') if sys.version_info[0] == 2 else _iter361)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.removeAudiences is not None:
            oprot.writeFieldBegin('removeAudiences', TType.BOOL, 45)
            oprot.writeBool(self.removeAudiences)
            oprot.writeFieldEnd()
        if self.replyHistogramHour is not None:
            oprot.writeFieldBegin('replyHistogramHour', TType.LIST, 46)
            oprot.writeListBegin(TType.I32, len(self.replyHistogramHour))
            for _iter362 in self.replyHistogramHour:
                oprot.writeI32(_iter362)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.baselineReplyHistogramHour is not None:
            oprot.writeFieldBegin('baselineReplyHistogramHour', TType.LIST, 47)
            oprot.writeListBegin(TType.I32, len(self.baselineReplyHistogramHour))
            for _iter363 in self.baselineReplyHistogramHour:
                oprot.writeI32(_iter363)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.orgRecommendations is not None:
            oprot.writeFieldBegin('orgRecommendations', TType.LIST, 48)
            oprot.writeListBegin(TType.I32, len(self.orgRecommendations))
            for _iter364 in self.orgRecommendations:
                oprot.writeI32(_iter364)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.teamId is not None:
            oprot.writeFieldBegin('teamId', TType.STRING, 49)
            oprot.writeString(self.teamId.encode('utf-8') if sys.version_info[0] == 2 else self.teamId)
            oprot.writeFieldEnd()
        if self.daysToFollowup is not None:
            oprot.writeFieldBegin('daysToFollowup', TType.I32, 50)
            oprot.writeI32(self.daysToFollowup)
            oprot.writeFieldEnd()
        if self.daysOverdue is not None:
            oprot.writeFieldBegin('daysOverdue', TType.I32, 51)
            oprot.writeI32(self.daysOverdue)
            oprot.writeFieldEnd()
        if self.associatedDeals is not None:
            oprot.writeFieldBegin('associatedDeals', TType.LIST, 52)
            oprot.writeListBegin(TType.STRUCT, len(self.associatedDeals))
            for _iter365 in self.associatedDeals:
                _iter365.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.teamLastContacted is not None:
            oprot.writeFieldBegin('teamLastContacted', TType.I64, 53)
            oprot.writeI64(self.teamLastContacted)
            oprot.writeFieldEnd()
        if self.relationshipShares is not None:
            oprot.writeFieldBegin('relationshipShares', TType.LIST, 54)
            oprot.writeListBegin(TType.STRING, len(self.relationshipShares))
            for _iter366 in self.relationshipShares:
                oprot.writeString(_iter366.encode('utf-8') if sys.version_info[0] == 2 else _iter366)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.relationshipShareConnections is not None:
            oprot.writeFieldBegin('relationshipShareConnections', TType.LIST, 55)
            oprot.writeListBegin(TType.STRUCT, len(self.relationshipShareConnections))
            for _iter367 in self.relationshipShareConnections:
                _iter367.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.directConnection is not None:
            oprot.writeFieldBegin('directConnection', TType.BOOL, 56)
            oprot.writeBool(self.directConnection)
            oprot.writeFieldEnd()
        if self.externalToTeam is not None:
            oprot.writeFieldBegin('externalToTeam', TType.BOOL, 57)
            oprot.writeBool(self.externalToTeam)
            oprot.writeFieldEnd()
        if self.manuallyUpdatedById is not None:
            oprot.writeFieldBegin('manuallyUpdatedById', TType.STRING, 58)
            oprot.writeString(self.manuallyUpdatedById.encode('utf-8') if sys.version_info[0] == 2 else self.manuallyUpdatedById)
            oprot.writeFieldEnd()
        if self.mobileIdentifiers is not None:
            oprot.writeFieldBegin('mobileIdentifiers', TType.LIST, 59)
            oprot.writeListBegin(TType.STRUCT, len(self.mobileIdentifiers))
            for _iter368 in self.mobileIdentifiers:
                _iter368.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.householdId is not None:
            oprot.writeFieldBegin('householdId', TType.STRING, 60)
            oprot.writeString(self.householdId.encode('utf-8') if sys.version_info[0] == 2 else self.householdId)
            oprot.writeFieldEnd()
        if self.preferredContactMethod is not None:
            oprot.writeFieldBegin('preferredContactMethod', TType.I32, 61)
            oprot.writeI32(self.preferredContactMethod)
            oprot.writeFieldEnd()
        if self.linkedContactLabels is not None:
            oprot.writeFieldBegin('linkedContactLabels', TType.MAP, 62)
            oprot.writeMapBegin(TType.STRING, TType.I32, len(self.linkedContactLabels))
            for _kiter369, _viter370 in self.linkedContactLabels.items():
                oprot.writeString(_kiter369.encode('utf-8') if sys.version_info[0] == 2 else _kiter369)
                oprot.writeI32(_viter370)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.nextOutReach is not None:
            oprot.writeFieldBegin('nextOutReach', TType.I64, 63)
            oprot.writeI64(self.nextOutReach)
            oprot.writeFieldEnd()
        if self.transactionData is not None:
            oprot.writeFieldBegin('transactionData', TType.STRUCT, 64)
            self.transactionData.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Household(object):
    """
    Attributes:
     - id
     - createdAt
     - updatedAt
     - name
     - address
     - contacts
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I64, 'createdAt', None, None, ),  # 2
        (3, TType.I64, 'updatedAt', None, None, ),  # 3
        (4, TType.STRING, 'name', 'UTF8', None, ),  # 4
        (5, TType.STRUCT, 'address', (ContactAddress, ContactAddress.thrift_spec), None, ),  # 5
        (6, TType.LIST, 'contacts', (TType.STRUCT, (LinkedContact, LinkedContact.thrift_spec), False), None, ),  # 6
    )
    def __init__(self, id=None, createdAt=None, updatedAt=None, name=None, address=None, contacts=None, ):
        self.id = id
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.name = name
        self.address = address
        self.contacts = contacts

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRUCT:
                    self.address = ContactAddress()
                    self.address.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.contacts = []
                    (_etype371, _size374) = iprot.readListBegin()
                    for _i372 in range(_size374):
                        _elem373 = LinkedContact()
                        _elem373.read(iprot)
                        self.contacts.append(_elem373)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Household')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 2)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 3)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 4)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRUCT, 5)
            self.address.write(oprot)
            oprot.writeFieldEnd()
        if self.contacts is not None:
            oprot.writeFieldBegin('contacts', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.contacts))
            for _iter375 in self.contacts:
                _iter375.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class InteractionParticipant(object):
    """
    Attributes:
     - contactId
     - handle
     - firstName
     - lastName
     - displayName
     - contact
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'contactId', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'handle', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'firstName', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'lastName', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'displayName', 'UTF8', None, ),  # 5
        (6, TType.STRUCT, 'contact', (Contact, Contact.thrift_spec), None, ),  # 6
    )
    def __init__(self, contactId=None, handle=None, firstName=None, lastName=None, displayName=None, contact=None, ):
        self.contactId = contactId
        self.handle = handle
        self.firstName = firstName
        self.lastName = lastName
        self.displayName = displayName
        self.contact = contact

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.contactId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.handle = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.firstName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.lastName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.displayName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRUCT:
                    self.contact = Contact()
                    self.contact.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('InteractionParticipant')
        if self.contactId is not None:
            oprot.writeFieldBegin('contactId', TType.STRING, 1)
            oprot.writeString(self.contactId.encode('utf-8') if sys.version_info[0] == 2 else self.contactId)
            oprot.writeFieldEnd()
        if self.handle is not None:
            oprot.writeFieldBegin('handle', TType.STRING, 2)
            oprot.writeString(self.handle.encode('utf-8') if sys.version_info[0] == 2 else self.handle)
            oprot.writeFieldEnd()
        if self.firstName is not None:
            oprot.writeFieldBegin('firstName', TType.STRING, 3)
            oprot.writeString(self.firstName.encode('utf-8') if sys.version_info[0] == 2 else self.firstName)
            oprot.writeFieldEnd()
        if self.lastName is not None:
            oprot.writeFieldBegin('lastName', TType.STRING, 4)
            oprot.writeString(self.lastName.encode('utf-8') if sys.version_info[0] == 2 else self.lastName)
            oprot.writeFieldEnd()
        if self.displayName is not None:
            oprot.writeFieldBegin('displayName', TType.STRING, 5)
            oprot.writeString(self.displayName.encode('utf-8') if sys.version_info[0] == 2 else self.displayName)
            oprot.writeFieldEnd()
        if self.contact is not None:
            oprot.writeFieldBegin('contact', TType.STRUCT, 6)
            self.contact.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class MergeSuggestion(object):
    """
    Attributes:
     - id
     - crmAgentId
     - duplicateContacts
     - primaryContact
     - matchedData
     - crmTeamId
     - createdAt
     - updatedAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'crmAgentId', 'UTF8', None, ),  # 2
        (3, TType.LIST, 'duplicateContacts', (TType.STRUCT, (Contact, Contact.thrift_spec), False), None, ),  # 3
        (4, TType.STRUCT, 'primaryContact', (Contact, Contact.thrift_spec), None, ),  # 4
        (5, TType.LIST, 'matchedData', (TType.STRING, 'UTF8', False), None, ),  # 5
        (6, TType.STRING, 'crmTeamId', 'UTF8', None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'updatedAt', None, None, ),  # 8
    )
    def __init__(self, id=None, crmAgentId=None, duplicateContacts=None, primaryContact=None, matchedData=None, crmTeamId=None, createdAt=None, updatedAt=None, ):
        self.id = id
        self.crmAgentId = crmAgentId
        self.duplicateContacts = duplicateContacts
        self.primaryContact = primaryContact
        self.matchedData = matchedData
        self.crmTeamId = crmTeamId
        self.createdAt = createdAt
        self.updatedAt = updatedAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.crmAgentId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.LIST:
                    self.duplicateContacts = []
                    (_etype376, _size379) = iprot.readListBegin()
                    for _i377 in range(_size379):
                        _elem378 = Contact()
                        _elem378.read(iprot)
                        self.duplicateContacts.append(_elem378)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRUCT:
                    self.primaryContact = Contact()
                    self.primaryContact.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.matchedData = []
                    (_etype380, _size383) = iprot.readListBegin()
                    for _i381 in range(_size383):
                        _elem382 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.matchedData.append(_elem382)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.crmTeamId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('MergeSuggestion')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.crmAgentId is not None:
            oprot.writeFieldBegin('crmAgentId', TType.STRING, 2)
            oprot.writeString(self.crmAgentId.encode('utf-8') if sys.version_info[0] == 2 else self.crmAgentId)
            oprot.writeFieldEnd()
        if self.duplicateContacts is not None:
            oprot.writeFieldBegin('duplicateContacts', TType.LIST, 3)
            oprot.writeListBegin(TType.STRUCT, len(self.duplicateContacts))
            for _iter384 in self.duplicateContacts:
                _iter384.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.primaryContact is not None:
            oprot.writeFieldBegin('primaryContact', TType.STRUCT, 4)
            self.primaryContact.write(oprot)
            oprot.writeFieldEnd()
        if self.matchedData is not None:
            oprot.writeFieldBegin('matchedData', TType.LIST, 5)
            oprot.writeListBegin(TType.STRING, len(self.matchedData))
            for _iter385 in self.matchedData:
                oprot.writeString(_iter385.encode('utf-8') if sys.version_info[0] == 2 else _iter385)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.crmTeamId is not None:
            oprot.writeFieldBegin('crmTeamId', TType.STRING, 6)
            oprot.writeString(self.crmTeamId.encode('utf-8') if sys.version_info[0] == 2 else self.crmTeamId)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 8)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Interaction(object):
    """
    Attributes:
     - id
     - type
     - subject
     - body
     - initiatedByContact
     - timestamp
     - createdAt
     - updatedAt
     - participants
     - editable
     - participantCount
     - threadId
     - subtype
     - personId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'id', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
        (3, TType.STRING, 'subject', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'body', 'UTF8', None, ),  # 4
        (5, TType.BOOL, 'initiatedByContact', None, None, ),  # 5
        (6, TType.I64, 'timestamp', None, None, ),  # 6
        (7, TType.I64, 'createdAt', None, None, ),  # 7
        (8, TType.I64, 'updatedAt', None, None, ),  # 8
        (9, TType.LIST, 'participants', (TType.STRUCT, (InteractionParticipant, InteractionParticipant.thrift_spec), False), None, ),  # 9
        (10, TType.BOOL, 'editable', None, None, ),  # 10
        (11, TType.I32, 'participantCount', None, None, ),  # 11
        (12, TType.STRING, 'threadId', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'subtype', 'UTF8', None, ),  # 13
        (14, TType.STRING, 'personId', 'UTF8', None, ),  # 14
    )
    def __init__(self, id=None, type=None, subject=None, body=None, initiatedByContact=None, timestamp=None, createdAt=None, updatedAt=None, participants=None, editable=None, participantCount=None, threadId=None, subtype=None, personId=None, ):
        self.id = id
        self.type = type
        self.subject = subject
        self.body = body
        self.initiatedByContact = initiatedByContact
        self.timestamp = timestamp
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.participants = participants
        self.editable = editable
        self.participantCount = participantCount
        self.threadId = threadId
        self.subtype = subtype
        self.personId = personId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.subject = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.body = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.BOOL:
                    self.initiatedByContact = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.timestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.updatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.LIST:
                    self.participants = []
                    (_etype386, _size389) = iprot.readListBegin()
                    for _i387 in range(_size389):
                        _elem388 = InteractionParticipant()
                        _elem388.read(iprot)
                        self.participants.append(_elem388)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.BOOL:
                    self.editable = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.I32:
                    self.participantCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.threadId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.subtype = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRING:
                    self.personId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Interaction')
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 1)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.subject is not None:
            oprot.writeFieldBegin('subject', TType.STRING, 3)
            oprot.writeString(self.subject.encode('utf-8') if sys.version_info[0] == 2 else self.subject)
            oprot.writeFieldEnd()
        if self.body is not None:
            oprot.writeFieldBegin('body', TType.STRING, 4)
            oprot.writeString(self.body.encode('utf-8') if sys.version_info[0] == 2 else self.body)
            oprot.writeFieldEnd()
        if self.initiatedByContact is not None:
            oprot.writeFieldBegin('initiatedByContact', TType.BOOL, 5)
            oprot.writeBool(self.initiatedByContact)
            oprot.writeFieldEnd()
        if self.timestamp is not None:
            oprot.writeFieldBegin('timestamp', TType.I64, 6)
            oprot.writeI64(self.timestamp)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 7)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.updatedAt is not None:
            oprot.writeFieldBegin('updatedAt', TType.I64, 8)
            oprot.writeI64(self.updatedAt)
            oprot.writeFieldEnd()
        if self.participants is not None:
            oprot.writeFieldBegin('participants', TType.LIST, 9)
            oprot.writeListBegin(TType.STRUCT, len(self.participants))
            for _iter390 in self.participants:
                _iter390.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.editable is not None:
            oprot.writeFieldBegin('editable', TType.BOOL, 10)
            oprot.writeBool(self.editable)
            oprot.writeFieldEnd()
        if self.participantCount is not None:
            oprot.writeFieldBegin('participantCount', TType.I32, 11)
            oprot.writeI32(self.participantCount)
            oprot.writeFieldEnd()
        if self.threadId is not None:
            oprot.writeFieldBegin('threadId', TType.STRING, 12)
            oprot.writeString(self.threadId.encode('utf-8') if sys.version_info[0] == 2 else self.threadId)
            oprot.writeFieldEnd()
        if self.subtype is not None:
            oprot.writeFieldBegin('subtype', TType.STRING, 13)
            oprot.writeString(self.subtype.encode('utf-8') if sys.version_info[0] == 2 else self.subtype)
            oprot.writeFieldEnd()
        if self.personId is not None:
            oprot.writeFieldBegin('personId', TType.STRING, 14)
            oprot.writeString(self.personId.encode('utf-8') if sys.version_info[0] == 2 else self.personId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class AggregateInteraction(object):
    """
    Attributes:
     - type
     - subtype
     - count
     - earliestInteractionTimestamp
     - latestInteractionTimestamp
     - latestInteraction
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'type', None, None, ),  # 1
        (2, TType.STRING, 'subtype', 'UTF8', None, ),  # 2
        None,  # 3
        (4, TType.I32, 'count', None, None, ),  # 4
        (5, TType.I64, 'earliestInteractionTimestamp', None, None, ),  # 5
        (6, TType.I64, 'latestInteractionTimestamp', None, None, ),  # 6
        (7, TType.STRUCT, 'latestInteraction', (Interaction, Interaction.thrift_spec), None, ),  # 7
    )
    def __init__(self, type=None, subtype=None, count=None, earliestInteractionTimestamp=None, latestInteractionTimestamp=None, latestInteraction=None, ):
        self.type = type
        self.subtype = subtype
        self.count = count
        self.earliestInteractionTimestamp = earliestInteractionTimestamp
        self.latestInteractionTimestamp = latestInteractionTimestamp
        self.latestInteraction = latestInteraction

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.subtype = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.count = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I64:
                    self.earliestInteractionTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.latestInteractionTimestamp = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.latestInteraction = Interaction()
                    self.latestInteraction.read(iprot)
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('AggregateInteraction')
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 1)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.subtype is not None:
            oprot.writeFieldBegin('subtype', TType.STRING, 2)
            oprot.writeString(self.subtype.encode('utf-8') if sys.version_info[0] == 2 else self.subtype)
            oprot.writeFieldEnd()
        if self.count is not None:
            oprot.writeFieldBegin('count', TType.I32, 4)
            oprot.writeI32(self.count)
            oprot.writeFieldEnd()
        if self.earliestInteractionTimestamp is not None:
            oprot.writeFieldBegin('earliestInteractionTimestamp', TType.I64, 5)
            oprot.writeI64(self.earliestInteractionTimestamp)
            oprot.writeFieldEnd()
        if self.latestInteractionTimestamp is not None:
            oprot.writeFieldBegin('latestInteractionTimestamp', TType.I64, 6)
            oprot.writeI64(self.latestInteractionTimestamp)
            oprot.writeFieldEnd()
        if self.latestInteraction is not None:
            oprot.writeFieldBegin('latestInteraction', TType.STRUCT, 7)
            self.latestInteraction.write(oprot)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
