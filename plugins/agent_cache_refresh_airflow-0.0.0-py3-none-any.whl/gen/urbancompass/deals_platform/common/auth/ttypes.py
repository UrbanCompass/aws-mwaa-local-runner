
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys

from thrift.transport import TTransport


class Action(object):
    DEAL_READ = 0
    DEAL_HOLD = 1
    DEAL_VOID = 2
    DEAL_NOTES = 3
    DEAL_INITIAL_REVIEW = 4
    DEAL_FINAL_REVIEW = 5
    DEAL_POST_TRANSACTION_EDIT = 6
    DEAL_VENDOR_PAYMENT_HOLD = 7
    DEAL_WITHDRAW = 8
    DRAFT_DEAL_UPDATE = 9
    DEAL_CREATE = 10
    DEAL_REAPPROVAL = 11
    DRAFT_DEAL_READ = 12
    DEAL_STATUS_READ = 13
    FUND_UPDATE = 14
    CREDIT_CREATE = 15
    CREDIT_READ = 16
    CREDIT_WRITE = 17
    REIMBURSEMENT_CREATE = 18
    REIMBURSEMENT_READ = 19
    REIMBURSEMENT_WRITE = 20

    _VALUES_TO_NAMES = {
        0: "DEAL_READ",
        1: "DEAL_HOLD",
        2: "DEAL_VOID",
        3: "DEAL_NOTES",
        4: "DEAL_INITIAL_REVIEW",
        5: "DEAL_FINAL_REVIEW",
        6: "DEAL_POST_TRANSACTION_EDIT",
        7: "DEAL_VENDOR_PAYMENT_HOLD",
        8: "DEAL_WITHDRAW",
        9: "DRAFT_DEAL_UPDATE",
        10: "DEAL_CREATE",
        11: "DEAL_REAPPROVAL",
        12: "DRAFT_DEAL_READ",
        13: "DEAL_STATUS_READ",
        14: "FUND_UPDATE",
        15: "CREDIT_CREATE",
        16: "CREDIT_READ",
        17: "CREDIT_WRITE",
        18: "REIMBURSEMENT_CREATE",
        19: "REIMBURSEMENT_READ",
        20: "REIMBURSEMENT_WRITE",
    }

    _NAMES_TO_VALUES = {
        "DEAL_READ": 0,
        "DEAL_HOLD": 1,
        "DEAL_VOID": 2,
        "DEAL_NOTES": 3,
        "DEAL_INITIAL_REVIEW": 4,
        "DEAL_FINAL_REVIEW": 5,
        "DEAL_POST_TRANSACTION_EDIT": 6,
        "DEAL_VENDOR_PAYMENT_HOLD": 7,
        "DEAL_WITHDRAW": 8,
        "DRAFT_DEAL_UPDATE": 9,
        "DEAL_CREATE": 10,
        "DEAL_REAPPROVAL": 11,
        "DRAFT_DEAL_READ": 12,
        "DEAL_STATUS_READ": 13,
        "FUND_UPDATE": 14,
        "CREDIT_CREATE": 15,
        "CREDIT_READ": 16,
        "CREDIT_WRITE": 17,
        "REIMBURSEMENT_CREATE": 18,
        "REIMBURSEMENT_READ": 19,
        "REIMBURSEMENT_WRITE": 20,
    }


class Group(object):
    """
    Attributes:
     - name
     - teamIds
     - id
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.SET, 'teamIds', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.STRING, 'id', 'UTF8', None, ),  # 3
    )
    def __init__(self, name=None, teamIds=None, id=None, ):
        self.name = name
        self.teamIds = teamIds
        self.id = id

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.SET:
                    self.teamIds = set()
                    (_etype3, _size5) = iprot.readSetBegin()
                    for _i2 in range(_size5):
                        _elem4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.teamIds.add(_elem4)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Group')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.teamIds is not None:
            oprot.writeFieldBegin('teamIds', TType.SET, 2)
            oprot.writeSetBegin(TType.STRING, len(self.teamIds))
            for _iter6 in self.teamIds:
                oprot.writeString(_iter6.encode('utf-8') if sys.version_info[0] == 2 else _iter6)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.id is not None:
            oprot.writeFieldBegin('id', TType.STRING, 3)
            oprot.writeString(self.id.encode('utf-8') if sys.version_info[0] == 2 else self.id)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Role(object):
    """
    Attributes:
     - name
     - permissions
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'name', 'UTF8', None, ),  # 1
        (2, TType.SET, 'permissions', (TType.I32, None, False), None, ),  # 2
    )
    def __init__(self, name=None, permissions=None, ):
        self.name = name
        self.permissions = permissions

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.SET:
                    self.permissions = set()
                    (_etype8, _size10) = iprot.readSetBegin()
                    for _i7 in range(_size10):
                        _elem9 = iprot.readI32()
                        self.permissions.add(_elem9)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Role')
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 1)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.permissions is not None:
            oprot.writeFieldBegin('permissions', TType.SET, 2)
            oprot.writeSetBegin(TType.I32, len(self.permissions))
            for _iter11 in self.permissions:
                oprot.writeI32(_iter11)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class User(object):
    """
    Attributes:
     - userId
     - roleNames
     - groupIds
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'userId', 'UTF8', None, ),  # 1
        (2, TType.SET, 'roleNames', (TType.STRING, 'UTF8', False), None, ),  # 2
        (3, TType.SET, 'groupIds', (TType.STRING, 'UTF8', False), None, ),  # 3
    )
    def __init__(self, userId=None, roleNames=None, groupIds=None, ):
        self.userId = userId
        self.roleNames = roleNames
        self.groupIds = groupIds

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.userId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.SET:
                    self.roleNames = set()
                    (_etype13, _size15) = iprot.readSetBegin()
                    for _i12 in range(_size15):
                        _elem14 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.roleNames.add(_elem14)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.SET:
                    self.groupIds = set()
                    (_etype17, _size19) = iprot.readSetBegin()
                    for _i16 in range(_size19):
                        _elem18 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.groupIds.add(_elem18)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('User')
        if self.userId is not None:
            oprot.writeFieldBegin('userId', TType.STRING, 1)
            oprot.writeString(self.userId.encode('utf-8') if sys.version_info[0] == 2 else self.userId)
            oprot.writeFieldEnd()
        if self.roleNames is not None:
            oprot.writeFieldBegin('roleNames', TType.SET, 2)
            oprot.writeSetBegin(TType.STRING, len(self.roleNames))
            for _iter20 in self.roleNames:
                oprot.writeString(_iter20.encode('utf-8') if sys.version_info[0] == 2 else _iter20)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.groupIds is not None:
            oprot.writeFieldBegin('groupIds', TType.SET, 3)
            oprot.writeSetBegin(TType.STRING, len(self.groupIds))
            for _iter21 in self.groupIds:
                oprot.writeString(_iter21.encode('utf-8') if sys.version_info[0] == 2 else _iter21)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
