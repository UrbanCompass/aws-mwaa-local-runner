
# -*- coding: utf-8 -*-
# GENERATED CODE: DO NOT MODIFY
"""
:copyright: (c) 2021 by Urban Compass, Inc.
"""

from thrift.Thrift import TType, TMessageType, TFrozenDict, TException, TApplicationException
from thrift.protocol.TProtocol import TProtocolException
import sys
import gen.urbancompass.listing.address.ttypes
import gen.urbancompass.common.base.ttypes
import gen.urbancompass.building.building_client_source.ttypes
import gen.urbancompass.contact_info.ttypes
import gen.urbancompass.image.ttypes
import gen.urbancompass.listing.listing.ttypes
import gen.urbancompass.image.non_image_media.ttypes
import gen.urbancompass.property_type.ttypes

from thrift.transport import TTransport


class BuildingPreviewStatusType(object):
    NONEXISTENT = 0
    AGGREGATOR_INITIALIZED = 1
    EDITOR_CREATED = 2
    EDITOR_UPDATED = 3
    APPROVED = 4
    REJECTED = 5
    PUBLISHED = 6

    _VALUES_TO_NAMES = {
        0: "NONEXISTENT",
        1: "AGGREGATOR_INITIALIZED",
        2: "EDITOR_CREATED",
        3: "EDITOR_UPDATED",
        4: "APPROVED",
        5: "REJECTED",
        6: "PUBLISHED",
    }

    _NAMES_TO_VALUES = {
        "NONEXISTENT": 0,
        "AGGREGATOR_INITIALIZED": 1,
        "EDITOR_CREATED": 2,
        "EDITOR_UPDATED": 3,
        "APPROVED": 4,
        "REJECTED": 5,
        "PUBLISHED": 6,
    }


class DetailOption(object):
    NONE = 0
    ALLOWED = 1
    NOT_ALLOWED = 2
    UNKNOWN = 3
    HDFC_INCOME_RESTRICTIONS = 4
    NOT_APPLICABLE = 5
    COLLECTED = 6
    NOT_COLLECTED = 7
    YES = 8
    NO = 9

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "ALLOWED",
        2: "NOT_ALLOWED",
        3: "UNKNOWN",
        4: "HDFC_INCOME_RESTRICTIONS",
        5: "NOT_APPLICABLE",
        6: "COLLECTED",
        7: "NOT_COLLECTED",
        8: "YES",
        9: "NO",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "ALLOWED": 1,
        "NOT_ALLOWED": 2,
        "UNKNOWN": 3,
        "HDFC_INCOME_RESTRICTIONS": 4,
        "NOT_APPLICABLE": 5,
        "COLLECTED": 6,
        "NOT_COLLECTED": 7,
        "YES": 8,
        "NO": 9,
    }


class DetailPolicyField(object):
    LAND_MARKED = 0
    LAND_LEASED = 1
    LIVE_WORK = 2
    WASHER_DRYER = 3
    HDFC_INCOME_RESTRICTIONS = 4
    TRANSFER_FEE_COLLECTED = 5
    GIFTING_ALLOWED = 6
    DIPLOMATS_ALLOWED = 7
    OPEN_HOUSES_ALLOWED = 8
    SUBLET = 9
    PIED_A_TERRE = 10
    CO_PURCHASING = 11
    PARENTAL_PURCHASING = 12
    GUARANTOR = 13

    _VALUES_TO_NAMES = {
        0: "LAND_MARKED",
        1: "LAND_LEASED",
        2: "LIVE_WORK",
        3: "WASHER_DRYER",
        4: "HDFC_INCOME_RESTRICTIONS",
        5: "TRANSFER_FEE_COLLECTED",
        6: "GIFTING_ALLOWED",
        7: "DIPLOMATS_ALLOWED",
        8: "OPEN_HOUSES_ALLOWED",
        9: "SUBLET",
        10: "PIED_A_TERRE",
        11: "CO_PURCHASING",
        12: "PARENTAL_PURCHASING",
        13: "GUARANTOR",
    }

    _NAMES_TO_VALUES = {
        "LAND_MARKED": 0,
        "LAND_LEASED": 1,
        "LIVE_WORK": 2,
        "WASHER_DRYER": 3,
        "HDFC_INCOME_RESTRICTIONS": 4,
        "TRANSFER_FEE_COLLECTED": 5,
        "GIFTING_ALLOWED": 6,
        "DIPLOMATS_ALLOWED": 7,
        "OPEN_HOUSES_ALLOWED": 8,
        "SUBLET": 9,
        "PIED_A_TERRE": 10,
        "CO_PURCHASING": 11,
        "PARENTAL_PURCHASING": 12,
        "GUARANTOR": 13,
    }


class DistrictType(object):
    SCHOOL = 0
    CITY_COUNCIL = 1
    POLICE_DEPARTMENT = 2
    FIRE_DEPARTMENT = 3
    SANITATION = 4
    HISTORIC = 5
    COMMUNITY = 6
    HEALTH_CENTER = 7

    _VALUES_TO_NAMES = {
        0: "SCHOOL",
        1: "CITY_COUNCIL",
        2: "POLICE_DEPARTMENT",
        3: "FIRE_DEPARTMENT",
        4: "SANITATION",
        5: "HISTORIC",
        6: "COMMUNITY",
        7: "HEALTH_CENTER",
    }

    _NAMES_TO_VALUES = {
        "SCHOOL": 0,
        "CITY_COUNCIL": 1,
        "POLICE_DEPARTMENT": 2,
        "FIRE_DEPARTMENT": 3,
        "SANITATION": 4,
        "HISTORIC": 5,
        "COMMUNITY": 6,
        "HEALTH_CENTER": 7,
    }


class KafkaMessageSendStatus(object):
    CIRCUIT_BREAKER_OPEN = 0
    FAILURE_IN_KAFKA_CLUSTER = 1
    INVALID_INPUT = 2
    KAFKA_NOT_ENABLE = 3
    KAFKA_FEATURE_NOT_ENABLED = 4
    SUCCESS = 5

    _VALUES_TO_NAMES = {
        0: "CIRCUIT_BREAKER_OPEN",
        1: "FAILURE_IN_KAFKA_CLUSTER",
        2: "INVALID_INPUT",
        3: "KAFKA_NOT_ENABLE",
        4: "KAFKA_FEATURE_NOT_ENABLED",
        5: "SUCCESS",
    }

    _NAMES_TO_VALUES = {
        "CIRCUIT_BREAKER_OPEN": 0,
        "FAILURE_IN_KAFKA_CLUSTER": 1,
        "INVALID_INPUT": 2,
        "KAFKA_NOT_ENABLE": 3,
        "KAFKA_FEATURE_NOT_ENABLED": 4,
        "SUCCESS": 5,
    }


class LeedCertifiedType(object):
    NONE = 0
    CERTIFIED = 1
    SILVER = 2
    GOLD = 3
    PLATINUM = 4

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "CERTIFIED",
        2: "SILVER",
        3: "GOLD",
        4: "PLATINUM",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "CERTIFIED": 1,
        "SILVER": 2,
        "GOLD": 3,
        "PLATINUM": 4,
    }


class OccupancyStatus(object):
    NONE = 0
    IMMEDIATE_OCCUPANCY = 1
    OCCUPANCY = 2

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "IMMEDIATE_OCCUPANCY",
        2: "OCCUPANCY",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "IMMEDIATE_OCCUPANCY": 1,
        "OCCUPANCY": 2,
    }


class PetPolicy(object):
    NONE = 0
    ONLY_CATS = 1
    ONLY_DOGS = 2
    PETS_ALLOWED = 3

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "ONLY_CATS",
        2: "ONLY_DOGS",
        3: "PETS_ALLOWED",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "ONLY_CATS": 1,
        "ONLY_DOGS": 2,
        "PETS_ALLOWED": 3,
    }


class PropertyType(object):
    NONE = 0
    SINGLE_FAMILY = 1
    CONDOP = 2
    CO_OP = 3
    CONDO = 4
    RENTAL = 5
    MIXED_USE = 6
    MULTI_FAMILY = 7
    TOWNHOUSE = 8
    MOBILE_MANUFACTURED = 9
    NON_RESIDENTIAL = 10
    OTHER = 11

    _VALUES_TO_NAMES = {
        0: "NONE",
        1: "SINGLE_FAMILY",
        2: "CONDOP",
        3: "CO_OP",
        4: "CONDO",
        5: "RENTAL",
        6: "MIXED_USE",
        7: "MULTI_FAMILY",
        8: "TOWNHOUSE",
        9: "MOBILE_MANUFACTURED",
        10: "NON_RESIDENTIAL",
        11: "OTHER",
    }

    _NAMES_TO_VALUES = {
        "NONE": 0,
        "SINGLE_FAMILY": 1,
        "CONDOP": 2,
        "CO_OP": 3,
        "CONDO": 4,
        "RENTAL": 5,
        "MIXED_USE": 6,
        "MULTI_FAMILY": 7,
        "TOWNHOUSE": 8,
        "MOBILE_MANUFACTURED": 9,
        "NON_RESIDENTIAL": 10,
        "OTHER": 11,
    }


class ProximityCode(object):
    NOT_AVAILABLE = 0
    DETACHED = 1
    SEMI_ATTACHED = 2
    ATTACHED = 3

    _VALUES_TO_NAMES = {
        0: "NOT_AVAILABLE",
        1: "DETACHED",
        2: "SEMI_ATTACHED",
        3: "ATTACHED",
    }

    _NAMES_TO_VALUES = {
        "NOT_AVAILABLE": 0,
        "DETACHED": 1,
        "SEMI_ATTACHED": 2,
        "ATTACHED": 3,
    }


class PublishMessageType(object):
    PUBLISH = 0
    APPROVE = 1
    REJECT = 2

    _VALUES_TO_NAMES = {
        0: "PUBLISH",
        1: "APPROVE",
        2: "REJECT",
    }

    _NAMES_TO_VALUES = {
        "PUBLISH": 0,
        "APPROVE": 1,
        "REJECT": 2,
    }


class BuildingPreviewOutputDTO(object):
    """
    Attributes:
     - buildingId
     - address
     - addressSha
     - geoId
     - numberOfUnits
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'buildingId', None, None, ),  # 1
        (2, TType.STRING, 'address', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'addressSha', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'geoId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'numberOfUnits', None, None, ),  # 5
    )
    def __init__(self, buildingId=None, address=None, addressSha=None, geoId=None, numberOfUnits=None, ):
        self.buildingId = buildingId
        self.address = address
        self.addressSha = addressSha
        self.geoId = geoId
        self.numberOfUnits = numberOfUnits

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.buildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.addressSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.numberOfUnits = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BuildingPreviewOutputDTO')
        if self.buildingId is not None:
            oprot.writeFieldBegin('buildingId', TType.I64, 1)
            oprot.writeI64(self.buildingId)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 2)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.addressSha is not None:
            oprot.writeFieldBegin('addressSha', TType.STRING, 3)
            oprot.writeString(self.addressSha.encode('utf-8') if sys.version_info[0] == 2 else self.addressSha)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 4)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.numberOfUnits is not None:
            oprot.writeFieldBegin('numberOfUnits', TType.I32, 5)
            oprot.writeI32(self.numberOfUnits)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BuildingPreviewStatus(object):
    """
    Attributes:
     - messierBuildingId
     - ucAddress
     - ucAddressSha
     - geoId
     - previewStatus
     - createdAt
     - lastModified
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'messierBuildingId', None, None, ),  # 1
        (2, TType.STRING, 'ucAddress', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'ucAddressSha', 'UTF8', None, ),  # 3
        (4, TType.STRING, 'geoId', 'UTF8', None, ),  # 4
        (5, TType.I32, 'previewStatus', None, None, ),  # 5
        (6, TType.I64, 'createdAt', None, None, ),  # 6
        (7, TType.I64, 'lastModified', None, None, ),  # 7
    )
    def __init__(self, messierBuildingId=None, ucAddress=None, ucAddressSha=None, geoId=None, previewStatus=None, createdAt=None, lastModified=None, ):
        self.messierBuildingId = messierBuildingId
        self.ucAddress = ucAddress
        self.ucAddressSha = ucAddressSha
        self.geoId = geoId
        self.previewStatus = previewStatus
        self.createdAt = createdAt
        self.lastModified = lastModified

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.messierBuildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.ucAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.ucAddressSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.previewStatus = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.lastModified = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BuildingPreviewStatus')
        if self.messierBuildingId is not None:
            oprot.writeFieldBegin('messierBuildingId', TType.I64, 1)
            oprot.writeI64(self.messierBuildingId)
            oprot.writeFieldEnd()
        if self.ucAddress is not None:
            oprot.writeFieldBegin('ucAddress', TType.STRING, 2)
            oprot.writeString(self.ucAddress.encode('utf-8') if sys.version_info[0] == 2 else self.ucAddress)
            oprot.writeFieldEnd()
        if self.ucAddressSha is not None:
            oprot.writeFieldBegin('ucAddressSha', TType.STRING, 3)
            oprot.writeString(self.ucAddressSha.encode('utf-8') if sys.version_info[0] == 2 else self.ucAddressSha)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 4)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.previewStatus is not None:
            oprot.writeFieldBegin('previewStatus', TType.I32, 5)
            oprot.writeI32(self.previewStatus)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 6)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        if self.lastModified is not None:
            oprot.writeFieldBegin('lastModified', TType.I64, 7)
            oprot.writeI64(self.lastModified)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class DetailPolicy(object):
    """
    Attributes:
     - option
     - detail
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'option', None, None, ),  # 1
        (2, TType.STRING, 'detail', 'UTF8', None, ),  # 2
    )
    def __init__(self, option=None, detail=None, ):
        self.option = option
        self.detail = detail

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.option = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.detail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('DetailPolicy')
        if self.option is not None:
            oprot.writeFieldBegin('option', TType.I32, 1)
            oprot.writeI32(self.option)
            oprot.writeFieldEnd()
        if self.detail is not None:
            oprot.writeFieldBegin('detail', TType.STRING, 2)
            oprot.writeString(self.detail.encode('utf-8') if sys.version_info[0] == 2 else self.detail)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Dimensions(object):
    """
    Attributes:
     - depth
     - width
     - height
     - area
     - rawInput
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'depth', None, None, ),  # 1
        (2, TType.DOUBLE, 'width', None, None, ),  # 2
        (3, TType.DOUBLE, 'height', None, None, ),  # 3
        (4, TType.DOUBLE, 'area', None, None, ),  # 4
        (5, TType.STRING, 'rawInput', 'UTF8', None, ),  # 5
    )
    def __init__(self, depth=None, width=None, height=None, area=None, rawInput=None, ):
        self.depth = depth
        self.width = width
        self.height = height
        self.area = area
        self.rawInput = rawInput

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.depth = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.width = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.height = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.area = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.rawInput = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Dimensions')
        if self.depth is not None:
            oprot.writeFieldBegin('depth', TType.DOUBLE, 1)
            oprot.writeDouble(self.depth)
            oprot.writeFieldEnd()
        if self.width is not None:
            oprot.writeFieldBegin('width', TType.DOUBLE, 2)
            oprot.writeDouble(self.width)
            oprot.writeFieldEnd()
        if self.height is not None:
            oprot.writeFieldBegin('height', TType.DOUBLE, 3)
            oprot.writeDouble(self.height)
            oprot.writeFieldEnd()
        if self.area is not None:
            oprot.writeFieldBegin('area', TType.DOUBLE, 4)
            oprot.writeDouble(self.area)
            oprot.writeFieldEnd()
        if self.rawInput is not None:
            oprot.writeFieldBegin('rawInput', TType.STRING, 5)
            oprot.writeString(self.rawInput.encode('utf-8') if sys.version_info[0] == 2 else self.rawInput)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class District(object):
    """
    Attributes:
     - code
     - type
     - name
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'code', 'UTF8', None, ),  # 1
        (2, TType.I32, 'type', None, None, ),  # 2
        (3, TType.STRING, 'name', 'UTF8', None, ),  # 3
    )
    def __init__(self, code=None, type=None, name=None, ):
        self.code = code
        self.type = type
        self.name = name

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.code = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.type = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('District')
        if self.code is not None:
            oprot.writeFieldBegin('code', TType.STRING, 1)
            oprot.writeString(self.code.encode('utf-8') if sys.version_info[0] == 2 else self.code)
            oprot.writeFieldEnd()
        if self.type is not None:
            oprot.writeFieldBegin('type', TType.I32, 2)
            oprot.writeI32(self.type)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 3)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FinancialPolicy(object):
    """
    Attributes:
     - minDownPayment
     - taxDeductibility
     - maxDebtToIncomeRatio
     - minPostClosingLiquidity
    """

    thrift_spec = (
        None,  # 0
        (1, TType.DOUBLE, 'minDownPayment', None, None, ),  # 1
        (2, TType.DOUBLE, 'taxDeductibility', None, None, ),  # 2
        (3, TType.DOUBLE, 'maxDebtToIncomeRatio', None, None, ),  # 3
        (4, TType.I32, 'minPostClosingLiquidity', None, None, ),  # 4
    )
    def __init__(self, minDownPayment=None, taxDeductibility=None, maxDebtToIncomeRatio=None, minPostClosingLiquidity=None, ):
        self.minDownPayment = minDownPayment
        self.taxDeductibility = taxDeductibility
        self.maxDebtToIncomeRatio = maxDebtToIncomeRatio
        self.minPostClosingLiquidity = minPostClosingLiquidity

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.DOUBLE:
                    self.minDownPayment = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.DOUBLE:
                    self.taxDeductibility = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.maxDebtToIncomeRatio = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I32:
                    self.minPostClosingLiquidity = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FinancialPolicy')
        if self.minDownPayment is not None:
            oprot.writeFieldBegin('minDownPayment', TType.DOUBLE, 1)
            oprot.writeDouble(self.minDownPayment)
            oprot.writeFieldEnd()
        if self.taxDeductibility is not None:
            oprot.writeFieldBegin('taxDeductibility', TType.DOUBLE, 2)
            oprot.writeDouble(self.taxDeductibility)
            oprot.writeFieldEnd()
        if self.maxDebtToIncomeRatio is not None:
            oprot.writeFieldBegin('maxDebtToIncomeRatio', TType.DOUBLE, 3)
            oprot.writeDouble(self.maxDebtToIncomeRatio)
            oprot.writeFieldEnd()
        if self.minPostClosingLiquidity is not None:
            oprot.writeFieldBegin('minPostClosingLiquidity', TType.I32, 4)
            oprot.writeI32(self.minPostClosingLiquidity)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class FloorPlanImage(object):
    """
    Attributes:
     - image
     - unitNumber
     - bedrooms
     - bathrooms
     - squareFeet
     - price
     - date
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRUCT, 'image', (gen.urbancompass.image.ttypes.ImageInfo, gen.urbancompass.image.ttypes.ImageInfo.thrift_spec), None, ),  # 1
        (2, TType.STRING, 'unitNumber', 'UTF8', None, ),  # 2
        (3, TType.DOUBLE, 'bedrooms', None, None, ),  # 3
        (4, TType.DOUBLE, 'bathrooms', None, None, ),  # 4
        (5, TType.DOUBLE, 'squareFeet', None, None, ),  # 5
        (6, TType.DOUBLE, 'price', None, None, ),  # 6
        (7, TType.I64, 'date', None, None, ),  # 7
    )
    def __init__(self, image=None, unitNumber=None, bedrooms=None, bathrooms=None, squareFeet=None, price=None, date=None, ):
        self.image = image
        self.unitNumber = unitNumber
        self.bedrooms = bedrooms
        self.bathrooms = bathrooms
        self.squareFeet = squareFeet
        self.price = price
        self.date = date

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRUCT:
                    self.image = gen.urbancompass.image.ttypes.ImageInfo()
                    self.image.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.unitNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.DOUBLE:
                    self.bedrooms = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.DOUBLE:
                    self.bathrooms = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.DOUBLE:
                    self.squareFeet = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.DOUBLE:
                    self.price = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I64:
                    self.date = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('FloorPlanImage')
        if self.image is not None:
            oprot.writeFieldBegin('image', TType.STRUCT, 1)
            self.image.write(oprot)
            oprot.writeFieldEnd()
        if self.unitNumber is not None:
            oprot.writeFieldBegin('unitNumber', TType.STRING, 2)
            oprot.writeString(self.unitNumber.encode('utf-8') if sys.version_info[0] == 2 else self.unitNumber)
            oprot.writeFieldEnd()
        if self.bedrooms is not None:
            oprot.writeFieldBegin('bedrooms', TType.DOUBLE, 3)
            oprot.writeDouble(self.bedrooms)
            oprot.writeFieldEnd()
        if self.bathrooms is not None:
            oprot.writeFieldBegin('bathrooms', TType.DOUBLE, 4)
            oprot.writeDouble(self.bathrooms)
            oprot.writeFieldEnd()
        if self.squareFeet is not None:
            oprot.writeFieldBegin('squareFeet', TType.DOUBLE, 5)
            oprot.writeDouble(self.squareFeet)
            oprot.writeFieldEnd()
        if self.price is not None:
            oprot.writeFieldBegin('price', TType.DOUBLE, 6)
            oprot.writeDouble(self.price)
            oprot.writeFieldEnd()
        if self.date is not None:
            oprot.writeFieldBegin('date', TType.I64, 7)
            oprot.writeI64(self.date)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetOneBuildingPartitionInputDTO(object):
    """
    Attributes:
     - geoId
     - limit
     - lastModified
     - lastModifiedBefore
     - lastUcAddressSha
     - messierBuildingId
     - partition
     - totalPartitions
     - ucAddressSha
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'geoId', 'UTF8', None, ),  # 1
        (2, TType.I32, 'limit', None, None, ),  # 2
        (3, TType.I64, 'lastModified', None, None, ),  # 3
        (4, TType.I64, 'lastModifiedBefore', None, None, ),  # 4
        (5, TType.STRING, 'lastUcAddressSha', 'UTF8', None, ),  # 5
        (6, TType.I64, 'messierBuildingId', None, None, ),  # 6
        (7, TType.I32, 'partition', None, None, ),  # 7
        (8, TType.I32, 'totalPartitions', None, None, ),  # 8
        (9, TType.STRING, 'ucAddressSha', 'UTF8', None, ),  # 9
    )
    def __init__(self, geoId=None, limit=None, lastModified=None, lastModifiedBefore=None, lastUcAddressSha=None, messierBuildingId=None, partition=None, totalPartitions=None, ucAddressSha=None, ):
        self.geoId = geoId
        self.limit = limit
        self.lastModified = lastModified
        self.lastModifiedBefore = lastModifiedBefore
        self.lastUcAddressSha = lastUcAddressSha
        self.messierBuildingId = messierBuildingId
        self.partition = partition
        self.totalPartitions = totalPartitions
        self.ucAddressSha = ucAddressSha

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.limit = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.lastModified = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.lastModifiedBefore = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.lastUcAddressSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.messierBuildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.I32:
                    self.partition = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.totalPartitions = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.ucAddressSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetOneBuildingPartitionInputDTO')
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 1)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.limit is not None:
            oprot.writeFieldBegin('limit', TType.I32, 2)
            oprot.writeI32(self.limit)
            oprot.writeFieldEnd()
        if self.lastModified is not None:
            oprot.writeFieldBegin('lastModified', TType.I64, 3)
            oprot.writeI64(self.lastModified)
            oprot.writeFieldEnd()
        if self.lastModifiedBefore is not None:
            oprot.writeFieldBegin('lastModifiedBefore', TType.I64, 4)
            oprot.writeI64(self.lastModifiedBefore)
            oprot.writeFieldEnd()
        if self.lastUcAddressSha is not None:
            oprot.writeFieldBegin('lastUcAddressSha', TType.STRING, 5)
            oprot.writeString(self.lastUcAddressSha.encode('utf-8') if sys.version_info[0] == 2 else self.lastUcAddressSha)
            oprot.writeFieldEnd()
        if self.messierBuildingId is not None:
            oprot.writeFieldBegin('messierBuildingId', TType.I64, 6)
            oprot.writeI64(self.messierBuildingId)
            oprot.writeFieldEnd()
        if self.partition is not None:
            oprot.writeFieldBegin('partition', TType.I32, 7)
            oprot.writeI32(self.partition)
            oprot.writeFieldEnd()
        if self.totalPartitions is not None:
            oprot.writeFieldBegin('totalPartitions', TType.I32, 8)
            oprot.writeI32(self.totalPartitions)
            oprot.writeFieldEnd()
        if self.ucAddressSha is not None:
            oprot.writeFieldBegin('ucAddressSha', TType.STRING, 9)
            oprot.writeString(self.ucAddressSha.encode('utf-8') if sys.version_info[0] == 2 else self.ucAddressSha)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class KafkaMessageStatusCounter(object):
    """
    Attributes:
     - counter
    """

    thrift_spec = (
        None,  # 0
        (1, TType.MAP, 'counter', (TType.I32, None, TType.I32, None, False), None, ),  # 1
    )
    def __init__(self, counter=None, ):
        self.counter = counter

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.MAP:
                    self.counter = {}
                    (_ktype3, _vtype4, _size7) = iprot.readMapBegin()
                    for _i2 in range(_size7):
                        _key5 = iprot.readI32()
                        _val6 = iprot.readI32()
                        self.counter[_key5] = _val6
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('KafkaMessageStatusCounter')
        if self.counter is not None:
            oprot.writeFieldBegin('counter', TType.MAP, 1)
            oprot.writeMapBegin(TType.I32, TType.I32, len(self.counter))
            for _kiter8, _viter9 in self.counter.items():
                oprot.writeI32(_kiter8)
                oprot.writeI32(_viter9)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class NewDevelopment(object):
    """
    Attributes:
     - interiorDesigner
     - yearConverted
     - startDate
     - endDate
     - occupancyStatusSelection
     - occupancyDate
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'interiorDesigner', 'UTF8', None, ),  # 1
        (2, TType.I32, 'yearConverted', None, None, ),  # 2
        (3, TType.I64, 'startDate', None, None, ),  # 3
        (4, TType.I64, 'endDate', None, None, ),  # 4
        (5, TType.I32, 'occupancyStatusSelection', None, None, ),  # 5
        (6, TType.I64, 'occupancyDate', None, None, ),  # 6
    )
    def __init__(self, interiorDesigner=None, yearConverted=None, startDate=None, endDate=None, occupancyStatusSelection=None, occupancyDate=None, ):
        self.interiorDesigner = interiorDesigner
        self.yearConverted = yearConverted
        self.startDate = startDate
        self.endDate = endDate
        self.occupancyStatusSelection = occupancyStatusSelection
        self.occupancyDate = occupancyDate

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.interiorDesigner = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.yearConverted = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.startDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.endDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.I32:
                    self.occupancyStatusSelection = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.occupancyDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('NewDevelopment')
        if self.interiorDesigner is not None:
            oprot.writeFieldBegin('interiorDesigner', TType.STRING, 1)
            oprot.writeString(self.interiorDesigner.encode('utf-8') if sys.version_info[0] == 2 else self.interiorDesigner)
            oprot.writeFieldEnd()
        if self.yearConverted is not None:
            oprot.writeFieldBegin('yearConverted', TType.I32, 2)
            oprot.writeI32(self.yearConverted)
            oprot.writeFieldEnd()
        if self.startDate is not None:
            oprot.writeFieldBegin('startDate', TType.I64, 3)
            oprot.writeI64(self.startDate)
            oprot.writeFieldEnd()
        if self.endDate is not None:
            oprot.writeFieldBegin('endDate', TType.I64, 4)
            oprot.writeI64(self.endDate)
            oprot.writeFieldEnd()
        if self.occupancyStatusSelection is not None:
            oprot.writeFieldBegin('occupancyStatusSelection', TType.I32, 5)
            oprot.writeI32(self.occupancyStatusSelection)
            oprot.writeFieldEnd()
        if self.occupancyDate is not None:
            oprot.writeFieldBegin('occupancyDate', TType.I64, 6)
            oprot.writeI64(self.occupancyDate)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class PublishMessage(object):
    """
    Attributes:
     - messierBuildingId
     - action
     - clientSource
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'messierBuildingId', None, None, ),  # 1
        (2, TType.I32, 'action', None, None, ),  # 2
        (3, TType.I32, 'clientSource', None, None, ),  # 3
    )
    def __init__(self, messierBuildingId=None, action=None, clientSource=None, ):
        self.messierBuildingId = messierBuildingId
        self.action = action
        self.clientSource = clientSource

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.messierBuildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.action = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.clientSource = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('PublishMessage')
        if self.messierBuildingId is not None:
            oprot.writeFieldBegin('messierBuildingId', TType.I64, 1)
            oprot.writeI64(self.messierBuildingId)
            oprot.writeFieldEnd()
        if self.action is not None:
            oprot.writeFieldBegin('action', TType.I32, 2)
            oprot.writeI32(self.action)
            oprot.writeFieldEnd()
        if self.clientSource is not None:
            oprot.writeFieldBegin('clientSource', TType.I32, 3)
            oprot.writeI32(self.clientSource)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TaxAbatements(object):
    """
    Attributes:
     - selection
     - abatementsOption
     - expirationYear
     - description
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'selection', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'abatementsOption', 'UTF8', None, ),  # 2
        (3, TType.I32, 'expirationYear', None, None, ),  # 3
        (4, TType.STRING, 'description', 'UTF8', None, ),  # 4
    )
    def __init__(self, selection=None, abatementsOption=None, expirationYear=None, description=None, ):
        self.selection = selection
        self.abatementsOption = abatementsOption
        self.expirationYear = expirationYear
        self.description = description

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.selection = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.abatementsOption = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.expirationYear = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TaxAbatements')
        if self.selection is not None:
            oprot.writeFieldBegin('selection', TType.STRING, 1)
            oprot.writeString(self.selection.encode('utf-8') if sys.version_info[0] == 2 else self.selection)
            oprot.writeFieldEnd()
        if self.abatementsOption is not None:
            oprot.writeFieldBegin('abatementsOption', TType.STRING, 2)
            oprot.writeString(self.abatementsOption.encode('utf-8') if sys.version_info[0] == 2 else self.abatementsOption)
            oprot.writeFieldEnd()
        if self.expirationYear is not None:
            oprot.writeFieldBegin('expirationYear', TType.I32, 3)
            oprot.writeI32(self.expirationYear)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 4)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class TaxRecord(object):
    """
    Attributes:
     - boroughBlockLot
     - taxMapNumber
     - apportionmentBbl
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, 'boroughBlockLot', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'taxMapNumber', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'apportionmentBbl', 'UTF8', None, ),  # 3
    )
    def __init__(self, boroughBlockLot=None, taxMapNumber=None, apportionmentBbl=None, ):
        self.boroughBlockLot = boroughBlockLot
        self.taxMapNumber = taxMapNumber
        self.apportionmentBbl = apportionmentBbl

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self.boroughBlockLot = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.taxMapNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.apportionmentBbl = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('TaxRecord')
        if self.boroughBlockLot is not None:
            oprot.writeFieldBegin('boroughBlockLot', TType.STRING, 1)
            oprot.writeString(self.boroughBlockLot.encode('utf-8') if sys.version_info[0] == 2 else self.boroughBlockLot)
            oprot.writeFieldEnd()
        if self.taxMapNumber is not None:
            oprot.writeFieldBegin('taxMapNumber', TType.STRING, 2)
            oprot.writeString(self.taxMapNumber.encode('utf-8') if sys.version_info[0] == 2 else self.taxMapNumber)
            oprot.writeFieldEnd()
        if self.apportionmentBbl is not None:
            oprot.writeFieldBegin('apportionmentBbl', TType.STRING, 3)
            oprot.writeString(self.apportionmentBbl.encode('utf-8') if sys.version_info[0] == 2 else self.apportionmentBbl)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BuildingDetails(object):
    """
    Attributes:
     - floors
     - units
     - yearBuilt
     - name
     - age
     - buildingType
     - buildingSize
     - buildingClass
     - primaryPropertyType
     - description
     - petPolicy
     - dogsAllowed
     - catsAllowed
     - petPolicyDetail
     - maxPetWeight
     - unitType
     - submittedDate
     - effectiveDate
     - coopRules
     - serviceLevel
     - access
     - proposedOffering
     - totalSelloutPrice
     - offeringPlan
     - certificateOccupancy
     - exposures
     - wallPolicy
     - residentialUnits
     - condoUnits
     - blockAndLot
     - bin
     - borough
     - block
     - taxLot
     - censusBlock
     - censusTract
     - fireCompany
     - policePrecinct
     - healthArea
     - sanitationBoro
     - sanitationSub
     - zoneDist1
     - zoneDist2
     - zoneDist3
     - zoneDist4
     - overlayOne
     - overlayTwo
     - spDist1
     - spDist2
     - spDist3
     - limitedHeight
     - splitZone
     - landUse
     - easements
     - buildingArea
     - commercialArea
     - residentialArea
     - officeArea
     - retailArea
     - garageArea
     - storageArea
     - factoryArea
     - otherArea
     - areaSourceCode
     - numBuildings
     - extensionCode
     - proximityCode
     - irregularLotCode
     - lotType
     - basementCode
     - assessedLand
     - assessedTotal
     - exemptLand
     - exemptTotal
     - taxAbatements
     - yearAlter1
     - yearAlter2
     - landmark
     - buildingFar
     - residentialFar
     - commercialFar
     - facilityFar
     - boroCode
     - condoNumber
     - tract2010
     - zoneMap
     - zmCode
     - sanbornMap
     - taxMap
     - edesignNum
     - apportionmentDate
     - plutoMapId
     - firm07Flag
     - pfirm15Flag
     - version
     - mapPlutoF
     - rpadDate
     - dcasDate
     - zoningDate
     - landmkDate
     - basempDate
     - masDate
     - poliDate
     - edesigDate
     - geom
     - crossStreets
     - flipTax
     - expectedDTI
     - xCoord
     - yCoord
     - leedCertified
     - detailPolicies
     - detailPoliciesToExclude
     - financialPolicy
     - boardRequirements
     - parkingType
     - parkingDetail
     - parkingOnSite
     - parkingOwnership
     - garageOnSite
     - parking
     - unitCount
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I32, 'floors', None, None, ),  # 1
        (2, TType.I32, 'units', None, None, ),  # 2
        (3, TType.I32, 'yearBuilt', None, None, ),  # 3
        (4, TType.STRING, 'name', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'age', 'UTF8', None, ),  # 5
        (6, TType.STRING, 'buildingClass', 'UTF8', None, ),  # 6
        (7, TType.STRING, 'description', 'UTF8', None, ),  # 7
        (8, TType.I64, 'submittedDate', None, None, ),  # 8
        (9, TType.I64, 'effectiveDate', None, None, ),  # 9
        (10, TType.LIST, 'coopRules', (TType.STRING, 'UTF8', False), None, ),  # 10
        (11, TType.STRING, 'serviceLevel', 'UTF8', None, ),  # 11
        (12, TType.STRING, 'access', 'UTF8', None, ),  # 12
        (13, TType.STRING, 'proposedOffering', 'UTF8', None, ),  # 13
        (14, TType.DOUBLE, 'totalSelloutPrice', None, None, ),  # 14
        (15, TType.STRING, 'offeringPlan', 'UTF8', None, ),  # 15
        (16, TType.STRING, 'certificateOccupancy', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'exposures', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'wallPolicy', 'UTF8', None, ),  # 18
        (19, TType.I32, 'block', None, None, ),  # 19
        (20, TType.I32, 'taxLot', None, None, ),  # 20
        (21, TType.STRING, 'censusBlock', 'UTF8', None, ),  # 21
        (22, TType.STRING, 'censusTract', 'UTF8', None, ),  # 22
        (23, TType.STRING, 'fireCompany', 'UTF8', None, ),  # 23
        (24, TType.I32, 'policePrecinct', None, None, ),  # 24
        (25, TType.I32, 'healthArea', None, None, ),  # 25
        (26, TType.I32, 'sanitationBoro', None, None, ),  # 26
        (27, TType.STRING, 'overlayOne', 'UTF8', None, ),  # 27
        (28, TType.STRING, 'overlayTwo', 'UTF8', None, ),  # 28
        (29, TType.STRING, 'limitedHeight', 'UTF8', None, ),  # 29
        (30, TType.STRING, 'landUse', 'UTF8', None, ),  # 30
        (31, TType.I32, 'easements', None, None, ),  # 31
        (32, TType.DOUBLE, 'buildingArea', None, None, ),  # 32
        (33, TType.I64, 'commercialArea', None, None, ),  # 33
        (34, TType.I64, 'residentialArea', None, None, ),  # 34
        (35, TType.I64, 'officeArea', None, None, ),  # 35
        (36, TType.I64, 'retailArea', None, None, ),  # 36
        (37, TType.I64, 'garageArea', None, None, ),  # 37
        (38, TType.I64, 'factoryArea', None, None, ),  # 38
        (39, TType.I64, 'otherArea', None, None, ),  # 39
        (40, TType.STRING, 'areaSourceCode', 'UTF8', None, ),  # 40
        (41, TType.I32, 'numBuildings', None, None, ),  # 41
        (42, TType.STRING, 'extensionCode', 'UTF8', None, ),  # 42
        (43, TType.I32, 'proximityCode', None, None, ),  # 43
        (44, TType.STRING, 'irregularLotCode', 'UTF8', None, ),  # 44
        (45, TType.STRING, 'lotType', 'UTF8', None, ),  # 45
        (46, TType.STRING, 'basementCode', 'UTF8', None, ),  # 46
        (47, TType.DOUBLE, 'assessedLand', None, None, ),  # 47
        (48, TType.DOUBLE, 'assessedTotal', None, None, ),  # 48
        (49, TType.I64, 'exemptLand', None, None, ),  # 49
        (50, TType.I64, 'exemptTotal', None, None, ),  # 50
        (51, TType.I32, 'yearAlter1', None, None, ),  # 51
        (52, TType.I32, 'yearAlter2', None, None, ),  # 52
        (53, TType.STRING, 'landmark', 'UTF8', None, ),  # 53
        (54, TType.DOUBLE, 'buildingFar', None, None, ),  # 54
        (55, TType.DOUBLE, 'residentialFar', None, None, ),  # 55
        (56, TType.DOUBLE, 'commercialFar', None, None, ),  # 56
        (57, TType.DOUBLE, 'facilityFar', None, None, ),  # 57
        (58, TType.I32, 'boroCode', None, None, ),  # 58
        (59, TType.I32, 'condoNumber', None, None, ),  # 59
        (60, TType.STRING, 'sanbornMap', 'UTF8', None, ),  # 60
        (61, TType.STRING, 'edesignNum', 'UTF8', None, ),  # 61
        (62, TType.STRING, 'apportionmentDate', 'UTF8', None, ),  # 62
        (63, TType.I32, 'plutoMapId', None, None, ),  # 63
        (64, TType.STRING, 'version', 'UTF8', None, ),  # 64
        (65, TType.STRING, 'crossStreets', 'UTF8', None, ),  # 65
        (66, TType.DOUBLE, 'flipTax', None, None, ),  # 66
        (67, TType.DOUBLE, 'expectedDTI', None, None, ),  # 67
        (68, TType.I32, 'residentialUnits', None, None, ),  # 68
        (69, TType.I32, 'condoUnits', None, None, ),  # 69
        (70, TType.STRING, 'blockAndLot', 'UTF8', None, ),  # 70
        (71, TType.I64, 'bin', None, None, ),  # 71
        (72, TType.STRING, 'borough', 'UTF8', None, ),  # 72
        (73, TType.STRING, 'sanitationSub', 'UTF8', None, ),  # 73
        (74, TType.STRING, 'zoneDist1', 'UTF8', None, ),  # 74
        (75, TType.STRING, 'zoneDist2', 'UTF8', None, ),  # 75
        (76, TType.STRING, 'zoneDist3', 'UTF8', None, ),  # 76
        (77, TType.STRING, 'zoneDist4', 'UTF8', None, ),  # 77
        (78, TType.STRING, 'spDist1', 'UTF8', None, ),  # 78
        (79, TType.STRING, 'spDist2', 'UTF8', None, ),  # 79
        (80, TType.STRING, 'spDist3', 'UTF8', None, ),  # 80
        (81, TType.BOOL, 'splitZone', None, None, ),  # 81
        (82, TType.I64, 'storageArea', None, None, ),  # 82
        (83, TType.STRING, 'tract2010', 'UTF8', None, ),  # 83
        (84, TType.I64, 'xCoord', None, None, ),  # 84
        (85, TType.I64, 'yCoord', None, None, ),  # 85
        (86, TType.STRING, 'zoneMap', 'UTF8', None, ),  # 86
        (87, TType.STRING, 'zmCode', 'UTF8', None, ),  # 87
        (88, TType.STRING, 'taxMap', 'UTF8', None, ),  # 88
        (89, TType.STRING, 'firm07Flag', 'UTF8', None, ),  # 89
        (90, TType.STRING, 'pfirm15Flag', 'UTF8', None, ),  # 90
        (91, TType.STRING, 'mapPlutoF', 'UTF8', None, ),  # 91
        (92, TType.STRING, 'rpadDate', 'UTF8', None, ),  # 92
        (93, TType.STRING, 'dcasDate', 'UTF8', None, ),  # 93
        (94, TType.STRING, 'zoningDate', 'UTF8', None, ),  # 94
        (95, TType.STRING, 'landmkDate', 'UTF8', None, ),  # 95
        (96, TType.STRING, 'basempDate', 'UTF8', None, ),  # 96
        (97, TType.STRING, 'masDate', 'UTF8', None, ),  # 97
        (98, TType.STRING, 'poliDate', 'UTF8', None, ),  # 98
        (99, TType.STRING, 'edesigDate', 'UTF8', None, ),  # 99
        (100, TType.STRING, 'geom', 'UTF8', None, ),  # 100
        (101, TType.STRING, 'petPolicy', 'UTF8', None, ),  # 101
        (102, TType.STRING, 'buildingType', 'UTF8', None, ),  # 102
        (103, TType.BOOL, 'dogsAllowed', None, None, ),  # 103
        (104, TType.BOOL, 'catsAllowed', None, None, ),  # 104
        (105, TType.STRUCT, 'taxAbatements', (TaxAbatements, TaxAbatements.thrift_spec), None, ),  # 105
        (106, TType.I32, 'leedCertified', None, None, ),  # 106
        (107, TType.MAP, 'detailPolicies', (TType.I32, None, TType.STRUCT, (DetailPolicy, DetailPolicy.thrift_spec), False), None, ),  # 107
        (108, TType.STRUCT, 'financialPolicy', (FinancialPolicy, FinancialPolicy.thrift_spec), None, ),  # 108
        (109, TType.STRING, 'boardRequirements', 'UTF8', None, ),  # 109
        (110, TType.I32, 'primaryPropertyType', None, None, ),  # 110
        (111, TType.STRING, 'petPolicyDetail', 'UTF8', None, ),  # 111
        (112, TType.STRING, 'buildingSize', 'UTF8', None, ),  # 112
        (113, TType.STRING, 'parkingType', 'UTF8', None, ),  # 113
        (114, TType.STRING, 'parkingDetail', 'UTF8', None, ),  # 114
        (115, TType.BOOL, 'parkingOnSite', None, None, ),  # 115
        None,  # 116
        (117, TType.STRING, 'parkingOwnership', 'UTF8', None, ),  # 117
        (118, TType.BOOL, 'garageOnSite', None, None, ),  # 118
        (119, TType.STRING, 'parking', 'UTF8', None, ),  # 119
        (120, TType.DOUBLE, 'maxPetWeight', None, None, ),  # 120
        (121, TType.SET, 'detailPoliciesToExclude', (TType.I32, None, False), None, ),  # 121
        (122, TType.STRING, 'unitType', 'UTF8', None, ),  # 122
        (123, TType.I32, 'unitCount', None, None, ),  # 123
    )
    def __init__(self, floors=None, units=None, yearBuilt=None, name=None, age=None, buildingClass=None, description=None, submittedDate=None, effectiveDate=None, coopRules=None, serviceLevel=None, access=None, proposedOffering=None, totalSelloutPrice=None, offeringPlan=None, certificateOccupancy=None, exposures=None, wallPolicy=None, block=None, taxLot=None, censusBlock=None, censusTract=None, fireCompany=None, policePrecinct=None, healthArea=None, sanitationBoro=None, overlayOne=None, overlayTwo=None, limitedHeight=None, landUse=None, easements=None, buildingArea=None, commercialArea=None, residentialArea=None, officeArea=None, retailArea=None, garageArea=None, factoryArea=None, otherArea=None, areaSourceCode=None, numBuildings=None, extensionCode=None, proximityCode=None, irregularLotCode=None, lotType=None, basementCode=None, assessedLand=None, assessedTotal=None, exemptLand=None, exemptTotal=None, yearAlter1=None, yearAlter2=None, landmark=None, buildingFar=None, residentialFar=None, commercialFar=None, facilityFar=None, boroCode=None, condoNumber=None, sanbornMap=None, edesignNum=None, apportionmentDate=None, plutoMapId=None, version=None, crossStreets=None, flipTax=None, expectedDTI=None, residentialUnits=None, condoUnits=None, blockAndLot=None, bin=None, borough=None, sanitationSub=None, zoneDist1=None, zoneDist2=None, zoneDist3=None, zoneDist4=None, spDist1=None, spDist2=None, spDist3=None, splitZone=None, storageArea=None, tract2010=None, xCoord=None, yCoord=None, zoneMap=None, zmCode=None, taxMap=None, firm07Flag=None, pfirm15Flag=None, mapPlutoF=None, rpadDate=None, dcasDate=None, zoningDate=None, landmkDate=None, basempDate=None, masDate=None, poliDate=None, edesigDate=None, geom=None, petPolicy=None, buildingType=None, dogsAllowed=None, catsAllowed=None, taxAbatements=None, leedCertified=None, detailPolicies=None, financialPolicy=None, boardRequirements=None, primaryPropertyType=None, petPolicyDetail=None, buildingSize=None, parkingType=None, parkingDetail=None, parkingOnSite=None, parkingOwnership=None, garageOnSite=None, parking=None, maxPetWeight=None, detailPoliciesToExclude=None, unitType=None, unitCount=None, ):
        self.floors = floors
        self.units = units
        self.yearBuilt = yearBuilt
        self.name = name
        self.age = age
        self.buildingClass = buildingClass
        self.description = description
        self.submittedDate = submittedDate
        self.effectiveDate = effectiveDate
        self.coopRules = coopRules
        self.serviceLevel = serviceLevel
        self.access = access
        self.proposedOffering = proposedOffering
        self.totalSelloutPrice = totalSelloutPrice
        self.offeringPlan = offeringPlan
        self.certificateOccupancy = certificateOccupancy
        self.exposures = exposures
        self.wallPolicy = wallPolicy
        self.block = block
        self.taxLot = taxLot
        self.censusBlock = censusBlock
        self.censusTract = censusTract
        self.fireCompany = fireCompany
        self.policePrecinct = policePrecinct
        self.healthArea = healthArea
        self.sanitationBoro = sanitationBoro
        self.overlayOne = overlayOne
        self.overlayTwo = overlayTwo
        self.limitedHeight = limitedHeight
        self.landUse = landUse
        self.easements = easements
        self.buildingArea = buildingArea
        self.commercialArea = commercialArea
        self.residentialArea = residentialArea
        self.officeArea = officeArea
        self.retailArea = retailArea
        self.garageArea = garageArea
        self.factoryArea = factoryArea
        self.otherArea = otherArea
        self.areaSourceCode = areaSourceCode
        self.numBuildings = numBuildings
        self.extensionCode = extensionCode
        self.proximityCode = proximityCode
        self.irregularLotCode = irregularLotCode
        self.lotType = lotType
        self.basementCode = basementCode
        self.assessedLand = assessedLand
        self.assessedTotal = assessedTotal
        self.exemptLand = exemptLand
        self.exemptTotal = exemptTotal
        self.yearAlter1 = yearAlter1
        self.yearAlter2 = yearAlter2
        self.landmark = landmark
        self.buildingFar = buildingFar
        self.residentialFar = residentialFar
        self.commercialFar = commercialFar
        self.facilityFar = facilityFar
        self.boroCode = boroCode
        self.condoNumber = condoNumber
        self.sanbornMap = sanbornMap
        self.edesignNum = edesignNum
        self.apportionmentDate = apportionmentDate
        self.plutoMapId = plutoMapId
        self.version = version
        self.crossStreets = crossStreets
        self.flipTax = flipTax
        self.expectedDTI = expectedDTI
        self.residentialUnits = residentialUnits
        self.condoUnits = condoUnits
        self.blockAndLot = blockAndLot
        self.bin = bin
        self.borough = borough
        self.sanitationSub = sanitationSub
        self.zoneDist1 = zoneDist1
        self.zoneDist2 = zoneDist2
        self.zoneDist3 = zoneDist3
        self.zoneDist4 = zoneDist4
        self.spDist1 = spDist1
        self.spDist2 = spDist2
        self.spDist3 = spDist3
        self.splitZone = splitZone
        self.storageArea = storageArea
        self.tract2010 = tract2010
        self.xCoord = xCoord
        self.yCoord = yCoord
        self.zoneMap = zoneMap
        self.zmCode = zmCode
        self.taxMap = taxMap
        self.firm07Flag = firm07Flag
        self.pfirm15Flag = pfirm15Flag
        self.mapPlutoF = mapPlutoF
        self.rpadDate = rpadDate
        self.dcasDate = dcasDate
        self.zoningDate = zoningDate
        self.landmkDate = landmkDate
        self.basempDate = basempDate
        self.masDate = masDate
        self.poliDate = poliDate
        self.edesigDate = edesigDate
        self.geom = geom
        self.petPolicy = petPolicy
        self.buildingType = buildingType
        self.dogsAllowed = dogsAllowed
        self.catsAllowed = catsAllowed
        self.taxAbatements = taxAbatements
        self.leedCertified = leedCertified
        self.detailPolicies = detailPolicies
        self.financialPolicy = financialPolicy
        self.boardRequirements = boardRequirements
        self.primaryPropertyType = primaryPropertyType
        self.petPolicyDetail = petPolicyDetail
        self.buildingSize = buildingSize
        self.parkingType = parkingType
        self.parkingDetail = parkingDetail
        self.parkingOnSite = parkingOnSite
        self.parkingOwnership = parkingOwnership
        self.garageOnSite = garageOnSite
        self.parking = parking
        self.maxPetWeight = maxPetWeight
        self.detailPoliciesToExclude = detailPoliciesToExclude
        self.unitType = unitType
        self.unitCount = unitCount

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I32:
                    self.floors = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I32:
                    self.units = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I32:
                    self.yearBuilt = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.name = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.age = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.STRING:
                    self.buildingClass = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRING:
                    self.description = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.submittedDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.I64:
                    self.effectiveDate = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.coopRules = []
                    (_etype10, _size13) = iprot.readListBegin()
                    for _i11 in range(_size13):
                        _elem12 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.coopRules.append(_elem12)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.serviceLevel = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRING:
                    self.access = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRING:
                    self.proposedOffering = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.DOUBLE:
                    self.totalSelloutPrice = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRING:
                    self.offeringPlan = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.certificateOccupancy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.exposures = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.wallPolicy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.I32:
                    self.block = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.I32:
                    self.taxLot = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.STRING:
                    self.censusBlock = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.STRING:
                    self.censusTract = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRING:
                    self.fireCompany = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.I32:
                    self.policePrecinct = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.I32:
                    self.healthArea = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.I32:
                    self.sanitationBoro = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.overlayOne = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 28:
                if ftype == TType.STRING:
                    self.overlayTwo = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRING:
                    self.limitedHeight = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.STRING:
                    self.landUse = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.I32:
                    self.easements = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.DOUBLE:
                    self.buildingArea = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.I64:
                    self.commercialArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.I64:
                    self.residentialArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.I64:
                    self.officeArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.I64:
                    self.retailArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.I64:
                    self.garageArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.I64:
                    self.factoryArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.I64:
                    self.otherArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.STRING:
                    self.areaSourceCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.I32:
                    self.numBuildings = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.STRING:
                    self.extensionCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.I32:
                    self.proximityCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.STRING:
                    self.irregularLotCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.STRING:
                    self.lotType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.STRING:
                    self.basementCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.DOUBLE:
                    self.assessedLand = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.DOUBLE:
                    self.assessedTotal = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.I64:
                    self.exemptLand = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.I64:
                    self.exemptTotal = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.I32:
                    self.yearAlter1 = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.I32:
                    self.yearAlter2 = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.STRING:
                    self.landmark = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.DOUBLE:
                    self.buildingFar = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.DOUBLE:
                    self.residentialFar = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.DOUBLE:
                    self.commercialFar = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.DOUBLE:
                    self.facilityFar = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.I32:
                    self.boroCode = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.I32:
                    self.condoNumber = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.STRING:
                    self.sanbornMap = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.STRING:
                    self.edesignNum = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 62:
                if ftype == TType.STRING:
                    self.apportionmentDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 63:
                if ftype == TType.I32:
                    self.plutoMapId = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 64:
                if ftype == TType.STRING:
                    self.version = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 65:
                if ftype == TType.STRING:
                    self.crossStreets = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 66:
                if ftype == TType.DOUBLE:
                    self.flipTax = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 67:
                if ftype == TType.DOUBLE:
                    self.expectedDTI = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 68:
                if ftype == TType.I32:
                    self.residentialUnits = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 69:
                if ftype == TType.I32:
                    self.condoUnits = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 70:
                if ftype == TType.STRING:
                    self.blockAndLot = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 71:
                if ftype == TType.I64:
                    self.bin = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 72:
                if ftype == TType.STRING:
                    self.borough = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 73:
                if ftype == TType.STRING:
                    self.sanitationSub = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 74:
                if ftype == TType.STRING:
                    self.zoneDist1 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 75:
                if ftype == TType.STRING:
                    self.zoneDist2 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 76:
                if ftype == TType.STRING:
                    self.zoneDist3 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 77:
                if ftype == TType.STRING:
                    self.zoneDist4 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 78:
                if ftype == TType.STRING:
                    self.spDist1 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 79:
                if ftype == TType.STRING:
                    self.spDist2 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 80:
                if ftype == TType.STRING:
                    self.spDist3 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 81:
                if ftype == TType.BOOL:
                    self.splitZone = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 82:
                if ftype == TType.I64:
                    self.storageArea = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 83:
                if ftype == TType.STRING:
                    self.tract2010 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 84:
                if ftype == TType.I64:
                    self.xCoord = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 85:
                if ftype == TType.I64:
                    self.yCoord = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 86:
                if ftype == TType.STRING:
                    self.zoneMap = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 87:
                if ftype == TType.STRING:
                    self.zmCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 88:
                if ftype == TType.STRING:
                    self.taxMap = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 89:
                if ftype == TType.STRING:
                    self.firm07Flag = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 90:
                if ftype == TType.STRING:
                    self.pfirm15Flag = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 91:
                if ftype == TType.STRING:
                    self.mapPlutoF = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 92:
                if ftype == TType.STRING:
                    self.rpadDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 93:
                if ftype == TType.STRING:
                    self.dcasDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 94:
                if ftype == TType.STRING:
                    self.zoningDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 95:
                if ftype == TType.STRING:
                    self.landmkDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 96:
                if ftype == TType.STRING:
                    self.basempDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 97:
                if ftype == TType.STRING:
                    self.masDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 98:
                if ftype == TType.STRING:
                    self.poliDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 99:
                if ftype == TType.STRING:
                    self.edesigDate = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 100:
                if ftype == TType.STRING:
                    self.geom = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 101:
                if ftype == TType.STRING:
                    self.petPolicy = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 102:
                if ftype == TType.STRING:
                    self.buildingType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 103:
                if ftype == TType.BOOL:
                    self.dogsAllowed = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 104:
                if ftype == TType.BOOL:
                    self.catsAllowed = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 105:
                if ftype == TType.STRUCT:
                    self.taxAbatements = TaxAbatements()
                    self.taxAbatements.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 106:
                if ftype == TType.I32:
                    self.leedCertified = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 107:
                if ftype == TType.MAP:
                    self.detailPolicies = {}
                    (_ktype15, _vtype16, _size19) = iprot.readMapBegin()
                    for _i14 in range(_size19):
                        _key17 = iprot.readI32()
                        _val18 = DetailPolicy()
                        _val18.read(iprot)
                        self.detailPolicies[_key17] = _val18
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 108:
                if ftype == TType.STRUCT:
                    self.financialPolicy = FinancialPolicy()
                    self.financialPolicy.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 109:
                if ftype == TType.STRING:
                    self.boardRequirements = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 110:
                if ftype == TType.I32:
                    self.primaryPropertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 111:
                if ftype == TType.STRING:
                    self.petPolicyDetail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 112:
                if ftype == TType.STRING:
                    self.buildingSize = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 113:
                if ftype == TType.STRING:
                    self.parkingType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 114:
                if ftype == TType.STRING:
                    self.parkingDetail = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 115:
                if ftype == TType.BOOL:
                    self.parkingOnSite = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 117:
                if ftype == TType.STRING:
                    self.parkingOwnership = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 118:
                if ftype == TType.BOOL:
                    self.garageOnSite = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 119:
                if ftype == TType.STRING:
                    self.parking = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 120:
                if ftype == TType.DOUBLE:
                    self.maxPetWeight = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 121:
                if ftype == TType.SET:
                    self.detailPoliciesToExclude = set()
                    (_etype21, _size23) = iprot.readSetBegin()
                    for _i20 in range(_size23):
                        _elem22 = iprot.readI32()
                        self.detailPoliciesToExclude.add(_elem22)
                    iprot.readSetEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 122:
                if ftype == TType.STRING:
                    self.unitType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 123:
                if ftype == TType.I32:
                    self.unitCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BuildingDetails')
        if self.floors is not None:
            oprot.writeFieldBegin('floors', TType.I32, 1)
            oprot.writeI32(self.floors)
            oprot.writeFieldEnd()
        if self.units is not None:
            oprot.writeFieldBegin('units', TType.I32, 2)
            oprot.writeI32(self.units)
            oprot.writeFieldEnd()
        if self.yearBuilt is not None:
            oprot.writeFieldBegin('yearBuilt', TType.I32, 3)
            oprot.writeI32(self.yearBuilt)
            oprot.writeFieldEnd()
        if self.name is not None:
            oprot.writeFieldBegin('name', TType.STRING, 4)
            oprot.writeString(self.name.encode('utf-8') if sys.version_info[0] == 2 else self.name)
            oprot.writeFieldEnd()
        if self.age is not None:
            oprot.writeFieldBegin('age', TType.STRING, 5)
            oprot.writeString(self.age.encode('utf-8') if sys.version_info[0] == 2 else self.age)
            oprot.writeFieldEnd()
        if self.buildingClass is not None:
            oprot.writeFieldBegin('buildingClass', TType.STRING, 6)
            oprot.writeString(self.buildingClass.encode('utf-8') if sys.version_info[0] == 2 else self.buildingClass)
            oprot.writeFieldEnd()
        if self.description is not None:
            oprot.writeFieldBegin('description', TType.STRING, 7)
            oprot.writeString(self.description.encode('utf-8') if sys.version_info[0] == 2 else self.description)
            oprot.writeFieldEnd()
        if self.submittedDate is not None:
            oprot.writeFieldBegin('submittedDate', TType.I64, 8)
            oprot.writeI64(self.submittedDate)
            oprot.writeFieldEnd()
        if self.effectiveDate is not None:
            oprot.writeFieldBegin('effectiveDate', TType.I64, 9)
            oprot.writeI64(self.effectiveDate)
            oprot.writeFieldEnd()
        if self.coopRules is not None:
            oprot.writeFieldBegin('coopRules', TType.LIST, 10)
            oprot.writeListBegin(TType.STRING, len(self.coopRules))
            for _iter24 in self.coopRules:
                oprot.writeString(_iter24.encode('utf-8') if sys.version_info[0] == 2 else _iter24)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.serviceLevel is not None:
            oprot.writeFieldBegin('serviceLevel', TType.STRING, 11)
            oprot.writeString(self.serviceLevel.encode('utf-8') if sys.version_info[0] == 2 else self.serviceLevel)
            oprot.writeFieldEnd()
        if self.access is not None:
            oprot.writeFieldBegin('access', TType.STRING, 12)
            oprot.writeString(self.access.encode('utf-8') if sys.version_info[0] == 2 else self.access)
            oprot.writeFieldEnd()
        if self.proposedOffering is not None:
            oprot.writeFieldBegin('proposedOffering', TType.STRING, 13)
            oprot.writeString(self.proposedOffering.encode('utf-8') if sys.version_info[0] == 2 else self.proposedOffering)
            oprot.writeFieldEnd()
        if self.totalSelloutPrice is not None:
            oprot.writeFieldBegin('totalSelloutPrice', TType.DOUBLE, 14)
            oprot.writeDouble(self.totalSelloutPrice)
            oprot.writeFieldEnd()
        if self.offeringPlan is not None:
            oprot.writeFieldBegin('offeringPlan', TType.STRING, 15)
            oprot.writeString(self.offeringPlan.encode('utf-8') if sys.version_info[0] == 2 else self.offeringPlan)
            oprot.writeFieldEnd()
        if self.certificateOccupancy is not None:
            oprot.writeFieldBegin('certificateOccupancy', TType.STRING, 16)
            oprot.writeString(self.certificateOccupancy.encode('utf-8') if sys.version_info[0] == 2 else self.certificateOccupancy)
            oprot.writeFieldEnd()
        if self.exposures is not None:
            oprot.writeFieldBegin('exposures', TType.STRING, 17)
            oprot.writeString(self.exposures.encode('utf-8') if sys.version_info[0] == 2 else self.exposures)
            oprot.writeFieldEnd()
        if self.wallPolicy is not None:
            oprot.writeFieldBegin('wallPolicy', TType.STRING, 18)
            oprot.writeString(self.wallPolicy.encode('utf-8') if sys.version_info[0] == 2 else self.wallPolicy)
            oprot.writeFieldEnd()
        if self.block is not None:
            oprot.writeFieldBegin('block', TType.I32, 19)
            oprot.writeI32(self.block)
            oprot.writeFieldEnd()
        if self.taxLot is not None:
            oprot.writeFieldBegin('taxLot', TType.I32, 20)
            oprot.writeI32(self.taxLot)
            oprot.writeFieldEnd()
        if self.censusBlock is not None:
            oprot.writeFieldBegin('censusBlock', TType.STRING, 21)
            oprot.writeString(self.censusBlock.encode('utf-8') if sys.version_info[0] == 2 else self.censusBlock)
            oprot.writeFieldEnd()
        if self.censusTract is not None:
            oprot.writeFieldBegin('censusTract', TType.STRING, 22)
            oprot.writeString(self.censusTract.encode('utf-8') if sys.version_info[0] == 2 else self.censusTract)
            oprot.writeFieldEnd()
        if self.fireCompany is not None:
            oprot.writeFieldBegin('fireCompany', TType.STRING, 23)
            oprot.writeString(self.fireCompany.encode('utf-8') if sys.version_info[0] == 2 else self.fireCompany)
            oprot.writeFieldEnd()
        if self.policePrecinct is not None:
            oprot.writeFieldBegin('policePrecinct', TType.I32, 24)
            oprot.writeI32(self.policePrecinct)
            oprot.writeFieldEnd()
        if self.healthArea is not None:
            oprot.writeFieldBegin('healthArea', TType.I32, 25)
            oprot.writeI32(self.healthArea)
            oprot.writeFieldEnd()
        if self.sanitationBoro is not None:
            oprot.writeFieldBegin('sanitationBoro', TType.I32, 26)
            oprot.writeI32(self.sanitationBoro)
            oprot.writeFieldEnd()
        if self.overlayOne is not None:
            oprot.writeFieldBegin('overlayOne', TType.STRING, 27)
            oprot.writeString(self.overlayOne.encode('utf-8') if sys.version_info[0] == 2 else self.overlayOne)
            oprot.writeFieldEnd()
        if self.overlayTwo is not None:
            oprot.writeFieldBegin('overlayTwo', TType.STRING, 28)
            oprot.writeString(self.overlayTwo.encode('utf-8') if sys.version_info[0] == 2 else self.overlayTwo)
            oprot.writeFieldEnd()
        if self.limitedHeight is not None:
            oprot.writeFieldBegin('limitedHeight', TType.STRING, 29)
            oprot.writeString(self.limitedHeight.encode('utf-8') if sys.version_info[0] == 2 else self.limitedHeight)
            oprot.writeFieldEnd()
        if self.landUse is not None:
            oprot.writeFieldBegin('landUse', TType.STRING, 30)
            oprot.writeString(self.landUse.encode('utf-8') if sys.version_info[0] == 2 else self.landUse)
            oprot.writeFieldEnd()
        if self.easements is not None:
            oprot.writeFieldBegin('easements', TType.I32, 31)
            oprot.writeI32(self.easements)
            oprot.writeFieldEnd()
        if self.buildingArea is not None:
            oprot.writeFieldBegin('buildingArea', TType.DOUBLE, 32)
            oprot.writeDouble(self.buildingArea)
            oprot.writeFieldEnd()
        if self.commercialArea is not None:
            oprot.writeFieldBegin('commercialArea', TType.I64, 33)
            oprot.writeI64(self.commercialArea)
            oprot.writeFieldEnd()
        if self.residentialArea is not None:
            oprot.writeFieldBegin('residentialArea', TType.I64, 34)
            oprot.writeI64(self.residentialArea)
            oprot.writeFieldEnd()
        if self.officeArea is not None:
            oprot.writeFieldBegin('officeArea', TType.I64, 35)
            oprot.writeI64(self.officeArea)
            oprot.writeFieldEnd()
        if self.retailArea is not None:
            oprot.writeFieldBegin('retailArea', TType.I64, 36)
            oprot.writeI64(self.retailArea)
            oprot.writeFieldEnd()
        if self.garageArea is not None:
            oprot.writeFieldBegin('garageArea', TType.I64, 37)
            oprot.writeI64(self.garageArea)
            oprot.writeFieldEnd()
        if self.factoryArea is not None:
            oprot.writeFieldBegin('factoryArea', TType.I64, 38)
            oprot.writeI64(self.factoryArea)
            oprot.writeFieldEnd()
        if self.otherArea is not None:
            oprot.writeFieldBegin('otherArea', TType.I64, 39)
            oprot.writeI64(self.otherArea)
            oprot.writeFieldEnd()
        if self.areaSourceCode is not None:
            oprot.writeFieldBegin('areaSourceCode', TType.STRING, 40)
            oprot.writeString(self.areaSourceCode.encode('utf-8') if sys.version_info[0] == 2 else self.areaSourceCode)
            oprot.writeFieldEnd()
        if self.numBuildings is not None:
            oprot.writeFieldBegin('numBuildings', TType.I32, 41)
            oprot.writeI32(self.numBuildings)
            oprot.writeFieldEnd()
        if self.extensionCode is not None:
            oprot.writeFieldBegin('extensionCode', TType.STRING, 42)
            oprot.writeString(self.extensionCode.encode('utf-8') if sys.version_info[0] == 2 else self.extensionCode)
            oprot.writeFieldEnd()
        if self.proximityCode is not None:
            oprot.writeFieldBegin('proximityCode', TType.I32, 43)
            oprot.writeI32(self.proximityCode)
            oprot.writeFieldEnd()
        if self.irregularLotCode is not None:
            oprot.writeFieldBegin('irregularLotCode', TType.STRING, 44)
            oprot.writeString(self.irregularLotCode.encode('utf-8') if sys.version_info[0] == 2 else self.irregularLotCode)
            oprot.writeFieldEnd()
        if self.lotType is not None:
            oprot.writeFieldBegin('lotType', TType.STRING, 45)
            oprot.writeString(self.lotType.encode('utf-8') if sys.version_info[0] == 2 else self.lotType)
            oprot.writeFieldEnd()
        if self.basementCode is not None:
            oprot.writeFieldBegin('basementCode', TType.STRING, 46)
            oprot.writeString(self.basementCode.encode('utf-8') if sys.version_info[0] == 2 else self.basementCode)
            oprot.writeFieldEnd()
        if self.assessedLand is not None:
            oprot.writeFieldBegin('assessedLand', TType.DOUBLE, 47)
            oprot.writeDouble(self.assessedLand)
            oprot.writeFieldEnd()
        if self.assessedTotal is not None:
            oprot.writeFieldBegin('assessedTotal', TType.DOUBLE, 48)
            oprot.writeDouble(self.assessedTotal)
            oprot.writeFieldEnd()
        if self.exemptLand is not None:
            oprot.writeFieldBegin('exemptLand', TType.I64, 49)
            oprot.writeI64(self.exemptLand)
            oprot.writeFieldEnd()
        if self.exemptTotal is not None:
            oprot.writeFieldBegin('exemptTotal', TType.I64, 50)
            oprot.writeI64(self.exemptTotal)
            oprot.writeFieldEnd()
        if self.yearAlter1 is not None:
            oprot.writeFieldBegin('yearAlter1', TType.I32, 51)
            oprot.writeI32(self.yearAlter1)
            oprot.writeFieldEnd()
        if self.yearAlter2 is not None:
            oprot.writeFieldBegin('yearAlter2', TType.I32, 52)
            oprot.writeI32(self.yearAlter2)
            oprot.writeFieldEnd()
        if self.landmark is not None:
            oprot.writeFieldBegin('landmark', TType.STRING, 53)
            oprot.writeString(self.landmark.encode('utf-8') if sys.version_info[0] == 2 else self.landmark)
            oprot.writeFieldEnd()
        if self.buildingFar is not None:
            oprot.writeFieldBegin('buildingFar', TType.DOUBLE, 54)
            oprot.writeDouble(self.buildingFar)
            oprot.writeFieldEnd()
        if self.residentialFar is not None:
            oprot.writeFieldBegin('residentialFar', TType.DOUBLE, 55)
            oprot.writeDouble(self.residentialFar)
            oprot.writeFieldEnd()
        if self.commercialFar is not None:
            oprot.writeFieldBegin('commercialFar', TType.DOUBLE, 56)
            oprot.writeDouble(self.commercialFar)
            oprot.writeFieldEnd()
        if self.facilityFar is not None:
            oprot.writeFieldBegin('facilityFar', TType.DOUBLE, 57)
            oprot.writeDouble(self.facilityFar)
            oprot.writeFieldEnd()
        if self.boroCode is not None:
            oprot.writeFieldBegin('boroCode', TType.I32, 58)
            oprot.writeI32(self.boroCode)
            oprot.writeFieldEnd()
        if self.condoNumber is not None:
            oprot.writeFieldBegin('condoNumber', TType.I32, 59)
            oprot.writeI32(self.condoNumber)
            oprot.writeFieldEnd()
        if self.sanbornMap is not None:
            oprot.writeFieldBegin('sanbornMap', TType.STRING, 60)
            oprot.writeString(self.sanbornMap.encode('utf-8') if sys.version_info[0] == 2 else self.sanbornMap)
            oprot.writeFieldEnd()
        if self.edesignNum is not None:
            oprot.writeFieldBegin('edesignNum', TType.STRING, 61)
            oprot.writeString(self.edesignNum.encode('utf-8') if sys.version_info[0] == 2 else self.edesignNum)
            oprot.writeFieldEnd()
        if self.apportionmentDate is not None:
            oprot.writeFieldBegin('apportionmentDate', TType.STRING, 62)
            oprot.writeString(self.apportionmentDate.encode('utf-8') if sys.version_info[0] == 2 else self.apportionmentDate)
            oprot.writeFieldEnd()
        if self.plutoMapId is not None:
            oprot.writeFieldBegin('plutoMapId', TType.I32, 63)
            oprot.writeI32(self.plutoMapId)
            oprot.writeFieldEnd()
        if self.version is not None:
            oprot.writeFieldBegin('version', TType.STRING, 64)
            oprot.writeString(self.version.encode('utf-8') if sys.version_info[0] == 2 else self.version)
            oprot.writeFieldEnd()
        if self.crossStreets is not None:
            oprot.writeFieldBegin('crossStreets', TType.STRING, 65)
            oprot.writeString(self.crossStreets.encode('utf-8') if sys.version_info[0] == 2 else self.crossStreets)
            oprot.writeFieldEnd()
        if self.flipTax is not None:
            oprot.writeFieldBegin('flipTax', TType.DOUBLE, 66)
            oprot.writeDouble(self.flipTax)
            oprot.writeFieldEnd()
        if self.expectedDTI is not None:
            oprot.writeFieldBegin('expectedDTI', TType.DOUBLE, 67)
            oprot.writeDouble(self.expectedDTI)
            oprot.writeFieldEnd()
        if self.residentialUnits is not None:
            oprot.writeFieldBegin('residentialUnits', TType.I32, 68)
            oprot.writeI32(self.residentialUnits)
            oprot.writeFieldEnd()
        if self.condoUnits is not None:
            oprot.writeFieldBegin('condoUnits', TType.I32, 69)
            oprot.writeI32(self.condoUnits)
            oprot.writeFieldEnd()
        if self.blockAndLot is not None:
            oprot.writeFieldBegin('blockAndLot', TType.STRING, 70)
            oprot.writeString(self.blockAndLot.encode('utf-8') if sys.version_info[0] == 2 else self.blockAndLot)
            oprot.writeFieldEnd()
        if self.bin is not None:
            oprot.writeFieldBegin('bin', TType.I64, 71)
            oprot.writeI64(self.bin)
            oprot.writeFieldEnd()
        if self.borough is not None:
            oprot.writeFieldBegin('borough', TType.STRING, 72)
            oprot.writeString(self.borough.encode('utf-8') if sys.version_info[0] == 2 else self.borough)
            oprot.writeFieldEnd()
        if self.sanitationSub is not None:
            oprot.writeFieldBegin('sanitationSub', TType.STRING, 73)
            oprot.writeString(self.sanitationSub.encode('utf-8') if sys.version_info[0] == 2 else self.sanitationSub)
            oprot.writeFieldEnd()
        if self.zoneDist1 is not None:
            oprot.writeFieldBegin('zoneDist1', TType.STRING, 74)
            oprot.writeString(self.zoneDist1.encode('utf-8') if sys.version_info[0] == 2 else self.zoneDist1)
            oprot.writeFieldEnd()
        if self.zoneDist2 is not None:
            oprot.writeFieldBegin('zoneDist2', TType.STRING, 75)
            oprot.writeString(self.zoneDist2.encode('utf-8') if sys.version_info[0] == 2 else self.zoneDist2)
            oprot.writeFieldEnd()
        if self.zoneDist3 is not None:
            oprot.writeFieldBegin('zoneDist3', TType.STRING, 76)
            oprot.writeString(self.zoneDist3.encode('utf-8') if sys.version_info[0] == 2 else self.zoneDist3)
            oprot.writeFieldEnd()
        if self.zoneDist4 is not None:
            oprot.writeFieldBegin('zoneDist4', TType.STRING, 77)
            oprot.writeString(self.zoneDist4.encode('utf-8') if sys.version_info[0] == 2 else self.zoneDist4)
            oprot.writeFieldEnd()
        if self.spDist1 is not None:
            oprot.writeFieldBegin('spDist1', TType.STRING, 78)
            oprot.writeString(self.spDist1.encode('utf-8') if sys.version_info[0] == 2 else self.spDist1)
            oprot.writeFieldEnd()
        if self.spDist2 is not None:
            oprot.writeFieldBegin('spDist2', TType.STRING, 79)
            oprot.writeString(self.spDist2.encode('utf-8') if sys.version_info[0] == 2 else self.spDist2)
            oprot.writeFieldEnd()
        if self.spDist3 is not None:
            oprot.writeFieldBegin('spDist3', TType.STRING, 80)
            oprot.writeString(self.spDist3.encode('utf-8') if sys.version_info[0] == 2 else self.spDist3)
            oprot.writeFieldEnd()
        if self.splitZone is not None:
            oprot.writeFieldBegin('splitZone', TType.BOOL, 81)
            oprot.writeBool(self.splitZone)
            oprot.writeFieldEnd()
        if self.storageArea is not None:
            oprot.writeFieldBegin('storageArea', TType.I64, 82)
            oprot.writeI64(self.storageArea)
            oprot.writeFieldEnd()
        if self.tract2010 is not None:
            oprot.writeFieldBegin('tract2010', TType.STRING, 83)
            oprot.writeString(self.tract2010.encode('utf-8') if sys.version_info[0] == 2 else self.tract2010)
            oprot.writeFieldEnd()
        if self.xCoord is not None:
            oprot.writeFieldBegin('xCoord', TType.I64, 84)
            oprot.writeI64(self.xCoord)
            oprot.writeFieldEnd()
        if self.yCoord is not None:
            oprot.writeFieldBegin('yCoord', TType.I64, 85)
            oprot.writeI64(self.yCoord)
            oprot.writeFieldEnd()
        if self.zoneMap is not None:
            oprot.writeFieldBegin('zoneMap', TType.STRING, 86)
            oprot.writeString(self.zoneMap.encode('utf-8') if sys.version_info[0] == 2 else self.zoneMap)
            oprot.writeFieldEnd()
        if self.zmCode is not None:
            oprot.writeFieldBegin('zmCode', TType.STRING, 87)
            oprot.writeString(self.zmCode.encode('utf-8') if sys.version_info[0] == 2 else self.zmCode)
            oprot.writeFieldEnd()
        if self.taxMap is not None:
            oprot.writeFieldBegin('taxMap', TType.STRING, 88)
            oprot.writeString(self.taxMap.encode('utf-8') if sys.version_info[0] == 2 else self.taxMap)
            oprot.writeFieldEnd()
        if self.firm07Flag is not None:
            oprot.writeFieldBegin('firm07Flag', TType.STRING, 89)
            oprot.writeString(self.firm07Flag.encode('utf-8') if sys.version_info[0] == 2 else self.firm07Flag)
            oprot.writeFieldEnd()
        if self.pfirm15Flag is not None:
            oprot.writeFieldBegin('pfirm15Flag', TType.STRING, 90)
            oprot.writeString(self.pfirm15Flag.encode('utf-8') if sys.version_info[0] == 2 else self.pfirm15Flag)
            oprot.writeFieldEnd()
        if self.mapPlutoF is not None:
            oprot.writeFieldBegin('mapPlutoF', TType.STRING, 91)
            oprot.writeString(self.mapPlutoF.encode('utf-8') if sys.version_info[0] == 2 else self.mapPlutoF)
            oprot.writeFieldEnd()
        if self.rpadDate is not None:
            oprot.writeFieldBegin('rpadDate', TType.STRING, 92)
            oprot.writeString(self.rpadDate.encode('utf-8') if sys.version_info[0] == 2 else self.rpadDate)
            oprot.writeFieldEnd()
        if self.dcasDate is not None:
            oprot.writeFieldBegin('dcasDate', TType.STRING, 93)
            oprot.writeString(self.dcasDate.encode('utf-8') if sys.version_info[0] == 2 else self.dcasDate)
            oprot.writeFieldEnd()
        if self.zoningDate is not None:
            oprot.writeFieldBegin('zoningDate', TType.STRING, 94)
            oprot.writeString(self.zoningDate.encode('utf-8') if sys.version_info[0] == 2 else self.zoningDate)
            oprot.writeFieldEnd()
        if self.landmkDate is not None:
            oprot.writeFieldBegin('landmkDate', TType.STRING, 95)
            oprot.writeString(self.landmkDate.encode('utf-8') if sys.version_info[0] == 2 else self.landmkDate)
            oprot.writeFieldEnd()
        if self.basempDate is not None:
            oprot.writeFieldBegin('basempDate', TType.STRING, 96)
            oprot.writeString(self.basempDate.encode('utf-8') if sys.version_info[0] == 2 else self.basempDate)
            oprot.writeFieldEnd()
        if self.masDate is not None:
            oprot.writeFieldBegin('masDate', TType.STRING, 97)
            oprot.writeString(self.masDate.encode('utf-8') if sys.version_info[0] == 2 else self.masDate)
            oprot.writeFieldEnd()
        if self.poliDate is not None:
            oprot.writeFieldBegin('poliDate', TType.STRING, 98)
            oprot.writeString(self.poliDate.encode('utf-8') if sys.version_info[0] == 2 else self.poliDate)
            oprot.writeFieldEnd()
        if self.edesigDate is not None:
            oprot.writeFieldBegin('edesigDate', TType.STRING, 99)
            oprot.writeString(self.edesigDate.encode('utf-8') if sys.version_info[0] == 2 else self.edesigDate)
            oprot.writeFieldEnd()
        if self.geom is not None:
            oprot.writeFieldBegin('geom', TType.STRING, 100)
            oprot.writeString(self.geom.encode('utf-8') if sys.version_info[0] == 2 else self.geom)
            oprot.writeFieldEnd()
        if self.petPolicy is not None:
            oprot.writeFieldBegin('petPolicy', TType.STRING, 101)
            oprot.writeString(self.petPolicy.encode('utf-8') if sys.version_info[0] == 2 else self.petPolicy)
            oprot.writeFieldEnd()
        if self.buildingType is not None:
            oprot.writeFieldBegin('buildingType', TType.STRING, 102)
            oprot.writeString(self.buildingType.encode('utf-8') if sys.version_info[0] == 2 else self.buildingType)
            oprot.writeFieldEnd()
        if self.dogsAllowed is not None:
            oprot.writeFieldBegin('dogsAllowed', TType.BOOL, 103)
            oprot.writeBool(self.dogsAllowed)
            oprot.writeFieldEnd()
        if self.catsAllowed is not None:
            oprot.writeFieldBegin('catsAllowed', TType.BOOL, 104)
            oprot.writeBool(self.catsAllowed)
            oprot.writeFieldEnd()
        if self.taxAbatements is not None:
            oprot.writeFieldBegin('taxAbatements', TType.STRUCT, 105)
            self.taxAbatements.write(oprot)
            oprot.writeFieldEnd()
        if self.leedCertified is not None:
            oprot.writeFieldBegin('leedCertified', TType.I32, 106)
            oprot.writeI32(self.leedCertified)
            oprot.writeFieldEnd()
        if self.detailPolicies is not None:
            oprot.writeFieldBegin('detailPolicies', TType.MAP, 107)
            oprot.writeMapBegin(TType.I32, TType.STRUCT, len(self.detailPolicies))
            for _kiter25, _viter26 in self.detailPolicies.items():
                oprot.writeI32(_kiter25)
                _viter26.write(oprot)
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.financialPolicy is not None:
            oprot.writeFieldBegin('financialPolicy', TType.STRUCT, 108)
            self.financialPolicy.write(oprot)
            oprot.writeFieldEnd()
        if self.boardRequirements is not None:
            oprot.writeFieldBegin('boardRequirements', TType.STRING, 109)
            oprot.writeString(self.boardRequirements.encode('utf-8') if sys.version_info[0] == 2 else self.boardRequirements)
            oprot.writeFieldEnd()
        if self.primaryPropertyType is not None:
            oprot.writeFieldBegin('primaryPropertyType', TType.I32, 110)
            oprot.writeI32(self.primaryPropertyType)
            oprot.writeFieldEnd()
        if self.petPolicyDetail is not None:
            oprot.writeFieldBegin('petPolicyDetail', TType.STRING, 111)
            oprot.writeString(self.petPolicyDetail.encode('utf-8') if sys.version_info[0] == 2 else self.petPolicyDetail)
            oprot.writeFieldEnd()
        if self.buildingSize is not None:
            oprot.writeFieldBegin('buildingSize', TType.STRING, 112)
            oprot.writeString(self.buildingSize.encode('utf-8') if sys.version_info[0] == 2 else self.buildingSize)
            oprot.writeFieldEnd()
        if self.parkingType is not None:
            oprot.writeFieldBegin('parkingType', TType.STRING, 113)
            oprot.writeString(self.parkingType.encode('utf-8') if sys.version_info[0] == 2 else self.parkingType)
            oprot.writeFieldEnd()
        if self.parkingDetail is not None:
            oprot.writeFieldBegin('parkingDetail', TType.STRING, 114)
            oprot.writeString(self.parkingDetail.encode('utf-8') if sys.version_info[0] == 2 else self.parkingDetail)
            oprot.writeFieldEnd()
        if self.parkingOnSite is not None:
            oprot.writeFieldBegin('parkingOnSite', TType.BOOL, 115)
            oprot.writeBool(self.parkingOnSite)
            oprot.writeFieldEnd()
        if self.parkingOwnership is not None:
            oprot.writeFieldBegin('parkingOwnership', TType.STRING, 117)
            oprot.writeString(self.parkingOwnership.encode('utf-8') if sys.version_info[0] == 2 else self.parkingOwnership)
            oprot.writeFieldEnd()
        if self.garageOnSite is not None:
            oprot.writeFieldBegin('garageOnSite', TType.BOOL, 118)
            oprot.writeBool(self.garageOnSite)
            oprot.writeFieldEnd()
        if self.parking is not None:
            oprot.writeFieldBegin('parking', TType.STRING, 119)
            oprot.writeString(self.parking.encode('utf-8') if sys.version_info[0] == 2 else self.parking)
            oprot.writeFieldEnd()
        if self.maxPetWeight is not None:
            oprot.writeFieldBegin('maxPetWeight', TType.DOUBLE, 120)
            oprot.writeDouble(self.maxPetWeight)
            oprot.writeFieldEnd()
        if self.detailPoliciesToExclude is not None:
            oprot.writeFieldBegin('detailPoliciesToExclude', TType.SET, 121)
            oprot.writeSetBegin(TType.I32, len(self.detailPoliciesToExclude))
            for _iter27 in self.detailPoliciesToExclude:
                oprot.writeI32(_iter27)
            oprot.writeSetEnd()
            oprot.writeFieldEnd()
        if self.unitType is not None:
            oprot.writeFieldBegin('unitType', TType.STRING, 122)
            oprot.writeString(self.unitType.encode('utf-8') if sys.version_info[0] == 2 else self.unitType)
            oprot.writeFieldEnd()
        if self.unitCount is not None:
            oprot.writeFieldBegin('unitCount', TType.I32, 123)
            oprot.writeI32(self.unitCount)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class SharedListingFields(object):
    """
    Attributes:
     - amenities
     - images
     - syndicatedInfos
     - contactsInfo
     - contactsInfoToExclude
     - floorplanImages
     - nonImageMedia
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'amenities', (TType.STRING, 'UTF8', False), None, ),  # 1
        (2, TType.LIST, 'images', (TType.STRUCT, (gen.urbancompass.image.ttypes.ImageInfo, gen.urbancompass.image.ttypes.ImageInfo.thrift_spec), False), None, ),  # 2
        (3, TType.STRUCT, 'syndicatedInfos', (gen.urbancompass.listing.listing.ttypes.SyndicationInfos, gen.urbancompass.listing.listing.ttypes.SyndicationInfos.thrift_spec), None, ),  # 3
        (4, TType.LIST, 'contactsInfo', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 4
        (5, TType.LIST, 'contactsInfoToExclude', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 5
        (6, TType.LIST, 'floorplanImages', (TType.STRUCT, (FloorPlanImage, FloorPlanImage.thrift_spec), False), None, ),  # 6
        (7, TType.LIST, 'nonImageMedia', (TType.STRUCT, (gen.urbancompass.image.non_image_media.ttypes.MediaInfo, gen.urbancompass.image.non_image_media.ttypes.MediaInfo.thrift_spec), False), None, ),  # 7
    )
    def __init__(self, amenities=None, images=None, syndicatedInfos=None, contactsInfo=None, contactsInfoToExclude=None, floorplanImages=None, nonImageMedia=None, ):
        self.amenities = amenities
        self.images = images
        self.syndicatedInfos = syndicatedInfos
        self.contactsInfo = contactsInfo
        self.contactsInfoToExclude = contactsInfoToExclude
        self.floorplanImages = floorplanImages
        self.nonImageMedia = nonImageMedia

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.amenities = []
                    (_etype28, _size31) = iprot.readListBegin()
                    for _i29 in range(_size31):
                        _elem30 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.amenities.append(_elem30)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.LIST:
                    self.images = []
                    (_etype32, _size35) = iprot.readListBegin()
                    for _i33 in range(_size35):
                        _elem34 = gen.urbancompass.image.ttypes.ImageInfo()
                        _elem34.read(iprot)
                        self.images.append(_elem34)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRUCT:
                    self.syndicatedInfos = gen.urbancompass.listing.listing.ttypes.SyndicationInfos()
                    self.syndicatedInfos.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.contactsInfo = []
                    (_etype36, _size39) = iprot.readListBegin()
                    for _i37 in range(_size39):
                        _elem38 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem38.read(iprot)
                        self.contactsInfo.append(_elem38)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.LIST:
                    self.contactsInfoToExclude = []
                    (_etype40, _size43) = iprot.readListBegin()
                    for _i41 in range(_size43):
                        _elem42 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem42.read(iprot)
                        self.contactsInfoToExclude.append(_elem42)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.LIST:
                    self.floorplanImages = []
                    (_etype44, _size47) = iprot.readListBegin()
                    for _i45 in range(_size47):
                        _elem46 = FloorPlanImage()
                        _elem46.read(iprot)
                        self.floorplanImages.append(_elem46)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.LIST:
                    self.nonImageMedia = []
                    (_etype48, _size51) = iprot.readListBegin()
                    for _i49 in range(_size51):
                        _elem50 = gen.urbancompass.image.non_image_media.ttypes.MediaInfo()
                        _elem50.read(iprot)
                        self.nonImageMedia.append(_elem50)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('SharedListingFields')
        if self.amenities is not None:
            oprot.writeFieldBegin('amenities', TType.LIST, 1)
            oprot.writeListBegin(TType.STRING, len(self.amenities))
            for _iter52 in self.amenities:
                oprot.writeString(_iter52.encode('utf-8') if sys.version_info[0] == 2 else _iter52)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.images is not None:
            oprot.writeFieldBegin('images', TType.LIST, 2)
            oprot.writeListBegin(TType.STRUCT, len(self.images))
            for _iter53 in self.images:
                _iter53.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.syndicatedInfos is not None:
            oprot.writeFieldBegin('syndicatedInfos', TType.STRUCT, 3)
            self.syndicatedInfos.write(oprot)
            oprot.writeFieldEnd()
        if self.contactsInfo is not None:
            oprot.writeFieldBegin('contactsInfo', TType.LIST, 4)
            oprot.writeListBegin(TType.STRUCT, len(self.contactsInfo))
            for _iter54 in self.contactsInfo:
                _iter54.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.contactsInfoToExclude is not None:
            oprot.writeFieldBegin('contactsInfoToExclude', TType.LIST, 5)
            oprot.writeListBegin(TType.STRUCT, len(self.contactsInfoToExclude))
            for _iter55 in self.contactsInfoToExclude:
                _iter55.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.floorplanImages is not None:
            oprot.writeFieldBegin('floorplanImages', TType.LIST, 6)
            oprot.writeListBegin(TType.STRUCT, len(self.floorplanImages))
            for _iter56 in self.floorplanImages:
                _iter56.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.nonImageMedia is not None:
            oprot.writeFieldBegin('nonImageMedia', TType.LIST, 7)
            oprot.writeListBegin(TType.STRUCT, len(self.nonImageMedia))
            for _iter57 in self.nonImageMedia:
                _iter57.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class Building(object):
    """
    Attributes:
     - _id
     - buildingIdSHA
     - buildingId
     - primaryGovId
     - primaryGovIdType
     - __uc_id_sha__
     - buildingEditorUcIdSha
     - messierBuildingId
     - listingIds
     - contributingSourceFeeds
     - address
     - preDirection
     - streetNumber
     - street
     - streetType
     - postDirection
     - city
     - state
     - zipCode
     - county
     - latitude
     - longitude
     - geoId
     - inputAddress
     - aliasAddresses
     - neighborhoods
     - owners
     - ownersToExclude
     - developers
     - developersToExclude
     - ownership
     - architect
     - managementCompany
     - managementCompanies
     - managementCompaniesToExclude
     - recentLenders
     - recentLendersToExclude
     - details
     - propertyType
     - taxRecords
     - lotDimensions
     - buildingDimensions
     - residentialDimensions
     - districts
     - sharedListingFields
     - amenitiesToExclude
     - editorImagesToExclude
     - externalLinks
     - buildingAgreementType
     - buildingProjectName
     - buildingEditorCreatedAt
     - buildingEditorLastUpdated
     - buildingEditorLastDetailPolicyUpdated
     - aggregatedMessierListingIds
     - rawPlutoCount
     - internalOnlyOlrBuildingInfo
     - provider
     - alternativeCityNames
     - geomObjInfo
     - geolocationResult
     - addressCorrected
     - zipcodeTieBreakApplied
     - newDevelopment
     - propertyId
     - exclusionPathsMap
    """

    thrift_spec = (
        None,  # 0
        (1, TType.STRING, '_id', 'UTF8', None, ),  # 1
        (2, TType.STRING, 'buildingIdSHA', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'buildingId', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'listingIds', (TType.STRING, 'UTF8', False), None, ),  # 4
        None,  # 5
        None,  # 6
        None,  # 7
        (8, TType.LIST, 'owners', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 8
        (9, TType.STRUCT, 'architect', (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), None, ),  # 9
        (10, TType.LIST, 'developers', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 10
        (11, TType.STRING, 'geoId', 'UTF8', None, ),  # 11
        (12, TType.STRUCT, 'propertyType', (gen.urbancompass.property_type.ttypes.PropertyType, gen.urbancompass.property_type.ttypes.PropertyType.thrift_spec), None, ),  # 12
        (13, TType.STRUCT, 'lotDimensions', (Dimensions, Dimensions.thrift_spec), None, ),  # 13
        (14, TType.STRUCT, 'buildingDimensions', (Dimensions, Dimensions.thrift_spec), None, ),  # 14
        (15, TType.STRUCT, 'sharedListingFields', (SharedListingFields, SharedListingFields.thrift_spec), None, ),  # 15
        (16, TType.STRING, 'address', 'UTF8', None, ),  # 16
        (17, TType.STRING, 'city', 'UTF8', None, ),  # 17
        (18, TType.STRING, 'state', 'UTF8', None, ),  # 18
        (19, TType.STRING, 'zipCode', 'UTF8', None, ),  # 19
        (20, TType.DOUBLE, 'latitude', None, None, ),  # 20
        (21, TType.DOUBLE, 'longitude', None, None, ),  # 21
        (22, TType.LIST, 'districts', (TType.STRUCT, (District, District.thrift_spec), False), None, ),  # 22
        (23, TType.STRUCT, 'details', (BuildingDetails, BuildingDetails.thrift_spec), None, ),  # 23
        (24, TType.STRUCT, 'managementCompany', (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), None, ),  # 24
        (25, TType.LIST, 'taxRecords', (TType.STRUCT, (TaxRecord, TaxRecord.thrift_spec), False), None, ),  # 25
        (26, TType.STRUCT, 'residentialDimensions', (Dimensions, Dimensions.thrift_spec), None, ),  # 26
        (27, TType.STRING, 'ownership', 'UTF8', None, ),  # 27
        None,  # 28
        (29, TType.STRUCT, 'inputAddress', (gen.urbancompass.listing.address.ttypes.InputAddress, gen.urbancompass.listing.address.ttypes.InputAddress.thrift_spec), None, ),  # 29
        (30, TType.LIST, 'aliasAddresses', (TType.STRUCT, (gen.urbancompass.listing.address.ttypes.AliasAddress, gen.urbancompass.listing.address.ttypes.AliasAddress.thrift_spec), False), None, ),  # 30
        (31, TType.STRING, '__uc_id_sha__', 'UTF8', None, ),  # 31
        (32, TType.LIST, 'contributingSourceFeeds', (TType.STRING, 'UTF8', False), None, ),  # 32
        (33, TType.LIST, 'neighborhoods', (TType.STRING, 'UTF8', False), None, ),  # 33
        (34, TType.LIST, 'externalLinks', (TType.STRING, 'UTF8', False), None, ),  # 34
        (35, TType.I32, 'buildingAgreementType', None, None, ),  # 35
        (36, TType.STRING, 'buildingProjectName', 'UTF8', None, ),  # 36
        (37, TType.I64, 'buildingEditorCreatedAt', None, None, ),  # 37
        (38, TType.I64, 'buildingEditorLastUpdated', None, None, ),  # 38
        (39, TType.LIST, 'aggregatedMessierListingIds', (TType.I64, None, False), None, ),  # 39
        (40, TType.I32, 'rawPlutoCount', None, None, ),  # 40
        (41, TType.STRING, 'preDirection', 'UTF8', None, ),  # 41
        (42, TType.STRING, 'streetNumber', 'UTF8', None, ),  # 42
        (43, TType.STRING, 'street', 'UTF8', None, ),  # 43
        (44, TType.STRING, 'streetType', 'UTF8', None, ),  # 44
        (45, TType.STRING, 'postDirection', 'UTF8', None, ),  # 45
        (46, TType.LIST, 'recentLenders', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 46
        (47, TType.STRUCT, 'internalOnlyOlrBuildingInfo', (gen.urbancompass.listing.listing.ttypes.OlrBuildingInfo, gen.urbancompass.listing.listing.ttypes.OlrBuildingInfo.thrift_spec), None, ),  # 47
        (48, TType.STRING, 'county', 'UTF8', None, ),  # 48
        (49, TType.STRING, 'messierBuildingId', 'UTF8', None, ),  # 49
        (50, TType.STRING, 'buildingEditorUcIdSha', 'UTF8', None, ),  # 50
        (51, TType.STRING, 'provider', 'UTF8', None, ),  # 51
        (52, TType.LIST, 'editorImagesToExclude', (TType.STRUCT, (gen.urbancompass.image.ttypes.ImageInfo, gen.urbancompass.image.ttypes.ImageInfo.thrift_spec), False), None, ),  # 52
        (53, TType.LIST, 'alternativeCityNames', (TType.STRING, 'UTF8', False), None, ),  # 53
        (54, TType.STRUCT, 'geomObjInfo', (gen.urbancompass.listing.address.ttypes.GeomObjInfo, gen.urbancompass.listing.address.ttypes.GeomObjInfo.thrift_spec), None, ),  # 54
        (55, TType.I32, 'geolocationResult', None, None, ),  # 55
        (56, TType.BOOL, 'addressCorrected', None, None, ),  # 56
        (57, TType.LIST, 'amenitiesToExclude', (TType.STRING, 'UTF8', False), None, ),  # 57
        (58, TType.LIST, 'managementCompanies', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 58
        (59, TType.BOOL, 'zipcodeTieBreakApplied', None, None, ),  # 59
        (60, TType.STRING, 'primaryGovId', 'UTF8', None, ),  # 60
        (61, TType.STRING, 'primaryGovIdType', 'UTF8', None, ),  # 61
        (62, TType.STRUCT, 'newDevelopment', (NewDevelopment, NewDevelopment.thrift_spec), None, ),  # 62
        (63, TType.I64, 'buildingEditorLastDetailPolicyUpdated', None, None, ),  # 63
        (64, TType.I64, 'propertyId', None, None, ),  # 64
        (65, TType.MAP, 'exclusionPathsMap', (TType.STRING, 'UTF8', TType.LIST, (TType.STRING, 'UTF8', False), False), None, ),  # 65
        (66, TType.LIST, 'ownersToExclude', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 66
        (67, TType.LIST, 'developersToExclude', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 67
        (68, TType.LIST, 'managementCompaniesToExclude', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 68
        (69, TType.LIST, 'recentLendersToExclude', (TType.STRUCT, (gen.urbancompass.contact_info.ttypes.ContactInfo, gen.urbancompass.contact_info.ttypes.ContactInfo.thrift_spec), False), None, ),  # 69
    )
    def __init__(self, _id=None, buildingIdSHA=None, buildingId=None, listingIds=None, owners=None, architect=None, developers=None, geoId=None, propertyType=None, lotDimensions=None, buildingDimensions=None, sharedListingFields=None, address=None, city=None, state=None, zipCode=None, latitude=None, longitude=None, districts=None, details=None, managementCompany=None, taxRecords=None, residentialDimensions=None, ownership=None, inputAddress=None, aliasAddresses=None, __uc_id_sha__=None, contributingSourceFeeds=None, neighborhoods=None, externalLinks=None, buildingAgreementType=None, buildingProjectName=None, buildingEditorCreatedAt=None, buildingEditorLastUpdated=None, aggregatedMessierListingIds=None, rawPlutoCount=None, preDirection=None, streetNumber=None, street=None, streetType=None, postDirection=None, recentLenders=None, internalOnlyOlrBuildingInfo=None, county=None, messierBuildingId=None, buildingEditorUcIdSha=None, provider=None, editorImagesToExclude=None, alternativeCityNames=None, geomObjInfo=None, geolocationResult=None, addressCorrected=None, amenitiesToExclude=None, managementCompanies=None, zipcodeTieBreakApplied=None, primaryGovId=None, primaryGovIdType=None, newDevelopment=None, buildingEditorLastDetailPolicyUpdated=None, propertyId=None, exclusionPathsMap=None, ownersToExclude=None, developersToExclude=None, managementCompaniesToExclude=None, recentLendersToExclude=None, ):
        self._id = _id
        self.buildingIdSHA = buildingIdSHA
        self.buildingId = buildingId
        self.listingIds = listingIds
        self.owners = owners
        self.architect = architect
        self.developers = developers
        self.geoId = geoId
        self.propertyType = propertyType
        self.lotDimensions = lotDimensions
        self.buildingDimensions = buildingDimensions
        self.sharedListingFields = sharedListingFields
        self.address = address
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.latitude = latitude
        self.longitude = longitude
        self.districts = districts
        self.details = details
        self.managementCompany = managementCompany
        self.taxRecords = taxRecords
        self.residentialDimensions = residentialDimensions
        self.ownership = ownership
        self.inputAddress = inputAddress
        self.aliasAddresses = aliasAddresses
        self.__uc_id_sha__ = __uc_id_sha__
        self.contributingSourceFeeds = contributingSourceFeeds
        self.neighborhoods = neighborhoods
        self.externalLinks = externalLinks
        self.buildingAgreementType = buildingAgreementType
        self.buildingProjectName = buildingProjectName
        self.buildingEditorCreatedAt = buildingEditorCreatedAt
        self.buildingEditorLastUpdated = buildingEditorLastUpdated
        self.aggregatedMessierListingIds = aggregatedMessierListingIds
        self.rawPlutoCount = rawPlutoCount
        self.preDirection = preDirection
        self.streetNumber = streetNumber
        self.street = street
        self.streetType = streetType
        self.postDirection = postDirection
        self.recentLenders = recentLenders
        self.internalOnlyOlrBuildingInfo = internalOnlyOlrBuildingInfo
        self.county = county
        self.messierBuildingId = messierBuildingId
        self.buildingEditorUcIdSha = buildingEditorUcIdSha
        self.provider = provider
        self.editorImagesToExclude = editorImagesToExclude
        self.alternativeCityNames = alternativeCityNames
        self.geomObjInfo = geomObjInfo
        self.geolocationResult = geolocationResult
        self.addressCorrected = addressCorrected
        self.amenitiesToExclude = amenitiesToExclude
        self.managementCompanies = managementCompanies
        self.zipcodeTieBreakApplied = zipcodeTieBreakApplied
        self.primaryGovId = primaryGovId
        self.primaryGovIdType = primaryGovIdType
        self.newDevelopment = newDevelopment
        self.buildingEditorLastDetailPolicyUpdated = buildingEditorLastDetailPolicyUpdated
        self.propertyId = propertyId
        self.exclusionPathsMap = exclusionPathsMap
        self.ownersToExclude = ownersToExclude
        self.developersToExclude = developersToExclude
        self.managementCompaniesToExclude = managementCompaniesToExclude
        self.recentLendersToExclude = recentLendersToExclude

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.STRING:
                    self._id = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.buildingIdSHA = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.buildingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.listingIds = []
                    (_etype58, _size61) = iprot.readListBegin()
                    for _i59 in range(_size61):
                        _elem60 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.listingIds.append(_elem60)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.LIST:
                    self.owners = []
                    (_etype62, _size65) = iprot.readListBegin()
                    for _i63 in range(_size65):
                        _elem64 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem64.read(iprot)
                        self.owners.append(_elem64)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRUCT:
                    self.architect = gen.urbancompass.contact_info.ttypes.ContactInfo()
                    self.architect.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.LIST:
                    self.developers = []
                    (_etype66, _size69) = iprot.readListBegin()
                    for _i67 in range(_size69):
                        _elem68 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem68.read(iprot)
                        self.developers.append(_elem68)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.STRUCT:
                    self.propertyType = gen.urbancompass.property_type.ttypes.PropertyType()
                    self.propertyType.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 13:
                if ftype == TType.STRUCT:
                    self.lotDimensions = Dimensions()
                    self.lotDimensions.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 14:
                if ftype == TType.STRUCT:
                    self.buildingDimensions = Dimensions()
                    self.buildingDimensions.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 15:
                if ftype == TType.STRUCT:
                    self.sharedListingFields = SharedListingFields()
                    self.sharedListingFields.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 16:
                if ftype == TType.STRING:
                    self.address = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 17:
                if ftype == TType.STRING:
                    self.city = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 18:
                if ftype == TType.STRING:
                    self.state = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 19:
                if ftype == TType.STRING:
                    self.zipCode = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 20:
                if ftype == TType.DOUBLE:
                    self.latitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 21:
                if ftype == TType.DOUBLE:
                    self.longitude = iprot.readDouble()
                else:
                    iprot.skip(ftype)
            elif fid == 22:
                if ftype == TType.LIST:
                    self.districts = []
                    (_etype70, _size73) = iprot.readListBegin()
                    for _i71 in range(_size73):
                        _elem72 = District()
                        _elem72.read(iprot)
                        self.districts.append(_elem72)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 23:
                if ftype == TType.STRUCT:
                    self.details = BuildingDetails()
                    self.details.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 24:
                if ftype == TType.STRUCT:
                    self.managementCompany = gen.urbancompass.contact_info.ttypes.ContactInfo()
                    self.managementCompany.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 25:
                if ftype == TType.LIST:
                    self.taxRecords = []
                    (_etype74, _size77) = iprot.readListBegin()
                    for _i75 in range(_size77):
                        _elem76 = TaxRecord()
                        _elem76.read(iprot)
                        self.taxRecords.append(_elem76)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 26:
                if ftype == TType.STRUCT:
                    self.residentialDimensions = Dimensions()
                    self.residentialDimensions.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 27:
                if ftype == TType.STRING:
                    self.ownership = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 29:
                if ftype == TType.STRUCT:
                    self.inputAddress = gen.urbancompass.listing.address.ttypes.InputAddress()
                    self.inputAddress.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 30:
                if ftype == TType.LIST:
                    self.aliasAddresses = []
                    (_etype78, _size81) = iprot.readListBegin()
                    for _i79 in range(_size81):
                        _elem80 = gen.urbancompass.listing.address.ttypes.AliasAddress()
                        _elem80.read(iprot)
                        self.aliasAddresses.append(_elem80)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 31:
                if ftype == TType.STRING:
                    self.__uc_id_sha__ = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 32:
                if ftype == TType.LIST:
                    self.contributingSourceFeeds = []
                    (_etype82, _size85) = iprot.readListBegin()
                    for _i83 in range(_size85):
                        _elem84 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.contributingSourceFeeds.append(_elem84)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 33:
                if ftype == TType.LIST:
                    self.neighborhoods = []
                    (_etype86, _size89) = iprot.readListBegin()
                    for _i87 in range(_size89):
                        _elem88 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.neighborhoods.append(_elem88)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 34:
                if ftype == TType.LIST:
                    self.externalLinks = []
                    (_etype90, _size93) = iprot.readListBegin()
                    for _i91 in range(_size93):
                        _elem92 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.externalLinks.append(_elem92)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 35:
                if ftype == TType.I32:
                    self.buildingAgreementType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 36:
                if ftype == TType.STRING:
                    self.buildingProjectName = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 37:
                if ftype == TType.I64:
                    self.buildingEditorCreatedAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 38:
                if ftype == TType.I64:
                    self.buildingEditorLastUpdated = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 39:
                if ftype == TType.LIST:
                    self.aggregatedMessierListingIds = []
                    (_etype94, _size97) = iprot.readListBegin()
                    for _i95 in range(_size97):
                        _elem96 = iprot.readI64()
                        self.aggregatedMessierListingIds.append(_elem96)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 40:
                if ftype == TType.I32:
                    self.rawPlutoCount = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 41:
                if ftype == TType.STRING:
                    self.preDirection = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 42:
                if ftype == TType.STRING:
                    self.streetNumber = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 43:
                if ftype == TType.STRING:
                    self.street = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 44:
                if ftype == TType.STRING:
                    self.streetType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 45:
                if ftype == TType.STRING:
                    self.postDirection = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 46:
                if ftype == TType.LIST:
                    self.recentLenders = []
                    (_etype98, _size101) = iprot.readListBegin()
                    for _i99 in range(_size101):
                        _elem100 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem100.read(iprot)
                        self.recentLenders.append(_elem100)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 47:
                if ftype == TType.STRUCT:
                    self.internalOnlyOlrBuildingInfo = gen.urbancompass.listing.listing.ttypes.OlrBuildingInfo()
                    self.internalOnlyOlrBuildingInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 48:
                if ftype == TType.STRING:
                    self.county = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 49:
                if ftype == TType.STRING:
                    self.messierBuildingId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 50:
                if ftype == TType.STRING:
                    self.buildingEditorUcIdSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 51:
                if ftype == TType.STRING:
                    self.provider = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 52:
                if ftype == TType.LIST:
                    self.editorImagesToExclude = []
                    (_etype102, _size105) = iprot.readListBegin()
                    for _i103 in range(_size105):
                        _elem104 = gen.urbancompass.image.ttypes.ImageInfo()
                        _elem104.read(iprot)
                        self.editorImagesToExclude.append(_elem104)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 53:
                if ftype == TType.LIST:
                    self.alternativeCityNames = []
                    (_etype106, _size109) = iprot.readListBegin()
                    for _i107 in range(_size109):
                        _elem108 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.alternativeCityNames.append(_elem108)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 54:
                if ftype == TType.STRUCT:
                    self.geomObjInfo = gen.urbancompass.listing.address.ttypes.GeomObjInfo()
                    self.geomObjInfo.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 55:
                if ftype == TType.I32:
                    self.geolocationResult = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 56:
                if ftype == TType.BOOL:
                    self.addressCorrected = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 57:
                if ftype == TType.LIST:
                    self.amenitiesToExclude = []
                    (_etype110, _size113) = iprot.readListBegin()
                    for _i111 in range(_size113):
                        _elem112 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        self.amenitiesToExclude.append(_elem112)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 58:
                if ftype == TType.LIST:
                    self.managementCompanies = []
                    (_etype114, _size117) = iprot.readListBegin()
                    for _i115 in range(_size117):
                        _elem116 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem116.read(iprot)
                        self.managementCompanies.append(_elem116)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 59:
                if ftype == TType.BOOL:
                    self.zipcodeTieBreakApplied = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 60:
                if ftype == TType.STRING:
                    self.primaryGovId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 61:
                if ftype == TType.STRING:
                    self.primaryGovIdType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 62:
                if ftype == TType.STRUCT:
                    self.newDevelopment = NewDevelopment()
                    self.newDevelopment.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 63:
                if ftype == TType.I64:
                    self.buildingEditorLastDetailPolicyUpdated = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 64:
                if ftype == TType.I64:
                    self.propertyId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 65:
                if ftype == TType.MAP:
                    self.exclusionPathsMap = {}
                    (_ktype119, _vtype120, _size123) = iprot.readMapBegin()
                    for _i118 in range(_size123):
                        _key121 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                        _val122 = []
                        (_etype124, _size127) = iprot.readListBegin()
                        for _i125 in range(_size127):
                            _elem126 = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                            _val122.append(_elem126)
                        iprot.readListEnd()
                        self.exclusionPathsMap[_key121] = _val122
                    iprot.readMapEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 66:
                if ftype == TType.LIST:
                    self.ownersToExclude = []
                    (_etype128, _size131) = iprot.readListBegin()
                    for _i129 in range(_size131):
                        _elem130 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem130.read(iprot)
                        self.ownersToExclude.append(_elem130)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 67:
                if ftype == TType.LIST:
                    self.developersToExclude = []
                    (_etype132, _size135) = iprot.readListBegin()
                    for _i133 in range(_size135):
                        _elem134 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem134.read(iprot)
                        self.developersToExclude.append(_elem134)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 68:
                if ftype == TType.LIST:
                    self.managementCompaniesToExclude = []
                    (_etype136, _size139) = iprot.readListBegin()
                    for _i137 in range(_size139):
                        _elem138 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem138.read(iprot)
                        self.managementCompaniesToExclude.append(_elem138)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 69:
                if ftype == TType.LIST:
                    self.recentLendersToExclude = []
                    (_etype140, _size143) = iprot.readListBegin()
                    for _i141 in range(_size143):
                        _elem142 = gen.urbancompass.contact_info.ttypes.ContactInfo()
                        _elem142.read(iprot)
                        self.recentLendersToExclude.append(_elem142)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('Building')
        if self._id is not None:
            oprot.writeFieldBegin('_id', TType.STRING, 1)
            oprot.writeString(self._id.encode('utf-8') if sys.version_info[0] == 2 else self._id)
            oprot.writeFieldEnd()
        if self.buildingIdSHA is not None:
            oprot.writeFieldBegin('buildingIdSHA', TType.STRING, 2)
            oprot.writeString(self.buildingIdSHA.encode('utf-8') if sys.version_info[0] == 2 else self.buildingIdSHA)
            oprot.writeFieldEnd()
        if self.buildingId is not None:
            oprot.writeFieldBegin('buildingId', TType.STRING, 3)
            oprot.writeString(self.buildingId.encode('utf-8') if sys.version_info[0] == 2 else self.buildingId)
            oprot.writeFieldEnd()
        if self.listingIds is not None:
            oprot.writeFieldBegin('listingIds', TType.LIST, 4)
            oprot.writeListBegin(TType.STRING, len(self.listingIds))
            for _iter144 in self.listingIds:
                oprot.writeString(_iter144.encode('utf-8') if sys.version_info[0] == 2 else _iter144)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.owners is not None:
            oprot.writeFieldBegin('owners', TType.LIST, 8)
            oprot.writeListBegin(TType.STRUCT, len(self.owners))
            for _iter145 in self.owners:
                _iter145.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.architect is not None:
            oprot.writeFieldBegin('architect', TType.STRUCT, 9)
            self.architect.write(oprot)
            oprot.writeFieldEnd()
        if self.developers is not None:
            oprot.writeFieldBegin('developers', TType.LIST, 10)
            oprot.writeListBegin(TType.STRUCT, len(self.developers))
            for _iter146 in self.developers:
                _iter146.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 11)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.propertyType is not None:
            oprot.writeFieldBegin('propertyType', TType.STRUCT, 12)
            self.propertyType.write(oprot)
            oprot.writeFieldEnd()
        if self.lotDimensions is not None:
            oprot.writeFieldBegin('lotDimensions', TType.STRUCT, 13)
            self.lotDimensions.write(oprot)
            oprot.writeFieldEnd()
        if self.buildingDimensions is not None:
            oprot.writeFieldBegin('buildingDimensions', TType.STRUCT, 14)
            self.buildingDimensions.write(oprot)
            oprot.writeFieldEnd()
        if self.sharedListingFields is not None:
            oprot.writeFieldBegin('sharedListingFields', TType.STRUCT, 15)
            self.sharedListingFields.write(oprot)
            oprot.writeFieldEnd()
        if self.address is not None:
            oprot.writeFieldBegin('address', TType.STRING, 16)
            oprot.writeString(self.address.encode('utf-8') if sys.version_info[0] == 2 else self.address)
            oprot.writeFieldEnd()
        if self.city is not None:
            oprot.writeFieldBegin('city', TType.STRING, 17)
            oprot.writeString(self.city.encode('utf-8') if sys.version_info[0] == 2 else self.city)
            oprot.writeFieldEnd()
        if self.state is not None:
            oprot.writeFieldBegin('state', TType.STRING, 18)
            oprot.writeString(self.state.encode('utf-8') if sys.version_info[0] == 2 else self.state)
            oprot.writeFieldEnd()
        if self.zipCode is not None:
            oprot.writeFieldBegin('zipCode', TType.STRING, 19)
            oprot.writeString(self.zipCode.encode('utf-8') if sys.version_info[0] == 2 else self.zipCode)
            oprot.writeFieldEnd()
        if self.latitude is not None:
            oprot.writeFieldBegin('latitude', TType.DOUBLE, 20)
            oprot.writeDouble(self.latitude)
            oprot.writeFieldEnd()
        if self.longitude is not None:
            oprot.writeFieldBegin('longitude', TType.DOUBLE, 21)
            oprot.writeDouble(self.longitude)
            oprot.writeFieldEnd()
        if self.districts is not None:
            oprot.writeFieldBegin('districts', TType.LIST, 22)
            oprot.writeListBegin(TType.STRUCT, len(self.districts))
            for _iter147 in self.districts:
                _iter147.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.details is not None:
            oprot.writeFieldBegin('details', TType.STRUCT, 23)
            self.details.write(oprot)
            oprot.writeFieldEnd()
        if self.managementCompany is not None:
            oprot.writeFieldBegin('managementCompany', TType.STRUCT, 24)
            self.managementCompany.write(oprot)
            oprot.writeFieldEnd()
        if self.taxRecords is not None:
            oprot.writeFieldBegin('taxRecords', TType.LIST, 25)
            oprot.writeListBegin(TType.STRUCT, len(self.taxRecords))
            for _iter148 in self.taxRecords:
                _iter148.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.residentialDimensions is not None:
            oprot.writeFieldBegin('residentialDimensions', TType.STRUCT, 26)
            self.residentialDimensions.write(oprot)
            oprot.writeFieldEnd()
        if self.ownership is not None:
            oprot.writeFieldBegin('ownership', TType.STRING, 27)
            oprot.writeString(self.ownership.encode('utf-8') if sys.version_info[0] == 2 else self.ownership)
            oprot.writeFieldEnd()
        if self.inputAddress is not None:
            oprot.writeFieldBegin('inputAddress', TType.STRUCT, 29)
            self.inputAddress.write(oprot)
            oprot.writeFieldEnd()
        if self.aliasAddresses is not None:
            oprot.writeFieldBegin('aliasAddresses', TType.LIST, 30)
            oprot.writeListBegin(TType.STRUCT, len(self.aliasAddresses))
            for _iter149 in self.aliasAddresses:
                _iter149.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.__uc_id_sha__ is not None:
            oprot.writeFieldBegin('__uc_id_sha__', TType.STRING, 31)
            oprot.writeString(self.__uc_id_sha__.encode('utf-8') if sys.version_info[0] == 2 else self.__uc_id_sha__)
            oprot.writeFieldEnd()
        if self.contributingSourceFeeds is not None:
            oprot.writeFieldBegin('contributingSourceFeeds', TType.LIST, 32)
            oprot.writeListBegin(TType.STRING, len(self.contributingSourceFeeds))
            for _iter150 in self.contributingSourceFeeds:
                oprot.writeString(_iter150.encode('utf-8') if sys.version_info[0] == 2 else _iter150)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.neighborhoods is not None:
            oprot.writeFieldBegin('neighborhoods', TType.LIST, 33)
            oprot.writeListBegin(TType.STRING, len(self.neighborhoods))
            for _iter151 in self.neighborhoods:
                oprot.writeString(_iter151.encode('utf-8') if sys.version_info[0] == 2 else _iter151)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.externalLinks is not None:
            oprot.writeFieldBegin('externalLinks', TType.LIST, 34)
            oprot.writeListBegin(TType.STRING, len(self.externalLinks))
            for _iter152 in self.externalLinks:
                oprot.writeString(_iter152.encode('utf-8') if sys.version_info[0] == 2 else _iter152)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.buildingAgreementType is not None:
            oprot.writeFieldBegin('buildingAgreementType', TType.I32, 35)
            oprot.writeI32(self.buildingAgreementType)
            oprot.writeFieldEnd()
        if self.buildingProjectName is not None:
            oprot.writeFieldBegin('buildingProjectName', TType.STRING, 36)
            oprot.writeString(self.buildingProjectName.encode('utf-8') if sys.version_info[0] == 2 else self.buildingProjectName)
            oprot.writeFieldEnd()
        if self.buildingEditorCreatedAt is not None:
            oprot.writeFieldBegin('buildingEditorCreatedAt', TType.I64, 37)
            oprot.writeI64(self.buildingEditorCreatedAt)
            oprot.writeFieldEnd()
        if self.buildingEditorLastUpdated is not None:
            oprot.writeFieldBegin('buildingEditorLastUpdated', TType.I64, 38)
            oprot.writeI64(self.buildingEditorLastUpdated)
            oprot.writeFieldEnd()
        if self.aggregatedMessierListingIds is not None:
            oprot.writeFieldBegin('aggregatedMessierListingIds', TType.LIST, 39)
            oprot.writeListBegin(TType.I64, len(self.aggregatedMessierListingIds))
            for _iter153 in self.aggregatedMessierListingIds:
                oprot.writeI64(_iter153)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.rawPlutoCount is not None:
            oprot.writeFieldBegin('rawPlutoCount', TType.I32, 40)
            oprot.writeI32(self.rawPlutoCount)
            oprot.writeFieldEnd()
        if self.preDirection is not None:
            oprot.writeFieldBegin('preDirection', TType.STRING, 41)
            oprot.writeString(self.preDirection.encode('utf-8') if sys.version_info[0] == 2 else self.preDirection)
            oprot.writeFieldEnd()
        if self.streetNumber is not None:
            oprot.writeFieldBegin('streetNumber', TType.STRING, 42)
            oprot.writeString(self.streetNumber.encode('utf-8') if sys.version_info[0] == 2 else self.streetNumber)
            oprot.writeFieldEnd()
        if self.street is not None:
            oprot.writeFieldBegin('street', TType.STRING, 43)
            oprot.writeString(self.street.encode('utf-8') if sys.version_info[0] == 2 else self.street)
            oprot.writeFieldEnd()
        if self.streetType is not None:
            oprot.writeFieldBegin('streetType', TType.STRING, 44)
            oprot.writeString(self.streetType.encode('utf-8') if sys.version_info[0] == 2 else self.streetType)
            oprot.writeFieldEnd()
        if self.postDirection is not None:
            oprot.writeFieldBegin('postDirection', TType.STRING, 45)
            oprot.writeString(self.postDirection.encode('utf-8') if sys.version_info[0] == 2 else self.postDirection)
            oprot.writeFieldEnd()
        if self.recentLenders is not None:
            oprot.writeFieldBegin('recentLenders', TType.LIST, 46)
            oprot.writeListBegin(TType.STRUCT, len(self.recentLenders))
            for _iter154 in self.recentLenders:
                _iter154.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.internalOnlyOlrBuildingInfo is not None:
            oprot.writeFieldBegin('internalOnlyOlrBuildingInfo', TType.STRUCT, 47)
            self.internalOnlyOlrBuildingInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.county is not None:
            oprot.writeFieldBegin('county', TType.STRING, 48)
            oprot.writeString(self.county.encode('utf-8') if sys.version_info[0] == 2 else self.county)
            oprot.writeFieldEnd()
        if self.messierBuildingId is not None:
            oprot.writeFieldBegin('messierBuildingId', TType.STRING, 49)
            oprot.writeString(self.messierBuildingId.encode('utf-8') if sys.version_info[0] == 2 else self.messierBuildingId)
            oprot.writeFieldEnd()
        if self.buildingEditorUcIdSha is not None:
            oprot.writeFieldBegin('buildingEditorUcIdSha', TType.STRING, 50)
            oprot.writeString(self.buildingEditorUcIdSha.encode('utf-8') if sys.version_info[0] == 2 else self.buildingEditorUcIdSha)
            oprot.writeFieldEnd()
        if self.provider is not None:
            oprot.writeFieldBegin('provider', TType.STRING, 51)
            oprot.writeString(self.provider.encode('utf-8') if sys.version_info[0] == 2 else self.provider)
            oprot.writeFieldEnd()
        if self.editorImagesToExclude is not None:
            oprot.writeFieldBegin('editorImagesToExclude', TType.LIST, 52)
            oprot.writeListBegin(TType.STRUCT, len(self.editorImagesToExclude))
            for _iter155 in self.editorImagesToExclude:
                _iter155.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.alternativeCityNames is not None:
            oprot.writeFieldBegin('alternativeCityNames', TType.LIST, 53)
            oprot.writeListBegin(TType.STRING, len(self.alternativeCityNames))
            for _iter156 in self.alternativeCityNames:
                oprot.writeString(_iter156.encode('utf-8') if sys.version_info[0] == 2 else _iter156)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.geomObjInfo is not None:
            oprot.writeFieldBegin('geomObjInfo', TType.STRUCT, 54)
            self.geomObjInfo.write(oprot)
            oprot.writeFieldEnd()
        if self.geolocationResult is not None:
            oprot.writeFieldBegin('geolocationResult', TType.I32, 55)
            oprot.writeI32(self.geolocationResult)
            oprot.writeFieldEnd()
        if self.addressCorrected is not None:
            oprot.writeFieldBegin('addressCorrected', TType.BOOL, 56)
            oprot.writeBool(self.addressCorrected)
            oprot.writeFieldEnd()
        if self.amenitiesToExclude is not None:
            oprot.writeFieldBegin('amenitiesToExclude', TType.LIST, 57)
            oprot.writeListBegin(TType.STRING, len(self.amenitiesToExclude))
            for _iter157 in self.amenitiesToExclude:
                oprot.writeString(_iter157.encode('utf-8') if sys.version_info[0] == 2 else _iter157)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.managementCompanies is not None:
            oprot.writeFieldBegin('managementCompanies', TType.LIST, 58)
            oprot.writeListBegin(TType.STRUCT, len(self.managementCompanies))
            for _iter158 in self.managementCompanies:
                _iter158.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.zipcodeTieBreakApplied is not None:
            oprot.writeFieldBegin('zipcodeTieBreakApplied', TType.BOOL, 59)
            oprot.writeBool(self.zipcodeTieBreakApplied)
            oprot.writeFieldEnd()
        if self.primaryGovId is not None:
            oprot.writeFieldBegin('primaryGovId', TType.STRING, 60)
            oprot.writeString(self.primaryGovId.encode('utf-8') if sys.version_info[0] == 2 else self.primaryGovId)
            oprot.writeFieldEnd()
        if self.primaryGovIdType is not None:
            oprot.writeFieldBegin('primaryGovIdType', TType.STRING, 61)
            oprot.writeString(self.primaryGovIdType.encode('utf-8') if sys.version_info[0] == 2 else self.primaryGovIdType)
            oprot.writeFieldEnd()
        if self.newDevelopment is not None:
            oprot.writeFieldBegin('newDevelopment', TType.STRUCT, 62)
            self.newDevelopment.write(oprot)
            oprot.writeFieldEnd()
        if self.buildingEditorLastDetailPolicyUpdated is not None:
            oprot.writeFieldBegin('buildingEditorLastDetailPolicyUpdated', TType.I64, 63)
            oprot.writeI64(self.buildingEditorLastDetailPolicyUpdated)
            oprot.writeFieldEnd()
        if self.propertyId is not None:
            oprot.writeFieldBegin('propertyId', TType.I64, 64)
            oprot.writeI64(self.propertyId)
            oprot.writeFieldEnd()
        if self.exclusionPathsMap is not None:
            oprot.writeFieldBegin('exclusionPathsMap', TType.MAP, 65)
            oprot.writeMapBegin(TType.STRING, TType.LIST, len(self.exclusionPathsMap))
            for _kiter159, _viter160 in self.exclusionPathsMap.items():
                oprot.writeString(_kiter159.encode('utf-8') if sys.version_info[0] == 2 else _kiter159)
                oprot.writeListBegin(TType.STRING, len(_viter160))
                for _iter161 in _viter160:
                    oprot.writeString(_iter161.encode('utf-8') if sys.version_info[0] == 2 else _iter161)
                oprot.writeListEnd()
            oprot.writeMapEnd()
            oprot.writeFieldEnd()
        if self.ownersToExclude is not None:
            oprot.writeFieldBegin('ownersToExclude', TType.LIST, 66)
            oprot.writeListBegin(TType.STRUCT, len(self.ownersToExclude))
            for _iter162 in self.ownersToExclude:
                _iter162.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.developersToExclude is not None:
            oprot.writeFieldBegin('developersToExclude', TType.LIST, 67)
            oprot.writeListBegin(TType.STRUCT, len(self.developersToExclude))
            for _iter163 in self.developersToExclude:
                _iter163.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.managementCompaniesToExclude is not None:
            oprot.writeFieldBegin('managementCompaniesToExclude', TType.LIST, 68)
            oprot.writeListBegin(TType.STRUCT, len(self.managementCompaniesToExclude))
            for _iter164 in self.managementCompaniesToExclude:
                _iter164.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.recentLendersToExclude is not None:
            oprot.writeFieldBegin('recentLendersToExclude', TType.LIST, 69)
            oprot.writeListBegin(TType.STRUCT, len(self.recentLendersToExclude))
            for _iter165 in self.recentLendersToExclude:
                _iter165.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BuildingInfo(object):
    """
    Attributes:
     - messierBuildingId
     - ucAddress
     - ucAddressSha
     - buildingListingIds
     - geoId
     - lastModified
     - buildingStruct
     - primaryPropertyType
     - govId
     - govIdType
     - isNewDevelopment
     - propertyId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'messierBuildingId', None, None, ),  # 1
        (2, TType.STRING, 'ucAddress', 'UTF8', None, ),  # 2
        (3, TType.STRING, 'ucAddressSha', 'UTF8', None, ),  # 3
        (4, TType.LIST, 'buildingListingIds', (TType.I64, None, False), None, ),  # 4
        (5, TType.STRING, 'geoId', 'UTF8', None, ),  # 5
        (6, TType.I64, 'lastModified', None, None, ),  # 6
        (7, TType.STRUCT, 'buildingStruct', (Building, Building.thrift_spec), None, ),  # 7
        (8, TType.I32, 'primaryPropertyType', None, None, ),  # 8
        (9, TType.STRING, 'govId', 'UTF8', None, ),  # 9
        (10, TType.STRING, 'govIdType', 'UTF8', None, ),  # 10
        (11, TType.BOOL, 'isNewDevelopment', None, None, ),  # 11
        (12, TType.I64, 'propertyId', None, None, ),  # 12
    )
    def __init__(self, messierBuildingId=None, ucAddress=None, ucAddressSha=None, buildingListingIds=None, geoId=None, lastModified=None, buildingStruct=None, primaryPropertyType=None, govId=None, govIdType=None, isNewDevelopment=None, propertyId=None, ):
        self.messierBuildingId = messierBuildingId
        self.ucAddress = ucAddress
        self.ucAddressSha = ucAddressSha
        self.buildingListingIds = buildingListingIds
        self.geoId = geoId
        self.lastModified = lastModified
        self.buildingStruct = buildingStruct
        self.primaryPropertyType = primaryPropertyType
        self.govId = govId
        self.govIdType = govIdType
        self.isNewDevelopment = isNewDevelopment
        self.propertyId = propertyId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.messierBuildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.ucAddress = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.ucAddressSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.LIST:
                    self.buildingListingIds = []
                    (_etype166, _size169) = iprot.readListBegin()
                    for _i167 in range(_size169):
                        _elem168 = iprot.readI64()
                        self.buildingListingIds.append(_elem168)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModified = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.buildingStruct = Building()
                    self.buildingStruct.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I32:
                    self.primaryPropertyType = iprot.readI32()
                else:
                    iprot.skip(ftype)
            elif fid == 9:
                if ftype == TType.STRING:
                    self.govId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 10:
                if ftype == TType.STRING:
                    self.govIdType = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 11:
                if ftype == TType.BOOL:
                    self.isNewDevelopment = iprot.readBool()
                else:
                    iprot.skip(ftype)
            elif fid == 12:
                if ftype == TType.I64:
                    self.propertyId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BuildingInfo')
        if self.messierBuildingId is not None:
            oprot.writeFieldBegin('messierBuildingId', TType.I64, 1)
            oprot.writeI64(self.messierBuildingId)
            oprot.writeFieldEnd()
        if self.ucAddress is not None:
            oprot.writeFieldBegin('ucAddress', TType.STRING, 2)
            oprot.writeString(self.ucAddress.encode('utf-8') if sys.version_info[0] == 2 else self.ucAddress)
            oprot.writeFieldEnd()
        if self.ucAddressSha is not None:
            oprot.writeFieldBegin('ucAddressSha', TType.STRING, 3)
            oprot.writeString(self.ucAddressSha.encode('utf-8') if sys.version_info[0] == 2 else self.ucAddressSha)
            oprot.writeFieldEnd()
        if self.buildingListingIds is not None:
            oprot.writeFieldBegin('buildingListingIds', TType.LIST, 4)
            oprot.writeListBegin(TType.I64, len(self.buildingListingIds))
            for _iter170 in self.buildingListingIds:
                oprot.writeI64(_iter170)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 5)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.lastModified is not None:
            oprot.writeFieldBegin('lastModified', TType.I64, 6)
            oprot.writeI64(self.lastModified)
            oprot.writeFieldEnd()
        if self.buildingStruct is not None:
            oprot.writeFieldBegin('buildingStruct', TType.STRUCT, 7)
            self.buildingStruct.write(oprot)
            oprot.writeFieldEnd()
        if self.primaryPropertyType is not None:
            oprot.writeFieldBegin('primaryPropertyType', TType.I32, 8)
            oprot.writeI32(self.primaryPropertyType)
            oprot.writeFieldEnd()
        if self.govId is not None:
            oprot.writeFieldBegin('govId', TType.STRING, 9)
            oprot.writeString(self.govId.encode('utf-8') if sys.version_info[0] == 2 else self.govId)
            oprot.writeFieldEnd()
        if self.govIdType is not None:
            oprot.writeFieldBegin('govIdType', TType.STRING, 10)
            oprot.writeString(self.govIdType.encode('utf-8') if sys.version_info[0] == 2 else self.govIdType)
            oprot.writeFieldEnd()
        if self.isNewDevelopment is not None:
            oprot.writeFieldBegin('isNewDevelopment', TType.BOOL, 11)
            oprot.writeBool(self.isNewDevelopment)
            oprot.writeFieldEnd()
        if self.propertyId is not None:
            oprot.writeFieldBegin('propertyId', TType.I64, 12)
            oprot.writeI64(self.propertyId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class BuildingListingInfo(object):
    """
    Attributes:
     - messierBuildingListingId
     - externalBuildingSha
     - buildingId
     - sourceFeed
     - geoId
     - lastModified
     - buildingStruct
     - createdAt
    """

    thrift_spec = (
        None,  # 0
        (1, TType.I64, 'messierBuildingListingId', None, None, ),  # 1
        (2, TType.STRING, 'externalBuildingSha', 'UTF8', None, ),  # 2
        (3, TType.I64, 'buildingId', None, None, ),  # 3
        (4, TType.STRING, 'sourceFeed', 'UTF8', None, ),  # 4
        (5, TType.STRING, 'geoId', 'UTF8', None, ),  # 5
        (6, TType.I64, 'lastModified', None, None, ),  # 6
        (7, TType.STRUCT, 'buildingStruct', (Building, Building.thrift_spec), None, ),  # 7
        (8, TType.I64, 'createdAt', None, None, ),  # 8
    )
    def __init__(self, messierBuildingListingId=None, externalBuildingSha=None, buildingId=None, sourceFeed=None, geoId=None, lastModified=None, buildingStruct=None, createdAt=None, ):
        self.messierBuildingListingId = messierBuildingListingId
        self.externalBuildingSha = externalBuildingSha
        self.buildingId = buildingId
        self.sourceFeed = sourceFeed
        self.geoId = geoId
        self.lastModified = lastModified
        self.buildingStruct = buildingStruct
        self.createdAt = createdAt

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.I64:
                    self.messierBuildingListingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.STRING:
                    self.externalBuildingSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.I64:
                    self.buildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.STRING:
                    self.sourceFeed = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 5:
                if ftype == TType.STRING:
                    self.geoId = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 6:
                if ftype == TType.I64:
                    self.lastModified = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 7:
                if ftype == TType.STRUCT:
                    self.buildingStruct = Building()
                    self.buildingStruct.read(iprot)
                else:
                    iprot.skip(ftype)
            elif fid == 8:
                if ftype == TType.I64:
                    self.createdAt = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('BuildingListingInfo')
        if self.messierBuildingListingId is not None:
            oprot.writeFieldBegin('messierBuildingListingId', TType.I64, 1)
            oprot.writeI64(self.messierBuildingListingId)
            oprot.writeFieldEnd()
        if self.externalBuildingSha is not None:
            oprot.writeFieldBegin('externalBuildingSha', TType.STRING, 2)
            oprot.writeString(self.externalBuildingSha.encode('utf-8') if sys.version_info[0] == 2 else self.externalBuildingSha)
            oprot.writeFieldEnd()
        if self.buildingId is not None:
            oprot.writeFieldBegin('buildingId', TType.I64, 3)
            oprot.writeI64(self.buildingId)
            oprot.writeFieldEnd()
        if self.sourceFeed is not None:
            oprot.writeFieldBegin('sourceFeed', TType.STRING, 4)
            oprot.writeString(self.sourceFeed.encode('utf-8') if sys.version_info[0] == 2 else self.sourceFeed)
            oprot.writeFieldEnd()
        if self.geoId is not None:
            oprot.writeFieldBegin('geoId', TType.STRING, 5)
            oprot.writeString(self.geoId.encode('utf-8') if sys.version_info[0] == 2 else self.geoId)
            oprot.writeFieldEnd()
        if self.lastModified is not None:
            oprot.writeFieldBegin('lastModified', TType.I64, 6)
            oprot.writeI64(self.lastModified)
            oprot.writeFieldEnd()
        if self.buildingStruct is not None:
            oprot.writeFieldBegin('buildingStruct', TType.STRUCT, 7)
            self.buildingStruct.write(oprot)
            oprot.writeFieldEnd()
        if self.createdAt is not None:
            oprot.writeFieldBegin('createdAt', TType.I64, 8)
            oprot.writeI64(self.createdAt)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)

class GetOneBuildingPartitionOutputDTO(object):
    """
    Attributes:
     - processedBuildings
     - lastBuildingLastModified
     - lastBuildingBuildingAddressSha
     - lastBuildingMessierBuildingId
    """

    thrift_spec = (
        None,  # 0
        (1, TType.LIST, 'processedBuildings', (TType.STRUCT, (Building, Building.thrift_spec), False), None, ),  # 1
        (2, TType.I64, 'lastBuildingLastModified', None, None, ),  # 2
        (3, TType.STRING, 'lastBuildingBuildingAddressSha', 'UTF8', None, ),  # 3
        (4, TType.I64, 'lastBuildingMessierBuildingId', None, None, ),  # 4
    )
    def __init__(self, processedBuildings=None, lastBuildingLastModified=None, lastBuildingBuildingAddressSha=None, lastBuildingMessierBuildingId=None, ):
        self.processedBuildings = processedBuildings
        self.lastBuildingLastModified = lastBuildingLastModified
        self.lastBuildingBuildingAddressSha = lastBuildingBuildingAddressSha
        self.lastBuildingMessierBuildingId = lastBuildingMessierBuildingId

    def read(self, iprot):
        if iprot._fast_decode is not None and isinstance(iprot.trans, TTransport.CReadableTransport) and self.thrift_spec is not None:
            iprot._fast_decode(self, iprot, (self.__class__, self.thrift_spec))
            return
        iprot.readStructBegin()
        while True:
            (fname, ftype, fid) = iprot.readFieldBegin()
            if ftype == TType.STOP:
                break
            if fid == 1:
                if ftype == TType.LIST:
                    self.processedBuildings = []
                    (_etype171, _size174) = iprot.readListBegin()
                    for _i172 in range(_size174):
                        _elem173 = Building()
                        _elem173.read(iprot)
                        self.processedBuildings.append(_elem173)
                    iprot.readListEnd()
                else:
                    iprot.skip(ftype)
            elif fid == 2:
                if ftype == TType.I64:
                    self.lastBuildingLastModified = iprot.readI64()
                else:
                    iprot.skip(ftype)
            elif fid == 3:
                if ftype == TType.STRING:
                    self.lastBuildingBuildingAddressSha = iprot.readString().decode('utf-8') if sys.version_info[0] == 2 else iprot.readString()
                else:
                    iprot.skip(ftype)
            elif fid == 4:
                if ftype == TType.I64:
                    self.lastBuildingMessierBuildingId = iprot.readI64()
                else:
                    iprot.skip(ftype)
            else:
                iprot.skip(ftype)
            iprot.readFieldEnd()
        iprot.readStructEnd()

    def write(self, oprot):
        if oprot._fast_encode is not None and self.thrift_spec is not None:
            oprot.trans.write(oprot._fast_encode(self, (self.__class__, self.thrift_spec)))
            return
        oprot.writeStructBegin('GetOneBuildingPartitionOutputDTO')
        if self.processedBuildings is not None:
            oprot.writeFieldBegin('processedBuildings', TType.LIST, 1)
            oprot.writeListBegin(TType.STRUCT, len(self.processedBuildings))
            for _iter175 in self.processedBuildings:
                _iter175.write(oprot)
            oprot.writeListEnd()
            oprot.writeFieldEnd()
        if self.lastBuildingLastModified is not None:
            oprot.writeFieldBegin('lastBuildingLastModified', TType.I64, 2)
            oprot.writeI64(self.lastBuildingLastModified)
            oprot.writeFieldEnd()
        if self.lastBuildingBuildingAddressSha is not None:
            oprot.writeFieldBegin('lastBuildingBuildingAddressSha', TType.STRING, 3)
            oprot.writeString(self.lastBuildingBuildingAddressSha.encode('utf-8') if sys.version_info[0] == 2 else self.lastBuildingBuildingAddressSha)
            oprot.writeFieldEnd()
        if self.lastBuildingMessierBuildingId is not None:
            oprot.writeFieldBegin('lastBuildingMessierBuildingId', TType.I64, 4)
            oprot.writeI64(self.lastBuildingMessierBuildingId)
            oprot.writeFieldEnd()
        oprot.writeFieldStop()
        oprot.writeStructEnd()

    def validate(self):
        return

    def __repr__(self):
        L = ['%s=%r' % (key, value)
             for key, value in self.__dict__.items()]
        return '%s(%s)' % (self.__class__.__name__, ', '.join(L))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not (self == other)
