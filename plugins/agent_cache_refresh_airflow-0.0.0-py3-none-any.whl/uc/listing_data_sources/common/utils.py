# -*- coding: utf-8 -*-
"""
:copyright: (c) 2014 by UrbanCompass, Inc.
"""

import argparse
import io
import contextlib
import errno
import fcntl
import functools
import hashlib
import imghdr
import inspect
import itertools
import logging
import operator
import pkgutil
import string
import sys
import tempfile
import threading
import time
import urllib.request, urllib.error, urllib.parse

import os
import pymongo

import pymongo.errors
import requests
from bson import SON
from unittest.mock import MagicMock
from pymongo import collection as collection_type, UpdateOne, ReplaceOne
from retrying import retry
from thrift.Thrift import TApplicationException

from gen.urbancompass.geography.common.constants import SOURCE_FEED_DISPLAY_NAMES
from gen.urbancompass.image.ttypes import AsyncImagesTag
from gen.urbancompass.listing.listing_normalization.ttypes import NormalizationRequest
from gen.urbancompass.ingestion.feed_forge.feed_forge_service.ttypes import FeedCallMode

from uc.base import app
from uc.aws import s3_tools_uc_args
from uc import json_thrift
from uc import clients
from uc.listing_data_sources.common.constants import MONGO_ID
from uc.listing_data_sources.common.constants import UC_ID_SHA
from uc.listing_data_sources.common.constants import UC_SOURCE_ID
from uc.util.decorators import logging_return_or_exception
from functools import reduce


class PrefixArgParser(object):
    def __init__(
        self,
        parser,
        long_flag_prefix=None,
        short_flag_prefix=None,
        arg_prefix=None,
        add_default_to_help=True,
    ):
        self.parser = parser
        self.long_flag_prefix = long_flag_prefix
        self.short_flag_prefix = short_flag_prefix
        self.arg_prefix = arg_prefix
        self.add_default_to_help = add_default_to_help

    def __getattr__(self, item):
        return getattr(self.parser, item)

    def flag_chars(self, arg):
        return list(itertools.takewhile(lambda c: c in self.parser.prefix_chars, arg))

    def add_prefix(self, arg):
        name_start = len(self.flag_chars(arg))
        prefix = {0: self.arg_prefix, 1: self.short_flag_prefix}.get(
            name_start, self.long_flag_prefix
        )
        if not prefix or arg[name_start:].startswith(prefix):
            return arg
        else:
            return arg[:name_start] + prefix + arg[name_start:]

    @staticmethod
    def add_default(dargs):
        if dargs.get("default"):
            help = dargs.get("help", "")
            if not help[-1:].isspace():
                help += " "
            dargs["help"] = help + "(default=%(default)r)"

    def is_optional_argument(self, *args):
        return any(self.flag_chars(arg) for arg in args)

    def get_dest_for_optional_argument(self, *args):
        first_short_option = None
        for arg in args:
            if len(self.flag_chars(arg)) == 2:
                return arg[2:].replace("-", "_")
            elif len(self.flag_chars(arg)) == 1 and first_short_option is None:
                first_short_option = arg
        return first_short_option[1:].replace("-", "_")

    def get_default_metavar_for_optional_argument_with_no_dest(self, *args):
        return self.get_dest_for_optional_argument(*args).upper()

    def add_argument(self, *args, **dargs):
        if (
            self.is_optional_argument(*args)
            and dargs.get("action", "store") in ("store", "append")
            and "metavar" not in dargs
            and "dest" not in dargs
            and "choices" not in dargs
        ):
            dargs["metavar"] = self.get_default_metavar_for_optional_argument_with_no_dest(*args)
        args = [self.add_prefix(arg) for arg in args]
        if self.add_default_to_help:
            self.add_default(dargs)
        return self.parser.add_argument(*args, **dargs)

    def get_options(self, options):
        results = argparse.Namespace()
        for prefix in (self.long_flag_prefix, self.short_flag_prefix, self.arg_prefix):
            if prefix:
                for flag, value in list(vars(options).items()):
                    if flag.startswith(prefix):
                        setattr(results, flag[len(prefix) :], value)
        return results

    def get_option(self, option):
        return getattr(self.options, option)

    @property
    def options(self):
        if not hasattr(self, "_options"):
            self._options = self.get_options(app.OPTIONS)
        return self._options

    def set_defaults(self, **kwargs):
        # This function only works for setting default values for long flags
        args = {self.long_flag_prefix + key: value for key, value in list(kwargs.items())}
        self.parser.set_defaults(**args)


class RetsProxyException(Exception):
    def __init__(self, msg):
        super(RetsProxyException, self).__init__(self, msg)
        self.text = msg


def add_google_style_bool_argument(arg_parser, *args, **kwargs):
    """
    Add a google style bool argument.

    This adds 2 mutually exclusive flags, one is "--flag" and the other is "--no-flag".
    By default, the value is None, when --flag is specified, value is set to True and --no-flag set
    it to False.

    :param arg_parser: arg_parser to add flags to
    :param args: any args taken by add_argument function
    :param kwargs: any keyword args taken by add_argument function
    :return:
    """
    prefix_arg_parser = PrefixArgParser(arg_parser, "no-", "no-")
    if "dest" not in kwargs:
        kwargs["dest"] = prefix_arg_parser.get_dest_for_optional_argument(*args)
    if "default" not in kwargs:
        kwargs["default"] = None
    meg = arg_parser.add_mutually_exclusive_group(required=kwargs.pop("required", None))
    meg.add_argument(*args, action="store_true", **kwargs)
    kwargs["help"] = argparse.SUPPRESS
    meg.add_argument(
        *(prefix_arg_parser.add_prefix(arg) for arg in args), action="store_false", **kwargs
    )


def ucretry(*args, **kwargs):
    """
    Reuse the retrying.retry but support the followings:

    No retries on SystemExit error;
    Always logging exceptions;

    Should be used the same way as retrying.retry, as a decorator, but with only kwargs

    :param kwargs: any kw args supported by retrying.retry
    :return: function
    """

    original_retry_on_exception = kwargs.get("retry_on_exception")

    def retry_on_exception(exception):
        logging.error("Caught some exception: %r" % exception)
        if isinstance(exception, SystemExit):
            return False
        return original_retry_on_exception(exception) if original_retry_on_exception else True

    kwargs["retry_on_exception"] = retry_on_exception

    return retry(*args, **kwargs)


@contextlib.contextmanager
def with_lock(exit_on_failure=True):
    lock_dir = "/var/lock"
    if not os.access(lock_dir, os.W_OK):
        lock_dir = tempfile.gettempdir()
    lock_file = os.path.join(lock_dir, "%s.pid" % os.path.basename(sys.argv[0]))
    fd = os.open(lock_file, os.O_RDWR | os.O_CREAT)
    opened = os.fdopen(fd, "r+")
    try:
        fcntl.lockf(opened, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError as ioe:
        if ioe.errno in (errno.EAGAIN, errno.EACCES):
            opened.close()
            if exit_on_failure:
                logging.error("Unable to grab lock %s, exiting", lock_file)
                sys.exit()
            yield None
        else:
            raise
    else:
        try:
            pid = "%s\n" % os.getpid()
            opened.write(pid)
            opened.truncate(len(pid))
            yield opened
        finally:
            fcntl.lockf(opened, fcntl.LOCK_UN)
            opened.close()
            os.unlink(lock_file)


def _read_file(path, s3_connector=None):
    if path.startswith("s3://"):
        if s3_connector is None:
            s3_connector = s3_tools_uc_args.new_s3_connector(use_iam=True)
        with s3_connector.temp_copy_of_s3_file(path) as tmp:
            return open(tmp).read()
    elif path.startswith("http://") or path.startswith("https://"):
        # Using requests for http(s) protocol to support basic authentication
        response = requests.get(path)
        response.raise_for_status()
        return response.text
    elif "://" in path:
        f = urllib.request.urlopen(path)
        return f.read()
    else:
        return open(path).read()


def read_file(path, s3_connector=None, **retry_dargs):
    if retry_dargs:

        @ucretry(**retry_dargs)
        def read_file_wrapped():
            return _read_file(path, s3_connector)

        return read_file_wrapped()
    else:
        return _read_file(path, s3_connector)


def get_latest_file_from_s3(file_name_prefix, path, s3_connector, file_type=".csv"):
    directory_files = s3_connector.list(path)
    # The name of csv file has to be started with prefix and ended with 'csv'
    geo_field_map_files = [
        file_name
        for file_name in sorted(directory_files)
        if file_name.split("/")[-1].startswith(file_name_prefix) and file_name.endswith(file_type)
    ]
    if geo_field_map_files:
        return max(geo_field_map_files)
    else:
        return None


def _save_file(path, data, s3_connector):
    if path.startswith("s3://"):
        s3_connector.upload(path, io.StringIO(data), num_cb=0)
    else:  # assume it's local file system
        open(path, "wb").write(data)


def save_file(path, data, s3_connector, **retry_dargs):
    if retry_dargs:

        @ucretry(**retry_dargs)
        def save_file_wrapped():
            return _save_file(path, data, s3_connector)

        return save_file_wrapped()
    else:
        return _save_file(path, data, s3_connector)


def save_to_mongo_with_overrides(collection, documents, key, **overrides):
    """
    Save documents/listings to mongo collection

    The documents can contain updates operators from mongo, and works in a similar fashion, if a
    document don't contain any of these update operators (e.g. $set), it will override the entire
    document, otherwise, it's updating parts of the document.

    So far, only $set operator is supported

    For more information, see

    http://docs.mongodb.org/manual/reference/operator/update/

    http://docs.mongodb.org/manual/reference/method/db.collection.update/#db.collection.update


    :param collection: mongo collection
    :param documents: listings/documents to write out
    :param key: the id of the document, used for lookup, this is like _id in mongo document
    :param overrides: key, value pairs of extra data to be written to mongo
    :return:
    """
    bulk_op = collection.initialize_unordered_bulk_op()
    if documents:
        for document in documents:
            if isinstance(key, (tuple, list)):
                key_dict = {k: document[k] for k in key}
            else:
                key_dict = {key: document[key]}
            dollar_set = document.get("$set")
            if dollar_set:
                bulk_op.find(key_dict).update_one({"$set": dict(dollar_set, **overrides)})
            else:
                bulk_op.find(key_dict).upsert().replace_one(dict(document, **overrides))

        try:
            bulk_op.execute()
        except pymongo.errors.BulkWriteError as bwe:
            logging.error(bwe.details)
            raise
    else:
        return None


def get_all_keys(coll):
    """
    Uses map reduce to retrieve all the keys from a collection's records.
    Recursively traverses lists and dict within records and collects their keys.

    :param coll: Mongo collection
    :return: A list of top-level keys found in this collection.
    """

    def all_keys(d, prefix=""):
        top_level_keys = [".".join((prefix, key)) for key in list(d.keys())]
        recursive_keys = []
        for key in top_level_keys:
            val = d.get(key)
            if isinstance(val, dict):
                recursive_keys += all_keys(val, prefix=key)
            elif isinstance(val, list):
                for item in val:
                    if isinstance(item, collection_type.Collection):
                        raise TypeError("Cannot handle nested mongo collections.")
                    recursive_keys += (
                        all_keys(item, prefix=key)
                        if ((isinstance(item, dict) or isinstance(item, list)))
                        else []
                    )

        return top_level_keys + recursive_keys

    return reduce(
        lambda keys, rec_keys: operator.or_(keys, set(rec_keys)),
        [all_keys(d) for d in coll.find()],
        set(),
    )


def compare_collection_to_metadata(keys_to_values, coll, lookup_fields):
    key_value_differences = {}
    for key in lookup_fields:
        values = keys_to_values.get(key)
        if not values:
            logging.info("Specified key %s not in metadata.", key)
        else:
            metadata_vals = set(values)
            raw_vals = set(coll.distinct(key))

            key_value_differences[key] = {
                "both": sorted(list(metadata_vals.intersection(raw_vals))),
                "metadata_only": sorted(list(metadata_vals.difference(raw_vals))),
                "raw_only": sorted(list(raw_vals.difference(metadata_vals))),
            }

    return key_value_differences


def save_to_mongo(collection, listings, key):
    return save_to_mongo_with_overrides(collection, listings, key)


# TODO: to be removed once mongo db migration cleaup done
def save_to_db(collection, listings, key):
    requests = []
    if listings:
        for document in listings:
            if isinstance(key, (tuple, list)):
                key_dict = {k: document[k] for k in key}
            else:
                key_dict = {key: document[key]}
            dollar_set = document.get("$set")
            if dollar_set:
                requests.append(UpdateOne(key_dict, {"$set": dict(dollar_set)}))
            else:
                requests.append(ReplaceOne(key_dict, document, upsert=True))

        try:
            result = collection.bulk_write(requests)
            logging.info(
                "Modified: {}, Upserted: {}, Matched: {}".format(
                    result.modified_count, result.upserted_count, result.matched_count
                )
            )

            return result
        except pymongo.errors.BulkWriteError as bwe:
            logging.error(bwe.details)
            raise
    else:
        return None


def load_from_mongo_by_key_values(collection, key, values_list, projection_fields={}):
    result = {}
    projection = projection_fields.copy()
    projection.update({key: 1})
    for item in collection.find({key: {"$in": values_list}}, projection):
        result[item[key]] = item
    return result


def load_from_mongo_by_lat_long(collection, key, latitude, longitude, max_distance):
    """
    Retrieve the entries based on coordinates of lat and long from MongoDB
    @:param key needs to be the geojson type of Point and indexed as GEOSPHERE in MongoDB
    """
    result = []
    query = {
        key: {
            "$near": SON(
                [
                    ("$geometry", SON([("type", "Point"), ("coordinates", [longitude, latitude])])),
                    ("$maxDistance", max_distance),
                ]
            )
        }
    }
    for item in collection.find(query):
        result.append(item)
    return result


def load_from_mongo_by_source(collection, source):
    return load_from_mongo_by_sources(collection, [source])


def load_from_mongo_by_sources(collection, sources):
    source_ids = [source[MONGO_ID] for source in sources]
    return list(collection.find({"__uc_source__": {"$in": source_ids}}))


def truncate_mongo_bulk_upserted_results(results, limit=20):
    if results:
        upserted = results["upserted"]
        if len(upserted) > limit:
            results["upserted"] = upserted[:limit] + [
                "%s entries truncated ..." % (len(upserted) - limit)
            ]
        return results
    else:
        return None


class ResultsLoggingThread(threading.Thread):
    """
    A thread would always log its return results or exception, target parameter is a required keyword
    """

    def __init__(self, *args, **dargs):
        self.success = False
        self.results = None

        def target_wrapper(*args, **dargs):
            try:
                results = target(*args, **dargs)
                self.success = True
                self.results = results
                return results
            except:
                self.exc_info = sys.exc_info()
                raise

        if 1 < len(args):
            target = args[1]
            args = list(args)
            args[1] = logging_return_or_exception(functools.wraps(target)(target_wrapper))
        else:
            target = dargs["target"]
            dargs["target"] = logging_return_or_exception(functools.wraps(target)(target_wrapper))

        super(ResultsLoggingThread, self).__init__(*args, **dargs)


class ModuleDisable(object):
    """
    Class that mocks all functions and classes of the specified module,
    to make sure that no code path is able to use this module
    """

    @classmethod
    def _disable_functions_and_classes(cls, module_obj, magic_mock):
        for k in dir(module_obj):
            obj = getattr(module_obj, k)
            if inspect.isclass(obj) or inspect.isroutine(obj):
                try:
                    setattr(module_obj, k, magic_mock)
                except:
                    pass

    @classmethod
    def disable(cls, module):
        if isinstance(module, str):
            module = __import__(module)

        magic_mock = MagicMock(
            spec=[], side_effect=Exception("Module %s was disallowed for use" % module.__name__)
        )

        cls._disable_functions_and_classes(module, magic_mock)

        prefix = module.__name__ + "."
        for importer, modname, ispkg in pkgutil.iter_modules(module.__path__, prefix):
            module = __import__(modname, fromlist=["dummy"])
            cls._disable_functions_and_classes(module, magic_mock)


def parse_tsv(contents):
    dicts = []
    headers = None
    for line in contents.splitlines():
        if line.strip():
            fields = line.split("\t")
            if not headers:
                headers = fields
                continue
            # If header length doesn't match field length,
            # we still want to process the data that aligned with the header
            dicts.append({k: v for k, v in zip(headers, fields)})
    return dicts


def fix_image_header(image):
    # The image header may contain the date/time of the download, override with blank
    start_signature = "Property\x0d\x0a"
    end_signature = "RETS-Connector/1.2"
    printable_bytes = set(ord(c) for c in string.printable)
    replaced = 0

    if imghdr.what("", image["__DATA__"]) == "jpeg":
        offset = image["__DATA__"].find(start_signature)
        if offset != -1:
            header_length = ord(image["__DATA__"][offset - 1])
            end_position = image["__DATA__"].find(
                end_signature, offset + len(start_signature), offset + header_length
            )
            if end_position == -1:
                end_position = offset + header_length
            else:
                end_position += len(end_signature)
            bytes_obj = bytearray(image["__DATA__"])
            for i in range(offset, end_position):
                if bytes_obj[i] in printable_bytes:
                    bytes_obj[i] = " "
                    replaced += 1
                else:
                    break
            image["__DATA__"] = str(bytes_obj)
    return replaced


def generate_image_info(image_response):
    response_dict = {}
    response_dict["thumbnail"] = image_response.newThumbUrl
    response_dict["original"] = image_response.newUrl
    if image_response.metaData:
        response_dict["watermarked"] = image_response.metaData.watermarked
        response_dict["width"] = image_response.metaData.width
        response_dict["height"] = image_response.metaData.height
        response_dict["byteSize"] = image_response.metaData.byteSize
        response_dict["md5Sum"] = image_response.metaData.md5Sum
    return response_dict


def normalize_display_source_name(source):
    """
    For MLS market, instead of using the name defined the <geo>_rets, prefer more concise
    name for different geo
    :param source: source name from rets app
    :return: normalized source name if possible
    """
    return SOURCE_FEED_DISPLAY_NAMES.get(source, source)


@ucretry(
    stop_max_attempt_number=2,
    wait_fixed=1000,
    retry_on_exception=lambda e: not isinstance(e, TApplicationException),
    wrap_exception=False,
)
def normalize_listing_revision(
    client,
    listing_revision,
    process_image_async=None,
    source=None,
    geo=None,
    use_google_geolocator=None,
):
    with client.ensure_connected():
        tag = None
        if process_image_async:
            assert source
            assert geo
            tag = AsyncImagesTag(sourceName=source, geo=geo)
        request = NormalizationRequest(
            inputListing=listing_revision,
            geoId=geo,
            asyncImagesTag=tag,
            useGoogleGeolocator=use_google_geolocator,
        )
        response = client.normalizeListingAndImages(request)
        return response.normalizedListing, response.cause


def generate_uc_id_sha(source_name, *keys):
    """
    Generate an ID based on feed name and feed primary key.

    These IDs are used to uniquely identify feed listing objects.

    :param source_name: Name of the source from which the listing comes.
    :param keys: Combined together must form a unique key for the source provider.
    :type keys: iterator(str) or str
    :return: ID string that should be unique across all Compass data feeds.
    """
    key_string = ",".join(keys)
    return hashlib.sha1((",".join((source_name, key_string))).encode("utf-8")).hexdigest()


def time_to_printable_thrift_timestamp(time):
    return time.to_string() if time else repr(None)


_thrift_clients_factory = None


def get_rpc_client_factory(app_options):
    global _thrift_clients_factory
    if not _thrift_clients_factory:
        _thrift_clients_factory = clients.GrpcClientFactory(app_options)
    return _thrift_clients_factory


def listing_revision_to_dict(listing_revision, listing_pk_name, listing_pk):
    ret = json_thrift.thrift_to_dict(listing_revision)
    ret[listing_pk_name] = listing_pk
    ret[UC_ID_SHA] = getattr(listing_revision, UC_ID_SHA)
    ret[UC_SOURCE_ID] = getattr(listing_revision, UC_SOURCE_ID)
    return ret


def split_by_condition(iter, condition_func=lambda x: True):
    ret_true = []
    ret_false = []
    for l in iter:
        if condition_func(l):
            ret_true.append(l)
        else:
            ret_false.append(l)
    return ret_true, ret_false


def record_stats(event_logger, class_name, rets_mode, timing_stats, item_stats, timestamp=None):
    try:
        timestamp = int(timestamp or time.time())
        suffix = "{}.{}".format(class_name, rets_mode) if rets_mode else class_name
        event_logger.log_event(
            distinct_id="rets_app_metrics_{0}_1".format(timestamp),
            name="rets_app.timings.{}".format(suffix),
            json_dict={"timestamp": timestamp, "value": timing_stats},
        )
        event_logger.log_event(
            distinct_id="rets_app_metrics_{0}_2".format(timestamp),
            name="rets_app.items_processed.{}".format(suffix),
            json_dict={"timestamp": timestamp, "value": item_stats},
        )
    except Exception as e:
        logging.exception(e)


def ensure_listing_collection_indices(intermediate, raw_collection, listing_primary_keys):
    raw_collection.ensure_index(
        [(key, pymongo.ASCENDING) for key in listing_primary_keys], unique=True, background=True
    )
    raw_collection.ensure_index("__uc_source__", background=True)
    intermediate.ensure_index("listingId", background=True)
    intermediate.ensure_index("listingIdSHA", background=True)
    intermediate.ensure_index(
        [(key, pymongo.ASCENDING) for key in listing_primary_keys], unique=True, background=True
    )
    intermediate.ensure_index("__uc_source__", background=True)
    intermediate.ensure_index("mostRecentSourceId", background=True)


def is_incremental_mode(mode):
    return mode in ("incremental", "fixup")


def get_source_feed(lr):
    """
    Get source feed of a listing revision object
    :param lr: ListingRevision object
    :return: source feed str
    """
    if lr.listing.externalKeys:
        source_feed_keys = [x for x in lr.listing.externalKeys if x.externalKeyName == "sourceFeed"]
        if len(source_feed_keys) > 0:
            return source_feed_keys[0].externalKeyValue
    return None


# TODO: this method should be updated when thrift is updated and approach is stable
def get_feed_forge_call_mode(mode):
    switcher = {
        "incremental": FeedCallMode.INCREMENTAL,
        "reingest": FeedCallMode.REINGESTION,
        "backfill": FeedCallMode.INCREMENTAL,
    }
    return switcher.get(mode, FeedCallMode.UNKNOWN)


def truncate_string(string, length):
    if string and len(string) < length:
        return string
    return string[:length] + ".."


def feed_forge_call_mode_remap(mode):
    switcher = {
        1: "incremental",
        2: "reingest",
    }
    return switcher.get(mode, "unknown")
