# -*- coding: utf-8 -*-
"""
Client Service to Service Auth interceptor.
Stores the information about last calling client in
request context.

:copyright: (c) 2021 by UrbanCompass, Inc.
"""
import grpc
import logging

from grpc._interceptor import _ClientCallDetails
from uc.base.app import get_app_name
from uc.service_auth.service_auth import DistinguishedNameMetadata
from gen.urbancompass.common.base.constants import SERVICE_AUTH_KEY


class ClientServiceAuthInterceptor(grpc.UnaryUnaryClientInterceptor):
    def intercept_unary_unary(self, continuation, client_call_details, request):
        """An interceptor that adds a thrift-serialized ClientServiceAuthInterceptor to
         the grpc Context metadata. This can be in turn used by the servers to identify
          their upstream clients info. This is the implementation of
         https://grpc.github.io/grpc/python/_modules/grpc.html#UnaryUnaryClientInterceptor.intercept_unary_unary
        :param continuation: A function that proceeds with the invocation by
                executing the next interceptor in chain or invoking the
                actual RPC on the underlying Channel. It is the interceptor's
                responsibility to call it if it decides to move the RPC forward.
                The interceptor can use
                `response_iterator = continuation(client_call_details, request)`
                to continue with the RPC. `continuation` returns an object that is
                both a Call for the RPC and an iterator for response values.
                Drawing response values from the returned Call-iterator may
                raise RpcError indicating termination of the RPC with non-OK
                status.
        :param client_call_details: A ClientCallDetails object describing the
                outgoing RPC.
        :param request: The request value for the RPC.
        :return: An object that is both a Call for the RPC and an iterator of
                response values. Drawing response values from the returned
                Call-iterator may raise RpcError indicating termination of
                the RPC with non-OK status.
        """
        metadata = {}
        if client_call_details.metadata:
            metadata = dict(client_call_details.metadata)
        try:
            app_name = get_app_name()

            logging.debug("app_name=%s" % app_name)
            if app_name:
                distinguished_name_metadata = DistinguishedNameMetadata(app_name)
                metadata[SERVICE_AUTH_KEY] = str(distinguished_name_metadata)
        except Exception as e:
            logging.warning(
                "{} Cannot get DistinguishedNameMetadata with error: {}".format(
                    self.__class__.__name__, e
                )
            )
        client_call_details = _ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=metadata.items(),
            credentials=client_call_details.credentials,
            wait_for_ready=client_call_details.wait_for_ready,
            compression=client_call_details.compression,
        )
        response = continuation(client_call_details, request)
        return response
